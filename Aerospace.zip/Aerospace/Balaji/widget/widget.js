/**
 * Created by rjogle on 10/4/2016.
 */
angular.module('App.widget', [])
    .directive('rejectPopup', function () {
        return {
            restrict: 'E',
            replace: true,
            template: '<div class="modal fade form-box" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">' +
            '<div class="modal-dialog" role="document">'+
            '   <div class="modal-content">' +
            '  <div class="modal-header">' +
            '       <h4 class="modal-title main-heading" id="myModalLabel">We are Sorry</h4>' +
            '       </div>' +
            '       <div class="modal-body">' +
            '          <h2 class="sub-heading">It looks like we are not able to provide you with coverage.</h2>' +
            '       </div>' +
            '       <div class="modal-footer">' +
            '       <a class="go-to-aig-btn" data-dismiss="modal">Back to Application</a>' +
            '       <a class="go-to-aig-btn" href="http://www.aig.com/business/insurance/specialty/unmanned-aircraft-solutions">Go to AIG.COM</a>' +
            '       </div>' +
            '       </div>' +
            '       </div>' +
            '       </div>',
            controller: function ($scope) {
                $scope.rejected = function (attrs) {
                    $('#myModal').modal({backdrop: 'static', keyboard: false})
                }
            }
        }
    })
    .directive('agePopup', function () {
        return {
            restrict: 'E',
            replace: true,
            template: '<div class="modal fade form-box" id="ageRejectModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">' +
            '<div class="modal-dialog" role="document">'+
            '   <div class="modal-content">' +
            '  <div class="modal-header">' +
            '       <h4 class="modal-title main-heading" id="myModalLabel">We are Sorry</h4>' +
            '       </div>' +
            '       <div class="modal-body">' +
            '          <h2 class="sub-heading">This operator needs to be at least 18 years of age. We cannot provide you coverage at this time.</h2>' +
            '       </div>' +
            '       <div class="modal-footer">' +
            '       <a class="go-to-aig-btn" data-dismiss="modal">Back to Application</a>' +
            '       <a class="go-to-aig-btn" href="http://www.aig.com/business/insurance/specialty/unmanned-aircraft-solutions">Go to AIG.COM</a>' +
            '       </div>' +
            '       </div>' +
            '       </div>' +
            '       </div>',
            controller: function ($scope) {
                // $('#ageRejectModal').modal({backdrop: 'static', keyboard: false})
            }
        }
    })
    .directive('fexpPopup', function () {
        return {
            restrict: 'E',
            replace: true,
            template: '<div class="modal fade form-box" id="fexpRejectModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">' +
            '<div class="modal-dialog" role="document">'+
            '   <div class="modal-content">' +
            '  <div class="modal-header">' +
            '       <h4 class="modal-title main-heading" id="myModalLabel">We are Sorry</h4>' +
            '       </div>' +
            '       <div class="modal-body">' +
            '          <h2 class="sub-heading">This operator needs at least 5 hours of total flying experience to be covered. You can complete this form now, and then notify your broker once they have completed their hours</h2>' +
            '       </div>' +
            '       <div class="modal-footer">' +
            '       <a class="go-to-aig-btn" data-dismiss="modal">Back to Application</a>' +
            '       <a class="go-to-aig-btn" href="http://www.aig.com/business/insurance/specialty/unmanned-aircraft-solutions">Go to AIG.COM</a>' +
            '       </div>' +
            '       </div>' +
            '       </div>' +
            '       </div>',
            controller: function ($scope) {
                // $('#ageRejectModal').modal({backdrop: 'static', keyboard: false})
            }
        }
    })
    .directive('htmlQuote', function (HTMLtoPDFobj,$sce) {
        return {
            restrict: 'E',
            replace: true,
            template: '<div class="modal fade form-box" id="quote" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">' +
            '<div class="modal-dialog" role="document">'+
            '   <div class="modal-content">' +
            '  <div class="modal-header">' +
            '       </div>' +
            '       <div class="modal-body">' +
            "          <div class='' id='showHtmlData' ng-bind-html='showHTMLData'></div>" +
            '       </div>' +
            '       <div class="modal-footer">' +
            '       <a class="go-to-aig-btn" data-dismiss="modal">Back to Application</a>' +
            '       <a class="go-to-aig-btn" href="http://www.aig.com/business/insurance/specialty/unmanned-aircraft-solutions">Go to AIG.COM</a>' +
            '       </div>' +
            '       </div>' +
            '       </div>' +
            '       </div>',
            controller: function ($scope) {
                $scope.showpopup = function (attrs) {
                    $scope.showHTMLData = $sce.trustAsHtml(HTMLtoPDFobj.finalObj)
                    $('#quote').modal({backdrop: 'static', keyboard: false})
                }
            }
        }
    })
    .directive('fraudNotice', function () {
        return {
            restrict: 'E',
            replace: true,
            template: '<div class="modal fade form-box" id="fraudNotice" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">' +
            '<div class="modal-dialog" role="document">'+
            '   <div class="modal-content">' +
            '  <div class="modal-header">' +
            '       <h4 class="modal-title main-heading" id="myModalLabel">FRAUD WARNINGS</h4>' +
            '       <h2 class="sub-heading">Last updated 6/15</h2>' +
            '       </div>' +
            '       <div class="modal-body fraud-notice-text">' +
            '          <p><b>NOTICE TO APPLICANTS:</b>  ANY PERSON WHO KNOWINGLY AND WITH INTENT TO DEFRAUD ANY INSURANCE COMPANY OR OTHER PERSON FILES AN APPLICATION FOR INSURANCE OR STATEMENT OF CLAIM CONTAINING ANY MATERIALLY FALSE INFORMATION OR, CONCEALS, FOR THE PURPOSE OF MISLEADING, INFORMATION CONCERNING ANY FACT MATERIAL THERETO, COMMITS A FRAUDULENT ACT, WHICH IS A CRIME AND MAY SUBJECT SUCH PERSON TO CRIMINAL AND CIVIL PENALTIES.</p>' +
            '          <p><b>NOTICE TO ALABAMA APPLICANTS:</b>  ANY PERSON WHO KNOWINGLY AND WITH INTENT TO DEFRAUD ANY INSURANCE COMPANY OR OTHER PERSON FILES AN APPLICATION FOR INSURANCE OR STATEMENT OF CLAIM CONTAINING ANY MATERIALLY FALSE INFORMATION OR, CONCEALS, FOR THE PURPOSE OF MISLEADING, INFORMATION CONCERNING ANY FACT MATERIAL THERETO, COMMITS A FRAUDULENT ACT, WHICH IS A CRIME AND MAY SUBJECT SUCH PERSON TO CRIMINAL AND CIVIL PENALTIES.</p>' +
            '          <p><b>NOTICE TO ARKANSAS, NEW MEXICO AND WEST VIRGINIA APPLICANTS:</b>  ANY PERSON WHO KNOWINGLY PRESENTS A FALSE OR FRAUDULENT CLAIM FOR PAYMENT OF A LOSS OR BENEFIT, OR KNOWINGLY PRESENTS FALSE INFORMATION IN AN APPLICATION FOR INSURANCE IS GUILTY OF A CRIME AND MAY BE SUBJECT TO FINES AND CONFINEMENT IN PRISON.</p>' +
            '          <p><b>NOTICE TO COLORADO APPLICANTS:</b>IT IS UNLAWFUL TO KNOWINGLY PROVIDE FALSE, INCOMPLETE, OR MISLEADING FACTS OR INFORMATION TO AN INSURANCE COMPANY FOR THE PURPOSE OF DEFRAUDING OR ATTEMPTING TO DEFRAUD THE COMPANY.  PENALTIES MAY INCLUDE IMPRISONMENT, FINES, DENIAL OF INSURANCE, AND CIVIL DAMAGES.  ANY INSURANCE COMPANY OR AGENT OF AN INSURANCE COMPANY WHO KNOWINGLY PROVIDES FALSE, INCOMPLETE, OR MISLEADING FACTS OR INFORMATION TO A POLICYHOLDER OR CLAIMANT FOR THE PURPOSE OF DEFRAUDING OR ATTEMPTING TO DEFRAUD THE POLICYHOLDER OR CLAIMANT WITH REGARD TO A SETTLEMENT OR AWARD PAYABLE FROM INSURANCE PROCEEDS SHALL BE REPORTED TO THE COLORADO DIVISION OF INSURANCE WITHIN THE DEPARTMENT OF REGULATORY AUTHORITIES.</p>' +
            '          <p><b>NOTICE TO DISTRICT OF COLUMBIA APPLICANTS:</b>WARNING:  IT IS A CRIME TO PROVIDE FALSE OR MISLEADING INFORMATION TO AN INSURER FOR THE PURPOSE OF DEFRAUDING THE INSURER OR ANY OTHER PERSON.  PENALTIES INCLUDE IMPRISONMENT AND/OR FINES.  IN ADDITION, AN INSURER MAY DENY INSURANCE BENEFITS IF FALSE INFORMATION MATERIALLY RELATED TO A CLAIM WAS PROVIDED BY THE APPLICANT.</p>' +
            '          <p><b>NOTICE TO FLORIDA APPLICANTS:</b>ANY PERSON WHO KNOWINGLY AND WITH INTENT TO INJURE, DEFRAUD, OR DECEIVE ANY INSURER FILES A STATEMENT OF CLAIM OR AN APPLICATION CONTAINING ANY FALSE, INCOMPLETE OR MISLEADING INFORMATION IS GUILTY OF A FELONY OF THE THIRD DEGREE.</p>' +
            '          <p><b>NOTICE TO KANSAS APPLICANTS:</b>ANY PERSON WHO KNOWINGLY AND WITH INTENT TO DEFRAUD, PRESENTS, CAUSES TO BE PRESENTED OR PREPARED WITH KNOWLEDGE OR BELIEF THAT IT WILL BE PRESENTED TO OR BY AN INSURER, PURPORTED INSURER, BROKER OR ANY AGENT THEREOF, ANY WRITTEN, ELECTRONIC, ELECTRONIC IMPULSE, FACSIMILE, MAGNETIC, ORAL, OR TELEPHONIC COMMUNICATION OR STATEMENT AS PART OF, OR IN SUPPORT OF, AN APPLICATION FOR THE ISSUANCE OF, OR THE RATING OF AN INSURANCE POLICY FOR PERSONAL OR COMMERCIAL INSURANCE, OR A CLAIM FOR PAYMENT OR OTHER BENEFIT PURSUANT TO AN INSURANCE POLICY FOR COMMERCIAL OR PERSONAL INSURANCE WHICH SUCH PERSON KNOWS TO CONTAIN MATERIAL FALSE INFORMATION CONCERNING ANY FACT MATERIAL THERETO; OR CONCEALS, FOR THE PURPOSE OF MISLEADING, INFORMATION CONCERNING ANY FACT MATERIAL THERETO COMMITS A FRAUDULENT INSURANCE ACT.</p>' +
            '          <p><b>NOTICE TO KENTUCKY APPLICANTS:</b>ANY PERSON WHO KNOWINGLY AND WITH INTENT TO DEFRAUD ANY INSURANCE COMPANY OR OTHER PERSON FILES AN APPLICATION FOR INSURANCE CONTAINING ANY MATERIALLY FALSE INFORMATION, OR CONCEALS FOR THE PURPOSE OF MISLEADING, INFORMATION CONCERNING ANY FACT MATERIAL THERETO, COMMITS A FRAUDULENT INSURANCE ACT, WHICH IS A CRIME.</p>' +
            '          <p><b>NOTICE TO LOUISIANA APPLICANTS:</b>ANY PERSON WHO KNOWINGLY PRESENTS A FALSE OR FRAUDULENT CLAIM FOR PAYMENT OF A LOSS OR BENEFIT OR KNOWINGLY PRESENTS FALSE INFORMATION IN AN APPLICATION FOR INSURANCE IS GUILTY OF A CRIME AND MAY BE SUBJECT TO FINES AND CONFINEMENT IN PRISON.</p>' +
            '          <p><b>NOTICE TO MAINE APPLICANTS:</b>IT IS A CRIME TO KNOWINGLY PROVIDE FALSE, INCOMPLETE OR MISLEADING INFORMATION TO AN INSURANCE COMPANY FOR THE PURPOSE OF DEFRAUDING THE COMPANY.  PENALTIES MAY INCLUDE IMPRISONMENT, FINES OR A DENIAL OF INSURANCE BENEFITS.</p>'+
            '          <p><b>NOTICE TO MARYLAND APPLICANTS:</b>ANY PERSON WHO KNOWINGLY OR WILLFULLY PRESENTS A FALSE OR FRAUDULENT CLAIM FOR PAYMENT OF A LOSS OR BENEFIT OR WHO KNOWINGLY OR WILLFULLY PRESENTS FALSE INFORMATION IN AN APPLICATION FOR INSURANCE IS GUILTY OF A CRIME AND MAY BE SUBJECT TO FINES AND CONFINEMENT IN PRISON.</p>' +
            '          <p><b>NOTICE TO MINNESOTA APPLICANTS:</b>A PERSON WHO FILES A CLAIM WITH INTENT TO DEFRAUD OR HELPS COMMIT A FRAUD AGAINST AN INSURER IS GUILTY OF A CRIME.</p>' +
            '          <p><b>NOTICE TO NEW JERSEY APPLICANTS:</b>ANY PERSON WHO INCLUDES ANY FALSE OR MISLEADING INFORMATION ON AN APPLICATION FOR AN INSURANCE POLICY IS SUBJECT TO CRIMINAL AND CIVIL PENALTIES.</p>' +
            '          <p><b>NOTICE TO NEW YORK APPLICANTS:</b>ANY PERSON WHO KNOWINGLY AND WITH INTENT TO DEFRAUD ANY INSURANCE COMPANY OR OTHER PERSON FILES AN APPLICATION FOR INSURANCE OR STATEMENT OF CLAIM CONTAINING ANY MATERIALLY FALSE INFORMATION, OR CONCEALS FOR THE PURPOSE OF MISLEADING, INFORMATION CONCERNING ANY FACT MATERIAL THERETO, COMMITS A FRAUDULENT INSURANCE ACT, WHICH IS A CRIME, AND SHALL ALSO BE SUBJECT TO A CIVIL PENALTY NOT TO EXCEED FIVE THOUSAND DOLLARS AND THE STATED VALUE OF THE CLAIM FOR EACH SUCH VIOLATION.</p>' +
            '          <p><b>NOTICE TO OHIO APPLICANTS:</b>ANY PERSON WHO, WITH INTENT TO DEFRAUD OR KNOWING THAT HE IS FACILITATING A FRAUD AGAINST AN INSURER, SUBMITS AN APPLICATION OR FILES A CLAIM CONTAINING A FALSE OR DECEPTIVE STATEMENT IS GUILTY OF INSURANCE FRAUD.</p>' +
            '          <p><b>NOTICE TO OKLAHOMA APPLICANTS:</b>WARNING:  ANY PERSON WHO KNOWINGLY, AND WITH INTENT TO INJURE, DEFRAUD OR DECEIVE ANY INSURER, MAKES ANY CLAIM FOR THE PROCEEDS OF AN INSURANCE POLICY CONTAINING ANY FALSE, INCOMPLETE OR MISLEADING INFORMATION IS GUILTY OF A FELONT (365:15-1-10, 36 § 3613.1).</p>' +
            '          <p><b>NOTICE TO OREGON APPLICANTS:</b>ANY PERSON WHO KNOWINGLY AND WITH INTENT TO DEFRAUD ANY INSURANCE COMPANY OR OTHER PERSON FILES AN APPLICATION FOR INSURANCE OR STATEMENT OF CLAIM CONTAINING ANY MATERIALLY FALSE INFORMATION OR, CONCEALS, FOR THE PURPOSE OF MISLEADING, INFORMATION CONCERNING ANY FACT MATERIAL THERETO, MAY BE GUILTY OF A FRAUDULENT ACT, WHICH MAY BE A CRIME AND MAY SUBJECT SUCH PERSON TO CRIMINAL AND CIVIL PENALTIES.</p>' +
            '          <p><b>NOTICE TO PENNSYLVANIA APPLICANTS:</b>ANY PERSON WHO KNOWINGLY AND WITH INTENT TO DEFRAUD ANY INSURANCE COMPANY OR OTHER PERSON FILES AN APPLICATION FOR INSURANCE OR STATEMENT OF CLAIM CONTAINING ANY MATERIALLY FALSE INFORMATION OR CONCEALS FOR THE PURPOSE OF MISLEADING, INFORMATION CONCERNING ANY FACT MATERIAL THERETO COMMITS A FRAUDULENT INSURANCE ACT, WHICH IS A CRIME AND SUBJECT SUCH PERSON TO CRIMINAL AND CIVIL PENALTIES.</p>' +
            '          <p><b>NOTICE TO TENNESSEE, VIRGINIA AND WASHINGTON APPLICANTS:</b>IT IS A CRIME TO KNOWINGLY PROVIDE FALSE, INCOMPLETE OR MISLEADING INFORMATION TO AN INSURANCE COMPANY FOR THE PURPOSE OF DEFRAUDING THE COMPANY.  PENALTIES INCLUDE IMPRISONMENT, FINES AND DENIAL OF INSURANCE BENEFITS.</p>' +
            '          <p><b>NOTICE TO VERMONT APPLICANTS:</b>ANY PERSON WHO KNOWINGLY PRESENTS A FALSE STATEMENT IN AN APPLICATION FOR INSURANCE MAY BE GUILTY OF A CRIMINAL OFFENSE AND SUBJECT TO PENALTIES UNDER STATE LAW.</p>' +
            '          <p>ALL INFORMATION HEREIN IS WARRANTED TO BE TRUE TO THE BEST OF MY KNOWLEDGE AND NO INFORMATION HAS BEEN SUPPRESSED OR WITHHELD, AND NO INSURER HAS CANCELLED OR REFUSED TO RENEW THIS INSURANCE.  I UNDERSTAND THAT THE INFORMATION HEREIN AND THE TRUTHFULNESS THEREOF WILL BE THE BASIS OF ANY INSURANCE PROVIDED BY AIG AEROSPACE INSURANCE SERVICES, INC.  <b>THIS APPLICATION DOES NOT BIND THE APPLICANT OR THE COMPANY TO PROVIDE ANY INSURANCE.</b></p>' +
            '       </div>' +
            '       <div class="modal-footer">' +
            '       <a class="go-to-aig-btn" data-dismiss="modal">Back to Application</a>' +
            '       </div>' +
            '       </div>' +
            '       </div>' +
            '       </div>',
            controller: function ($scope) {
                $scope.fraudNoticePopup = function (attrs) {
                    $('#fraudNotice').modal({backdrop: 'static', keyboard: false})
                }
            }
        }
    })
    .directive('privacyPolicy', function () {
        return {
            restrict: 'E',
            replace: true,
            template: '<div class="modal fade form-box" id="privacyPolicy" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">' +
            '<div class="modal-dialog" role="document">'+
            '   <div class="modal-content">' +
            '  <div class="modal-header">' +
            '       <h4 class="modal-title main-heading" id="myModalLabel">Privacy Policy</h4>' +
            '       </div>' +
            '       <div class="modal-body">' +
            '          <object data="docs/UE1524(09-16) Privacy.pdf" type="application/pdf" style="width:1065px; height:100%;">alt : <a href="docs/UE1524(09-16) Privacy.pdf">Privacy Policy PDF</a></object>' +
            '       </div>' +
            '       <div class="modal-footer">' +
            '       <a class="go-to-aig-btn" data-dismiss="modal">Back to Application</a>' +
            '       </div>' +
            '       </div>' +
            '       </div>' +
            '       </div>',
            controller: function ($scope) {
                $scope.privacyPolicyPopup = function (attrs) {
                    $('#privacyPolicy').modal({backdrop: 'static', keyboard: false})
                }
            }
        }
    })
    .directive('serviceError', function () {
        return {
            restrict: 'E',
            replace: true,
            template: '<div class="modal fade form-box" id="serviceErrorModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">' +
            '<div class="modal-dialog" role="document">'+
            '   <div class="modal-content">' +
            '  <div class="modal-header">' +
            '       <h4 class="modal-title main-heading" id="myModalLabel">We are Sorry</h4>' +
            '       </div>' +
            '       <div class="modal-body">' +
            '          <h2 class="sub-heading">An error occurred while processing. Please try again later.</h2>' +
            '       </div>' +
            '       <div class="modal-footer">' +
            '       <a class="go-to-aig-btn" href="http://www.aig.com/business/insurance/specialty/unmanned-aircraft-solutions">Go to AIG.COM</a>' +
            '       </div>' +
            '       </div>' +
            '       </div>' +
            '       </div>',
            controller: function ($scope) {
                // $('#ageRejectModal').modal({backdrop: 'static', keyboard: false})
            }
        }
    })
    .directive("restricteddate", function () {
      return {
        restrict: "A",
        require: "ngModel",
        link: function (scope, elem, attrs, ngModelCtrl) {
          var updateModel = function (dateText) {
            scope.$apply(function () {
              ngModelCtrl.$setViewValue(dateText);
            });
          };
          var options = {
            dateFormat: "mm/dd/yy",
            minDate: -0,
            onSelect: function (dateText) {
              updateModel(dateText);
            }
          };
          elem.datepicker(options);
        }
      }
    })
    .directive("yearrestricteddate", function () {
      return {
        restrict: "A",
        require: "ngModel",
        link: function (scope, elem, attrs, ngModelCtrl) {
          var updateModel = function (dateText) {
            scope.$apply(function () {
              ngModelCtrl.$setViewValue(dateText);
            });
          };
          var options = {
            dateFormat: "mm/dd/yy",
            minDate: -0,
            maxDate: 365,
            onSelect: function (dateText) {
              updateModel(dateText);
            }
          };
          elem.datepicker(options);
        }
      }
    })
    .directive("anydate", function () {
      return {
        restrict: "A",
        require: "ngModel",
        link: function (scope, elem, attrs, ngModelCtrl) {
          var updateModel = function (dateText) {
            scope.$apply(function () {
              ngModelCtrl.$setViewValue(dateText);
            });
          };
          var options = {
            dateFormat: "mm/dd/yy",
            onSelect: function (dateText) {
              updateModel(dateText);
            }
          };
          elem.datepicker(options);
        }
      }
    })
    .directive("nofuturedate", function () {
      return {
        restrict: "A",
        require: "ngModel",
        link: function (scope, elem, attrs, ngModelCtrl) {
          var updateModel = function (dateText) {
            scope.$apply(function () {
              ngModelCtrl.$setViewValue(dateText);
            });
          };
          var options = {
            dateFormat: "mm/dd/yy",
            maxDate: 0,
            onSelect: function (dateText) {
              updateModel(dateText);
            }
          };
          elem.datepicker(options);
        }
      }
    })
    .directive('noSpecialChar', function() {
        return {
          require: 'ngModel',
          restrict: 'A',
          link: function(scope, element, attrs, modelCtrl) {
            modelCtrl.$parsers.push(function(inputValue) {
              if (inputValue == null)
                return ''
              cleanInputValue = inputValue.replace(/[^\w\s]/gi, '');
              if (cleanInputValue != inputValue) {
                modelCtrl.$setViewValue(cleanInputValue);
                modelCtrl.$render();
              }
              return cleanInputValue;
            });
          }
        }
    })
    .directive("regExInput", function(){
        "use strict";
        return {
            restrict: "A",
            require: "?regEx",
            scope: {},
            replace: false,
            link: function(scope, element, attrs, ctrl){
              element.bind('keypress', function (event) {
                var regex = new RegExp(attrs.regEx);
                var key = String.fromCharCode(!event.charCode ? event.which : event.charCode);
                if (!regex.test(key)) {
                   event.preventDefault();
                   return false;
                }
              });
            }
        };
    })
    .directive("scroll", function ($window) {
        return function(scope, element, attrs) {
            angular.element($window).bind("scroll", function() {
                if (this.pageYOffset <= 187) {
                    angular.element(element).removeClass('sticky');
                 } else {
                    angular.element(element).addClass('sticky');
                 }
                scope.$apply();
            });
        };
    });