angular.module('App.utility', [])

    .factory('mailAPI', ['$http', function($http) {


        var fetchtoken = function(successCallback, failureCallback) {
            var request = $http({
                method: "POST",
                url: 'https://cs2.salesforce.com/services/oauth2/token',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                },
                data: 'grant_type=password&client_id=3MVG9Iu66FKeHhINs8qzEqczV95Dd4.QorqkdIaICNGArC6X7nEsmmmMkruLzB_ClG5Avcqabp.gKSaUOlku1&client_secret=8846274163957919445&username=sendemail.attachment@aig.com&password=Work4Aig8ARAmKhP8A0PuumPEvo5LMKv'
            });
            request.then(successCallback, failureCallback);
        };

        var sendMail = function(mailObj, token, successCallback, failureCallback) {

            var request = $http({
                method: "POST",
                url: 'https://cs2.salesforce.com/services/apexrest/SendEmailAttachments',
                headers: {
                    'Authorization': 'Bearer ' + token,
                    'Content-Type': 'application/json'
                },
                data: mailObj
            });
            request.then(successCallback, failureCallback);
        };

        // expose a public API
        return {
            getOauthToken: fetchtoken,
            sendMail: sendMail
        };
    }])

    .factory('PremiumRanges', ['$http', function($http) {
        var fetchRanges = function(getResult, AccessToken, successCallback, failureCallback) {

            var request = $http({
                method: "POST",
                url: 'https://cs2.salesforce.com/services/apexrest/DroneQuoteRange/ ',
                headers: {
                    'Authorization': 'Bearer ' + AccessToken,
                    'Content-Type': 'application/json'
                },
                data: getResult
            });
            request.then(successCallback, failureCallback);
        };

        // expose a public API
        return {
            fetchRanges: fetchRanges
        };
    }])

    .factory('getBrokerList',['$http','oAuthToken',function($http,oAuthToken){
        var brokerList = function(successCallback, failureCallback){
            //$http.get("data/dummy-broker-info.json").success(callback);
            var request = $http({
                method: "GET",
                url: 'https://cs2.salesforce.com/services/apexrest/GetBrokerInfo',
                headers: {
                    'Authorization': 'Bearer ' + oAuthToken.token,
                    'Content-Type': 'application/json'
                },
            });
            request.then(successCallback, failureCallback);
        };

        var broker = function(code,successCallback, failureCallback){
            //$http.get("data/dummy-broker-info.json").success(callback);
           var brokercode = {"brokerCode":code}
            var request = $http({
                method: "POST",
                url: 'https://cs2.salesforce.com/services/apexrest/GetBrokerInfo',
                headers: {
                    'Authorization': 'Bearer ' + oAuthToken.token,
                    'Content-Type': 'application/json'
                },
                data: brokercode
            });
            request.then(successCallback, failureCallback);
        };

        return{
            brokerList:brokerList,
            broker:broker
        }
    }])

    .factory('getUSdata',['$http','oAuthToken',function($http,oAuthToken){
        var stateList = function(callback){
            $http.get("data/us_state.json").success(callback);

        };

        var discriminal = function(successCallback, failureCallback){
             var request = $http({
                 method: "GET",
                 url: 'https://cs2.salesforce.com/services/apexrest/GetStatesList',
                 headers: {
                     'Authorization': 'Bearer ' + oAuthToken.token,
                     'Content-Type': 'application/json'
                 },
             });
             request.then(successCallback, failureCallback);
        }
        var countryList = function(callback){
            $http.get("data/us_country.json").success(callback);
        };
        return{
            stateList:stateList,
            countryList:countryList,
            discriminal:discriminal
        }
    }])

    .factory('getEndosements',['$http',function($http){
        var endoList = function(callback){
            $http.get("data/endorsements/endorsements.json").success(callback);
        };
        return{
            endoList:endoList
        }
    }])

    .factory('helpTextService',['$http',function($http){
        return{
            flyingHours:"List the # of hours of experience in flying unmanned aircraft.",
            IMexp : "List the # of hours of experience in flying the unmanned aircraft to be insured.",
            certPilot:"Have you obtained your remote pilot certificate with sUAS rating?",
            formalTraining:"Have you attended any third party unmanned aircraft training program(either web or classroom based) that included sections on topics such as flight planning, air traffic control, weather and general best operating practices?",
            MfdTraining:"Have you attended a training program  conducted by or thru the manufacturer of the one or more of the aircraft to be insured?",
            WarLiability:"What is war liability coverage?- Standard policies do not provide coverage for losses due to war, hostilities, malicious acts and other events that may result in an aircraft loss. The purchase of war liability expands coverage to protect against such exposures.",
            CivilTwilight:"Civil twilight is 3 minutes before official sunrise to  30 minutes after sunset, local time."
            }
    }])


