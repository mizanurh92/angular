'use strict';

var App = angular.module('App', ['ngRoute', 'duScroll', 'App.utility', 'App.Validation', 'App.widget', 'ngSanitize']);

App.config(function($routeProvider) {
    $routeProvider
        .when("/", {
            templateUrl: "views/dashboard.html"
        });
});

App.value('duScrollDuration', 1100)
App.value('duScrollOffset', 150)
App.value('HTMLtoPDFobj', {
    finalObj: ''
})
App.value('oAuthToken', {
    token: ''
})

