var mongoose = require('mongoose');

module.exports = mongoose.connect('User',{
    email : string,
    password: string
})