var express = require('express');
var cors = require('cors');
var mongoose = require('mongoose');
var bodyParser = require('body-parser');
var app = express();

var posts = [
  {message: 'Hello'},
  {message: 'Hi'}
];

app.use(cors());
app.use(bodyParser.json());

app.get('/posts' , (req,res) =>{
    res.send(posts);
})

app.post('/register' , (req,res) =>{
    var userData = req.body;
    var user = new user(userData)

    user.save((err, result) =>{
        if(!err) {
            console.log("server is connected");
        }
        res.sendStatus(200);
    })
   
})

app.post('/login' , async (req,res) =>{
    var userData = req.body;
    var user = await User.findOne({email: userData.email});
    console.log(user)
    res.sendStatus(200);
    
   
})

mongoose.connect('mongodb://test:test@ds121599.mlab.com:21599/messageboard' , (err) =>{
    if(!err) {
        console.log("server is connected");
    }
})
app.listen(3000);