import { Component, OnInit } from '@angular/core';
import { ApiService } from '../api.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent {
  loginData = {}
  
  constructor(private apiService:ApiService){}

  post(){
    this.apiService.loginUser(this.loginData);
  }
  
}
