import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpModule } from "@angular/http";
import {MatButtonModule, MatCardModule, MatToolbarModule} from '@angular/material';
import { RouterModule } from '@angular/router';
import { AppComponent } from './app.component';
import { ApiService } from './api.service';
import { MessagesComponent } from './messages/messages.component';
import { RegisterComponent } from './register/register.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {MatInputModule} from '@angular/material/input';
import { FormsModule } from '@angular/forms';
import { LoginComponent } from './login/login.component';
const routes = [
  {
    path:"register", component:RegisterComponent
  },
  {
    path:"login", component:LoginComponent
  }
]
@NgModule({
  declarations: [
    AppComponent,
    MessagesComponent,
    RegisterComponent,
    LoginComponent
  ],
  imports: [
    BrowserModule,
    HttpModule, MatButtonModule, MatCardModule, MatToolbarModule, MatInputModule, BrowserAnimationsModule,
     RouterModule.forRoot(routes), FormsModule
  ],
  providers: [ApiService],
  bootstrap: [AppComponent]
})
export class AppModule { }
