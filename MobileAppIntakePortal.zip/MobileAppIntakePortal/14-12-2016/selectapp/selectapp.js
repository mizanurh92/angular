'use strict';

angular.module('myApp.selectapp', ['ngRoute', 'myApp.utility'])

.config(['$routeProvider', function($routeProvider) {
     $routeProvider.when('/selectapp', {
          templateUrl: 'selectapp/selectapp.html',
          controller: 'selectappCtrl'
     });
}])

.value('datatoBind', {
     selectApp: '',
     createApp: '',
     choosefeature: '',
     selectBackend: '',
     chooseOS: ''
})

.controller('selectappCtrl', ['$scope', 'datatoBind', function($scope, datatoBind) {
     if (localStorage.userid) {
          $scope.isAppSelected = true;
          $scope.typeofapplication = ['Smartphone', 'Tablet'];
          $scope.fn_selectApp = function() {
               if ($scope.selection.length != 0) {
                    $scope.isAppSelected = true;
                    datatoBind.selectApp = $scope.selection;
                    localStorage.selectApp = $scope.selection;
                    location.href = '#!/createapp';
               } else {
                    $scope.isAppSelected = false;
               }
          }

          $scope.selection = [];
          $scope.toggleSelection = function(type) {
               var idx = $scope.selection.indexOf(type);
               // is currently selected
               if (idx > -1) {
                    $scope.selection.splice(idx, 1);
               }
               // is newly selected
               else {
                    $scope.selection.push(type);
               }
               $scope.DeviceType = $scope.selection.toString();
               if ($scope.selection.length > 0) {
                    $scope.IsChecked = true;
               } else {
                    $scope.IsChecked = true;
               }


          };
          $scope.backButton = function() {
               history.back();
          }

          $scope.goToHome = function() {
               location.href = '#!/view2';
          }
     } else {
          location.href = '#!/login';
     }
}])
