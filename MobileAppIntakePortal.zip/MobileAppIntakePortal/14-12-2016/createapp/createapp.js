'use strict';

angular.module('myApp.createapp', ['ngRoute', 'myApp.utility'])

.config(['$routeProvider', function($routeProvider) {
     $routeProvider.when('/createapp', {
          templateUrl: 'createapp/createapp.html',
          controller: 'createappCtrl'
     });
}])

.controller('createappCtrl', ['$scope', 'datatoBind', function($scope, datatoBind) {
     if (localStorage.createApp) {
          $scope.latest_app_name = JSON.parse(localStorage.createApp).app_Name;
     }
     if (localStorage.createApp) {
          $scope.latest_app_owner = JSON.parse(localStorage.createApp).app_owner;
     }
     if (localStorage.createApp) {
          $scope.latest_Description = JSON.parse(localStorage.createApp).Description;
     }

     if (localStorage.userid) {
     $scope.isApp = true;
     $scope.fn_createApp = function(valid, obj) {
          if (valid) {
               $scope.isApp = true;
               datatoBind.createApp = obj;
                    localStorage.createApp = JSON.stringify(obj);
               location.href = '#!/choosefeature';
          } else {
               $scope.isApp = false;
          }
     }

     $scope.goToHome = function() {
          location.href = '#!/view2';
     }

     $scope.backButton = function() {
          history.back();
     }
     } else {
          location.href = '#!/login';
     }
}])
