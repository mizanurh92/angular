'use strict';

angular.module('myApp.preview', ['ngRoute', 'myApp.utility'])

.config(['$routeProvider', function ($routeProvider) {
	$routeProvider.when('/preview', {
		templateUrl: 'preview/preview.html',
		controller: 'previewCtrl'
	});
}])

.controller('previewCtrl', ['$scope', 'datatoBind', 'MAIPSer', 'UserService', 'setFlag', function($scope, datatoBind, MAIPSer, UserService, setFlag) {
     if (localStorage.userid) {
          $scope.AppObj = JSON.parse(localStorage.createApp);
          $scope.appDescription = $scope.AppObj.Description;
          $scope.appName = $scope.AppObj.app_Name;
          $scope.appFeature = localStorage.choosefeature;
          $scope.appbackEnd = localStorage.selectBackend;
          $scope.appOS = localStorage.chooseOS;
          $scope.appDevicetype = localStorage.selectApp;

	/********** WRITE SERVICE CODE************/
	var osObj = '';
	var featObj = '';
	var selAppObj = '';
	var selBackObj = '';
	

    var mailObj = "<!DOCTYPE html><html><head><style type='text/css' media='print'>body {font-family: sans-serif;color: #585761;font-size: 12px;}table {width: 500px;border-top: 1px solid #a09e9e;border-right: 1px solid #a09e9e;}table tr td {border-left: 1px solid #a09e9e;border-bottom: 1px solid #a09e9e;padding: 8px;}</style></head><table width='100%' cellpadding='0' cellspacing='0'><tr><td align='left' width='35%'><b>Application Description :</b></td><td align='left'>" + $scope.appDescription + "</td></tr><tr><td align='left'><b>Application Features :</b></td><td align='left'>" + $scope.appFeature + "</td></tr><tr><td align='left'><b>Backend Needs :</b></td><td align='left'>" + $scope.appbackEnd + "</td></tr><tr><td align='left'><b>Operating System :</b></td><td align='left'>" + $scope.appOS + "</td></tr><tr><td align='left'><b>Device Type :</b></td><td align='left'>" + localStorage.selectApp + "</td></tr></table></body></html>";
//	console.log(mailObj)
	var mail = {}
	MAIPSer.getDefaultUser(function (resp) {
		for (var i = 0; i < resp.data.length; i++) {

			mail = {
      //  "email_addresses": resp.data[i].user_email,
        "email_addresses": "Prathamesh.Rudrakshawar@aig.com",
				"subject": "Digital Market New Mobile App Request",
				"body": mailObj
			}
//                    if (setFlag.pageRefresh == true) {
//                         $scope.mailFun(mail)
//                    }
		}


	}, function (resp) {

	})


          var saveObj = {};
          saveObj = {
               "app_type": localStorage.selectApp.toString(),
               "app_name": JSON.parse(localStorage.createApp).app_Name,
               "app_owner_name": JSON.parse(localStorage.createApp).app_owner,
               "app_description": JSON.parse(localStorage.createApp).Description,
               "app_features": localStorage.choosefeature.toString(),
               "app_backend": localStorage.selectBackend.toString(),
               "app_os": localStorage.chooseOS.toString(),
               "user_id": localStorage.userid,
               "status": "1"
          }
          var adduser = JSON.parse(localStorage.usernames);
         
          if (setFlag.pageRefresh == true) {
               MAIPSer.saveData(saveObj, function(resp) {
                    console.log("Data have saved succesfully");
                   //mail service start
                    console.log()         
 
                    for(var i=0; i<adduser.length; i++){
                        var object = [{
                                   "app_id": parseInt(resp.data.value),
                                   "user_name": adduser[i].user_name,
                                   "user_email": adduser[i].user_email
                              }]
                         MAIPSer.addUser(object, function(resp) {
                                   console.log(resp)
                                   console.log("User Added");
                              }, function(resp) {
                                   console.log(resp)
                                   console.log("Failed to add")
                              })
                       
                    }
                    
                    MAIPSer.sendMail(mail, function(resp) {
                         console.log("Mail has been sent successfully.")
                    }, function(resp) {
                         console.log("Mail not sent.")
                    })
              
          
                   //mail service end
                   
               }, function(resp) {
                    console.log("Data failed to save");
               })
          }


	/******************************************/



	$scope.fn_preview = function () {
		location.href = '#!/view2';
	}
    }else{
       location.href = '#!/login';
   }

}])