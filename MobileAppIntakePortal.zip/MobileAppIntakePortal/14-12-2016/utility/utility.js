'use strict';
angular.module('myApp.utility', [])

.factory('MAIPSer', ['$http', function($http) {

     var loginUser = function(userid, successCallback, failureCallback) {

          var request = $http({
               method: "POST",
               url: 'http://ec2-35-164-48-176.us-west-2.compute.amazonaws.com:8080/mobileappintake/maip/loginuser',
               headers: {
                    'Content-Type': 'application/json'
               },
               data: userid
          });
          request.then(successCallback, failureCallback);
     };
     var getData = function(userid, successCallback, failureCallback) {
          console.log(userid)
          var request = $http({
               method: "POST",
               url: 'http://ec2-35-164-48-176.us-west-2.compute.amazonaws.com:8080/mobileappintake/maip/getappsofuser',
               headers: {
                    'Content-Type': 'application/json'
               },
               data: userid
          });
          request.then(successCallback, failureCallback);
     };
     var getParticularData = function(userid, successCallback, failureCallback) {

          var request = $http({
               method: "POST",
               url: 'http://ec2-35-164-48-176.us-west-2.compute.amazonaws.com:8080/mobileappintake/maip/getappdetails',
               headers: {
                    'Content-Type': 'application/json'
               },
               data: userid
          });
          request.then(successCallback, failureCallback);
     };
     var getDefaultUser = function(successCallback, failureCallback) {

          var request = $http({
               method: "GET",
               url: 'http://ec2-35-164-48-176.us-west-2.compute.amazonaws.com:8080/mobileappintake/maip/getdefaultusers',
          });
          request.then(successCallback, failureCallback);
     };
     var sendMail = function(mailObj, successCallback, failureCallback) {

          var request = $http({
               method: "POST",
               url: 'http://ec2-35-164-48-176.us-west-2.compute.amazonaws.com:8080/mobileappintake/maip/sendmail',
               headers: {
                    'Content-Type': 'application/json'
               },
               data: mailObj
          });
          request.then(successCallback, failureCallback);
     };

     var saveData = function(Obj, successCallback, failureCallback) {

          var request = $http({
               method: "POST",
               url: 'http://ec2-35-164-48-176.us-west-2.compute.amazonaws.com:8080/mobileappintake/maip/addappdetails',
               headers: {
                    'Content-Type': 'application/json'
               },
               data: Obj
          });
          request.then(successCallback, failureCallback);
     };

     var addUser = function(Obj, successCallback, failureCallback) {
          var request = $http({
               method: "POST",
               url: 'http://ec2-35-164-48-176.us-west-2.compute.amazonaws.com:8080/mobileappintake/maip/adduser',
               headers: {
                    'Content-Type': 'application/json'
               },
               data: Obj
          });
          request.then(successCallback, failureCallback);
     };
    
     var getUser = function(Obj, successCallback, failureCallback) {
         var object = {"app_id":Obj}
          var request = $http({
               method: "POST",
               url: 'http://ec2-35-164-48-176.us-west-2.compute.amazonaws.com:8080/mobileappintake/maip/getusersofapp',
               headers: {
                    'Content-Type': 'application/json'
               },
               data: object
          });
          request.then(successCallback, failureCallback);
     };
     var removeUser = function(appid, emailid, successCallback, failureCallback) {
         var object = [{"app_id":appid,"user_email":emailid}];
          var request = $http({
               method: "POST",
               url: 'http://ec2-35-164-48-176.us-west-2.compute.amazonaws.com:8080/mobileappintake/maip/deleteuser',
               headers: {
                    'Content-Type': 'application/json'
               },
               data: object
          });
          request.then(successCallback, failureCallback);
     };
     return {
          loginUser: loginUser,
          getData: getData,
          getParticularData: getParticularData,
          getDefaultUser: getDefaultUser,
          sendMail: sendMail,
          saveData: saveData,
          addUser: addUser,
          getUser:getUser,
          removeUser:removeUser
     };
}]);
