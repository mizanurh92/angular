'use strict';

angular.module('myApp.view2', ['ngRoute', 'myApp.utility'])

.config(['$routeProvider', function($routeProvider) {
          $routeProvider.when('/view2', {
               templateUrl: 'view2/view2.html',
               controller: 'View2Ctrl'
          });
     }])
     .value('setFlag', {
          pageRefresh: ''
     })

.controller('View2Ctrl', ['$scope', 'MAIPSer', 'UserService', 'setFlag', '$rootScope', function($scope, MAIPSer, UserService, setFlag, $rootScope) {
     setFlag.pageRefresh = true;
     if (localStorage.userid) {
          $scope.NoData = true;
          $scope.HaveData = true;
          var userID = {
               "user_id": localStorage.userid
          }

          $scope.topusername = localStorage.userid;

          $scope.logout = function() {
               localStorage.userid = null;
               location.href = '#!/login';
          }

          $scope.sendBuildMail = function() {

               console.log("Sending Release mail!");


               var buildMailObj = "<!DOCTYPE html><html><head><style type='text/css' media='print'>body {font-family: sans-serif;color: #585761;font-size: 12px;}table {width: 500px;border-top: 1px solid #a09e9e;border-right: 1px solid #a09e9e;}table tr td {border-left: 1px solid #a09e9e;border-bottom: 1px solid #a09e9e;padding: 8px;}</style></head><table width='100%' cellpadding='0' cellspacing='0'><tr><td align='left' width='35%'><b>Application Name :</b></td><td align='left'>" + $scope.individualArr[0].app_name + "</td></tr><tr><td align='left' width='35%'><b>Applicaion Description :</b></td><td align='left'>" + $scope.individualArr[0].app_description + "</td></tr><tr><td align='left'><b>Application Features :</b></td><td align='left'>" + $scope.individualArr[0].app_features + "</td></tr><tr><td align='left'><b>Backend Needs :</b></td><td align='left'>" + $scope.individualArr[0].app_backend + "</td></tr><tr><td align='left'><b>Operating System :</b></td><td align='left'>" + $scope.individualArr[0].app_os + "</td></tr><tr><td align='left'><b>Device Type :</b></td><td align='left'>" + $scope.individualArr[0].app_type + "</td></tr>";
               if (document.getElementById("iOS").checked == true) {
                    buildMailObj = buildMailObj + "<tr><td align='left'><b>iOS Release Build Version:</b></td><td align='left'>" + VIos + "</td></tr>";
               }
               if (document.getElementById("Android").checked == true) {
                    buildMailObj = buildMailObj + "<tr><td align='left'><b>Android Release Build Version:</b></td><td align='left'>" + VAndroid + "</td></tr>";
               }
               buildMailObj = buildMailObj + "</table></body></html>";


               var mail = {}
               MAIPSer.getDefaultUser(function(resp) {
                    for (var i = 0; i < resp.data.length; i++) {

                         mail = {
                              //     "email_addresses": resp.data[i].user_email,
                              "email_addresses": "Prathamesh.Rudrakshawar@aig.com",
                              "subject": "Digital Market New Mobile App Request",
                              "body": buildMailObj
                         }

                         $scope.mailFun(mail)

                    }


               }, function(resp) {

               })


               $scope.mailFun = function(mail) {
                    MAIPSer.sendMail(mail, function(resp) {
                         console.log("Mail has been sent successfully.")
                    }, function(resp) {
                         console.log("Mail not sent.")
                    })
               }

          }


          $scope.AlluserDataArr = [];
          MAIPSer.getData(userID, function(resp) {
                    if (resp.data.length != 0) {
                         for (var i = 0; i < resp.data.length; i++) {
                              var appid = {
                                        "app_id": resp.data[i].app_id
                                   }
                                   /************ USER Detail Service start *************/
                              MAIPSer.getParticularData(appid, function(response) {
                                   $scope.AlluserDataArr.push({
                                        "app_id": response.data.app_id,
                                        "app_name": response.data.app_name,
                                        "app_backend": response.data.app_backend,
                                        "app_description": response.data.app_description,
                                        "app_features": response.data.app_features,
                                        "app_os": response.data.app_os,
                                        "app_owner_name": response.data.app_owner_name,
                                        "app_type": response.data.app_type,
                                        "date_created": response.data.date_created,
                                        "date_updated": response.data.date_updated,
                                        "status": response.data.status,
                                        "user_id": response.data.user_id

                                   });
                                   $scope.AlluserDataArrUserLength = $scope.AlluserDataArr.length;

                                   function mycomparator(a, b) {
                                        return parseInt(a.app_id, 10) - parseInt(b.app_id, 10);
                                   }
                                   $scope.AlluserDataArr.sort(mycomparator);
                                   $scope.showDetailView('u2', $scope.AlluserDataArr[$scope.AlluserDataArr.length - 1])
                                   $scope.HaveData = false;
                              })

                              /************ USER Detail Service End *************/



                         }
                    } else {
                         $scope.NoData = false;
                         $scope.HaveData = true;
                    }
               })
               /*************************Default User Service start *******************/
          $scope.defaultUserArr = [];
          $scope.appuserslength = 0;
          MAIPSer.getDefaultUser(function(resp) {
               for (var k = 0; k < resp.data.length; k++) {
                    $scope.defaultUserArr.push({
                         "app_id": resp.data[k].app_id,
                         "user_email": resp.data[k].user_email,
                         "user_name": resp.data[k].user_name
                    })
               }

               $scope.appuserslength = $scope.defaultUserArr.length;
          })

          /*************************Default User Service End *******************/

          $scope.showDetailView = function(flag, param) {
               $scope.individualArr = [];
               if (flag == 'u1') {
                    for (var i = 0; i < $scope.AlluserDataArr.length; i++) {
                         if ($scope.AlluserDataArr[i].app_id == param) {
                              $scope.individualArr.push({
                                   "app_id": $scope.AlluserDataArr[i].app_id,
                                   "app_name": $scope.AlluserDataArr[i].app_name,
                                   "app_backend": $scope.AlluserDataArr[i].app_backend,
                                   "app_description": $scope.AlluserDataArr[i].app_description,
                                   "app_features": $scope.AlluserDataArr[i].app_features,
                                   "app_os": $scope.AlluserDataArr[i].app_os,
                                   "app_owner_name": $scope.AlluserDataArr[i].app_owner_name,
                                   "app_type": $scope.AlluserDataArr[i].app_type,
                                   "date_created": $scope.AlluserDataArr[i].date_created,
                                   "date_updated": $scope.AlluserDataArr[i].date_updated,
                                   "status": $scope.AlluserDataArr[i].status,
                                   "user_id": $scope.AlluserDataArr[i].user_id

                              })
                              var allOs = $scope.AlluserDataArr[i].app_os;
                              var eOs = allOs.split(",");
                              var len = eOs.length;
                              $scope.osList = [];
                              for (var j = 0; j < len; j++) {
                                   $scope.osList.push(eOs[j])
                              }
                         }
                    }
                    $scope.getUserData = [];
                                    MAIPSer.getUser(param,function(response){
                                  var data = response.data;
                                  if(data.length > 0){
                                      $scope.noData = false;
                                     for(var i=0; i<data.length; i++){
                                         $scope.getUserData.push({
                                             "app_id":data[i].app_id,
                                             "user_email":data[i].user_email,
                                             "user_name":data[i].user_name
                                         })
                                     }
                                  }
                                        else{
                                            $scope.noData = true;
                                        }
                              })
                   
                   
               } else {
                    $scope.individualArr.push({
                         "app_id": param.app_id,
                         "app_name": param.app_name,
                         "app_backend": param.app_backend,
                         "app_description": param.app_description,
                         "app_features": param.app_features,
                         "app_os": param.app_os,
                         "app_owner_name": param.app_owner_name,
                         "app_type": param.app_type,
                         "date_created": param.date_created,
                         "date_updated": param.date_updated,
                         "status": param.status,
                         "user_id": param.user_id
                    })
                    var allOs = param.app_os;
                    var eOs = allOs.split(",");
                    var len = eOs.length;
                    $scope.osList = [];
                    for (var j = 0; j < len; j++) {
                         $scope.osList.push(eOs[j])
                    }

               }
          }
   
          
          $scope.clickToOpen = function() {
               $scope.checkedValue = []; 
               $scope.vNo=[];
               var inputElements=[];
               $scope.Vnum='';
               $scope.Vnum1='';
               $scope.Vnum2='';              
              
               inputElements = document.getElementsByClassName('messageCheckbox');
               for(var i=0; inputElements[i]; ++i){
                     if(inputElements[i].checked){
                         $scope.checkedValue.push(inputElements[i].name)

                     }
               }
               console.log($scope.checkedValue)
                if($scope.checkedValue.length=='1'){
                    if($scope.checkedValue[0] == 'iOS'){
                         $scope.Vnum=$("#iOS > div >input").val();
                         document.getElementById("releaseBuild").disabled = false;
                    }
                    if($scope.checkedValue[0] == 'Android'){
                         $scope.Vnum=$("#Android > div >input").val();
                         document.getElementById("releaseBuild").disabled = false;
                    }
                }
                if($scope.checkedValue.length=='2'){
                         $scope.Vnum1=$("#iOS > div >input").val();
                         $scope.Vnum2=$("#Android > div >input").val();
                         document.getElementById("releaseBuild").disabled = false;
                }
               $('#popupmodal').modal({backdrop: 'static', keyboard: false});
               $rootScope.$broadcast('selectedOs', {
                              someProp: $scope.checkedValue,
                              pro1:$scope.Vnum, 
                              pro2:$scope.Vnum1,
                              pro3:$scope.Vnum2 // send whatever you want
                         });
          }
          $scope.adduserpopup = function(id) {
               $rootScope.appid = id;
               $('#adduserpopup').modal({
                    backdrop: 'static',
                    keyboard: false
               });
          }
          $scope.activeClass = function(param) {
               var ef = document.getElementsByClassName("selectedLi");
               for (var i = 0; i < ef.length; i++) {
                    ef[i].className = '';
               }
               var el = document.getElementsByClassName("MyClass");
               for (var i = 0; i < el.length; i++) {
                    el[i].className = '';
               }
               var newId = "USER_" + param;
               document.getElementById(newId).className = "MyClass";
          }
          $scope.selection0 = [];
          $scope.toggleSelection0 = function toggleSelection(eachOS) {
               var idx = $scope.selection0.indexOf(eachOS);

               // is currently selected
               if (idx > -1) {
                    $scope.selection0.splice(idx, 1);
               }

               // is newly selected
               else {
                    $scope.selection0.push(eachOS);
               }
               $scope.selectedOs = $scope.selection0.toString();
               var inputElements1=[];
               var checkedValue1 = [];
               inputElements1 = document.getElementsByClassName('messageCheckbox');
                   for(var i=0; inputElements1[i]; ++i){
                     if(inputElements1[i].checked){
                         checkedValue1.push(inputElements1[i].name)

                     }
               }
               if(checkedValue1.length>0){            
                    if(checkedValue1.length=='1'){
                         if(checkedValue1[0] == 'iOS'){ 
                              $scope.stoppedTyping=function(){
                                   var textarea_value = document.getElementById("1_0").value;
                                  if(textarea_value.length > 0) { 
                                   document.getElementById('releaseBuild').disabled = false; 
                                   } else { 
                                        document.getElementById('releaseBuild').disabled = true;
                                   } 
                              }
                              
                         }
                         if(checkedValue1[0] == 'Android'){
                              $scope.stoppedTyping=function(){
                                   var textarea_value = document.getElementById("1_1").value;
                                   if(textarea_value.length > 0) { 
                                   document.getElementById('releaseBuild').disabled = false;

                                   } else { 
                                        document.getElementById('releaseBuild').disabled = true;
                                   }
                              }
                         }
                     }
                    if(checkedValue1.length=='2'){
                         document.getElementById('releaseBuild').disabled = true;
                         $scope.stoppedTyping=function(){
                              var textarea_value = document.getElementById("1_0").value;
                              var textarea_value1 = document.getElementById("1_1").value;
                              if(textarea_value.length > 0 && textarea_value1.length > 0) { 
                                   document.getElementById('releaseBuild').disabled = false; 
                              } 
                              else { 
                                   document.getElementById('releaseBuild').disabled = true;
                              }
                         }
                    }

               }
               if(checkedValue1.length==0){
                    document.getElementById("releaseBuild").disabled = true;
                    console.log("insde loop2")
               }

          };
         
          $scope.createApplication = function() {
               location.href = '#!/selectapp';
          }
     } else {
          location.href = '#!/login';
     }
}]);
