'use strict';

angular.module('myApp.adduser', ['ngRoute', 'myApp.utility'])

.config(['$routeProvider', function($routeProvider) {
     $routeProvider.when('/adduser', {
          templateUrl: 'adduser/adduser.html',
          controller: 'adduserCtrl'
     });
}])

.controller('adduserCtrl', ['$scope', 'datatoBind', '$rootScope', function($scope, datatoBind, $rootScope) {
     $scope.hideuser = false;
     if (localStorage.userid) {
          $scope.isUser = true;
          $scope.fn_adduser = function(user) {
               var adduserarray = [];
               var i;
               var emailList = $("#email_val").val().split(',');
               for (i = 0; i < emailList.length; i++) {
                    for (i = 0; i < emailList.length; i++) {
                         var expr = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;
                         var expr2 = /^(.*?)@/;
                         var result = expr.test(emailList[i]);
                         var result2 = expr2.exec(emailList[i]);
                         var names = result2[1].replace(/\./g, " ");


                         adduserarray.push(names);
                         if (!result) {
                              document.getElementById("demo").style.color = "red";
                              document.getElementById("demo").innerHTML = "sorry enter a valid email adrress";
                              return false;
                         }
                    }
                    if (emailList.length == 1) {
                         document.getElementById("demo").innerHTML = "";
                         $('#serviceErrorModal').modal({
                              backdrop: 'static',
                              keyboard: false
                         })
                         $rootScope.$broadcast('updatedlocal', {
                              someProp: localStorage // send whatever you want
                         });
                         localStorage.usernames = JSON.stringify(adduserarray);
                         return true;
                    } else {
                         document.getElementById("demo").innerHTML = ""
                         localStorage.usernames = JSON.stringify(adduserarray);
                         $('#serviceErrorModal').modal({
                              backdrop: 'static',
                              keyboard: false
                         })
                         $rootScope.$broadcast('updatedlocal', {
                              someProp: localStorage // send whatever you want
                         });

                    }
               }

          }


          $scope.goToHome = function() {
               location.href = '#!/view2';
          }

          $scope.backButton = function() {
               history.back();
          }
     } else {
          location.href = '#!/login';
     }
}])
