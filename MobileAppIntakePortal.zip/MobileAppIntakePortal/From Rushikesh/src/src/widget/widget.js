'use strict';
angular.module('myApp.widgets', [])

.directive('loading', ['$http', function($http) {
     return {
          restrict: 'A',
          link: function(scope, element, attrs) {
               scope.isLoading = function() {
                    var reqCount = $http.pendingRequests;
                    return reqCount.length > 0;
               };
               scope.$watch(scope.isLoading, function(value) {
                    if (value) {
                         element.removeClass('ng-hide');
                    } else {
                         element.addClass('ng-hide');
                    }
               });
          }
     };
}])

.directive('serviceError', function() {
          return {
               restrict: 'E',
               replace: true,
               templateUrl: 'widget/service-error.htm',
               controller: function($scope, $rootScope) {
                    $scope.$on('updatedlocal', function(event, param) {
                         var data = param.someProp;

                         $scope.AppObj = JSON.parse(data.createApp);
                         $scope.appDescription = $scope.AppObj.Description;
                         $scope.appName = $scope.AppObj.app_Name;
                         $scope.appFeature = data.choosefeature;
                         $scope.appbackEnd = data.selectBackend;
                         $scope.appOS = data.chooseOS;
                         $scope.appDevicetype = data.selectApp;


                         $scope.popObj = "<!DOCTYPE html><html><head><style type='text/css' media='print'>body {font-family: sans-serif;color: #585761;font-size: 12px;}table {width: 500px;border-top: 1px solid #a09e9e;border-right: 1px solid #a09e9e;}table tr td {border-left: 1px solid #a09e9e;border-bottom: 1px solid #a09e9e;padding: 8px;}</style></head><table width='100%' cellpadding='0' cellspacing='0'><tr><td align='left' width='35%'><b>Application Description :</b></td><td align='left'>" + $scope.appDescription + "</td></tr><tr><td align='left'><b>Application Features :</b></td><td align='left'>" + $scope.appFeature + "</td></tr><tr><td align='left'><b>Backend Needs :</b></td><td align='left'>" + $scope.appbackEnd + "</td></tr><tr><td align='left'><b>Operating System :</b></td><td align='left'>" + $scope.appOS + "</td></tr><tr><td align='left'><b>Device Type :</b></td><td align='left'>" + data.selectApp + "</td></tr></table></body></html>";

                    });
                    $scope.confirm = function() {
                         location.href = '#!/preview';
                    }

               }
          }
     })
     .directive('popupModal', function() {
          return {
               restrict: 'E',
               replace: true,
               templateUrl: 'widget/popup.htm',
               controller: function($scope, $rootScope) {
                    $scope.$on('selectedOs', function(event, param) {
                         var data = param.someProp;
                         var varIos = param.pro1;
                         var varAndroid = param.pro2;
                         var varboth = param.pro3;
                         $scope.appOS = [];
                         $scope.appOS = data;

                         if (data.length == '1') {
                              $scope.popObj = "<!DOCTYPE html><html><head><style type='text/css' media='print'>body {font-family: sans-serif;color: #585761;font-size: 12px;}table {width: 500px;border-top: 1px solid #a09e9e;border-right: 1px solid #a09e9e;}table tr td {border-left: 1px solid #a09e9e;border-bottom: 1px solid #a09e9e;padding: 8px;}</style></head><table width='100%' cellpadding='0' cellspacing='0'><tr><td><b>Operating System :</b></td><td><b>Version</b></td></tr><tr><td align='left'>" + $scope.appOS[0] + "</td><td align='left'>" + varIos + "</td></tr></table></body></html>";
                         };
                         if (data.length == '2') {
                              $scope.popObj = "<!DOCTYPE html><html><head><style type='text/css' media='print'>body {font-family: sans-serif;color: #585761;font-size: 12px;}table {width: 500px;border-top: 1px solid #a09e9e;border-right: 1px solid #a09e9e;}table tr td {border-left: 1px solid #a09e9e;border-bottom: 1px solid #a09e9e;padding: 8px;}</style></head><table width='100%' cellpadding='0' cellspacing='0'><tr><td><b>Operating System :</b></td><td><b>Version</b></td></tr><tr><td align='left'>" + $scope.appOS[0] + "</td><td align='left'>" + varAndroid + "</td></tr><tr><td align='left'>" + $scope.appOS[1] + "</td><td align='left'>" + varboth + "</td></tr></table></body></html>";
                         };


                    });

               }
          }
     })
     .directive('adduserModal', function(MAIPSer,$route) {
          return {
               restrict: 'E',
               replace: true,
               templateUrl: 'widget/adduserpopup.htm',
               controller: function($scope, $rootScope) {
                    $scope.isUsers = true;
                    $scope.fn_adduserfrompopup = function(valid) {
                         $scope.addpopuperarray = [];
                         var i;
                         var emailList = $("#popup_email_val").val().split(',');

                         if (emailList[emailList.length - 1] != "") {
                              for (i = 0; i < emailList.length; i++) {
                                   for (i = 0; i < emailList.length; i++) {
                                        var expr = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;
                                        var expr2 = /^(.*?)@/;
                                        var result = expr.test(emailList[i]);
                                        if (result) {
                                             var result2 = expr2.exec(emailList[i]);
                                             var names = result2[1].replace(/\./g, " ");
                                             $scope.addpopuperarray.push({
                                                  'user_name': names,
                                                  'user_email': emailList[i],
                                                  'app_id': $rootScope.appid
                                             });
                                             console.log($scope.addpopuperarray)
                                        }

                                        if (!result) {
                                             $scope.isUsers = false;
                                             document.getElementById("popupmessage").style.color = "red";
                                             document.getElementById("popupmessage").innerHTML = "sorry enter a valid email adrress";
                                             return false;
                                        }
                                   }
                                   if (emailList) {
                                        $scope.isUsers = true;
                                        $scope.addusertoList();
                                        $('#adduserpopup').modal('hide');
                                        document.getElementById("popupmessage").innerHTML = ""


                                   }
                              }
                         }
                    }

                    $scope.addusertoList = function() {
                       for(var i=0; i<$scope.addpopuperarray.length; i++){
                            var object = [{
                                "app_id":$scope.addpopuperarray[i].app_id,
                                "user_name":$scope.addpopuperarray[i].user_name,
                                "user_email":$scope.addpopuperarray[i].user_email
                            }]
                            console.log(object)
                         MAIPSer.addUser(object, function(resp) {
                              console.log(resp)
                              console.log("User Added");
                             $route.reload();
                         }, function(resp) {
                              console.log(resp)
                              console.log("Failed to add")
                         })
                            
                       }
                        

                    }

               }
          }
     })
