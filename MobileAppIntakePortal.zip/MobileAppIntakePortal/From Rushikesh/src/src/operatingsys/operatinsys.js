'use strict';

angular.module('myApp.operatinsys', ['ngRoute', 'myApp.utility'])

.config(['$routeProvider', function($routeProvider) {
     $routeProvider.when('/operatinsys', {
          templateUrl: 'operatingsys/operatinsys.html',
          controller: 'operatinsysCtrl'
     });
}])

.controller('operatinsysCtrl', ['$scope', 'datatoBind', function($scope, datatoBind) {
     if (localStorage.userid) {
          $scope.isOS = true;
          $scope.typeofplatforms = ['iOS', 'Android'];
          $scope.fn_operaintgsys = function() {
               if ($scope.selection3.length != 0) {
                    $scope.isOS = true;
                    datatoBind.chooseOS = $scope.selection3;
                    localStorage.chooseOS = $scope.selection3;
                    location.href = '#!/adduser';
               } else {
                    $scope.isOS = false;
               }

          }
          $scope.selection3 = [];
          $scope.toggleSelection3 = function toggleSelection(type) {
               var idx = $scope.selection3.indexOf(type);

               // is currently selected
               if (idx > -1) {
                    $scope.selection3.splice(idx, 1);
               }

               // is newly selected
               else {
                    $scope.selection3.push(type);
               }
               $scope.isOS = $scope.selection3.toString();

               if ($scope.selection3.length > 0) {
                    $scope.IsChecked = false;
               } else {
                    $scope.IsChecked = true;
               }
               //          console.log($scope.IsChecked)
          };
          $scope.goToHome = function() {
               location.href = '#!/view2';
          }

          $scope.backButton = function() {
               history.back();
          }
     } else {
          location.href = '#!/login';
     }
}])
