'use strict';

angular.module('myApp.login', ['ngRoute', 'myApp.utility'])

.config(['$routeProvider', function($routeProvider) {
          $routeProvider.when('/login', {
               templateUrl: 'login/login.html',
               controller: 'LoginCtrl'
          });
     }])
     .value('UserService', {
          id: ''
     })
     .controller('LoginCtrl', ['$scope', 'MAIPSer', 'UserService', function($scope, MAIP, UserService) {
          localStorage.clear();
          var userDetails;
          $scope.invalidUser = false;
          $scope.LogIn = function() {
               //               $scope.username = "PRATHAMESH.RUDRAKSHAWAR@AIG.COM";
               //               $scope.password = "work4aig";

               userDetails = {
                    'user_email': $scope.username,
                    'password': $scope.password
               }
               MAIP.loginUser(userDetails, function(resp) {
                    if (resp.data.status == 'success') {
                         $scope.invalidUser = false;
                         //UserService.id = resp.data.message;
                         if (typeof(Storage) !== "undefined") {
                              localStorage.userid = resp.data.message;
                         } else {
                              alert("Your Browser Does not support Web Storage!");
                         }
                         location.href = '#!/view2';
                    } else {
                         $scope.invalidUser = true;
                    }
               }, function(data) {
                    console.log(data)
               })


          }
     }]);
