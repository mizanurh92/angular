'use strict';

angular.module('myApp.choosefeature', ['ngRoute', 'myApp.utility'])

.config(['$routeProvider', function($routeProvider) {
     $routeProvider.when('/choosefeature', {
          templateUrl: 'choosefeature/choosefeature.html',
          controller: 'choosefeatureCtrl'
     });
}])

.controller('choosefeatureCtrl', ['$scope', 'datatoBind', function($scope, datatoBind) {
     if (localStorage.userid) {
          $scope.typeoffeatures = ['Notification', 'Authentication', 'Analytics'];
          $scope.isFeature = true;
          $scope.fn_features = function() {
               if ($scope.selection1.length != 0) {
                    $scope.isFeature = true;
                    datatoBind.choosefeature = $scope.selection1;
                    localStorage.choosefeature = $scope.selection1;
                    location.href = '#!/selectbackend';
               } else {
                    $scope.isFeature = false;
               }
          }
          $scope.selection1 = [];
          $scope.toggleSelection1 = function toggleSelection(type) {
               var idx = $scope.selection1.indexOf(type);

               // is currently selected
               if (idx > -1) {
                    $scope.selection1.splice(idx, 1);
               }

               // is newly selected
               else {
                    $scope.selection1.push(type);
               }
               $scope.features = $scope.selection1.toString();
               if ($scope.selection1.length > 0) {
                    $scope.IsChecked = false;
               } else {
                    $scope.IsChecked = true;
               }
          };

          $scope.goToHome = function() {
               location.href = '#!/view2';
          }

          $scope.backButton = function() {
               history.back();
          }
     } else {
          location.href = '#!/login';
     }
}])
