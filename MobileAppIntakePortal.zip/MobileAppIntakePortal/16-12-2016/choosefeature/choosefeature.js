'use strict';

angular.module('myApp.choosefeature', ['ngRoute', 'myApp.utility'])

.config(['$routeProvider', function($routeProvider) {
     $routeProvider.when('/choosefeature', {
          templateUrl: 'choosefeature/choosefeature.html',
          controller: 'choosefeatureCtrl'
     });
}])

.controller('choosefeatureCtrl', ['$scope', 'datatoBind', function($scope, datatoBind) {
     if (localStorage.userid) {
          $scope.typeoffeatures = ['Notification', 'Authentication', 'Analytics'];
          $scope.isFeature = true;
          $scope.fn_features = function() {
               if ($scope.selection1.length != 0) {
                    $scope.isFeature = true;
                    datatoBind.choosefeature = $scope.selection1;
                    localStorage.choosefeature = $scope.selection1;
                    location.href = '#!/selectbackend';
               } else {
                    $scope.isFeature = false;
               }
          }
          $scope.selection1 = [];
          $scope.toggleSelection1 = function toggleSelection(type) {
               var idx = $scope.selection1.indexOf(type);

               // is currently selected
               if (idx > -1) {
                    $scope.selection1.splice(idx, 1);
               }

               // is newly selected
               else {
                    $scope.selection1.push(type);
               }
               $scope.features = $scope.selection1.toString();
               if ($scope.selection1.length > 0) {
                    $scope.IsChecked = false;
               } else {
                    $scope.IsChecked = true;
               }
          };

		 if(localStorage.choosefeature = localStorage.choosefeature) {
			 var cFeat = localStorage.choosefeature.split(",")
			 for(var i = 0; i < cFeat.length; i++) {
				 if(cFeat[i] == 'Notification') {
					 $scope.CF0 = true;
				 } else {

				 } 
				 if(cFeat[i] == 'Authentication') {
					 $scope.CF1 = true;
				 } else {

				 } 
				 if(cFeat[i] == 'Analytics') {
					 $scope.CF2 = true;
				 } else {

				 }
			 }
			 $scope.selection1 = cFeat;
		 } else {
			 
		 }
		 
          $scope.goToHome = function() {
               location.href = '#!/view2';
          }

          $scope.backButton = function() {
               history.back();
          }
     } else {
          location.href = '#!/login';
     }
}])
