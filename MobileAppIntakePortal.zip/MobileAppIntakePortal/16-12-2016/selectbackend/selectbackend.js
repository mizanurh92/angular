'use strict';

angular.module('myApp.selectbackend', ['ngRoute', 'myApp.utility'])

.config(['$routeProvider', function($routeProvider) {
     $routeProvider.when('/selectbackend', {
          templateUrl: 'selectbackend/selectbackend.html',
          controller: 'selectbackendCtrl'
     });
}])

.controller('selectbackendCtrl', ['$scope', 'datatoBind', function($scope, datatoBind) {
     if (localStorage.userid) {
          $scope.isBackend = true;
          $scope.typeofconnectivity = ['Database Connectivity', 'legacy System', 'Cloud Integration', 'Content Only'];
          $scope.fn_backend = function() {
               if ($scope.selection2.length != 0) {
                    $scope.isBackend = true;
                    datatoBind.selectBackend = $scope.selection2.join(', ');
                    localStorage.selectBackend = $scope.selection2;
                    location.href = '#!/operatinsys';
               } else {
                    $scope.isBackend = false;
               }

     }
     $scope.selection2 = [];
     $scope.toggleSelection2 = function toggleSelection(type) {
          var idx = $scope.selection2.indexOf(type);

          // is currently selected
          if (idx > -1) {
               $scope.selection2.splice(idx, 1);
          }

          // is newly selected
          else {
               $scope.selection2.push(type);
          }
          $scope.backEnds = $scope.selection2.toString();

               if ($scope.selection2.length > 0) {
                    $scope.IsChecked = false;
               } else {
                    $scope.IsChecked = true;
               }
          };
		  if(localStorage.selectBackend = localStorage.selectBackend) {
			  var BackEnd = localStorage.selectBackend.split(",");
			  for(var i = 0; i < BackEnd.length; i++){
				  if(BackEnd[i] == 'Database Connectivity'){
					  $scope.backend0 = true;
				  } else {
					  
				  }
				  if(BackEnd[i] == 'legacy System'){
					  $scope.backend1 = true;
				  } else {
					  
				  }
				  if(BackEnd[i] == 'Cloud Integration'){
					  $scope.backend2 = true;
				  } else {
					  
				  }
				  if(BackEnd[i] == 'Content Only'){
					  $scope.backend3 = true;
				  } else {
					  
				  }
			  }
			  $scope.selection2 = BackEnd;
		  } else {
			  
		  }
          $scope.goToHome = function() {
               location.href = '#!/view2';
          }

          $scope.backButton = function() {
               history.back();
          }
     } else {
          location.href = '#!/login';
     }
}])
