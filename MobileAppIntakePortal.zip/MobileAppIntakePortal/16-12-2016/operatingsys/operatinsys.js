'use strict';

angular.module('myApp.operatinsys', ['ngRoute', 'myApp.utility'])

.config(['$routeProvider', function($routeProvider) {
     $routeProvider.when('/operatinsys', {
          templateUrl: 'operatingsys/operatinsys.html',
          controller: 'operatinsysCtrl'
     });
}])

.controller('operatinsysCtrl', ['$scope', 'datatoBind', function($scope, datatoBind) {
     if (localStorage.userid) {
     $scope.isOS = true;
     $scope.typeofplatforms = ['iOS', 'Android'];
     $scope.fn_operaintgsys = function() {
          if ($scope.selection3.length != 0) {
               $scope.isOS = true;
               datatoBind.chooseOS = $scope.selection3.join(', ');
                    localStorage.chooseOS = $scope.selection3.join(', ');
                    location.href = '#!/adduser';
               } else {
                    $scope.isOS = false;
               }

     }
     $scope.selection3 = [];
     $scope.toggleSelection3 = function toggleSelection(type) {
          var idx = $scope.selection3.indexOf(type);

          // is currently selected
          if (idx > -1) {
               $scope.selection3.splice(idx, 1);
          }

          // is newly selected
          else {
               $scope.selection3.push(type);
          }
          $scope.isOS = $scope.selection3.toString();

               if ($scope.selection3.length > 0) {
                    $scope.IsChecked = false;
               } else {
                    $scope.IsChecked = true;
               }
               //          console.log($scope.IsChecked)
          };
		  if(localStorage.chooseOS = localStorage.chooseOS) {
			  var ChooseOS = localStorage.chooseOS.split(",")
			  for(var i = 0; i < ChooseOS.length; i++) {
				  if(ChooseOS[i] == 'iOS' || ChooseOS[i] == ' iOS') {
					  $scope.ChOS0 = true;
				  } else {
					  
				  }
				  if(ChooseOS[i] == 'Android' || ChooseOS[i] == ' Android') {
					  $scope.ChOS1 = true;
				  } else {
					  
				  }
			  }
			  $scope.selection3 = ChooseOS;
		  } else {
			  
		  }
          $scope.goToHome = function() {
               location.href = '#!/view2';
          }

     $scope.backButton = function() {
          history.back();
     }
     } else {
          location.href = '#!/login';
     }
}])
