/**
 * Created by rjogle on 10/5/2016.
 */
angular.module('App.Validation',[])

.directive("blurredFocused", [function () {
    return {
        restrict:"A",
        priority:-1,
        link:function(scope,ele,attrs){

            ele.on("blur",function(){

                scope.$apply(function(){
                    console.log(attrs)

                })

            })

            ele.on("focus",function(){

                scope.$apply(function(){
                    console.log("hereddde")

                })
            })
        }
    }
}])

.directive('onlyDigits', function () {
    return {
        require: 'ngModel',
        restrict: 'A',
        link: function (scope, element, attr, ctrl) {
            function inputValue(val) {
                if (val) {
                    var digits = val.replace(/[^0-9.]/g, '');

                    if (digits.split('.').length > 2) {
                        digits = digits.substring(0, digits.length - 1);
                    }

                    if (digits !== val) {
                        ctrl.$setViewValue(digits);
                        ctrl.$render();
                    }
                    return parseFloat(digits);
                }
                return undefined;
            }
            ctrl.$parsers.push(inputValue);
        }
    };
})

.directive('helpText',['helpTextService',function(helpTextService){
return{
    restrict: 'EA',
    replace: true,
    scope: {
        textKey: "@"
    },
    template: '<span class="qs">  <span class="popover above">{{helptextmessageSet}}</span></span>',
    link: function(scope, el, attrs) {
        scope.helptextmessage = attrs.textKey;
        scope.helptextmessageSet = (helpTextService[scope.helptextmessage]);
        $('[data-toggle="popover"]').popover();
    }
}

}]);
