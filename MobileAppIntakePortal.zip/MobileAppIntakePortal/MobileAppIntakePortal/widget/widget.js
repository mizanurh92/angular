/**
 * Created by rjogle on 10/4/2016.
 */
angular.module('App.widget', [])
    .directive('rejectPopup', function () {
        return {
            restrict: 'E',
            replace: true,
            template: '<div class="modal fade form-box" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">' +
            '<div class="modal-dialog" role="document">'+
            '   <div class="modal-content">' +
            '  <div class="modal-header">' +
            '       <h4 class="modal-title main-heading" id="myModalLabel">We are Sorry</h4>' +
            '       </div>' +
            '       <div class="modal-body">' +
            '          <h2 class="sub-heading">It looks like we are not able to provide you with coverage.</h2>' +
            '       </div>' +
            '       <div class="modal-footer">' +
            '       <a class="go-to-aig-btn" data-dismiss="modal">Back to Application</a>' +
            '       <a class="go-to-aig-btn" href="http://www.aig.com/business/insurance/specialty/unmanned-aircraft-solutions">Go to AIG.COM</a>' +
            '       </div>' +
            '       </div>' +
            '       </div>' +
            '       </div>',
            controller: function ($scope) {
                $scope.rejected = function (attrs) {
                    $('#myModal').modal({backdrop: 'static', keyboard: false})
                }
            }
        }
    })
    .directive('htmlQuote', function (HTMLtoPDFobj,$sce) {
        return {
            restrict: 'E',
            replace: true,
            template: '<div class="modal fade form-box" id="quote" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">' +
            '<div class="modal-dialog" role="document">'+
            '   <div class="modal-content">' +
            '  <div class="modal-header">' +
            '       </div>' +
            '       <div class="modal-body">' +
            "          <div class='' id='showHtmlData' ng-bind-html='showHTMLData'></div>" +
            '       </div>' +
            '       <div class="modal-footer">' +
            '       <a class="go-to-aig-btn" data-dismiss="modal">Back to Application</a>' +
            '       <a class="go-to-aig-btn" href="http://www.aig.com/business/insurance/specialty/unmanned-aircraft-solutions">Go to AIG.COM</a>' +
            '       </div>' +
            '       </div>' +
            '       </div>' +
            '       </div>',
            controller: function ($scope) {
                $scope.showpopup = function (attrs) {
                    $scope.showHTMLData = $sce.trustAsHtml(HTMLtoPDFobj.finalObj)
                    $('#quote').modal({backdrop: 'static', keyboard: false})
                }
            }
        }
    })
    .directive('serviceError', function () {
        return {
            restrict: 'E',
            replace: true,
            template: '<div class="modal fade form-box" id="serviceErrorModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">' +
            '<div class="modal-dialog" role="document">'+
            '   <div class="modal-content">' +
            '  <div class="modal-header">' +
            '       <h4 class="modal-title main-heading" id="myModalLabel">We are Sorry</h4>' +
            '       </div>' +
            '       <div class="modal-body">' +
            '          <h2 class="sub-heading">An error occurred while processing. Please try again later.</h2>' +
            '       </div>' +
            '       <div class="modal-footer">' +
            '       <a class="go-to-aig-btn" href="http://www.aig.com/business/insurance/specialty/unmanned-aircraft-solutions">Go to AIG.COM</a>' +
            '       </div>' +
            '       </div>' +
            '       </div>' +
            '       </div>',
            controller: function ($scope) {
                // $('#ageRejectModal').modal({backdrop: 'static', keyboard: false})
            }
        }
    })
    .directive("restricteddate", function () {
      return {
        restrict: "A",
        require: "ngModel",
        link: function (scope, elem, attrs, ngModelCtrl) {
          var updateModel = function (dateText) {
            scope.$apply(function () {
              ngModelCtrl.$setViewValue(dateText);
            });
          };
          var options = {
            dateFormat: "mm/dd/yy",
            minDate: -0,
            onSelect: function (dateText) {
              updateModel(dateText);
            }
          };
          elem.datepicker(options);
        }
      }
    })
    .directive("anydate", function () {
      return {
        restrict: "A",
        require: "ngModel",
        link: function (scope, elem, attrs, ngModelCtrl) {
          var updateModel = function (dateText) {
            scope.$apply(function () {
              ngModelCtrl.$setViewValue(dateText);
            });
          };
          var options = {
            dateFormat: "mm/dd/yy",
            onSelect: function (dateText) {
              updateModel(dateText);
            }
          };
          elem.datepicker(options);
        }
      }
    })
    .directive("scroll", function ($window) {
        return function(scope, element, attrs) {
            angular.element($window).bind("scroll", function() {
                if (this.pageYOffset <= 187) {
                    angular.element(element).removeClass('sticky');
                 } else {
                    angular.element(element).addClass('sticky');
                 }
                scope.$apply();
            });
        };
    });