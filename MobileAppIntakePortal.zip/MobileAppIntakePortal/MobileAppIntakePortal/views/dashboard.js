App.controller('mainController', ['$scope', '$document', '$timeout', '$http', 'mailAPI', 'HTMLtoPDFobj', 'oAuthToken', 'PremiumRanges','getBrokerList','getUSdata','getEndosements', function($scope, $document, $timeout, $http, mailAPI, HTMLtoPDFobj, oAuthToken, PremiumRanges,getBrokerList,getUSdata,getEndosements) {


    $scope.highTier = false;
    $scope.isPhysicalDamage = true;
    $scope.isSystemInformation = true;
    $scope.isWarLibility = true;
    $scope.isPhysicalDamagaeWar = true;
    $scope.isOtherusers = true;

    $scope.required = true;
    $scope.requiredSysinfo = true;
    $scope.opinfo = true;
    $scope.isNew_mobile_app=true;
    $scope.isManage_app=true;
    $scope.isManage_user=true;
    $scope.isAddUser=true;
    $scope.isBuild=true;
    $scope.addUserBox=true;
    /********* checkbox and radio buttons values*************/

    $scope.typeofplatforms = ['iOS', 'Android']

    $scope.typeofapp = ['Native', 'Hybrid']

    $scope.typeofdevices = ['Phone', 'Tablets']

    $scope.typeoffeatures = ['Authentication', 'Push Notification', 'Analytics', 'Connect to legacy services', 'Database', 'Cloud', 'Content only']

    $scope.userinfo=[
        {fName: 'Harsh', lName: 'Deshai',email:'a@a.com'},
        {fName: 'Mohan', lName: 'kumar',email:'aa@a.com'},
        {fName: 'Kuldeep', lName: 'sharma',email:'aaaa@a.com'}
    ];
    $scope.builds=[
    {build_no:4, date:'1/11/2013',distribution:'yes'},
    {build_no:3, date:'1/10/2013',distribution:'yes'},
    {build_no:2, date:'1/9/2013',distribution:'yes'},
    {build_no:1, date:'1/8/2013',distribution:'yes'},
    ];
     $scope.appList=['Glossory App','Ticker App','Employee Directory App','Travel and Meal App'];
    /**********select box end ***********/

    var date = new Date();
    $scope.dateString = date.getMonth() + 1 + "/" + date.getDate() + "/" + date.getFullYear().toString();

    $document.scrollTopAnimated(0).then(function() {});
    $scope.currentYear = new Date().getFullYear();
    $scope.toggleSelection = function toggleSelection(type) {
        var idx = $scope.selectiontypeofbuisness.indexOf(type);
        if (idx > -1) {
            $scope.selectiontypeofbuisness.splice(idx, 1);
        } else {
            $scope.selectiontypeofbuisness.push(type);
        }
    };

    $scope.scrollDown = function(parameter) {
        var someElement = angular.element(document.getElementById(parameter));
        $document.scrollToElementAnimated(someElement);
    }

     


    $scope.fnuserinfo = function() {
        // var addid = $scope.userinfo.length + 1;
        $scope.userinfo.push({
            fName: User.fName,
            lName: User.lName,
            email: User.email
        })
        console.log($scope.userinfo)
    }

    $scope.addUser=function(){
        $scope.addUserBox=false;
    }
    $scope.cancelUser=function(){
        $scope.addUserBox=true;
    }
    $scope.removeUser = function() {
        var removeUser = $scope.userinfo.length - 1;
        $scope.userinfo.splice(removeUser);
    }
    $scope.remove = function(AppList){
          var index = $scope.appList.indexOf(AppList);
          $scope.appList.splice(index, 1);     
        };
    $scope.main_section = function(param){
        var idparameter = param;
        $scope.isNew_mobile_app = false;
        $scope.required = true;
        $timeout(function() {
            $scope.scrollDown(idparameter)
                }, 200);
        $scope.rejectedBox = true;
         $scope.myObj = {
                    "width": "180px"
                };
    }
    $scope.fn_section_0 = function(param) {
        var idparameter = param;
        $scope.isPhysicalDamage = false;
        $scope.required = true;
        $timeout(function() {
            $scope.scrollDown(idparameter)
                }, 200);
                $scope.myObj = {
                    "width": "360px"
                };
        $scope.rejectedBox = true;
    }
     $scope.fn_section_10 = function(param) {
      
        var idparameter = param;
        $scope.isPhysicalDamage = true;
        $timeout(function() {
            $scope.scrollDown(idparameter)
        }, 200);
        $scope.myObj = {
            "width": "0px"
        };
        
        $scope.rejectedBox = true;
    }

    $scope.fn_section_1 = function(param) {
      
        var idparameter = param;
        $scope.isSystemInformation = false;
        $timeout(function() {
            $scope.scrollDown(idparameter)
        }, 200);
        $scope.myObj = {
            "width": "540px"
        };
        
        $scope.rejectedBox = true;
    }
    $scope.fn_section_21 = function(param) {
      
        var idparameter = param;
        $scope.isSystemInformation = true;
        $timeout(function() {
            $scope.scrollDown(idparameter)
        }, 200);
        $scope.myObj = {
            "width": "180px"
        };
        
        $scope.rejectedBox = true;
    }
    $scope.fn_section_2 = function(param) {
         $scope.isPhysicalDamagaeWar = false;
         var idparameter = param;
            $timeout(function() {
                $scope.scrollDown(idparameter)
            }, 200);
            $scope.myObj = {
                "width": "720px"
            };
        
    }

    $scope.fn_section_3 = function(param) {
        
        $scope.isWarLibility = false;
        var idparameter = param;
        $timeout(function() {
            $scope.scrollDown(idparameter)
        }, 200);
        $scope.myObj = {
            "width": "900px"
        };
        
    }

     $scope.fn_section_4 = function(param) {
        
        $scope.isOperatorDetails4 = false;
        var idparameter = param;
        $timeout(function() {
            $scope.scrollDown(idparameter)
        }, 200);
        $scope.myObj = {
            "width": "900px"
        };
        $scope.rejectedBox = true;

    }
      $scope.main_section1 = function(param){
        var idparameter = param;
        $scope.isManage_app = false;
        $scope.required = true;
        $timeout(function() {
            $scope.scrollDown(idparameter)
                }, 200);
         $scope.myObj = {
                    "width": "300px"
                };
        $scope.rejectedBox = true;
    }

     $scope.fn_section_5 = function(param) {
        var idparameter = param;
        $scope.isManage_user = false;
        $scope.required = true;
        $timeout(function() {
            $scope.scrollDown(idparameter)
                }, 200);
                $scope.myObj = {
                    "width": "600px"
                };
        $scope.rejectedBox = true;
    }
     $scope.fn_section_6 = function(param) {
        var idparameter = param;
        $scope.isBuild = false;
        $scope.required = true;
        $timeout(function() {
            $scope.scrollDown(idparameter)
                }, 200);
                $scope.myObj = {
                    "width": "900px"
                };
        $scope.rejectedBox = true;
    }
      $scope.goToHome = function(param) {
        var idparameter = param;
        $scope.isManage_app=true;
        $scope.required = true;
        $scope.isManage_user = true;
        $scope.islanding=false;
        $scope.isBuild=true;
        $scope.isPhysicalDamage=true;
    }
   $scope.htmltopdf = function(senderList,subjectLine,bodyline) {
        if ($scope.highTier == false) {
            var dronobj, dronesize, dronelessthan11, dronelessthan21, dronelessthan22, dronemorethan55, physicaldamage, coverageamnt, aircraft;
            dronelessthan11 = $scope.finalArr[0].drone_less_11_lbs;
            dronelessthan21 = $scope.finalArr[0].drone_less_21_lbs;
            dronelessthan22 = $scope.finalArr[0].drone_less_55_lbs;
            dronemorethan55 = $scope.finalArr[0].drone_more_55_lbs;
            dronesize = $scope.finalArr[0].dronesize;
            physicaldamage = $scope.finalArr[0].PhysicalDamage;
            coverageamnt = $scope.finalArr[0].coverage_amount;

            var aircrafttablestart;
            var aircrafttableend;
            var aircraftbind = "";
            var aircraft = "";

            var payload = "";
            var payloadtablebind = "";
            var payloadtablestart;
            var payloadtableend;

            var GCE = "";
            var GCEtablebind = "";
            var GCEtablestart;
            var GCEtableend;

            var spareparts = "";
            var sparepartstablebind = "";
            var sparepartstablestart;
            var sparepartstableend;

            var Endoforpdf = $scope.endoGlobal;
            var libility;

            TotalPremium = $scope.libilityCoverageArray[0].Total_Premium;
            CommonEndoforpdf = "";

            for (var key in $scope.CommonEndorsementObj) {
                CommonEndoforpdf = CommonEndoforpdf + $scope.CommonEndorsementObj[key];
            }

            Soa = $scope.libilityCoverageArray[0].Libility_limit;
            PdfendosVisualobr = $scope.endosVisualobr;
            PdfhiredCont = $scope.hiredCont;
            PdfIssuingCompany = $scope.IssuingCompany;
            PdfPolicyForm = $scope.PolicyForm;
            if (!$scope.libilityCoverageArray[0].War_libility_premium) {
                $scope.libilityCoverageArray[0].War_libility_premium = 0;
            }
            libility = "<tr height='25px'> <td colspan='2' align='center'><font size='small'>$" + $scope.libilityCoverageArray[0].Libility_limit + "</font> <\/td><td align='center'><font size='small'>$5,000</font> <\/td><td align='center'><font size='small'>$" + $scope.libilityCoverageArray[0].Base_libility_premium + "</font> <\/td><td align='center'><font size='small'>$" + $scope.libilityCoverageArray[0].Non_Owned_libility_premium + "</font> <\/td><td align='center'><font size='small'>$" + $scope.libilityCoverageArray[0].War_libility_premium + "</font> <\/td><td align='center'><font size='small'>$" + $scope.libilityCoverageArray[0].libility_premium_total + "</font> <\/td></tr>";

            if ($scope.finalArr[0].PhysicalDamage == "Yes") {
                aircrafttablestart = "<table border='1' bordercolor='#757575' width='100%' align='center'> <tr><th colspan='8' bgcolor='#757575' height='35px'><b><font color='white' size='small'>PHYSICAL DAMAGE COVERAGE</font></b></th><\/tr><tr height='25px'> <th colspan='8' bgcolor='#9E9E9E'><b><font color='white' size='small'> AIRCRAFT - UAV, including any equipment usually installed in it or on the aircraft </b></font> </th> <\/tr><tr bgcolor='#D2D2D2' valign='center' height='25px'> <th><font size='small'><b>Make</b></font></th> <th><font size='small'><b>Model</b></font> </th> <th><font size='small'><b>Year</b></font> </th> <th><font size='small'><b>Registration #</b></font> </th> <th><font size='small'><b>Value</b></font> </th> <th><font size='small'><b>Premium</b></font></th> <th><font size='small'><b>War Premium</b></font></th> <th><font size='small'><b>Total Premium</b></font></th> <\/tr>";
                for (var m = 0; m <= $scope.finalArr[0].aircraft.length - 1; m++) {
                    if ($scope.finalArr[0].PhysicalDamageByWar == "Yes") {
                        aircraft += "<tr valign='center' height='25px'><td><font size='small'>" + $scope.finalArr[0].aircraft[m].make + "</font><\/td><td><font size='small'>" + $scope.finalArr[0].aircraft[m].model + "</font><\/td><td><font size='small'>" + $scope.finalArr[0].aircraft[m].year + "</font><\/td><td><font size='small'>" + $scope.finalArr[0].aircraft[m].registration + "</font><\/td><td><font size='small'>" + $scope.finalArr[0].aircraft[m].value + "</font><\/td> <td><font size='small'>$" + $scope.allData.AircraftPremiums.PhysicalDamagePremium[m] + "</font><\/td><td><font size='small'>$" + $scope.allData.AircraftPremiums.PhisicalDamageWarPremium[m] + "</font><\/td><td><font size='small'>$" + $scope.allData.AircraftPremiums.TotalPhysicalDamagePremium[m] + "</font></td></tr>";
                    } else {
                        aircraft += "<tr valign='center' height='25px'><td><font size='small'>" + $scope.finalArr[0].aircraft[m].make + "</font><\/td><td><font size='small'>" + $scope.finalArr[0].aircraft[m].model + "</font><\/td><td><font size='small'>" + $scope.finalArr[0].aircraft[m].year + "</font><\/td><td><font size='small'>" + $scope.finalArr[0].aircraft[m].registration + "</font><\/td><td><font size='small'>" + $scope.finalArr[0].aircraft[m].value + "</font><\/td> <td><font size='small'>$" + $scope.allData.AircraftPremiums.PhysicalDamagePremium[m] + "</font><\/td><td><font size='small'>$0</font><\/td><td><font size='small'>$" + $scope.allData.AircraftPremiums.TotalPhysicalDamagePremium[m] + "</font></td></tr>";
                    }
                }
                aircrafttableend = "</table>";
                aircraftbind = aircrafttablestart + aircraft + aircrafttableend;

                if ($scope.finalArr[0].payload.length - 1 != -1) {
                    payloadtablestart = "<table width='100%' align='center' border='1' bordercolor='#757575'> <tr> <th colspan='8' bgcolor='#9E9E9E' height='55px'><font size='small'><b><font color='white'>Payload – Any additional removable equipment that may be carried by the aircraft such as gimbals, cameras, sensors,etc. for which a separate insured value is required</font></b></font> </th> <\/tr><tr bgcolor='#D2D2D2' valign='center' height='25px'> <th><font size='small'><b>Make</b></font> </th> <th colspan='2'><font size='small'><b>Model</b></font> </th> <th><font size='small'><b>Serial #</b></font> </th> <th><font size='small'><b>Value</b></font></th> <th><font size='small'><b>Premium</b></font></th> <th><font size='small'><b>War Premium</b></font></th> <th><font size='small'><b>Total Premium</b></font></th> <\/tr>";

                    for (var j = 0; j <= $scope.finalArr[0].payload.length - 1; j++) {
                        payload = "<tr valign='center' height='25px'> <td><font size='small'>" + $scope.finalArr[0].payload[j].payloadmake + "</font><\/td><td colspan='2'><font size='small'>" + $scope.finalArr[0].payload[j].payloadmodel + "</font><\/td><td><font size='small'>" + $scope.finalArr[0].payload[j].payloadyear + "</font><\/td><td><font size='small'>" + $scope.finalArr[0].payload[j].payloadserial + "</font><\/td><td><font size='small'>$" + $scope.allData.PayloadPremiums.PhysicalDamagePremium[j] + "</font><\/td><td><font size='small'>$" + $scope.allData.PayloadPremiums.PhisicalDamageWarPremium[j] + "</font><\/td><td><font size='small'>$" + $scope.allData.PayloadPremiums.TotalPhysicalDamagePremium[j] + "</font><\/td></tr>"
                    }
                    payloadtableend = "</table>";
                    payloadtablebind = payloadtablestart + payload + payloadtableend;

                }

                if ($scope.finalArr[0].GCR.length - 1 != -1) {
                    GCEtablestart = "<table border='1' bordercolor='#757575' width='100%' align='center'> <tr><th colspan='8' colspan='8' bgcolor='#9E9E9E' height='35px'><font size='small'><b><font color='white'>GROUND CONTROL EQUIPMENT</font></b></font> </th><\/tr><tr bgcolor='#D2D2D2' height='25px'> <th><font size='small'><b>Make</b></font> </th> <th colspan='2'><font size='small'><b>Model</b></font> </th> <th><font size='small'><b>Serial #</b></font> </th> <th><font size='small'><b>Value</b></font></th> <th><font size='small'><b>Premium</b></font></th> <th><font size='small'><b>War Premium</b></font></th> <th><font size='small'><b>Total Premium</b></font></th> <\/tr>";

                    for (var k = 0; k <= $scope.finalArr[0].GCR.length - 1; k++) {
                        GCE = "<tr valign='center' height='25px'><td><font size='small'>" + $scope.finalArr[0].GCR[k].GCEmake + "</font><\/td><td colspan='2'><font size='small'>" + $scope.finalArr[0].GCR[k].GCEmodel + "</font><\/td><td><font size='small'>" + $scope.finalArr[0].GCR[k].GCEyear + "</font><\/td><td><font size='small'>" + $scope.finalArr[0].GCR[k].GCEserial + "</font><\/td><td><font size='small'>$" + $scope.allData.GroundControlPremiums.PhysicalDamagePremium[k] + "</font><\/td><td><font size='small'>$" + $scope.allData.GroundControlPremiums.PhisicalDamageWarPremium[k] + "</font><\/td><td><font size='small'>$" + $scope.allData.GroundControlPremiums.TotalPhysicalDamagePremium[k] + "</font><\/td></tr>"
                    }
                    GCEtableend = "</table>";
                    GCEtablebind = GCEtablestart + GCE + GCEtableend;
                }

                if ($scope.finalArr[0].Spare_part.length - 1 != -1) {

                    sparepartstablestart = "<table border='1' bordercolor='#757575' width='100%' align='center'> <tr><th colspan='8' bgcolor='#9E9E9E' height='35px'><font size='small'><b><font color='white'>SPARE PARTS</font></b></font> </th><\/tr><tr bgcolor='#D2D2D2' height='25px'> <th><font size='small'><b>Make</b></font> </th> <th colspan='2'><font size='small'><b>Model</b></font> </th> <th><font size='small'><b>Serial #</b></font> </th> <th><font size='small'><b>Value</b></font></th> <th><font size='small'><b>Premium</b></font></th> <th><font size='small'><b>War Premium</b></font></th> <th><font size='small'><b>Total Premium</b></font></th> <\/tr>";

                    for (var l = 0; l <= $scope.finalArr[0].Spare_part.length - 1; l++) {
                        spareparts = "<tr valign='center' height='25px'><td><font size='small'>" + $scope.finalArr[0].Spare_part[l].SparePartmake + "</font><\/td><td colspan='2'><font size='small'>" + $scope.finalArr[0].Spare_part[l].SparePartmodel + "</font><\/td><td><font size='small'>" + $scope.finalArr[0].Spare_part[l].SparePartyear + "</font><\/td><td><font size='small'>" + $scope.finalArr[0].Spare_part[l].SparePartserial + "</font><\/td><td><font size='small'>$" + $scope.allData.SparePartsPremiums.PhysicalDamagePremium[l] + "</font><\/td><td><font size='small'>$" + $scope.allData.SparePartsPremiums.PhisicalDamageWarPremium[l] + "</font><\/td><td><font size='small'>$" + $scope.allData.SparePartsPremiums.TotalPhysicalDamagePremium[l] + "</font><\/td></tr>";
                    }
                    sparepartstableend = "</table>";
                    sparepartstablebind = sparepartstablestart + spareparts + sparepartstableend;
                }
            }

            var HTMLobj = " <html><head> </head><body style='width:80%; padding:10px 10%;margin:0'> <table width='100%'> <tr> <td> <table width='100%'> <tr> <td colspan='1'> <table width='40%'> <tr> <td align='center' valign='top'><font color='DeepSkyBlue' valign='top'>AIG</font> <\/td><\/tr></table> <\/td><td colspan='2'> <font size='small'><span><b>AIG Aerospace Insurance Services, Inc.<br>1200 Abernathy Road N.E., Building 600,<br>Atlanta, GA 30328<br>Phone: (404) 249-1800<br></b></span> </font> <\/td><td colspan='2' valign='top'> <font size='small'><span><b>Date: " + CurrentDate + "<br>Company: LOCKTON COMPANIES, INC.</b></span> </font> <\/td><\/tr><tr> <td colspan='1' align='center'> <\/td><td colspan='1' align='left'><font size='small'>Inception: To Be Advised</font> <\/td><td colspan='1' align='center'><font size='small'>Expiration: To Be Advised</font> <\/td><td colspan='2' align='left'> <\/td><\/tr></table> <\/td><\/tr><tr> <td> <table width='100%' align='center' valign='middle'> <tr height='0' valign='middle'><td height='4' width='100%' bgcolor='#757575' cellspacing='0' cellpadding='0' valign='middle'><\/td><\/tr><tr valign='middle' height='35px'> <td align='center' valign='middle'><font size='small'>AIG AEROSPACE UNMANNED AIRCRAFT INSURANCE PROPOSAL</font><\/td><\/tr><tr height='0' valign='middle'><td height='4' width='100%' bgcolor='#757575' cellspacing='0' cellpadding='0' valign='middle'><\/td><\/tr></table> <\/td><\/tr><tr> <td> <table border='1' width='100%' align='center' bordercolor='#757575'> <tr><th colspan='4' bgcolor='#757575' height='30px'><font size='small'><b><font color='white'>GENERAL EXPOSURE</font></b></font> </th><\/tr><tr bgcolor='silver' height='25px'> <th><font size='small' ><b>Number of Drones less than 11 lbs</b></font> </th> <th><font size='small' colspan='2'><b>Number of Drones 11 lbs - 21 lbs</b></font> </th> <th><font size='small' colspan='2'><b>Number of Drones 22 lbs - 55 lbs</b></font> </th> <th><font size='small' colspan='2'><b>Physical damage Coverage ? </b></font> </th> <\/tr><tr height='25px'> <td align='center'><font size='small' colspan='2'>" + dronelessthan11 + "</font> <\/td><td align='center'><font size='small' colspan='2'>" + dronelessthan21 + "</font> <\/td><td align='center'><font size='small' colspan='2'>" + dronelessthan22 + "</font> <\/td><td align='center'><font size='small' colspan='2'>" + physicaldamage + "</font> <\/td><\/tr></table> <\/td><\/tr><tr> <td> <table border='1' width='100%' align='center' bordercolor='#757575'> <tr> <th colspan='7' bgcolor='#757575' height='35px'><font size='small'><b><font color='white'>LIABILITIES</font></b></font></th><\/tr><tr bgcolor='#9E9E9E' height='25px'> <th colspan='2'><font size='small'><b>Liability Limits</b></font> </th> <th><font size='small'><b>Med Pay</b></font> </th> <th><font size='small'><b>Base Liability Premium</b></font> </th> <th><font size='small'><b>Non-Owned Liability Premium</b></font> </th> <th><font size='small'><b>War Liability Premium</b></font> </th> <th><font size='small'><b>Premium Total</b></font> </th> <\/tr>" + libility + " </table> <table width='80%'> <tr><td><font size='small'>Covered Aircraft: Any Unmanned Aircraft owned and operated by the Name Insured weighing less than 55 lbs</font></td><\/tr></table> <\/td><\/tr><tr> <td>  " + aircraftbind + "  <\/td><\/tr><tr> <td> " + payloadtablebind + "  <\/td><\/tr><tr> <td>  " + GCEtablebind + "  <\/td><\/tr><tr> <td> " + sparepartstablebind + "  <table> <tr><td><h6>A Physical Damage deductible equal to 10% of the insured value of any listed aircraft or equipment above shall apply in the event of any covered physical damage loss.</h6></td><\/tr></table> <\/td><\/tr><tr> <td> <table width='100%' align='center'> <tr> <td width='70%' height='30px' align='center' valign='center'><\/td><td width='30%' bgcolor='#757575' height='30px' align='center' valign='center'> <b><font color='white' size='small'>TOTAL ANNUAL PREMIUM</font></b><br><\/td><\/tr><tr> <td width='70%' height='30px' align='center' valign='center'><\/td><td width='30%' height='30px' align='center' valign='center'> <b><font>$" + TotalPremium + "</font></b><br><\/td><\/tr></table> <\/td><\/tr><tr> <td> <table width='100%'> <tr> <td><font size='small'>Producer Commission:<font><\/td><td><font size='small'> 15.00% </font> <\/td><\/tr><tr> <td><font size='small'>Issuing Company:</font> <\/td><td><font size='small'>" + PdfIssuingCompany + "</font> <\/td><\/tr><tr> <td><font size='small'>Policy Form:</font> <\/td><td><font size='small'>" + PdfPolicyForm + "</font> <\/td><\/tr></table> <\/td><\/tr><tr> <td> <table bordercolor='#757575' width='100%' align='center' border='1' bordercolor='#757575'> <tr><th colspan='8' bgcolor='#757575' height='45px'><b><font color='white'>ENDORSEMENTS</font></b></th><\/tr><tr width='100%' height='200px'> <td colspan='8' align='left'><font size='small'>" + Endoforpdf + " " + CommonEndoforpdf + "</font> <\/td><\/tr><tr height='45px' colspan='8'><td align='left' bgcolor='#9E9E9E' colspan='8'><b>Coverage Extensions</b></td><\/tr><tr height='35px'> <td colspan='3' align='left'>Broad Coverages<\/td><td colspan='5' align='left'>Airworthiness Certificate Amendment Amended Premises Coverage<\/td><\/tr><tr height='35px'> <td colspan='3' align='left'>Premises Medical Payments<\/td><td colspan='5' align='left'>$5,000 Each Person<\/td><\/tr><tr height='35px'> <td colspan='3' align='left'>Sale of Aircraft:<\/td><td colspan='5' align='left'>$" + Soa + " Each Occurrence and Aggregate<\/td><\/tr><tr height='45px'><td align='left' bgcolor='#9E9E9E' colspan='8'><b>Non-Owned Liability</b></td><\/tr><tr height='35px'> <td colspan='8' align='left'>" + PdfhiredCont + "<\/td><\/tr><tr height='45px'><td bgcolor='#9E9E9E' colspan='8' align='left'><b>Personal Injury</b></td><\/tr><tr height='35px'><td colspan='8' align='left'>$" + Soa + " Any one offense and in the annual aggregate</td><\/tr><tr height='45px'><td bgcolor='#9E9E9E' colspan='8' align='left'><b>Purpose of Use</b></td><\/tr><tr height='35px'><td colspan='8' align='left'>As required by the Named Insured</td><\/tr><tr height='45px'><td bgcolor='#9E9E9E' colspan='8' align='left'><b>Policy Territory</b></td><\/tr><tr height='65px'><td colspan='8' align='left'>Worldwide subject to UAS117 limitations, but also limited to day, visual line-of-sight operations conducted no higher than 400 feet above ground level (AGL). Flights above 400 feet AGL permitted if conducted within 400 foot radius of a structure.</td><\/tr><tr height='45px'><td bgcolor='#9E9E9E' colspan='8' align='left'><b>Pilot Warranties</b></td><\/tr><tr height='65px'><td colspan='8' align='left'>" + PdfendosVisualobr + "</td><\/tr></table> <\/td><\/tr><tr> <td> <table> <tr height='200px'> <td> This is only a quotation and no coverage has been bound. This quotation is valid for thirty (30) days or until the expiration of the current policy, whichever comes first, and is subject to change with any new underwriting information. Premiums do not included any applicable state and/or municipal taxes. This quotation includes terrorism coverage as outlined by the Terrorism Risk Insurance Extension Act (TRIEA) of 2005 for the premium of $1 per policy. This quotation contains a broad outline of coverage and does not include all the terms, conditions and exclusions of the policy (or policies) that may be issued to you. The policy (or policies) contain the full and complete agreement with regard to coverage. Please review the policy (or policies) thoroughly upon receipt and notify us promptly in writing if you have any questions. In the event of any inconsistency between the quotation or binder and the policy, the policy language shall control unless the parties agree to an amendment. <\/td><\/tr></table> <\/td><\/tr></table></body></html>";
            HTMLtoPDFobj.finalObj = HTMLobj;
            if ($scope.sendMail == true) {
                $scope.fn_mail(senderList, subjectLine, bodyline, HTMLobj)
            }
        } else {
            var HTMLobj = " ";
            if ($scope.sendMail == true) {
                $scope.fn_mail(senderList, subjectLine, bodyline, HTMLobj)
            }
        }
    }

    /**************************** MAIL SERVICE START ********************/

    $scope.fn_mail = function(senderList,subjectLine,bodyline,HTMLobj) {

        var obj = {
            "toAddresses": senderList,
            "subject": subjectLine,
            "Body": HTMLobj,
            "plainTextBody": bodyline
        }

        var AccessToken = oAuthToken.token;
        mailAPI.sendMail(obj, AccessToken, function(resp){
            console.log("%cMail has been sent sucessfully", "background: green; color: white; font-size: small");
        }, function(resp){
            console.log("%cMail has not sent", "background: green; color: white; font-size: small");
            // $('#serviceErrorModal').modal({backdrop: 'static', keyboard: false});
        })


    }

    

    $scope.numberWithCommas = function(x){
        if(x){ 
        var parts = x.toString().split(".");
        parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ",");
        return parts.join(".");
    }
    }

    $scope.getDataforPremiumRanges = function() {
        var getResult = $scope.premiumAttributes;
        var AccessToken = oAuthToken.token;
        PremiumRanges.fetchRanges(getResult, AccessToken, function(resp) {
            console.log("%cPremium Ranges Genreted", "background: green; color: white; font-size: small");
            $scope.$fn_fetch_premiumCalc(resp.data)
            $scope.allData = [];
            $scope.allData = resp.data;
        }, function(resp) {
            console.log("%cPremium Ranges Not Genreted ", "background: red; color: white; font-size: small");
            // $('#serviceErrorModal').modal({backdrop: 'static', keyboard: false});
        })
    }



    $scope.jqFun = function(){
        $('.yes-btn').click(function() {
            $(this).addClass('active');
            $(this).next('.no-btn').removeClass('active');
        });
        $('.no-btn').click(function() {
            $(this).addClass('active');
            $(this).prev('.yes-btn').removeClass('active');
        });

        //toggle the component with class accordion_body
        $('.review-confirm-box > li > div').hide();
        $(".review-confirm-box > li > a").click(function () {
            if ($(this).next().is(':visible')) {
                $(this).next().slideUp(300);
                $(this).children(".plusminus").text('+');
            }
            else {
                $(this).next().slideDown(300);
                $(this).children(".plusminus").text('-');
            }
        });
    }
    /**************************** MAIL SERVICE END ********************/

    $timeout(function() {
        $scope.jqFun()
    }, 2000);

}]);