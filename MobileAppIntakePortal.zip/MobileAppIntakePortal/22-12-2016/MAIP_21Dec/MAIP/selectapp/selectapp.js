'use strict';

angular.module('myApp.selectapp', ['ngRoute', 'myApp.utility'])

.config(['$routeProvider', function($routeProvider) {
     $routeProvider.when('/selectapp', {
          templateUrl: 'selectapp/selectapp.html',
          controller: 'selectappCtrl'
     });
}])

.value('datatoBind', {
     selectApp: '',
     createApp: '',
     choosefeature: '',
     selectBackend: '',
     chooseOS: ''
})

.controller('selectappCtrl', ['$scope', 'datatoBind', function($scope, datatoBind) {
     if (localStorage.userid) {
          $scope.isAppSelected = true;
          $scope.typeofapplication = ['Smartphone', 'Tablet'];
          $scope.fn_selectApp = function() {
               if ($scope.selection.length != 0) {
                    $scope.isAppSelected = true;
                    datatoBind.selectApp = $scope.selection;
                    localStorage.selectApp = $scope.selection;
                    location.href = '#!/createapp';
               } else {
                    $scope.isAppSelected = false;
               }
          }

          $scope.selection = [];
          $scope.toggleSelection = function(type) {
               var idx = $scope.selection.indexOf(type);
               // is currently selected
               if (idx > -1) {
                    $scope.selection.splice(idx, 1);
               }
               // is newly selected
               else {
                    $scope.selection.push(type);
               }
               $scope.DeviceType = $scope.selection.toString();
               if ($scope.selection.length > 0) {
                    $scope.IsChecked = true;
               } else {
                    $scope.IsChecked = true;
               }


          };

		 
		 
		 if(localStorage.selectApp = localStorage.selectApp) {
			 var SApp = localStorage.selectApp.split(",")
			 for(var i = 0; i < SApp.length; i++) {
				 if(SApp[i] == 'Smartphone') {
					 $scope.AppType0 = true;
				 } else {

				 } 
				 if(SApp[i] == 'Tablet') {
					 $scope.AppType1 = true;
				 } else {

				 } 
			 }
			 $scope.selection = SApp;
		 } else {
			 
		 }
		 
          $scope.backButton = function() {
               history.back();
          }

          $scope.goToHome = function() {
               location.href = '#!/view2';
          }
     } else {
          location.href = '#!/login';
     }
}])
