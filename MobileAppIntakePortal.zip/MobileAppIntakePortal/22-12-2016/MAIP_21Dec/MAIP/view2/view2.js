'use strict';

angular.module('myApp.view2', ['ngRoute', 'myApp.utility'])

.config(['$routeProvider', function($routeProvider) {
     $routeProvider.when('/view2', {
          templateUrl: 'view2/view2.html',
          controller: 'View2Ctrl'
     });
}])
     .value('setFlag', {
          pageRefresh: ''
     })

.filter('unique', function() {
   // we will return a function which will take in a collection
   // and a keyname
   return function(collection, keyname) {
      // we define our output and keys array;
      var output = [], 
          keys = [];

      // we utilize angular's foreach function
      // this takes in our original collection and an iterator function
      angular.forEach(collection, function(item) {
          // we check to see whether our object exists
          var key = item[keyname];
          // if it's not already part of our keys array
          if(keys.indexOf(key) === -1) {
              // add it to our keys array
              keys.push(key); 
              // push this item to our final output array
              output.push(item);
          }
      });
      // return our array which should be devoid of
      // any duplicates
      return output;
   };
})



.controller('View2Ctrl', ['$scope', 'MAIPSer', 'UserService', 'setFlag', '$rootScope', '$http','orderByFilter', function($scope, MAIPSer, UserService, setFlag, $rootScope, $http, orderBy) {
     setFlag.pageRefresh = true;
     if (localStorage.userid) {
          $scope.NoData = true;
          $scope.HaveData = true;
          var userID = {
               "user_id": localStorage.userid
          }

     $scope.topusername = localStorage.user_name;

     $scope.logout = function() {
          localStorage.userid = null;
          location.href = '#!/login';
     }

          

     $scope.AlluserDataArr = [];
     MAIPSer.getData(userID, function(resp) {
               if (resp.data.length != 0) {
                    for (var i = 0; i < resp.data.length; i++) {
                         var appid = {
                                   "app_id": resp.data[i].app_id
                              }
                              /************ USER Detail Service start *************/
                         MAIPSer.getParticularData(appid, function(response) {
                              $scope.AlluserDataArr.push({
                                   "app_id": response.data.app_id,
                                   "app_name": response.data.app_name,
                                   "app_backend": response.data.app_backend,
                                   "app_description": response.data.app_description,
                                   "app_features": response.data.app_features,
                                   "app_os": response.data.app_os,
                                   "app_owner_name": response.data.app_owner_name,
                                   "app_type": response.data.app_type,
                                   "date_created": response.data.date_created,
                                   "date_updated": response.data.date_updated,
                                   "status": response.data.status,
                                        "user_id": response.data.user_id,
                                       "app_users":response.data.app_users,
                                       "totallen":response.data.app_users.length

                              });
                              $scope.AlluserDataArrUserLength = $scope.AlluserDataArr.length;
                              function mycomparator(a, b) {
                                   return parseInt(a.app_id, 10) - parseInt(b.app_id, 10);
                              }
                              $scope.AlluserDataArr.sort(mycomparator);
                                   $scope.showDetailView('u2', $scope.AlluserDataArr[$scope.AlluserDataArr.length - 1])
                                   $scope.HaveData = false;
                              })

                         /************ USER Detail Service End *************/



                         }
                    } else {
                         $scope.NoData = false;
                         $scope.HaveData = true;
                    }
               })
               /*************************Default User Service start *******************/
          $scope.defaultUserArr = [];
          $scope.appuserslength = 0;
          MAIPSer.getDefaultUser(function(resp) {
               for (var k = 0; k < resp.data.length; k++) {
                    $scope.defaultUserArr.push({
                         "app_id": resp.data[k].app_id,
                         "user_email": resp.data[k].user_email,
                         "user_name": resp.data[k].user_name
                    })
               }

               $scope.appuserslength = $scope.defaultUserArr.length;
          })

          /*************************Default User Service End *******************/

          $scope.showDetailView = function(flag, param) {
               $scope.individualArr = [];
                  var appid = {
                                        "app_id": param
                                   }
             

               if (flag == 'u1') {
                    MAIPSer.getParticularData(appid,function(resp){
                   $scope.individualArr.push({
                                   "app_id": resp.data.app_id,
                                   "app_name": resp.data.app_name,
                                   "app_backend": resp.data.app_backend,
                                   "app_description": resp.data.app_description,
                                   "app_features": resp.data.app_features,
                                   "app_os": resp.data.app_os,
                                   "app_owner_name": resp.data.app_owner_name,
                                   "app_type": resp.data.app_type,
                                   "date_created": resp.data.date_created,
                                   "date_updated": resp.data.date_updated,
                                   "status": resp.data.status,
                                   "user_id": resp.data.user_id
                              })
                   
                      $rootScope.getUserData = [];
                              for (var l = 0; l < resp.data.app_users.length; l++) {

                                   $rootScope.getUserData.push({
                                        "app_id": resp.data.app_users[l].app_id,
                                        "user_email": resp.data.app_users[l].user_email,
                                        "user_name": resp.data.app_users[l].user_name
                                   })
                              }
              })
                    for (var i = 0; i < $scope.AlluserDataArr.length; i++) {
                        
                        
                        
                         if ($scope.AlluserDataArr[i].app_id == param) {

                           

                              var allOs = $scope.AlluserDataArr[i].app_os;
                              var eOs = allOs.split(",");
                              var len = eOs.length;
                              $scope.osList = [];
                              for (var j = 0; j < len; j++) {
                                   $scope.osList.push(eOs[j])
                              }
                         }
                    }

                    
                 


               } else {
                    
                    $scope.individualArr.push({
                         "app_id": param.app_id,
                         "app_name": param.app_name,
                         "app_backend": param.app_backend,
                         "app_description": param.app_description,
                         "app_features": param.app_features,
                         "app_os": param.app_os,
                         "app_owner_name": param.app_owner_name,
                         "app_type": param.app_type,
                         "date_created": param.date_created,
                         "date_updated": param.date_updated,
                         "status": param.status,
                         "user_id": param.user_id
                    })
                    var allOs = param.app_os;
                    var eOs = allOs.split(",");
                    var len = eOs.length;
                    $scope.osList = [];
                    for (var j = 0; j < len; j++) {
                         $scope.osList.push(eOs[j])
                    }
                  $rootScope.getUserData = [];
                   for(var k=0; k<param.app_users.length; k++){
                       
                       $rootScope.getUserData.push({
                                        "app_id": param.app_users[k].app_id,
                                        "user_email": param.app_users[k].user_email,
                                        "user_name": param.app_users[k].user_name
                                   })
                   }

               }
          }
   
          
          $scope.clickToOpen = function() {
               $scope.checkedValue = []; 
               $scope.vNo=[];
               var inputElements=[];
               $scope.Vnum='';
               $scope.Vnum1='';
               $scope.Vnum2='';     
               $scope.appname=$(".detailLi .appName").text();
               $scope.desp=   $(".detailLi .Description").text();     
              
               inputElements = document.getElementsByClassName('messageCheckbox');
               for(var i=0; inputElements[i]; ++i){
                     if(inputElements[i].checked){
                         $scope.checkedValue.push(inputElements[i].name)

                     }
               }
               console.log($scope.checkedValue)
                if($scope.checkedValue.length=='1'){
                    if($scope.checkedValue[0] == 'iOS'){
                         $scope.Vnum=$("#iOS > div >input").val();
                        
                    }
                    if($scope.checkedValue[0] == 'Android'){
                         $scope.Vnum=$("#Android > div >input").val();
                         
                    }
                }
                if($scope.checkedValue.length=='2'){
                      $scope.Vnum1=$(".selectOs > ul >li:nth-child(1) > div >input").val();
                      $scope.Vnum2=$(".selectOs > ul >li:nth-child(2) > div >input").val();
                }
               $('#popupmodal').modal({backdrop: 'static', keyboard: false});
               $rootScope.$broadcast('selectedOs', {
                              someProp: $scope.checkedValue,
                              pro1:$scope.Vnum, 
                              pro2:$scope.Vnum1,
                              pro3:$scope.Vnum2 ,
                              pro4:$scope.appname,
                              pro5: $scope.desp // send whatever you want
                         });
          }
          $scope.adduserpopup = function(id) {
               $rootScope.appid = id;
               $('#adduserpopup').modal({
                    backdrop: 'static',
                    keyboard: false
               });
          }
          $scope.activeClass=function(param){
               var ef = document.getElementsByClassName("selectedLi");
               for (var i = 0; i < ef.length; i++) {
                    ef[i].className = '';
               }
               var el=document.getElementsByClassName("MyClass");
               for (var i = 0; i < el.length; i++) {
                   el[i].className='';
               }
               var newId="USER_"+param;
               document.getElementById(newId).className = "MyClass";
          }
          $scope.selection0 = [];
          $scope.toggleSelection0 = function toggleSelection(eachOS) {
          var idx = $scope.selection0.indexOf(eachOS);

          // is currently selected
          if (idx > -1) {
               $scope.selection0.splice(idx, 1);
          }

               // is newly selected
               else {
                    $scope.selection0.push(eachOS);
               }
               $scope.selectedOs = $scope.selection0.toString();
               var inputElements1=[];
               var checkedValue1 = [];
               inputElements1 = document.getElementsByClassName('messageCheckbox');
                   for(var i=0; inputElements1[i]; ++i){
                     if(inputElements1[i].checked){
                         checkedValue1.push(inputElements1[i].name)

                     }
               }
              if(checkedValue1.length>0){            
                  if(checkedValue1.length=='1'){
                       if(checkedValue1[0] == 'iOS' && $scope.osList.length==2){ 
                            console.log("log1")
                            $scope.stoppedTyping=function(){
                                 var textarea_value = $("#iOS .inputBox input").val();
                                if(textarea_value.length > 0) { 
                                 document.getElementById('releaseBuild').disabled = false; 
                                 } else { 
                                      document.getElementById('releaseBuild').disabled = true;
                                 } 
                            }
                            
                       }
                       if(checkedValue1[0] == 'iOS' && $scope.osList.length==1){ 
                            console.log("log1")
                            $scope.stoppedTyping=function(){
                                 var textarea_value = $("#iOS .inputBox input").val();
                                if(textarea_value.length > 0) { 
                                 document.getElementById('releaseBuild').disabled = false; 
                                 } else { 
                                      document.getElementById('releaseBuild').disabled = true;
                                 } 
                            }
                            
                       }
                       if(checkedValue1[0] == 'Android' && $scope.osList.length==2 && checkedValue1.length==2){
                            console.log("log3")
                            $scope.stoppedTyping=function(){
                                 var textarea_value = $("#Android .inputBox input").val();
                                 if(textarea_value.length > 0) { 
                                 document.getElementById('releaseBuild').disabled = false;
                                 console.log("log2")
                                 } else { 
                                      document.getElementById('releaseBuild').disabled = true;
                                      console.log("log0")
                                 }
                            }
                       }
                       if(checkedValue1[0] == 'Android' && $scope.osList.length==2 && checkedValue1.length==1){
                        var previoustext= $("#Android .inputBox input").val();
                        if($("#Android > input:checked").length > 0 && previoustext.length >0){
                          document.getElementById('releaseBuild').disabled = false;
                          console.log("log11")
                        }
                        else{
                          document.getElementById('releaseBuild').disabled = true;
                          console.log("log12")
                        }
                            console.log("log9")
                            $scope.stoppedTyping=function(){
                                 var textarea_value = $("#Android .inputBox input").val();
                                 if(textarea_value.length > 0) { 
                                 document.getElementById('releaseBuild').disabled = false;
                                 console.log("log2")
                                 } else { 
                                      document.getElementById('releaseBuild').disabled = true;
                                      console.log("log0")
                                 }
                            }
                       }
                       if(checkedValue1[0] == 'iOS' && $scope.osList.length==2 && checkedValue1.length==1){
                        var previoustext= $("#iOS .inputBox input").val();
                        if($("#iOS > input:checked").length > 0 && previoustext.length >0){
                          document.getElementById('releaseBuild').disabled = false;
                          console.log("log11")
                        }
                        else{
                          document.getElementById('releaseBuild').disabled = true;
                          console.log("log12")
                        }
                            console.log("log9")
                            $scope.stoppedTyping=function(){
                                 var textarea_value = $("#iOS .inputBox input").val();
                                 if(textarea_value.length > 0) { 
                                 document.getElementById('releaseBuild').disabled = false;
                                 console.log("log2")
                                 } else { 
                                      document.getElementById('releaseBuild').disabled = true;
                                      console.log("log0")
                                 }
                            }
                       }
                       if(checkedValue1[0] == 'Android' && $scope.osList.length==1){
                            console.log("log4")
                            $scope.stoppedTyping=function(){
                                 var textarea_value = $("#Android .inputBox input").val();
                                 if(textarea_value.length > 0) { 
                                 document.getElementById('releaseBuild').disabled = false;

                                   } else { 
                                        document.getElementById('releaseBuild').disabled = true;
                                   }
                              }
                         }

                   }

                  if(checkedValue1.length=='2'){
                       document.getElementById('releaseBuild').disabled = true;
                       $scope.stoppedTyping=function(){
                            var textarea_value = $("#Android .inputBox input").val();
                            var textarea_value1 = $("#iOS .inputBox input").val();
                            if(textarea_value.length > 0 && textarea_value1.length > 0) { 
                                 document.getElementById('releaseBuild').disabled = false; 
                            } 
                            else { 
                                 document.getElementById('releaseBuild').disabled = true;
                            }
                       }
                  }

               }
               if(checkedValue1.length==0){
                    document.getElementById("releaseBuild").disabled = true;
               }

          };
              $scope.removeUser = function(appid, email) {
               MAIPSer.removeUser(appid, email, function(resp) {
                    console.log("deleted successfully.")
                    for (var i = 0; i < $scope.getUserData.length; ++i) {
                         if ($scope.getUserData[i].user_email == email) {
                              $scope.getUserData.splice(i, 1);
                         }
                    }
                   for(var x=0; x<$scope.AlluserDataArr.length; x++){
                       for(var y=0;y<$scope.AlluserDataArr[x].app_users.length; y++){
                           if($scope.AlluserDataArr[x].app_users[y].user_email == email){
                            $scope.AlluserDataArr[x].app_users.splice(y,1);
                           }
                       }
                   }
               }, function(resp) {
                    console.log("not deleted.")
               })
          }


          $scope.sortByemail = function(user_email) {
            $scope.reverse = (user_email !== null && $scope.user_email === user_email)
                ? !$scope.reverse : true;
            $scope.user_email = user_email;
            $scope.getUserData = orderBy($scope.getUserData, $scope.user_email, $scope.reverse);
          };
          $scope.sortByname = function(user_name) {
            $scope.reverse1 = (user_name !== null && $scope.user_name === user_name)
                ? !$scope.reverse1 : true;
            $scope.user_name = user_name;
            $scope.getUserData = orderBy($scope.getUserData, $scope.user_name, $scope.reverse1);
          };
          $scope.createApplication = function() {
			   localStorage.removeItem('selectApp');
			   localStorage.removeItem('createApp');
			   localStorage.removeItem('choosefeature');
			   localStorage.removeItem('selectBackend');
			   localStorage.removeItem('chooseOS');
			   localStorage.removeItem('user_names');
			   localStorage.removeItem('usernames');
               location.href = '#!/selectapp';
          }
     } else {
          location.href = '#!/login';
     }
}]);
