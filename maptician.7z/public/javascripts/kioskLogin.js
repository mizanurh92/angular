$(document).ready(function(){

	populateFields();

	$('#loginForm.FlowupLabels').FlowupLabels({
		class_focused:"focused-narrow",
		class_populated:"populated-narrow"
	});

	var loginValidator = $("#loginForm").validate({
		rules: {
			companyName: {
				required: true,
				minlength: 3,
				maxlength: 50
			},
			userName: {
				required: true,
			},
			password: {
				required: true,
			}
		},
		messages: {
			companyName:{
				required: "Please enter your company name",
				minlength: "Invalid company name",
				maxlength: "Invalid company name"
			},
			userName:{
				required: "Please enter a user name for the kiosk"
			},
			password:{
				required: "Please enter a password"
			}
		},
		submitHandler:function(form,event){
			var data = {
				company: $('#company').val(),
				username: $('#userName').val(),
				password: $('#password').val(),
			}
			var checked = $("#rememberMe").prop('checked');
			if(checked){
				setCookies();
			} else {
				unsetCookies();
			}			
			$("#spinnerIcon").css("display","block");
			$.ajax({
				type:"POST",
				url: "/kioskLogin",
				data:data,
				dataType:'json',
				success:function(data){
					console.log('success',data)
					if(data.login){
						$("#errorMsg").hide();
						window.location = "./";
					} else {
						$("#errorMsg").html(data.err).show();
						$("#spinnerIcon").hide();
					}
				}
			})
		}
	})

	$("#rememberMe").on('change',function(e){
		var checked = $("#rememberMe").prop('checked');
		if(checked){
			setCookies();
		} else {
			unsetCookies();
		}

	})

})



function setCookies(){
    var days = 365;
    var d = new Date();
    d.setTime(d.getTime() + (days*24*60*60*1000));
    var expires = "expires="+ d.toUTCString();
    var company = $('#company').val();
    var userName = $('#userName').val();
    document.cookie = 'company' + "=" + company + ";" + expires + ";path=/";
    document.cookie = 'userName' + "=" + userName + ";" + expires + ";path=/";
}

function unsetCookies(){
    var d = new Date();
    d.setTime(d.getTime() - (24*60*60*1000));
    var expires = "expires="+ d.toUTCString();
    document.cookie = 'company' + "=;" + expires + ";path=/";
    document.cookie = 'userName' + "=;" + expires + ";path=/";
}

function getCookie(cname) {
    var name = cname + "=";
    var decodedCookie = decodeURIComponent(document.cookie);
    var ca = decodedCookie.split(';');
    for(var i = 0; i <ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0) == ' ') {
            c = c.substring(1);
        }
        if (c.indexOf(name) == 0) {
            return c.substring(name.length, c.length);
        }
    }
    return "";
}

function populateFields(){ // Checks to see if either a Cookie or URI Path variable provides login credentials
	var vars = {};

	if(document.cookie){
		vars.company = getCookie('company');
		vars.userName = getCookie('userName');
		$("#rememberMe").prop('checked',true);
	}

	// Parse the url for variables.  Priority give to these vs. cookie based data.
	var q = document.URL.split('?')[1];
	var hash;
	if(q != undefined){
		q = q.split('&');
		for(var i = 0; i < q.length; i++){
			hash = q[i].split('=');
			vars[hash[0]] = decodeURIComponent(hash[1]);
		}
	}

	vars.company && $('#company').val(vars.company);
	vars.user && $('#username').val(vars.user);
}