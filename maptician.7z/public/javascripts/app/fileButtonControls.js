Maptician.inits.editorButtonControls = function(progController){
	
    // ########################################## New Map #################################################

    $("#newMap,#quickCreateMap").click(function(){
        if(Maptician.Editor){
            Maptician.Modals.newMap();
        }
    })

    // ########################################## Load Map #################################################
            
    $("#loadMap,#quickLoadMap").click(function(){ // Gets the file names and displays them in a load files modal
        Maptician.ModalTables.loadFileTable("editor");
    })

    // ########################################## Save Map #################################################

    $("#saveMap").click(function(){
        if(Maptician.Editor){
            progController.saveMap();
        }
    })

    // ########################################## Close Map #################################################

    $("#closeMap").click(function(){
        if(Maptician.Editor){
            progController.closeFile();
        }
    })

    // ########################################## Branch Map #################################################

    $("#branchMap").click(function(){
        if(Maptician.Editor){
            progController.branchMap();
        }
    })

    // ########################################## Map Live Status #################################################

    $("#toggleLive").click(function(){
        if(Maptician.Editor){
            progController.toggleLive();
        }
    })

    // ########################################## Branch Map #################################################

    $("#createScenario").click(function(){
        if(Maptician.Editor){
            progController.branchScenario();
        }
    })

}