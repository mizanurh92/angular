//#################################  Button Panel Controller #####################################################
Maptician.buttons = {};
Maptician.buttons.radioButtonBar = function(buttonBar,buttonPanels){
	// buttonPanels is an array of panels that will be activated when the button is pressed
    $("#"+buttonBar+".MainNav li").click(function(){
        var button = $(this);
        var parent = button.parent();
        var siblings = parent.find('li');
        var index = siblings.index(this);
        siblings.removeClass('MainNav-Button_LeftOfActive MainNav-Button_RightOfActive MainNav-Button_Active');
        button.addClass('MainNav-Button_Active');
        button.prev().addClass('MainNav-Button_LeftOfActive');
        button.next().addClass('MainNav-Button_RightOfActive');
        for(var i = 0; i < buttonPanels.length;i++){
        	if(i == index){
        		$("#"+buttonPanels[i]).css({display:"block"});
        	} else {
        		$("#"+buttonPanels[i]).css({display:"none"});
        	}
        }
    })
}

Maptician.buttons.radioButtonBar2 = function(buttonBar,buttonPanelWrapper){
    // buttonPanels is an array of panels that will be activated when the button is pressed
    $("#"+buttonBar+".MainNav li").click(function(){
        var button = $(this);
        var parent = button.parent();
        var siblings = parent.find('li');
        var index = siblings.index(this);
        siblings.removeClass('MainNav-Button_LeftOfActive MainNav-Button_RightOfActive MainNav-Button_Active');
        button.addClass('MainNav-Button_Active');
        button.prev().addClass('MainNav-Button_LeftOfActive');
        button.next().addClass('MainNav-Button_RightOfActive');
        for(var i = 0; i < buttonPanels.length;i++){
            if(i == index){
                $("#"+buttonPanels[i]).css({display:"block"});
            } else {
                $("#"+buttonPanels[i]).css({display:"none"});
            }
        }
    })
}

Maptician.buttons.buttonBar = function(buttonBar){
	$("#"+buttonBar+".MainNav li").on("mousedown",function(){
		var button = $(this);
        button.addClass('MainNav-Button_Active');
        button.prev().addClass('MainNav-Button_LeftOfActive');
        button.next().addClass('MainNav-Button_RightOfActive');
	})

	$("#"+buttonBar+".MainNav li").on("mouseup mouseleave",function(){
		var button = $(this);
        var parent = button.parent();
        var siblings = parent.find('li');
        siblings.removeClass('MainNav-Button_LeftOfActive MainNav-Button_RightOfActive MainNav-Button_Active');
	})
}