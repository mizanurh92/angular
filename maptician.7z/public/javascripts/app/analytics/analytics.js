$Map.Analytics = {};
$Map.Analytics.Offices = {};
$Map.Analytics.Offices.Seats = {};
$Map.Analytics.Offices.Rooms = {};


///////////////////// Office Based Analytics ///////////////////////////////////


$Map.Analytics.Offices.Seats.seatCapacityTypeByDay = function(options){
	options = options || {};
	var officeID = options.officeID;
	var analysis = Maptician.Analytics.Offices.Seats.seatCapacityTypeByDay;
	var group = "seatCapacityTypeByDay";
	var fileName = 'seat_capacity_type_by_day';
	var url = "../api/analytics/capacity/seatCapacityTypeByDay";
	var numberFormat = d3.format(".0f");
	var decimalFormat = d3.format(".2f");
	var dateFormat = d3.time.format("%Y-%m-%d");
	var shortDate = d3.time.format("%b-%d '%y");
	var longDate = d3.time.format("%B %d, %Y");
	var analyticsWrapper = $("#officeSeatAnalytics");
	var downloadButton = analyticsWrapper.find('.download-btn');
	var main = analyticsWrapper.find('.main-chart');
	var mainTable = main.find('.main-table');
	var mainBrush = main.find('.main-areaBrush');
	var tile1 = analyticsWrapper.find('.tile-1');
	var tile2 = analyticsWrapper.find('.tile-2');
	var tile3 = analyticsWrapper.find('.tile-3');
	var tile4 = analyticsWrapper.find('.tile-4');
	var tile5 = analyticsWrapper.find('.tile-5');
	var tile6 = analyticsWrapper.find('.tile-6');
	var reset = analyticsWrapper.find('.reset');
	var start;
	var end = new Date(moment().endOf('day').subtract(12,'h').valueOf());
	var formatResults = function(result){
		var formatted = [];
		var tempObj;
		result.forEach(function (d) {
	        d.date = 1*d.date; // Coerce to number
	        if(start){ // Finds the earliest date in the results
	        	start = d.date < start ? d.date : start;
	        } else { start = d.date; }
			
			tempObj = {
				date: new Date(moment(d.date).startOf('day').add(1,'hour').valueOf()),
				department: d.department,
				floor: d.floor,
				suite: d.suite,
				map: d.mapName
			}
			d.reservable ? tempObj.reservable = d.reservable : null;
			d.assigned ? tempObj.assigned = d.assigned : null;
			d.unassigned ? tempObj.unassigned = d.unassigned : null;
			formatted.push(tempObj)	        
    	});	
    	return formatted;		
	}

	if(analysis.hasInit && options.unload){ // If an unload option is passed, the charts and all related objects are unloaded
		console.log('type unload')
		dc.deregisterChart(analysis.mainArea,group);
		dc.deregisterChart(analysis.mainBrush,group);
		dc.deregisterChart(analysis.capacityType,group);
		dc.deregisterChart(analysis.department,group);
		dc.deregisterChart(analysis.map,group);
		dc.deregisterChart(analysis.floor,group);
		dc.deregisterChart(analysis.suite,group);
		analysis.mainArea = null;
		analysis.mainBrush = null;
		analysis.capacityType = null;
		analysis.department = null;
		analysis.suite = null;
		analysis.floor = null;
		analysis.map = null;		
		mainTable.find("svg").remove();
		mainBrush.find("svg").remove();
		tile1.find("select").remove();
		tile2.find("select").remove();
		tile3.find("select").remove();
		tile4.find("select").remove();
		tile5.find("select").remove();
		analysis.data = null;
		analysis.mainDim = null;
		analysis.groups = null;
		analysis.capacityTypeDim = null;
		analysis.capacityTypeGroup = null;
		analysis.deptDim = null;
		analysis.deptGroup = null;
		analysis.suiteDim = null;
		analysis.suiteGroup = null;
		analysis.floorDim = null;
		analysis.floorGroup = null;
		analysis.mapDim = null;
		analysis.mapGroup = null;
		analysis.hasInit = false;
		reset.off('click');
		downloadButton.off('click');
		start = undefined;
		return;
	} else if(options.unload){ // 
		return;
	}

	main.css({display:"inline-block"}).find(".header").html("Seat Allocation By Day");
	tile1.css({display:"inline-flex"}).find(".header").html("Capacity Types");
	tile2.css({display:"inline-block"}).find(".header").html("Departments");
	tile3.css({display:"inline-block"}).find(".header").html("Maps");
	tile4.css({display:"inline-block"}).find(".header").html("Floors");
	tile5.css({display:"inline-block"}).find(".header").html("Suites");
	tile6.hide().find(".header").html("");

	if(analysis.hasInit){
		if(officeID != analysis.officeID){ // Only reloads if a new office was selected
			analysis.officeID = officeID;
			$.ajax({
				url: url,
				type: "GET",
				data: {officeID:analysis.officeID},
				success: function (result) {
					analysis.officeID = officeID;
					var formatted = formatResults(result);
					console.log('type reloaded data')
					console.log('type start:',start)
					try{
						analysis.data.remove();
						analysis.data.add(formatted);
					} catch(err){
						console.log(err)
					}
					dc.renderAll(group);
				}
			})			
		}
		return;
	}

	analysis.mainArea = dc.lineChart(mainTable[0],group);
	analysis.mainBrush = dc.lineChart(mainBrush[0],group);
	analysis.capacityType = dc.selectMenu(tile1[0],group);
	analysis.department = dc.selectMenu(tile2[0],group);
	analysis.map = dc.selectMenu(tile3[0],group);
	analysis.floor = dc.selectMenu(tile4[0],group);
	analysis.suite = dc.selectMenu(tile5[0],group);

	$.ajax({
		url: url,
		type: "GET",
		data: {officeID:officeID},
		success: function (result) {

		analysis.officeID = officeID;
		var formatted = formatResults(result);
		console.log(start)
    	start = new Date(moment(start).startOf('day').subtract(12,'h').valueOf()); // Start of the earliest day of data

		// Formatting the JSON result for crossfilter and grouping the data
		analysis.data = crossfilter(formatted);

	    // Dimensions and group for main chart
	    analysis.mainDim = analysis.data.dimension(function (d) {
	        return d.date;
	    });
	    analysis.groups = analysis.mainDim.group().reduce(
	        function (p, v) { /* callback for when data is added to the current filter results */
	            var reservable = v.reservable ? v.reservable : 0;
	            var assigned = v.assigned ? v.assigned : 0;
	            var unassigned = v.unassigned ? v.unassigned : 0;
	            p.count += reservable + assigned + unassigned;
	            p.reservable += reservable;
	            p.assignable += assigned + unassigned;
	            p.assigned += assigned;
	            p.unassigned += unassigned;
	            p.percentReservable = p.count ? (p.reservable / p.count) * 100 : 0;
	            p.percentAssignable = p.count ? (p.assignable / p.count) * 100 : 0;
	            p.percentAssigned = p.count ? (p.assigned / p.count) * 100 : 0;
	            p.percentUnassigned = p.count ? (p.unassigned / p.count) * 100 : 0;
	            return p;
	        }, /* callback for when data is removed from the current filter results */
	        function (p, v) {
	            var reservable = v.reservable ? v.reservable : 0;
	            var assigned = v.assigned ? v.assigned : 0;
	            var unassigned = v.unassigned ? v.unassigned : 0;
	            p.count -= reservable + assigned + unassigned;
	            p.reservable -= reservable;
	            p.assignable -= assigned + unassigned;
	            p.assigned -= assigned;
	            p.unassigned -= unassigned;
	            p.percentReservable = p.count ? (p.reservable / p.count) * 100 : 0;
	            p.percentAssignable = p.count ? (p.assignable / p.count) * 100 : 0;
	            p.percentAssigned = p.count ? (p.assigned / p.count) * 100 : 0;
	            p.percentUnassigned = p.count ? (p.unassigned / p.count) * 100 : 0;
	            return p;
	        }, /* initialize p */
	        function () {
	            return {
	                count: 0,
	                reservable: 0,
	                assignable: 0,
	                assigned: 0,
	                unassigned: 0,
	                percentReservable: 0,
	                percentAssignable: 0,
	                percentAssigned: 0,
	                percentUnassigned: 0
	            };
	        }
	    );

		analysis.capacityTypeDim = analysis.data.dimension(function (d) {
			if(d.reservable){return 'Reservable';}
			if(d.assigned){return 'Assigned';}
			if(d.unassigned){return 'Unassigned';}
		});
		analysis.capacityTypeGroup = analysis.capacityTypeDim.group();

		analysis.departmentDim = analysis.data.dimension(function (d) {
			return d.department;
		});
		analysis.departmentGroup = analysis.departmentDim.group();

		analysis.mapDim = analysis.data.dimension(function (d) {
			return d.map;
		});
		analysis.mapGroup = analysis.mapDim.group();	

		analysis.floorDim = analysis.data.dimension(function (d) {
			return d.floor;
		});
		analysis.floorGroup = analysis.floorDim.group();

		analysis.suiteDim = analysis.data.dimension(function (d) {
			return d.suite;
		});
		analysis.suiteGroup = analysis.suiteDim.group();

	    analysis.mainArea
	    	.renderArea(true)
	        .width(1000)
	        .height(320)
			.useViewBoxResizing(true)
	        .transitionDuration(1000)
	        .margins({top: 20, right: 20, bottom: 20, left: 30})
	        .dimension(analysis.mainDim)
	        .mouseZoomable(false)
	        .rangeChart(analysis.mainBrush)
	        .x(d3.time.scale().domain([start,end]))
	        .xUnits(d3.time.days)
	        .round(d3.time.day.round)
	        .elasticY(true)
	        .renderHorizontalGridLines(true)
	        .legend(dc.legend().x(850).y(0).itemHeight(13).gap(5))
	        .brushOn(false)
	        .group(analysis.groups, 'Assigned Capacity')
	        .valueAccessor(function (d) {return d.value.assigned;})
	        .stack(analysis.groups, 'Available Capacity', function (d) {return d.value.unassigned;})
	        .stack(analysis.groups, 'Reservable Capacity', function (d) {return d.value.reservable;})	        
	        .title(function (d) {
	             return dateFormat(d.key) + '\n' +
	             "Total: " + numberFormat(d.value.count) + '\n' +
	             "Assigned: " + numberFormat(d.value.assigned) + '\n' +
	             "Available: " + numberFormat(d.value.unassigned) + '\n' +
	             "Reservable: " + numberFormat(d.value.reservable);
	        })
	        .xAxis().tickFormat(shortDate).tickValues(
	    			function(){
						var filters = analysis.mainBrush.filters();
						if(filters.length){
							var range = filters[0];
							var days = moment.duration(moment.preciseDiff(range[0],range[1],true)).asDays();
							var step = Math.ceil(days/10);
							return getTicks(range[0],range[1],{step:step});
						} else {
							var days = moment.duration(moment.preciseDiff(start,end,true)).asDays();
							var step = Math.ceil(days/10);
							return getTicks(start,end,{step:step});
						}
	    			}
	    		)

	    analysis.mainBrush
	    	.renderArea(true)
	    	.width(1000)
	        .height(80)
			.useViewBoxResizing(true)
	    	.mouseZoomable(false)
	        .transitionDuration(1000)
	        .margins({top: 10, right: 20, bottom: 20, left: 30})
	        .dimension(analysis.mainDim)
	        .group(analysis.groups, 'Total Capacity')
	        .valueAccessor(function (d) {return d.value.count;})
	        .x(d3.time.scale().domain([start,end]))
	        .elasticY(true)
	        .renderHorizontalGridLines(false)
	        //.round(d3.time.day.round)
	        //.xUnits(d3.time.days)
	        .yAxis().tickValues([]).outerTickSize(0);
	    analysis.mainBrush
	    	.xAxis().tickFormat(shortDate).tickValues(
	    			function(){
						var days = moment.duration(moment.preciseDiff(start,end,true)).asDays();
						var step = Math.floor(days/10);
						return getTicks(start,end,{step:step});
	    			}
	    		)

	    analysis.capacityType
           	.dimension(analysis.capacityTypeDim)
           	.group(analysis.capacityTypeGroup)
           	.multiple(true)
			.title(function (d){return d.key;})

		analysis.department
           	.dimension(analysis.departmentDim)
           	.group(analysis.departmentGroup)
           	.multiple(true)
			.title(function (d){return d.key;})

		analysis.map
           	.dimension(analysis.mapDim)
           	.group(analysis.mapGroup)
           	.multiple(true)
			.title(function (d){return d.key;})

		analysis.floor
           	.dimension(analysis.floorDim)
           	.group(analysis.floorGroup)
           	.multiple(true)
			.title(function (d){return d.key;})

		analysis.suite
           	.dimension(analysis.suiteDim)
           	.group(analysis.suiteGroup)
           	.multiple(true)
			.title(function (d){return d.key;})

	    dc.renderAll(group);
	}});

	if(analysis.hasInit){

	} else {
		reset.on('click',function(){
			dc.filterAll(group);
			dc.redrawAll(group);
		})

		downloadButton.on('click',function(){
	        var data = analysis.mainDim.top(Infinity);
	        data = data.map(function(d){
	        	var formatted = {
	        		Date: longDate(d.date),
	        		Department: d.department,
	        		Map: d.map,
	        		Suite: d.suite,
	        		Floor: d.floor,
	        		Seats: d.capacity
	        	}
	        	return formatted;
	        })
	        var blob = new Blob([d3.csv.format(data)], {type: "text/csv;charset=utf-8"});
	        saveAs(blob, fileName+'.csv');
		})

		analysis.hasInit = true;
	}
}

$Map.Analytics.Offices.Seats.seatCapacityByDay = function(options){
	options = options || {};
	var officeID = options.officeID;
	var analysis = Maptician.Analytics.Offices.Seats.seatCapacityByDay;
	var group = "seatCapacityByDay";
	var fileName = 'seat_capacity_by_day';
	var url = "../api/analytics/capacity/seatCapacityByDay";
	var numberFormat = d3.format(".0f");
	var decimalFormat = d3.format(".2f");
	var dateFormat = d3.time.format("%Y-%m-%d");
	var shortDate = d3.time.format("%b-%d '%y");
	var longDate = d3.time.format("%B %d, %Y");
	var analyticsWrapper = $("#officeSeatAnalytics");
	var downloadButton = analyticsWrapper.find('.download-btn');
	var main = analyticsWrapper.find('.main-chart');
	var mainTable = main.find('.main-table');
	var mainBrush = main.find('.main-areaBrush');
	var tile1 = analyticsWrapper.find('.tile-1');
	var tile2 = analyticsWrapper.find('.tile-2');
	var tile3 = analyticsWrapper.find('.tile-3');
	var tile4 = analyticsWrapper.find('.tile-4');
	var tile5 = analyticsWrapper.find('.tile-5');
	var tile6 = analyticsWrapper.find('.tile-6');
	var reset = analyticsWrapper.find('.reset');
	var start;
	var end = new Date(moment().endOf('day').subtract(12,'h').valueOf());
	var formatResults = function(result){
		var formatted = [];
		result.forEach(function (d) {
	        d.date = 1 * d.date; // Coerce to number
	        if(start){ // Finds the earliest date in the results
	        	start = d.date < start ? d.date : start;
	        } else { start = d.date; }
			formatted.push({
				date: new Date(moment(d.date).startOf('day').add(1,'hour').valueOf()),
				map: d.mapName,
				suite: d.suite,
				floor: d.floor,
				capacity: d.capacity,
				department: d.department
			})	        
    	});	
    	return formatted;		
	}

	// If an unload option is passed, the charts and all related objects are unloaded
	if(analysis.hasInit && options.unload){ 
		dc.deregisterChart(analysis.mainBar,group);
		dc.deregisterChart(analysis.mainBrush,group);
		dc.deregisterChart(analysis.averageCapacity,group);
		dc.deregisterChart(analysis.department,group);
		dc.deregisterChart(analysis.suite,group);
		dc.deregisterChart(analysis.floor,group);
		dc.deregisterChart(analysis.map,group);
		analysis.mainBar = null;
		analysis.mainBrush = null;
		analysis.averageCapacity = null;
		analysis.department = null;
		analysis.suite = null;
		analysis.floor = null;
		analysis.map = null;
		mainTable.find("svg").remove();
		mainBrush.find("svg").remove();
		tile1.find("span").remove();
		tile2.find("select").remove();
		tile3.find("select").remove();
		tile4.find("select").remove();
		tile5.find("select").remove();
		analysis.data = null;
		analysis.all = null;
		analysis.mainDim = null;
		analysis.groups = null;
		analysis.groupAll = null;
		analysis.deptDim = null;
		analysis.deptGroup = null;
		analysis.suiteDim = null;
		analysis.suiteGroup = null;
		analysis.floorDim = null;
		analysis.floorGroup = null;
		analysis.mapDim = null;
		analysis.mapGroup = null;
		analysis.hasInit = false;
		reset.off('click');
		downloadButton.off('click');
		start = undefined;
		return;
	} else if(options.unload){ // 
		return;
	}

	main.css({display:"inline-block"}).find(".header").html("Seat Capacity By Day");
	tile1.css({display:"inline-flex"}).find(".header").html("Average Capacity");
	tile2.css({display:"inline-block"}).find(".header").html("Departments");
	tile3.css({display:"inline-block"}).find(".header").html("Suites");
	tile4.css({display:"inline-block"}).find(".header").html("Floors");
	tile5.css({display:"inline-block"}).find(".header").html("Maps");
	tile6.hide().find(".header").html("");

	if(analysis.hasInit){
		if(officeID != analysis.officeID){ // Only reloads if a new office was selected
			analysis.officeID = officeID;
			$.ajax({
				url: url,
				type: "GET",
				data: {officeID:analysis.officeID},
				success: function (result) {
					analysis.officeID = officeID;
					var formatted = formatResults(result);
					analysis.data.remove();
					analysis.data.add(formatted);
					dc.renderAll(group);
				}
			})			
		}
		return;
	}

	analysis.mainBar = dc.barChart(mainTable[0],group);
	analysis.mainBrush = dc.lineChart(mainBrush[0],group);
	analysis.averageCapacity = dc.numberDisplay(tile1[0],group);
	analysis.department = dc.selectMenu(tile2[0],group);
	analysis.suite = dc.selectMenu(tile3[0],group);
	analysis.floor = dc.selectMenu(tile4[0],group);
	analysis.map = dc.selectMenu(tile5[0],group);

	$.ajax({
		url: url,
		type: "GET",
		data: {officeID:officeID},
		success: function (result) {

		analysis.officeID = officeID;
		var formatted = formatResults(result);

    	start = new Date(moment(start).startOf('day').subtract(12,'h').valueOf());

		// Formatting the JSON result for crossfilter and grouping the data
		analysis.data = crossfilter(formatted);

	    // Dimensions and group for main chart
	    analysis.mainDim = analysis.data.dimension(function (d) {
	        return d.date;
	    });
	    analysis.groups = analysis.mainDim.group().reduce(
	        function (p, v) { /* callback for when data is added to the current filter results */
	            p.capacity += v.capacity;
	            return p;
	        }, /* callback for when data is removed from the current filter results */
	        function (p, v) {
	            p.capacity -= v.capacity;
	            return p;
	        }, /* initialize p */
	        function () {
	            return {
	                capacity: 0
	            };
	        }
	    );

	    // Group for Utilization (no dimension needed since it's a single value)
	    var filters, days, range;
	    analysis.groupAll = analysis.data.groupAll().reduce(
	        function (p, v) { /* callback for when data is added to the current filter results */
				filters = analysis.mainBrush.filters();
				days = filters.length ? daysBetween(filters[0][0],filters[0][1]) : daysBetween(start,end);
	            p.capacity += v.capacity;
	            p.average = p.capacity / days;
	            return p;
	        }, /* callback for when data is removed from the current filter results */
	        function (p, v) {
				filters = analysis.mainBrush.filters();
				days = filters.length ? daysBetween(filters[0][0],filters[0][1]) : daysBetween(start,end);
	            p.capacity -= v.capacity;
	            p.average = p.capacity / days;
	            return p;
	        },
	        function () { /* initialize p */
	            return {
	                capacity: 0,
	                average: 0
	            };
	        }
	    )

		analysis.deptDim = analysis.data.dimension(function (d) {
			return d.department ? d.department : "Unassigned";
		});
		analysis.deptGroup = analysis.deptDim.group();

		analysis.suiteDim = analysis.data.dimension(function (d) {
			return d.suite ? d.suite : "Other";
		});
		analysis.suiteGroup = analysis.suiteDim.group();

		analysis.floorDim = analysis.data.dimension(function (d) {
			return d.floor ? d.floor : "Other";
		});
		analysis.floorGroup = analysis.floorDim.group();

		analysis.mapDim = analysis.data.dimension(function (d) {
			return d.map ? d.map : "Other";
		});
		analysis.mapGroup = analysis.mapDim.group();


	    analysis.mainBar
	        .width(1000)
	        .height(320)
	        .centerBar(true)
			.useViewBoxResizing(true)
	        .transitionDuration(1000)
	        .margins({top: 20, right: 20, bottom: 20, left: 30})
	        .dimension(analysis.mainDim)
	        .mouseZoomable(false)
	        .rangeChart(analysis.mainBrush)
	        .x(d3.time.scale().domain([start,end]))
			.xUnits(d3.time.days)
	        .elasticY(true)
	        .renderHorizontalGridLines(true)
	        .legend(dc.legend().x(850).y(-20).itemHeight(13).gap(5))
	        .brushOn(false)
	        .group(analysis.groups, 'Seat Capacity')
	        .valueAccessor(function (d) {
	        	return d.value.capacity;
	        })    
	        .title(function (d) {
	             return longDate(d.key) + '\n' +
	             "Seats: " + numberFormat(d.value.capacity);
	        })
	    	.xAxis().tickFormat(shortDate).tickValues(
	    			function(){
						var filters = analysis.mainBrush.filters();
						if(filters.length){
							var range = filters[0];
							var days = moment.duration(moment.preciseDiff(range[0],range[1],true)).asDays();
							var step = Math.ceil(days/10);
							return getTicks(range[0],range[1],{step:step});
						} else {
							var days = moment.duration(moment.preciseDiff(start,end,true)).asDays();
							var step = Math.ceil(days/10);
							return getTicks(start,end,{step:step});
						}
	    			}
	    		)

	    analysis.mainBrush
	    	.renderArea(true)
	    	.width(1000)
	        .height(80)
			.useViewBoxResizing(true)
	    	.mouseZoomable(false)
	        .transitionDuration(1000)
	        .margins({top: 10, right: 20, bottom: 20, left: 30})
	        .dimension(analysis.mainDim)
	        .group(analysis.groups, 'Seat Capacity')
	        .valueAccessor(function (d) {return d.value.capacity;})
	        .x(d3.time.scale().domain([start,end]))
	        .elasticY(true)
	        .renderHorizontalGridLines(false)
	        .round(d3.time.day.round)
	        .xUnits(d3.time.days)
	        .yAxis().tickValues([]).outerTickSize(0);
	    analysis.mainBrush
	    	.xAxis().tickFormat(shortDate).tickValues(
	    			function(){
						var days = moment.duration(moment.preciseDiff(start,end,true)).asDays();
						var step = Math.floor(days/10);
						return getTicks(start,end,{step:step});
	    			}
	    		)

		analysis.averageCapacity
			.group(analysis.groupAll)
			.formatNumber(decimalFormat)
			.valueAccessor(function (p) {return p.average;})		

	    analysis.department
           	.dimension(analysis.deptDim)
           	.group(analysis.deptGroup)
           	.multiple(true)
           	.title(function(d){return d.key;})

	    analysis.suite
           	.dimension(analysis.suiteDim)
           	.group(analysis.suiteGroup)
           	.multiple(true)
           	.title(function(d){return d.key;})

	    analysis.floor
           	.dimension(analysis.floorDim)
           	.group(analysis.floorGroup)
           	.multiple(true)
           	.title(function(d){return d.key;})

	    analysis.map
           	.dimension(analysis.mapDim)
           	.group(analysis.mapGroup)
           	.multiple(true)
           	.title(function(d){return d.key;})

	    dc.renderAll(group);
	}});

	if(analysis.hasInit){

	} else {
		reset.on('click',function(){
			dc.filterAll(group);
			dc.redrawAll(group);
		})

		downloadButton.on('click',function(){
	        var data = analysis.mainDim.top(Infinity);
	        data = data.map(function(d){
	        	var formatted = {
	        		Date: longDate(d.date),
	        		Department: d.department,
	        		Map: d.map,
	        		Suite: d.suite,
	        		Floor: d.floor,
	        		Seats: d.capacity
	        	}
	        	return formatted;
	        })
	        var blob = new Blob([d3.csv.format(data)], {type: "text/csv;charset=utf-8"});
	        saveAs(blob, fileName+'.csv');
		})

		analysis.hasInit = true;
	}	
}

$Map.Analytics.Offices.Seats.seatReservationUsageByDay = function(options){
	options = options || {};
	var officeID = options.officeID;
	var analysis = $Map.Analytics.Offices.Seats.seatReservationUsageByDay;
	var group = "seatReservationUsageByDay";
	var fileName = 'daily_seat_reservation_usage';
	var url = "../api/analytics/capacity/seatReservationUsageByDay";
	var numberFormat = d3.format(".0f");
	var decimalFormat = d3.format(".2f");
	var dateFormat = d3.time.format("%Y-%m-%d");
	var shortDate = d3.time.format("%b-%d '%y");
	var longDate = d3.time.format("%B %d, %Y");
	var analyticsWrapper = $("#officeSeatAnalytics");
	var downloadButton = analyticsWrapper.find('.download-btn');
	var main = analyticsWrapper.find('.main-chart');
	var mainTable = main.find('.main-table');
	var mainBrush = main.find('.main-areaBrush');
	var tile1 = analyticsWrapper.find('.tile-1');
	var tile2 = analyticsWrapper.find('.tile-2');
	var tile3 = analyticsWrapper.find('.tile-3');
	var tile4 = analyticsWrapper.find('.tile-4');
	var tile5 = analyticsWrapper.find('.tile-5');
	var tile6 = analyticsWrapper.find('.tile-6');
	var reset = analyticsWrapper.find('.reset');
	var start;
	var end = new Date(moment().endOf('day').subtract(12,'h').valueOf());
	var formatResults = function(result){
		var formatted = [];
		result.forEach(function (d) {
	        d.d = 1 * d.d; // Coerce to number
	        if(start){ // Finds the earliest date in the results
	        	start = d.d < start ? d.d : start;
	        } else { start = d.d; }
			formatted.push({
				date: new Date(moment(d.d).startOf('day').valueOf()),
				suite: d.st,
				floor: d.f,
				seat: d.sn,
				available: d.a,
				used: d.u,
				department: d.dpt
			})        
    	});	
    	return formatted;		
	}

	// If an unload option is passed, the charts and all related objects are unloaded
	if(analysis.hasInit && options.unload){ 
		dc.deregisterChart(analysis.mainBar,group);
		dc.deregisterChart(analysis.mainBrush,group);
		dc.deregisterChart(analysis.utilization,group);
		dc.deregisterChart(analysis.department,group);
		dc.deregisterChart(analysis.seat,group);
		dc.deregisterChart(analysis.floor,group);
		dc.deregisterChart(analysis.suite,group);
		analysis.mainBar = null;
		analysis.mainBrush = null;
		analysis.utilization = null;
		analysis.department = null;
		analysis.seat = null;
		analysis.floor = null;
		analysis.suite = null;
		mainTable.find("svg").remove();
		mainBrush.find("svg").remove();
		tile1.find("span").remove();
		tile2.find("select").remove();
		tile3.find("select").remove();
		tile4.find("select").remove();
		tile5.find("select").remove();
		analysis.data = null;
		analysis.all = null;
		analysis.mainDim = null;
		analysis.groups = null;
		analysis.groupAll = null;
		analysis.deptDim = null;
		analysis.deptGroup = null;
		analysis.suiteDim = null;
		analysis.suiteGroup = null;
		analysis.floorDim = null;
		analysis.floorGroup = null;
		analysis.seatDim = null;
		analysis.seatGroup = null;
		analysis.weekdayDim = null;
		analysis.weekdayGroup = null;
		analysis.hasInit = false;
		reset.off('click');
		downloadButton.off('click');
		start = undefined;
		return;
	} else if(options.unload){ // 
		return;
	}

	main.css({display:"inline-block"}).find(".header").html("Reservable Seat Capacity");
	tile1.css({display:"inline-flex"}).find(".header").html("Average Utilization");
	tile2.css({display:"inline-block"}).find(".header").html("Weekday");
	tile3.css({display:"inline-block"}).find(".header").html("Department");
	tile4.css({display:"inline-block"}).find(".header").html("Seat");
	tile5.css({display:"inline-block"}).find(".header").html("Floor");
	tile6.css({display:"inline-block"}).find(".header").html("Suite");

	if(analysis.hasInit){
		if(officeID != analysis.officeID){ // Only reloads if a new office was selected
			analysis.officeID = officeID;
			$.ajax({
				url: url,
				type: "GET",
				data: {officeID:analysis.officeID},
				success: function (result) {
					analysis.officeID = officeID;
					var formatted = formatResults(result);
					analysis.data.remove();
					analysis.data.add(formatted);
					dc.renderAll(group);
				}
			})			
		}
		return;
	}

	analysis.mainBar = dc.barChart(mainTable[0],group);
	analysis.mainBrush = dc.lineChart(mainBrush[0],group);
	analysis.utilization = dc.numberDisplay(tile1[0],group);
	analysis.weekday = dc.selectMenu(tile2[0],group);
	analysis.department = dc.selectMenu(tile3[0],group);
	analysis.seat = dc.selectMenu(tile4[0],group);
	analysis.floor = dc.selectMenu(tile5[0],group);
	analysis.suite = dc.selectMenu(tile6[0],group);

	$.ajax({
		url: url,
		type: "GET",
		data: {officeID:officeID},
		success: function (result) {

		analysis.officeID = officeID;
		var formatted = formatResults(result);

    	start = new Date(moment(start).startOf('day').subtract(12,'h').valueOf());

		// Formatting the JSON result for crossfilter and grouping the data
		analysis.data = crossfilter(formatted);

	    // Dimensions and group for main chart
	    analysis.mainDim = analysis.data.dimension(function (d) {
	        return d.date;
	    });

	    // Dimensions and group for main chart
	    analysis.groups = analysis.mainDim.group().reduce(
	        function (p, v) { /* callback for when data is added to the current filter results */
	            p.total += v.available;
	            p.used += v.used;
	            p.available += (v.available - v.used);
	            p.average = p.total ? p.used / (p.total) : 0;
	            return p;
	        }, /* callback for when data is removed from the current filter results */
	        function (p, v) {
	            p.total -= v.available;
	            p.available -= (v.available - v.used);
	            p.used -= v.used;
	            p.average = p.total ? p.used / (p.total) : 0;
	            return p;
	        }, /* initialize p */
	        function () {
	            return {
	                total: 0,
	                available: 0,
	                used: 0,
	                average: 0
	            };
	        }
	    );

	    // Group for Utilization (no dimension needed since it's a single value)
	    analysis.groupAll = analysis.data.groupAll().reduce(
	        function (p, v) { /* callback for when data is added to the current filter results */
	            p.total += v.available;
	            p.used += v.used;
	            p.available += (v.available - v.used);
	            p.average = p.total ? p.used / (p.total) : 0;
	            return p;
	        }, /* callback for when data is removed from the current filter results */
	        function (p, v) {
	            p.total -= v.available;
	            p.available -= (v.available - v.used);
	            p.used -= v.used;
	            p.average = p.total ? p.used / (p.total) : 0;
	            return p;
	        },
	        function () { /* initialize p */
	            return {
	                total: 0,
	                available: 0,
	                used: 0,
	                average: 0
	            };
	        }
	    )

		analysis.weekdayDim = analysis.data.dimension(function (d) {
			return d.date ? moment(d.date).format('dddd') : null;
		});
		analysis.weekdayGroup = analysis.weekdayDim.group();

		analysis.departmentDim = analysis.data.dimension(function (d) {
			return d.department ? d.department : "Other";
		});
		analysis.departmentGroup = analysis.departmentDim.group();

		analysis.seatDim = analysis.data.dimension(function (d) {
			return d.seat ? d.seat : "Other";
		});
		analysis.seatGroup = analysis.seatDim.group();

		analysis.floorDim = analysis.data.dimension(function (d) {
			return d.floor ? d.floor : "Other";
		});
		analysis.floorGroup = analysis.floorDim.group();

		analysis.suiteDim = analysis.data.dimension(function (d) {
			return d.suite ? d.suite : "Other";
		});
		analysis.suiteGroup = analysis.suiteDim.group();

	    analysis.mainBar
	        .width(1000)
	        .height(320)
	        .centerBar(true)
			.useViewBoxResizing(true)
	        .transitionDuration(1000)
	        .margins({top: 20, right: 20, bottom: 20, left: 30})
	        .dimension(analysis.mainDim)
	        .mouseZoomable(false)
	        .rangeChart(analysis.mainBrush)
	        .x(d3.time.scale().domain([start,end]))
			.xUnits(d3.time.days)
	        .elasticY(true)
	        .renderHorizontalGridLines(true)
	        .legend(dc.legend().x(850).y(-20).itemHeight(13).gap(5))
	        .brushOn(false)
	        .group(analysis.groups, 'Reserved')
	        .valueAccessor(function (d) {return d.value.used;})
	        .stack(analysis.groups, 'Unused', function (d) {return d.value.available;})      
	        .title(function (d) {
	             return dateFormat(d.key) + '\n' +
	             "Available Capacity: " + numberFormat(d.value.used + d.value.available) + '\n' +
	             "Reserved Hours: " + numberFormat(d.value.used) + '\n' +
	             "Unused Hours: " + numberFormat(d.value.available) + '\n' +
	             "Utilization: " + numberFormat(((d.value.used / (d.value.used + d.value.available))) * 100) + "%"
	        })
	    	.xAxis().tickFormat(shortDate).tickValues(
	    			function(){
						var filters = analysis.mainBrush.filters();
						if(filters.length){
							var range = filters[0];
							var days = moment.duration(moment.preciseDiff(range[0],range[1],true)).asDays();
							var step = Math.ceil(days/10);
							return getTicks(range[0],range[1],{step:step});
						} else {
							var days = moment.duration(moment.preciseDiff(start,end,true)).asDays();
							var step = Math.ceil(days/10);
							return getTicks(start,end,{step:step});
						}
	    			}
	    		)

	    analysis.mainBrush
	    	.renderArea(true)
	    	.width(1000)
	        .height(80)
			.useViewBoxResizing(true)
	    	.mouseZoomable(false)
	        .transitionDuration(1000)
	        .margins({top: 10, right: 20, bottom: 20, left: 30})
	        .dimension(analysis.mainDim)
	        .group(analysis.groups, 'Utilization')
	        .valueAccessor(function (d) {return d.value.average;})
	        .x(d3.time.scale().domain([start,end]))
	        .elasticY(true)
	        .renderHorizontalGridLines(false)
	        .round(d3.time.day.round)
	        .xUnits(d3.time.days)
	        .yAxis().tickValues([]).outerTickSize(0);
	    analysis.mainBrush
	    	.xAxis().tickFormat(shortDate).tickValues(
	    			function(){
						var days = moment.duration(moment.preciseDiff(start,end,true)).asDays();
						var step = Math.floor(days/10);
						return getTicks(start,end,{step:step});
	    			}
	    		)


		analysis.utilization
			.group(analysis.groupAll)
			.valueAccessor(function (p) {return p.average;})
			.formatNumber(d3.format(".2%"));			

	    analysis.weekday
           	.dimension(analysis.weekdayDim)
           	.group(analysis.weekdayGroup)
           	.multiple(true)
           	.title(function(d){return d.key;})

		analysis.department
           	.dimension(analysis.departmentDim)
           	.group(analysis.departmentGroup)
           	.multiple(true)
           	.title(function(d){return d.key;})		

		analysis.seat
           	.dimension(analysis.seatDim)
           	.group(analysis.seatGroup)
           	.multiple(true)
           	.title(function(d){return d.key;})

		analysis.floor
           	.dimension(analysis.floorDim)
           	.group(analysis.floorGroup)
           	.multiple(true)
           	.title(function(d){return d.key;})

		analysis.suite
           	.dimension(analysis.suiteDim)
           	.group(analysis.suiteGroup)
           	.multiple(true)
           	.title(function(d){return d.key;})

	    dc.renderAll(group);
	}});

	if(analysis.hasInit){

	} else {
		reset.on('click',function(){
			dc.filterAll(group);
			dc.redrawAll(group);
		})

		downloadButton.on('click',function(){
	        var data = analysis.mainDim.top(Infinity);
	        data = data.map(function(d){
	        	var formatted = {
	        		Date: longDate(d.date),
	        		Department: d.department,
	        		Map: d.map,
	        		Suite: d.suite,
	        		Floor: d.floor,
	        		Seats: d.capacity
	        	}
	        	return formatted;
	        })
	        var blob = new Blob([d3.csv.format(data)], {type: "text/csv;charset=utf-8"});
	        saveAs(blob, fileName+'.csv');
		})

		analysis.hasInit = true;
	}	
}

$Map.Analytics.Offices.Seats.seatReservationUsageByHour = function(options){
	options = options || {};
	var officeID = options.officeID;
	var analysis = $Map.Analytics.Offices.Seats.seatReservationUsageByHour;
	var group = "seatReservationUsageByHour";
	var fileName = 'daily_seat_reservation_usage';
	var url = "../api/analytics/capacity/seatReservationUsageByHour";
	var numberFormat = d3.format(".0f");
	var decimalFormat = d3.format(".2f");
	var dateFormat = d3.time.format("%Y-%m-%d");
	var timeFormat = d3.time.format("%c")
	var shortDate = d3.time.format("%b-%d '%y");
	var longDate = d3.time.format("%B %d, %Y");
	var analyticsWrapper = $("#officeSeatAnalytics");
	var downloadButton = analyticsWrapper.find('.download-btn');
	var main = analyticsWrapper.find('.main-chart');
	var mainTable = main.find('.main-table');
	var mainBrush = main.find('.main-areaBrush');
	var tile1 = analyticsWrapper.find('.tile-1');
	var tile2 = analyticsWrapper.find('.tile-2');
	var tile3 = analyticsWrapper.find('.tile-3');
	var tile4 = analyticsWrapper.find('.tile-4');
	var tile5 = analyticsWrapper.find('.tile-5');
	var tile6 = analyticsWrapper.find('.tile-6');
	var reset = analyticsWrapper.find('.reset');
	var start;
	var end = new Date(moment().endOf('hour').valueOf());
	var formatResults = function(result){
		var formatted = [];
		result.forEach(function (d) {
	        d.d = 1 * d.d; // Coerce to number
	        if(start){ // Finds the earliest date in the results
	        	start = d.d < start ? d.d : start;
	        } else { start = d.d; }
			formatted.push({
				date: new Date(moment(d.d).startOf('hour').valueOf()),
				suite: d.st,
				floor: d.f,
				seat: d.sn,
				available: d.a,
				used: d.u,
				department: d.dpt
			})        
    	});	
    	return formatted;		
	}

	// If an unload option is passed, the charts and all related objects are unloaded
	if(analysis.hasInit && options.unload){ 
		dc.deregisterChart(analysis.mainBar,group);
		dc.deregisterChart(analysis.mainBrush,group);
		dc.deregisterChart(analysis.utilization,group);
		dc.deregisterChart(analysis.department,group);
		dc.deregisterChart(analysis.seat,group);
		dc.deregisterChart(analysis.floor,group);
		dc.deregisterChart(analysis.suite,group);
		analysis.mainBar = null;
		analysis.mainBrush = null;
		analysis.utilization = null;
		analysis.department = null;
		analysis.seat = null;
		analysis.floor = null;
		analysis.suite = null;
		mainTable.find("svg").remove();
		mainBrush.find("svg").remove();
		tile1.find("span").remove();
		tile2.find("select").remove();
		tile3.find("select").remove();
		tile4.find("select").remove();
		tile5.find("select").remove();
		analysis.data = null;
		analysis.all = null;
		analysis.mainDim = null;
		analysis.groups = null;
		analysis.groupAll = null;
		analysis.deptDim = null;
		analysis.deptGroup = null;
		analysis.suiteDim = null;
		analysis.suiteGroup = null;
		analysis.floorDim = null;
		analysis.floorGroup = null;
		analysis.seatDim = null;
		analysis.seatGroup = null;
		analysis.weekdayDim = null;
		analysis.weekdayGroup = null;
		analysis.hasInit = false;
		reset.off('click');
		downloadButton.off('click');
		start = undefined;
		return;
	} else if(options.unload){ // 
		return;
	}

	main.css({display:"inline-block"}).find(".header").html("Reservable Seat Capacity");
	tile1.css({display:"inline-flex"}).find(".header").html("Average Utilization");
	tile2.css({display:"inline-block"}).find(".header").html("Weekday");
	tile3.css({display:"inline-block"}).find(".header").html("Department");
	tile4.css({display:"inline-block"}).find(".header").html("Seat");
	tile5.css({display:"inline-block"}).find(".header").html("Floor");
	tile6.css({display:"inline-block"}).find(".header").html("Suite");

	if(analysis.hasInit){
		if(officeID != analysis.officeID){ // Only reloads if a new office was selected
			analysis.officeID = officeID;
			$.ajax({
				url: url,
				type: "GET",
				data: {officeID:analysis.officeID},
				success: function (result) {
					analysis.officeID = officeID;
					var formatted = formatResults(result);
					analysis.data.remove();
					analysis.data.add(formatted);
					dc.renderAll(group);
				}
			})			
		}
		return;
	}

	analysis.mainBar = dc.barChart(mainTable[0],group);
	analysis.mainBrush = dc.lineChart(mainBrush[0],group);
	analysis.utilization = dc.numberDisplay(tile1[0],group);
	analysis.weekday = dc.selectMenu(tile2[0],group);
	analysis.department = dc.selectMenu(tile3[0],group);
	analysis.seat = dc.selectMenu(tile4[0],group);
	analysis.floor = dc.selectMenu(tile5[0],group);
	analysis.suite = dc.selectMenu(tile6[0],group);

	$.ajax({
		url: url,
		type: "GET",
		data: {officeID:officeID},
		success: function (result) {

		analysis.officeID = officeID;
		var formatted = formatResults(result);

    	start = new Date(moment(start).startOf('hour').valueOf());

		// Formatting the JSON result for crossfilter and grouping the data
		analysis.data = crossfilter(formatted);

	    // Dimensions and group for main chart
	    analysis.mainDim = analysis.data.dimension(function (d) {
	        return d.date;
	    });

	    // Dimensions and group for main chart
	    analysis.groups = analysis.mainDim.group().reduce(
	        function (p, v) { /* callback for when data is added to the current filter results */
	            p.total += v.available;
	            p.used += v.used;
	            p.available += (v.available - v.used);
	            p.average = p.total ? p.used / (p.total) : 0;
	            return p;
	        }, /* callback for when data is removed from the current filter results */
	        function (p, v) {
	            p.total -= v.available;
	            p.available -= (v.available - v.used);
	            p.used -= v.used;
	            p.average = p.total ? p.used / (p.total) : 0;
	            return p;
	        }, /* initialize p */
	        function () {
	            return {
	                total: 0,
	                available: 0,
	                used: 0,
	                average: 0
	            };
	        }
	    );

	    // Group for Utilization (no dimension needed since it's a single value)
	    analysis.groupAll = analysis.data.groupAll().reduce(
	        function (p, v) { /* callback for when data is added to the current filter results */
	            p.total += v.available;
	            p.used += v.used;
	            p.available += (v.available - v.used);
	            p.average = p.total ? p.used / (p.total) : 0;
	            return p;
	        }, /* callback for when data is removed from the current filter results */
	        function (p, v) {
	            p.total -= v.available;
	            p.available -= (v.available - v.used);
	            p.used -= v.used;
	            p.average = p.total ? p.used / (p.total) : 0;
	            return p;
	        },
	        function () { /* initialize p */
	            return {
	                total: 0,
	                available: 0,
	                used: 0,
	                average: 0
	            };
	        }
	    )

		analysis.weekdayDim = analysis.data.dimension(function (d) {
			return d.date ? moment(d.date).format('dddd') : null;
		});
		analysis.weekdayGroup = analysis.weekdayDim.group();

		analysis.departmentDim = analysis.data.dimension(function (d) {
			return d.department ? d.department : "Other";
		});
		analysis.departmentGroup = analysis.departmentDim.group();

		analysis.seatDim = analysis.data.dimension(function (d) {
			return d.seat ? d.seat : "Other";
		});
		analysis.seatGroup = analysis.seatDim.group();

		analysis.floorDim = analysis.data.dimension(function (d) {
			return d.floor ? d.floor : "Other";
		});
		analysis.floorGroup = analysis.floorDim.group();

		analysis.suiteDim = analysis.data.dimension(function (d) {
			return d.suite ? d.suite : "Other";
		});
		analysis.suiteGroup = analysis.suiteDim.group();

	    analysis.mainBar
	        .width(1000)
	        .height(320)
	        .centerBar(true)
			.useViewBoxResizing(true)
	        .transitionDuration(1000)
	        .margins({top: 20, right: 20, bottom: 20, left: 30})
	        .dimension(analysis.mainDim)
	        .mouseZoomable(false)
	        .rangeChart(analysis.mainBrush)
	        .x(d3.time.scale().domain([start,end]))
			.xUnits(d3.time.hours)
	        .elasticY(true)
	        .renderHorizontalGridLines(true)
	        .legend(dc.legend().x(850).y(-20).itemHeight(13).gap(5))
	        .brushOn(false)
	        .group(analysis.groups, 'Reserved')
	        .valueAccessor(function (d) {return d.value.used;})
	        .stack(analysis.groups, 'Unused', function (d) {return d.value.available;})      
	        .title(function (d) {
	             return timeFormat(d.key) + '\n' +
	             "Available Capacity: " + numberFormat(d.value.used + d.value.available) + '\n' +
	             "Reserved Hours: " + numberFormat(d.value.used) + '\n' +
	             "Unused Hours: " + numberFormat(d.value.available) + '\n' +
	             "Utilization: " + numberFormat(((d.value.used / (d.value.used + d.value.available))) * 100) + "%"
	        })
	    	// .xAxis().tickFormat(shortDate).tickValues(
	    	// 		function(){
						// var filters = analysis.mainBrush.filters();
						// if(filters.length){
						// 	var range = filters[0];
						// 	var days = moment.duration(moment.preciseDiff(range[0],range[1],true)).asDays();
						// 	var step = Math.ceil(days/10);
						// 	return getTicks(range[0],range[1],{step:step});
						// } else {
						// 	var days = moment.duration(moment.preciseDiff(start,end,true)).asDays();
						// 	var step = Math.ceil(days/10);
						// 	return getTicks(start,end,{step:step});
						// }
	    	// 		}
	    	// 	)

	    analysis.mainBrush
	    	.renderArea(true)
	    	.width(1000)
	        .height(80)
			.useViewBoxResizing(true)
	    	.mouseZoomable(false)
	        .transitionDuration(1000)
	        .margins({top: 10, right: 20, bottom: 20, left: 30})
	        .dimension(analysis.mainDim)
	        .group(analysis.groups, 'Utilization')
	        .valueAccessor(function (d) {return d.value.average;})
	        .x(d3.time.scale().domain([start,end]))
	        .elasticY(true)
	        .renderHorizontalGridLines(false)
	        .round(d3.time.hour.round)
	        .xUnits(d3.time.hours)
	        .yAxis().tickValues([]).outerTickSize(0);
	    analysis.mainBrush
	    	.xAxis().tickFormat(shortDate).tickValues(
	    			function(){
						var days = moment.duration(moment.preciseDiff(start,end,true)).asDays();
						var step = Math.floor(days/10);
						return getTicks(start,end,{step:step});
	    			}
	    		)


		analysis.utilization
			.group(analysis.groupAll)
			.valueAccessor(function (p) {return p.average;})
			.formatNumber(d3.format(".2%"));			

	    analysis.weekday
           	.dimension(analysis.weekdayDim)
           	.group(analysis.weekdayGroup)
           	.multiple(true)
           	.title(function(d){return d.key;})

		analysis.department
           	.dimension(analysis.departmentDim)
           	.group(analysis.departmentGroup)
           	.multiple(true)
           	.title(function(d){return d.key;})		

		analysis.seat
           	.dimension(analysis.seatDim)
           	.group(analysis.seatGroup)
           	.multiple(true)
           	.title(function(d){return d.key;})

		analysis.floor
           	.dimension(analysis.floorDim)
           	.group(analysis.floorGroup)
           	.multiple(true)
           	.title(function(d){return d.key;})

		analysis.suite
           	.dimension(analysis.suiteDim)
           	.group(analysis.suiteGroup)
           	.multiple(true)
           	.title(function(d){return d.key;})

	    dc.renderAll(group);
	}});

	if(analysis.hasInit){

	} else {
		reset.on('click',function(){
			dc.filterAll(group);
			dc.redrawAll(group);
		})

		downloadButton.on('click',function(){
	        var data = analysis.mainDim.top(Infinity);
	        data = data.map(function(d){
	        	var formatted = {
	        		Date: longDate(d.date),
	        		Department: d.department,
	        		Map: d.map,
	        		Suite: d.suite,
	        		Floor: d.floor,
	        		Seats: d.capacity
	        	}
	        	return formatted;
	        })
	        var blob = new Blob([d3.csv.format(data)], {type: "text/csv;charset=utf-8"});
	        saveAs(blob, fileName+'.csv');
		})

		analysis.hasInit = true;
	}	
}

$Map.Analytics.Offices.Rooms.roomReservationUsageByDay = function(options){
	options = options || {};
	var officeID = options.officeID;
	var analysis = $Map.Analytics.Offices.Rooms.roomReservationUsageByDay;
	var group = "roomReservationUsageByDay";
	var fileName = 'daily_room_reservation_usage';
	var url = "../api/analytics/capacity/roomReservationUsageByDay";
	var numberFormat = d3.format(".0f");
	var decimalFormat = d3.format(".2f");
	var dateFormat = d3.time.format("%Y-%m-%d");
	var shortDate = d3.time.format("%b-%d '%y");
	var longDate = d3.time.format("%B %d, %Y");
	var analyticsWrapper = $("#roomReservationAnalytics");
	var downloadButton = analyticsWrapper.find('.download-btn');
	var main = analyticsWrapper.find('.main-chart');
	var mainTable = main.find('.main-table');
	var mainBrush = main.find('.main-areaBrush');
	var tile1 = analyticsWrapper.find('.tile-1');
	var tile2 = analyticsWrapper.find('.tile-2');
	var tile3 = analyticsWrapper.find('.tile-3');
	var tile4 = analyticsWrapper.find('.tile-4');
	var tile5 = analyticsWrapper.find('.tile-5');
	var tile6 = analyticsWrapper.find('.tile-6');
	var reset = analyticsWrapper.find('.reset');
	var start;
	var end = new Date(moment().endOf('day').subtract(12,'h').valueOf());
	var formatResults = function(result){
		var formatted = [];
		result.forEach(function (d) {
	        d.date = 1 * d.date; // Coerce to number
	        if(start){ // Finds the earliest date in the results
	        	start = d.date < start ? d.date : start;
	        } else { start = d.date; }
			formatted.push({
				date: new Date(moment(d.date).startOf('day').valueOf()),
				mapName: d.mapName,
				suite: d.suite,
				floor: d.floor,
				room: d.roomName,
				available: d.available,
				used: d.used,
				area: d.area,
				capacity: d.capacity,
				type: d.roomType
			})        
    	});	
    	return formatted;		
	}

	// If an unload option is passed, the charts and all related objects are unloaded
	if(analysis.hasInit && options.unload){ 
		dc.deregisterChart(officeByDay.capacityByDayChart,group);
		dc.deregisterChart(officeByDay.capacityByDayArea,group);
		dc.deregisterChart(officeByDay.capacityTypeSelect,group);
		dc.deregisterChart(officeByDay.capacityFloorSelect,group);
		dc.deregisterChart(officeByDay.capacitySuiteSelect,group);
		dc.deregisterChart(officeByDay.capacityMapSelect,group);
		dc.deregisterChart(officeByDay.capacityDeptSelect,group);
		officeByDay.capacityByDayChart.select("svg").remove();
		officeByDay.capacityByDayArea.select("svg").remove();
		officeByDay.capacityTypeSelect.select("svg").remove();
		officeByDay.capacityFloorSelect.select("svg").remove();
		officeByDay.capacitySuiteSelect.select("svg").remove();
		officeByDay.capacityMapSelect.select("svg").remove();
		officeByDay.capacityDeptSelect.select("svg").remove();
		officeByDay.capacityByDayChart = null;
		officeByDay.capacityByDayArea = null;
		officeByDay.capacityTypeSelect = null;
		officeByDay.capacityFloorSelect = null;
		officeByDay.capacitySuiteSelect = null;
		officeByDay.capacityMapSelect = null;
		officeByDay.capacityDeptSelect = null;
		officeByDay.data = null;
		officeByDay.all = null;
		officeByDay.capacityByDay = null;
		officeByDay.groups = null;
		officeByDay.capacityStatus = null;
		officeByDay.capacityStatusGroup = null;
		officeByDay.capacityFloor = null;
		officeByDay.capacityFloorGroup = null;
		officeByDay.capacitySuite = null;
		officeByDay.capacitySuiteGroup = null;
		officeByDay.capacityMap = null;
		officeByDay.capacityMapGroup = null;
		officeByDay.capacityDept = null;
		officeByDay.capacityDeptGroup = null;
		officeByDay.hasInit = false;
		$("#capacityByDay-area .reset").off('click');
		return;
	}

	main.css({display:"inline-block"}).find(".header").html("Reservable Room Capacity");
	tile1.css({display:"inline-flex"}).find(".header").html("Average Utilization");
	tile2.css({display:"inline-block"}).find(".header").html("Weekday");
	tile3.css({display:"inline-block"}).find(".header").html("Room");
	tile4.css({display:"inline-block"}).find(".header").html("Room Type");
	tile5.css({display:"inline-block"}).find(".header").html("Floor");
	tile6.css({display:"inline-block"}).find(".header").html("Suite");

	if(analysis.hasInit){
		if(officeID != analysis.officeID){ // Only reloads if a new office was selected
			analysis.officeID = officeID;
			$.ajax({
				url: url,
				type: "GET",
				data: {officeID:analysis.officeID},
				success: function (result) {
					analysis.officeID = officeID;
					var formatted = formatResults(result);
					analysis.data.remove();
					analysis.data.add(formatted);
					dc.renderAll(group);
				}
			})			
		}
		return;
	}

	analysis.mainBar = dc.barChart(mainTable[0],group);
	analysis.mainBrush = dc.lineChart(mainBrush[0],group);
	analysis.utilization = dc.numberDisplay(tile1[0],group);
	analysis.weekday = dc.selectMenu(tile2[0],group);
	analysis.room = dc.selectMenu(tile3[0],group);
	analysis.type = dc.selectMenu(tile4[0],group);
	analysis.floor = dc.selectMenu(tile5[0],group);
	analysis.suite = dc.selectMenu(tile6[0],group);

	$.ajax({
		url: url,
		type: "GET",
		data: {officeID:officeID},
		success: function (result) {

		analysis.officeID = officeID;
		var formatted = formatResults(result);

    	start = new Date(moment(start).startOf('day').subtract(12,'h').valueOf());

		// Formatting the JSON result for crossfilter and grouping the data
		analysis.data = crossfilter(formatted);

	    // Dimensions and group for main chart
	    analysis.mainDim = analysis.data.dimension(function (d) {
	        return d.date;
	    });

	    // Dimensions and group for main chart
	    analysis.groups = analysis.mainDim.group().reduce(
	        function (p, v) { /* callback for when data is added to the current filter results */
	            p.total += v.available;
	            p.used += v.used;
	            p.available += (v.available - v.used);
	            p.average = p.total ? p.used / (p.total) : 0;
	            return p;
	        }, /* callback for when data is removed from the current filter results */
	        function (p, v) {
	            p.total -= v.available;
	            p.available -= (v.available - v.used);
	            p.used -= v.used;
	            p.average = p.total ? p.used / (p.total) : 0;
	            return p;
	        }, /* initialize p */
	        function () {
	            return {
	                total: 0,
	                available: 0,
	                used: 0,
	                average: 0
	            };
	        }
	    );

	    // Group for Utilization (no dimension needed since it's a single value)
	    analysis.groupAll = analysis.data.groupAll().reduce(
	        function (p, v) { /* callback for when data is added to the current filter results */
	            p.total += v.available;
	            p.used += v.used;
	            p.available += (v.available - v.used);
	            p.average = p.total ? p.used / (p.total) : 0;
	            return p;
	        }, /* callback for when data is removed from the current filter results */
	        function (p, v) {
	            p.total -= v.available;
	            p.available -= (v.available - v.used);
	            p.used -= v.used;
	            p.average = p.total ? p.used / (p.total) : 0;
	            return p;
	        },
	        function () { /* initialize p */
	            return {
	                total: 0,
	                available: 0,
	                used: 0,
	                average: 0
	            };
	        }
	    )

		analysis.weekdayDim = analysis.data.dimension(function (d) {
			return d.date ? moment(d.date).format('dddd') : null;
		});
		analysis.weekdayGroup = analysis.weekdayDim.group();

		analysis.roomDim = analysis.data.dimension(function (d) {
			return d.room;
		});
		analysis.roomGroup = analysis.roomDim.group();

		analysis.typeDim = analysis.data.dimension(function (d) {
			return d.type ? d.type : "Other";
		});
		analysis.typeGroup = analysis.typeDim.group();

		analysis.floorDim = analysis.data.dimension(function (d) {
			return d.floor ? d.floor : "Other";
		});
		analysis.floorGroup = analysis.floorDim.group();

		analysis.suiteDim = analysis.data.dimension(function (d) {
			return d.suite ? d.suite : "Other";
		});
		analysis.suiteGroup = analysis.suiteDim.group();

	    analysis.mainBar
	        .width(1000)
	        .height(320)
	        .centerBar(true)
			.useViewBoxResizing(true)
	        .transitionDuration(1000)
	        .margins({top: 20, right: 20, bottom: 20, left: 30})
	        .dimension(analysis.mainDim)
	        .mouseZoomable(false)
	        .rangeChart(analysis.mainBrush)
	        .x(d3.time.scale().domain([start,end]))
			.xUnits(d3.time.days)
	        .elasticY(true)
	        .renderHorizontalGridLines(true)
	        .legend(dc.legend().x(850).y(-20).itemHeight(13).gap(5))
	        .brushOn(false)
	        .group(analysis.groups, 'Reserved')
	        .valueAccessor(function (d) {return d.value.used;})
	        .stack(analysis.groups, 'Unused', function (d) {return d.value.available;})      
	        .title(function (d) {
	             return dateFormat(d.key) + '\n' +
	             "Available Capacity: " + numberFormat(d.value.used + d.value.available) + '\n' +
	             "Reserved Hours: " + numberFormat(d.value.used) + '\n' +
	             "Unused Hours: " + numberFormat(d.value.available) + '\n' +
	             "Utilization: " + numberFormat(((d.value.used / (d.value.used + d.value.available))) * 100) + "%"
	        })
	    	.xAxis().tickFormat(shortDate).tickValues(
	    			function(){
						var filters = analysis.mainBrush.filters();
						if(filters.length){
							var range = filters[0];
							var days = moment.duration(moment.preciseDiff(range[0],range[1],true)).asDays();
							var step = Math.ceil(days/10);
							return getTicks(range[0],range[1],{step:step});
						} else {
							var days = moment.duration(moment.preciseDiff(start,end,true)).asDays();
							var step = Math.ceil(days/10);
							return getTicks(start,end,{step:step});
						}
	    			}
	    		)

	    analysis.mainBrush
	    	.renderArea(true)
	    	.width(1000)
	        .height(80)
			.useViewBoxResizing(true)
	    	.mouseZoomable(false)
	        .transitionDuration(1000)
	        .margins({top: 10, right: 20, bottom: 20, left: 30})
	        .dimension(analysis.mainDim)
	        .group(analysis.groups, 'Utilization')
	        .valueAccessor(function (d) {return d.value.average;})
	        .x(d3.time.scale().domain([start,end]))
	        .elasticY(true)
	        .renderHorizontalGridLines(false)
	        .round(d3.time.day.round)
	        .xUnits(d3.time.days)
	        .yAxis().tickValues([]).outerTickSize(0);
	    analysis.mainBrush
	    	.xAxis().tickFormat(shortDate).tickValues(
	    			function(){
						var days = moment.duration(moment.preciseDiff(start,end,true)).asDays();
						var step = Math.floor(days/10);
						return getTicks(start,end,{step:step});
	    			}
	    		)


		analysis.utilization
			.group(analysis.groupAll)
			.valueAccessor(function (p) {return p.average;})
			.formatNumber(d3.format(".2%"));			

	    analysis.weekday
           	.dimension(analysis.weekdayDim)
           	.group(analysis.weekdayGroup)
           	.multiple(true)
           	.title(function(d){return d.key;})

		analysis.room
           	.dimension(analysis.roomDim)
           	.group(analysis.roomGroup)
           	.multiple(true)
           	.title(function(d){return d.key;})		

		analysis.type
           	.dimension(analysis.typeDim)
           	.group(analysis.typeGroup)
           	.multiple(true)
           	.title(function(d){return d.key;})

		analysis.floor
           	.dimension(analysis.floorDim)
           	.group(analysis.floorGroup)
           	.multiple(true)
           	.title(function(d){return d.key;})

		analysis.suite
           	.dimension(analysis.suiteDim)
           	.group(analysis.suiteGroup)
           	.multiple(true)
           	.title(function(d){return d.key;})

	    dc.renderAll(group);
	}});

	if(analysis.hasInit){

	} else {
		reset.on('click',function(){
			dc.filterAll(group);
			dc.redrawAll(group);
		})

		downloadButton.on('click',function(){
	        var data = analysis.mainDim.top(Infinity);
	        data = data.map(function(d){
	        	var formatted = {
	        		Date: longDate(d.date),
	        		Department: d.department,
	        		Map: d.map,
	        		Suite: d.suite,
	        		Floor: d.floor,
	        		Seats: d.capacity
	        	}
	        	return formatted;
	        })
	        var blob = new Blob([d3.csv.format(data)], {type: "text/csv;charset=utf-8"});
	        saveAs(blob, fileName+'.csv');
		})

		analysis.hasInit = true;
	}	
}











/* FileSaver.js
 * A saveAs() FileSaver implementation.
 * 1.3.2
 * 2016-06-16 18:25:19
 *
 * By Eli Grey, http://eligrey.com
 * License: MIT
 *   See https://github.com/eligrey/FileSaver.js/blob/master/LICENSE.md
 */

/*global self */
/*jslint bitwise: true, indent: 4, laxbreak: true, laxcomma: true, smarttabs: true, plusplus: true */

/*! @source http://purl.eligrey.com/github/FileSaver.js/blob/master/FileSaver.js */

var saveAs = saveAs || (function(view) {
	"use strict";
	// IE <10 is explicitly unsupported
	if (typeof view === "undefined" || typeof navigator !== "undefined" && /MSIE [1-9]\./.test(navigator.userAgent)) {
		return;
	}
	var
		doc = view.document
		// only get URL when necessary in case Blob.js hasn't overridden it yet
		, get_URL = function() {
			return view.URL || view.webkitURL || view;
		}
		, save_link = doc.createElementNS("http://www.w3.org/1999/xhtml", "a")
		, can_use_save_link = "download" in save_link
		, click = function(node) {
			var event = new MouseEvent("click");
			node.dispatchEvent(event);
		}
		, is_safari = /constructor/i.test(view.HTMLElement) || view.safari
		, is_chrome_ios =/CriOS\/[\d]+/.test(navigator.userAgent)
		, throw_outside = function(ex) {
			(view.setImmediate || view.setTimeout)(function() {
				throw ex;
			}, 0);
		}
		, force_saveable_type = "application/octet-stream"
		// the Blob API is fundamentally broken as there is no "downloadfinished" event to subscribe to
		, arbitrary_revoke_timeout = 1000 * 40 // in ms
		, revoke = function(file) {
			var revoker = function() {
				if (typeof file === "string") { // file is an object URL
					get_URL().revokeObjectURL(file);
				} else { // file is a File
					file.remove();
				}
			};
			setTimeout(revoker, arbitrary_revoke_timeout);
		}
		, dispatch = function(filesaver, event_types, event) {
			event_types = [].concat(event_types);
			var i = event_types.length;
			while (i--) {
				var listener = filesaver["on" + event_types[i]];
				if (typeof listener === "function") {
					try {
						listener.call(filesaver, event || filesaver);
					} catch (ex) {
						throw_outside(ex);
					}
				}
			}
		}
		, auto_bom = function(blob) {
			// prepend BOM for UTF-8 XML and text/* types (including HTML)
			// note: your browser will automatically convert UTF-16 U+FEFF to EF BB BF
			if (/^\s*(?:text\/\S*|application\/xml|\S*\/\S*\+xml)\s*;.*charset\s*=\s*utf-8/i.test(blob.type)) {
				return new Blob([String.fromCharCode(0xFEFF), blob], {type: blob.type});
			}
			return blob;
		}
		, FileSaver = function(blob, name, no_auto_bom) {
			if (!no_auto_bom) {
				blob = auto_bom(blob);
			}
			// First try a.download, then web filesystem, then object URLs
			var
				filesaver = this
				, type = blob.type
				, force = type === force_saveable_type
				, object_url
				, dispatch_all = function() {
					dispatch(filesaver, "writestart progress write writeend".split(" "));
				}
				// on any filesys errors revert to saving with object URLs
				, fs_error = function() {
					if ((is_chrome_ios || (force && is_safari)) && view.FileReader) {
						// Safari doesn't allow downloading of blob urls
						var reader = new FileReader();
						reader.onloadend = function() {
							var url = is_chrome_ios ? reader.result : reader.result.replace(/^data:[^;]*;/, 'data:attachment/file;');
							var popup = view.open(url, '_blank');
							if(!popup) view.location.href = url;
							url=undefined; // release reference before dispatching
							filesaver.readyState = filesaver.DONE;
							dispatch_all();
						};
						reader.readAsDataURL(blob);
						filesaver.readyState = filesaver.INIT;
						return;
					}
					// don't create more object URLs than needed
					if (!object_url) {
						object_url = get_URL().createObjectURL(blob);
					}
					if (force) {
						view.location.href = object_url;
					} else {
						var opened = view.open(object_url, "_blank");
						if (!opened) {
							// Apple does not allow window.open
							view.location.href = object_url;
						}
					}
					filesaver.readyState = filesaver.DONE;
					dispatch_all();
					revoke(object_url);
				}
			;
			filesaver.readyState = filesaver.INIT;

			if (can_use_save_link) {
				object_url = get_URL().createObjectURL(blob);
				setTimeout(function() {
					save_link.href = object_url;
					save_link.download = name;
					click(save_link);
					dispatch_all();
					revoke(object_url);
					filesaver.readyState = filesaver.DONE;
				});
				return;
			}

			fs_error();
		}
		, FS_proto = FileSaver.prototype
		, saveAs = function(blob, name, no_auto_bom) {
			return new FileSaver(blob, name || blob.name || "download", no_auto_bom);
		}
	;
	// IE 10+ (native saveAs)
	if (typeof navigator !== "undefined" && navigator.msSaveOrOpenBlob) {
		return function(blob, name, no_auto_bom) {
			name = name || blob.name || "download";

			if (!no_auto_bom) {
				blob = auto_bom(blob);
			}
			return navigator.msSaveOrOpenBlob(blob, name);
		};
	}

	FS_proto.abort = function(){};
	FS_proto.readyState = FS_proto.INIT = 0;
	FS_proto.WRITING = 1;
	FS_proto.DONE = 2;

	FS_proto.error =
	FS_proto.onwritestart =
	FS_proto.onprogress =
	FS_proto.onwrite =
	FS_proto.onabort =
	FS_proto.onerror =
	FS_proto.onwriteend =
		null;

	return saveAs;
}(
	   typeof self !== "undefined" && self
	|| typeof window !== "undefined" && window
	|| this.content
));
// `self` is undefined in Firefox for Android content script context
// while `this` is nsIContentFrameMessageManager
// with an attribute `content` that corresponds to the window

if (typeof module !== "undefined" && module.exports) {
  module.exports.saveAs = saveAs;
} else if ((typeof define !== "undefined" && define !== null) && (define.amd !== null)) {
  define("FileSaver.js", function() {
    return saveAs;
  });
}