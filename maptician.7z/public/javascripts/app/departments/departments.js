$Map.Components = $Map.Components || {};

$Map.Components.Departments = function(){
	this.area = $("#departmentsArea");
	this.rightNav = $("#departmentsRightNav");
	this.navControls = $("#departmentsControlButtons");
	this.new = $("#newDepartment");
	this.refresh = $("#refreshDepartmentList");
	this.edit = $("#editDepartment");
	this.searchForm = this.rightNav.find('form');
	this.searchBox = $("#deptSearch");
	this.navTableHolder = $("#departmentNavTableHolder");
	this.navTable = $("#departmentNavTable");
	this.namespace = '.departments';

	// These variables control the modal used to create, edit, and delete departments
	this.selectorFormModal = $("#departmentFormModal");
	this.selectorForm = $(this.selectorFormModal.find('form')[0]);
	this.selectorValidator = null;
	this.action = null; // flag for whether the modal is in 'create' or 'update' mode
	this.createURL = '../api/departments/createNewDepartment';
	this.editURL = '../api/departments/editDepartment';

	// Tabs
	this.tabOpen = null;
	this.tabSelectors = $("#departmentTabSelectors");
	this.tabs = this.tabSelectors.find('li');

	// RightNav Department Table
	this.isOpen = false;
	this.departmentTable = null;
	this.departmentSelected = null; // deptID of selected row
	this.departmentSelector = null; // Datatables row selector object
	var Departments = this;

	this.open = function(){
		this.area.show();
		this.tabSelectors.show();
		this.rightNav.css({display:'block',visibility:'hidden'});
		this.setSelectTable();
		this.setBindings();
		this.setValidator();
		this.tabSelect(0);
		this.isOpen = true;
	}

	this.exit = function(){
		this.rightNav.hide();
		this.unsetBindings();
		this.departmentTable.clear().destroy(); // Clears datatable
		this.departmentTable = null;		
		this.navTable.children().remove(); // Removes table remaining table elements (except table)
		this.isOpen = false;
	}

	this.tabSelect = function(index){
		this.tabs.removeClass('active');
		$(this.tabs[index]).addClass('active');
		this.area.find('.subContent').hide();
		$(this.area.find('.subContent')[index]).show();

		if(index != 0 && !this.officeSelected){
			$("#departmentSelectNote").css({display:"flex"});
		}

		switch(index){
			case 0:
				this.rightNav.hide();
				//this.summary = this.summary || new $Map.Components.Departments.Summary(this);
				//this.summary.open();
				//this.tabOpen = this.summary;
			break;
			case 1:
				//this.occupants = this.occupants || new $Map.Components.Departments.MemberList(this);
				//this.occupants.open();
				this.rightNav.show();
				this.departmentTable.draw();
				//this.tabOpen = this.occupants;
			break;
			case 2:
				this.rightNav.show();
				this.reports = this.reports || new $Map.Components.Departments.Reports(this);
				this.reports.open();
				this.departmentTable.draw();
				this.tabOpen = this.reports;
			break;
			case 3:
				this.rightNav.show();
				this.analytics = this.analytics || new $Map.Components.Departments.Analytics(this);
				this.analytics.open();
				this.departmentTable.draw();
				this.tabOpen = this.analytics;
			break;
		}
	}

	this.setSelectTable = function(){
		this.departmentTable = this.departmentTable || this.navTable.DataTable({
			ajax: "../api/departments/navtable",
			rowId: 'deptID',
			select: {
				style: 'single',
				className: 'selected',
				selector: 'tr:not(.selected)'
			},
			scrollY: this.navTableHolder.height() - 25,
			deferRender:true,
			scroller:true,
			paging:true,
			columns: [
	        	{	
	        		width:150,
	        		data: {},
	        		title: "Department",
	        		class:'left',
	        		render: function(department){
	        			return department.deptName || "";
	        		}
	        	},
	            {
	            	width:50,
	            	data: {},
	            	title: "Number",
	            	class: 'center',
	            	render: function(department){
	        			return department.deptNumber || "";
	            	}
	        	},
	        	{
	            	width:50,
	            	data: {},
	            	title: "Status",
	            	class: 'center',
	            	render: function(department){
	        			return department.status;
	            	}	        		
	        	}
			],
			dom:'tr',
			initComplete:function(){
				Departments.rightNav.css({display:'none',visibility:'visible'});
			}
		})
	}

	this.setValidator = function(){
		this.selectorValidator = this.selectorForm.validate({
			rules: {
				departmentFormName: {
					required: true,
					rangelength: [3, 50],
					letNumSpac: true
				},
				departmentFormNumber: {
					maxlength: 10
				},
				departmentFormStatus: {
					required: true,
				},
			},
			messages: {
				departmentFormName: {
					required: "A Department Name is Required",
					letNumSpac: "Only standard letters and numbers are permitted in Department Names"
				},
				departmentFormNumber: {
					maxlength: "Department numbers cannot be more than 10 characters in length",
				},
				departmentFormStatus: {
					required: "A Department Status is Required",
				},
			},
			submitHandler:function(form,event){
				var data = {
					name: $("#departmentFormName").val(),
					address1: $("#departmentFormNumber").val(),
					address2: $("#departmentFormStatus").val(),
				}
				if(Departments.action == "edit"){
					data.deptID = Departments.departmentSelected;
				}
				var url = Departments.action == "create" ? Departments.createURL : Departments.editURL;
				$.ajax({
					type: "POST",
					url: url,
					data: data
				})
				.then(function(){
					$.modal.close();
					Departments.refreshSelectTable();
				})
				.catch(function(err){
					// TODO Need an error message to the user
					console.log(err);
				})
			}
		})
	}

	this.refreshSelectTable = function(){
		this.departmentTable && this.departmentTable.ajax.reload();
		this.departmentTable.row("#"+Departments.departmentSelected).select();
	}

	this.createTableItem = function(){
		this.selectorFormModal.find('h3.header').html('Create New Department');
		this.selectorFormModal.find('input.save').attr('value','Create');
		this.action = "create";
		this.selectorFormModal.modal();
	}

	this.editTableItem = function(){
		this.selectorFormModal.find('h3.header').html('Modify Department');
		this.selectorFormModal.find('input.save').attr('value','Save');
		this.action = "edit";
		var data = Departments.departmentSelector.data().toArray()[0];
		$("#departmentFormName").val(data.name).trigger('blur');
		$("#departmentFormNumber").val(data.number).trigger('blur');
		$("#departmentFormStatus").val(data.status).trigger('blur');
		this.selectorFormModal.modal();
	}

	this.selectNewDepartment = function(){
		// This tells the controller for the tab that a new department has been selected and to check
		// the department controller for the new deptID so that the controller can update its view to
		// match the newly selected department.
		this.tabOpen && this.tabOpen.updateDepartment();
	}

	this.setBindings = function(){
		// Select row event listener
		this.departmentTable && this.departmentTable.on( 'select' + this.namespace , function ( e, dt, type, indexes ) {
			Departments.officeSelector = Departments.departmentTable.rows(indexes);
			Departments.officeSelected = Departments.officeSelector.data().toArray()[0].deptID;
			Departments.selectNewDepartment();
			$("#departmentSelectNote").css({display:"none"});
		})

		this.new.on('click' + this.namespace, function(){
			Departments.createTableItem();
		})

		this.edit.on('click' + this.namespace, function(){
			if(Departments.officeSelected){
				Departments.editTableItem();				
			}
		})

		this.refresh.on('click' + this.namespace, function(){
			Departments.refreshSelectTable();
		})

		this.searchBox.on( 'input' + this.namespace, function () {
			Departments.departmentTable.search(Departments.searchBox.val()).draw();
		});

		this.selectorFormModal.find('.cancel').on('click' + this.namespace,function(){
			$.modal.close();
		})

		// Clears the form when the modal is closed
		this.selectorFormModal.on($.modal.AFTER_CLOSE,function(event,modal){ 
			Departments.selectorForm[0].reset();
			Departments.selectorForm.find('input.fl_input').trigger('blur');
		});

		_attach.call(Departments.departmentTable,'departmentMgrNav',25,function(height){
			$("#departmentNavTable").parent().css("height",height)
		});

		this.tabs.on('click' + this.namespace, function(){
			Departments.tabSelect($(this).index())
		})
	}

	this.unsetBindings = function(){
		this.departmentTable.off(this.namespace);
		this.refresh.off(this.namespace);
		this.edit.off(this.namespace);
		this.new.off(this.namespace);
		this.searchBox.off(this.namespace);
		this.selectorFormModal.find('.cancel').off(this.namespace);
		this.selectorFormModal.off($.modal.AFTER_CLOSE);
		$("#departmentMgrNav").remove(); // Remove iframe
	}
}
$Map.Components.Departments.prototype.constructor = $Map.Components.Departments;