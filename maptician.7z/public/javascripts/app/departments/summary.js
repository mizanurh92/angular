$Map.Components.DeparmentsSummary = function(){
	// General Parameters
	this.group = 'departmentsSummary';
	this.namspace = 'departmentsSummary';
	this.fileName = 'departments_summary';
	this.url = '../api/departments/summary/summaryData';

	// Screen Objects
	this.contentWrapper = $("#departmentSummary");
	this.tile0 = this.contentWrapper.find('.tile-0');
	this.tile1 = this.contentWrapper.find('.tile-1');
	this.tile2 = this.contentWrapper.find('.tile-2');
	this.tile3 = this.contentWrapper.find('.tile-3');
	this.tile4 = this.contentWrapper.find('.tile-4');
	this.tile5 = this.contentWrapper.find('.tile-5');
	this.tile6 = this.contentWrapper.find('.tile-6');
	this.tile7 = this.contentWrapper.find('.tile-7');
	this.tile8 = this.contentWrapper.find('.tile-8');
	this.tile9 = this.contentWrapper.find('.tile-9');

	var Summary = this;

	// Formatting Options
	var numberFormat = d3.format(".0f");
	var decimalFormat = d3.format(".2f");
	var percentFormat = d3.format(".0%");
	var dateFormat = d3.time.format("%Y-%m-%d");
	var shortDate = d3.time.format("%b-%d '%y");
	var longDate = d3.time.format("%B %d, %Y");

	this.open = function(){
		console.log('opening')
		this.setTiles();
		this.setCharts();
		this.getData();
		this.setBindings();
	}

	this.exit = function(){
		console.log('exiting')
		this.unsetTiles();
		this.unsetCharts();
		this.clearData();
		this.unsetBindings();
	}

	this.refresh = function(){

	}

	this.setTiles = function(){
		console.log('setting tiles')
		this.tile0.css({display:"inline-block"}).addClass('dc-select-box tall').find(".header").html("Offices");
		this.tile1.css({display:"inline-block"}).addClass('dc-select-box tall').find(".header").html("Departments");
		this.tile2.css({display:"inline-flex"}).addClass('dc-number').find(".header").html("Office Occupants");
		this.tile3.css({display:"inline-flex"}).addClass('dc-number').find(".header").html("Seat Utilization");
		this.tile4.css({display:"inline-flex"}).addClass('dc-number').find(".header").html("Available Seats");
		this.tile5.css({display:"inline-flex"}).addClass('dc-number').find(".header").html("Seat Efficiency");
		this.tile6.css({display:"inline-flex"}).addClass('dc-number').find(".header").html("Reservable Seats");
		this.tile7.css({display:"inline-flex"}).addClass('dc-number').find(".header").html("Reservable Rooms");
		this.tile8.css({display:"inline-flex"}).addClass('dc-number').find(".header").html("Assigned Seats");		
		this.tile9.css({display:"inline-flex"}).addClass('dc-number').find(".header").html("Assignable Seats");
	}

	this.unsetTiles = function(){
		tile0.css({display:"none"}).find(".header").html("");
		tile1.css({display:"none"}).find(".header").html("");
		tile2.css({display:"none"}).find(".header").html("");
		tile3.css({display:"none"}).find(".header").html("");
		tile4.css({display:"none"}).find(".header").html("");
		tile5.css({display:"none"}).find(".header").html("");
		tile6.css({display:"none"}).find(".header").html("");
		tile7.css({display:"none"}).find(".header").html("");
		tile8.css({display:"none"}).find(".header").html("");
		tile9.css({display:"none"}).find(".header").html("");
	}

	this.setCharts = function(){
		this.chart0 = dc.selectMenu(this.tile0[0],this.group);
		this.chart1 = dc.selectMenu(this.tile1[0],this.group);
		this.chart2 = dc.numberDisplay(this.tile2[0],this.group);
		this.chart3 = dc.numberDisplay(this.tile3[0],this.group);
		this.chart4 = dc.numberDisplay(this.tile4[0],this.group);
		this.chart5 = dc.numberDisplay(this.tile5[0],this.group);
		this.chart6 = dc.numberDisplay(this.tile6[0],this.group);
		this.chart7 = dc.numberDisplay(this.tile7[0],this.group);
		this.chart8 = dc.numberDisplay(this.tile8[0],this.group);
		this.chart9 = dc.numberDisplay(this.tile9[0],this.group);
	}

	this.unsetCharts = function(){
		this.chart0 && dc.deregisterChart(this.chart0,this.group);
		this.chart1 && dc.deregisterChart(this.chart1,this.group);
		this.chart2 && dc.deregisterChart(this.chart2,this.group);
		this.chart3 && dc.deregisterChart(this.chart3,this.group);
		this.chart4 && dc.deregisterChart(this.chart4,this.group);
		this.chart5 && dc.deregisterChart(this.chart5,this.group);
		this.chart6 && dc.deregisterChart(this.chart6,this.group);
		this.chart7 && dc.deregisterChart(this.chart7,this.group);
		this.chart8 && dc.deregisterChart(this.chart8,this.group);
		this.chart9 && dc.deregisterChart(this.chart9,this.group);
		this.chart0 = null;
		this.chart1 = null;
		this.chart2 = null;
		this.chart3 = null;
		this.chart4 = null;
		this.chart5 = null;
		this.chart6 = null;
		this.chart7 = null;
		this.chart8 = null;
		this.chart9 = null;
	}

	this.getData = function(){
		$.ajax({
			type:"GET",
			url: this.url
		})
		.then(function(data){
			//data = Summary.formatData(data);
			console.log(data)
			Summary.setDataObjects(data);
			Summary.configureCharts();
			Summary.renderCharts();
		})
		.catch(function(err){
			console.log(err);
		})
	}

	this.setDataObjects = function(data){
		console.log(data)
		this.data = crossfilter(data);
		console.log(this.data)
		this.groupAll = this.data.groupAll().reduce(
	        function (p, v) { /* callback for when data is added to the current filter results */
	            p.occupants += v.occupants;
	            p.resRooms += v.resRoom;
	            p.resSeats += v.resSeat;
	            p.assigned += v.assigned;
	            p.assignable += v.assignable;
	            p.available += v.assignable - v.assigned;
	            console.log(p)
	            return p;
	        }, /* callback for when data is removed from the current filter results */
	        function (p, v) {
	            p.occupants -= v.occupants;
	            p.resRooms -= v.resRoom;
	            p.resSeats -= v.resSeat;
	            p.assigned -= v.assigned;
	            p.assignable -= v.assignable;
	            p.available -= v.assignable - v.assigned;
	            return p;
	        },
	        function () { /* initialize p */
	            return {
	                occupants: 0,
	                resRooms: 0,
	                resSeats: 0,
	                assigned: 0,
	                assignable: 0,
	                available: 0
	            };
	        }
	    );

		this.officeDim = this.data.dimension(function(d){ return d.office; });
		this.officeGroup = this.officeDim.group();

		this.departmentDim = this.data.dimension(function(d){ return d.deptName; });
		this.departmentGroup = this.departmentDim.group();
	}

	this.configureCharts = function(){
	    this.chart0
           	.dimension(this.officeDim)
           	.group(this.officeGroup)
           	.multiple(true)
			.title(function(d){return d.key;})		
	    this.chart1
           	.dimension(this.departmentDim)
           	.group(this.departmentGroup)
           	.multiple(true)
           	.title(function(d){return d.key;})
		this.chart2.group(this.groupAll)
			.valueAccessor(function (p) {return p.occupants;})
			.formatNumber(numberFormat);
		this.chart3
			.group(this.groupAll)
			.valueAccessor(function (p) {return p.assignable ? p.assigned/p.assignable : 0})
			.formatNumber(percentFormat);
		this.chart4
			.group(this.groupAll)
			.valueAccessor(function (p) {return p.available})
			.formatNumber(numberFormat);
		this.chart5
			.group(this.groupAll)
			.valueAccessor(function (p) {return (p.assignable + p.resSeats) > 0 ? p.occupants / (p.assignable + p.resSeats) : 0})
			.formatNumber(percentFormat);
		this.chart6
			.group(this.groupAll)
			.valueAccessor(function (p) {return p.resSeats})
			.formatNumber(numberFormat);
		this.chart7
			.group(this.groupAll)
			.valueAccessor(function (p) {return p.resRooms})
			.formatNumber(numberFormat);
		this.chart8
			.group(this.groupAll)
			.valueAccessor(function (p) {return p.assigned})
			.formatNumber(numberFormat);											
		this.chart9
			.group(this.groupAll)
			.valueAccessor(function (p) {return p.assignable;})
			.formatNumber(numberFormat);
	}

	this.refreshData = function(){
	}

	this.clearData = function(){
		Summary.data = null;
		Summary.all = null;
		Summary.officeDim = null;
		Summary.officeGroup = null;
		Summary.departmentDim = null;
		Summary.departmentGroup = null;	
	}

	this.formatData = function(data){
		var formatted = [];
		data.forEach(function(d){})
		return formatted;
	}

	this.renderCharts = function(){
		dc.renderAll(this.group);
	}

	this.setBindings = function(){
	}

	this.unsetBindings = function(){
	}
}
$Map.Components.DeparmentsSummary.prototype.constructor = $Map.Components.DeparmentsSummary;