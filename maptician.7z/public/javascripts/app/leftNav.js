$Map.Components = $Map.Components || {};
$Map.Components.Nav = $Map.Components.Nav || {};

$Map.Components.Nav.NavController = function(){
	this.sideBarMinimized = false;
	this.leftNav = $("#leftNavBar"); // Div for the left navbar
	this.navList = $("#side-menu"); // UL for the left navbar
	this.menuButtons = $(".lev-1",this.navList); // Main Side buttons
	this.navHeader = $("#navHeader"); // Header in the upper left corner
	this.profileImg = $("#profilePic"); // Image in the navHeader
	
	this.clickDetector = $("#clickDetector"); // Transparent div used with profile menu
	this.leftNavToggle = $(".leftNavToggle",this.navHeader); // Class containing min and max buttons
	this.minimize = $("#sidebarMin");
	this.maximize = $("#sidebarMax");
	this.nameContainer = $("#profileNameContainer");
	this.contentAreas = $("#wrapper>.contentArea");
	this.tabSelectors = $("#wrapper>.tabSelectors");
	this.topNav = $("#topNav");

	this.profileSelector = $("#profileSelector"); // Drop down profile menu
	this.selectorOptions = this.profileSelector.find('li');  // Options for drop down profile menu

	this.minimizedWidth = 70;
	this.maximizedWidth = 170;
	this.openController = null; // This is initialized as an object that references the currently active controller
	var Nav = this;

	this.open = function(){
		this.setBindings();
		this.menuSelect('homeMenu'); // Sets the default starting location
	}

	this.exit = function(){
		
		// No Exit code since this must be running at all times
	}

	this.setBindings = function(){

		// Handles the primary navigation using the left-nav
		this.menuButtons.on("click",function(e){
			Nav.menuSelect($(this).attr('id'),e);
		})

		// Handles the expand and collapse button in the side-nav
		this.leftNavToggle.on("click",function(){
			Nav.toggleLeftNav();
		});

		// Handles the visual/css aspects of a click event for left nav buttons
		this.menuButtons.children('a').on("click",function(event){
			var listObj = $(this).parent();
			if(Nav.sideBarMinimized){
				listObj.addClass("selected").siblings().removeClass("selected");
			} else {
				if(listObj.hasClass("selected")){
					listObj.children("ul").slideToggle()
				} else{
					listObj.addClass("selected").siblings().removeClass("selected");
					listObj.children("ul").slideDown(); // Show any child objects
					listObj.siblings().children("ul").slideUp(); // Hide child objects of other selections
				}
			}
		})

		// When profile menu is displayed, a full screen transparent div is enabled behind the menu
		// This transparent div is used to receive any clicks not on the menu and to close the menu
		this.clickDetector.on("click",function(event){
			Nav.resetProfileMenu();
		})

		// Displays the profile menu list.  This is a ul that slides down from the profile image
		this.profileImg.add("#profileName").on("click",function(){
			if(Nav.sideBarMinimized == true){
				Nav.clickDetector.css("pointer-events","auto");
				$(".profileHeader",Nav.profileSelector).css("display","block")
				Nav.profileSelector.css({
					top:"90px",
					left:"0px"
				});
				Nav.profileSelector.slideToggle();
			} else {
				Nav.clickDetector.css("pointer-events","auto");
				Nav.profileSelector.slideToggle();
			}
		})

		// Handles selection of a list item in the profile selector
		this.selectorOptions.on('click',function(){
			var index = $(this).index() - 1; // first index is a header
			$Map.Profile = $Map.Profile || new $Map.Components.Profile.ProfileController(this);
			$Map.Profile.open(index);
			Nav.resetProfileMenu();
		})

		// If the profile menue is visible (as determined by clickDetector being active), pressing
		// escape will close and reset the menu
		$(document).keydown(function(e){
			if(e.which == 27 && Nav.clickDetector.css("pointer-events") == "auto"){
				Nav.resetProfileMenu();
			}
		})
	}

	this.toggleLeftNav = function(minimized){
		Nav.sideBarMinimized = minimized !== undefined ? !minimized : Nav.sideBarMinimized;
		if(Nav.sideBarMinimized){
			// Ajustments to left nav header
			Nav.maximize.hide();
			Nav.profileImg.velocity({top:22,left:52,borderRadius:"8%"});
			Nav.profileImg.css("box-shadow","1px 2px 4px 4px rgba(0,0,0,0.3)")
			Nav.leftNav.velocity({width:Nav.maximizedWidth}); // Width is increased to 170 px
			Nav.navHeader.velocity({height:120}); // Height of header is increased to 120px
			Nav.minimize.add(Nav.nameContainer).fadeIn();

			// Adjustments to left nav button list
			Nav.navList.velocity({marginTop:120}) // Start of unordered list is moved down
			window.setTimeout(function(){
					$("#side-menu li a span").show();
				},300); // Unhides the text labels on the left nav bar
			Nav.menuButtons.children('a').velocity({padding: "12px"});
			Nav.menuButtons.children('a').children('i').velocity({
				fontSize:16,
				width:'30px'
				})
			Nav.contentAreas.add(Nav.tabSelectors).add(Nav.topNav)
				.velocity({left:Nav.maximizedWidth});
			this.navList.removeClass('minimized');
		} else {
			// Ajustments to left nav header
			Nav.minimize.add(Nav.nameContainer).fadeOut();
			Nav.profileImg.velocity({top:22,left:2,borderRadius:"0%"});
			Nav.profileImg.css("box-shadow","0px 0px 0px 0px rgba(0,0,0,0)");
			Nav.leftNav.velocity({width:Nav.minimizedWidth}); // Left nav bar's width is reduced to 70 px
			Nav.navHeader.velocity({height:90}); // Height of header is reduced to 90px 
			Nav.maximize.velocity("fadeIn",{delay:300,duration:200}); // Maximize bar is visible at the top

			// Adjustments to left nav button list
			Nav.navList.velocity({marginTop:95}); // Start of unordered list is moved up
			Nav.menuButtons.children('a').children('span').hide(); // Text labels for left nav bar are turned-off
			Nav.menuButtons.children('a').velocity({padding: "10px"}); // Padding is added to center icons
			Nav.menuButtons.children('a').children('i').velocity({
				fontSize:25,
				width: (Nav.minimizedWidth - 5) + "px"
				}) // Icons for left nav bar are increased in size
			Nav.menuButtons.children('ul').hide(); // Any visible unordered list items are hidden
			Nav.contentAreas.add(Nav.tabSelectors).add(Nav.topNav)
				.velocity({left:Nav.minimizedWidth}); // Adjusts the size and position based on the nav bar size
			this.navList.addClass('minimized');		
		}
		Nav.sideBarMinimized = !Nav.sideBarMinimized;
	}

	this.resetProfileMenu = function(){
		Nav.clickDetector.css("pointer-events","none");
		Nav.profileSelector.slideUp();
		window.setTimeout(function(){
				Nav.profileSelector.css({
					top:"110px",
					left:"15px"
				});
				$(".profileHeader",Nav.profileSelector).css("display","none")
			},500);
	}

	this.menuSelect = function(menuID,e){
		if(this.openController && this.openController.menuID && this.openController.menuID != menuID){
			this.openController.controller.exit();
		} else if(this.openController && this.openController.menuID && this.openController.menuID == menuID){
			if(this.openController.menuID == "viewerMenu" || this.openController.menuID == "editorMenu"){
				this.openController.controller.open(e);
			}
			return;
		}

		this.contentAreas.hide();
		this.tabSelectors.hide();
		this.topNav.hide();

		switch(menuID){
			case "homeMenu":
				$("#homeArea,#topNav").css({display:"block"});
				$Map.Home = $Map.Home || new $Map.Components.Home();
				$Map.Home.open();
				Nav.openController = {
					menuID: menuID,
					controller: $Map.Home
				}				
			break;
			case "companyMenu": 
				$Map.Company = $Map.Company || new $Map.Components.Company();
				$Map.Company.open();
				Nav.openController = {
					menuID: menuID,
					controller: $Map.Company
				}
			break;
			case "officesMenu":
				$Map.Offices = $Map.Offices || new $Map.components.Offices();
				$Map.Offices.open();
				Nav.openController = {
					menuID: menuID,
					controller: $Map.Offices
				}
			break;
			case "deptMenu":
				$Map.Departments = $Map.Departments || new $Map.Components.Departments();
				$Map.Departments.open();
				Nav.openController = {
					menuID: menuID,
					controller: $Map.Departments
				}
			break;		
			case "viewerMenu":
				$Map.Viewer = $Map.Viewer || new MapViewerController();
				$Map.Viewer.open(e);
				Nav.openController = {
					menuID: menuID,
					controller: $Map.Viewer
				}				
			break;
			case "editorMenu":
				$Map.Editor = $Map.Editor || new MapEditorController();
				$Map.Editor.open(e);
				Nav.openController = {
					menuID: menuID,
					controller: $Map.Editor
				}
			break;
			case "scenariosMenu":
				Maptician.PageTables.scenariosTable();
				$("#scenariosArea,#topNav").css({display:"block"}); 
			break;
			case "maintenanceMenu":
				$Map.Maintenance = $Map.Maintenance || new $Map.components.Maintenance();
				$Map.Maintenance.open();
				Nav.openController = {
					menuID: menuID,
					controller: $Map.Maintenance
				}
			break;
		}
	}

	this.open(); // Initializes on load
}
$Map.Components.Nav.NavController.prototype.constructor = $Map.Components.Nav.NavController;