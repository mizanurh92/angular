Maptician.Modals = {};

Maptician.Modals.newMap = function(){
	var newMap = this.newMap;
	var modalElement = $('#newMapModal');

	if(newMap.OfficesTable){
		newMap.OfficesTable.ajax.reload();
		modalElement.modal();
		return;
	} else {
		var table = $("#newMapOfficeAssign");
		var tableURL = "/api/offices/newmaptable";
		var formElement = $('#newMapForm');
		modalElement.modal();	
	}

	newMap.OfficesTable = table.DataTable({
		ajax: {	url:tableURL },
      	select: 'single',
        scrollY: table.parent().height() - 130,
      	deferRender:true,
      	scroller:true,
      	paging:true,
      	columns: [
        	{	
        		width:100,
        		title:'Office Name',
        		data: 'name',
        		class:'leftAlign',
        	},
            {
            	width:100,
            	title:'City',
            	data: 'city',
            	class: 'centerAlign',
        	},
            {	
            	width:40,
            	title:'State',
            	data: 'state',
            	class: 'centerAlign',
        	}
      	],
      	dom: 't',
	})

	var OfficesTable = newMap.OfficesTable;


	if(newMap.hasInit){ // Sets up bindings on first run

	} else {

		_attach.call(newMap.OfficesTable,'officesTableFrame',70,function(height){
			table.parent().css("height",height)
		});

		$.validator.methods.validLength = function( value, element ) {
		  try{
			return this.optional( element ) || parseToInches(value);
		  } catch (err){
		  	return false;
		  }
		}

		newMap.validator = formElement.validate({
			rules: {
				mapNameInput: {
					required: true,
					minlength: 3,
					maxlength: 50
				},
				unitSystem: {
					required: true
				},
				newMapWidthInput: {
					required: true,
					validLength: true
				},
				newMapLengthInput: {
					required: true,
					validLength: true
				},
				floorInput: {
					maxlength: 25
				},
				suiteInput: {
					maxlength: 25
				}
			},
            messages: {
              newMapWidthInput: {validLength: "Please enter a valid distance"},
              newMapLengthInput: {validLength: "Please enter a valid distance"},              
            },
            submitHandler:function(form,event){
				var name, width, length, unitSystem, floor, suite, officeID, options;
				name = $("#mapNameInput").val();
				width = parseToInches($("#newMapWidthInput").val());
				length = parseToInches($("#newMapLengthInput").val());
				unitSystem = $('select[name=unitSystem]',modalElement).val();
				floor = $("#floorInput").val();
				suite = $("#suiteInput").val();
				officeID = newMap.officeID;
	            options = {
					unitSystem:unitSystem,
					floor:floor,
					suite:suite            	
	            }
				Maptician.Editor.newFile(width,length,name,officeID,options);
				$.modal.close();
            }
		})

		modalElement.find(".next").click(function(e){
			var selectedArray = OfficesTable.rows('.selected').data().toArray();
			if(selectedArray.length > 0){
				modalElement.find(".progressbar li").addClass('active');
				$(this).parent().parent().hide().next().show();
				newMap.officeID = selectedArray[0].officeID;
			} else {
				swal({
					title: "Please Select an Office",
					text: "You must assign the new map to an office.  Offices can be created " +
					"in the Offices menu with the necessary access permissions.",
					type: "warning",
					confirmButtonColor: "#525252",    
					confirmButtonText: "OK"
				}).catch(swal.noop)
			}
		})

		modalElement.find(".previous").click(function(e){
			$(this).parent().parent().hide().prev().show();
			newMap.officeID = null;
			modalElement.find(".progressbar li").eq(1).removeClass('active');
		})

		$("#newMapSearch").on( 'input', function () { // Search box for the office table
            OfficesTable.search($("#newMapSearch").val()).draw();
        });

		modalElement.on($.modal.AFTER_CLOSE,function(event,modal){ // Clears the form when the modal is closed
			formElement.get(0).reset();
			formElement.find('fieldset').css("display","");
			newMap.officeID = null;
			modalElement.find(".progressbar li").eq(1).removeClass('active');
			OfficesTable.search($("#newMapSearch").val()).draw();
			newMap.validator.resetForm();
		});

		modalElement.find(".cancel").click(function(){
			$.modal.close();
		})

		// This event listener changes the current distances in the map size inputs to the selected metric system
		$('select[name=unitSystem]', modalElement).on('change', function() {
   			var unitSystem = $('select[name=unitSystem]', modalElement).val();
   			console.log(unitSystem)
   			var defaultUnit;
   			var width,length;
   			switch(unitSystem){
   				case "US":
   					defaultUnit = 'feet';
   				break;
   				case "Metric":
   					defaultUnit = 'meters';
   				break;
   			}
			try{
                width = renderLength(parseToInches($("#newMapWidthInput").val(),{defaultUnit:defaultUnit}),{system:unitSystem,decimal:2});
                $("#newMapWidthInput").val(width);
            } catch(err){}
			try{
                length = renderLength(parseToInches($("#newMapLengthInput").val(),{defaultUnit:defaultUnit}),{system:unitSystem,decimal:2});
                $("#newMapLengthInput").val(length);
            } catch(err){}

		});

		newMap.hasInit = true;
	}
}

Maptician.Modals.setKioskCredentials = function(kiosk){
	var setKioskCredentials = this.setKioskCredentials;
	var kioskID = kiosk.kioskID;
	$("#kioskUserName").val(kiosk.userName);

	$('#kioskCredentialsModal').modal({
	  escapeClose: false,
	  clickClose: false,
	  showClose: false
	});

	if(setKioskCredentials.hasInit){ // Actions for subsequent (but not the first) runs

	} else { // Sets up bindings on first run

		$("#cancelKioskCredentials").on("click",function(){
			$.modal.close();
			$("#kioskUserName,#kioskPassword,#cKioskPassword").val('');
		})

		$("#setKioskCredentials").on("click",function(){
			var pass = $("#kioskPassword").val();
			var cpass = $("#cKioskPassword").val();
			var userName = $("#kioskUserName").val();
			if(pass && cpass && userName && pass == cpass){
				$("#errorMsg").html("");
				$.ajax('/api/kiosks/credentials', {
					method: "POST",
					data: {
						password: pass,
						userName: userName,
						id: kioskID
					},
				    success: function (data) {
				    	$.modal.close();
				    	$("#kioskUserName,#kioskPassword,#cKioskPassword").val('');
				    	Maptician.OfficeTables.kioskList();
				    },
				    error: function (data) {
				    	$("#errorMsg").html(data.responseJSON.errorMsg);
				    }
				});					
			} else {
				if(!pass || !cpass){
					$("#errorMsg").html("Please enter and confirm the password");
				}
				if(!userName){
					$("#errorMsg").html("Please enter a user name");
				}
			}
		})			

		$("#kioskPassword,#cKioskPassword").on("change",function(){
			var pass = $("#kioskPassword").val();
			var cpass = $("#cKioskPassword").val();
			if(pass && cpass){
				if(pass != cpass){
					$("#errorMsg").html("Passwords must match");
				} else {
					$("#errorMsg").html("");
				}
			}
		})

		setKioskCredentials.hasInit = true;
	}
}

Maptician.Modals.sendKioskPin = function(kiosk){
	var sendKioskPin = this.sendKioskPin;

	if(sendKioskPin.hasInit){ // Actions for subsequent (but not the first) runs

	} else { // Sets up bindings on first run

		$("#sendKioskPin").on("click",function(){
			var data = {
				pin: $("#kioskUserPin").val(),
				phoneNo: kiosk.phoneNo,
				first: kiosk.first,
				last:kiosk.last,
				userID: kiosk.userID
			}
			console.log(data);
			if(data.pin.length>0){
				$("#errorMsg").html("");
				if(Maptician.kioskModals.visitorData){
					data.guestName = Maptician.kioskModals.visitorData.name;
					data.guestEmail = Maptician.kioskModals.visitorData.email;
					data.guestCompany = Maptician.kioskModals.visitorData.company;
					data.guestMobile = Maptician.kioskModals.visitorData.mobile;
					data.guestPurpose = Maptician.kioskModals.visitorData.purpose;
				}
				$.ajax('/api/sms/sendsms', {
					method: "POST",
					data: data,
				    success: function (data) {
						$(".lightBox").hide();
						$("#pinsuccessMsg").show();
				    	$("#kioskUserPin").val('');
						$('#sucessBody').html("A sms has been sent successfuly!!!!! Please wait....");
						$("#goTohomePage").on('click',function(){
							$('#kioskpinValidatorModal').modal('hide');
							$(".contentArea").removeClass("activeTab");
							$("#kioskHomeArea").addClass("activeTab");
							sessionStorage.clear();
							Maptician.kioskModals.visitorData = null;
						})
						
				    },
				    error: function (data) {
				    	$("#pinerrorMsg").html("<p>Pin number not found</p>");
						
				    }
				});					
			} else {
				console.log("out of the loop")
			}
		})			

		sendKioskPin.hasInit = true;
	}
}