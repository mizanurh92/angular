$Map.Components = $Map.Components || {};

$Map.Components.Home = function(){
	this.area = $("#homeArea");
	this.topNav = $("#topNav");
	this.namespace = '.home';
	var Home = this;

	this.open = function(){
		this.area.show();
		this.topNav.show();
		this.setBindings();
	}

	this.exit = function(){
		this.unsetBindings(this.namespace);
	}

	this.setBindings = function(){
		
	}

	this.unsetBindings = function(namespace){
		this.area.off(this.namespace);
	}

}
$Map.Components.Home.prototype.constructor = $Map.Components.Home;