$Map.Components = $Map.Components || {};
$Map.Components.Profile = $Map.Components.Profile || {};

$Map.Components.Profile.UserProfileController = function(){
	this.profileNav = $("#userProfileNav"); // Left-nav for the profile menu
	this.navOptions = this.profileNav.find('li'); // Options for the profile menu
	this.profileModal = $("#userProfileModal");
	this.profileContent = this.profileModal.find('.profileContent'); // Content pages in profile modal
	this.okButton = $(".profileControls .ok",this.profileModal);
	this.nameSpace = '.userProfiles';
	var Profile = this;

	this.open = function(userID,img,data,row){
		this.userID = userID;
		this.img = img;
		this.src = data.profile;
		this.data = data;
		this.row = row;
		this.setBindings();
		this.navClick(0);
		this.profileModal.modal();
	}

	this.exit = function(){
		this.unsetBindings();
		if(this.profileData && this.profileData.loaded){
			this.profileData.updateTable(this.data,this.row);
			this.profileData.exit();
		}
		if(this.profileImages && this.profileImages.loaded){
			this.profileImages.updateImage(this.data,this.row,this.img);
			this.profileImages.exit();
		}
		this.profilePreferences && this.profilePreferences.loaded ? this.profilePreferences.exit() : null;
		this.profileAccount && this.profileAccount.loaded ? this.profileAccount.exit() : null;
		this.userID = null;
		this.img = null;
		this.src = null;
		this.data = null;
		this.row = null;
	}

	this.setBindings = function(){
		this.navOptions.on('click' + this.nameSpace,function(){
			var index = $(this).index();
			Profile.navClick(index);
		})

		this.okButton.on('click' + this.nameSpace,function(){
			$.modal.close();
		})

		this.profileModal.on($.modal.CLOSE+this.nameSpace, function(event, modal) {
			Profile.exit();
		});
	}

	this.unsetBindings = function(){
		this.navOptions.off(this.nameSpace);
		this.okButton.off(this.nameSpace);
		this.profileModal.off(this.nameSpace);
	}


	this.navClick = function(index){
		this.navOptions.eq(index).addClass('selected').siblings().removeClass('selected');
		this.profileContent.eq(index).show().siblings(".profileContent").hide();		
		switch(index){
			case 0:
				this.profileData = this.profileData || new $Map.Components.Profile.UserProfileData();
				this.profileData.open(this.userID);
			break;
			case 1:
				this.profileImages = this.profileimages || new $Map.Components.Profile.UserProfileImages(this);
				this.profileImages.open(this.userID,this.data.profile);
			break;
			case 2:
				this.preferences = this.preferences || new $Map.Components.Profile.UserPreferences();
				this.preferences.open(this.userID);
			break;
			case 3:
				this.profileAccount = this.profileAccount || new $Map.Components.Profile.UserAccount();
				this.profileAccount.open(this.userID);
			break;
		}
	}

}
$Map.Components.Profile.UserProfileController.prototype.constructor = $Map.Components.Profile.UserProfileController;


$Map.Components.Profile.UserProfileData = function(){
	this.modalElement = $("#userProfileModal");
	this.saveButton = this.modalElement.find('.save');
	this.firstName = $("#userProfileFirstName");
	this.lastName = $("#userProfileLastName");
	this.email = $("#userProfileEmail");
	this.cell = $("#userProfileCell");
	this.officePhone = $("#userProfileOfficePhone");
	this.title = $("#userProfileTitle");
	this.dept = $("#userProfileDept");
	this.empID = $("#userProfileEmpID");
	this.acctType = $("#userProfileAcctType");
	this.office = $("#userProfileOffice");
	this.nameSpace = '.userProfileData';
	this.loaded = false;
	var profile = this;

	this.open = function(userID){
		if(!this.loaded){
			this.userID = userID;
			this.setBindings();
			this.loadProfileData();
			this.loaded = true;
		}
	}

	this.exit = function(){
		this.clearProfileData();
		this.loaded = false;
		this.userID = null;
	}

	this.setBindings = function(){
		this.saveButton.on('click'+this.nameSpace, function(){
			profile.saveProfileData();
		})
	}

	this.unsetBindings = function(){
		
		this.modalElement.off(this.nameSpace);
	}

	// Updates the users table in the company menu based on updated (or not) profile data
	this.updateTable = function(data,row){
		var loaded = this.loadedData;
		data.first = loaded.first;
		data.last = loaded.last;
		data.email = loaded.email;
		data.employee.employeeID = loaded.employeeID;
		data.employee.title = loaded.title;
		data.employee.department = {
			deptID: loaded.deptID,
			name: loaded.departments[loaded.deptID]
		}
		data.office = {
			officeID: loaded.officeID,
			name: loaded.offices[loaded.officeID]
		}
		row.data(data).draw();
	}

	this.loadProfileData = function(){
		$.ajax({
			type:"get",
			url: "/api/employees/userProfileData",
			data: {userID:this.userID},
			success:function(data){
				profile.loadedData = data;
				profile.firstName.val(data.first);
				profile.lastName.val(data.last);
				profile.email.val(data.email);
				profile.cell.val(data.cell);
				profile.officePhone.val(data.officePhone);
				profile.title.val(data.title);
				profile.empID.val(data.employeeID);
				profile.populateDepartments(data.departments,data.deptID)
				profile.populateUsertypes(data.acctTypes,data.acctType);
				profile.populateOffices(data.offices,data.officeID);
			},
			error:function(err){
				console.log(err);
			}
		})			
	}

	this.populateOffices = function(data,current){
		this.office.empty();
		var option;
		for(var i in data){
			option = data[i];
			this.office.append('<option value="'+i+'">'+option+'</option>')
		}
		this.office.val(current);
	}

	this.populateDepartments = function(data,current){
		this.dept.empty();
		var option;
		for(var i in data){
			option = data[i];
			this.dept.append('<option value="'+i+'">'+option+'</option>')
		}
		this.dept.val(current);
	}

	this.populateUsertypes = function(data,current){
		this.acctType.empty();
		var option;
		for(var i in data){
			option = data[i];
			this.acctType.append('<option value="'+option+'">'+option+'</option>')
		}
		this.acctType.val(current);
	}

	this.saveProfileData = function(){
		var data = {
				userID:this.userID,
				firstName: profile.firstName.val(),
				lastName: profile.lastName.val(),
				email: profile.email.val(),
				cell: profile.cell.val(),
				officePhone: profile.officePhone.val(),
				title: profile.title.val(),
				empID: profile.empID.val(),
				dept: profile.dept.val(),
				acctType: profile.acctType.val(),
				office: profile.office.val()
			}
		var loaded = profile.loadedData;
		this.saveButton.append('<i class="fa fa-gear fa-spin"></i>');
		$.ajax({
			type:"post",
			url: "/api/employees/profileData",
			data: data,
			success:function(result){
				profile.saveButton.find('i').remove();
				loaded.acctType = data.acctType;
				loaded.cell = data.cell;
				loaded.officePhone = data.officePhone;
				loaded.deptID = data.dept;
				loaded.email = data.email;
				loaded.employeeID = data.empID;
				loaded.officeID = data.office;
				loaded.title = data.title;
				loaded.first = data.firstName;
				loaded.last = data.lastName;
			},
			error:function(err){
				profile.saveButton.find('i').remove();
				console.log(err);
				// TODO Add SWAL error
			}
		})			
	}

	this.clearProfileData = function(){
		profile.firstName.val('');
		profile.lastName.val('');
		profile.email.val('');
		profile.cell.val('');
		profile.officePhone.val('');
		profile.title.val('');
		profile.dept.val('');
		profile.empID.val('');
		profile.acctType.val('');
		profile.office.val('');		
	}
}
$Map.Components.Profile.UserProfileData.prototype.constructor = $Map.Components.Profile.UserProfileData;


$Map.Components.Profile.UserProfileImages = function(){
	this.getImgURL = '/api/profileimages/profiles/getUserImages';
	this.cropperElement = $('#userCropperImage');
	this.liveSamples = $("#userCropperLiveSamples");
	this.sizeSlider = $("#userProfileSize");
	this.sliderLabel = $("#userProfileSizeLabel");
	this.imageInput = $("#userUploadProfileImage");
	this.setImageBtn = $("#userSetImage");
	this.defaults = {
		aspectRatio: .75,
		viewMode:1,
		movable:false,
		rotatable:false,
		scalable:false,
		zoomable:false,
		company:null,
	}
	this.nameSpace = '.userProfileLoader';
	this.userID = null;
	this.smallProfile = null;
	this.loaded = false;
	var profile = this;

	this.open = function(userID,imageSrc){
		if(!this.loaded){
			this.smallProfile = imageSrc;
			this.userID = userID;
			this.getLiveImages();
			this.inits();
			this.setBindings();
			this.loaded = true;
		}
	}

	this.exit = function(){
		this.unsetBindings();
		this.cropperElement.cropper('destroy');
		this.cropperElement.attr('src',"images/blankprofile.png");
		this.sizeSlider.slider('destroy');
		var samples = profile.liveSamples;
		$(".largeProfile",samples).attr('src',"images/blankprofile.png");
		$(".smallProfile",samples).attr('src',"images/blankprofile.png");
		$(".thumbnail",samples).attr('src',"images/blankprofile.png");
		this.loaded = false;
	}

	this.updateImage = function(data,row,img){
		img.attr('src',this.smallProfile);
		data.profile = this.smallProfile;
		row.data(data);
	}

	this.getLiveImages = function(){
		$.ajax({
			url: this.getImgURL,
			method: "POST",
			data: {user:this.userID},
			success: function (data) {
				var samples = profile.liveSamples;
				var images = data.images;
				$(".largeProfile",samples).attr('src',images.largeProfile + '?'+Date.now());
				$(".smallProfile",samples).attr('src',images.mediumProfile + '?'+Date.now());
				$(".thumbnail",samples).attr('src',images.smallProfile + '?'+Date.now());
			},
			error: function (err) {
			  console.log(err);
			}
		});
	}

	this.setBindings = function(){
		this.imageInput.on('change'+this.nameSpace,function() { // Initializes image upload event listener
	        var cropper = profile.cropperElement;
	        var fileReader = new FileReader(),
	                files = this.files,
	                file;

	        if (!files.length) {return;}
	        
	        file = files[0]; // Should only be a single file, but limits it to the first just in case

	        if (/^image\/\w+$/.test(file.type)) {
	            fileReader.readAsDataURL(file);
	            fileReader.onload = function () {
	                profile.imageInput.val("");
	                cropper.cropper("reset", true).cropper("replace", this.result);
	            };
	        } else {
	        	// TODO turn into SWAL error
	        	console.log('Please choose an image file.')
	        }
	    });

		this.setImageBtn.on('click'+this.nameSpace,function(){  // Initialize "Set Image" button listener
			profile.setImageBtn.append('<i class="fa fa-gear fa-spin"></i>');

			var imageName,
				dims = {width:100,height:100},
				selected = profile.sizeSlider.slider('value');
			
			switch(selected){ // Sets the dimensions of the uploaded image based on the size selected
				case 0:
					dims = {height:200,width:150};
					imageName = "largeProfile";
				break;
				case 1:
					dims = {height:140,width:105};
					imageName = "smallProfile";
				break;
				case 2:
					dims = {height:100,width:100};
					imageName = "thumbnailProfile";
				break;
			}

			profile.cropperElement.cropper('getCroppedCanvas',dims).toBlob(function(blob){  // Turns the cropper canvas into a blob file and uploads
				  var formData = new FormData();
				  var route;

				  formData.append('croppedImage', blob,imageName);
				  url = '/api/profileimages/profiles/upload/'+profile.userID;
				  
				  $.ajax(route, {
				    method: "POST",
				    url: url,
				    arrayKey: '',
				    data: formData,
				    processData: false,
				    contentType: false,
				    success: function (data) {
				      profile.setImageBtn.find('i').remove();
				      var images = data.images;
				      var samples = profile.liveSamples;
				      switch(selected){
				      	case 0:
				      		$(".largeProfile",samples).attr('src',images.largeProfile + '?'+Date.now())
				      	break;
				      	case 1:
				      		$(".smallProfile",samples).attr('src',images.mediumProfile + '?'+Date.now())
				      	break;
				      	case 2:
				      		$(".thumbnail",samples).attr('src',images.smallProfile + '?'+Date.now());
				      		profile.smallProfile = images.smallProfile + '?'+Date.now();
				      	break;
				      }
				    },
				    error: function () {
				      profile.setImageBtn.find('i').remove();
				      console.log('Upload error');
				      // TODO Make a SWAL error for this
				    }
				  });
			});
		})
	}

	this.unsetBindings = function(){
		this.imageInput.off(this.nameSpace);
		this.setImageBtn.off(this.nameSpace);
	}

	this.inits = function(){
		var defaults = this.defaults;
		this.cropperElement.cropper({
			aspectRatio: defaults.aspectRatio,
			viewMode: defaults.viewMode,
			movable: defaults.movable,
			rotatable: defaults.rotatable,
			scalable: defaults.scalable,
			zoomable: defaults.zoomable,
			responsive: true,// Initialize Cropper Widget
		});

		this.sizeSlider.slider({ // Initialize Size Slider
			value:0,
			min: 0,
			max: 2,
			step: 1,
			slide: function(event,ui){
	            var message;
	            var aspect;
	            switch(ui.value){
	                case 0:
	                message = "Large Profile";
	                aspect = .75;
	                break;
	                case 1:
	                message = "Small Profile";
	                aspect = .75;
	                break;
	                case 2:
	                message = "Thumbnail Profile"
	                aspect = 1;
	                break;
	            }
				profile.cropperElement.cropper('setAspectRatio',aspect);
	            profile.sliderLabel.html(message);
	    	}
		});

		this.hasInit = true;
	}
}
$Map.Components.Profile.UserProfileImages.prototype.constructor = $Map.Components.Profile.UserProfileImages;


$Map.Components.Profile.UserPreferences = function(){
	this.profileModal = $("#userProfileModal");
	this.searchable = $("#userKioskSearchable");
	this.contactable = $("#userKioskContactable");
	this.codeRequired = $("#userKioskCodeRequired");
	this.listenerGroup = "preferences";
	this.userID = null;
	var Preferences = this;

	this.open = function(userID){
		this.userID = userID;
		this.loadPreferences();
		this.setBindings();
	}

	this.exit = function(){
		this.unsetBindings();
		this.userID = null;
	}

	this.loadPreferences = function(){
		$.ajax({
			type:"get",
			url: "/api/employees/preferences",
			data: {userID: this.userID},
			success:function(data){
				Preferences.searchable.prop("checked",data.searchable);
				Preferences.contactable.prop("checked",data.contactable);
				Preferences.codeRequired.prop("checked",data.codeRequired);
			},
			error:function(err){
				console.log(err);
			}
		})
	}

	this.setPreference = function(data,object){
		$.ajax({
			type:"POST",
			url: "/api/employees/preferences",
			data: data,
			success:function(data){
				$(object).parent().next().html("").hide();
			},
			error:function(err){
				$(object).prop("checked",err).parent().next().html("An error occured").show();
			}
		})
	}

	this.setBindings = function(){
		this.searchable.on('change.' + this.listenerGroup,function(e){
			var data = {
				kioskSearchable: Preferences.searchable.prop("checked"),
				userID: Preferences.userID
			}
			Preferences.setPreference(data,this);
		})
		
		this.contactable.on('change.' + this.listenerGroup,function(e){
			var data = {
				contactable: Preferences.contactable.prop("checked"),
				userID: Preferences.userID
			}
			Preferences.setPreference(data,this);
		})
		
		this.codeRequired.on('change.' + this.listenerGroup,function(e){
			var data = {
				codeRequired: Preferences.codeRequired.prop("checked"),
				userID: Preferences.userID
			}
			Preferences.setPreference(data,this);
		})
	}

	this.unsetBindings = function(){
		this.profileModal.off('.'+this.listenerGroup);
	}
}
$Map.Components.Profile.UserPreferences.prototype.constructor = $Map.Components.Profile.UserPreferences;


$Map.Components.Profile.UserAccount = function(){
	this.changePasswordForm = $("#changePasswordForm");
	this.changePasswordStatus = this.changePasswordForm.find('.result');
	this.changePasswordButton = $("#changePassword");
	this.closeSessionsButton = $("#closeSessions");
	this.oldPassword = $("#oldPassword");
	this.newPassword = $("#newPassword");
	this.retypePassword = $("#retypePassword");

	var Account = this;

	this.closeSession = function(){
		$.ajax({
			type:"get",
			url: "/api/authentication/closeSessions",
			success:function(data){
				console.log('success');
			},
			error:function(err){
				console.log('err');
			}
		})		
	}

	this.changePasswordValidator = this.changePasswordForm.validate({
		onkeyup:false,
		onfocusout:false,
		rules:{
			oldPassword:{
				required: true
			},
			newPassword:{
				required: true,
				diffFromOld: true,
				strongPassword: true,
			},
			retypePassword:{
				required: true,
				sameAsPass: true
			}
		},
		messages:{
			oldPassword:{
				required: "Please enter your existing password"
			},
			newPassword:{
				required: "Please enter the new password",
				diffFromOld: "New password must be different from the old password",
				strongPassword: "Password must be between 8 and 15 characters, contain an uppercase, lowercase, and a number"
			},
			retypePassword:{
				required: "Please retype the new password",
				sameAsPass: "Passwords do not match"
			}
		},
		submitHandler:function(form,event){
			var data = {
				oldPassword: Account.oldPassword.val(),
				newPassword: Account.newPassword.val()
			}
			Account.changePasswordForm.find('.spinner').addClass('spinning');
			$.ajax({
				type:"POST",
				url: "/api/authentication/changePassword",
				data:data,
				dataType:'json',
				success:function(data){
					Account.changePasswordForm.find('.spinner').removeClass('spinning');
					Account.changePasswordStatus
						.html('Password changed successfully')
						.addClass('success');
					Account.oldPassword.val('');
					Account.newPassword.val('');
					Account.retypePassword.val('');
				},
				error:function(err){
					Account.changePasswordForm.find('.spinner').removeClass('spinning');
					Account.changePasswordStatus
						.html(err.responseJSON.err)
						.addClass('error');					
				}
			})
		}
	})

	this.closeSessionsButton.on('click',function(){
		Account.closeSession();
	})
}
$Map.Components.Profile.UserAccount.prototype.constructor = $Map.Components.Profile.UserAccount;