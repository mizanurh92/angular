$Map.Components = $Map.Components || {};
$Map.Components.Profile = $Map.Components.Profile || {};

$Map.Components.Profile.ProfileController = function(){
	this.profileNav = $("#profileNav"); // Left-nav for the profile menu
	this.navOptions = this.profileNav.find('li'); // Options for the profile menu
	this.profileModal = $("#profileModal");
	this.profileContent = this.profileModal.find('.profileContent'); // Content pages in profile modal
	this.okButton = $(".profileControls .ok",this.profileModal);
	this.nameSpace = ".profileController";
	var Profile = this;

	this.open = function(index){
		this.setBindings();
		this.navClick(index);
		this.profileModal.modal();
	}

	this.exit = function(){ // Called on modal close
		this.unsetBindings();
		this.profileData && this.profileData.loaded ? this.profileData.exit() : null;
		this.profileImages && this.profileImages.loaded ? this.profileImages.exit() : null;
		this.profilePreferences && this.profilePreferences.loaded ? this.profilePreferences.exit() : null;
		this.profileAccount && this.profileAccount.loaded ? this.profileAccount.exit() : null;
	}

	this.setBindings = function(){
		this.navOptions.on('click'+this.nameSpace,function(){
			var index = $(this).index();
			Profile.navClick(index);
		})

		this.okButton.on('click'+this.nameSpace,function(){
			$.modal.close();
		})

		this.profileModal.on($.modal.CLOSE+this.nameSpace, function(event, modal) {
			Profile.exit();
		});
	}

	this.unsetBindings = function(){
		this.navOptions.off(this.nameSpace);
		this.okButton.off(this.nameSpace);
		this.profileModal.off(this.nameSpace);
	}

	this.navClick = function(index){
		this.navOptions.eq(index).addClass('selected').siblings().removeClass('selected');
		this.profileContent.eq(index).show().siblings(".profileContent").hide();		
		switch(index){
			case 0:
				this.profileData = this.profileData || new $Map.Components.Profile.ProfileData();
				this.profileData.open();
			break;
			case 1:
				this.profileImages = this.profileimages || new $Map.Components.Profile.ProfileImages();
				this.profileImages.open();
			break;
			case 2:
				this.profilePreferences = this.profilePreferences || new $Map.Components.Profile.Preferences();
				this.profilePreferences.open();
			break;
			case 3:
				this.profileAccount = this.profileAccount || new $Map.Components.Profile.Account();
				this.profileAccount.open();
			break;
		}
	}
}
$Map.Components.Profile.ProfileController.prototype.constructor = $Map.Components.Profile.ProfileController;

$Map.Components.Profile.ProfileData = function(){
	this.firstName = $("#profileFirstName");
	this.lastName = $("#profileLastName");
	this.email = $("#profileEmail");
	this.cell = $("#profileCell");
	this.officePhone = $("#profileOfficePhone");
	this.title = $("#profileTitle");
	this.dept = $("#profileDept");
	this.empID = $("#profileEmpID");
	this.acctType = $("#profileAcctType");
	this.office = $("#profileOffice");
	this.loaded = false;
	var profile = this;

	this.open = function(){
		if(!this.loaded){
			this.loadProfileData();
			this.loaded = true;
		}
	}

	this.exit = function(){
		this.loaded = false;
	}

	this.loadProfileData = function(){
		$.ajax({
			type:"get",
			url: "/api/employees/profileData",
			success:function(data){
				profile.firstName.html(data.first);
				profile.lastName.html(data.last);
				profile.email.html(data.email);
				profile.cell.html(data.cell);
				profile.officePhone.html(data.officePhone);
				profile.title.html(data.title);
				profile.dept.html(data.dept);
				profile.empID.html(data.employeeID);
				profile.acctType.html(data.acctType);
				profile.office.html(data.office);
			},
			error:function(err){
				console.log(err);
			}
		})			
	}
}
$Map.Components.Profile.ProfileData.prototype.constructor = $Map.Components.Profile.ProfileData;

$Map.Components.Profile.ProfileImages = function(){
	this.getImgURL = '/api/profileimages/profiles/getCurrentUserImages';
	this.cropperElement = $('#cropperImage');
	this.liveSamples = $("#cropperLiveSamples");
	this.sizeSlider = $("#profileSize");
	this.sliderLabel = $("#profileSizeLabel");
	this.imageInput = $("#uploadProfileImage");
	this.setImageBtn = $("#setImage");
	this.defaults = {
		aspectRatio: .75,
		viewMode:1,
		movable:false,
		rotatable:false,
		scalable:false,
		zoomable:false,
		company:null,
	}
	this.nameSpace = ".profileImages";
	this.userID;
	this.self;
	this.loaded = false;
	var profile = this;

	this.open = function(){
		if(!this.loaded){
			this.getLiveImages();
			this.inits();
			this.setBindings();
			this.loaded = true;
		}
	}

	this.exit = function(){
		this.cropperElement.cropper('destroy');
		this.cropperElement.attr('src',"images/blankprofile.png");
		this.sizeSlider.slider('destroy');
		this.unsetBindings();
		this.loaded = false;
	}

	this.getLiveImages = function(){
		$.ajax({
			url: this.getImgURL,
			method: "POST",
			success: function (data) {
				var samples = profile.liveSamples;
				var images = data.images;
				$(".largeProfile",samples).attr('src',images.largeProfile + '?'+Date.now());
				$(".smallProfile",samples).attr('src',images.mediumProfile + '?'+Date.now());
				$(".thumbnail",samples).attr('src',images.smallProfile + '?'+Date.now());
			},
			error: function () {
			  console.log('Error');
			}
		});
	}

	this.setBindings = function(){
		this.imageInput.on('change'+this.nameSpace,function() { // Initializes image upload event listener
	        var cropper = profile.cropperElement;
	        var fileReader = new FileReader(),
	                files = this.files,
	                file;
	        
	        if (!files.length) {return;}
	        
	        file = files[0]; // Should only be a single file, but limits it to the first just in case

	        if (/^image\/\w+$/.test(file.type)) {
	            fileReader.readAsDataURL(file);
	            fileReader.onload = function () {
	                profile.imageInput.val("");
	                cropper.cropper("reset", true).cropper("replace", this.result);
	            };
	        } else {
	        	// TODO turn into SWAL error
	        	console.log('Please choose an image file.')
	        }
	    });

		this.setImageBtn.on("click"+this.nameSpace,function(){  // Initialize "Set Image" button listener
			var imageName,
				dims = {width:100,height:100},
				selected = profile.sizeSlider.slider('value');
			
			switch(selected){ // Sets the dimensions of the uploaded image based on the size selected
				case 0:
					dims = {height:200,width:150};
					imageName = "largeProfile";
				break;
				case 1:
					dims = {height:140,width:105};
					imageName = "smallProfile";
				break;
				case 2:
					dims = {height:100,width:100};
					imageName = "thumbnailProfile";
				break;
			}

			profile.cropperElement.cropper('getCroppedCanvas',dims).toBlob(function(blob){  // Turns the cropper canvas into a blob file and uploads
				  var formData = new FormData();
				  var route;

				  formData.append('croppedImage', blob,imageName);
				  
				  $.ajax(route, {
				    method: "POST",
				    url: '/api/profileimages/profiles/myProfile',
				    arrayKey: '',
				    data: formData,
				    processData: false,
				    contentType: false,
				    success: function (data) {
				      var images = data.images;
				      switch(selected){
				      	case 0:
				      		$(".largeProfile").attr('src',images.largeProfile + '?'+Date.now())
				      	break;
				      	case 1:
				      		$(".smallProfile").attr('src',images.mediumProfile + '?'+Date.now())
				      	break;
				      	case 2:
				      		$(".thumbnail").attr('src',images.smallProfile + '?'+Date.now());
				      		$("#profilePic").attr('src',images.smallProfile + '?'+Date.now());
				      	break;
				      }
				    },
				    error: function () {
				      console.log('Upload error');
				    }
				  });
			});
		})
	}

	this.unsetBindings = function(){
		this.imageInput.off(this.nameSpace);
		this.setImageBtn.off(this.nameSpace);
	}

	this.inits = function(){
		var defaults = this.defaults;
		this.cropperElement.cropper({
			aspectRatio: defaults.aspectRatio,
			viewMode: defaults.viewMode,
			movable: defaults.movable,
			rotatable: defaults.rotatable,
			scalable: defaults.scalable,
			zoomable: defaults.zoomable,
			responsive: true,// Initialize Cropper Widget
		});

		this.sizeSlider.slider({ // Initialize Size Slider
			value:0,
			min: 0,
			max: 2,
			step: 1,
			slide: function(event,ui){
	            var message;
	            var aspect;
	            switch(ui.value){
	                case 0:
	                message = "Large Profile";
	                aspect = .75;
	                break;
	                case 1:
	                message = "Small Profile";
	                aspect = .75;
	                break;
	                case 2:
	                message = "Thumbnail Profile"
	                aspect = 1;
	                break;
	            }
				profile.cropperElement.cropper('setAspectRatio',aspect);
	            profile.sliderLabel.html(message);
	    	}
		});
	}
}
$Map.Components.Profile.ProfileImages.prototype.constructor = $Map.Components.Profile.ProfileImages;

$Map.Components.Profile.Preferences = function(){
	this.profileModal = $("#profileModal");
	this.searchable = $("#kioskSearchable");
	this.contactable = $("#kioskContactable");
	this.codeRequired = $("#kioskCodeRequired");
	this.nameSpace = ".profilePreferences";
	this.loaded = false;
	var Preferences = this;

	this.open = function(){
		if(!this.loaded){
			this.loadPreferences();
			this.setBindings();
			this.loaded = true;
		}
	}

	this.exit = function(){
		this.unsetBindings();
		this.loaded = false;
	}

	this.setBindings = function(){
		this.searchable.on('change' + this.nameSpace,function(e){
			var data = {
				kioskSearchable: Preferences.searchable.prop("checked")
			}
			Preferences.setPreference(data,this);
		})
		
		this.contactable.on('change' + this.nameSpace,function(e){
			var data = {
				contactable: Preferences.contactable.prop("checked")
			}
			Preferences.setPreference(data,this);
		})
		
		this.codeRequired.on('change' + this.nameSpace,function(e){
			var data = {
				codeRequired: Preferences.codeRequired.prop("checked")
			}
			Preferences.setPreference(data,this);
		})
	}

	this.unsetBindings = function(){
		
		this.profileModal.off(this.nameSpace);
	}

	this.loadPreferences = function(){
		$.ajax({
			type:"get",
			url: "/api/employees/preferences",
			success:function(data){
				Preferences.searchable.prop("checked",data.searchable);
				Preferences.contactable.prop("checked",data.contactable);
				Preferences.codeRequired.prop("checked",data.codeRequired);
			},
			error:function(err){
				console.log(err);
			}
		})
	}

	this.setPreference = function(data,object){
		$.ajax({
			type:"POST",
			url: "/api/employees/preferences",
			data: data,
			success:function(data){
				$(object).parent().next().html("").hide();
			},
			error:function(err){
				$(object).prop("checked",err).parent().next().html("An error occured").show();
			}
		})
	}
}
$Map.Components.Profile.Preferences.prototype.constructor = $Map.Components.Profile.Preferences;

$Map.Components.Profile.Account = function(){
	this.changePasswordForm = $("#changePasswordForm");
	this.changePasswordStatus = this.changePasswordForm.find('.result');
	this.changePasswordButton = $("#changePassword");
	this.closeSessionsButton = $("#closeSessions");
	this.oldPassword = $("#oldPassword");
	this.newPassword = $("#newPassword");
	this.retypePassword = $("#retypePassword");
	this.nameSpace = ".profileAccount";
	this.loaded = false; // Used since we don't want to unload until the modal is closed
	var Account = this;

	this.open = function(){
		if(!this.loaded){
			this.setBindings();
			this.loaded = true;			
		}
	}

	this.exit = function(){
		this.unsetBindings();
		this.loaded = false;
	}

	this.setBindings = function(){
		
		this.closeSessionsButton.on('click'+this.nameSpace,function(){
			Account.closeSession();
		})

		// Something like an event listener, but actually sets the submit event call back
		this.changePasswordValidator = this.changePasswordForm.validate({
			onkeyup:false,
			onfocusout:false,
			rules:{
				oldPassword:{
					required: true
				},
				newPassword:{
					required: true,
					diffFromOld: true,
					strongPassword: true,
				},
				retypePassword:{
					required: true,
					sameAsPass: true
				}
			},
			messages:{
				oldPassword:{
					required: "Please enter your existing password"
				},
				newPassword:{
					required: "Please enter the new password",
					diffFromOld: "New password must be different from the old password",
					strongPassword: "Password must be between 8 and 15 characters, contain an uppercase, lowercase, and a number"
				},
				retypePassword:{
					required: "Please retype the new password",
					sameAsPass: "Passwords do not match"
				}
			},
			submitHandler:function(form,event){
				var data = {
					oldPassword: Account.oldPassword.val(),
					newPassword: Account.newPassword.val()
				}
				Account.changePasswordForm.find('.spinner').addClass('spinning');
				$.ajax({
					type:"POST",
					url: "/api/authentication/changePassword",
					data:data,
					dataType:'json',
					success:function(data){
						Account.changePasswordForm.find('.spinner').removeClass('spinning');
						Account.changePasswordStatus
							.html('Password changed successfully')
							.addClass('success');
						Account.oldPassword.val('');
						Account.newPassword.val('');
						Account.retypePassword.val('');
					},
					error:function(err){
						Account.changePasswordForm.find('.spinner').removeClass('spinning');
						Account.changePasswordStatus
							.html(err.responseJSON.err)
							.addClass('error');					
					}
				})
			}
		})
	}

	this.unsetBindings = function(){
		
		this.closeSessionsButton.off(this.nameSpace);

		this.changePasswordValidator.destroy();
		this.changePasswordValidator = null;
	}

	this.closeSession = function(){
		$.ajax({
			type:"get",
			url: "/api/authentication/closeSessions",
			success:function(data){
				location.reload();
			},
			error:function(err){
				console.log('err');
			}
		})		
	}
}
$Map.Components.Profile.Account.prototype.constructor = $Map.Components.Profile.Account;