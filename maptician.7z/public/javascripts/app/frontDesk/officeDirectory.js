Maptician.PageTables ? null : Maptician.PageTables = {};

Maptician.PageTables.officeDirectoryTable = function(){
	var pageTables = Maptician.PageTables;
	var officeDirectoryTable = pageTables.officeDirectoryTable;
	var OfficeDirectoryTable;

	if(officeDirectoryTable.hasInit){
		Maptician.PageTables.OfficeDirectoryModal.ajax.reload();
		return;
	}

	pageTables.OfficeDirectoryTable = $('#officeDirectoryTable').DataTable({
		ajax: "/api/kiosks/userlist",
		scrollY: $("#officeDirectoryTable").parent().height() - 73,
		deferRender: true,
		scroller: true,
		paging: true,
		order: [[ 1, 'asc' ]],
		columns:[
			{
				data: {},
				width:'50px',
				title: "",
				sortable:false,
				className:'tableProfileImage',
				render: function(user){
					return '<div><img src="'+user.profile+'"></div>';
				}
			},
			{
				data: {},
				width:'300px',
				sortable:true,
				className:'leftAlign',
				render: function(user){
					if(user.first && user.last){
						return user.first + " " + user.last;
					} else if(user.first){
						return user.first;
					} else if(user.last){
						return user.last;
					} else {
						return ""
					}
				}
			},
			{   
				data: {}, // Employee Title
				width:'200px',
				title: "Title",
				className:'leftAlign',
				render: function(user){
					if(user.employee && user.employee.title){
						return user.employee.title;
					} else {
						return "";
					}
				}
			},
			{   
				data: {},  // Department
				width:'200px',
				title: "Department",
				className:'leftAlign',
				render: function(user){
					if(user.employee && user.employee.department && user.employee.department.name){
						return user.employee.department.name;
					} else {
						return "";
					}                   
				}
			},
			{   
				data: {},  // Floor
				width:'200px',
				title: "Floor",
				className:'centerAlign',
				render: function(user){
					if(user.seat){
						return user.seat.floor;
					} else {
						return "";						
					}                
				}
			},
			{   
				data: {},  // Suite
				width:'200px',
				title: "Suite",
				className:'centerAlign',
				render: function(user){
					if(user.seat){
						return user.seat.suite;
					} else {
						return "";						
					}                   
				}
			},
			{   
				data: {},  // Seat
				width:'200px',
				title: "Seat",
				class: 'centerAlign',
				render: function(user){
					if(user.seat == undefined){
						return "";
					} else {
						return user.seat.seatName;
					}
				}
			},
			{   
				data: {},  // Contact Button
				width:'200px',
				sortable:false,
				class: 'flexCenter',
				render: function(user){
					if(user.contactable){
						return '<div class="btn contactUserBtn" href="#">Contact</div>';
					} else {
						return "";
					}
				}
			},
		],
		dom: 'rt',
	})

	$("#div2Content").addClass("light-content");

	OfficeDirectoryTable = pageTables.OfficeDirectoryTable

	if(officeDirectoryTable.hasInit){ // Sets up bindings on first run

	} else {

		// The following set up the select-based filters for the table
		$("#directorySearch").on( 'input', function () {
			var textValue = $("#directorySearch").val();
			var deptValue = $("#departmentSelect").chosen().val();
			var floorValue = $("#floorSelect").chosen().val();
			var suiteValue = $("#suiteSelect").chosen().val();          
			var fullValue = textValue + " " + deptValue + " " + floorValue + " " + suiteValue;
			OfficeDirectoryTable.search(fullValue).draw();
		} );

		$('#departmentSelect').on('change', function(evt, params) {
			var textValue = $("#directorySearch").val();
			var deptValue = params ? params.selected : "";
			var floorValue = $("#floorSelect").chosen().val();
			var suiteValue = $("#suiteSelect").chosen().val();            
			var fullValue = textValue + " " + deptValue + " " + floorValue + " " + suiteValue;
			OfficeDirectoryTable.search(fullValue).draw();
		});

		$('#floorSelect').on('change', function(evt, params) {
			var textValue = $("#directorySearch").val();
			var deptValue = $("#departmentSelect").chosen().val();
			var floorValue = params ? params.selected : "";
			var suiteValue = $("#suiteSelect").chosen().val();            
			var fullValue = textValue + " " + deptValue + " " + floorValue + " " + suiteValue;
			OfficeDirectoryTable.search(fullValue).draw();
		});

		$('#suiteSelect').on('change', function(evt, params) {
			var textValue = $("#directorySearch").val();
			var deptValue = $("#departmentSelect").chosen().val();
			var floorValue = $("#floorSelect").chosen().val();
			var suiteValue = params ? params.selected : "";          
			var fullValue = textValue + " " + deptValue + " " + floorValue + " " + suiteValue;
			OfficeDirectoryTable.search(fullValue).draw();
		});

		$("#departmentSelect").chosen({
			placeholder_text_single:"Filter by Department",
			allow_single_deselect: true,
			width:"160px",
			disable_search_threshold: 10
		});

		$("#floorSelect").chosen({
			placeholder_text_single:"Filter by Floor",
			allow_single_deselect: true,
			width:"160px",
			disable_search_threshold: 10
		});

		$("#suiteSelect").chosen({
			placeholder_text_single:"Filter by Suite",
			allow_single_deselect: true,
			width:"160px",
			disable_search_threshold: 10
		});

		_attach.call(OfficeDirectoryTable,'officeDirectoryFrame',73,function(height){
			$("#officeDirectoryTable").parent().css("height",height)
		});

		// Whenever an ajax call is returned for the OfficeDirectoryTable, this repopulates the filter tables based on
		// the available data in that table.  This means that only viable options will populate the select tables.
		OfficeDirectoryTable.on('xhr.dt',function( e, settings, json, xhr ){
			if(!json || !json.data){return;}
			var data = json.data;
			var user;
			var deptObj = {};
			var floorObj = {};
			var suiteObj = {};
			var len = data.length;
			for(var i = 0; i < len; i++){
				user = data[i];
				user.employee && user.employee.department && user.employee.department.name ? deptObj[user.employee.department.name] = {} : null;
				if(user.seat){
					user.seat.floor ? floorObj[user.seat.floor] = {} : null;
					user.seat.suite ? suiteObj[user.seat.suite] = {} : null;
				}
			}

			var deptNames = Object.keys(deptObj);
			var floors = Object.keys(floorObj);
			var suites = Object.keys(suiteObj);

			var departmentSelect = $("#departmentSelect");
			departmentSelect.empty();
			departmentSelect.append("<option></option>")
			for(var i = 0; i < deptNames.length; i++){
				departmentSelect.append("<option>"+deptNames[i]+"</option>")
			}
			departmentSelect.trigger("chosen:updated");

			var floorSelect = $("#floorSelect");
			floorSelect.empty();
			floorSelect.append("<option></option>")
			for(var i = 0; i < floors.length; i++){
				floorSelect.append("<option>"+floors[i]+"</option>")
			}
			floorSelect.trigger("chosen:updated");

			var suiteSelect = $("#suiteSelect");
			suiteSelect.empty();
			suiteSelect.append("<option></option>")
			for(var i = 0; i < suites.length; i++){
				suiteSelect.append("<option>"+suites[i]+"</option>")
			}
			suiteSelect.trigger("chosen:updated");
		})


		$('#officeDirectoryTable tbody').on('click', 'td .contactUserBtn', function () {
			var data = OfficeDirectoryTable.row($(this).closest('tr')).data();
			console.log(data)
			var user = {
				name: data.first + " " + data.last,
				codeRequired: data.codeRequired,
				userID: data.userID
			}
			if(Maptician.ModalTables.guestLogModal && Maptician.ModalTables.guestLogModal.data){
				Maptician.ModalTables.contactUserModal(user,Maptician.ModalTables.guestLogModal.data)
			} else {
				Maptician.ModalTables.contactUserModal(user)
			}
			
		});
		
		officeDirectoryTable.hasInit = true;
	}


}