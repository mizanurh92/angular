Maptician.ModalTables ? null : Maptician.ModalTables = {};

// The guest log modal is called when a user clicks the "Sign Visitor Log" button on the kiosk
// The purpose of this object is to load a modal form where the user can enter their personal information
// to be saved on the server as a guest log entry.  Optionally, the user may also enter a meeting code
// which will be submitted as well.  If the user enters a meeting code, after the completion of the log entry
// the user will be prompted whether they would like to send a message to the person who gave them the code,
// letting them know that they have arrived and where they are.

Maptician.ModalTables.guestLogModal = function(){
    var modalTables = Maptician.ModalTables;
    var guestLogModal = modalTables.guestLogModal;
    var modalElement = $('#guestLogModal'); // Alias to the jQuery modal html element

    if(guestLogModal.hasInit){
        // Resets the form elements
        $("#guestNameInput").val('').trigger('blur');
        $("#companyNameInput").val('').trigger('blur');
        $("#cellNumberInput").val('').trigger('blur');
        $("#guestEmailInput").val('').trigger('blur');
        $("#meetingCodeInput").val('').trigger('blur');
        $("#guestPurposeSelect").val('').trigger('blur');
        $("#guestDetailArea").val('');
        guestLogModal.validator.resetForm();

        modalElement.modal({
            clickClose: false,
            fadeDuration: 200,
            fadeDelay: .5
        });
    } else { // Sets up bindings on first run
        // Sets the text box focus on the first input element on the form
        modalElement.on($.modal.OPEN, function(event, modal) {
          $("#guestNameInput").focus();
        });
        // Creates a mask for the cell phone input.  The question mark allows an invalid or partial number to be entered
        // without the whole input being thrown out
        $("#cellNumberInput").mask("?(999) 999-9999");
        $("#meetingCodeInput").mask("?***-***");

        modalElement.modal({
            clickClose: false, // Likely to have stray touches in a kiosk environment - thus disabled click close
            fadeDuration: 200,
            fadeDelay: .5
        });

        guestLogModal.validator = modalElement.validate({
            debug:true,
            rules:{
                guestNameInput: {
                    required: true,
                    minlength: 3,
                    maxlength: 50,
                    fullName: true
                },
                companyNameInput: {
                    rangelength: [2, 50]
                },
                cellNumberInput: {
                    phoneUS:{
                        depends: function(element){
                            return $(element).val() != '(___) ___-____';
                        }
                    }
                },
                guestEmailInput: {
                    email: true
                },
                meetingCodeInput:{
                    rangelength: {
                        param: [7,7],
                        depends: function(element){
                            return $(element).val().slice(-1) != '_';
                        }
                    }
                },
                guestPurposeSelect: {
                    required: true
                }
            },
            messages: {
              guestNameInput: {
                fullName: "Invalid characters used."
              },
              meetingCodeInput: {
                rangelength: "Please enter a 6 character Meeting Code."
              },              
            },
            submitHandler: function(form,event) {
                var data = {
                    name:$("#guestNameInput").val(),
                    company:$("#companyNameInput").val(),
                    cell:$("#cellNumberInput").val(),
                    email:$("#guestEmailInput").val(),
                    visitorCode:$("#meetingCodeInput").val(),
                    purpose:$("#guestPurposeSelect").val(),
                    detail:$("#guestDetailArea").val()
                }
                console.log('posting data',data)
                $.ajax({
                    type: "POST",
                    url: "api/kiosks/visitorLogEntry",
                    data: data
                })
                .then(function(result){
                    guestLogModal.data = data; // Saves the entered data to the guestLogModal object - either cleared or used later
                    if(result.visitorCode){ // Code was entered
                        $.modal.close();
                        if(result.code){ // Valid Code was entered
                            swal({
                                title: 'Thank You!',
                                text: 'Do you want to send an automated message to your host to let them know you have arrived?',
                                showConfirmButton: true,
                                showCancelButton: true,
                                type: 'success',
                                confirmButtonColor: '#3085d6',
                                cancelButtonColor: '#d33',
                                confirmButtonText: 'Yes',
                                cancelButtonText: 'No',
                            })
                            .then(function(){
                                data.header = "Tell your host that you're here:";
                                Maptician.ModalTables.visitorCodeModal(data);
                            })
                            .catch(function(){
                                delete guestLogModal.data.visitorCode;
                            })
                        } else { // Invalid Code was entered
                            delete guestLogModal.data.visitorCode;
                            swal({
                                title: 'Thank You!',
                                text: 'Your entry has been saved. However, your meeting code was not recognized.  Do you want to continue' +
                                    ' with the meeting notification?  You will have the opportunity to re-enter your code.',
                                showConfirmButton: true,
                                showCancelButton: true,
                                type: 'warning',
                                confirmButtonColor: '#3085d6',
                                cancelButtonColor: '#d33',
                                confirmButtonText: 'Yes',
                                cancelButtonText: 'No',
                            })
                            .then(function(){
                                delete guestLogModal.data.visitorCode;
                                data.header = "Tell your host that you're here:";
                                Maptician.ModalTables.visitorCodeModal(data);
                            })
                            .catch(swal.noop)
                        }
                    } else { // No Code was entered
                        $.modal.close();
                        swal({
                            title: 'Thank You!',
                            text: 'Your entry has been saved.',
                            timer: 5000,
                            showConfirmButton: true,
                            type: 'success'
                        }).catch(swal.noop)
                    }
                })
                .catch(function(err){
                    $.modal.close();
                    swal({
                        title: 'Sorry!',
                        text: 'Something went wrong while saving your entry.  Please try again later.',
                        timer: 5000,
                        showConfirmButton: true,
                        type: 'error'
                    })
                })
            },
            errorPlacement: function(error, element) {
                error.appendTo(element.parent());
            },
            success: function(label) {
                label.addClass("valid").html('<i class="fa fa-check-circle"></i>')
            },
            errorClass:"formError"
        })

        $("#guestLogModal .close").click(function(){
            $.modal.close();
        })
        
        guestLogModal.hasInit = true;
    }

}