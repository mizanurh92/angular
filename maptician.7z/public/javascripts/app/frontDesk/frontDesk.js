$(document).ready(function(){
	// if('serviceWorker' in navigator){ // Check for compatibility and register a service worker
	// 	navigator.serviceWorker.register('/sw.js',{scope:"/"})
	// 	.then(function(){
	// 		console.log('service worker registered')
	// 	})
	// 	.catch(function(err){
	// 		console.log(err)
	// 	})
	// }

	$("#visitorLog").click(function(){
		Maptician.ModalTables.guestLogModal();
	})
	$("#meetingCode").click(function(){
		// The following line deletes any visitor code being stored for security reasons.
		Maptician.ModalTables.guestLogModal.data ? delete Maptician.ModalTables.guestLogModal.data.visitorCode : null;
		Maptician.ModalTables.visitorCodeModal(Maptician.ModalTables.guestLogModal.data);
	})

	Maptician.inits();
})
Maptician = {};
$Map = Maptician;

Maptician.inits = function(){
	var buttonArea = $('#kioskButtonArea');
	var buttons = buttonArea.children();
	$Map.sliderElement = $("#kiosk-slider");
	buttons.filter(':nth-child(1)')
		.addClass('activeBtn')
		.children('.led')
		.removeClass('led-off')
		.addClass('led-blue');
	
	$('.MainNav-Button').mouseup(function() { this.blur() })

	// The following handles properly trimming the image in the slider
    $(window).resize(function(){
        var img = $("#contentHomeImage");
        var container = $("#div1Content");
        var imgAspect = img[0].naturalWidth/img[0].naturalHeight;
        var containerAspect = container.width()/container.height();
        if(imgAspect <= containerAspect){
        	img.attr("style","width:100%");
        } else {
        	img.attr("style","height:100%");
        }
    });
    
 //    $("#contentHomeImage").one("load", function() {
	//   window.dispatchEvent(new Event('resize'));
	// }).each(function() {
	//   if(this.complete) $(this).load();
	// });
    
	// Starts the clock in the upper right corner
	Maptician.clock();

	// Custom validators for jquery validation
	$.validator.methods.email = function( value, element ) {
	  return this.optional( element ) || /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/.test( value );
	}
	$.validator.methods.fullName = function( value, element ) {
	  return this.optional( element ) || /^[a-z ,.'-]+$/i.test( value );
	}
	
	// Formats the input boxes to have labels which move to the top on focus or upon non-null value
	$('.FlowupLabels').FlowupLabels();
	
	// Loads the slider navigation UI object
	$Map.slider = $Map.sliderElement.show().slick({
	  infinite: false,
	  speed: 300,
	  slidesToShow: 1,
	  centerMode: true,
	  centerPadding:"0px",
	  //variableWidth: true
	});
	$('#contentPanel .slick-prev').insertAfter($('#contentPanel .slick-next')); // Needed for back arrow to work
	
	buttonArea.css({display:"flex"}); // The buttons are hidden until the slider is loaded

	$('#kioskButtonArea .kioskButton').click(function(event){
		var index = $(this).index();
		$('.mainSlider').slick("slickGoTo", index, false);
	})

	$('.mainSlider').on('beforeChange',function(event,slick,currentSlide,nextSlide){
		buttons.removeClass('activeBtn');
		var leds = buttons.children('.led');
		leds.removeClass('led-blue').addClass('led-off');
		$(leds[nextSlide]).removeClass('led-off').addClass('led-blue');
		buttons.filter(':nth-child('+(nextSlide+1)+')').addClass('activeBtn');
	})

	$('.mainSlider').on('afterChange',function(event,slick,currentSlide){
		$Map.KioskNav.drawn = false;
		switch(currentSlide){
			case 0:
				$('.mainSlider').slick("slickSetOption", "touchMove", true, true);
				$('.mainSlider').slick("slickSetOption", "draggable", true, true);
				$('.mainSlider').slick("slickSetOption", "touchThreshold", 5, true);
			break;
			case 1:
				Maptician.PageTables && Maptician.PageTables.OfficeDirectoryTable ? Maptician.PageTables.OfficeDirectoryTable.draw() : null;
				$('.mainSlider').slick("slickSetOption", "touchMove", true, true);
				$('.mainSlider').slick("slickSetOption", "draggable", true, true);
				$('.mainSlider').slick("slickSetOption", "touchThreshold", 5, true);
			break;
			case 2:
				$('.mainSlider').slick("slickSetOption", "touchMove", false, true);
				$('.mainSlider').slick("slickSetOption", "draggable", false, true);
				$('.mainSlider').slick("slickSetOption", "touchThreshold", 1, true);
				$Map.KioskNav.drawn = true;
			break;
		}
	})




	//setTimeout(function(){
		$("#div3Content").css('display','block');
		Maptician.KioskNav = new MapKioskController();
		Maptician.KioskNav.showMapElements();
		$('#kioskRightNavBar').show();
	//}, 10000);


	//setTimeout(function(){
		Maptician.PageTables.officeDirectoryTable();
		Maptician.idleTimer(45);
	//}, 10000);


}


// Performs a reset on the kiosk.  This is intended to occur after some amount of idle time.
// The data for the directory and the maps are not reloaded.
Maptician.reset = function(){
	// Closes any open modals
	$.modal.close();
	swal.closeModal();

	// Resets the slider to the first slide
	$('.mainSlider').slick("slickGoTo", 0 , false);

	// Clears filters in the office directory
	$("#directorySearch").val('');
	$("#departmentSelect").chosen().val('').trigger("chosen:updated");
	$("#floorSelect").chosen().val('').trigger("chosen:updated");
	$("#suiteSelect").chosen().val('').trigger("chosen:updated");
	Maptician.PageTables.OfficeDirectoryTable.search('').draw();

	// Clear any saved data from the guest log modal
	Maptician.ModalTables.guestLogModal ? delete Maptician.ModalTables.guestLogModal.data : null;
	
	// Resets the map viewer to center on the "You are here" position
	$("#div3Content").css('display','block');
	$Map.KioskNav.changeFile($Map.KioskNav.kioskMapID,{point:$Map.KioskNav.kioskPoint});
	$("#kioskMapSearch").hide();
	$("#div3Content").css('display','');
}

// Starts an idle timer that counts the seconds since the last user action was made
// If the timer elapses and the warning button isn't pressed, the kiosk resets itself
Maptician.idleTimer = function(timer){
	var idleTime = 0;
	var warningInProgress = false;
	var actionTaken = false;
	var timerDuration = timer;

	var timerIncrement = function() {
		// Timer only increments when an action has been taken since the last reset
		if(!actionTaken){return;}

		idleTime += 5;

		if(idleTime >= timerDuration && !warningInProgress){
			warningInProgress = true;
			swal({
				title: 'Idle Warning',
				text: 'You have been idle for '+timerDuration+' seconds. This kiosk will reset unless you press "Continue" in the next 15 seconds.',
				timer: 15000,
				showConfirmButton: true,
				confirmButtonText: 'Continue',
				type: 'warning'
			})
			.then(function(){ // "Continue" button was pushed
				idleTime = 0;
				warningInProgress = false;
			})
			.catch(function(err){ // If the timer elapses the kiosk resets, if it is closed otherwise, there is no reset
				idleTime = 0;
				warningInProgress = false;
				if(err=="timer"){
					actionTaken = false;
					Maptician.reset();
				}
			})
		}
	}

	//Increment the idle time counter every 5 seconds
	var idleInterval = setInterval(timerIncrement, 5000);

	$(document).mousedown (function (e) {
		idleTime = 0;
		actionTaken = true;
	});
	$(document).keypress(function (e) {
		idleTime = 0;
		actionTaken = true;
	});
	$(document).click(function (e) {
		idleTime = 0;
		actionTaken = true;
	});
}

Maptician.unit = function(system){
	if(system){
		this.units = system;
	} else {
		return this.units;
	}
}

Maptician.current = function(){
	if(Maptician.KioskNav && Maptician.KioskNav.isSet() && Maptician.KioskNav.isDrawn()){
		return Maptician.KioskNav.currentFile;
	}
}

Maptician.clock = function(options){
	options = options || {};
	var clock = Maptician.clock;
	clock.update = function(){
		$('#dateClock').html(moment().format('MMMM Do, YYYY'));
		$('#timeClock').html(moment().format('h:mm A'));
	}
	clock.update();
	setInterval(clock.update,60000);
}