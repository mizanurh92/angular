Maptician.ModalTables ? null : Maptician.ModalTables = {};

// The visitor code modal is called through a number of routes.  Firstly, it can be called directly by the user
// by clicking on the "Meeting Codes" button.  Secondly, it can be called by having the user enter a meeting code
// into the guest log modal and select to proceed to the meeting contact process.  Thirdly, it can be called
// from the office directory upon selecting "Contact" for an individual.  Each path has seperate rules and different
// prepopulation and enabling/disabling of various fields.  Upon sucessful submission of a valid code, the server
// will send a SMS Message to the code owner with a message detailing the guest's name and location floor/suite/kiosk.

Maptician.ModalTables.visitorCodeModal = function(options){
	options = options || {};
	var modalTables = Maptician.ModalTables;
	var visitorCodeModal = modalTables.visitorCodeModal;
	var modalElement = $('#visitorCodeModal'); // Alias to the jQuery modal html element
	modalElement.find('.header').html(options.header || "Tell your host that you're here:")

	// Resets the form elements
	$("#guestNameInput2").val(options.name || '').trigger('blur');
	$("#targetNameInput").val('');
	$("#companyNameInput2").val(options.company || '').trigger('blur');
	$("#cellNumberInput2").val(options.cell || '').trigger('blur');
	$("#guestEmailInput2").val(options.email || '').trigger('blur');
	$("#meetingCodeInput2").val(options.visitorCode || '').trigger('blur');

	if(visitorCodeModal.hasInit){
		console.log('already init')
		visitorCodeModal.validator.resetForm();
		// Unhide form
		modalElement.modal({
			clickClose: false,
			fadeDuration: 200,
			fadeDelay: .5
		});
	} else { // Sets up bindings on first run
		
		// Sets the text box focus on the first input element on the form
		modalElement.on($.modal.OPEN, function(event, modal) {
		  $("#meetingCodeInput2").focus();
		  if($("#meetingCodeInput2").val()){
		  	$("#meetingCodeInput2").trigger('blur');
		  }

		});

		// Creates a mask for the cell phone input.  The question mark allows an invalid or partial number to be entered
		// without the whole input being thrown out
		$("#cellNumberInput2").mask("?(999) 999-9999");
		$("#meetingCodeInput2").mask("?***-***");
		
		modalElement.modal({
			clickClose: false, // Likely to have stray touches in a kiosk environment - thus disabled click close
			fadeDuration: 200,
			fadeDelay: .5
		});
		
		visitorCodeModal.validator = modalElement.validate({
			debug:true,
			onkeyup: false,
			rules:{
				guestNameInput: {
					required: true,
					minlength: 3,
					maxlength: 50,
					fullName: true
				},
				companyNameInput: {
					rangelength: [2, 50]
				},
				cellNumberInput: {
					phoneUS:{
						depends: function(element){
							return $(element).val() != '(___) ___-____';
						}
					}
				},
				guestEmailInput: {
					email: true
				},
				meetingCodeInput:{
					required:true,
					rangelength: {
						param: [7,7],
						depends: function(element){
							var string = $(element).val();
							var last = string.slice(-1);
							if(last == '_'){
								string = string.slice(0,-1);
								$(element).val(string);
							}
							return true;
						}
					},
					remote:{
						param:{
							url: "api/kiosks/validateCode",
							type: "GET",
							dataFilter:function(data){
								var json = JSON.parse(data);
								if(json.result){
									$("#targetNameInput").val(json.name).trigger('blur');
									return 'true';
								} else {
									$("#targetNameInput").val('').trigger('blur');
									return 'false';
								}
							}
						},
						depends: function(element){
							return $(element).val().slice(-1) != '_';
						}
					}
				},
			},
			messages: {
			  guestNameInput: {
				fullName: "Invalid characters used."
			  },
			  meetingCodeInput: {
				rangelength: "Please enter a 6 character Meeting Code.",
				remote: "Meeting code could not be found."
			  },
			},
			submitHandler: function(form,event) {
				var data = {
					guestName:$("#guestNameInput2").val(),
					guestCompany:$("#companyNameInput2").val(),
					guestCell:$("#cellNumberInput2").val(),
					guestEmail:$("#guestEmailInput2").val(),
					visitorCode:$("#meetingCodeInput2").val(),
				}
				console.log('posting data',data)
				$.ajax({
					type: "POST",
					url: "api/kiosks/visitorCodeSubmit",
					data: data
				})
				.then(function(result){
					console.log(result)
					$.modal.close();
					if(result.success){
						swal({
							title: 'Message Sent',
							text: 'A message has been sent to your host letting them know that you have arrived.',
							showConfirmButton: true,
							type: 'success',
							timer: 10000,
							confirmButtonText: 'OK',
						})
						.then(function(){
							// Deletes any stored user information from the guest log since the user has sucessfully
							// contacted their host - so this data is no longer required and should be removed
							// for security/usability reasons.
							if(Maptician.ModalTables.guestLogModal && Maptician.ModalTables.guestLogModal.data){
								delete Maptician.ModalTables.guestLogModal.data
							}
						})
						.catch(swal.noop)
					} else {
						swal({
							title: 'Sorry!',
							text: 'Something went wrong while sending your message.  Please try again later.',
							timer: 10000,
							showConfirmButton: true,
							type: 'error'
						})						
					}
				})
				.catch(function(err){
					$.modal.close();
					swal({
						title: 'Sorry!',
						text: 'Something went wrong while sending your message.  Please try again later.',
						timer: 10000,
						showConfirmButton: true,
						type: 'error'
					})
				})
			},
			errorPlacement: function(error, element) {
				error.appendTo(element.parent());
			},
			success: function(label) {
				label.addClass("valid").html('<i class="fa fa-check-circle"></i>')
			},
			errorClass:"formError"
		})

		$("#visitorCodeModal .close").click(function(){
			$.modal.close();
		})
		
		visitorCodeModal.hasInit = true;
	}

}