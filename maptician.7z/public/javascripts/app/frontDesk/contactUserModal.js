Maptician.ModalTables ? null : Maptician.ModalTables = {};

// The contact user modal is very similar to the visitorCodeModal both in terms of structure and purpose.  The primary
// difference between the two is that the Visitor Code Modal asks the visitor for a visitor code and their personal
// information and sends a message to a user based on those.  The Contact User Modal starts with a target user
// (most likely from the directory) and asks the user for their personal information.  Based on the target user, the
// modal will either require a visitor code or not request one.  The later happens when that user and the overall security
// policy allow for visitors to contact via SMS without the visitor code.

Maptician.ModalTables.contactUserModal = function(user,prefill,options){ // User is an object containing user information
	options = options || {};
	prefill = prefill || {};
	var modalTables = Maptician.ModalTables;
	var contactUserModal = modalTables.contactUserModal;
	var modalElement = $('#contactUserModal'); // Alias to the jQuery modal html element
	modalElement.find('.header').html(options.header || "Contact an occupant by text message:")
	contactUserModal.codeRequired = user.codeRequired === false ? false : true; // defaults to true if codeRequired doesn't exist
	contactUserModal.userID = user.userID;

	// Resets the form elements
	$("#targetNameInput2").val(user.name).trigger('blur');
	$("#meetingCodeInput3").val('').trigger('blur');
	$("#guestNameInput3").val(prefill.name || '').trigger('blur');
	$("#companyNameInput3").val(prefill.company || '').trigger('blur');
	$("#cellNumberInput3").val(prefill.cell || '').trigger('blur');
	$("#guestEmailInput3").val(prefill.email || '').trigger('blur');

	contactUserModal.codeRequired ? $("#contactUserCode").show() : $("#contactUserCode").hide();

	if(contactUserModal.hasInit){
		contactUserModal.validator.resetForm();
		// Unhide form
		modalElement.modal({
			clickClose: false,
			fadeDuration: 200,
			fadeDelay: .5
		});
	} else { // Sets up bindings on first run
		
		// Sets the text box focus on the first input element on the form
		modalElement.on($.modal.OPEN, function(event, modal) {
			$("#meetingCodeInput3").focus();
			if($("#meetingCodeInput3").val()){
				$("#meetingCodeInput3").trigger('blur');
			}
		});

		// Creates a mask for the cell phone input.  The question mark allows an invalid or partial number to be entered
		// without the whole input being thrown out
		$("#cellNumberInput3").mask("?(999) 999-9999");
		$("#meetingCodeInput3").mask("?***-***");
		
		modalElement.modal({
			clickClose: false, // Likely to have stray touches in a kiosk environment - thus disabled click close
			fadeDuration: 200,
			fadeDelay: .5
		});
		
		contactUserModal.validator = modalElement.validate({
			debug:true,
			onkeyup: false,
			rules:{
				guestNameInput: {
					required: true,
					minlength: 3,
					maxlength: 50,
					fullName: true
				},
				companyNameInput: {
					rangelength: [2, 50]
				},
				cellNumberInput: {
					required: true,
					phoneUS:{
						depends: function(element){
							return $(element).val() != '(___) ___-____';
						}
					}
				},
				guestEmailInput: {
					email: true,
					required: true
				},
				meetingCodeInput:{
					required:{
						param: true,
						depends:function(element){
							return contactUserModal.codeRequired;
						}
					},
					rangelength: {
						param: [7,7],
						depends: function(element){
							var string = $(element).val();
							var last = string.slice(-1);
							if(last == '_'){
								string = string.slice(0,-1);
								$(element).val(string);
							}
							return true;
						}
					},
					remote:{
						param:{
							url: "api/kiosks/validateUserCode",
							data:{
								userID: function(){
									return contactUserModal.userID;
								}
							},
							type: "GET",
							dataFilter:function(data){
								var json = JSON.parse(data);
								if(json.result){
									return 'true';
								} else {
									return 'false';
								}
							}
						},
						depends: function(element){
							return $(element).val().slice(-1) != '_';
						}
					}
				},
			},
			messages: {
			  guestNameInput: {
				fullName: "Invalid characters used."
			  },
			  meetingCodeInput: {
				rangelength: "Please enter a 6 character Meeting Code.",
				remote: "Meeting code could not be found."
			  },
			},
			submitHandler: function(form,event) {
				var data = {
					guestName:$("#guestNameInput3").val(),
					guestCompany:$("#companyNameInput3").val(),
					guestCell:$("#cellNumberInput3").val(),
					guestEmail:$("#guestEmailInput3").val(),
					visitorCode:$("#meetingCodeInput3").val(),
					userID:Maptician.ModalTables.contactUserModal.userID,
					codeRequired:Maptician.ModalTables.contactUserModal.codeRequired
				}
				console.log('posting data',data)
				$.ajax({
					type: "POST",
					url: "api/kiosks/contactUserSubmit",
					data: data
				})
				.then(function(result){
					console.log(result)
					$.modal.close();
					if(result.success){
						swal({
							title: 'Message Sent',
							text: 'A message has been sent letting the individual know you are here.',
							showConfirmButton: true,
							type: 'success',
							timer: 10000,
							confirmButtonText: 'OK',
						})
						.then(function(){
							// Deletes any stored user information from the guest log since the user has sucessfully
							// contacted their host - so this data is no longer required and should be removed
							// for security/usability reasons.
							if(Maptician.ModalTables.guestLogModal && Maptician.ModalTables.guestLogModal.data){
								delete Maptician.ModalTables.guestLogModal.data
							}
						})
						.catch(swal.noop)
					} else {
						swal({
							title: 'Sorry!',
							text: 'Something went wrong while sending your message.  Please try again later.',
							timer: 10000,
							showConfirmButton: true,
							type: 'error'
						})						
					}
				})
				.catch(function(err){
					$.modal.close();
					swal({
						title: 'Sorry!',
						text: 'Something went wrong while sending your message.  Please try again later.',
						timer: 10000,
						showConfirmButton: true,
						type: 'error'
					})
				})
			},
			errorPlacement: function(error, element) {
				error.appendTo(element.parent());
			},
			success: function(label) {
				label.addClass("valid").html('<i class="fa fa-check-circle"></i>')
			},
			errorClass:"formError"
		})

		$("#contactUserModal .close").click(function(){
			$.modal.close();
		})
		
		contactUserModal.hasInit = true;
	}

}