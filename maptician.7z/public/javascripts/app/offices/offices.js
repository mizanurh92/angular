$Map.components = $Map.components || {};

$Map.components.Offices = function(){
	this.area = $("#officesArea");
	this.topNav = $("#topNav");
	this.rightNav = $("#officesRightNav");
	this.navControls = $("#officesControlButtons");
	this.new = $("#newOffice");
	this.refresh = $("#refreshOfficeList");
	this.edit = $("#editOffice");
	this.searchForm = this.rightNav.find('form');
	this.searchBox = $("#officeSearch");
	this.navTableHolder = $("#officesNavTableHolder");
	this.navTable = $("#officesNavTable");
	this.tabSelectors = $("#officesTabSelectors");
	this.tabs = $("#officesTabSelectors").find('li');

	// These variables control the modal used to create, edit, and delete offices
	this.selectorFormModal = $("#officeFormModal");
	this.selectorForm = $(this.selectorFormModal.find('form')[0]);
	this.selectorValidator = null;
	this.action = null; // flag for whether the modal is in 'create' or 'update' mode
	this.createURL = '../api/offices/createNewOffice';
	this.editURL = '../api/offices/editOffice';

	// Tabs
	this.tabOpen = null;

	// RightNav Office Table
	this.isOpen = false;
	this.officeTable = null;
	this.officeSelected = null; // deptID of selected row
	this.officeSelector = null; // Datatables row selector object
	var Offices = this;

	this.open = function(){
		this.area.show();
		this.tabSelectors.show();
		this.setSelectTable();
		this.setBindings('office');
		this.setValidator();
		this.tabSelect(0);
		this.isOpen = true;
	}

	this.exit = function(){
		this.rightNav.hide();
		this.unsetBindings('office');
		this.officeTable.clear().destroy(); // Clears datatable
		this.officeTable = null;		
		this.navTable.children().remove(); // Removes table remaining table elements (except table)
		this.isOpen = false;
	}

	this.tabSelect = function(index){

		this.tabs.removeClass('active');
		$(this.tabs[index]).addClass('active');
		this.area.find('.subContent').hide();
		$(this.area.find('.subContent')[index]).show();

		if(index != 0 && !this.officeSelected){
			$("#officeSelectNote").css({display:"flex"});
		}

		switch(index){
			case 0:
				this.rightNav.hide();
				this.summary = this.summary || new $Map.components.OfficesSummary(this);
				this.summary.open();
				this.tabOpen = this.summary;
			break;
			case 1:
				this.occupants = this.occupants || new $Map.components.OccupantList(this);
				this.occupants.open();
				this.rightNav.show();
				this.officeTable.draw();
				this.tabOpen = this.occupants;
			break;
			case 2:
				this.rightNav.show();
				this.reports = this.reports || new $Map.components.OfficesReports(this);
				this.reports.open();
				this.officeTable.draw();
				this.tabOpen = this.reports;
			break;
			case 3:
				this.rightNav.show();
				this.analytics = this.analytics || new $Map.components.OfficeAnalytics(this);
				this.analytics.open();
				this.officeTable.draw();
				this.tabOpen = this.analytics;
			break;
			case 4:
				this.rightNav.show();
				this.officeTable.draw();
				$Map.OfficeTables.kioskList({officeID:this.officeSelected});
			break;
		}
	}

	this.setSelectTable = function(){
		this.officeTable = this.officeTable || this.navTable.DataTable({
			ajax: "../api/offices/navtable",
			rowId: 'officeID',
			select: {
				style: 'single',
				className: 'selected',
				selector: 'tr:not(.selected)'
			},
			scrollY: this.navTableHolder.height() - 25,
			deferRender:true,
			scroller:true,
			paging:true,
			columns: [
				{	
					width:100,
					data: {},
					title: "Office",
					class:'left',
					render: function(office){
						return office.name;
					}
				},
				{
					width:100,
					data: {},
					title: "Location",
					class: 'center',
					render: function(office){
						if(office.city && office.state){
							return office.city + ", " + office.state;
						} else if(office.city){
							return office.city;
						} else if(office.state){
							return office.state;
						}
						return "";
					}
				}
			],
			dom:'tr'
		})
	}

	this.setValidator = function(){
		this.selectorValidator = this.selectorForm.validate({
			rules: {
				officeFormName: {
					required: true,
					rangelength: [3, 50],
					letNumSpac: true
				},
				officeFormAddress: {
					maxlength: 95
				},
				officeFormAddress2: {
					maxlength: 95
				},
				officeFormCity: {
					rangelength: [2, 50]
				},
				officeFormState: {
					rangelength: [2, 15]
				},
				officeFormZip: {
					rangelength: [5, 10]
				},
				officeFormCountry: {
					rangelength: [2, 50]
				},
			},
			messages: {
				officeFormName: {
					required: "An Office Name is Required",
					letNumSpac: "Only standard letters and numbers are permitted in Office Names"
				},
				newMapLengthInput: {validLength: "Please enter a valid distance"},              
			},
			submitHandler:function(form,event){
				var data = {
					name: $("#officeFormName").val(),
					address1: $("#officeFormAddress").val(),
					address2: $("#officeFormAddress2").val(),
					city: $("#officeFormCity").val(),
					state: $("#officeFormState").val(),
					zip: $("#officeFormZip").val(),
					country: $("#officeFormCountry").val(),
				}
				if(Offices.action == "edit"){
					data.officeID = Offices.officeSelected;
				}
				var url = Offices.action == "create" ? Offices.createURL : Offices.editURL;
				$.ajax({
					type: "POST",
					url: url,
					data: data
				})
				.then(function(){
					$.modal.close();
					Offices.refreshSelectTable();
				})
				.catch(function(err){
					// TODO Need an error message to the user
					console.log(err);
				})
			}
		})
	}

	this.refreshSelectTable = function(){
		this.officeTable && this.officeTable.ajax.reload();
		this.officeTable.row("#"+Offices.officeSelected).select();
	}

	this.createTableItem = function(){
		this.selectorFormModal.find('h3.header').html('Create New Office');
		this.selectorFormModal.find('input.save').attr('value','Create');
		this.action = "create";
		this.selectorFormModal.modal();
	}

	this.editTableItem = function(){
		this.selectorFormModal.find('h3.header').html('Modify Office');
		this.selectorFormModal.find('input.save').attr('value','Save');
		this.action = "edit";
		var data = Offices.officeSelector.data().toArray()[0];
		$("#officeFormName").val(data.name).trigger('blur');
		$("#officeFormAddress").val(data.address1).trigger('blur');
		$("#officeFormAddress2").val(data.address2).trigger('blur');
		$("#officeFormCity").val(data.city).trigger('blur');
		$("#officeFormState").val(data.state).trigger('blur');
		$("#officeFormZip").val(data.zip).trigger('blur');
		$("#officeFormCountry").val(data.country).trigger('blur');
		this.selectorFormModal.modal();
	}

	this.selectNewOffice = function(){

		this.tabOpen && this.tabOpen.updateOffice();
	}

	this.setBindings = function(namespace){
		// Select row event listener
		this.officeTable && this.officeTable.on( 'select.' + namespace , function ( e, dt, type, indexes ) {
			Offices.officeSelector = Offices.officeTable.rows(indexes);
			Offices.officeSelected = Offices.officeSelector.data().toArray()[0].officeID;
			Offices.selectNewOffice();
			$("#officeSelectNote").css({display:"none"});
		})

		this.new.on('click.' + namespace, function(){
			Offices.createTableItem();
		})

		this.edit.on('click.' + namespace, function(){
			if(Offices.officeSelected){
				Offices.editTableItem();				
			}
		})

		this.refresh.on('click.' + namespace, function(){
			Offices.refreshSelectTable();
		})

		this.searchBox.on( 'input.' + namespace, function () {
			Offices.officeTable.search(Offices.searchBox.val()).draw();
		});

		this.selectorFormModal.find('.cancel').on('click.' + namespace,function(){
			$.modal.close();
		})

		// Clears the form when the modal is closed
		this.selectorFormModal.on($.modal.AFTER_CLOSE,function(event,modal){ 
			Offices.selectorForm[0].reset();
			Offices.selectorForm.find('input.fl_input').trigger('blur');
		});

		_attach.call(this.officeTable,'officeMgrNav',25,function(height){
			$("#officesNavTable").parent().css("height",height)
		});

		this.tabs.on('click.' + namespace, function(){
			Offices.tabSelect($(this).index())
		})
	}

	this.unsetBindings = function(namespace){
		this.officeTable.off('.'+namespace);
		this.refresh.off('.'+namespace);
		this.edit.off('.'+namespace);
		this.new.off('.'+namespace);
		this.searchBox.off('.'+namespace);
		this.selectorFormModal.find('.cancel').off('.'+namespace);
		this.selectorFormModal.off($.modal.AFTER_CLOSE);
		$("#officeMgrNav").remove(); // Remove iframe
	}
}
$Map.components.Offices.prototype.constructor = $Map.components.Offices;


$Map.components.OfficesReports = function(officeController){
	this.officeController = officeController;
	this.reportSelector = $("#officeReports select.reports-select");
	this.openReport = null;
	var Reports = this;
	// Maps Report - done
	// Seats Report - done
	// Rooms Report - done
	// Zones Report - done
	// Occupants Report - done
	// Visitor Log - done
	// Kiosk Contactable Report
	// Kiosk Report
	// Kiosk Contact Log
	this.open = function(){
		this.reportSelector.val(0);
		this.setBindings();
	}

	this.exit = function(){
		this.openReport.report.exit();
		this.openReport = null;
		this.unsetBindings();
	}

	this.updateOffice = function(){
		if(this.openReport){
			this.openReport.report.update(this.officeController.officeSelected);
		}
	}

	this.setBindings = function(){
		this.reportSelector.on('change',function(){
			var index = 1*$(this).val();

			if(Reports.openReport && Reports.openReport.index != index){
				Reports.openReport.report.exit();				
			}

			switch(index){
				case 0:
					Reports.mapList = Reports.mapList || new $Map.components.OfficesReports.mapList();
					Reports.mapList.open(Reports.officeController.officeSelected);
					Reports.openReport = {index:index,report:Reports.mapList};
				break;
				case 1:
					Reports.seatList = Reports.seatList || new $Map.components.OfficesReports.seatList();
					Reports.seatList.open(Reports.officeController.officeSelected);
					Reports.openReport = {index:index,report:Reports.seatList};
				break;
				case 2:
					Reports.roomList = Reports.roomList || new $Map.components.OfficesReports.roomList();
					Reports.roomList.open(Reports.officeController.officeSelected);
					Reports.openReport = {index:index,report:Reports.roomList};
				break;
				case 3:
					Reports.zoneList = Reports.zoneList || new $Map.components.OfficesReports.zoneList();
					Reports.zoneList.open(Reports.officeController.officeSelected);
					Reports.openReport = {index:index,report:Reports.zoneList};
				break;
				case 4:
					Reports.occupantList = Reports.occupantList || new $Map.components.OfficesReports.occupantList();
					Reports.occupantList.open(Reports.officeController.officeSelected);
					Reports.openReport = {index:index,report:Reports.occupantList};
				break;
				case 5:
					Reports.visitorList = Reports.visitorList || new $Map.components.OfficesReports.visitorList();
					Reports.visitorList.open(Reports.officeController.officeSelected);
					Reports.openReport = {index:index,report:Reports.visitorList};
				break;
			}
		})
	}

	this.unsetBindings = function(){
		this.reportSelector.off('change');
	}
}
$Map.components.OfficesReports.prototype.constructor = $Map.components.OfficesReports;

$Map.components.OfficesReports.mapList = function(){
	this.url = '../api/offices/reports/mapList';
	this.tableContainer = $("#officeReports .table-container")
	this.tableElement = $("#officeReportTable");
	this.tableColumns = 9;
	this.table = null;
	this.officeID = null;
	this.selector = null;
	this.selected = null;
	this.tableOffset = 110;
	this.namespace = 'mapListReport';
	var report = this;

	this.open = function(officeID){
		this.officeID = officeID;
		this.createFooter();
		this.setTable();
		this.setBindings(this.namespace);
		this.isOpen = true;
	}

	this.exit = function(){
		this.unsetBindings();
		this.table && this.table.clear().destroy(); // Clears datatable
		this.table = null;		
		this.tableElement.children().remove(); // Removes table remaining table elements (except table)
		this.isOpen = false;
	}

	this.update = function(officeID){
		if(officeID != this.officeID){
			this.officeID = officeID;
			this.refreshTable();
		}
	}

	this.setTable = function(){
		this.table = this.table || this.tableElement.DataTable({
			ajax: {
				url: this.url,
				data:function(d){
					return {officeID:report.officeID};
				}
			},
			rowId: 'mapID',
			select: {
				style: 'single',
				className: 'selected',
				selector: 'tr:not(.selected)'
			},
			scrollY: report.tableContainer.height() - this.tableOffset,
			deferRender:true,
			scroller:true,
			paging:true,
			autoWidth:true,
			fixedHeader:{
				footer: true
			},
			columns:[
				{
					width: 100,
					title: "Map Name",
					data: {},
					class: 'leftAlign',
					render: function(map){
						return map.name || "";
					}
				},
				{
					width: 50,
					title: "Floor",
					data: {},
					class: 'centerAlign',
					render: function(map){
						return map.floor || "";
					}
				},
				{
					width: 50,
					title: "Suite",
					data: {},
					class: 'centerAlign',
					render: function(map){
						return map.suite || "";
					}
				},
				{
					width: 50,
					title: "Seats",
					data: {},
					class: 'centerAlign',
					render: function(map){
						map.seatCount = map.seatCount !== undefined ? map.seatCount : map.seats.length;
						return '<a class="seatDrillDown">'+map.seatCount+'</a>';
					}
				},
				{
					width: 50,
					title: "Open Seats",
					data: {},
					class: 'centerAlign',
					render: function(map){
						if(map.openSeatCount !== undefined){
							return '<a class="openSeatDrillDown">'+map.openSeatCount+'</a>';
						} else {
							var seat;
							map.openSeats = [];
							map.assignedSeats = [];
							map.openSeatCount = 0;
							map.assignedSeatCount = 0;
							map.seatCount = map.seatCount || map.seats.length;
							for(var i = 0; i < map.seatCount; i++){
								seat = map.seats[i];
								if(!seat.reservable){
									if(seat.assignmentStatus == "Unassigned"){
										map.openSeats.push(seat.seatID);
										map.openSeatCount += 1;
									} else {
										map.assignedSeats.push(seat.seatID);
										map.assignedSeatCount += 1;
									}
								}
							}
							return '<a class="openSeatDrillDown">'+map.openSeatCount+'</a>';
						}
					}
				},
					{              	
						width: 50,
						title: "Utilization",
						data: {}, // Seat Utilization
						render: function(map){ 
							var value = map.seatCount ? 100 * map.assignedSeatCount / map.seatCount : 0;
							var myString = "";
							myString += '<div class="cssProgress"><div class="progress3">';
							myString += '<div class="cssProgress-bar cssProgress-success" data-percent="';
							myString += value;
							myString += '" style="width:';
							myString += value;
							myString += '%;"><span class="cssProgress-label">';
							myString += round(value,0);
							myString += '%</span></div></div></div>';
							return myString;
					},
				},
				{
					width: 50,
					title: "Rooms",
					data: {},
					class: 'centerAlign',
					render: function(map){
						map.roomCount = map.roomCount !== undefined ? map.roomCount : map.rooms.length;
						return '<a class="roomDrillDown">'+map.roomCount+'</a>';
					}
				},
				{
					width: 50,
					title: "Zones",
					data: {},
					class: 'centerAlign',
					render: function(map){
						map.zoneCount = map.zoneCount !== undefined ? map.zoneCount : map.zones.length;
						return '<a class="zoneDrillDown">'+map.zoneCount+'</a>';
					}
				},
				{
					width: 120,
					data: {},
					class: 'buttonCenter-small',
					"orderable":false,
					render: function(map){
						var myString = "";
						myString += '<div class="btn viewMapButton">View</div><div class="btn editMapButton">Edit</div>';
						return myString;
					},
				}
			],
			footerCallback: function(row,data,start,end,display){
				var api = this.api();

				var seats = api.column(3,{search:'applied'}).data()
					.reduce( function (a, b) {
						return b.seatCount + a;
					}, 0 );
				$(api.column(3).footer()).html(seats);

				var openSeats = api.column(4,{search:'applied'}).data()
					.reduce( function (a, b) {
						return b.openSeatCount + a;
					}, 0 );
				$(api.column(4).footer()).html(openSeats);

				var assignedSeats = api.column(4,{search:'applied'}).data()
					.reduce( function (a, b) {
						return b.assignedSeatCount + a;
					}, 0 );

				var assignableSeats = assignedSeats + openSeats;

				var value = assignableSeats ? 100 * (assignedSeats / assignableSeats) : "NA";
				var myString = "";
				myString += '<div class="cssProgress"><div class="progress3">';
				myString += '<div class="cssProgress-bar cssProgress-success" data-percent="';
				myString += value;
				myString += '" style="width:';
				myString += value;
				myString += '%;"><span class="cssProgress-label">';
				myString += value ? round(value,0) +"%" : "N/A";
				myString += '</span></div></div></div>';
				$( api.column(5).footer() ).html(myString);	

				var rooms = api.column(6,{search:'applied'}).data()
					.reduce( function (a, b) {
						return b.roomCount + a;
					}, 0 );
				$(api.column(6).footer()).html(rooms);			

				var zones = api.column(7,{search:'applied'}).data()
					.reduce( function (a, b) {
						return b.zoneCount + a;
					}, 0 );
				$(api.column(7).footer()).html(zones);	
			},
			dom: 'brt'
		})
	}

	this.setBindings = function(namespace){
		table = this.table;

		// Handles row selection
		table && table.on( 'select.' + namespace , function ( e, dt, type, indexes ) {
			report.selector = table.rows(indexes);
			report.selected = report.selector.data().toArray()[0].mapID;
		})

		// Resizes the table based on a change in the height of parent element (resize event)
		// Does this by creating an iframe in the same space and listening for a resize
		_attach.call(table,this.namespace,this.tableOffset,function(height){
			console.log('resize')
			report.tableElement.parent().css("height",height - 30);
			table.draw();
		});

		// Redraws the map when the leftNav is maximized or minimized.
		// Needed to keep the columns and headers aligned during the resize
		$("#sidebarMin,#sidebarMax").on('click.'+namespace,function(){
			var tableContext = table;
			setTimeout(function(){
				tableContext.draw();
			},300)
		})

		// Add event listener for opening seat table modal for all seats
		table && table.on('click.'+namespace, 'td a.seatDrillDown', function () {
			var data = report.table.row($(this).closest('tr')).data();
			var seats = data.seats;
			var seatIDArray = [];
			for(var i in seats){seatIDArray.push(seats[i].seatID)}
			var modalOptions = {
				title: 'Seats in ' + data.name
			}
			Maptician.ModalTables.seatTable(seatIDArray,modalOptions);
		});

		// Add event listener for opening seat table modal for all seats
		table && table.on('click.'+namespace, 'td a.openSeatDrillDown', function () {
			var data = report.table.row($(this).closest('tr')).data();
			var modalOptions = {
				title: 'Open seats in ' + data.name
			}
			Maptician.ModalTables.seatTable(data.openSeats,modalOptions);
		});

		// Add event listener for opening seat table modal for all seats
		table && table.on('click.'+namespace, 'td a.roomDrillDown', function () {
			var data = report.table.row($(this).closest('tr')).data();
			var rooms = data.rooms;
			var roomIDArray = [];
			for(var i in rooms){roomIDArray.push(rooms[i].roomID)}
			var modalOptions = {
				title: 'Rooms in ' + data.name
			}
			Maptician.ModalTables.roomTable(roomIDArray,modalOptions);
		});

		// Add event listener for opening seat table modal for all seats
		table && table.on('click.'+namespace, 'td a.zoneDrillDown', function () {
			var data = report.table.row($(this).closest('tr')).data();
			var zones = data.zones;
			var zoneIDArray = [];
			for(var i in zones){zoneIDArray.push(zones[i].zoneID)}
			var modalOptions = {
				title: 'Zones in ' + data.name
			}
			Maptician.ModalTables.zoneTable(zoneIDArray,modalOptions);
		});

		// Add event listener for the edit button
		table && table.on('click.'+namespace,'.editMapButton', function () {
			var data = table.row($(this).closest('tr')).data();
			var editData = {
				id: data.mapID
			}
			$.ajax({type:"GET",url: "/loadMapFile",data:editData,
				success:function(result){
					$("#editorMenu a").trigger('click');
					$Map.Editor.loadFile(result);
				}
			})
		});

		// Add event listener for the view button
		table && table.on('click.'+namespace,'.viewMapButton', function () {
			var data = table.row($(this).closest('tr')).data();
			var editData = {
				id: data.mapID
			}
			$.ajax({type:"GET",url: "/loadMapFile",data:editData,
				success:function(result){
					$("#viewerMenu a").trigger('click');
					$Map.Viewer.loadFile(result);
				}
			})
		});
	}

	this.unsetBindings = function(){
		$(document).off('.'+this.namespace);
		$("#"+this.namespace).remove(); // Remove iframe
	}

	this.refreshTable = function(){
		
		report.table.ajax.reload();
	}

	this.createFooter = function(){
		var footer = "";
		footer += "<tfoot><tr>";
		for(var i = 0; i < this.tableColumns; i++){footer+= "<td></td>"}
		footer += "</tr></tfoot>";
		this.tableElement.append(footer);
	}
}
$Map.components.OfficesReports.mapList.prototype.constructor = $Map.components.OfficesReports.mapList;

$Map.components.OfficesReports.seatList = function(){
	this.url = '../api/offices/reports/seatList';
	this.tableContainer = $("#officeReports .table-container")
	this.tableElement = $("#officeReportTable");
	this.tableColumns = 11;
	this.table = null;
	this.officeID = null;
	this.selector = null;
	this.selected = null;
	this.tableOffset = 110;
	this.namespace = 'seatListReport';
	var report = this;

	this.open = function(officeID){
		this.officeID = officeID;
		this.setTable();
		this.setBindings(this.namespace);
		this.isOpen = true;
	}

	this.exit = function(){
		this.unsetBindings();
		this.table && this.table.clear().destroy(); // Clears datatable
		this.table = null;		
		this.tableElement.children().remove(); // Removes table remaining table elements (except table)
		this.isOpen = false;
	}

	this.update = function(officeID){
		if(officeID != this.officeID){
			this.officeID = officeID;
			this.refreshTable();
		}
	}

	this.setTable = function(){
		this.table = this.table || this.tableElement.DataTable({
			ajax: {
				url: this.url,
				data:function(d){
					return {officeID:report.officeID};
				}
			},
			rowId: 'seatID',
			select: {
				style: 'single',
				className: 'selected',
				selector: 'tr:not(.selected)'
			},
			scrollY: report.tableContainer.height() - this.tableOffset,
			deferRender:true,
			scroller:true,
			paging:true,
			autoWidth:true,
			columns:[
				{
					width: 50,
					sortable: false,
					data: {},
					className: 'tableProfileImage',
					render: function(seat){
						var path = seat.imagePath || "./../images/blankprofile.png";
						return '<div><img src="'+path+'"></div>';
					}					
				},
				{
					width: 50,
					title: "Seat",
					data: {},
					class: 'leftAlign',
					render: function(seat){
						return seat.seatName || "";
					}
				},
				{
					width: 100,
					title: "Map",
					data: {},
					class: 'leftAlign',
					render: function(seat){
						return seat.mapName || "";
					}
				},
				{
					width: 40,
					title: "Floor",
					data: {},
					class: 'centerAlign',
					render: function(seat){
						return seat.floor || "";
					}
				},
				{
					width: 40,
					title: "Suite",
					data: {},
					class: 'centerAlign',
					render: function(seat){
						return seat.suite || "";
					}
				},
				{
					width: 50,
					title: "Department",
					data: {},
					class: 'leftAlign',
					render: function(seat){
						return seat.department || "";
					}
				},
				{
					width: 50,
					title: "Type",
					data: {},
					class: 'leftAlign',
					render: function(seat){
						return seat.type || "";
					}
				},
				{
					width: 50,
					title: "Usage",
					data: {},
					class: 'leftAlign',
					render: function(seat){
						if(seat.reservable){
							return '<div class="btn seatReservationsButton">Reservations</div>';						
						} else if(seat.assignedTo) {
							return seat.assignedTo;
						} else {
							return "Available";
						}
						return seat.type || "";
					}
				},
				{
					width: 50,
					title: "Zone",
					data: {},
					class: 'leftAlign',
					render: function(seat){
						var zoneIndex = Object.keys(seat.zones);
						if(zoneIndex.length){
							if(zoneIndex.length == 1){
								return '<a class="zoneDrillDown">'+seat.zones[zoneIndex[0]].zoneName+'</a>';
							} else {
								return '<a class="zoneDrillDown">'+'Multiple'+'</a>';
							}
						} else {
							return "";
						}
					}
				},
				{
					width: 50,
					title: "Room",
					data: {},
					class: 'leftAlign',
					render: function(seat){
						var roomIndex = Object.keys(seat.rooms);
						if(roomIndex.length){
							if(roomIndex.length == 1){
								return '<a class="roomDrillDown">'+seat.rooms[roomIndex[0]].roomName+'</a>';
							} else {
								return '<a class="roomDrillDown">'+'Multiple'+'</a>';
							}
						} else {
							return "";
						}
					}
				},
				{
					width: 100,
					data: {},
					class: 'buttonCenter-small',
					"orderable":false,
					render: function(map){
						var myString = "";
						myString += '<div class="btn viewMapButton">View</div><div class="btn editMapButton">Edit</div>';
						return myString;
					},
				}
			],
			dom: 'brt'
		})
	}

	this.setBindings = function(namespace){
		table = this.table;

		// Handles row selection
		table && table.on( 'select.' + namespace , function ( e, dt, type, indexes ) {
			report.selector = table.rows(indexes);
			report.selected = report.selector.data().toArray()[0].mapID;
		})

		// Resizes the table based on a change in the height of parent element (resize event)
		// Does this by creating an iframe in the same space and listening for a resize
		_attach.call(table,this.namespace,this.tableOffset,function(height){
			report.tableElement.parent().css("height",height - 30);
			table.draw();
		});

		// Redraws the map when the leftNav is maximized or minimized.
		// Needed to keep the columns and headers aligned during the resize
		$("#sidebarMin,#sidebarMax").on('click.'+namespace,function(){
			var tableContext = table;
			setTimeout(function(){
				tableContext.draw();
			},300)
		})

		// Add event listener for opening seat table modal for all seats
		table && table.on('click.'+namespace, 'td a.seatDrillDown', function () {
			var data = report.table.row($(this).closest('tr')).data();
			var seats = data.seats;
			var seatIDArray = [];
			for(var i in seats){seatIDArray.push(seats[i].seatID)}
			var modalOptions = {
				title: 'Seats in ' + data.name
			}
			Maptician.ModalTables.seatTable(seatIDArray,modalOptions);
		});

		// Add event listener for opening seat table modal for all seats
		table && table.on('click.'+namespace, 'td a.roomDrillDown', function () {
			var data = report.table.row($(this).closest('tr')).data();
			var roomIDArray = Object.keys(data.rooms);
			var modalOptions = {
				title: 'Rooms containing Seat: ' + data.seatName
			}
			Maptician.ModalTables.roomTable(roomIDArray,modalOptions);
		});

		// Add event listener for opening seat table modal for all seats
		table && table.on('click.'+namespace, 'td a.zoneDrillDown', function () {
			var data = report.table.row($(this).closest('tr')).data();
			var zoneIDArray = Object.keys(data.zones);
			var modalOptions = {
				title: 'Zones containing Seat: ' + data.seatName
			}
			Maptician.ModalTables.zoneTable(zoneIDArray,modalOptions);
		});

		// Add event listener for the edit button
		table && table.on('click.'+namespace,'.editMapButton', function () {
			var data = table.row($(this).closest('tr')).data();
			var editData = {
				id: data.mapID
			}
			$.ajax({type:"GET",url: "/loadMapFile",data:editData,
				success:function(result){
					$("#editorMenu a").trigger('click');
					$Map.Editor.loadFile(result);
				}
			})
		});

		// Add event listener for the view button
		table && table.on('click.'+namespace,'.viewMapButton', function () {
			var data = table.row($(this).closest('tr')).data();
			var editData = {
				id: data.mapID
			}
			$.ajax({type:"GET",url: "/loadMapFile",data:editData,
				success:function(result){
					$("#viewerMenu a").trigger('click');
					$Map.Viewer.loadFile(result);
				}
			})
		});
	}

	this.unsetBindings = function(){
		$(document).off('.'+this.namespace);
		$("#"+this.namespace).remove(); // Remove iframe
	}

	this.refreshTable = function(){
		
		report.table.ajax.reload();
	}
}
$Map.components.OfficesReports.seatList.prototype.constructor = $Map.components.OfficesReports.seatList;

$Map.components.OfficesReports.roomList = function(){
	this.url = '../api/offices/reports/roomList';
	this.tableContainer = $("#officeReports .table-container")
	this.tableElement = $("#officeReportTable");
	this.tableColumns = 11;
	this.table = null;
	this.officeID = null;
	this.selector = null;
	this.selected = null;
	this.tableOffset = 110;
	this.namespace = 'roomListReport';
	var report = this;

	this.open = function(officeID){
		this.officeID = officeID;
		this.setTable();
		this.setBindings(this.namespace);
		this.isOpen = true;
	}

	this.exit = function(){
		this.unsetBindings();
		this.table && this.table.clear().destroy(); // Clears datatable
		this.table = null;		
		this.tableElement.children().remove(); // Removes table remaining table elements (except table)
		this.isOpen = false;
	}

	this.update = function(officeID){
		if(officeID != this.officeID){
			this.officeID = officeID;
			this.refreshTable();
		}
	}

	this.setTable = function(){
		this.table = this.table || this.tableElement.DataTable({
			ajax: {
				url: this.url,
				data:function(d){
					return {officeID:report.officeID};
				}
			},
			rowId: 'roomID',
			select: {
				style: 'single',
				className: 'selected',
				selector: 'tr:not(.selected)'
			},
			scrollY: report.tableContainer.height() - this.tableOffset,
			deferRender:true,
			scroller:true,
			paging:true,
			autoWidth:true,
			columns:[
				{
					width: 50,
					title: "Room",
					data: {},
					class: 'leftAlign',
					render: function(room){
						return room.roomName || "";
					}
				},
				{
					width: 100,
					title: "Map",
					data: {},
					class: 'leftAlign',
					render: function(room){
						return room.mapName || "";
					}
				},
				{
					width: 40,
					title: "Floor",
					data: {},
					class: 'centerAlign',
					render: function(room){
						return room.floor || "";
					}
				},
				{
					width: 40,
					title: "Suite",
					data: {},
					class: 'centerAlign',
					render: function(room){
						return room.suite || "";
					}
				},
				{
					width: 50,
					title: "Type",
					data: {},
					class: 'centerAlign',
					render: function(room){
						return room.roomType || "";
					}
				},				
				{
					width: 50,
					title: "Reservable",
					data: {},
					class: 'leftAlign',
					render: function(room){
						return room.reservable ? "Reservable" : "";
					}
				},
				{
					width: 50,
					title: "Department",
					data: {},
					class: 'leftAlign',
					render: function(room){
						return room.department || "";
					}
				},
				{
					width: 30,
					title: "Size",
					data: {},
					class: 'centerAlign',
					render: function(room){
						return renderArea(room.area) || "";
					}
				},
				{
					width: 30,
					title: "Capacity",
					data: {},
					class: 'centerAlign',
					render: function(room){
						return room.capacity || "";
					}
				},
				{
					width: 50,
					title: "Seats",
					data: {},
					class: 'centerAlign',
					render: function(room){
						room.seatCount = room.seatCount !== undefined ? room.seatCount : Object.keys(room.seats).length;
						return '<a class="seatDrillDown">'+room.seatCount+'</a>';
					}
				},
				{
					width: 100,
					data: {},
					class: 'buttonCenter-small',
					"orderable":false,
					render: function(map){
						var myString = "";
						myString += '<div class="btn viewMapButton">View</div><div class="btn editMapButton">Edit</div>';
						return myString;
					},
				}
			],
			dom: 'brt'
		})
	}

	this.setBindings = function(namespace){
		table = this.table;

		// Handles row selection
		table && table.on( 'select.' + namespace , function ( e, dt, type, indexes ) {
			report.selector = table.rows(indexes);
			report.selected = report.selector.data().toArray()[0].mapID;
		})

		// Resizes the table based on a change in the height of parent element (resize event)
		// Does this by creating an iframe in the same space and listening for a resize
		_attach.call(table,this.namespace,this.tableOffset,function(height){
			report.tableElement.parent().css("height",height - 30);
			table.draw();
		});

		// Redraws the map when the leftNav is maximized or minimized.
		// Needed to keep the columns and headers aligned during the resize
		$("#sidebarMin,#sidebarMax").on('click.'+namespace,function(){
			var tableContext = table;
			setTimeout(function(){
				tableContext.draw();
			},300)
		})

		// Add event listener for opening seat table modal for all seats
		table && table.on('click.'+namespace, 'td a.seatDrillDown', function () {
			var data = report.table.row($(this).closest('tr')).data();
			var seatIDArray = Object.keys(data.seats);
			var modalOptions = {
				title: 'Seats in ' + data.roomName
			}
			Maptician.ModalTables.seatTable(seatIDArray,modalOptions);
		});

		// Add event listener for opening seat table modal for all seats
		table && table.on('click.'+namespace, 'td a.roomDrillDown', function () {
			var data = report.table.row($(this).closest('tr')).data();
			var roomIDArray = Object.keys(data.rooms);
			var modalOptions = {
				title: 'Rooms containing Seat: ' + data.seatName
			}
			Maptician.ModalTables.roomTable(roomIDArray,modalOptions);
		});


		// Add event listener for the edit button
		table && table.on('click.'+namespace,'.editMapButton', function () {
			var data = table.row($(this).closest('tr')).data();
			var editData = {
				id: data.mapID
			}
			$.ajax({type:"GET",url: "/loadMapFile",data:editData,
				success:function(result){
					$("#editorMenu a").trigger('click');
					$Map.Editor.loadFile(result);
				}
			})
		});

		// Add event listener for the view button
		table && table.on('click.'+namespace,'.viewMapButton', function () {
			var data = table.row($(this).closest('tr')).data();
			var editData = {
				id: data.mapID
			}
			$.ajax({type:"GET",url: "/loadMapFile",data:editData,
				success:function(result){
					$("#viewerMenu a").trigger('click');
					$Map.Viewer.loadFile(result);
				}
			})
		});
	}

	this.unsetBindings = function(){
		$(document).off('.'+this.namespace);
		$("#"+this.namespace).remove(); // Remove iframe
	}

	this.refreshTable = function(){
		
		report.table.ajax.reload();
	}
}
$Map.components.OfficesReports.roomList.prototype.constructor = $Map.components.OfficesReports.roomList;

$Map.components.OfficesReports.zoneList = function(){
	this.url = '../api/offices/reports/zoneList';
	this.tableContainer = $("#officeReports .table-container")
	this.tableElement = $("#officeReportTable");
	this.tableColumns = 9;
	this.table = null;
	this.officeID = null;
	this.selector = null;
	this.selected = null;
	this.tableOffset = 110;
	this.namespace = 'zoneListReport';
	var report = this;

	this.open = function(officeID){
		this.officeID = officeID;
		this.setTable();
		this.setBindings(this.namespace);
		this.isOpen = true;
	}

	this.exit = function(){
		this.unsetBindings();
		this.table && this.table.clear().destroy(); // Clears datatable
		this.table = null;		
		this.tableElement.children().remove(); // Removes table remaining table elements (except table)
		this.isOpen = false;
	}

	this.update = function(officeID){
		if(officeID != this.officeID){
			this.officeID = officeID;
			this.refreshTable();
		}
	}

	this.setTable = function(){
		this.table = this.table || this.tableElement.DataTable({
			ajax: {
				url: this.url,
				data:function(d){
					return {officeID:report.officeID};
				}
			},
			rowId: 'zoneID',
			select: {
				style: 'single',
				className: 'selected',
				selector: 'tr:not(.selected)'
			},
			scrollY: report.tableContainer.height() - this.tableOffset,
			deferRender:true,
			scroller:true,
			paging:true,
			autoWidth:true,
			columns:[
				{
					width: 50,
					title: "Zone",
					data: {},
					class: 'leftAlign',
					render: function(zone){
						return zone.zoneName || "";
					}
				},
				{
					width: 100,
					title: "Map",
					data: {},
					class: 'leftAlign',
					render: function(zone){
						return zone.mapName || "";
					}
				},
				{
					width: 40,
					title: "Floor",
					data: {},
					class: 'centerAlign',
					render: function(zone){
						return zone.floor || "";
					}
				},
				{
					width: 40,
					title: "Suite",
					data: {},
					class: 'centerAlign',
					render: function(zone){
						return zone.suite || "";
					}
				},
				{
					width: 50,
					title: "Department",
					data: {},
					class: 'leftAlign',
					render: function(zone){
						return zone.department || "";
					}
				},
				{
					width: 50,
					title: "Rooms",
					data: {},
					class: 'centerAlign',
					render: function(zone){
						zone.roomCount = zone.roomCount !== undefined ? zone.roomCount : Object.keys(zone.rooms).length;
						return '<a class="roomDrillDown">'+zone.roomCount+'</a>';
					}
				},
				{
					width: 50,
					title: "Seats",
					data: {},
					class: 'centerAlign',
					render: function(zone){
						zone.seatCount = zone.seatCount !== undefined ? zone.seatCount : Object.keys(zone.seats).length;
						return '<a class="seatDrillDown">'+zone.seatCount+'</a>';
					}
				},
				{
					width: 30,
					title: "Size",
					data: {},
					class: 'centerAlign',
					render: function(room){
						return renderArea(room.area) || "";
					}
				},
				{
					width: 100,
					data: {},
					class: 'buttonCenter-small',
					"orderable":false,
					render: function(room){
						var myString = "";
						myString += '<div class="btn viewMapButton">View</div><div class="btn editMapButton">Edit</div>';
						return myString;
					},
				}
			],
			dom: 'brt'
		})
	}

	this.setBindings = function(namespace){
		table = this.table;

		// Handles row selection
		table && table.on( 'select.' + namespace , function ( e, dt, type, indexes ) {
			report.selector = table.rows(indexes);
			report.selected = report.selector.data().toArray()[0].mapID;
		})

		// Resizes the table based on a change in the height of parent element (resize event)
		// Does this by creating an iframe in the same space and listening for a resize
		_attach.call(table,this.namespace,this.tableOffset,function(height){
			report.tableElement.parent().css("height",height - 30);
			table.draw();
		});

		// Redraws the map when the leftNav is maximized or minimized.
		// Needed to keep the columns and headers aligned during the resize
		$("#sidebarMin,#sidebarMax").on('click.'+namespace,function(){
			var tableContext = table;
			setTimeout(function(){
				tableContext.draw();
			},300)
		})

		// Add event listener for opening seat table modal for all seats
		table && table.on('click.'+namespace, 'td a.seatDrillDown', function () {
			var data = report.table.row($(this).closest('tr')).data();
			var seatIDArray = Object.keys(data.seats);
			var modalOptions = {
				title: 'Seats in Zone:' + data.roomName
			}
			Maptician.ModalTables.seatTable(seatIDArray,modalOptions);
		});

		// Add event listener for opening seat table modal for all seats
		table && table.on('click.'+namespace, 'td a.roomDrillDown', function () {
			var data = report.table.row($(this).closest('tr')).data();
			var roomIDArray = Object.keys(data.rooms);
			var modalOptions = {
				title: 'Rooms in Zone: ' + data.seatName
			}
			Maptician.ModalTables.roomTable(roomIDArray,modalOptions);
		});


		// Add event listener for the edit button
		table && table.on('click.'+namespace,'.editMapButton', function () {
			var data = table.row($(this).closest('tr')).data();
			var editData = {
				id: data.mapID
			}
			$.ajax({type:"GET",url: "/loadMapFile",data:editData,
				success:function(result){
					$("#editorMenu a").trigger('click');
					$Map.Editor.loadFile(result);
				}
			})
		});

		// Add event listener for the view button
		table && table.on('click.'+namespace,'.viewMapButton', function () {
			var data = table.row($(this).closest('tr')).data();
			var editData = {
				id: data.mapID
			}
			$.ajax({type:"GET",url: "/loadMapFile",data:editData,
				success:function(result){
					$("#viewerMenu a").trigger('click');
					$Map.Viewer.loadFile(result);
				}
			})
		});
	}

	this.unsetBindings = function(){
		$(document).off('.'+this.namespace);
		$("#"+this.namespace).remove(); // Remove iframe
	}

	this.refreshTable = function(){
		
		report.table.ajax.reload();
	}
}
$Map.components.OfficesReports.zoneList.prototype.constructor = $Map.components.OfficesReports.zoneList;

$Map.components.OfficesReports.occupantList = function(){
	this.url = '../api/offices/reports/occupantList';
	this.tableContainer = $("#officeReports .table-container")
	this.tableElement = $("#officeReportTable");
	this.tableColumns = 9;
	this.table = null;
	this.officeID = null;
	this.selector = null;
	this.selected = null;
	this.tableOffset = 110;
	this.namespace = 'occupantListReport';
	var report = this;

	this.open = function(officeID){
		this.officeID = officeID;
		this.setTable();
		this.setBindings(this.namespace);
		this.isOpen = true;
	}

	this.exit = function(){
		this.unsetBindings();
		this.table && this.table.clear().destroy(); // Clears datatable
		this.table = null;		
		this.tableElement.children().remove(); // Removes table remaining table elements (except table)
		this.isOpen = false;
	}

	this.update = function(officeID){
		if(officeID != this.officeID){
			this.officeID = officeID;
			this.refreshTable();
		}
	}

	this.setTable = function(){
		this.table = this.table || this.tableElement.DataTable({
			ajax: {
				url: this.url,
				data:function(d){
					return {officeID:report.officeID};
				}
			},
			rowId: 'zoneID',
			select: {
				style: 'single',
				className: 'selected',
				selector: 'tr:not(.selected)'
			},
			scrollY: report.tableContainer.height() - this.tableOffset,
			deferRender:true,
			scroller:true,
			paging:true,
			autoWidth:true,
			columns:[
				{
					width: 50,
					sortable: false,
					data: {},
					className: 'tableProfileImage',
					render: function(user){
						return '<div><img src="'+user.imagePath+'"></div>';
					}					
				},
				{
					width: 75,
					title: "Name",
					data: {},
					class: 'leftAlign',
					render: function(user){
						return user.name || "";
					}
				},
				{
					width: 40,
					title: "ID",
					data: {},
					class: 'centerAlign',
					render: function(user){
						return user.employeeID || "";
					}
				},
				{
					width: 40,
					title: "Title",
					data: {},
					class: 'leftAlign',
					render: function(user){
						return user.title || "";
					}
				},
				{
					width: 50,
					title: "Department",
					data: {},
					class: 'centerAlign',
					render: function(user){
						return user.department || "";
					}
				},
				{
					width: 50,
					title: "Primary Office?",
					data: {},
					class: 'centerAlign',
					render: function(user){
						return user.office ? "Yes" : "No";
					}
				},
				{
					width: 50,
					title: "Seat Assigned",
					data: {},
					class: 'centerAlign',
					render: function(user){
						var seats = Object.keys(user.seatAssign);
						var seatCount = seats.length;
						if(seatCount == 0){
							return "";
						} else if (seatCount == 1){
							return '<a class="seatAssignDrillDown">' + user.seatAssign[seats[0]] + '</a>';
						} else {
							return '<a class="seatAssignDrillDown">' + seatCount + '</a>';
						}
					}
				},
				{
					width: 50,
					title: "Seat Reserved",
					data: {},
					class: 'centerAlign',
					render: function(user){
						var seats = Object.keys(user.seatRes);
						var seatCount = seats.length;
						if(seatCount == 0){
							return "";
						} else if (seatCount == 1){
							return '<a class="seatResDrillDown">' + user.seatRes[user.seats[0]] + '</a>';
						} else {
							return '<a class="seatResDrillDown">' + seatCount + '</a>';
						}
					}
				},
				{
					width: 50,
					title: "Room Reserved",
					data: {},
					class: 'centerAlign',
					render: function(user){
						var rooms = Object.keys(user.roomRes);
						var roomCount = rooms.length;
						if(roomCount == 0){
							return "";
						} else if (roomCount == 1){
							return '<a class="roomDrillDown">' + user.roomRes[user.rooms[0]] + '</a>';
						} else {
							return '<a class="roomDrillDown">' + roomCount + '</a>';
						}
					}
				},
			],
			dom: 'brt'
		})
	}

	this.setBindings = function(namespace){
		table = this.table;

		// Handles row selection
		table && table.on( 'select.' + namespace , function ( e, dt, type, indexes ) {
			report.selector = table.rows(indexes);
			report.selected = report.selector.data().toArray()[0].mapID;
		})

		// Resizes the table based on a change in the height of parent element (resize event)
		// Does this by creating an iframe in the same space and listening for a resize
		_attach.call(table,this.namespace,this.tableOffset,function(height){
			report.tableElement.parent().css("height",height - 30);
			table.draw();
		});

		// Redraws the map when the leftNav is maximized or minimized.
		// Needed to keep the columns and headers aligned during the resize
		$("#sidebarMin,#sidebarMax").on('click.'+namespace,function(){
			var tableContext = table;
			setTimeout(function(){
				tableContext.draw();
			},300)
		})

		// Add event listener for opening seat table modal for all seats
		table && table.on('click.'+namespace, 'td a.seatAssignDrillDown', function () {
			var data = report.table.row($(this).closest('tr')).data();
			var seatIDArray = Object.keys(data.seatAssign);
			var modalOptions = {
				title: 'Seats assigned to ' + data.name
			}
			Maptician.ModalTables.seatTable(seatIDArray,modalOptions);
		});

		// Add event listener for opening seat table modal for all seats
		table && table.on('click.'+namespace, 'td a.seatResDrillDown', function () {
			var data = report.table.row($(this).closest('tr')).data();
			var seatIDArray = Object.keys(data.seatRes);
			var modalOptions = {
				title: 'Seats reserved by ' + data.name
			}
			Maptician.ModalTables.seatTable(seatIDArray,modalOptions);
		});

		// Add event listener for opening seat table modal for all seats
		table && table.on('click.'+namespace, 'td a.roomDrillDown', function () {
			var data = report.table.row($(this).closest('tr')).data();
			var roomIDArray = Object.keys(data.roomRes);
			var modalOptions = {
				title: 'Rooms reserved by ' + data.name
			}
			Maptician.ModalTables.roomTable(roomIDArray,modalOptions);
		});

	}

	this.unsetBindings = function(){
		$(document).off('.'+this.namespace);
		$("#"+this.namespace).remove(); // Remove iframe
	}

	this.refreshTable = function(){
		
		report.table.ajax.reload();
	}
}
$Map.components.OfficesReports.occupantList.prototype.constructor = $Map.components.OfficesReports.occupantList;

$Map.components.OfficesReports.visitorList = function(){
	this.url = '../api/offices/reports/visitorList';
	this.tableContainer = $("#officeReports .table-container")
	this.tableElement = $("#officeReportTable");
	this.tableColumns = 9;
	this.table = null;
	this.officeID = null;
	this.selector = null;
	this.selected = null;
	this.tableOffset = 110;
	this.namespace = 'visitorListReport';
	this.timeSelect = $('#officeReports .time-select');
	this.start = null;
	this.end = null;
	var report = this;

	this.open = function(officeID){
		this.officeID = officeID;
		this.timeSelect.val(0).show();
		this.getTimePeriod();
		this.setTable();
		this.setBindings(this.namespace);
		this.isOpen = true;
	}

	this.exit = function(){
		this.unsetBindings();
		this.timeSelect.val(0).hide();
		this.table && this.table.clear().destroy(); // Clears datatable
		this.table = null;		
		this.tableElement.children().remove(); // Removes table remaining table elements (except table)
		this.isOpen = false;
	}

	this.update = function(officeID){
		if(officeID != this.officeID){
			this.officeID = officeID;
			this.refreshTable();
		}
	}

	this.setTable = function(){
		this.table = this.table || this.tableElement.DataTable({
			ajax: {
				url: this.url,
				data:function(d){
					return {
						officeID:report.officeID,
						start: report.start,
						end: report.end
					};
				}
			},
			rowId: 'date',
			select: {
				style: 'single',
				className: 'selected',
				selector: 'tr:not(.selected)'
			},
			scrollY: report.tableContainer.height() - this.tableOffset,
			deferRender:true,
			scroller:true,
			paging:true,
			autoWidth:true,
			columns:[
				{
					width: 75,
					title: "Name",
					data: {},
					class: 'leftAlign',
					render: function(visitor){
						return visitor.name || "";
					}
				},
				{
					width: 50,
					title: "Company",
					data: {},
					class: 'leftAlign',
					render: function(visitor){
						return visitor.company || "";
					}
				},
				{
					width: 50,
					title: "Purpose",
					data: {},
					class: 'leftAlign',
					render: function(visitor){
						return visitor.purpose || "";
					}
				},
				{
					width: 50,
					title: "Date",
					data: {},
					class: 'centerAlign',
					render: function(visitor){
						return moment(visitor.date).format('MMM DD, YYYY');
					}
				},
				{
					width: 50,
					title: "Time",
					data: {},
					class: 'centerAlign',
					render: function(visitor){
						return moment(visitor.date).format('hh:mm A');
					}
				},
				{
					width: 50,
					title: "Kiosk",
					data: {},
					class: 'leftAlign',
					render: function(visitor){
						return visitor.kiosk || "";
					}
				},
				{
					width: 50,
					title: "Map",
					data: {},
					class: 'leftAlign',
					render: function(visitor){
						return visitor.map || "";
					}
				},
				{
					width: 50,
					title: "Phone",
					data: {},
					class: 'centerAlign',
					render: function(visitor){
						return visitor.cell || "";
					}
				},
				{
					width: 50,
					title: "Email",
					data: {},
					class: 'leftAlign',
					render: function(visitor){
						return visitor.email || "";
					}
				},
			],
			dom: 'brt'
		})
	}

	this.setBindings = function(namespace){
		table = this.table;

		// Handles row selection
		table && table.on( 'select.' + namespace , function ( e, dt, type, indexes ) {
			report.selector = table.rows(indexes);
			report.selected = report.selector.data().toArray()[0].mapID;
		})

		// Resizes the table based on a change in the height of parent element (resize event)
		// Does this by creating an iframe in the same space and listening for a resize
		_attach.call(table,this.namespace,this.tableOffset,function(height){
			report.tableElement.parent().css("height",height - 30);
			table.draw();
		});

		this.timeSelect.on('change.' + namespace, function(){
			report.refreshTable();
		})

		// Redraws the map when the leftNav is maximized or minimized.
		// Needed to keep the columns and headers aligned during the resize
		$("#sidebarMin,#sidebarMax").on('click.'+namespace,function(){
			var tableContext = table;
			setTimeout(function(){
				tableContext.draw();
			},300)
		})
	}

	this.unsetBindings = function(){
		$(document).off('.'+this.namespace);
		$("#"+this.namespace).remove(); // Remove iframe
	}

	this.refreshTable = function(){
		this.getTimePeriod();
		report.table.ajax.reload().draw();
	}

	this.getTimePeriod = function(){
		switch(1*this.timeSelect.val()){
			case 0: // This week
				this.start = moment().startOf('week').valueOf();
				this.end = moment().valueOf();
			break;
			case 1: // This Month
				this.start = moment().startOf('month').valueOf();
				this.end = moment().valueOf();
			break;
			case 2: // This Year
				this.start = moment().startOf('year').valueOf();
				this.end = moment().valueOf();
			break;
			case 3: // Today
				this.start = moment().startOf('day').valueOf();
				this.end = moment().valueOf();
			break;
			case 4: // Yesterday
				this.start = moment().subtract(1,'day').startOf('day').valueOf();
				this.end = moment().subtract(1,'day').endOf('day').valueOf();
			break;
			case 5: // Last Week
				this.start = moment().subtract(1,'week').startOf('week').valueOf();
				this.end = moment().subtract(1,'week').endOf('week').valueOf();
			break;
			case 6: // Last Month
				this.start = moment().subtract(1,'month').startOf('month').valueOf();
				this.end = moment().subtract(1,'month').endOf('month').valueOf();
			break;
			case 7: // Last Year
				this.start = moment().subtract(1,'year').startOf('year').valueOf();
				this.end = moment().subtract(1,'year').endOf('year').valueOf();
			break;
			case 8: // Past 7 Days
				this.start = moment().subtract(7,'days').startOf('day').valueOf();
				this.end = moment().endOf('day').valueOf();
			break;
			case 9: // Past 30 Days
				this.start = moment().subtract(30,'days').startOf('day').valueOf();
				this.end = moment().endOf('day').valueOf();
			break;
			case 10: // Past 90 Days
				this.start = moment().subtract(90,'days').startOf('day').valueOf();
				this.end = moment().endOf('day').valueOf();
			break;
		}
	}
}
$Map.components.OfficesReports.occupantList.prototype.constructor = $Map.components.OfficesReports.occupantList;