$Map.components.OccupantList = function(officeController){
	// General Parameters
	this.controller = officeController;
	this.group = 'officeOccupants';
	this.namspace = 'officeOccupants';
	this.fileName = 'office_occupants';
	this.url = '../api/offices/summary/occupantList';
	this.contentArea = $("#officeOccupants");
	this.searchBox = this.contentArea.find('.search');
	this.template = $("#officeOccupants .profile-tile");
	this.data = null;

	var Occupants = this;

	this.open = function(){
		this.setBindings();
		this.getData();
	}

	this.exit = function(){

	}

	this.refresh = function(){

	}

	this.updateOffice = function(){
		this.contentArea.children('.profile-tile').remove();
		this.getData();
	}

	this.getData = function(){
		var data = this.controller.officeSelected || "";
		$.ajax({
			type:"GET",
			data: {officeID:data},
			url: this.url
		})
		.then(function(data){
			Occupants.data = data.data;
			Occupants.stringify();
			Occupants.drawTiles();
		})
		.catch(function(err){
			console.log(err);
		})
	}

	this.stringify = function(){
		var len = this.data.length;
		for(var i = 0; i < len; i++){
			this.data[i].text = JSON.stringify(this.data[i]).toLowerCase();
		}
	}

	this.drawTiles = function(){
		this.contentArea.children('.profile-tile').remove();
		var len = this.data.length;
		for(var i = 0; i < len; i++){
			this.createTile(i);
		}
	}

	this.createTile = function(index){
		var data = this.data[index];
		var seat, room;
		var tile = this.template.clone();
		tile.prop('id',data.userID);
		for(var i in data.seatAssign){
			seat = data.seatAssign[i];
			var assignedSeatString = "Assigned Seat: ";
			assignedSeatString += seat.seatName;
			assignedSeatString += seat.floor ? " Floor: " + seat.floor : "";
			assignedSeatString += seat.suite ? " Suite: " + seat.suite : "";
			break; // Only want the first assignment
		}
		for(var i in data.seatRes){
			seat = data.seatRes[i];
			var reservedSeatString = "Reserved Seat: ";
			reservedSeatString += seat.seatName;
			reservedSeatString += seat.floor ? " Floor: " + seat.floor : "";
			reservedSeatString += seat.suite ? " Suite: " + seat.suite : "";
			break; // Only want the first assignment
		}
		for(var i in data.roomRes){
			seat = data.roomRes[i];
			var reservedRoomString = "Reserved Room: ";
			reservedRoomString += seat.roomName;
			reservedRoomString += seat.floor ? " Floor: " + seat.floor : "";
			reservedRoomString += seat.suite ? " Suite: " + seat.suite : "";
			break; // Only want the first assignment
		}
		tile.find('img').prop('src',data.imagePath);
		data.name ? tile.find('.name').html(data.name) : tile.find('.name').remove();
		data.title ? tile.find('.title').html(data.title) : tile.find('.title').remove();
		data.department && data.department != "Unassigned" ? tile.find('.department').html("Department: "+data.department) : tile.find('.department').remove();
		data.email ? tile.find('.email').html("Email: <a href='mailto:"+data.email+"'>"+data.email+"</a>") : tile.find('.email').remove();
		data.cell ? tile.find('.cell').html("Cell: <a href='tel:"+data.cell+"'>" + data.cell+"</a>") : tile.find('.cell').remove();
		data.floor ? tile.find('.floor').html("Floor: "+data.floor) : tile.find('.floor').remove();
		data.suite ? tile.find('.suite').html("Suite: "+data.suite) : tile.find('.suite').remove();
		assignedSeatString ? tile.find('.assnSeat').html(assignedSeatString) : tile.find('.assnSeat').remove();
		reservedSeatString ? tile.find('.resSeat').html(reservedSeatString) : tile.find('.resSeat').remove();
		reservedRoomString ? tile.find('.resRoom').html(reservedRoomString) : tile.find('.resRoom').remove();
		tile.appendTo(this.contentArea);
	}

	this.setBindings = function(){
		this.searchBox.on('input.'+this.namspace,function(){
			var data = Occupants.data;
			var len = data.length;
			var value = $(this).val().toLowerCase().split(' ');
			var len2 = value.length;
			var text, search, occupant;
			var objID;
			var excluded = false;
			for(var i = 0; i < len; i++){
				excluded = false;
				occupant = data[i];
				text = occupant.text;
				console.log(text)
				console.log(value)
				objID = occupant.userID;
				for(var j = 0; j < len2; j++){
					search = value[j];
					if(text.indexOf(search) == -1){
						excluded = true;
						break;
					}
				}
				if(excluded){
					$("#"+objID).hide();
				} else {
					$("#"+objID).show();
				}
			}
		})
	}

	this.unsetBindings = function(){

	}
}
$Map.components.OccupantList.prototype.constructor = $Map.components.OccupantList;