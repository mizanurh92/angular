$Map.components.OfficeAnalytics = function(officeController){
	console.log('Started Analytics Controller')
	this.officeController = officeController;
	this.reportSelector = $("#officeAnalytics select.analytics-select");
	this.openReport = null;
	var Analytics = this;

	this.open = function(){
		this.reportSelector.val(0);
		this.setBindings();
	}

	this.exit = function(){
		this.openReport.report.exit();
		this.openReport = null;
		this.unsetBindings();
	}

	this.updateOffice = function(){
		if(this.openReport){
			this.openReport.report.update(this.officeController.officeSelected);
		}
	}

	this.setBindings = function(){
		this.reportSelector.on('change',function(){
			
			var index = 1*$(this).val();

			if(Analytics.openReport && Analytics.openReport.index != index){
				Analytics.openReport.report.exit();				
			}

			switch(index){
				case 0:
				break;
				case 1:
					Analytics.seatCapacityTypeByDay = Analytics.seatCapacityTypeByDay || new $Map.components.OfficeAnalytics.seatCapacityTypeByDay;
					Analytics.seatCapacityTypeByDay.open(Analytics.officeController.officeSelected);
					Analytics.openReport = {index:index,report:Analytics.seatCapacityTypeByDay};
				break;
				case 2:
					Analytics.seatCapacityByDay = Analytics.seatCapacityByDay || new $Map.components.OfficeAnalytics.seatCapacityByDay;
					Analytics.seatCapacityByDay.open(Analytics.officeController.officeSelected);
					Analytics.openReport = {index:index,report:Analytics.seatCapacityByDay};
				break;
				case 3:
					Analytics.seatReservationUsageByDay = Analytics.seatReservationUsageByDay || new $Map.components.OfficeAnalytics.seatReservationUsageByDay;
					Analytics.seatReservationUsageByDay.open(Analytics.officeController.officeSelected);
					Analytics.openReport = {index:index,report:Analytics.seatReservationUsageByDay};
				break;
				// case 2:
				// 	Reports.roomList = Reports.roomList || new $Map.components.OfficesReports.roomList();
				// 	Reports.roomList.open(Reports.officeController.officeSelected);
				// 	Reports.openReport = {index:index,report:Reports.roomList};
				// break;
				// case 3:
				// 	Reports.zoneList = Reports.zoneList || new $Map.components.OfficesReports.zoneList();
				// 	Reports.zoneList.open(Reports.officeController.officeSelected);
				// 	Reports.openReport = {index:index,report:Reports.zoneList};
				// break;
				// case 4:
				// 	Reports.occupantList = Reports.occupantList || new $Map.components.OfficesReports.occupantList();
				// 	Reports.occupantList.open(Reports.officeController.officeSelected);
				// 	Reports.openReport = {index:index,report:Reports.occupantList};
				// break;
				// case 5:
				// 	Reports.visitorList = Reports.visitorList || new $Map.components.OfficesReports.visitorList();
				// 	Reports.visitorList.open(Reports.officeController.officeSelected);
				// 	Reports.openReport = {index:index,report:Reports.visitorList};
				// break;
			}
		})
	}

	this.unsetBindings = function(){
		this.reportSelector.off('change');
	}
}
$Map.components.OfficeAnalytics.prototype.constructor = $Map.components.OfficeAnalytics;

$Map.components.OfficeAnalytics.seatCapacityTypeByDay = function(){
	// General Parameters
	this.group = 'seatCapacityTypeByDay';
	this.namespace = 'seatCapacityTypeByDay';
	this.fileName = 'seat_capacity_type_by_day';
	this.url = '../api/analytics/capacity/seatCapacityTypeByDay';

	// Screen Objects
	this.contentWrapper = $("#officeAnalytics");
	this.tile0 = this.contentWrapper.find('.tile-0');
	this.tile1 = this.contentWrapper.find('.tile-1');
	this.tile2 = this.contentWrapper.find('.tile-2');
	this.tile3 = this.contentWrapper.find('.tile-3');
	this.tile4 = this.contentWrapper.find('.tile-4');
	this.tile5 = this.contentWrapper.find('.tile-5');
	this.tile6 = this.contentWrapper.find('.tile-6');
	this.tile7 = this.contentWrapper.find('.tile-7');
	this.tile8 = this.contentWrapper.find('.tile-8');
	this.tile9 = this.contentWrapper.find('.tile-9');
	this.downloadButton = this.contentWrapper.find('.download-btn');
	this.resetButton = this.contentWrapper.find('.reset-btn')

	var Analytics = this;

	// Formatting Options
	var numberFormat = d3.format(".0f");
	var decimalFormat = d3.format(".2f");
	var percentFormat = d3.format(".0%");
	var dateFormat = d3.time.format("%Y-%m-%d");
	var shortDate = d3.time.format("%b-%d '%y");
	var longDate = d3.time.format("%B %d, %Y");	

	this.open = function(officeID){
		this.officeID = officeID;
		this.setTiles();
		this.setCharts();
		this.getData();
		this.setBindings();
	}

	this.exit = function(){
		this.unsetCharts();
		this.unsetTiles();
		this.clearData();
		this.unsetBindings();
		this.officeID = null;
	}

	this.update = function(officeID){
		this.officeID = officeID;
		this.unsetCharts();
		this.unsetTiles();
		this.clearData();
		this.setTiles();
		this.setCharts();
		this.getData();
	}

	this.setTiles = function(){
		this.tile0.css({display:"inline-block"}).addClass('full-width half-high main-chart')
			.html("<div class='main-table'><strong class='header absolute'>Seat Capacity</strong>" + 
				"</div><div class='main-areaBrush'></div>");
		this.tile1.css({display:"inline-flex"}).addClass('dc-select-box')
			.html("<strong class='header absolute'>Capacity Type</strong>");
		this.tile2.css({display:"inline-flex"}).addClass('dc-select-box')
			.html("<strong class='header absolute'>Department</strong>");
		this.tile3.css({display:"inline-flex"}).addClass('dc-select-box')
			.html("<strong class='header absolute'>Map</strong>");
		this.tile4.css({display:"inline-flex"}).addClass('dc-select-box')
			.html("<strong class='header absolute'>Floor</strong>");
		this.tile5.css({display:"inline-flex"}).addClass('dc-select-box')
			.html("<strong class='header absolute'>Suite</strong>");
		this.tile6.css({display:"none"}).html("");
		this.tile7.css({display:"none"}).html("");
		this.tile8.css({display:"none"}).html("");		
		this.tile9.css({display:"none"}).html("");
	}

	this.unsetTiles = function(){
		this.tile0.css({display:"none"}).removeClass("full-width half-high main-chart").html("");
		this.tile1.css({display:"none"}).removeClass("dc-select-box").html("");
		this.tile2.css({display:"none"}).removeClass("dc-select-box").html("");
		this.tile3.css({display:"none"}).removeClass("dc-select-box").html("");
		this.tile4.css({display:"none"}).removeClass("dc-select-box").html("");
		this.tile5.css({display:"none"}).removeClass("dc-select-box").html("");
		this.tile6.css({display:"none"}).html("");
		this.tile7.css({display:"none"}).html("");
		this.tile8.css({display:"none"}).html("");
		this.tile9.css({display:"none"}).html("");
	}

	this.setCharts = function(){
		this.chart0a = dc.lineChart(this.tile0.children('.main-table')[0],this.group);
		this.chart0b = dc.lineChart(this.tile0.children('.main-areaBrush')[0],this.group);
		this.chart1 = dc.selectMenu(this.tile1[0],this.group);
		this.chart2 = dc.selectMenu(this.tile2[0],this.group);
		this.chart3 = dc.selectMenu(this.tile3[0],this.group);
		this.chart4 = dc.selectMenu(this.tile4[0],this.group);
		this.chart5 = dc.selectMenu(this.tile5[0],this.group);
		//this.chart6 = dc.numberDisplay(this.tile6[0],this.group);
		//this.chart7 = dc.numberDisplay(this.tile7[0],this.group);
		//this.chart8 = dc.numberDisplay(this.tile8[0],this.group);
		//this.chart9 = dc.numberDisplay(this.tile9[0],this.group);
	}

	this.unsetCharts = function(){
		dc.deregisterAllCharts(this.group);
		this.chart0a = null;
		this.chart0b = null;
		this.chart1 = null;
		this.chart2 = null;
		this.chart3 = null;
		this.chart4 = null;
		this.chart5 = null;
		//this.chart6 = null;
		//this.chart7 = null;
		//this.chart8 = null;
		//this.chart9 = null;
	}

	this.getData = function(){
		$.ajax({
			type:"GET",
			url: this.url,
			data: {officeID:this.officeID}
		})
		.then(function(data){
			data = Analytics.formatData(data);
			Analytics.setDataObjects(data);
			Analytics.configureCharts();
			if(!data.length){return;}
			Analytics.renderCharts();
		})
		.catch(function(err){
			console.log(err);
		})
	}	

	this.setDataObjects = function(data){
		this.data = crossfilter(data);

	    // Dimensions and group for main chart
	    this.mainDim = this.data.dimension(function (d) {
	        return d.date;
	    });

	    this.mainGroups = this.mainDim.group().reduce(
	        function (p, v) { /* callback for when data is added to the current filter results */
	            var val = v.val || 0;
	            var type = v.type;
	            p[type] += val;
	            p.Count += val;
	            p.Assignable = p.Assigned + p.Unassigned;
	            return p;
	        }, /* callback for when data is removed from the current filter results */
	        function (p, v) {
	            var val = v.val || 0;
	            var type = v.type;
	            p[type] -= val;
	            p.Count -= val;
	            p.Assignable = p.Assigned + p.Unassigned;
	            return p;
	        }, /* initialize p */
	        function () {
	            return {
	                Count: 0,
	                Reservable: 0,
	                Assignable: 0,
	                Assigned: 0,
	                Unassigned: 0,
	            };
	        }
	    );

		this.capacityTypeDim = this.data.dimension(function (d) {
			return d.type;
		});
		this.capacityTypeGroup = this.capacityTypeDim.group();

		this.departmentDim = this.data.dimension(function (d) {
			return d.department;
		});
		this.departmentGroup = this.departmentDim.group();

		this.mapDim = this.data.dimension(function (d) {
			return d.map;
		});
		this.mapGroup = this.mapDim.group();	

		this.floorDim = this.data.dimension(function (d) {
			return d.floor;
		});
		this.floorGroup = this.floorDim.group();

		this.suiteDim = this.data.dimension(function (d) {
			return d.suite;
		});
		this.suiteGroup = this.suiteDim.group();

	}

	this.configureCharts = function(){
		this.chart0a
			.renderArea(true)
		    .width(1000)
		    .height(320)
			.useViewBoxResizing(true)
		    .transitionDuration(1000)
		    .margins({top: 20, right: 20, bottom: 20, left: 30})
		    .dimension(this.mainDim)
		    .mouseZoomable(false)
		    .rangeChart(this.chart0b)
		    .x(d3.time.scale().domain([this.start,this.end]))
		    .xUnits(d3.time.days)
		    .round(d3.time.day.round)
		    .elasticY(true)
		    .renderHorizontalGridLines(true)
		    .legend(dc.legend().x(850).y(0).itemHeight(13).gap(5))
		    .brushOn(false)
		    .group(this.mainGroups, 'Assigned Capacity')
		    .valueAccessor(function (d) {return d.value.Assigned;})
		    .stack(this.mainGroups, 'Available Capacity', function (d) {return d.value.Unassigned;})
		    .stack(this.mainGroups, 'Reservable Capacity', function (d) {return d.value.Reservable;})	        
		    .title(function (d) {
		         return dateFormat(d.key) + '\n' +
		         "Total: " + numberFormat(d.value.Count) + '\n' +
		         "Assigned: " + numberFormat(d.value.Assigned) + '\n' +
		         "Available: " + numberFormat(d.value.Unassigned) + '\n' +
		         "Reservable: " + numberFormat(d.value.Reservable);
		    })
		    .xAxis().tickFormat(shortDate).tickValues(
					function(){
						var filters = Analytics.chart0b.filters();
						if(filters.length){
							var range = filters[0];
							var days = moment.duration(moment.preciseDiff(range[0],range[1],true)).asDays();
							var step = Math.ceil(days/10);
							return $Map.tools.analytics.getTicks(range[0],range[1],{step:step});
						} else {
							var days = moment.duration(moment.preciseDiff(Analytics.start,Analytics.end,true)).asDays();
							var step = Math.ceil(days/10);
							return $Map.tools.analytics.getTicks(Analytics.start,Analytics.end,{step:step});
						}
					}
				)

		this.chart0b
			.renderArea(true)
			.width(1000)
		    .height(80)
			.useViewBoxResizing(true)
			.mouseZoomable(false)
		    .transitionDuration(1000)
		    .margins({top: 10, right: 20, bottom: 20, left: 30})
		    .dimension(this.mainDim)
		    .group(this.mainGroups, 'Total Capacity')
		    .valueAccessor(function (d) {return d.value.Count;})
		    .x(d3.time.scale().domain([this.start,this.end]))
		    .elasticY(true)
		    .renderHorizontalGridLines(false)
		    //.round(d3.time.day.round)
		    //.xUnits(d3.time.days)
		    .yAxis().tickValues([]).outerTickSize(0);
		this.chart0b
			.xAxis().tickFormat(shortDate).tickValues(
					function(){
						var days = moment.duration(moment.preciseDiff(Analytics.start,Analytics.end,true)).asDays();
						var step = Math.floor(days/10);
						return $Map.tools.analytics.getTicks(Analytics.start,Analytics.end,{step:step});
					}
				)

		this.chart1
		   	.dimension(this.capacityTypeDim)
		   	.group(this.capacityTypeGroup)
		   	.multiple(true)
			.title(function (d){return d.key;})

		this.chart2
		   	.dimension(this.departmentDim)
		   	.group(this.departmentGroup)
		   	.multiple(true)
			.title(function (d){return d.key;})

		this.chart3
		   	.dimension(this.mapDim)
		   	.group(this.mapGroup)
		   	.multiple(true)
			.title(function (d){return d.key;})

		this.chart4
		   	.dimension(this.floorDim)
		   	.group(this.floorGroup)
		   	.multiple(true)
			.title(function (d){return d.key;})

		this.chart5
		   	.dimension(this.suiteDim)
		   	.group(this.suiteGroup)
		   	.multiple(true)
			.title(function (d){return d.key;})
	}

	this.refreshData = function(){
		$.ajax({
			type:"GET",
			url: this.url,
			data: {officeID:this.officeID}
		})
		.then(function(data){
			data = Analytics.formatData(data);
			try{
				Analytics.data.remove();
				Analytics.data.add(data);
			} catch (err) {
				console.log(err);
			}
			Analytics.renderCharts();
		})
		.catch(function(err){
			console.log(err);
		})		
	}

	this.clearData = function(){
		this.data = null;
		this.mainDim = null;
		this.mainGroups = null;
		this.capacityTypeDim = null;
		this.capacityTypeGroup = null;
		this.departmentDim = null;
		this.departmentGroup = null;
		this.mapDim = null;
		this.mapGroup = null;
		this.floorDim = null;
		this.floorGroup = null;
		this.suiteDim = null;
		this.suiteGroup = null;
	}

	this.formatData = function(data){
		var formatted = [];
		this.end = new Date(moment().endOf('day').subtract(12,'h').valueOf());
		this.start = null;
		data.forEach(function(d){
			d.date = 1*d.date; // Coerce to number
			if(Analytics.start){ // Finds the earliest date in the results
				Analytics.start = d.date < Analytics.start ? d.date : Analytics.start;
			} else { Analytics.start = d.date; }

			var tempObj = {
				date: new Date(moment(d.date).startOf('day').add(1,'hour').valueOf()),
				department: d.department,
				floor: d.floor,
				suite: d.suite,
				map: d.mapName
			}
			if(d.reservable){
				formatted.push($.extend({type:"Reservable",val:d.reservable},tempObj))
			}
			if(d.assigned){
				formatted.push($.extend({type:"Assigned",val:d.assigned},tempObj))
			}
			if(d.unassigned){
				formatted.push($.extend({type:"Unassigned",val:d.unassigned},tempObj))
			}       
		})
		return formatted;
	}

	this.renderCharts = function(){
		dc.renderAll(this.group);
	}

	this.setBindings = function(){
		this.resetButton.on('click.'+this.namespace,function(){
			dc.filterAll(Analytics.group);
			dc.redrawAll(Analytics.group);
		})

		this.downloadButton.on('click.'+this.namespace,function(){
		    var data = Analytics.mainDim.top(Infinity);
		    data = data.map(function(d){
		    	var formatted = {
		    		Date: longDate(d.date),
		    		Department: d.department,
		    		Map: d.map,
		    		Suite: d.suite,
		    		Floor: d.floor,
		    		Seats: d.capacity
		    	}
		    	return formatted;
		    })
		    var blob = new Blob([d3.csv.format(data)], {type: "text/csv;charset=utf-8"});
		    saveAs(blob, Analytics.fileName+'.csv');
		})
	}

	this.unsetBindings = function(){
		this.resetButton.off('.'+this.namespace);
		this.downloadButton.off('.'+this.namespace);		
	}
}
$Map.components.OfficeAnalytics.seatCapacityTypeByDay.prototype.constructor = 
	$Map.components.OfficeAnalytics.seatCapacityTypeByDay;

$Map.components.OfficeAnalytics.seatCapacityByDay = function(){
	console.log('loading seat capacity by day')
	// General Parameters
	this.group = 'seatCapacityByDay';
	this.namespace = 'seatCapacityByDay';
	this.fileName = 'seat_capacity_by_day';
	this.url = '../api/analytics/capacity/seatCapacityByDay';

	// Screen Objects
	this.contentWrapper = $("#officeAnalytics");
	this.tile0 = this.contentWrapper.find('.tile-0');
	this.tile1 = this.contentWrapper.find('.tile-1');
	this.tile2 = this.contentWrapper.find('.tile-2');
	this.tile3 = this.contentWrapper.find('.tile-3');
	this.tile4 = this.contentWrapper.find('.tile-4');
	this.tile5 = this.contentWrapper.find('.tile-5');
	this.tile6 = this.contentWrapper.find('.tile-6');
	this.tile7 = this.contentWrapper.find('.tile-7');
	this.tile8 = this.contentWrapper.find('.tile-8');
	this.tile9 = this.contentWrapper.find('.tile-9');
	this.downloadButton = this.contentWrapper.find('.download-btn');
	this.resetButton = this.contentWrapper.find('.reset-btn')

	var Analytics = this;
	var daysBetween = $Map.tools.analytics.daysBetween;
	var getTicks = $Map.tools.analytics.getTicks;

	// Formatting Options
	var numberFormat = d3.format(".0f");
	var decimalFormat = d3.format(".2f");
	var percentFormat = d3.format(".0%");
	var dateFormat = d3.time.format("%Y-%m-%d");
	var shortDate = d3.time.format("%b-%d '%y");
	var longDate = d3.time.format("%B %d, %Y");	

	this.open = function(officeID){
		this.officeID = officeID;
		this.setTiles();
		this.setCharts();
		this.getData();
		this.setBindings();
	}

	this.exit = function(){
		this.unsetCharts();
		this.unsetTiles();
		this.clearData();
		this.unsetBindings();
		this.officeID = null;
	}

	this.update = function(officeID){
		this.officeID = officeID;
		this.unsetCharts();
		this.unsetTiles();
		this.clearData();
		this.setTiles();
		this.setCharts();
		this.getData();
	}

	this.setTiles = function(){
		this.tile0.css({display:"inline-block"}).addClass('full-width half-high main-chart')
			.html("<div class='main-table'><strong class='header absolute'>Seat Capacity</strong>" + 
				"</div><div class='main-areaBrush'></div>");
		this.tile1.css({display:"inline-flex"}).addClass('dc-number')
			.html("<strong class='header absolute'>Average Capacity</strong>");
		this.tile2.css({display:"inline-flex"}).addClass('dc-select-box')
			.html("<strong class='header absolute'>Department</strong>");
		this.tile3.css({display:"inline-flex"}).addClass('dc-select-box')
			.html("<strong class='header absolute'>Map</strong>");
		this.tile4.css({display:"inline-flex"}).addClass('dc-select-box')
			.html("<strong class='header absolute'>Floor</strong>");
		this.tile5.css({display:"inline-flex"}).addClass('dc-select-box')
			.html("<strong class='header absolute'>Suite</strong>");
		this.tile6.css({display:"none"}).html("");
		this.tile7.css({display:"none"}).html("");
		this.tile8.css({display:"none"}).html("");		
		this.tile9.css({display:"none"}).html("");
	}

	this.unsetTiles = function(){
		this.tile0.css({display:"none"}).removeClass("full-width half-high main-chart").html("");
		this.tile1.css({display:"none"}).removeClass("dc-number").html("");
		this.tile2.css({display:"none"}).removeClass("dc-select-box").html("");
		this.tile3.css({display:"none"}).removeClass("dc-select-box").html("");
		this.tile4.css({display:"none"}).removeClass("dc-select-box").html("");
		this.tile5.css({display:"none"}).removeClass("dc-select-box").html("");
		this.tile6.css({display:"none"}).html("");
		this.tile7.css({display:"none"}).html("");
		this.tile8.css({display:"none"}).html("");
		this.tile9.css({display:"none"}).html("");
	}

	this.setCharts = function(){
		this.chart0a = dc.barChart(this.tile0.children('.main-table')[0],this.group);
		this.chart0b = dc.lineChart(this.tile0.children('.main-areaBrush')[0],this.group);
		this.chart1 = dc.numberDisplay(this.tile1[0],this.group);
		this.chart2 = dc.selectMenu(this.tile2[0],this.group);
		this.chart3 = dc.selectMenu(this.tile3[0],this.group);
		this.chart4 = dc.selectMenu(this.tile4[0],this.group);
		this.chart5 = dc.selectMenu(this.tile5[0],this.group);
		//this.chart6 = dc.numberDisplay(this.tile6[0],this.group);
		//this.chart7 = dc.numberDisplay(this.tile7[0],this.group);
		//this.chart8 = dc.numberDisplay(this.tile8[0],this.group);
		//this.chart9 = dc.numberDisplay(this.tile9[0],this.group);
	}

	this.unsetCharts = function(){
		dc.deregisterAllCharts(this.group);
		this.chart0a = null;
		this.chart0b = null;
		this.chart1 = null;
		this.chart2 = null;
		this.chart3 = null;
		this.chart4 = null;
		this.chart5 = null;
		//this.chart6 = null;
		//this.chart7 = null;
		//this.chart8 = null;
		//this.chart9 = null;
	}

	this.getData = function(){
		$.ajax({
			type:"GET",
			url: this.url,
			data: {officeID:this.officeID}
		})
		.then(function(data){
			data = Analytics.formatData(data);
			Analytics.setDataObjects(data);
			Analytics.configureCharts();
			if(!data.length){return;}
			Analytics.renderCharts();
		})
		.catch(function(err){
			console.log(err);
		})
	}	

	this.setDataObjects = function(data){
		this.data = crossfilter(data);

	    // Dimensions and group for main chart
	    this.mainDim = this.data.dimension(function (d) {
	        return d.date;
	    });

	    this.mainGroups = this.mainDim.group().reduce(
	        function (p, v) { /* callback for when data is added to the current filter results */
	            p.capacity += v.capacity;
	            return p;
	        }, /* callback for when data is removed from the current filter results */
	        function (p, v) {
	            p.capacity -= v.capacity;
	            return p;
	        }, /* initialize p */
	        function () {
	            return {
	                capacity: 0
	            };
	        }
	    );

	    // Group for Utilization (no dimension needed since it's a single value)
	    var filters, days, range;
	    this.groupAll = this.data.groupAll().reduce(
	        function (p, v) { /* callback for when data is added to the current filter results */
				filters = Analytics.chart0b.filters();
				days = filters.length ? daysBetween(filters[0][0],filters[0][1]) : daysBetween(Analytics.start,Analytics.end);
	            p.capacity += v.capacity;
	            p.average = p.capacity / days;
	            return p;
	        }, /* callback for when data is removed from the current filter results */
	        function (p, v) {
				filters = Analytics.chart0b.filters();
				days = filters.length ? daysBetween(filters[0][0],filters[0][1]) : daysBetween(Analytics.start,Analytics.end);
	            p.capacity -= v.capacity;
	            p.average = p.capacity / days;
	            return p;
	        },
	        function () { /* initialize p */
	            return {
	                capacity: 0,
	                average: 0
	            };
	        }
	    )

		this.deptDim = this.data.dimension(function (d) {
			return d.department ? d.department : "Unassigned";
		});
		this.deptGroup = this.deptDim.group();

		this.suiteDim = this.data.dimension(function (d) {
			return d.suite ? d.suite : "Other";
		});
		this.suiteGroup = this.suiteDim.group();

		this.floorDim = this.data.dimension(function (d) {
			return d.floor ? d.floor : "Other";
		});
		this.floorGroup = this.floorDim.group();

		this.mapDim = this.data.dimension(function (d) {
			return d.map ? d.map : "Other";
		});
		this.mapGroup = this.mapDim.group();

	}

	this.configureCharts = function(){
		this.chart0a
			.width(1000)
			.height(320)
			.centerBar(true)
			.useViewBoxResizing(true)
			.transitionDuration(1000)
			.margins({top: 20, right: 20, bottom: 20, left: 30})
			.dimension(Analytics.mainDim)
			.mouseZoomable(false)
			.rangeChart(this.chart0b)
			.x(d3.time.scale().domain([this.start,this.end]))
			.xUnits(d3.time.days)
			.elasticY(true)
			.renderHorizontalGridLines(true)
			.legend(dc.legend().x(850).y(-20).itemHeight(13).gap(5))
			.brushOn(false)
			.group(this.mainGroups, 'Seat Capacity')
			.valueAccessor(function (d) { return d.value.capacity; })    
			.title(function (d) {
			     return longDate(d.key) + '\n' +
			     "Seats: " + numberFormat(d.value.capacity);
			})
			.xAxis().tickFormat(shortDate).tickValues(
					function(){
						var filters = Analytics.chart0b.filters();
						if(filters.length){
							var range = filters[0];
							var days = moment.duration(moment.preciseDiff(range[0],range[1],true)).asDays();
							var step = Math.ceil(days/10);
							return getTicks(range[0],range[1],{step:step});
						} else {
							var days = moment.duration(moment.preciseDiff(Analytics.start,Analytics.end,true)).asDays();
							var step = Math.ceil(days/10);
							return getTicks(Analytics.start,Analytics.end,{step:step});
						}
					}
				)

		this.chart0b
			.renderArea(true)
			.width(1000)
			.height(80)
			.useViewBoxResizing(true)
			.mouseZoomable(false)
			.transitionDuration(1000)
			.margins({top: 10, right: 20, bottom: 20, left: 30})
			.dimension(Analytics.mainDim)
			.group(Analytics.mainGroups, 'Seat Capacity')
			.valueAccessor(function (d) {return d.value.capacity;})
			.x(d3.time.scale().domain([this.start,this.end]))
			.elasticY(true)
			.renderHorizontalGridLines(false)
			.round(d3.time.day.round)
			.xUnits(d3.time.days)
			.yAxis().tickValues([]).outerTickSize(0);
		this.chart0b
			.xAxis().tickFormat(shortDate).tickValues(
					function(){
						var days = moment.duration(moment.preciseDiff(Analytics.start,Analytics.end,true)).asDays();
						var step = Math.floor(days/10);
						return getTicks(Analytics.start,Analytics.end,{step:step});
					}
				)

		this.chart1
			.group(this.groupAll)
			.formatNumber(decimalFormat)
			.valueAccessor(function (p) {return p.average;})

		this.chart2
		   	.dimension(this.deptDim)
		   	.group(this.deptGroup)
		   	.multiple(true)
			.title(function (d){return d.key;})

		this.chart3
		   	.dimension(this.mapDim)
		   	.group(this.mapGroup)
		   	.multiple(true)
			.title(function (d){return d.key;})

		this.chart4
		   	.dimension(this.floorDim)
		   	.group(this.floorGroup)
		   	.multiple(true)
			.title(function (d){return d.key;})

		this.chart5
		   	.dimension(this.suiteDim)
		   	.group(this.suiteGroup)
		   	.multiple(true)
			.title(function (d){return d.key;})
	}

	this.refreshData = function(){
		$.ajax({
			type:"GET",
			url: this.url,
			data: {officeID:this.officeID}
		})
		.then(function(data){
			data = Analytics.formatData(data);
			try{
				Analytics.data.remove();
				Analytics.data.add(data);
			} catch (err) {
				console.log(err);
			}
			Analytics.renderCharts();
		})
		.catch(function(err){
			console.log(err);
		})		
	}

	this.clearData = function(){
		this.data = null;
		this.mainDim = null;
		this.mainGroups = null;
		this.groupAll = null;
		this.departmentDim = null;
		this.departmentGroup = null;
		this.mapDim = null;
		this.mapGroup = null;
		this.floorDim = null;
		this.floorGroup = null;
		this.suiteDim = null;
		this.suiteGroup = null;
	}

	this.formatData = function(data){
		var formatted = [];
		this.end = new Date(moment().endOf('day').subtract(12,'h').valueOf());
		this.start = null;
		data.forEach(function(d){
	        d.date = 1 * d.date; // Coerce to number
	        if(Analytics.start){ // Finds the earliest date in the results
	        	Analytics.start = d.date < Analytics.start ? d.date : Analytics.start;
	        } else { Analytics.start = d.date; }
			formatted.push({
				date: new Date(moment(d.date).startOf('day').add(1,'hour').valueOf()),
				map: d.mapName,
				suite: d.suite,
				floor: d.floor,
				capacity: d.capacity,
				department: d.department
			})	      
		})
		return formatted;
	}

	this.renderCharts = function(){
		dc.renderAll(this.group);
	}

	this.setBindings = function(){
		this.resetButton.on('click.'+this.namespace,function(){
			dc.filterAll(Analytics.group);
			dc.redrawAll(Analytics.group);
		})

		this.downloadButton.on('click.'+this.namespace,function(){
		    var data = Analytics.mainDim.top(Infinity);
		    data = data.map(function(d){
		    	var formatted = {
		    		Date: longDate(d.date),
		    		Department: d.department,
		    		Map: d.map,
		    		Suite: d.suite,
		    		Floor: d.floor,
		    		Seats: d.capacity
		    	}
		    	return formatted;
		    })
		    var blob = new Blob([d3.csv.format(data)], {type: "text/csv;charset=utf-8"});
		    saveAs(blob, Analytics.fileName+'.csv');
		})
	}

	this.unsetBindings = function(){
		this.resetButton.off('.'+this.namespace);
		this.downloadButton.off('.'+this.namespace);		
	}
}
$Map.components.OfficeAnalytics.seatCapacityTypeByDay.prototype.constructor = 
	$Map.components.OfficeAnalytics.seatCapacityTypeByDay;

$Map.components.OfficeAnalytics.seatReservationUsageByDay = function(){
	console.log('Loading Seat Reservation Usage By Day')
	// General Parameters
	this.group = 'seatReservationUsageByDay';
	this.namespace = 'seatReservationUsageByDay';
	this.fileName = 'seat_reservation_usage_by_day';
	this.url = '../api/analytics/capacity/seatReservationUsageByDay';

	// Screen Objects
	this.contentWrapper = $("#officeAnalytics");
	this.tile0 = this.contentWrapper.find('.tile-0');
	this.tile1 = this.contentWrapper.find('.tile-1');
	this.tile2 = this.contentWrapper.find('.tile-2');
	this.tile3 = this.contentWrapper.find('.tile-3');
	this.tile4 = this.contentWrapper.find('.tile-4');
	this.tile5 = this.contentWrapper.find('.tile-5');
	this.tile6 = this.contentWrapper.find('.tile-6');
	this.tile7 = this.contentWrapper.find('.tile-7');
	this.tile8 = this.contentWrapper.find('.tile-8');
	this.tile9 = this.contentWrapper.find('.tile-9');
	this.downloadButton = this.contentWrapper.find('.download-btn');
	this.resetButton = this.contentWrapper.find('.reset-btn')

	var Analytics = this;
	var daysBetween = $Map.tools.analytics.daysBetween;
	var getTicks = $Map.tools.analytics.getTicks;

	// Formatting Options
	var numberFormat = d3.format(".0f");
	var decimalFormat = d3.format(".2f");
	var percentFormat = d3.format(".0%");
	var dateFormat = d3.time.format("%Y-%m-%d");
	var shortDate = d3.time.format("%b-%d '%y");
	var longDate = d3.time.format("%B %d, %Y");	

	this.open = function(officeID){
		this.officeID = officeID;
		this.setTiles();
		this.setCharts();
		this.getData();
		this.setBindings();
	}

	this.exit = function(){
		this.unsetCharts();
		this.unsetTiles();
		this.clearData();
		this.unsetBindings();
		this.officeID = null;
	}

	this.update = function(officeID){
		this.officeID = officeID;
		this.unsetCharts();
		this.unsetTiles();
		this.clearData();
		this.setTiles();
		this.setCharts();
		this.getData();
	}

	this.setTiles = function(){
		this.tile0.css({display:"inline-block"}).addClass('full-width half-high main-chart')
			.html("<div class='main-table'><strong class='header absolute'>Reservable Seat Capacity</strong>" + 
				"</div><div class='main-areaBrush'></div>");
		this.tile1.css({display:"inline-flex"}).addClass('dc-number')
			.html("<strong class='header absolute'>Average Utilization</strong>");
		this.tile2.css({display:"inline-flex"}).addClass('dc-select-box')
			.html("<strong class='header absolute'>Weekday</strong>");
		this.tile3.css({display:"inline-flex"}).addClass('dc-select-box')
			.html("<strong class='header absolute'>Department</strong>");
		this.tile4.css({display:"inline-flex"}).addClass('dc-select-box')
			.html("<strong class='header absolute'>Seat</strong>");
		this.tile5.css({display:"inline-flex"}).addClass('dc-select-box')
			.html("<strong class='header absolute'>Floor</strong>");
		this.tile6.css({display:"inline-flex"}).addClass('dc-select-box')
			.html("<strong class='header absolute'>Suite</strong>");
		this.tile7.css({display:"none"}).html("");
		this.tile8.css({display:"none"}).html("");		
		this.tile9.css({display:"none"}).html("");
	}

	this.unsetTiles = function(){
		this.tile0.css({display:"none"}).removeClass("full-width half-high main-chart").html("");
		this.tile1.css({display:"none"}).removeClass("dc-number").html("");
		this.tile2.css({display:"none"}).removeClass("dc-select-box").html("");
		this.tile3.css({display:"none"}).removeClass("dc-select-box").html("");
		this.tile4.css({display:"none"}).removeClass("dc-select-box").html("");
		this.tile5.css({display:"none"}).removeClass("dc-select-box").html("");
		this.tile6.css({display:"none"}).removeClass("dc-select-box").html("");
		this.tile7.css({display:"none"}).html("");
		this.tile8.css({display:"none"}).html("");
		this.tile9.css({display:"none"}).html("");
	}

	this.setCharts = function(){
		this.chart0a = dc.barChart(this.tile0.children('.main-table')[0],this.group);
		this.chart0b = dc.lineChart(this.tile0.children('.main-areaBrush')[0],this.group);
		this.chart1 = dc.numberDisplay(this.tile1[0],this.group);
		this.chart2 = dc.selectMenu(this.tile2[0],this.group);
		this.chart3 = dc.selectMenu(this.tile3[0],this.group);
		this.chart4 = dc.selectMenu(this.tile4[0],this.group);
		this.chart5 = dc.selectMenu(this.tile5[0],this.group);
		this.chart6 = dc.selectMenu(this.tile6[0],this.group);
		//this.chart7 = dc.numberDisplay(this.tile7[0],this.group);
		//this.chart8 = dc.numberDisplay(this.tile8[0],this.group);
		//this.chart9 = dc.numberDisplay(this.tile9[0],this.group);
	}

	this.unsetCharts = function(){
		dc.deregisterAllCharts(this.group);
		this.chart0a = null;
		this.chart0b = null;
		this.chart1 = null;
		this.chart2 = null;
		this.chart3 = null;
		this.chart4 = null;
		this.chart5 = null;
		this.chart6 = null;
		//this.chart7 = null;
		//this.chart8 = null;
		//this.chart9 = null;
	}

	this.getData = function(){
		$.ajax({
			type:"GET",
			url: this.url,
			data: {officeID:this.officeID}
		})
		.then(function(data){
			data = Analytics.formatData(data);
			Analytics.setDataObjects(data);
			Analytics.configureCharts();
			if(!data.length){return;}
			Analytics.renderCharts();
		})
		.catch(function(err){
			console.log(err);
		})
	}	

	this.setDataObjects = function(data){
		this.data = crossfilter(data);

	    // Dimensions and group for main chart
	    this.mainDim = this.data.dimension(function (d) {
	        return d.date;
	    });

	    this.mainGroups = this.mainDim.group().reduce(
	        function (p, v) { /* callback for when data is added to the current filter results */
	            p.total += v.available;
	            p.used += v.used;
	            p.available += (v.available - v.used);
	            p.average = p.total ? p.used / (p.total) : 0;
	            return p;
	        }, /* callback for when data is removed from the current filter results */
	        function (p, v) {
	            p.total -= v.available;
	            p.available -= (v.available - v.used);
	            p.used -= v.used;
	            p.average = p.total ? p.used / (p.total) : 0;
	            return p;
	        }, /* initialize p */
	        function () {
	            return {
	                total: 0,
	                available: 0,
	                used: 0,
	                average: 0
	            };
	        }
	    );

	    // Group for Utilization (no dimension needed since it's a single value)
	    var filters, days, range;
	    this.groupAll = this.data.groupAll().reduce(
	        function (p, v) { /* callback for when data is added to the current filter results */
	            p.total += v.available;
	            p.used += v.used;
	            p.available += (v.available - v.used);
	            p.average = p.total ? p.used / (p.total) : 0;
	            return p;
	        }, /* callback for when data is removed from the current filter results */
	        function (p, v) {
	            p.total -= v.available;
	            p.available -= (v.available - v.used);
	            p.used -= v.used;
	            p.average = p.total ? p.used / (p.total) : 0;
	            return p;
	        },
	        function () { /* initialize p */
	            return {
	                total: 0,
	                available: 0,
	                used: 0,
	                average: 0
	            };
	        }
	    )

		this.weekdayDim = this.data.dimension(function (d) {
			return moment(d.date).format('dddd');
		});
		this.weekdayGroup = this.weekdayDim.group();

		this.departmentDim = this.data.dimension(function (d) {
			return d.department;
		});
		this.departmentGroup = this.departmentDim.group();

		this.seatDim = this.data.dimension(function (d) {
			return d.seat ? d.seat : "Other";
		});
		this.seatGroup = this.seatDim.group();

		this.suiteDim = this.data.dimension(function (d) {
			return d.suite ? d.suite : "Other";
		});
		this.suiteGroup = this.suiteDim.group();

		this.floorDim = this.data.dimension(function (d) {
			return d.floor ? d.floor : "Other";
		});
		this.floorGroup = this.floorDim.group();

	}

	this.configureCharts = function(){
		this.chart0a
			.width(1000)
			.height(320)
			.centerBar(true)
			.useViewBoxResizing(true)
			.transitionDuration(1000)
			.margins({top: 20, right: 20, bottom: 20, left: 30})
			.dimension(Analytics.mainDim)
			.mouseZoomable(false)
			.rangeChart(this.chart0b)
			.x(d3.time.scale().domain([this.start,this.end]))
			.xUnits(d3.time.days)
			.elasticY(true)
			.renderHorizontalGridLines(true)
			.legend(dc.legend().x(850).y(-20).itemHeight(13).gap(5))
			.brushOn(false)
			.group(this.mainGroups, 'Reserved')
			.valueAccessor(function (d) { return d.value.used; })
			.stack(this.mainGroups, 'Unused', function (d) {return d.value.available;})  
			.title(function (d) {
	             return dateFormat(d.key) + '\n' +
	             "Available Capacity: " + numberFormat(d.value.used + d.value.available) + '\n' +
	             "Reserved Hours: " + numberFormat(d.value.used) + '\n' +
	             "Unused Hours: " + numberFormat(d.value.available) + '\n' +
	             "Utilization: " + numberFormat(((d.value.used / (d.value.used + d.value.available))) * 100) + "%"
			})
			.xAxis().tickFormat(shortDate).tickValues(
					function(){
						var filters = Analytics.chart0b.filters();
						if(filters.length){
							var range = filters[0];
							var days = moment.duration(moment.preciseDiff(range[0],range[1],true)).asDays();
							var step = Math.ceil(days/10);
							return getTicks(range[0],range[1],{step:step});
						} else {
							var days = moment.duration(moment.preciseDiff(Analytics.start,Analytics.end,true)).asDays();
							var step = Math.ceil(days/10);
							return getTicks(Analytics.start,Analytics.end,{step:step});
						}
					}
				)

		this.chart0b
			.renderArea(true)
			.width(1000)
			.height(80)
			.useViewBoxResizing(true)
			.mouseZoomable(false)
			.transitionDuration(1000)
			.margins({top: 10, right: 20, bottom: 20, left: 30})
			.dimension(Analytics.mainDim)
			.group(Analytics.mainGroups, 'Utilization')
			.valueAccessor(function (d) {return d.value.average;})
			.x(d3.time.scale().domain([this.start,this.end]))
			.elasticY(true)
			.renderHorizontalGridLines(false)
			.round(d3.time.day.round)
			.xUnits(d3.time.days)
			.yAxis().tickValues([]).outerTickSize(0);
		this.chart0b
			.xAxis().tickFormat(shortDate).tickValues(
					function(){
						var days = moment.duration(moment.preciseDiff(Analytics.start,Analytics.end,true)).asDays();
						var step = Math.floor(days/10);
						return getTicks(Analytics.start,Analytics.end,{step:step});
					}
				)

		this.chart1
			.group(this.groupAll)
			.valueAccessor(function (p) {return p.average;})
			.formatNumber(d3.format(".2%"));

		this.chart2
           	.dimension(this.weekdayDim)
           	.group(this.weekdayGroup)
           	.multiple(true)
           	.title(function(d){return d.key;})

		this.chart3
           	.dimension(this.departmentDim)
           	.group(this.departmentGroup)
           	.multiple(true)
           	.title(function(d){return d.key;})	

		this.chart4
           	.dimension(this.seatDim)
           	.group(this.seatGroup)
           	.multiple(true)
           	.title(function(d){return d.key;})

		this.chart5
           	.dimension(this.floorDim)
           	.group(this.floorGroup)
           	.multiple(true)
           	.title(function(d){return d.key;})

		this.chart6
           	.dimension(this.suiteDim)
           	.group(this.suiteGroup)
           	.multiple(true)
           	.title(function(d){return d.key;})
	}

	this.refreshData = function(){
		$.ajax({
			type:"GET",
			url: this.url,
			data: {officeID:this.officeID}
		})
		.then(function(data){
			data = Analytics.formatData(data);
			try{
				Analytics.data.remove();
				Analytics.data.add(data);
			} catch (err) {
				console.log(err);
			}
			Analytics.renderCharts();
		})
		.catch(function(err){
			console.log(err);
		})		
	}

	this.clearData = function(){
		this.data = null;
		this.mainDim = null;
		this.mainGroups = null;
		this.groupAll = null;
		this.weekdayDim = null;
		this.weekdayGroup = null;		
		this.departmentDim = null;
		this.departmentGroup = null;
		this.seatDim = null;
		this.seatGroup = null;
		this.floorDim = null;
		this.floorGroup = null;
		this.suiteDim = null;
		this.suiteGroup = null;
	}

	this.formatData = function(data){
		var formatted = [];
		this.end = new Date(moment().endOf('day').subtract(12,'h').valueOf());
		this.start = null;
		data.forEach(function(d){
	        d.date = 1 * d.date; // Coerce to number
	        if(Analytics.start){ // Finds the earliest date in the results
	        	Analytics.start = d.date < Analytics.start ? d.date : Analytics.start;
	        } else { Analytics.start = d.date; }
			formatted.push({
				date: new Date(moment(d.d).startOf('day').valueOf()),
				suite: d.st,
				floor: d.f,
				seat: d.sn,
				available: d.a,
				used: d.u,
				department: d.dpt
			})  	      
		})
		return formatted;
	}

	this.renderCharts = function(){
		dc.renderAll(this.group);
	}

	this.setBindings = function(){
		this.resetButton.on('click.'+this.namespace,function(){
			dc.filterAll(Analytics.group);
			dc.redrawAll(Analytics.group);
		})

		this.downloadButton.on('click.'+this.namespace,function(){
		    var data = Analytics.mainDim.top(Infinity);
		    data = data.map(function(d){
		    	var formatted = {
		    		Date: longDate(d.date),
		    		Department: d.department,
		    		Map: d.map,
		    		Suite: d.suite,
		    		Floor: d.floor,
		    		Seats: d.capacity
		    	}
		    	return formatted;
		    })
		    var blob = new Blob([d3.csv.format(data)], {type: "text/csv;charset=utf-8"});
		    saveAs(blob, Analytics.fileName+'.csv');
		})
	}

	this.unsetBindings = function(){
		this.resetButton.off('.'+this.namespace);
		this.downloadButton.off('.'+this.namespace);		
	}
}
$Map.components.OfficeAnalytics.seatReservationUsageByDay.prototype.constructor = 
	$Map.components.OfficeAnalytics.seatReservationUsageByDay;


$Map.tools = $Map.tools || {};
$Map.tools.analytics = $Map.tools.analytics || {};

$Map.tools.analytics.getTicks = function(start,end,options){
	options = options || {};
	var type = options.type || "step"; // types are step and number
	var step = options.step || 1;
	var number = options.number || 2;
	start = moment(start);
	end = moment(end);
	var result = [];
	if(type == 'step'){
		result.push(start.toDate());
		while(true){
			start.add(step,'days');
			if(start <= end){
				result.push(start.toDate());
			} else {
				break;
			}
		}
	}
	return result;
}

$Map.tools.analytics.daysBetween = function(start,end){
	start = moment(start).startOf('day');
	end = moment(end).startOf('day');
	var duration = moment.preciseDiff(start,end,true);
	return Math.floor(moment.duration(duration).asDays());
}