//#################################  Math Helper Functions #####################################################

// This function takes in the center points of a circle with a given radius, and an angle
// along the circle (in degrees).  It returns the location of that point along the circle
// in cartesian coordinates.
function polarToCartesian(centerX, centerY, radius, angleInDegrees) {
  var angleInRadians = (angleInDegrees) * Math.PI / 180.0;
  return {
    x: centerX + (radius * Math.cos(angleInRadians)),
    y: centerY - (radius * Math.sin(angleInRadians))
  };
}



function formatNearOrFar(targetMoment){
  var now = moment();
  if(targetMoment.dayOfYear() == now.dayOfYear() && targetMoment.year() == now.year()){
      return targetMoment.format('h:mm a');
  } else {
      return targetMoment.format('MM/DD/YY h:mm a');
  }  
}

// This function creates an empty iframe within an existing div or similar block object
// The iframe has the same size as its container and triggers a callback when the size
// of the parent changes.  This is used to listen for changes in the size of a div, even
// where the overall document/window size doesn't change.
function _attach(id,offset,cb) {
    // There is no `resize` event for elements, so to trigger this effect,
    // create an empty HTML document using an <iframe> which will issue a
    // resize event inside itself when the document resizes. Since it is
    // 100% x 100% that will occur whenever the host element is resized.
    var that = this;
    var obj = $('<iframe/>')
      .css( {
        position: 'absolute',
        top: 0,
        left: 0,
        height: '100%',
        width: '100%',
        zIndex: -1,
        border: 0
      } )
      .attr( 'frameBorder', '0' )
      .attr( 'src', 'about:blank' )
      .attr( 'id', id );

    obj[0].onload = function () {
      var body = this.contentDocument.body;
      var height = body.offsetHeight;
      var contentDoc = this.contentDocument;
      var defaultView = contentDoc.defaultView || contentDoc.parentWindow;
      
      defaultView.onresize = function () {
        // Three methods to get the iframe height, to keep all browsers happy
        var newHeight = body.clientHeight || body.offsetHeight;
        var docClientHeight = contentDoc.documentElement.clientHeight;

        if ( ! newHeight && docClientHeight ) {
          newHeight = docClientHeight;
        }

        if ( newHeight !== height ) {
          height = newHeight;
          cb(height-offset);
        }
      };
    };

    obj
      .appendTo( $(this.table().container()).parent())
      .attr( 'data', 'about:blank' );
  }


function renderLength(inches,options){ // Takes in measurements in inches, returns a formatted measure based on options
  options = options || {};
  var system = options.system || "US";
  var decimal = options.decimal || system == "Metric" ? 2 : 0;
  var inchesAndFeet = options.inchesAndFeet || true;
  var commaSeparators = options.commaSeparators || true;
  var cm = options.cm || false;
  switch(system){
    case "US":
      if(inchesAndFeet){
        return formatInches(inches,decimal,commaSeparators)
      } else {
        if(commaSeparators){
          return numberWithCommas(round(inches,decimal));
        } else {
          return round(inches,decimal);
        }
      }
    break;
    case "Metric":
      var meters = inchesToMeters(inches);
      if(cm){
        if(commaSeparators){
          return numberWithCommas(round(meters * 100,decimal))+" cm";
        } else {
          return round(meters * 100,decimal)+" cm";
        }
      } else {
        if(commaSeparators){
          return numberWithCommas(round(meters,decimal))+" m";
        } else {
          return round(meters,decimal)+" m";
        }
      }
    break;
  }
}

var lengthParse = /([+\-])?((?:\d+\/|(?:\d+|^|\s)\.)?\d+)\s*([^\s\d+\-.,:;^\/]+(?:\^\d+(?:$|(?=[\s:;\/])))?(?:\/[^\s\d+\-.,:;^\/]+(?:\^\d+(?:$|(?=[\s:;\/])))?)*)?/g;
var testForAlpha = /^[A-z]+$/g;

function parseToInches(string,optObj){ // Requires the plug-in jq-quantities to be installed
  var options = optObj || {};
  var defaultUnit = options.defaultUnit || 'inches';
  var numParsed,numHolder,unitHolder;
  var stringArray = string.match(lengthParse);
  var strLen = stringArray.length;
  var scalar = 0;
  for(var i = 0;i<strLen;i++){
    try{
      scalar += Qty(stringArray[i]).to('inches').toPrec('.01 in').scalar;
    } catch(err){
      numParsed = lengthParse.exec(stringArray[i]);
      if(!testForAlpha.test(numParsed[2])){
          numHolder = eval(numParsed[2]);
          unitHolder = numParsed[3] || defaultUnit;
          scalar += Qty(numHolder+unitHolder).to('inches').toPrec('.01 in').scalar;
      } else{
          return(err);
      }         
    }
  }
  return scalar; // returns a scalar value in inches;
}

function formatSqInchesLabel(sqInches){
  return numberWithCommas(sqInches)+" ft"+"2".sup()
}

function copyPoint(point){
  return {x:point.x,y:point.y};
}

function renderArea(sqInches,optObj){
  var options = optObj || {};
  var system = options.system || "US";
  var svgRender = options.svg || false;
  var decimal = options.decimal || 0;
  var commaSeparators = options.commaSeparators || true;	
  var cm = options.cm || false;
  var area;
	var areaText = "";
	var suffix = "";

	switch(system){
		case "US":
		    if((sqInches%144) == 0){area = sqInches/144;} 
		    else {area = (sqInches/144).toFixed(decimal);}	
		    if(svgRender){
				suffix = " sq.ft.";
		    } else {
		    	suffix = " ft"+"2".sup();
		    }
		break;
		case "Metric":
        area = (sqInches * 0.00064516).toFixed(decimal);
        if(svgRender){
        suffix = " sq.m.";
        } else {
          suffix = " m"+"2".sup();
        }
		break;
	}
	if(commaSeparators){
		areaText = numberWithCommas(area)+suffix;
	} else {
		areaText = area+suffix;
	}
	return areaText;
}

function formatSqInches(inches){ // returns square feet
    if((inches%144) == 0){return inches/144;} 
    else {return (inches/144).toFixed(2);}
}

function round(value, decimals) {
  return Number(Math.round(value+'e'+decimals)+'e-'+decimals);
}

function roundPoint(point,optObj){
  var options = optObj || {};
  var decimals = options.decimals || 5;
  return {x:Number(Math.round(point.x+'e'+decimals)+'e-'+decimals),y:Number(Math.round(point.y+'e'+decimals)+'e-'+decimals)}
}

function formatInches(inches,decimals,commas){
    decimals = decimals || 0;
    commas = commas || true;
    var rounded = round(inches,decimals);
    var feet = Math.floor(rounded/12);
    var inches = round(rounded%12,decimals);
    if(commas){
      return numberWithCommas(feet)+"' "+inches+'"';
    } else {
      return feet+"' "+inches+'"';
    }
}

function numberWithCommas(x) {
    var parts = x.toString().split(".");
    parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ",");
    return parts.join(".");
}

function parseFeetInches(measure){
    var rex = /^(\d+)'(\d+)(?:''|")$/;
    var match = rex.exec(measure);
    var feet, inch;
    if (match) {
        feet = parseInt(match[1], 10);
        inch = parseInt(match[2], 10);
        return feet*12 + inch;
    } else {
        return measure;
    }
}

function inchesToMeters(inches){
    return inches/39.37007874;
}

function meterToInches(meters){
    return meters * 39.37007874;
}


function makePositiveAngle(angle){
  if(angle < 0){
    return angle + 2*Math.PI;
  }
  return angle;
}

function toPercent(num,dec){
  return numberWithCommas((num*100).toFixed(dec)) + "%";
}

function findAngle(intersect,point1,point2){
  vector1 = {
    x: point1.x - intersect.x,
    y: intersect.y - point1.y,
  }
  vector1.mag = Math.sqrt(Math.pow(vector1.x,2)+Math.pow(vector1.y,2));
  vector2 = {
    x: point2.x - intersect.x,
    y: intersect.y - point2.y
  }
  vector2.mag = Math.sqrt(Math.pow(vector2.x,2)+Math.pow(vector2.y,2));
  var dotProduct = vector1.x * vector2.x + vector1.y * vector2.y;
  var cosRatio = dotProduct / (vector1.mag*vector2.mag);
  return Math.acos(cosRatio);
}

function checkAcute(intersect,point1,point2){
  var angle = findAngle(intersect,point1,point2);
  console.log(angle)
  return Math.abs(angle) < Math.PI/2;
}

function generateUUID(){
    var d = $.now();
    var uuid = 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
        var r = (d + Math.random()*16)%16 | 0;
        d = Math.floor(d/16);
        return (c=='x' ? r : (r&0x3|0x8)).toString(16);
    });
    return uuid;
}

function getSeconds(str) {
  var seconds = 0;
  var days = str.match(/(\d+)\s*d/);
  var hours = str.match(/(\d+)\s*h/);
  var minutes = str.match(/(\d+)\s*m/);
  if (days) { seconds += parseInt(days[1])*86400; }
  if (hours) { seconds += parseInt(hours[1])*3600; }
  if (minutes) { seconds += parseInt(minutes[1])*60; }
  return seconds;
}

function formatDuration(seconds){
  seconds = Math.floor(Math.abs(seconds)); // normalize the value
  var sec, minutes, hours, days, durString;
  
  sec = seconds % 60;
  seconds -= sec;
  minutes = seconds % 3600;
  seconds -= minutes;
  hours = seconds % 86400;
  seconds -= hours;

  days = seconds / 86400;
  hours = hours / 3600;
  minutes = minutes / 60;

  durString = '';
  if(days){
    if(days > 1){
      durString = days + " days ";
    } else {
      durString = days + " day ";
    }
  }
  if(hours){
    if(hours > 1){
      durString += hours + " hours ";
    } else {
      durString += hours + " hour ";
    }    
  }
  if(minutes){
    if(minutes > 1){
      durString += minutes + " minutes ";
    } else {
      durString += minutes + " minute ";
    }    
  }
  return durString
}

function isNumeric( obj ) {
    return !jQuery.isArray( obj ) && (obj - parseFloat( obj ) + 1) >= 0;
}

// Probably don't need as it pulls the calculation from a DOM object
function polyAreaDOM(poly){
    var area = 0;
    var pts = poly.points;
    console.log("pts:"+pts);
    var len = pts.numberOfItems;
    console.log("len:"+len);
    for(var i=0;i<len;++i){
        var p1 = pts.getItem(i);
        console.log("p1x:"+p1.x);
        console.log("p1y:"+p1.y);
        var p2 = pts.getItem((i+len-1)%len);
        area += (p2.x+p1.x) * (p2.y-p1.y);
    }
    return Math.abs(area/2);
}

// finds area of a polygon defined by the ordered point list
// does not check to see if it is a valid polygon
function polyArea(pointList){
  var area = 0;
  var len = pointList.length;
  for(var i = 0;i < len; i++){
      var p1 = pointList[i];
      var p2 = pointList[(i+len-1)%len];
      area += (p2.x+p1.x)*(p2.y-p1.y);
  }
  return Math.abs(area/2);
}

function contains(a, obj) {
    for (var i = 0; i < a.length; i++) {
        if (a[i] === obj) {
            return true;
        }
    }
    return false;
}

// checks to see if a point is inside a polygon defined by a set of ordered points
function inside(point, vs) {
    // ray-casting algorithm based on
    // http://www.ecse.rpi.edu/Homepages/wrf/Research/Short_Notes/pnpoly.html
    
    var x = point.x
    var y = point.y;
    
    var inside = false;
    var length = vs.length;
    for (var i = 0, j = length - 1; i < length; j = i++) {
        var xi = vs[i].x, yi = vs[i].y;
        var xj = vs[j].x, yj = vs[j].y;
        
        var intersect = ((yi > y) != (yj > y))
            && (x < (xj - xi) * (y - yi) / (yj - yi) + xi);
        if (intersect) inside = !inside;
    }
    
    return inside;
};

// checks to see if any point is inside the poly
function pointInside(point, poly) {
    // ray-casting algorithm based on
    // http://www.ecse.rpi.edu/Homepages/wrf/Research/Short_Notes/pnpoly.html
    point = Array.isArray(point) ? point : [point];
    var pointLength = point.length;
    var polyLength = poly.length;
    var x;
    var y;
   
    var inside = false;
    for(var k = 0;k < pointLength;k++){
      x = point[k].x
      y = point[k].y;      
      for (var i = 0, j = polyLength - 1; i < polyLength; j = i++) {
          var xi = poly[i].x, yi = poly[i].y;
          var xj = poly[j].x, yj = poly[j].y;
          
          var intersect = ((yi > y) != (yj > y))
              && (x < (xj - xi) * (y - yi) / (yj - yi) + xi);
          if (intersect) inside = !inside;
      }
      if(inside){return true;}
    }
    return inside;
};

// checks to see if any of a set of points (poly1) fit within a polygon defined as a set of points (poly2)
// poly1 doesn't have to be a polygon, just a set of points
// returns whether a point is inside or not, and if so, returns as a second object in array the index of the
// first point found inside
function polyInside(poly1, poly2) {
    // ray-casting algorithm based on
    // http://www.ecse.rpi.edu/Homepages/wrf/Research/Short_Notes/pnpoly.html
    var poly1Length = poly1.length;
    var poly2Length = poly2.length;
    var x;
    var y;
   
    var inside = false;
    for(var k = 0;k < poly1Length;k++){
      x = poly1[k].x
      y = poly1[k].y;      
      for (var i = 0, j = poly2Length - 1; i < poly2Length; j = i++) {
          var xi = poly2[i].x, yi = poly2[i].y;
          var xj = poly2[j].x, yj = poly2[j].y;
          
          var intersect = ((yi > y) != (yj > y))
              && (x < (xj - xi) * (y - yi) / (yj - yi) + xi);
          if (intersect) inside = !inside;
      }
      if(inside){return [true,k];}
    }
    return [inside];
};



function fullyInside(poly1, poly2) { // Checks to see if poly1 is entirely within poly2
    // ray-casting algorithm based on
    // http://www.ecse.rpi.edu/Homepages/wrf/Research/Short_Notes/pnpoly.html
    var poly1Length = poly1.length;
    var poly2Length = poly2.length;
    var x;
    var y;
    var inside;
    for(var k = 0;k < poly1Length;k++){
      inside = false;
      x = poly1[k].x
      y = poly1[k].y;      
      for (var i = 0, j = poly2Length - 1; i < poly2Length; j = i++) {
          var xi = poly2[i].x, yi = poly2[i].y;
          var xj = poly2[j].x, yj = poly2[j].y;
          
          var intersect = ((yi > y) != (yj > y))
              && (x < (xj - xi) * (y - yi) / (yj - yi) + xi);
          if (intersect) inside = !inside;
      }
      if(!inside){return false;}
    }
    return true;
};

function pointInBox(box,point){
    // box should be an object with a top,bottom,left,right value - javascript coords such that y value is inverted
    // point is an object with an x and y value
    return !(point.x > box.right || 
           point.x < box.left || 
           point.y > box.bottom ||
           point.y < box.top);
    }


function toRads(val){
    return val * (Math.PI/180);
}

function toDeg(val){
    return val * (180/Math.PI)
}



function throttle(fn, threshhold, returnThis) {
  threshhold || (threshhold = 250);
  var last;
  var deferTimer;
  return function () {
    var context = this;

    var now = +new Date,
        args = arguments;
    if (last && now < last + threshhold) {
      // hold on to it
      clearTimeout(deferTimer);
      deferTimer = setTimeout(function () {
        last = now;
        fn.apply(context, args);
      }, threshhold);
    } else {
      last = now;
      fn.apply(context, args);
    }
    return returnThis;
  };
}

//$('body').on('mousemove', throttle(function (event) {
//  console.log('tick');
//}, 1000));

// http://remysharp.com/2010/07/21/throttling-function-calls/

function debounce(fn, delay) {
  var timer = null;
  return function () {
    var context = this, args = arguments;
    clearTimeout(timer);
    timer = setTimeout(function () {
      fn.apply(context, args);
    }, delay);
    return false;
  };
}

//$('input.username').keypress(debounce(function (event) {
  // do something
//}, 250))


function isNumeric(n) {
  return !isNaN(parseFloat(n)) && isFinite(n);
}


function anglesCollinear(angle1,angle2){ // Checks to see if two angles are collinear, returns result
  return round((angle1%Math.PI + angle2%Math.PI)%Math.PI,10) == 0;
}


// convert 0..255 R,G,B values to a hexidecimal color string
RGBToHex = function(r,g,b){
    var bin = r << 16 | g << 8 | b;
    return (function(h){
        return new Array(7-h.length).join("0")+h
    })(bin.toString(16).toUpperCase())
}

// convert a hexidecimal color string to 0..255 R,G,B
hexToRGB = function(hex){
    var r = hex >> 16;
    var g = hex >> 8 & 0xFF;
    var b = hex & 0xFF;
    return [r,g,b];
}

function stringSplice(string,index,number,insert){
    return string.slice(0,index) + insert + string.slice(index+number);
}

// Converts RGB to hex
function rgb2hex(rgb) {
    if (rgb === undefined) return rgb;
    if (/^#[0-9A-F]{6}$/i.test(rgb)) return rgb;

    rgb = rgb.match(/^rgb\((\d+),\s*(\d+),\s*(\d+)\)$/);
    function hex(x) {
        return ("0" + parseInt(x).toString(16)).slice(-2);
    }
    return "#" + hex(rgb[1]) + hex(rgb[2]) + hex(rgb[3]);
}

function snapround(number,resolution){
    return Math.round(number / resolution)*resolution;  
}


// Returns a vector for the line between two parallel line segements
function parallelSegmentsProjection(seg1,seg2){
  var diffVector = {x:seg1.start.x-seg2.start.x,y:seg1.start.y-seg2.start.y};
  var seg1Vector = {x:seg1.start.x-seg1.end.x,y:seg1.start.y-seg1.end.y};
  var seg1MagSquared = Math.pow(getLength(seg1.start,seg1.end),2);
  var projStep1 = (seg1Vector.x*diffVector.x + seg1Vector.y*diffVector.y)/seg1MagSquared;
  var projStep2 = {x:seg1Vector.x * projStep1,y:seg1Vector.y*projStep1};
  var projStep3 = {x:diffVector.x - projStep2.x,y:diffVector.y - projStep2.y};
  return projStep3;
}

// Finds the shortest distance between a point and a line segment as well as the point on the line segment closest to the point
function pDistance(point,line) {
  var xx, yy;
  var start = line.start;
  var end = line.end;
  var A = point.x - start.x;
  var B = point.y - start.y;
  var C = end.x - start.x;
  var D = end.y - start.y;
  var dot = A * C + B * D;
  var len_sq = C * C + D * D;
  var param = -1;
  if (len_sq != 0) param = dot / len_sq; //in case of 0 length line
  if (param < 0) {
    xx = start.x;
    yy = start.y;
  } else if (param > 1) {
    xx = end.x;
    yy = end.y;
  } else {
    xx = start.x + param * C;
    yy = start.y + param * D;
  }
  var dx = point.x - xx;
  var dy = point.y - yy;
  return {dist:Math.sqrt(dx * dx + dy * dy),dx:dx,dy:dy,x:xx,y:yy};
}

// Finds the point of intersection (if any exists) between two line segments
// Line segments have the following format: {start:{x:val,y:val},end:{x:val,y:val}}
function getSegmentIntersection(line1,line2){
  var p0x = line1.start.x;
  var p0y = line1.start.y;
  var p1x = line1.end.x;
  var p1y = line1.end.y;
  var p2x = line2.start.x;
  var p2y = line2.start.y;
  var p3x = line2.end.x;
  var p3y = line2.end.y;  
  var ix,iy;
  var s1x = p1x - p0x;
  var s1y = p1y - p0y;
  var s2x = p3x - p2x;
  var s2y = p3y - p2y;
  var s = (-s1y * (p0x - p2x) + s1x * (p0y - p2y)) / (-s2x * s1y + s1x * s2y);
  var t = ( s2x * (p0y - p2y) - s2y * (p0x - p2x)) / (-s2x * s1y + s1x * s2y);
    
  if (s >= 0 && s <= 1 && t >= 0 && t <= 1){
    // Collision/intersection detected
    ix = p0x + (t * s1x);
    iy = p0y + (t * s1y);
    return {x:ix,y:iy};
  }

  return null; // No collision

}

// Finds the closest point on any set of line segments to an arbitrary starting point
// point is an object with an x and y value and represents the starting point to be measured against
// segmentObj is an object containing arrays of line segments.  The key/index of the segment object
// is an identifier for the object being represented by the array of segments (presumed to be an outline)
// The goal is to return the objectID with the segment closest to the point, along with the segment values
// themselves and the point along the segment which is closest.
function closestSegment(point,segmentObj){
  var closestDist = null;
  var closestSegment = null;
  var closestPoint = null;
  var closestObj = null;
  var keys = Object.keys(segmentObj);
  var len = keys.length;
  var objLen;
  var currentObj,currentLine,results;
  for(var i = 0;i < len; i++){
    currentObj = segmentObj[keys[i]]; // should be an array of line segments [{start:{x:val,y:val},end:{x:val,y:val}},...]
    objLen = currentObj.length;
    for(var j = 0; j < objLen; j++){
      currentLine = currentObj[j];
      results = pDistance(point,currentLine);
      if(results.dist < closestDist || closestDist == null){
        closestDist = results.dist;
        closestSegment = currentLine;
        closestPoint = {x:results.x,y:results.y};
        closestObj = keys[i];
      }
    }
  }
  return {
    dist:closestDist,
    segment: closestSegment,
    point: closestPoint,
    objID: closestObj
  }
}

function closestIntersectingSegment(currentPoint,currentSeg,currentSegID,segmentObj,cornerPoints){
  var intersecting = [];
  var keys = Object.keys(segmentObj);
  var len = keys.length;
  var objLen;
  var currentObj,currentLine,results;
  for(var i = 0;i < len; i++){
    currentObj = segmentObj[keys[i]]; // should be an array of line segments [{start:{x:val,y:val},end:{x:val,y:val}},...]
    objLen = currentObj.length;
    for(var j = 0; j < objLen; j++){
      currentLine = currentObj[j];
      if(keys[i] == currentSegID){
        if(sameSegment(currentSeg,currentLine)){
          continue; // skips this segment if it is the current segment
        }
      }
      results = getSegmentIntersection(currentSeg,currentLine);
      if(results != null){
          if(checkArrayForPoint({x:results.x,y:results.y},cornerPoints)){
            continue;
          }
        intersecting.push({segment:currentLine,objID:keys[i],intersection:{x:results.x,y:results.y}});
      }
    }
  }

  var prevSegmentObj = segmentObj[currentSegID];
  var closestDist = null;
  var closestSegment = null;
  var closestPoint = null;
  var closestObjID = null;
  len = intersecting.length;
  for(var i = 0;i < len; i++){
    currentLine = intersecting[i];
    results = getLength(currentPoint,currentLine.intersection);
    if(results <= closestDist || closestDist == null){
      if(results == closestDist){
        if(closestObjID == currentSegID){ // Gives a preference for moving onto a new object
          closestDist = results;
          closestSegment = currentLine.segment;
          closestPoint = currentLine.intersection;
          closestObjID = currentLine.objID;
        } else {
           if(hasSameSegment(closestSegment,prevSegmentObj)){
              closestDist = results;
              closestSegment = currentLine.segment;
              closestPoint = currentLine.intersection;
              closestObjID = currentLine.objID;
           }
          continue;
        }
      }
      closestDist = results;
      closestSegment = currentLine.segment;
      closestPoint = currentLine.intersection;
      closestObjID = currentLine.objID;
    }
  }

  return {dist:closestDist,segment:closestSegment,point:closestPoint,objID:closestObjID};
}


// This is much like the closestIntersectingSegment function, but with the difference that it filters out segment
// intersections that cross over a segment from the previous object.  This is primarily used where the current
// point is at an intersection between two objects.  At that intersection, you may have two directions to look
// for the next segment intersection.  One of those directions (the one you wont want to take) will have an intersection
// between the current object and the previous object.  By filtering out those intersections.
// Basically, we want to make sure the segment/intersection is not with the previousSegID or falls within the previous object
function closestIntersectingSegmentWithoutRecross(currentPoint,currentSeg,currentSegID,previousSeg,previousSegID,segmentObj,cornerPoints){
    var intersecting = [];
    var keys = Object.keys(segmentObj);
    var len = keys.length;
    var objLen;
    var currentObj,currentLine,results;
    for(var i = 0;i < len; i++){
      currentObj = segmentObj[keys[i]]; // should be an array of line segments [{start:{x:val,y:val},end:{x:val,y:val}},...]
      objLen = currentObj.length;
      if(keys[i] == previousSegID){console.log('skipping for past object');continue;} // skips the segment if it is in the previous object
      for(var j = 0; j < objLen; j++){
        currentLine = currentObj[j];
        if(keys[i] == currentSegID){if(sameSegment(currentSeg,currentLine)){console.log('skipping for current segment');continue;}} // skips the segment if it is the current segment
        results = getSegmentIntersection(currentSeg,currentLine);
        if(results != null){
          if(checkArrayForPoint({x:results.x,y:results.y},cornerPoints)){console.log('skipping for corner duplication');continue;} // skips intersections with known past intersection points
          intersecting.push({segment:currentLine,objID:keys[i],intersection:{x:results.x,y:results.y}});
        }
      }
    }

    var closestDist = null;
    var closestSegment = null;
    var closestPoint = null;
    var closestObj = null;
    var poly = null;
    var tempSegment;
    var currentSegmentObj = segmentObj[currentSegID];

    // Loops through intersecting line segments 
    var len = intersecting.length;
    for(var i = 0;i < len; i++){
      currentLine = intersecting[i];
      results = getLength(currentPoint,currentLine.intersection);
      if(results <= closestDist || closestDist == null){
        poly = createPolygon(segmentObj[previousSegID]);
        if(pointInside(currentLine.intersection,poly)){console.log('points inside previous object poly - weeding out');continue;} // Prevents intersecting with a corner inside the previous object
        if(currentLine.objID != currentSegID){
          if(hasSameSegment(currentLine.segment,currentSegmentObj)){console.log('has same segment - weeding out');continue;};
        }
        tempSegment = {start:{x:currentPoint.x,y:currentPoint.y},end:{x:currentLine.intersection.x,y:currentLine.intersection.y}};
        if(preventRecross(tempSegment,previousSeg,segmentObj[previousSegID])){console.log('recross prevented');continue;} // Prevents recrossing the previous object
        if(results == closestDist){
          if(closestObj == currentSegID){ // Gives a preference for moving onto a new object
            closestDist = results;
            closestSegment = currentLine.segment;
            closestPoint = currentLine.intersection;
            closestObj = currentLine.objID;
          }          
        } else {
          closestDist = results;
          closestSegment = currentLine.segment;
          closestPoint = currentLine.intersection;
          closestObj = currentLine.objID;          
        }
      }
    }

  return {dist:closestDist,segment:closestSegment,point:closestPoint,objID:closestObj};
}

// Checks to see if a segment crosses the previous object on a line seperate from the original intersection segment
// If true, we basically know that the target intersection is the result of an invalid move
function preventRecross(segment,prevSegment,prevSegmentObj){
    var intersecting = [];
    var currentLine,results;
    var objLen = prevSegmentObj.length;
    for(var j = 0; j < objLen; j++){
      currentLine = prevSegmentObj[j];
      results = getSegmentIntersection(segment,currentLine);
      if(results){
        if(!sameSegment(prevSegment,currentLine) && !samePoint(results,segment.start)){
          return true;
        }
      }
    }
    return false;  
}

function checkArrayForPoint(point,pointArray){ // Returns true if the point is in the point array
  var len = pointArray.length;
  for(i = 0; i < len; i++){
    if(point.x == pointArray[i].x && point.y == pointArray[i].y){
      return true;
    }
  }
  return false;
}

function createPolygon(segments){ // Segments must be an array and must be in order
  var len = segments.length;
  var points = [];
  for(var i = 0; i < len; i++){
    currentSeg = segments[i];
    points.push({x:currentSeg.start.x,y:currentSeg.start.y});
  }
  return points;
}

function sameSegment(segment1,segment2){ // returns true if the segments are the same
  // does not catch if the starts and ends are flipped
  var opt1 = segment1.start.x == segment2.start.x && segment1.start.y == segment2.start.y;
  var opt2 = segment1.end.x == segment2.end.x && segment1.end.y == segment2.end.y;
  var opt3 = segment1.start.x == segment2.end.x && segment1.start.y == segment2.end.y;
  var opt4 = segment1.end.x == segment2.start.x && segment1.end.y == segment2.start.y;
  return (opt1 && opt2) || (opt3 && opt4);
}

function samePoint(point1,point2){
  return point1.x == point2.x && point1.y == point2.y;
}

// Checks to see if a segment Object has a segment which matches a given segment
// This is used to prevent the system from selecting a segment which perfectly matches another object's segment
function hasSameSegment(segment,segmentObj){
  var checkSegment;
  for(var i in segmentObj){
    checkSegment = segmentObj[i];
    if(sameSegment(segment,segmentObj[i])){
      return true;
    }
  }
  return false;
}

var snapPointToLine = function(point,snapObjects,optObj){
  var options = optObj || {};
  options.sensitivity = options.sensitivity || 12;
  if(options.points === undefined){
    options.points = true;
  }
  if(options.edges === undefined){
    options.edges = true;
  }

  var snapObjects,objectsToCheck,myPoints,mySnapPoints,closeObjects,pointSnapped,edgeSnapped;
  closeObjects = {snapEdges:[],snapPoints:[]}; // Holder for objects where the point is inside the buffer box
  objectsToCheck = snapObjects.length;

  for(var i = 0;i<objectsToCheck;i++){
      if(pointInside([point],snapObjects[i].bufferBox)){
          closeObjects.snapEdges.push(snapObjects[i].snapEdges);
          closeObjects.snapPoints.push(snapObjects[i].snapPoints);
      }
  }

  if(options.points && closeObjects.snapPoints.length){ // First step is to check for a snap point to snap to
    pointSnapped = snapPoint([point],closeObjects.snapPoints,options.sensitivity);
  }

  if(pointSnapped){
      return {xMove:pointSnapped.xMove,yMove:pointSnapped.yMove};
  } else if (closeObjects.snapEdges.length) {
      if(options.edges){
        edgeSnapped = snapPointToEdge([point],closeObjects.snapEdges);
      }
      if(edgeSnapped){
          return {xMove:edgeSnapped.xMove,yMove:edgeSnapped.yMove};                     
      }
  }
  return false;
}

var snapPointToEdge = function(point,candidateEdges){
    // Example Line Segment/Edge {start:{x:val,y:vale},end:{x:val,y:val}}
    var currentObj,currentLine,result,xMove,yMove;
    var len = candidateEdges.length;
    var shortest = {dist:null};
    
    for(var i = 0;i < len;i++){
      currentObj = candidateEdges[i];
      for(var k = 0;k < currentObj.length;k++){
        currentLine = currentObj[k];
        result = pDistance(point[0],currentLine);
        if(result.dist < shortest.dist || shortest.dist === null){
          shortest = result;
        }
      }
    }

    if(shortest.dist !== null){
        xMove = -shortest.dx;
        yMove = -shortest.dy;
        return {xMove:xMove,yMove:yMove};
    } else {
        return false;
    }
}

var snapObject = function(myPoints,snapObjects,optObj){
  var options = optObj || {};
  options.sensitivity = options.sensitivity || 12;
  if(options.points === undefined){
    options.points = true;
  }
  if(options.edges === undefined){
    options.edges = true;
  }

  var objectsToCheck,myPoints,mySnapPoints,closeObjects,pointSnapped,edgeSnapped;
  objectsToCheck = snapObjects.length;
  mySnapPoints = myPoints.snapPoints;
  closeObjects = {snapEdges:[],snapPoints:[]};
  for(var i = 0;i<objectsToCheck;i++){
      if(pointInside(mySnapPoints,snapObjects[i].bufferBox)){
          closeObjects.snapEdges.push(snapObjects[i].snapEdges);
          closeObjects.snapPoints.push(snapObjects[i].snapPoints);
      }
  }

  if(options.points){
    pointSnapped = snapPoint(myPoints.snapPoints,closeObjects.snapPoints,options.sensitivity);
  }
  if(pointSnapped){
      return {xMove:pointSnapped.xMove,yMove:pointSnapped.yMove};
  } else if (closeObjects.snapEdges.length) {
      if(options.edges){
        edgeSnapped = snapEdge(myPoints.snapEdges,closeObjects.snapEdges,options.sensitivity);
      }
      if(edgeSnapped){
          return {xMove:edgeSnapped.xMove,yMove:edgeSnapped.yMove};                     
      }
  }
  return false;
}

var snapPoint = function(snapPoints,candidatePoints,sensitivity){
  var myPoint,targetSnaps,targetPoint,dist,xMove,yMove;
  var closestPoint = {myPoint:{x:null,y:null},snapPoint:{x:null,y:null},dist:null};
  var myPointsLen = snapPoints.length;
  var snapCanidates = candidatePoints.length;
  if(snapCanidates){
      for(var i = 0;i < myPointsLen;i++){
          myPoint = snapPoints[i];
          for(var j = 0;j < snapCanidates;j++){
              targetSnaps = candidatePoints[j];
              for(var k = 0;k < targetSnaps.length;k++){
                  targetPoint = targetSnaps[k];
                  dist = getLength(myPoint,targetPoint);
                  if(dist<sensitivity){
                      if(closestPoint.dist === null || closestPoint.dist > dist){
                          closestPoint.dist = dist;
                          closestPoint.myPoint = {x:myPoint.x,y:myPoint.y};
                          closestPoint.snapPoint = {x:targetPoint.x,y:targetPoint.y};
                      }
                  }
              }
          }                        
      }
      if(closestPoint.dist !== null){
        xMove = closestPoint.snapPoint.x - closestPoint.myPoint.x;
        yMove = closestPoint.snapPoint.y - closestPoint.myPoint.y;
        return {xMove:xMove,yMove:yMove};      
      } else {
        return false;
      }
  } else {
    return false;
  }
}

var snapEdge = function(snapObjectEdges,candidateEdges,sensitivity){ // both arguments are arrays of line segments, each with start and end points
    // Example Line Segment {start:{x:val,y:vale},end:{x:val,y:val}}
    var xMove,yMove,myEdge;
    var len = snapObjectEdges.length;
    var len2 = candidateEdges.length;
    var targetEdges,targetEdge,theta1,theta2,projection,projectionLength;
    var shortestProjection = {projection:null,length:null};
    for(var i = 0;i < len;i++){
        myEdge = snapObjectEdges[i];
        theta1 = getAngle(myEdge.start,myEdge.end);
        for(var j = 0;j < len2;j++){
            targetEdges = candidateEdges[j];
            for(var k = 0; k < targetEdges.length;k++){
                targetEdge = targetEdges[k];
                theta2 = getAngle(targetEdge.start,targetEdge.end);
                if(round((theta1%Math.PI + theta2%Math.PI)%Math.PI,10) == 0){ // Checks to see if the edges are parallel
                    projection = parallelSegmentsProjection(myEdge,targetEdge);
                    projectionLength = Math.sqrt(Math.pow(projection.x,2) + Math.pow(projection.y,2));
                    if(projectionLength < sensitivity && (shortestProjection.length > projectionLength || shortestProjection.length === null)){
                        shortestProjection.projection = projection;
                        shortestProjection.length = projectionLength;
                    }
                }
            }
        }
    }
    if(shortestProjection.length !== null){
        xMove = -shortestProjection.projection.x;
        yMove = -shortestProjection.projection.y;
        return {xMove:xMove,yMove:yMove};
    } else {
        return false;
    }
}


function getLength(point1,point2){
  return Math.sqrt(Math.pow(point1.y-point2.y,2)+Math.pow(point1.x-point2.x,2));
}

function getAngle(point1,point2){
  return Math.atan2((point1.y-point2.y),(point2.x-point1.x));
}

function getMidPoint(point1,point2){
    return {x:(point1.x+point2.x)/2,y:(point1.y+point2.y)/2}
}

function equalPoints(point1,point2){
  return round(point1.x,5) == round(point2.x,5) & round(point1.y,5) == round(point2.y,5);
}



function rectHandleDrag(points,handleDragging,angle,minimumDimension,initialDims,centerPoint,width,length,map){
  var coords = map.pointerCoords(); // gets the latest mouse location
  var xMove = coords.x-map.handle.x/map.scale;
  var yMove = coords.y-map.handle.y/map.scale;

  points[handleDragging].dragOffset(xMove,yMove,0,map);

  switch(handleDragging){
        
    case 0: // Upper left
    var theta1 = angle;
    var theta2 = getAngle(points[0],points[2]);
    var theta3 = theta2 - theta1;
    var theta4 = theta1 + Math.PI/2;
    var theta5 = theta4 + Math.PI/2;
    var dist = getLength(points[0],points[2]);
    var width = dist * Math.cos(theta3);
    var length = dist * Math.sin(-theta3);
    if(width < minimumDimension){width = minimumDimension;}
    if(length < minimumDimension){length = minimumDimension;}
    
    var p1x = length * Math.cos(theta4) + points[2].x;
    var p1y = -length * Math.sin(theta4) + points[2].y;
    var p3x = width * Math.cos(theta5) + points[2].x;
    var p3y = -width * Math.sin(theta5) + points[2].y;
    var p0x = length * Math.cos(theta4) + p3x;
    var p0y = -length * Math.sin(theta4) + p3y;

    points[0].updatePosition(p0x,p0y);
    points[3].updatePosition(p3x,p3y);
    points[1].updatePosition(p1x,p1y);
    
    break;

    case 1:  // Upper right
    var theta1 = angle;
    var theta2 = getAngle(points[3],points[1]);
    var theta3 = theta2 - theta1;
    var theta4 = theta1 + Math.PI/2;
    var dist = getLength(points[1],points[3]);
    var width = dist * Math.cos(theta3);
    var length = dist * Math.sin(theta3);
    if(width < minimumDimension){width = minimumDimension;}
    if(length < minimumDimension){length = minimumDimension;}
    
    var p2x = width * Math.cos(theta1) + points[3].x;
    var p2y = -width * Math.sin(theta1) + points[3].y;
    var p0x = length * Math.cos(theta4) + points[3].x;
    var p0y = -length * Math.sin(theta4) + points[3].y;
    var p1x = length * Math.cos(theta4) + p2x;
    var p1y = -length * Math.sin(theta4) + p2y;
    
    points[1].updatePosition(p1x,p1y);
    points[2].updatePosition(p2x,p2y);
    points[0].updatePosition(p0x,p0y);
    break;

    case 2:  // Lower right
    var theta1 = angle;
    var theta2 = getAngle(points[0],points[2]);
    var theta3 = theta2 - theta1;
    var theta4 = theta1 + Math.PI/2;
    var dist = getLength(points[0],points[2]);
    var width = dist * Math.cos(theta3);
    var length = -dist * Math.sin(theta3);
    if(width < minimumDimension){width = minimumDimension;}
    if(length < minimumDimension){length = minimumDimension;}

    var p1x = width * Math.cos(theta1) + points[0].x;
    var p1y = -width * Math.sin(theta1) + points[0].y;
    var p3x = -length * Math.cos(theta4) + points[0].x;
    var p3y = length * Math.sin(theta4) + points[0].y;
    var p2x = -length * Math.cos(theta4) + p1x;
    var p2y = length * Math.sin(theta4) + p1y;

    points[2].updatePosition(p2x,p2y);
    points[1].updatePosition(p1x,p1y);
    points[3].updatePosition(p3x,p3y);
    break;

    case 3:  // Lower left
    var theta1 = angle;
    var theta2 = getAngle(points[1],points[3]);
    var theta3 = theta2 - theta1;
    var theta4 = theta1 + Math.PI/2;
    var dist = getLength(points[1],points[3]);
    var width = -dist * Math.cos(theta3);
    var length = -dist * Math.sin(theta3);
    if(width < minimumDimension){width = minimumDimension;}
    if(length < minimumDimension){length = minimumDimension;}

    var p0x = -width * Math.cos(theta1) + points[1].x;
    var p0y = width * Math.sin(theta1) + points[1].y;
    var p2x = -length * Math.cos(theta4) + points[1].x;
    var p2y = length * Math.sin(theta4) + points[1].y;
    var p3x = -length * Math.cos(theta4) + p0x;
    var p3y = length * Math.sin(theta4) + p0y;
    
    points[3].updatePosition(p3x,p3y);
    points[0].updatePosition(p0x,p0y);
    points[2].updatePosition(p2x,p2y);
    
    break;

    case 4:  // Top Edge
    var theta1 = angle;
    var theta2 = theta1 + Math.PI/2;
    var dist = Math.sqrt(Math.pow(xMove,2)+Math.pow(yMove,2));
    var theta3 = Math.atan2(-yMove,xMove);
    var theta4 = theta2 - theta3;
    var adj = map.snapRound(dist * Math.cos(theta4));
    if(initialDims.lengthMargin <= -adj){adj = -initialDims.lengthMargin;} // Enforces the minimum dimension size
    var newX = adj * Math.cos(theta2);
    var newY = -adj * Math.sin(theta2);
    points[4].dragOffset(newX,newY);
    points[0].dragOffset(newX,newY);
    points[1].dragOffset(newX,newY);
    break;

    case 5: // Right Edge
    var theta1 = angle;
    var theta2 = Math.atan2(-yMove,xMove);
    var theta3 = theta2 - theta1;
    var dist = Math.sqrt(Math.pow(xMove,2)+Math.pow(yMove,2));
    var adj = map.snapRound(dist * Math.cos(theta3));
    if(initialDims.widthMargin <= -adj){adj = -initialDims.widthMargin;} // Enforces the minimum dimension size
    var newX = adj * Math.cos(theta1);
    var newY = -adj * Math.sin(theta1);
    points[5].dragOffset(newX,newY);
    points[1].dragOffset(newX,newY);
    points[2].dragOffset(newX,newY);
    break;

    case 6: // Bottom Edge
    var theta1 = angle;
    var theta2 = theta1 + Math.PI/2;
    var dist = Math.sqrt(Math.pow(xMove,2)+Math.pow(yMove,2));
    var theta3 = Math.atan2(-yMove,xMove);
    var theta4 = theta2 - theta3;
    var adj = map.snapRound(dist * Math.cos(theta4));
    if(initialDims.lengthMargin <= adj){adj = initialDims.lengthMargin;} // Enforces the minimum dimension size
    var newX = adj * Math.cos(theta2);
    var newY = -adj * Math.sin(theta2);
    points[6].dragOffset(newX,newY);
    points[2].dragOffset(newX,newY);
    points[3].dragOffset(newX,newY);
    break;

    case 7: // Left Edge
    var theta1 = angle;
    var theta2 = Math.atan2(-yMove,xMove);
    var theta3 = theta2 - theta1;
    var dist = Math.sqrt(Math.pow(xMove,2)+Math.pow(yMove,2));
    var adj = map.snapRound(dist * Math.cos(theta3));
    if(initialDims.widthMargin <= adj){adj = initialDims.widthMargin;} // Enforces the minimum dimension size
    var newX = adj * Math.cos(theta1);
    var newY = -adj * Math.sin(theta1);
    points[7].dragOffset(newX,newY);
    points[3].dragOffset(newX,newY);
    points[0].dragOffset(newX,newY);
    break;

    case 8: // Drag Hangle
        var xComponent = coords.x - centerPoint.x;
        var yComponent = coords.y - centerPoint.y;
        angle = Math.atan2(-yComponent,xComponent) - Math.PI/2;
        points[0].rotateAroundCenter(centerPoint.x,centerPoint.y,angle);
        points[1].rotateAroundCenter(centerPoint.x,centerPoint.y,angle);
        points[2].rotateAroundCenter(centerPoint.x,centerPoint.y,angle);
        points[3].rotateAroundCenter(centerPoint.x,centerPoint.y,angle);
        return angle;
    break;
  }
}