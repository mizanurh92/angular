//#################################  State Controller #####################################################

function StateController(map){
    this.state = "openSelector";
    this.controllers = null;
    this.dataConnections = null;
    this.crossHairs = new CrossHairController(map);
    this.dragHandle = "";
    this.revisionStep = 0; // This is where the editor currently sits on the undo/redo chain
    this.maxRevisions = 10; // The length of the undo/redo chain
    this.undoArray = [[]];
    this.redoArray = [[]];
    this.started = false;


    this.setControllers = function(controllers, dataConnections){
        this.controllers = controllers;
        this.dataConnections = dataConnections;
    }

    // Undo/Redo is set up as two arrays, an undo array and a redo array.  Whenever an action is taken that could be undone
    // two entries are made, one in each array.  The entry in the undo array provides the state of the change objects just
    // before the change, allowing for the action to be undone.  The entry to the redo array provides the state of the changed
    // object right after the action.  Allowing the actio to be redone after an undo.  The objects inside the array are arrays
    // themselves, as each action may impact many items.  Changes are pushed to the current position of the array when an action
    // occurs.  When another action occurs, the current position is unshifted and the prior action moves further back in line.

    // This is called after the initial load and begins allowing changes to be undone/redone
    // This is needed so that various initializations can't be undone as they can be captured by the process
    this.startUndoRedo = function(){
        this.started = true;
    }

    this.undo = function(){
        if(!this.started){ return; }
        if(this.revisionStep < this.maxRevisions - 1 && this.revisionStep < this.undoArray.length){
            // The next section checks to see whether there are any undo packages in the [0] location.  If the revision step is 0 and
            // the user selects undo but there aren't any revisions in that bucket yet, nothing will happen.  The buckets can be empty
            // because a new bucket in [0] will be created by various actions that may not lead to an undo package being created.
            // Rather than doing nothing, the application assumes the user wants to undo the last undoable action and so the revision
            // step is set to 1, which, if it exists, should have something in it.
            if(this.revisionStep == 0 && this.undoArray[0].length == 0 && this.redoArray[0].length == 0){
                if(this.undoArray[1] && this.redoArray[1]){
                    this.revisionStep = 1;
                } else {
                    return;
                }
            }
            // Executes the packages in the current undo revision step and then moves one notch further up the undo chain
            for(var i = 0;i < this.undoArray[this.revisionStep].length;i++){
                this.executePackage(this.undoArray[this.revisionStep][i]);
            }
            this.revisionStep++;
        }
    }

    this.redo = function(){
        if(!this.started){ return; }
        if(this.revisionStep>0){ // Can only redo if you are not at the begginning of the revision chain
            this.revisionStep--; // Move towards the begginning one notch
            for(var i = 0;i < this.redoArray[this.revisionStep].length;i++){ // execute all packages in the revision array one notch up
                this.executePackage(this.redoArray[this.revisionStep][i]);
            }
        }
    }

    // This function should be called when there is an action that should be able to be undone.  This establishes
    // a fresh step in the undo chain unless an empty step is already available.
    this.triggerNewRevisionStep = function(){
        if(!this.started){ return; }
        if(this.revisionStep == 0){ // If you are at the begginning of the revision chain
            if(this.undoArray[0].length > 0 && this.redoArray[0].length > 0){ // And there is data in the buckets
                this.undoArray.unshift([]);  // Shift current data over and create a new empty bucket
                this.redoArray.unshift([]);  // ''
                if(this.undoArray.length>this.maxRevisions){ // Removes data beyond the max undo threshhold
                    this.undoArray.pop();
                    this.redoArray.pop();
                }
            }
        }        
        if(this.revisionStep != 0){ // If you are not at the begginning of the revision chain
            // Note that when you undo several actions and then take a new undoable action, you lose the ability to redo
            // those past undo's
            for(var i = 0;i<this.revisionStep;i++){ // Remove all items from the revision chain up to the current point
                this.undoArray.shift();
                this.redoArray.shift();
            }
            this.undoArray.unshift([]);  // Shift current data over and create a new empty bucket
            this.redoArray.unshift([]);  // You can assume the current bucket is non-empty because it wasn't the start
            this.revisionStep = 0;
        }
    }

    this.addUndoPackage = function(package){
        if(!this.started){ return; }
        console.log("undo package created",package.packageType);
        this.undoArray[0].push(package)
    }

    this.addRedoPackage = function(package){
        if(!this.started){ return; }
        console.log("redo package created",package.packageType);
        this.redoArray[0].push(package)
    }

    this.executePackage = function(package){
        if(package.controller == 'data'){
            console.log(package.packageType," executed.")
            this.dataConnections.loadPackage(package);
        } else {
            var controller = this.controllers[package.controller];
            console.log(package.packageType," executed.")
            controller.loadPackage(package);    
        }
        
    }

    this.load = function(){ // Resets the undo/redo system on load of a file (no persistent undo/redo on save)
        this.undoArray = [[]];
        this.redoArray = [[]];
        this.revisionStep = 0;
    }

    this.crossHairBinding = function(){
        var state = this;
        map.map.mousemove(function(){
            if(state.crossHairs.active){
                state.crossHairs.move(map.pointerCoords().x,map.pointerCoords().y);
            }
        });
        map.map.mouseleave(function(){state.crossHairs.remove();}); // removes the crosshairs if the mouse leaves the map area
        map.map.mouseenter(function(){state.crossHairs.create();}); // creates the crosshairs if the mouse enters the map area
    }
    this.crossHairBinding();
    
    this.setState = function(newState,optObj){
        console.log("New state is:"+newState);
        var options = optObj || {};
        var crossHairs = options.crossHairs || false;
        var cursor = options.cursor || "default";

        switch(newState){
            case "createWall":
            case "drawWall":
                crossHairs = true;
            break;
        }

        this.state = newState;
        if(crossHairs){
            this.crossHairs.activate(); 
        } else {
            this.crossHairs.deactivate(); 
        }
        map.map.css("cursor",cursor);
    }

    this.setDragHandle = function(value){
        this.dragHandle = value;
    }

    this.getDragHandle = function(){
        return this.dragHandle;
    }

}