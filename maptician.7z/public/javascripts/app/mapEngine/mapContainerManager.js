//#################################  Map Container Controller #####################################################
// Sets the map container and calculates useful measurements
function MapContainerController(container){
    // The mapContainer is a div that holds the map and is the size of the "currently viewable" portion of the map
    // The overflow portions of the map are hidden, so the mapContainer acts as a "window" to view the map through
    this.container = container || $("#mapContainer");
    this.pos = {
        x: this.container.position().left,
        y: this.container.position().top
    };
    this.dim = {
        width: this.container.width(),
        height: this.container.height()
    }
    this.position = function(){
        this.pos.x = this.container.position().left;
        this.pos.y = this.container.position().top;
        return this.pos;
    }
    this.size = function(){
        this.dim.width = this.container.width();
        this.dim.height = this.container.height();
        return this.dim;
    }
    this.width = function(){
        this.dim.width = this.container.width();
        return this.dim.width;
    }
    this.height = function(){
        this.dim.height = this.container.height();
        return this.dim.height;
    }
    this.x = function(){
        this.pos.x = this.container.position().left;
        return this.pos.x;
    }
    this.y = function(){
        this.pos.y = this.container.position().top;
        return this.pos.y;
    }
}