function KioskViewerInstance(file){
    this.map;
    this.miniMap;
    this.state;
    this.controllers;
    this.dataConnections;
    this.settings;
    this.objectSelector;
    this.keyboardRouter;
    this.mouseRouter;

    // #####################################  Application Functions  ############################################################
    this.load = function(file){
        console.log(file)
        this.clear();
        this.units = file.settings.unitSystem;
        this.map = new MapController(file.map.originalDim.width,file.map.originalDim.height,'Kiosk');
        this.miniMap = new MiniMapController(this.map,{
            miniMapContainer:$("#kioskMiniMapContainer"),
            miniMapSVG: $("#kioskMiniMapSVG"),
            miniMap: $("#kioskMiniMap"),
            viewBox: $("#kioskMiniViewBox"),
            type: "Kiosk"
        });
        this.map.setMiniMap(this.miniMap);
        this.map.toggleGrid(false);
        this.state = new StateController(this.map);
        this.controllers = {
            architect: new ArchitectureController(this.state,this.map),
            zones: new ZoneController(this.state,this.map),
            rooms: new RoomController(this.state,this.map),
            furniture: new FurnitureController(this.state,this.map),
            seats: new SeatController(this.state,this.map),
            kiosks: new KioskController(this.state,this.map),
            maplinks: new MapLinkController(this.state,this.map),            
        }
        this.dataConnections = new ConnectionController(this.controllers);
        this.settings = new SettingsController(file.id,file.name,this.map,this.minimap,file.settings.unitSystem,file.officeID,this);
        this.objectSelector = new KioskObjectSelector(this.controllers,this.settings);
        this.keyboardRouter = new KioskKeyboardRouterController(this.state,this.map,this.objectSelector,this.controllers,this.dataConnections);
        this.mouseRouter = new KioskMouseRouter(
            this.controllers,
            this.state,
            this.map,
            this.miniMap,
            this.objectSelector,
            this.keyboardRouter,
            this.dataConnections
        );
        this.state.load();
        this.map.load(file.map)
        this.map.loadView();
        this.miniMap.setMiniMap();
        this.miniMap.setScale();
        this.miniMap.setMinimapView();
        this.settings.load(file.settings);
        for(var i in file.controllers){
            console.log("Loading ",i)
            try{
                this.controllers[i].load(file.controllers[i],this.state,this.dataConnections);
                this.controllers[i].program = "Kiosk";
            } catch(err){
                console.log(err);
            }
        }
        this.dataConnections.load(file.id,{type:"Kiosk"});
        delete this.units;
        this.setTitle();
        console.log("Load Complete");
    }

    // #####################################  Helper Functions  ############################################################

    this.clear = function(){
        for(var i in this.controllers){
            this.controllers[i].removeAll();
        }
        $("#kioskViewerTitle").html("");
    }

    this.getMapID = function(){
        return this.settings.getID();
    }

    this.getName = function(){
        return this.settings.getMapName();
    }

    this.getFloor = function(){
        return this.settings.floorNumber;
    }

    this.getSuite = function(){
        return this.settings.suiteNumber;
    }

    this.getUnitSystem = function(){
        return this.settings.getUnitSystem();
    }

    this.hide = function(){
        console.log('Hiding Kiosk Map')
        this.map.saveView();
        for(var i in this.controllers){
            this.controllers[i].removeLayer();
        }
        $("#kioskViewerTitle").html("");
    }

    this.refreshLayers = function(){
        // for(var i in this.controllers){
        //     this.controllers[i].removeLayer();
        // }        
        // for(var i in this.controllers){
        //     this.controllers[i].redrawLayer();
        // }           
    }

    this.redraw = function(){
        this.map.reloadMap();
        this.settings.setUnit();
        for(var i in this.controllers){
            this.controllers[i].redrawLayer();
        }        
        this.objectSelector.selectSVG();
        this.map.loadView();
        this.miniMap.setMiniMap();
        this.miniMap.setScale();
        this.miniMap.setMinimapView();
        this.setTitle();
    }

    this.objectsSelected = function(){
        for(var i in this.controllers){
            if(this.controllers[i].objectsAreSelected()){
                return true;
            }
        }
        return false;
    }

    this.setTitle = function(){
        var title = "";
        //var name = this.getName();
        var floor = this.getFloor();
        var suite = this.getSuite();
        // if(name){
        //     title += name;
        //     title += floor || suite ? '<br />' : "";
        //     title += floor ? 'Floor: ' + floor : "";
        //     title += floor && suite ? " , " : "";
        //     title += suite ? 'Suite: ' + suite : "";            
        // } else if(floor || suite){
        //     title += floor ? 'Floor: ' + floor : "";
        //     title += floor && suite ? " , " : "";
        //     title += suite ? 'Suite: ' + suite : "";
        // }
        title = "";
        if(floor || suite){
            title += floor ? 'Floor: ' + floor : "";
            title += floor && suite ? " , " : "";
            title += suite ? 'Suite: ' + suite : "";
        }
        $("#kioskViewerTitle").html(title);
    }

    this.goToPoint = function(point){
        this.miniMap.setMiniMap();
        this.miniMap.setScale();
        this.miniMap.setMinimapView();
        this.map.goToPoint(point);
    }

    this.getKioskPoint = function(kioskID){
        return this.controllers.kiosks.objects[kioskID].points[0].getPoint();
    }

    this.load(file);
    this.objectSelector.selectSVG();
}