//#################################  Keyboard Router Controller #####################################################

function KioskSvgRouter(controllers,state,map,objectSelector){
	this.controllers = controllers;
	this.clicked = function(id,svgObject,button,ctrlKey){
        if(svgObject.hasClass("architect")){
            if(state.state == "openSelector") { 
                var subclass;
                if(svgObject.hasClass("door")){subclass = "Door";}
                if(svgObject.hasClass("window")){subclass = "Window";}
	            objectSelector.selectSVG(id.slice(1),"architect",subclass);
	            this.controllers.architect.viewerSelectOne(id.slice(1),subclass);
            }
        }

		if(svgObject.hasClass("Seat")){
	        if(state.state == "openSelector") { 
	            this.controllers.seats.selectOne(id.slice(1));
	            objectSelector.selectSVG(id.slice(1),"seats");
	        }
		}

		if(svgObject.hasClass("Kiosk")){
	        if(state.state == "openSelector") { 
	            this.controllers.kiosks.selectOne(id.slice(1));
	            objectSelector.selectSVG(id.slice(1),"kiosks");
	        }
		}

		if(svgObject.hasClass("furniture")){
	        if(state.state == "openSelector") {
	            var objID = id.slice(1);
	            if(svgObject.hasClass("subobject")){
	            	var type = svgObject[0].classList[2];
	            	objectSelector.selectSVG(objID,"furniture",type);
	            } else {
		            objectSelector.selectSVG(objID,"furniture");	            	
	            }
	        }
		}

		if(svgObject.hasClass("map")){
	        if(state.state == "openSelector") { 
	            objectSelector.selectSVG();
	        }
		}

		if(svgObject.hasClass("Zone")){
	        if(button == 1){
            	objectSelector.selectSVG(id,"zones");
	        }
		}

		if(svgObject.hasClass("Room")){
	        if(button == 1){
            	objectSelector.selectSVG(id,"rooms");
	        }
		}

	}
}