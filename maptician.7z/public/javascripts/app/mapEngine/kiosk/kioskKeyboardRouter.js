//#################################  Keyboard Router #####################################################

function KioskKeyboardRouterController(state,map,objectSelector,controllers,dataConnections){
	this.keyUp = function(event){}
	this.keyPress = function(event){}
}