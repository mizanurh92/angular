Maptician.Kiosk ? null : Maptician.Kiosk = {}
Maptician.Kiosk.Tables = {};

Maptician.Kiosk.Tables.selectMapTable = function(data){
	var kioskTables = Maptician.Kiosk.Tables;
	var selectMapTable = kioskTables.selectMapTable;
	var SelectMapTable;

    if(kioskTables.SelectMapTable){
        $('#selectMapModal').modal();
        kioskTables.SelectMapTable.clear().rows.add(data);
        kioskTables.SelectMapTable.draw();
        return;
    }

    $('#selectMapModal').modal();

    kioskTables.SelectMapTable = $("#selectMapTable").DataTable({
        data: data,
        select: 'single',
        language:{
            "info": "Showing Maps _START_ to _END_ of _MAX_",
            "lengthMenu": "Show _MENU_ Maps",
            "search": "Search:",
        },
        scrollY:$("#selectMapModal").height() - 99,
      	deferRender:true,
      	scroller:true,
      	paging:true,
        order:[1,'asc'],
        columns: [
            {
				data: {}, // Map Name
				width: '200px',
				'className':'leftAlign',
				render: function(map){
					return map.name;
				},
			},
            {
				data: {}, // Floor
				width: '50px',
				'className':'tableCenterText',
				render: function(map){
					return map.floor;
				},
			},
            {
				data: {}, // Suite
				width: '50px',
				'className':'tableCenterText',
				render: function(map){
                    return map.suite;
				},
			},
        ],
        dom: 'rt',
        initComplete: function(){
            //$('#selectMapModal').modal();
        }
    }) // End of DataTable Initialization

    SelectMapTable = kioskTables.SelectMapTable;

    if(selectMapTable.hasInit){ // Sets up bindings on first run

    } else {

		_attach.call(SelectMapTable,'selectMapTableFrame',99,function(height){
			$("#selectMapTable").parent().css("height",height)
		});
    
        SelectMapTable.on( 'select', function ( e, dt, type, indexes ) {
            SelectMapTable.selectedFile = SelectMapTable.rows( indexes ).data().toArray()[0];
        })
        
        $("#cancelSelectMap").click(function(){
            $.modal.close();
        })

        $("#confirmSelectMap").click(function(){
            if(SelectMapTable.selectedFile){
                $Map.KioskNav.changeFile(SelectMapTable.selectedFile.mapID);
                delete SelectMapTable.selectedFile;
                $.modal.close();
            }
        })

        selectMapTable.hasInit = true;
    }
}

Maptician.Kiosk.Tables.searchMapTable = function(){
    var kioskTables = Maptician.Kiosk.Tables;
    var searchMapTable = kioskTables.searchMapTable;
    var SearchMapTable;

    var data;
    var dataArray = [];

    if(searchMapTable.hasInit){
        data = Maptician.KioskNav.currentFile.dataConnections.users;
        for(var i in data){dataArray.push(data[i]);}
        kioskTables.SearchMapTable.clear().rows.add(dataArray);
        kioskTables.SearchMapTable.draw();
        return;
    } else {
        data = Maptician.KioskNav.currentFile.dataConnections.users;
        for(var i in data){dataArray.push(data[i]);}
    }

    kioskTables.SearchMapTable = $("#kioskMapSearchTable").DataTable({
        data:dataArray,
        select: 'single',
        language:{
            "info": "Showing Maps _START_ to _END_ of _MAX_",
            "lengthMenu": "Show _MENU_ Maps",
            "search": "Search:",
        },
        scrollY:$("#kioskMapSearch").height() - 80,
        deferRender:true,
        scroller:true,
        paging:true,
        order:[1,'asc'],
        columns:[
            {
                title:"Name",
                data:{},
                sortable:false,
                'className':'tableProfileImage',
                render: function(poi){
                    return poi.first + " " + poi.last;
                }
            },
            {
                title:"Type",
                data:{}, // Name
                'className':'tableCenterText',
                render: function(poi){
                    return "User"
                }
            },
            {
                data:{}, // Location
                sortable:false,
                'className':'tableCenterText',
                render: function(poi){
                    return "<i class='fa fa-crosshairs fa-lg findPOI'></i>";
                }
            },
        ],
        dom: 'rt'
    })

    SearchMapTable = Maptician.Kiosk.Tables.SearchMapTable;

    if(searchMapTable.hasInit){

    } else {
        
        searchMapTable.hasInit = true;
    }
}