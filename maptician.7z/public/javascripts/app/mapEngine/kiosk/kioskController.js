function MapKioskController(){
    this.files = {};  // Object containing the open map editor documents - referenced by mapID
    this.currentFile = null; // Pointer holds a reference to the active map file
    this.drawn = false;
    this.kioskID = "";
    this.kioskMapID = "";
    this.kioskPoint = null;

    this.loadOffice = function(){
        var that = this;
        $.ajax({
            type:"GET",
            url: "/api/kiosks/kioskData"
        })
        .then(function(result){
            that.kioskID = result.kiosk;
            that.kioskMapID = result.map;
            that.kioskPoint = result.location;
            return $.ajax({
                type:"GET",
                url: "/loadOfficeFile"
            })
        })
        .then(function(result){
            for(var i = 0; i < result.length; i++ ){
                that.loadFile(result[i]);
            }
            that.showMapElements();
            that.changeFile(that.kioskMapID,{point:that.kioskPoint});
            $("#div3Content").css('display',''); // Resets the css property for display, reverting to style sheet control
        })
        .catch(function(err){
            console.log(err);
        })
    }

    this.loadFile = function(file){
        console.log("Loading Map:",file.name)
        var id = file.id;
        var name = file.name;
        if(this.isSet()){this.currentFile.hide();} // Hides any file already displayed
        $Map.unit(file.settings.unitSystem);
        this.files[id] = new KioskViewerInstance(file); // Creates a map viewer instance, loads the file, and adds it to file list
        this.currentFile = this.files[id]; // Sets the map viewer instance as currently active
    }

    this.changeFile = function(id,options){
        var options = options || {};
        var point = options.point || null;
        if(this.currentFile.getMapID() == id){ // Route if we're already on the file
            if(point){
                this.currentFile.goToPoint(point);
            }
            return;
        }
        this.currentFile.hide();
        this.currentFile = this.files[id];
        $Map.unit(this.currentFile.getUnitSystem());
        this.currentFile.redraw();
        this.drawn = true;
        if(point){
            this.currentFile.goToPoint(point);
        }
        Maptician.Kiosk.Tables.searchMapTable();
    }

    this.hide = function(){
        if(this.drawn == true){
            this.currentFile.hide();
            this.drawn = false;
        }
    }

    this.redraw = function(){
        if(this.drawn == false){
            if(this.currentFile){
                this.currentFile.redraw();
                this.drawn = true;    
            }        
        }
    }

    this.initializations = function(){ // Initialization required on load
        // Disables right click context menus for the map container area
        // TODO remove the getElement portion in production - this will completely disable contect menus
        document.getElementById("editorArea").addEventListener( "contextmenu", function(e) { // TODO build a context menu system
            //e.preventDefault();
        });

        $Map.buttons.buttonBar('kioskViewerButtons');
    }

    this.setBindings = function(){
        var progController = this;
        var documentObj = $(document);
        var screenMap = $("#map");
        var editorArea = $("#editorArea");
        var miniMap = $("#kioskMiniMapContainer");

        document.ontouchmove = function(event){
            if(progController.drawn){
                event.preventDefault();
            }
        }

        editorArea.on('tapstart',function(event,touch){
            if(progController.drawn){
                progController.currentFile.mouseRouter.documentMouseDown(touch);
            }
        })

        miniMap.on('tapstart',function(event,touch){
            if(progController.drawn){
                progController.currentFile.mouseRouter.miniMapMouseDown(touch);
            }
        })

        miniMap.on('tapmove',function(event,touch){
            if(progController.drawn){
                progController.currentFile.mouseRouter.miniMapMouseMove(touch);
            }
        })

        editorArea.on('tapmove',function(event,touch){
            if(progController.drawn){
                progController.currentFile.mouseRouter.documentMouseMove(touch);
            }
        })

        screenMap.on('tapmove',function(event){
            if(progController.drawn){
                progController.currentFile.mouseRouter.mapMouseMove(event);
            }
        })

        screenMap.on('tapstart',function(event,touch){
            if(progController.drawn){
                progController.currentFile.mouseRouter.mapMouseDown(event);
            }
        })

        documentObj.mouseup(function(event){
            if(progController.drawn){
                progController.currentFile.mouseRouter.documentMouseUp(event);
            }
        })

        $("svg").on("mousedown",function(e){ // Mouse click binding for map objects
            if(e.which == 1 && progController.drawn ){
                var id = e.toElement ? e.toElement.id : e.target.id;
                var object = e.toElement || e.target;
                var jQueryObject = $(object);
                progController.currentFile.mouseRouter.svgClickRouter.clicked(id,jQueryObject,e.which,e.ctrlKey);            
            }
        })

        this.screenSizeBindings(progController);
        this.mapNavigationBindings(progController);
    }

    this.screenSizeBindings = function(progController){  // Controls map area and navbar sizes and positions on resize
        $(window).resize(function(){
            // Updates map position on window resize so that it doesn't get positioned outside of bounds
            if(progController.isSet()){
                progController.currentFile.map.constrainedMove(
                    progController.currentFile.map.x(),
                    progController.currentFile.map.y(),
                    progController.currentFile.miniMap
                    );
            }
        });    
    }

    this.mapNavigationBindings = function(progController){ // Handles map zooming and panning based on mouse and keyboard input

        $("#map").on("dblclick",throttle(function(e){  // Function that zooms the map in by a scalestep on doubleclick of the map
            if(e.ctrlKey && progController.isDrawn()){ // Only triggers on ctrl+double-click
                progController.currentFile.map.zoomMap("in",progController.currentFile.miniMap,"mouse");
            }
        },300,false));

        $("#map").on('wheel',throttle(function(e){  // Controls zooming via scroll wheel
            if(e.ctrlKey && progController.isDrawn()){ // Only triggers on ctrl+scroll
                if(e.originalEvent.deltaY<0){progController.currentFile.map.zoomMap("in",progController.currentFile.miniMap,"mouse");} 
                else {progController.currentFile.map.zoomMap("out",progController.currentFile.miniMap,"mouse");}
            }
        },200,false));

        $(document).on("keydown",throttle(function(e){ // Controls zoom-in and out via the plus and minus keys
            if(!$.modal.isActive() && progController.isDrawn() && progController.currentFile.objectSelector.selectorActive == false){
                switch(e.which){
                    case 107: // Plus Key
                        progController.currentFile.map.zoomMap("in",progController.currentFile.miniMap,"center");
                    break;
                    case 109: // Minus Key
                        progController.currentFile.map.zoomMap("out",progController.currentFile.miniMap,"center");
                    break;
                };
            }
        },400,true));
    
        $(document).on("keydown",throttle(function(e){
            if(!$.modal.isActive() && progController.isDrawn() && progController.currentFile.objectSelector.selectorActive == false){ 
                // Keys will not pan the screen when the object selector is active
                if(progController.currentFile.state.state == "openSelector"){ // Appliction state must be in open selector mode
                    switch(e.which){ // note that the map moves in the opposite direction of the arrow press
                        case 37:
                            progController.currentFile.map.animateMoveMap(1,0,progController.currentFile.miniMap);
                        break;
                        case 38:
                            progController.currentFile.map.animateMoveMap(0,1,progController.currentFile.miniMap);
                        break;
                        case 39:
                            progController.currentFile.map.animateMoveMap(-1,0,progController.currentFile.miniMap);
                        break;
                        case 40:
                            progController.currentFile.map.animateMoveMap(0,-1,progController.currentFile.miniMap);
                        break;
                    }
                }
            }
            return false; // prevents the default action for the key events
        },83,true)) // Throttle the map move so that the animation is roughly continuous while the button is down  

        $("#kioskChangeMap").click(function(){
            if(progController.isDrawn()){
                $Map.Kiosk.Tables.selectMapTable(progController.getMapData());
            }
        })
      
        $("#kioskCurrentLocation").click(function(){
            if(progController.isDrawn()){
                progController.changeFile(progController.kioskMapID,{point:progController.kioskPoint});
            }
        })

        $("#kioskSearch").click(function(){
            if(progController.isDrawn()){
                $("#kioskMapSearch").slideToggle({
                    duration:600
                });
                $('#kioskSearch').toggleClass('MainNav-Button_Active2');
                $('#kioskChangeMap').toggleClass('MainNav-Button_LeftOfActive2');
            }
        })

        $("#kioskFitZoom").click(function(){
            if(progController.isDrawn()){
                progController.currentFile.map.fitMap(progController.currentFile.miniMap);
            }
        })

        $("#kioskZoomOut").click(function(){
            if(progController.isDrawn()){
                progController.currentFile.map.zoomMap("out",progController.currentFile.miniMap,"center");
            }
        })

        $("#kioskZoomIn").click(function(){
            if(progController.isDrawn()){
                progController.currentFile.map.zoomMap("in",progController.currentFile.miniMap,"center");
            }
        })


    }

    this.isSet = function(){ // Returns true if a map is set and loaded
        return this.currentFile != null;
    }

    this.isDrawn = function(){ // Returns whether the viewer is currently drawn
        return this.drawn;
    }

    this.reloadFile = function(){
        //TODO write refresh function
    }

    this.hideMapElements = function(){
        $("#kioskMiniMap").css("display","none");
        $("#map").css("display","none");      
    }

    this.showMapElements = function(){
        $("#kioskMiniMap").css("display","block");
        $("#map").css("display","block");  
    }

    this.getMapData = function(){
        var map;
        var dataArray = [];
        for(var i in this.files){
            map = this.files[i];
            dataArray.push({
                name: map.getName(),
                floor: map.getFloor(),
                suite: map.getSuite(),
                mapID: i
            })
        }
        return dataArray;
    }

    this.initializations();
    this.setBindings();
    this.loadOffice();
}
MapKioskController.prototype.zoomScale = [.1,.25,.5,.75,1,1.25,1.5,2,3,4,6,8,10,12,15];