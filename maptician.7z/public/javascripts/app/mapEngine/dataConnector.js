//#################################  Connection Controller #####################################################

function ConnectionController(controllers,mapName, state){
	this.controllers = controllers;
	this.zones = controllers.zones.objects; // Alias to the zones object
	this.rooms = controllers.rooms.objects; // Alias to the rooms object
	this.seats = controllers.seats.objects;; // Alias to the seats object
	this.kiosks = controllers.kiosks.objects; // Alias to the kiosks object
	this.maplinks = controllers.maplinks.objects; // Alias to the maplinks object
	this.seatReservations = {};
	this.roomReservations = {};
	this.seatAssignments = {}; // Object indexed by seatID containing userID and change status for the assignment
	this.users = {}; // Object indexed by userID containing user/employee data
	this.state = state;
	var mapName = mapName;
	var Connections = this;

	this.load = function(mapID,options){
		var options = options || {};
		console.log("Loading Connections")
		this.loadSeatAssignments(mapID,function(){
			options.type == "Kiosk" ? Maptician.Kiosk.Tables.searchMapTable() : null;
			Connections.state.startUndoRedo();
		});
		this.checkSeatsForZone();
		this.checkSeatsForRoom();
		this.checkZonesForRoom();
		this.validateMaplinks();
		if(options.type == "Viewer"){
			this.loadReservations(mapID);
		}
	}

	this.loadInactive = function(mapID,connections){
		this.seatAssignments = connections.seatAssignments;
		var assignedUsers = {};
		for(var i in this.seatAssignments){
			assignedUsers[this.seatAssignments[i].userID] = null;
		}
		var uniqueUsers = Object.keys(assignedUsers) || [];
		console.log('Loading Seat Assignments')
		var connections = this;
		$.ajax({
			type:"POST",
			url: "/api/seats/seat-assignments/",
			data: {users:uniqueUsers},
			success: function(result){
				var userID;
				connections.users = result.users || {};
				for(var seatID in connections.seats){
					if(connections.seatAssignments[seatID]){
						userID = connections.seatAssignments[seatID].userID;
						connections.seats[seatID].setAssignment(connections.users[userID]);
					}
				}

			}, // End of Success callback
			error: function(error){
				console.log('error loading assignments');
			}
		}) // End of AJAX Call
		this.validateMaplinks();
		this.checkSeatsForZone();
		this.checkSeatsForRoom();
	}

	//########################################  Maplinks #############################################

	this.setMaplink = function(linkID,connection){
		this.maplinks[linkID].setMaplink(connection);
	}

	this.removeMaplink = function(linkID){
		this.maplinks[linkID].removeMaplink();
	}

	this.validateMaplinks = function(){
		var connection;
		var validationList = [];
		var controller = this;
		for(var i in this.maplinks){
			connection = this.maplinks[i].getConnectionValidator();
			if(connection){
				validationList.push(connection);
			}
		}
		if(validationList.length == 0){
			return;
		}
		$.ajax({
			type:"POST",
			url: "/api/maplinks/validate/",
			data: {data:validationList}
		})
		.then(function(results){
			for(var i = 0; i < results.length; i++){
				connection = results[i];
				if(connection.valid){
					controller.setMaplink(connection.maplinkID,{
						floor: connection.floor,
						linkID: connection.connectionID,
						linkName: connection.linkName,
						location: connection.location,
						mapID: connection.mapID,
						mapName: connection.mapName,
						suite: connection.suite
					})
				} else {
					controller.removeMaplink(connection.maplinkID)
				}
			}
		})
		.catch(function(err){
			console.log(err);
		})
	}

	this.getMaplink = function(linkID){
		var linkObj = this.maplinks[linkID].getMaplink();
		var link = linkObj.link;
		var type = linkObj.type;
		if(link){
			switch(linkObj.type){
				case "StairsMaplink":
				case "DoorMaplink":
					swal({
					  title: "Office Navigation",
					  text: "You are about to navigate to a different map associated with this office.  Do you wish to continue?",
					  type: "question",
					  showCancelButton: true,
					  confirmButtonColor: "#525252",    
					  confirmButtonText: "Continue",
					  cancelButtonText: "Cancel",
					})
					.then(function(isConfirm){
						if(isConfirm === true){
							console.log('loading link')
							$Map.Viewer.viewFile({
								mapID:link.mapID,
								location:link.location,
								focus:{
									controller:"maplinks",
									id:link.linkID
								}
							})
						}
					})
					.catch(function(err){
						console.log(err);
					})
				break;
			}            
		}
	}

	//########################################  Room & Seat Reservations #############################################

	this.loadReservations = function(mapID){
		console.log('Loading Reservation Assignments')
		Connections.seatReservations = {};
		Connections.roomReservations = {};
		$.ajax({
			type:"GET",
			url: "/api/reservations/mapReservations/",
			data:{
				mapID:mapID
			},
			success: function(result){
				Connections.seatReservations = result.seatReservations || {};
				Connections.roomReservations = result.roomReservations || {};
				Connections.setReservations()
			}, // End of Success callback
			error: function(error){
				console.log('error loading reservations');
			}
		}) // End of AJAX Call        
	}

	this.setReservations = function(){
		var reservation,seatID,roomID, now;
		now = moment().valueOf();
		for(var i in Connections.seats){
			Connections.seats[i].setReservationToNull();
		}
		for(var i in Connections.rooms){
			Connections.rooms[i].setReservationToNull();
		}
		for(var i in Connections.seatReservations){
			reservation = Connections.seatReservations[i];
			seatID = reservation.seatID;
			if(now > reservation.start && now < reservation.end){
				Connections.seats[seatID].setReservation(reservation);
			}
		}
		for(var i in Connections.roomReservations){
			reservation = Connections.roomReservations[i];
			roomID = reservation.roomID;
			if(now > reservation.start && now < reservation.end){
				Connections.rooms[roomID].setReservation(reservation);
			}            
		}
		Connections.checkReservations();
	}

	this.checkReservations = function(){
		for(var i in Connections.seats){
			Connections.seats[i].checkReservation();
		}
		for(var i in Connections.rooms){
			Connections.rooms[i].checkReservation();
		}
	}

	this.getNextReservation = function(id,type){
		var res, earliest, earliestRes, now, len;
		var resList = [];
		if(type == 'Room'){
			for(var i in this.roomReservations){
				res = this.roomReservations[i];
				if(res.roomID == id){
					resList.push(res);
				}
			}
		} else if (type == 'Seat'){
			for(var i in this.seatReservations){
				res = this.seatReservations[i];
				if(res.seatID == id){
					resList.push(res);
				}
			}
		}
		now = moment().valueOf();
		len = resList.length;
		for(var i = 0; i < resList.length; i++){
			res = resList[i];
			if(res.end > now){
				if(earliest == undefined || res.start < earliest){
					earliest = res.start;
					earliestRes = res;
				}
			}
		}
		if(earliest){
			return earliestRes;
		} else {
			return null;
		}
	}

	this.getNextAvailability = function(id,type){
		var res, earliest, earliestRes, now, len;
		var resList = [];
		if(type == 'Room'){
			for(var i in this.roomReservations){
				res = this.roomReservations[i];
				if(res.roomID == id){
					resList.push(res);
				}
			}
		} else if (type == 'Seat'){
			for(var i in this.seatReservations){
				res = this.seatReservations[i];
				if(res.seatID == id){
					resList.push(res);
				}
			}
		}
		now = moment().valueOf();
		var current;
		for(var i in resList){
			res = resList[i];
			if(res.start <= now && res.end > now){
				current = res;
				break;
			}
		}
		var updated = true;
		var nextAvailable;
		while(true){
			if(updated == false){
				nextAvailable = current;
				break;
			} else {
				updated = false;
			}
			for(var i in resList){
				res = resList[i];
				if(res.resID == current.resID){continue;}
				if(res.start >= current.end && res.start - current.end < 60000){
					current = res;
					updated = true;
				}
			}
		}

		return nextAvailable.end;
	}

	//########################################  Seat Assignments ##################################################

	// Runs when a map is initially loaded.  Populates an assignments object and a users object with
	// existing seat assignment data.  This is the sole source of seat assignment data for a map file
	// on its initial load.
	this.loadSeatAssignments = function(mapID,callback){
		console.log('Loading Seat Assignments');

		$.ajax({
			type:"GET",
			url: "/api/seats/seat-assignments/"+mapID,
			success: function(result){
				Connections.seatAssignments = result.seatAssignments || {}; // Initial seat assignment population
				Connections.users = result.users || {}; // Initial user list population (only has users with assigned seats)
				var userID, seat;

				// Adds a seats array for each user in the users object
				for(var seatID in Connections.seatAssignments){
					userID = Connections.seatAssignments[seatID].userID;
					// If the assigned seat isn't on the map, mark that assignment for deletion in the database
					// This shouldn't generally happen
					if(Connections.seats[seatID] === undefined){
						Connections.seatAssignments[seatID] = {
							updateType:'delete',
							seatID: seatID,
							userID: null
						}
						continue;
					}
					
					seatName = Connections.seats[seatID].name;
					// Creates a seats array for each user containing the seats which they are assigned for this map
					if(Connections.users[userID] && Connections.users[userID].seats){ // True if user has multiple seats in map
						// This is because the seats array would have been created through a previous loop for a different seat
						Connections.users[userID].seats.push({
							mapName:mapName,
							seatID: seatID,
							seatName: seatName
						})
					} else {
						Connections.users[userID].seats = [{
							mapName:mapName,
							seatID: seatID,
							seatName: seatName
						}]
					}
				}

				// Actually loads the assignment data into the seat map objects
				for(var seatID in Connections.seats){
					if(Connections.seatAssignments[seatID]){ // True if a seat assignment exists for the seat
						userID = Connections.seatAssignments[seatID].userID;
						var user = Connections.users[userID];
						Connections.seats[seatID].setAssignment(user);
					}
				}

				if(callback){callback(null);}

			}, // End of Success callback
			error: function(error){
				console.log(error,'Error loading seat assignments');
				if(callback){callback(error);}
			}
		}) // End of AJAX Call 
	}

	this.assignSeat = function(seatID,userID,userData,updateType){
		// Saves the existing seatAssignment Object
		var oldAssignment;
		var assignment = this.seatAssignments[seatID]
		if(assignment){
			oldAssignment = {
				userID: assignment.userID,
				seatID: assignment.seatID,
				updateType: assignment.updateType				
			};
		}

		// An update type of 'move' removes the user from their previous seat, if they had one, and places
		// them in the new seat.  Other option is 'multi', which indicates that the user is
		// assigned to multiple seats across one or more maps.
		updateType = updateType || 'move'; // move is default
		
		// Overwrites the current seat assignment with the new assignment data
		// Or creates a new seat assignment if that seat was not assigned before
		console.log('update type:',updateType,seatID,userID)
		this.seatAssignments[seatID] = {
			userID:userID,
			seatID:seatID,
			updateType:updateType
		};

		var newAssignment = {
			userID:userID,
			seatID:seatID,
			updateType:updateType			
		}

		// The userData comes from an ajax populated list, and so this could be an individual who hadn't been in the
		// initial user data download. Defaults to the original data, unless the user wasn't initially loaded.
		// Don't need to undo/redo the user creation as it doesn't matter if a new user was added to the list
		this.users[userID] = this.users[userID] || userData;

		var seats = this.users[userID].seats;
		
		// Saves a copy of the existing seats array for the impacted user
		var oldSeats = [];
		for(var i in seats){
			oldSeats.push({
				mapName: seats[i].mapName,
				seatID: seats[i].seatID,
				seatName: seats[i].seatID
			})
		}

		var seat = this.seats[seatID];

		// If a user is moved from one seat to another, this finds their old seat (if it's in this map) and
		// clears the previous assignment.
		if(updateType == 'move'){
			// Removes all existing seat assignments for the user
			for(var i in seats){
				this.removeAssignment(seats[i].seatID);
			}

			// Adds new seat assignment which becomes the only one for the user
			this.users[userID].seats = [{
				mapName: mapName,
				seatID: seatID,
				seatName: seat.name
			}]

		// If a user simply has an additional seat assignment, then it is added to their seats list
		} else if (updateType == 'multi'){
			// Adds new seat assignment to the user's seats array
			this.users[userID].seats.push({
				mapName: mapName,
				seatID: seatID,
				seatName: seat.name
			})
		}

		seats = this.users[userID].seats;

		// Saves a copy of the new seat array for the impacted user
		var newSeats = [];
		for(var i in seats){
			newSeats.push({
				mapName: seats[i].mapName,
				seatID: seats[i].seatID,
				seatName: seats[i].name
			})
		}

		// Updates the seletected seat with the new user data
		this.seats[seatID].setAssignment(userData);

		var undo = this.createUndoSeatAssignPackage(oldAssignment,oldSeats,userID,seatID);
		var redo = this.createRedoSeatAssignPackage(newAssignment,newSeats,userID,seatID);

		// Pushes undo/redo packages to the state controller
		this.sendRemoveAssignmentPackages(undo,redo);
	}

	this.removeAssignment = function(seatID){
		var seatAssignment = this.seatAssignments[seatID];
		if(seatAssignment && this.seats[seatID]){ // Ensures the seat was assigned and the seat exists
			// Seat may not exist if there was an error in the save process and the seat was deleted
			
			// Removes the seat references from the array of assigned seats for the user
			// Needs to loop since it is an array of objects with seatID properties
			var userID = seatAssignment.userID;
			var seats = this.users[userID].seats;
			var seat;
			for(var i in seats){
				seat = seats[i];
				// Removes the seat from the seats array if it is the one being cleared
				if(seat.seatID == seatID){
					seats.splice(i,1);
					break;
				}
			}
			// The seat reference has been removed from the seats array, but seat reference still persists and is saved
			// in undo/redo process below.  This way, it can be added back to the array in an undo/redo scenario

			var originalAssignment = {
				userID:seatAssignment.userID,
				seatID:seatAssignment.seatID,
				updateType:seatAssignment.updateType
			}

			var newAssignment = {
				updateType:'delete',
				seatID: seatID,
				userID: null
			}

			// Updates the seat assignment for the seat to show that it is now unassigned
			// This is also used by the server to know when to delete a seat assignment
			this.seatAssignments[seatID] = {
				updateType:'delete',
				seatID: seatID,
				userID: null
			}

			// Stores the existing seat assignment data
			var redo = this.createRedoRemoveAssignmentPackage(newAssignment,userID,seat)
		
			// Stores the updated seat assignment data
			var undo = this.createUndoRemoveAssignmentPackage(originalAssignment,userID,seat)
			
			// Pushes undo/redo packages to the state controller
			this.sendRemoveAssignmentPackages(undo,redo);

			// Sets the new data on the actual seat object
			this.seats[seatID].resetAssignment();

		}
	}

	//########################################  Checking Area Contents ##################################################

	this.checkSeatsForRoom = function(){
		var pointList,seatPoint,room,seat;
		var roomsBySeat = {};
		if(this.controllers.rooms){ // If there is a rooms controller loaded, get the bounding points for the rooms
			pointList = this.controllers.rooms.getPointsLists(); // pointList is an array[by room] of arrays[room points]
		}

		// Creates an object 'rooms' on each seat object which is indexed by roomID, showing which rooms the seat is within
		for(var seatID in this.seats){
			seat = this.seats[seatID]; //alias the current seat
			seat.rooms = {}; // Clears any current room assignment data
			seatPoint = seat.getOutlinePoints()[0]; // Gets the location of the seat
			for(var roomID in pointList){ // Loops through the current rooms
				if(inside(seatPoint,pointList[roomID])){ // Checks if the point is inside the room
					room = this.rooms[roomID]; // alias the current room
					seat.rooms[roomID] = {
						roomName:room.name
					};
					if(roomsBySeat[seatID]){
						roomsBySeat[seatID][roomID] = {};
					} else{
						roomsBySeat[seatID] = {};
						roomsBySeat[seatID][roomID] = {};
					}
				}
			}
		}  

		// Creates an object 'seats' on each room object, indexed by seatID, showing which seats are in that room
		for(var roomID in this.rooms){
			var seatsByRoom = {};
			for(var seatID in roomsBySeat){
				if(roomsBySeat[seatID][roomID]){ // if the seat has the room
					seatsByRoom[seatID] = {
						seatName:this.seats[seatID].name,
						reservable:this.seats[seatID].reservable
					};
				}
			}
			this.rooms[roomID].seats = seatsByRoom;
		} 

		console.log("Finished Checking Seats/Rooms");
	}

	this.checkSeatsForZone = function(){
		var pointList,seatPoint,zone;
		var zonesBySeat = {};
		
		if(this.controllers.zones){
			pointList = this.controllers.zones.getPointsLists();
		}
		
		// Creates an object 'zones' on each seat object which is indexed by zoneID, showing which zones the seat is within
		for(var seatID in this.seats){
			this.seats[seatID].zones = {}; // Clears any current zone data
			seatPoint = this.seats[seatID].getOutlinePoints()[0]; // Gets the location of the seat
			for(var zoneID in pointList){ // Loops through the current zones
				if(inside(seatPoint,pointList[zoneID])){ // Checks if the point is inside the zone
					zone = this.zones[zoneID];
					this.seats[seatID].zones[zoneID] = {
						zoneName:zone.name,
						zoneID:zone.id
					};
					if(zonesBySeat[seatID]){
						zonesBySeat[seatID][zoneID] = {};
					} else{
						zonesBySeat[seatID] = {};
						zonesBySeat[seatID][zoneID] = {};
					}
				}
			}
		}

		// Creates an object 'seats' on each zone object, indexed by seatID, showing which seats are in that zone
		for(var zoneID in this.zones){
			var seatsByZone = {};
			for(var seatID in zonesBySeat){
				if(zonesBySeat[seatID][zoneID]){ // if the seat has the zone
					seatsByZone[seatID] = {
						seatName:this.seats[seatID].name,
						reservable:this.seats[seatID].reservable
					};
				}
			}
			this.zones[zoneID].seats = seatsByZone;
		} 

		console.log("Finished Checking Seats/Zones");
	}

	this.checkZonesForRoom = function(){
		var roomPointList,zonePointList,roomID,roomPoints,zoneID,zonePoints,inside;
		if(this.controllers.zones && this.controllers.rooms){
			roomPointList = this.controllers.rooms.getPointsLists();
			zonePointList = this.controllers.zones.getPointsLists();
		} else {
			return;
		}
		for(var zoneID in zonePointList){this.zones[zoneID].rooms = [];}
		for(var roomID in roomPointList){
			this.rooms[roomID].zones = [];
			roomPoints = roomPointList[roomID];
			for(var zoneID in zonePointList){
				zonePoints = zonePointList[zoneID];
				inside = fullyInside(roomPoints,zonePoints);
				if(inside){
					this.rooms[roomID].zones.push(this.zones[zoneID].id);
					this.zones[zoneID].rooms.push(this.rooms[roomID].id);
				}
			}
		}
		console.log("Finished Checking Rooms/Zones");
	}

	//########################################  Save / Load Functions ###################################################

	this.save = function(){
		console.log("Saving Connections")
		this.checkSeatsForZone();
		this.checkSeatsForRoom();
		this.checkZonesForRoom();
		var saveFile = {};
		saveFile.seats = {};
		saveFile.zones = {};
		saveFile.rooms = {};
		saveFile.kiosks = {};
		saveFile.seatAssignments = this.seatAssignments;
		for(var i in this.seats){
			saveFile.seats[i] = this.seats[i].saveData();
		}
		for(var i in this.zones){
			saveFile.zones[i] = this.zones[i].saveData();
		}
		for(var i in this.rooms){
			saveFile.rooms[i] = this.rooms[i].saveData();
		}
		for(var i in this.kiosks){
			saveFile.kiosks[i] = this.kiosks[i].saveData();
		}
		return saveFile;
	}

	//#################################  Object Undo/Redo Functions #####################################################

	this.loadPackage = function(package){
		switch(package.packageType){
			case "undo seat assignment":
				console.log('undoing seat assignment');
				console.log(package)
				if(package.seatAssignment){
					this.seatAssignments[package.seatID] = package.seatAssignment;
				} else {
					delete this.seatAssignments[package.seatID];
				}
				this.users[package.userID].seats = package.seatsArray;
			break;
			case "redo seat assignment":
				console.log('undoing seat assignment');
				console.log(package)
				this.seatAssignments[package.seatID] = package.seatAssignment;
				this.users[package.userID].seats = package.seatsArray;
			break;
			case "undo remove seat assign":
				// Updates the seat assignment back to the original seat assignment object
				this.seatAssignments[package.seat.seatID] = package.seatAssignment;
				// Adds seat back to the user's seat assignment array
				this.users[package.userID].seats.push(package.seat);
			break;
			case "redo remove seat assign":
				// Updates the seat assignment to the new cleared state
				this.seatAssignments[package.seat.seatID] = package.seatAssignment;
				// Removes the seat from the user's seat assignment array
				var seats = this.users[package.userID].seats;
				var seat;
				for(var i in seats){
					seat = seats[i];
					if(seat.seatID == package.seat.seatID){
						seats.splice(i,1);
						break;
					}
				}
			break;
		} 
	}

    this.sendRemoveAssignmentPackages = function(undo,redo){
		this.state.addUndoPackage(undo);
		this.state.addRedoPackage(redo);
    }

	this.createUndoRemoveAssignmentPackage = function(seatAssignment,userID,seat){
		var package = {};
		package.packageType = "undo remove seat assign";
		package.controller = "data";
		package.seatAssignment = seatAssignment;
		package.userID = userID;
		package.seat = seat;
		return package;
	}

	this.createRedoRemoveAssignmentPackage = function(seatAssignment,userID,seat){
		var package = {};
		package.packageType = "redo remove seat assign";
		package.controller = "data";
		package.seatAssignment = seatAssignment;
		package.userID = userID;
		package.seat = seat;
		return package;
	}

	this.createUndoSeatAssignPackage = function(seatAssignment,seatsArray,userID,seatID){
		var package = {};
		package.packageType = "undo seat assignment";
		package.controller = "data";
		package.seatAssignment = seatAssignment;
		package.seatsArray = seatsArray;
		package.userID = userID;
		package.seatID = seatID;
		return package;
	}

	this.createRedoSeatAssignPackage = function(seatAssignment,seatsArray,userID,seatID){
		var package = {};
		package.packageType = "redo seat assignment";
		package.controller = "data";
		package.seatAssignment = seatAssignment;
		package.seatsArray = seatsArray;
		package.userID = userID;
		package.seatID = seatID;
		return package;		
	}




}