//#################################  Settings Controller #####################################################

function SettingsController(id,mapName,map,minimap,unitSystem,officeID,instance,options){
	this.id = id;
    this.officeID = officeID;
    this.mapName = mapName;
    this.unitSystem = unitSystem || "US";
    this.floorNumber = options && options.floor ? options.floor : "";
    this.suiteNumber = options && options.suite ? options.suite : "";
    this.instance = instance; // Reference to the parent instance of the map
    this.map = map; // Map controller
    var currentMap = this.map;
	this.minimap = minimap; // Minimap Controller

    // Data saved to db on a 'save' or loaded on a 'load' event
    this.saveArray = [
        'id',
        'mapName',
        'floorNumber',
        'suiteNumber',
        'unitSystem',
        'officeID'
    ];

    this.save = function(){
        var file = {};
        var len = this.saveArray.length
        for(var i = 0;i < len;i++){
            file[this.saveArray[i]] = this[this.saveArray[i]];
        }
        return file;
    }

    this.load = function(file){
        var len = this.saveArray.length
        for(var i = 0;i < len;i++){
            this[this.saveArray[i]] = file[this.saveArray[i]];
        }
        Maptician.currentUnit = this.unitSystem;  
    }

    // **********************  Settings Object Setters *********************************

    this.setProperty = function(id,property,value){
        switch(property){
            case "objectName":
                this.setMapName(value);
            break;
            case "objectSystemType":
                this.setUnit(value);
            break;
            case "objectZoomLevel":
                this.setZoomLevel(value);
            break;
            case "objectGridLinesToggle":
                this.setGridLines(value);
            break;
            case "objectGridSpacing":
                this.setGridSpacing(value);
            break;
            case "objectSnapToggle":
                this.setSnapToGrid(value);
            break;
            case "objectFloorNo":
                this.setFloorNo(value);
            break;
            case "objectSuiteNo":
                this.setSuiteNo(value);
            break;
        }
    }

    this.setUnit = function(value){
        this.unitSystem = value;
        $Map.unit(value);
        this.instance.refreshLayers();
    }

    this.setZoomLevel = function(value){
        if(this.map.getZoomLevel() < value){
            var type = "out";
        } else {
            var type = "in";
        }
        this.map.getZoomLevel(value);
        this.map.zoomMap(type,this.minimap,"center");       
    }

    this.setGridSpacing = function(value){
        this.map.gridResolution(value);
        this.map.toggleGrid(this.map.gridToggle);    
    }

    this.setMapName = function(value){
        this.mapName = value;
        $("#"+this.id).html(this.mapName);        
    }

    this.setGridLines = function(value){
        this.map.toggleGrid(value);
    }

    this.setSnapToGrid = function(value){
        this.map.snapGridToggle(value);
    }

    this.setFloorNo = function(value){
        this.floorNumber = value;
    }

    this.setSuiteNo = function(value){
        this.suiteNumber = value;
    }

    // **********************  Settings Object Getters *********************************

    this.getProperties = function(){
        var thisData = {};
        thisData.data = {
            objectName: {type:"text",value:this.mapName},
            objectType: {type:"label",value:"Map"},
            objectLengthText: {type:"label",value:this.getFormattedMapLength()},
            objectWidthText: {type:"label",value:this.getFormattedMapWidth()},
            objectSystemType: {type:"drop-down",value:this.unitSystem},
            objectArea: {type:"label",value:this.getFormattedMapArea()},
            objectResizeMap: {type:"na",value:null},
            objectCropMap: {type:"na",value:null},
            objectZoomLevelText: {type:"na",value:this.slide(null,{value:this.getMapZoomLevel()})},
            objectZoomLevel: {
                type:"slider",
                value:this.getMapZoomLevel(),
                min:0,
                max:this.map.zoomScale.length-1,
                slide:this.slide
                },
            objectGridLinesToggle: {type:"switch",value:this.getGridToggleStatus()},
            objectSnapToggle: {type:"switch",value:this.getGridSnapStatus()},
            objectGridSpacing: {type:"spinner",value:renderLength(this.getGridResolution(),{system:this.unitSystem})},
            objectFloorNo: {type:"text",value:this.floorNumber},
            objectSuiteNo: {type:"text",value:this.suiteNumber},
        }
        thisData.dividers = {
            sizeDivider:true,
            zoomDivider:true,
            gridDivider:true,
            addressDivider:true
        }
        return thisData;
    }

    // This is sent with property data to be used when the user slides the zoom slider
    this.slide = function(event,ui){  
        $( "#objectZoomLevelText" ).html(toPercent(currentMap.zoomScale[ui.value],0));
    }

    this.getFormattedMapLength = function(optObj){
        var options, decimal;
        options = optObj || {};
        decimal = options.decimal || 2;
        return renderLength(this.map.originalHeight(),{system:this.unitSystem,decimal:decimal});
    }

    this.getFormattedMapWidth = function(optObj){
        var options, decimal;
        options = optObj || {};
        decimal = options.decimal || 2;
        return renderLength(this.map.originalWidth(),{system:this.unitSystem,decimal:decimal});
    }

    this.getFormattedMapArea = function(optObj){
        var options, decimal, area;
        options = optObj || {};
        decimal = options.decimal || 2;
        area = this.map.originalWidth() * this.map.originalHeight();
        return renderArea(area,{system:this.unitSystem,decimal:decimal});
    }

    this.getGridToggleStatus = function(){
        return this.map.getGridToggle();
    }

    this.getGridSnapStatus = function(){
        return this.map.getSnapGridActive();
    }

    this.getGridResolution = function(){
        return this.map.gridResolution();
    }

    this.getMapZoomLevel = function(){
        return this.map.getZoomLevel();
    }

    this.getID = function(){
        return this.id;
    }

    this.getMapName = function(){
        return this.mapName;
    }

    this.getOfficeID = function(){
        return this.officeID;
    }

    this.getUnitSystem = function(){
        return this.unitSystem;
    }

}