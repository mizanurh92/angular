//#################################  Minimap Controller #####################################################

function MiniMapController(map,options){
    options = options || {};
    this.type = options.type || "Editor";
    this.miniMap = options.miniMap || $("#miniMap"); // SVG which points to the map SVG as its image source (creates mini-map effect)
    this.viewBox = options.viewBox || $("#miniViewBox"); // SVG overlay on the minimap which indicates which portion the user is currently viewing
    this.miniMapContainer = options.miniMapContainer || $("#miniMapContainer");
    this.miniMapSVG = options.miniMapSVG || $("#miniMapSVG");
    this.map = options.map || $("#map");
    this.scale = 0;
    this.viewHandle = {x:0,y:0};
    this.viewCoord = {x:0,y:0};
    
    this.setMiniMap = function(){ // Determines the limiting dimension of the map and scales the minimap to set that dimension to 100% on the minimap
        var containerWidth = this.miniMapContainer.width();
        var containerHeight = this.miniMapContainer.height();
        var mapWidth = this.map.width();
        var mapHeight = this.map.height();
        var mapAspect = mapWidth/mapHeight;
        var containerAspect = containerWidth/containerHeight;
        if(mapAspect<containerAspect){  // Height constrained
            this.miniMap.css("height",containerHeight);
            this.miniMap.css("width",Math.round(containerHeight*mapAspect));
            this.miniMap.css("left",(containerWidth-this.miniMap.width())/2);
            this.miniMap.css("top",0);
        } else {   // Width constrained
            this.miniMap.css("width",containerWidth);
            this.miniMap.css("height",containerWidth/mapAspect);
            this.miniMap.css("top",(containerHeight-this.miniMap.height())/2);
            this.miniMap.css("left",0);
        }
    }
    this.setMiniMap();
    this.setScale = function(){ // Gets the viewbox units per pixel
        this.scale = this.miniMapSVG.attr('viewBox').split(" ")[2] / this.miniMap.width();
    }
    this.setScale();
    this.setMinimapView = function(){ // Function matches the mini-map viewbox with the current viewport for the user
        
        // Checks to see if the full map is shown on the current screen.  If so, the Mini-Map shaded overlay is made fully transparent
        if( (map.width() <= map.mapContainer.width()) && (map.height()+1 <= map.mapContainer.height()) ){
            this.viewBox.css({opacity:0.0})
        } else {
            this.viewBox.css({opacity:0.2})
        }

        var xView, yView;
        if(map.position().x<0) xView = -map.position().x / map.scale;
        if(map.position().y<0) yView = -map.position().y / map.scale;
        this.viewBox.attr({
            x: xView || 0,
            y: yView || 0,
            width: map.mapContainer.width() / map.scale,
            height: map.mapContainer.height() / map.scale
        });
    };
    this.setMinimapView();

    
    this.setViewCoords = function(){ // Sets the coordinates of the mouse over the miniMap in terms of the full map coordinate system
        this.viewCoord.x = this.scale * (map.currentMousePos.x-this.miniMap.position().left);
        this.viewCoord.y = this.scale * (map.currentMousePos.y-this.miniMap.position().top);
    }
    this.setViewHandle = function(state){ // Sets the offset handle for the viewbox (used when dragging the mini-map viewbox)
        this.setViewCoords(); // Sets the coordinates to the most up to date value
        this.viewHandle.x = this.viewCoord.x - this.viewBox.attr("x");
        this.viewHandle.y = this.viewCoord.y - this.viewBox.attr("y");
        state.setState("miniMapDrag");
    };

    this.moveViewHandle = function(state){ // Sets the offset handle for the viewbox (used when dragging the mini-map viewbox)
        var viewbox = this.viewBox[0].getBoundingClientRect();
        var xOffset = (this.miniMapContainer.outerWidth()-this.miniMap.width())/2;
        var yOffset = (this.miniMapContainer.outerHeight()-this.miniMap.height())/2;
        var x = this.scale * (map.currentMousePos.x - xOffset - viewbox.width/2);
        var y = this.scale * (map.currentMousePos.y - yOffset - viewbox.height/2);
        this.viewBox.attr({
            x:x,
            y:y
        });
        map.constrainedMove(
            -(x)*((map.map.width()/this.miniMap.width())/this.scale),
            -(y)*((map.map.height()/this.miniMap.height())/this.scale),
            this
        )
    };

    this.constrain = function(x,y){
        var coordinates = {x:0,y:0};
        if(x<-map.xMargin){
            coordinates.x = -map.xMargin;
        } else {
            if(x>this.miniMap.width()*this.scale-this.viewBox.attr("width")+map.xMargin){
                coordinates.x = this.miniMap.width()*this.scale-this.viewBox.attr("width")+map.xMargin;
            } else {
                coordinates.x = x;
            }
        }
        if(y<-map.yMargin){
            coordinates.y = -map.yMargin;
        } else {
            if(y>this.miniMap.height()*this.scale-this.viewBox.attr("height")+map.yMargin){
                coordinates.y = this.miniMap.height()*this.scale-this.viewBox.attr("height")+map.yMargin;
            } else {
                coordinates.y = y;
            }
        }
        return coordinates;
    }

    this.mouseDrag = function(map){
        this.setViewCoords();
        var coord = this.constrain(this.viewCoord.x - this.viewHandle.x,this.viewCoord.y - this.viewHandle.y);
        this.viewBox.attr({
            x:coord.x,
            y:coord.y
        });
        map.constrainedMove(
            -(this.viewCoord.x - this.viewHandle.x)*((map.map.width()/this.miniMap.width())/this.scale),
            -(this.viewCoord.y - this.viewHandle.y)*((map.map.height()/this.miniMap.height())/this.scale),
            this
        )
    }
}