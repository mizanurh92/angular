//#################################  Map Controller #####################################################

function MapController(width,height,type){
    // The map is a div contained in the mapContainer div but may be larger or smaller than its container
    // The map div contains two or more svg objects which display the visual components of the map
    this.type = type;
    this.map = $("#map");
    this.miniMap;
    this.mapSize = {width:width,length:height};
    this.mapContainer = new MapContainerController();
    this.xMargin = 20; // When the map is wider than the map container, this gives the max amount of the container to show when at the edge of the map
    this.yMargin = 20; // When the map is taller than the map container, this gives the max amount of the container to show when at the edge of the map
    this.snapGridActive = true;
    this.gridToggle = true;
    this.snapGridResolution = 12; // Each unit should be equal to one inch
    this.mapArrowStep = 20; // Number of pixels the map shifts per arror key press
    switch(type){
        case "Editor":
            this.zoomScale = MapEditorController.prototype.zoomScale;
        break;
        case "Viewer":
            this.zoomScale = MapViewerController.prototype.zoomScale;
        break;
        case "Kiosk":
            this.zoomScale = MapKioskController.prototype.zoomScale;
        break;
    }
    this.zoomLevel = 4;
    this.scale = 1;
    this.currentView = {};
    this.saveArray = [
        "originalDim",
        "currentView",
        "snapGridActive",
        "gridToggle",
        "snapGridResolution"
    ]
    this.dim = {
        height: this.map.height(),
        width: this.map.width()
    }
    this.currentMousePos = {
        x: 0,
        y: 0
    }
    this.handle = {
        x: 0,
        y: 0
    }
    this.pointer = {
        x: 0,
        y: 0
    }
    this.pos = {
        x: this.map.position().left,
        y: this.map.position().top
    }
    this.originalDim = { // Holds the dimensions in pixels of the original size of the map, which is used for the zoom level calculation
        // Basically acts as the official size at scale = 1 such that each unit here represents 1 inch
        height: this.map.height(),
        width: this.map.width()
    }

    // #########################################  Helper Functions #########################################

    // Attaches the miniMap object to the map controller.
    this.setMiniMap = function(miniMap){this.miniMap = miniMap;}

    this.setHandle = function(){ 
        this.position();
        this.handle.x = this.currentMousePos.x - this.pos.x;
        this.handle.y = this.currentMousePos.y - this.pos.y;
        return this.handle; // Note that this returns the screen position, not the map position
    }

    this.getZoomLevel = function(value){
        if(value){
            this.zoomLevel = value;
        }
        return this.zoomLevel;
    }

    this.pointerCoords = function(options){ // Note that this returns the map position of the mouse pointer
        options = options || {};
        options.snapRound = options.snapRound || false;
        this.position();
        if(options.snapRound){
            this.pointer.x = this.snapRound(((this.currentMousePos.x-this.pos.x)/this.scale));
            this.pointer.y = this.snapRound(((this.currentMousePos.y-this.pos.y)/this.scale));
        } else {
            this.pointer.x = ((this.currentMousePos.x-this.pos.x)/this.scale);
            this.pointer.y = ((this.currentMousePos.y-this.pos.y)/this.scale);            
        }
        return this.pointer;
    }

    // Position functions
    this.position = function(){ // Updates and returns the latest position data (x and y) for the map
        this.pos.x = this.map.position().left;
        this.pos.y = this.map.position().top;
        return {x:this.pos.x,y:this.pos.y};
    }
    this.x = function(){
        this.pos.x = this.map.position().left;
        return this.pos.x;
    }
    this.y = function(){
        this.pos.y = this.map.position().top;
        return this.pos.y;
    }

    // Dimension functions
    this.size = function(){
        this.dim.height = this.map.outerHeight(true);
        this.dim.width = this.map.outerWidth(true);
        return this.dim;
    }
    this.height = function(){
        this.dim.height = this.map.outerHeight(true);
        return this.dim.height;
    }
    this.width = function(){
        this.dim.width = this.map.outerWidth(true);
        return this.dim.width;
    }
    this.originalHeight = function(){
        return this.originalDim.height;
    }
    this.originalWidth = function(){
        return this.originalDim.width;
    }

    // #########################################  Save/Load Functions #########################################

    this.save = function(){
        var saveFile = {};
        this.saveView();
        for(var i = 0; i < this.saveArray.length;i++){
            saveFile[this.saveArray[i]] = this[this.saveArray[i]];
        }
        return saveFile;
    }

    this.load = function(saveFile){
        for(var i = 0; i < this.saveArray.length;i++){
            this[this.saveArray[i]] = saveFile[this.saveArray[i]];
        }
        this.setSnapGrid();
        this.reloadMap();
    }

    // Saves the current scale and map position for use in save/load and open file switching
    this.saveView = function(){
        // Gets the map location of the center of the container window
        // Also converts it to the map resolution scale
        this.currentView.mapCoordMiddleX = (this.mapContainer.width()/2-this.pos.x)/this.scale;  
        this.currentView.mapCoordMiddleY = (this.mapContainer.height()/2-this.pos.y)/this.scale;
        this.currentView.scale = this.scale;
        return {
            mapCoordMiddleX: this.currentView.mapCoordMiddleX,
            mapCoordMiddleY: this.currentView.mapCoordMiddleY,
            scale: this.currentView.scale
        }
    }

    // Changes the view to the one saved in currentView.  Typically used during the loading of the map or switching
    // between loaded maps.
    this.loadView = function(){
        var newWidth, newHeight, newMapCoordMiddleX, newMapCoordMiddleY, newMapPositionX, newMapPositionY, constrained;
        this.scale = this.currentView.scale;
        newWidth = this.originalDim.width * this.scale; // In screen pixels
        newHeight = this.originalDim.height * this.scale; // In screen pixels
        newMapCoordMiddleX = this.currentView.mapCoordMiddleX * this.scale;
        newMapCoordMiddleY = this.currentView.mapCoordMiddleY * this.scale;
        newMapPositionX = this.mapContainer.width()/2 - newMapCoordMiddleX;
        newMapPositionY = this.mapContainer.height()/2 - newMapCoordMiddleY;
        constrained = this.constrainMap(newMapPositionX,newMapPositionY,newWidth,newHeight);
        this.map.css({
            left:constrained.x+'px',
            top:constrained.y+'px',
            height:newHeight+"px",
            width:newWidth+"px"
        });
        this.scalePointHandle();
    }


    // #########################################  Map Navigation Functions #########################################

    // This is a helper function that takes point values for the upper left point of the map and the map's
    // current width and height.  It determines whether the allowable range of motion for the map has been
    // reached.  If it has been reached, the function returns the original values, modified to reflect these
    // limits.  If no constraints have been reached, the original values are returned unaltered.
    this.constrainMap = function(x,y,width,height){
        var constrained = {x: 0,y: 0}
        if(width>this.mapContainer.width()){
            constrained.x = Math.min(Math.max(x,this.mapContainer.width()-this.xMargin-width),this.xMargin);
        } else {
            constrained.x = Math.min(Math.max(x,0),this.mapContainer.width()-width);
        }
        if(height>this.mapContainer.height()){
            constrained.y = Math.min(Math.max(y,this.mapContainer.height()-this.yMargin-height),this.yMargin);
        } else {
            constrained.y = Math.min(Math.max(y,0),this.mapContainer.height()-height);
        }
        return constrained;
    }

    // This function is primarily used for map dragging events, either directly or through the mini-map
    // This does not use animation features, but rather adjusts the css values directly.  Also, the constrained
    // element means that the edge of the map cannot be dragged more than a set amount from the edge of the
    // view window.
    this.constrainedMove = function(x,y,miniMap){
        var constrained = this.constrainMap(x,y,this.width(),this.height());
        this.map.css({
            top:constrained.y+'px',
            left:constrained.x+'px',
        });
        miniMap.setMinimapView();
    }

    
    // ########################################  Map Animation Functions  ########################################
    // Some could also be considered navigation functions

    // Fits the map to the current map container based on the limiting dimension of the map
    // This is the function tied to the button inside the mini-map window
    this.fitMap = function(miniMap){ 
        var scaleConstraint, heightConstrained, newHeight, newWidth, newTop, newLeft;

        // Finishes any current animation actions for the map.  This is necessary because the animation actions must
        // occur based on the expected destination of the map, and not its position while in transit for a previous
        // animation.
        this.map.finish(); 

        // Determines whether, given the aspect ratio of the map, the constraining dimension is the width of the view
        // window or the height.  Also determines the map scale at which the constraining dimension and the constrained
        // size are equal.
        scaleConstraint = 1;
        if((this.mapContainer.height()/this.height()) >= (this.mapContainer.width()/this.width())){
            heightConstrained = false;
            scaleConstraint = this.mapContainer.width() / this.width();
        } else {
            heightConstrained = true;
            scaleConstraint = this.mapContainer.height() / this.height();
        }
        this.scale = this.scale * scaleConstraint; // Sets the new scale for the map based on the determined scale constraint
        
        // Since the zoom level slider in the object selector has set intervals and there is no guarantee that the zoom
        // necessary to fit the window will fall exactly at one of these intervals, this loop determines the closest interval
        // rounding down and sets the zoom level at this.  This really only affects the slider and will cause a tiny bit of 
        // over or under-correction when the user uses the slider next.
        for(var i = 0;i < this.zoomScale.length;i++){
            if(this.scale>this.zoomScale[i]){
                this.zoomLevel = i;
            } else {
                this.zoomLevel = i;
                break;}
        }

        // Sets the new map dimensions based on the constrained dimension and centers the map along the non-constrained dimension
        var newHeight = this.originalDim.height * this.scale;
        var newWidth = this.originalDim.width * this.scale;
        if(heightConstrained == true){
            newTop = 0;
            newLeft = (this.mapContainer.width() - newWidth)/2;
        } else {
            newLeft = 0;
            newTop = (this.mapContainer.height() - newHeight)/2;
        }

        // The animation function that accomplishes the view adjustment.  Note that velocity is an alternative to the native jQuery
        // animate function.  Syntax should be equivalent, but this should be smoother animation.
        this.map.velocity({
            top:newTop+'px',
            left:newLeft+'px',
            height:newHeight+"px",
            width:newWidth+"px",
        },{complete:function(){
            miniMap.setMinimapView(); // set minimap view as callback function for the animation
        }},{queue:false});
        this.scalePointHandle();
    }

    // Animates the movement of the map along either axis based on arrow key input.  Direction values are provided as -1, 0, and 1.
    this.animateMoveMap = function(xDir,yDir,miniMap){
        this.map.finish();
        var constrained = this.constrainMap(this.x()+xDir * this.mapArrowStep,this.y()+ yDir* this.mapArrowStep,this.width(),this.height());
        this.map.velocity({
            top:constrained.y+'px',
            left:constrained.x+'px',
            },
            {   
                queue:false,
                duration:80,
                easing: "linear",
                complete: function(){miniMap.setMinimapView()}
            }
        );
    }

    this.goToPoint = function(point){
        var map = this; // Alias this object for use in the callback
        var newWidth = this.originalDim.width * this.scale; // In screen pixels
        var newHeight = this.originalDim.height * this.scale; // In screen pixels
        var newMapCoordMiddleX = point.x * this.scale;
        var newMapCoordMiddleY = point.y * this.scale;
        var newMapPositionX = this.mapContainer.width()/2 - newMapCoordMiddleX;
        var newMapPositionY = this.mapContainer.height()/2 - newMapCoordMiddleY;
        var constrained = this.constrainMap(newMapPositionX,newMapPositionY,newWidth,newHeight);
        this.map.velocity({
            left:constrained.x+'px',
            top:constrained.y+'px',
            height:newHeight+"px",
            width:newWidth+"px"
        },{
            duration:350,
            complete: function(){
                map.miniMap.setMinimapView();
            }
        });
        this.scalePointHandle();  
    }

    this.zoomMap = function(type,miniMap,coordType){
        this.map.finish();
        var viewMiddleX, viewMiddleY, pointer, mapCoordMiddleX, mapCoordMiddleY, mouseX, mouseY;
        var screenPosXPoint, screenPosYPoint, newWidth, newHeight;

        if(type == "in" && this.zoomLevel != 14){this.zoomLevel++;}
        if(type == "out" && this.zoomLevel != 0){this.zoomLevel--;}

        viewMiddleX = this.mapContainer.width()/2; // Gets the center x point of the map container window
        viewMiddleY = this.mapContainer.height()/2; // Gets the center y point of the map container window

        if(coordType == "center"){ // Zooms in or out at the center of the view window
            mapCoordMiddleX = (viewMiddleX-this.pos.x)/this.scale;  // Gets the map location of the center of the container window
            mapCoordMiddleY = (viewMiddleY-this.pos.y)/this.scale;  // Also converts it to the map resolution scale
        } else if(coordType == "mouse") { // Zooms ino r out at the mouse coordinate point
            pointer = this.pointerCoords();
            mouseX = pointer.x;
            mouseY = pointer.y;
            mapCoordMiddleX = (mouseX*1 + this.pos.x*1/this.scale)/(this.mapContainer.width()/this.scale); // Mouse position as % of container window
            mapCoordMiddleY = (mouseY*1 + this.pos.y*1/this.scale)/(this.mapContainer.height()/this.scale);
            screenPosXPoint = mapCoordMiddleX * this.mapContainer.width(); // in pixels
            screenPosYPoint = mapCoordMiddleY * this.mapContainer.height(); // in pixels
        }

        this.scale = this.zoomScale[this.zoomLevel]; // In zoom percentage, greater than 1 represents zoom-in
        newWidth = this.originalDim.width * this.scale; // In screen pixels
        newHeight = this.originalDim.height * this.scale; // In screen pixels
        
        if(coordType == "center"){
            var newMapCoordMiddleX = mapCoordMiddleX * this.scale;
            var newMapCoordMiddleY = mapCoordMiddleY * this.scale;
            var newMapPositionX = viewMiddleX - newMapCoordMiddleX;
            var newMapPositionY = viewMiddleY - newMapCoordMiddleY;
        } else if(coordType == "mouse"){
            var XlocationInMapUnits = screenPosXPoint / this.scale;
            var YlocationInMapUnits = screenPosYPoint / this.scale;
            var upperLeftXOverflow = mouseX - XlocationInMapUnits;
            var upperLeftYOverflow = mouseY - YlocationInMapUnits;
            var upperLeftXOverflowPixels = this.scale * - upperLeftXOverflow;
            var upperLeftYOverflowPixels = this.scale * - upperLeftYOverflow;
            var newMapPositionX = upperLeftXOverflowPixels;
            var newMapPositionY = upperLeftYOverflowPixels;
        }

        // Constrains the map so that zoom doesn't shift it out of bounds
        var constrained = this.constrainMap(newMapPositionX,newMapPositionY,newWidth,newHeight);

        this.map.animate({
            left:constrained.x+'px',
            top:constrained.y+'px',
            height:newHeight+"px",
            width:newWidth+"px"
        },{
            easing:"linear",
            queue:true,
            duration:350,
            complete: function(){miniMap.setMinimapView();}
        });

        this.scalePointHandle();
    }

    // This function changes the size of the point handle objects on the map to be more consistent in size across zoom
    // events.  Otherwise the point handles would become too small or too large to use at various zoom levels
    this.scalePointHandle = function(){
        $("#map .pointHandle").attr({r:5/this.scale + this.scale/20,"stroke-width":1/this.scale})
    }

    // ############################################  Grid and Snap Functions ############################################

    // Acts as both a setter and toggle, depending on whether a value (boolean) is passed.
    this.snapGridToggle = function(value){
        this.snapGridActive = value || !this.snapGridActive;
        this.setSnapGrid();
        return this.snapGridActive;
    }

    this.getSnapGridActive = function(){
        return this.snapGridActive;
    }

    this.getGridToggle = function(){
        return this.gridToggle;
    }

    // Updates the snap grid button icon based on whether the snap grid is active
    this.setSnapGrid = function(){
        if(this.snapGridActive){
            $("#snap i").attr("class","fa fa-grid-on fa-lg");
        } else {
            $("#snap i").attr("class","fa fa-grid-off fa-lg");
        }        
    }

    // Toggles or sets the background grid for the map
    this.toggleGrid = function(value){ 
        this.gridToggle = value || !this.gridToggle;
        if(this.gridToggle){
            $("#gridPattern").attr({width:this.snapGridResolution,height:this.snapGridResolution});
            $("#mapBackground").css({fill:"url('#gridPattern')"});
        } else {
            $("#mapBackground").css({fill:"white"});
        }
    }

    this.gridResolution = function(value){
        if(value){
            this.snapGridResolution = value;
        }
        return this.snapGridResolution;
    }
    
    // Provides a rounding method tied to the map's snap grid resolution and whether the snap grid is active
    // Basically, this allows map objects to snap to the grid based on the map-wide parameters
    // Two optional parameters are override and useFloor
    // override allows for a different snap resolution to be used than the current global one - i.e. for greater precision
    // useFloor changes the rounding to round down to the lowest grid intersection (up and right), the default is to use the
    // more general rounding method that rounds up and down depending on the decimals
    this.snapRound = function(number,override,useFloor){
        // TODO use options pattern for inputs other than number
        if(this.snapGridActive){
            var resolution = override || this.snapGridResolution;
            if(useFloor){
                return Math.floor(number / resolution)*resolution;
            }
            return Math.round(number / resolution)*resolution;
        } else {
            return number;
        };
    }


    // ############################################  Map Modification Functions ############################################

    // Reloads the map and mini-map with the currently set original dimensions
    this.reloadMap = function(){
        var x, y;
        this.scale = 1; // Scale is set to 1 because we will be using the original dimensions which are based on a 1 scale
        x = this.originalDim.width;
        y = this.originalDim.height;
        if(type == 'Viewer'){
            document.getElementById("viewerMiniMapSVG").setAttribute("viewBox","0 0 "+x+" "+y);   
        } else if(type == 'Kiosk'){
            document.getElementById("kioskMiniMapSVG").setAttribute("viewBox","0 0 "+x+" "+y);
        } else {
            document.getElementById("miniMapSVG").setAttribute("viewBox","0 0 "+x+" "+y);            
        }
        document.getElementById("backgroundContainer").setAttribute("viewBox","0 0 "+x+" "+y);
        document.getElementById("mapDesigner").setAttribute("viewBox","0 0 "+x+" "+y);
        $("#map").css({width: x,height: y});
        this.dim.width = x;
        this.dim.height = y;   
        this.setSnapGrid();     
    }

    // Resizes the map and original dimensions based on the specified values.  This is used to permanently change the size of
    // the map.  
    this.resizeMap = function(width,height){
        this.originalDim.width = width;
        this.originalDim.height = height;
        this.reloadMap();
    }

    // Initializations that occur during the object construction process
    this.toggleGrid(true); // Initializes the grid on object creation
    this.resizeMap(width,height); // Automatically sets the map dimensions
}