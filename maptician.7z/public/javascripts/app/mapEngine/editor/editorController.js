function MapEditorController(){
    this.files = {};  // Object containing the open map editor documents - referenced by mapID
    this.currentFile = null; // Pointer holds a reference to the active map file
    this.hasInit = false;
    this.drawn = false;
    this.navBar = $("#rightNavBar");
    this.mapArea = $("#editorArea");
    this.quickStart = $("#editorStartOptions");
    this.fileMenu = $("#editorMenu");
    this.fileList = this.fileMenu.find('.files');
    this.map = $("#map");
    this.miniMap = $("#miniMap");
    this.miniMapContainer = $("#miniMapContainer");
    this.objectSelector = $("#objectSelector");
    this.document = $(document);
    var Editor = this;

    this.newFile = function(width,height,name,officeID,optObj){
        var options = optObj || {};
        var unitSystem = options.unitSystem || "US";
        var floor = options.floor || "";
        var suite = options.suite || "";
        $Map.unit(unitSystem); // Sets the unit system based on the input
        Object.keys(this.files).length ? null : this.showMapElements(); // Inits for first file load
        this.currentFile && this.currentFile.hide(); // Hides any currently open file
        var id = generateUUID(); // Creates a permanent unique identifier for the map
        this.files[id] = new MapEditorInstance(width,height,id,name,officeID,
                {unitSystem:unitSystem,floor:floor,suite:suite}
            ); // Creates new file object
        this.currentFile = this.files[id]; // Assigns newly created file object to the current file
        this.currentFile.state.startUndoRedo();
        this.apppendFile(id,name); // Adds file element to menu
        this.setLeftNav(); // Sets file element to 'selected'
        this.drawn = true;
    }

    this.loadFile = function(file,options){
        var options = options || {};
        var point = options.point || null;
        var focus = options.focus || null;
        var id = file.id;
        var name = file.name;
        Object.keys(this.files).length ? null : this.showMapElements(); // Inits for first file load
        // TODO might want some kind of confirmation if the file is already loaded and would be over-written
        this.files[id] ? this.files[id].clear() : this.apppendFile(id,name);
        this.currentFile && this.currentFile.hide();
        $Map.unit(file.settings.unitSystem || "US");
        this.files[id] = new MapEditorInstance(12,12,id,name); // Creates an empty map instance and adds it to file list
        this.currentFile = this.files[id]; // Sets the new map instance as currently active
        this.drawn = true;
        this.currentFile.load(file); // Loads the downloaded data onto the map instance
        this.setLeftNav();
        point && this.currentFile.goToPoint(point);
        focus && this.currentFile.controllers[focus.controller].selectOne(focus.id);
    }

    this.loadScenario = function(file){
        var id = file.scenarioID;
        var name = file.scenarioName;
        var mapName = file.settings.mapName;
        var mapID = file.id;
        Object.keys(this.files).length ? null : this.showMapElements(); // Inits for first file load
        // TODO might want some kind of confirmation if the file is already loaded and would be over-written
        this.files[id] ? this.files[id].clear() : this.apppendFile(id,name);
        this.currentFile && this.currentFile.hide();
        $Map.unit(file.settings.unitSystem || "US");
        this.files[id] = new MapEditorInstance(12,12,mapID,mapName); // Creates an empty map instance and adds it to file list
        this.currentFile = this.files[id]; // Sets the new map instance as currently active
        this.currentFile.loadScenario(file); // Loads the downloaded data onto the map instance
        this.drawn = true;
        this.setLeftNav();    
    }

    // General starting point for loading based on various available options.  Determines whether
    // the requested map is already loaded, if so, it directs the editor to that map, if the map
    // is not loaded, it downloads the map and then displays it.  Includes options for moving the
    // view window to a specified location and for activating an object based on controller name
    // and objectID
    this.viewFile = function(options){
        var mapID = options.mapID || null;
        var date = options.date || null;
        var location = options.location || null; // Point object {x:foo,y:bar}
        var focus = options.focus || null; // Should be an object with a {controller:foo,id:bar}
        var file = options.file || null;
        var data = {
            id: mapID,
            date: date
        }
        if(file){ // If a map file is passed, load the map file
            this.loadFile(file,{point:location,focus:focus});
            return;
        }
        if(mapID && date === null && this.files[mapID]){ // If the map is already loaded and a date isn't provided
            this.changeFile(mapID,{point:location,focus:focus});
            return;
        }
        if(mapID){ // File isn't available or a date was provided (so could be an earlier version)
            $.ajax({
                type:"GET",
                url: "/loadMapFile",
                data: data,
                success:function(file){
                    Editor.loadFile(file,{point:location,focus:focus});
                }
            })
        }
    }

    this.changeFile = function(id,options){
        var options = options || {};
        var point = options.point || null;
        var focus = options.focus || null;
        if(this.files[id]===undefined){ // Error catching for if the file isn't actually loaded
            console.log("Cannot find loaded file.");
            return;
        } 
        if(this.currentFile.getMapID() == id){
            if(point){
                this.currentFile.goToPoint(point);
            }
            return;
        }
        this.currentFile.hide();
        this.currentFile = this.files[id];
        $Map.unit(this.currentFile.getUnitSystem());
        this.currentFile.redraw();
        this.setLeftNav();
        if(focus){
            this.currentFile.controllers[focus.controller].selectOne(focus.id);
        }
        if(point){
            this.currentFile.goToPoint(point);
        }
    }


    this.hide = function(){
        if(this.drawn && this.currentFile){
            this.currentFile.hide();
            this.drawn = false;
        }
    }

    this.redraw = function(){
        if(!this.drawn && this.currentFile){
            this.currentFile.redraw();
            this.drawn = true;
            this.setLeftNav();      
        }
    }



    this.setLeftNav = function(){ // Ensures that only the currently selected file is 'selected'
        if(this.currentFile){
            var id = this.currentFile.getMapID();
            $(".lev-2",this.fileMenu).removeClass("selected");
            $("#"+id,this.fileMenu).parent().addClass("selected");
        }
    }

    this.apppendFile = function(id,name){
        if(this.fileList.css("display")=="none"){
            this.fileList.append("<li class='lev-2'><a id='"+id+"' href='#'>"+name+"</a></li>");
            this.fileList.parent().css({height:"45px"});
            this.fileList.hide();
        } else {
            this.fileList.append("<li class='lev-2'><a id='"+id+"' href='#'>"+name+"</a></li>");
        }
    }

    this.initializations = function(){ // Initialization required on load
        // Disables right click context menus for the map container area
        // TODO remove the getElement portion in production - this will completely disable contect menus
        this.mapArea.on("contextmenu",function(e){
            e.preventDefault();
        })

        $("#infoDiv").outerHeight(window.innerHeight 
            - $("#lowerRightSelectorPanel").outerHeight()
            - $("#miniMapContainer").outerHeight()
            - $("#systembarButtons").outerHeight()
            - $("#toolbarButtons").outerHeight()
            - $("#objectButtons").outerHeight()
            );
        
        $("#areasAccordion").accordion({heightStyle: "content"});

        $("#selectorAccordion").accordion({
            heightStyle: "content",
            collapsible: true
        });

        this.objectSelector.slimScroll({
                position: 'right',
                height:"auto",
                railVisible: true,
                alwaysVisible: false,
                color: "gray",
                disableFadeOut:true,
                distance:"8px"
        });

        $Map.inits.editorButtonControls(Editor);
        $Map.buttons.radioButtonBar("toolbarButtons",["openSelector","archSelector","mapSelector","furnSelector","seatSelector"]);
        $Map.buttons.buttonBar("systembarButtons");
        $Map.buttons.buttonBar("objectButtons");

    }

    this.setBindings = function(){
        this.map.on('mousedown.editor',function(event){
            if(Editor.isSet() && Editor.drawn){
                Editor.currentFile.mouseRouter.mapMouseDown(event);
            }
        })
        this.map.on('mousemove.editor',function(event){
            if(Editor.isSet() && Editor.drawn){            
                Editor.currentFile.mouseRouter.mapMouseMove(event);
            }
        })
        this.map.on('mouseenter.editor',function(event){
            if(Editor.isSet() && Editor.drawn){              
                Editor.currentFile.mouseRouter.mapMouseEnter(event);
            }
        })
        this.map.on('mouseleave.editor',function(event){
            if(Editor.isSet() && Editor.drawn){              
                Editor.currentFile.mouseRouter.mapMouseLeave(event);
            }
        })
        this.document.on('mousemove.editor',function(event){
            if(Editor.isSet() && Editor.drawn){
                Editor.currentFile.mouseRouter.documentMouseMove(event);
            }
        })
        this.document.on('mouseup.editor',function(event){
            if(Editor.isSet() && Editor.drawn){
                Editor.currentFile.mouseRouter.documentMouseUp(event);
            }
        })
        this.miniMapContainer.on('tap.editor tapstart.editor',function(event,touch){
            if(Editor.drawn){
                Editor.currentFile.mouseRouter.miniMapMouseDown(touch[0] || touch );
            }
        })
        this.miniMapContainer.on('mousemove.editor tapmove.editor',function(event,touch){
            if(Editor.drawn && Editor.drawn && touch){
                Editor.currentFile.mouseRouter.miniMapMouseMove(touch);
            }
        })
        this.miniMapContainer.on('tapend.editor',function(event){
            if(Editor.isSet() && Editor.drawn){
                Editor.currentFile.mouseRouter.documentMouseUp(event);
            }
        })
        $("svg",this.map).on("mousedown.editor",function(e){ // Mouse click binding for map objects
            if(e.which == 1 && Editor.isSet() && Editor.drawn){
                Editor.currentFile.mouseRouter.svgClickRouter.clicked(e.toElement.id,$(e.toElement),e.which,e.ctrlKey);            
            }
        })
        this.document.on("keydown.editor",function(event){ // Main keyboard interface router
            if(!$.modal.isActive() && Editor.isSet() && Editor.drawn){ // keyboard router is only used when modal menus aren't active
                Editor.currentFile.keyboardRouter.keyPress(event);
            }
        })
        this.document.on("keyup.editor",function(event){ // Main keyboard interface router
            if(!$.modal.isActive() && Editor.isSet() && Editor.drawn){ // keyboard router is only used when modal menus aren't active
                Editor.currentFile.keyboardRouter.keyUp(event);
            }
        })

        // ################### Map Navigation Bindings #######################
        
        this.map.on("dblclick.editor",throttle(function(e){  // Function that zooms the map in by a scalestep on doubleclick of the map
            if(e.ctrlKey && Editor.drawn){ // Only triggers on ctrl+scroll
                Editor.currentFile.map.zoomMap("in",Editor.currentFile.miniMap,"mouse");
            }
        },300,false));

        this.map.on('wheel.editor',throttle(function(e){  // Controls zooming via scroll wheel
            if(e.ctrlKey && Editor.drawn){ // Only triggers on ctrl+scroll
                if(e.originalEvent.deltaY<0){
                    Editor.currentFile.map.zoomMap("in",Editor.currentFile.miniMap,"mouse");} 
                else {
                    Editor.currentFile.map.zoomMap("out",Editor.currentFile.miniMap,"mouse");
                }
            }
        },300,false));

        this.document.on("keydown.editor",throttle(function(e){ // Controls zoom-in and out via the plus and minus keys
            if(!Editor.currentFile){return;}
            var currentFile = Editor.currentFile;
            var map = currentFile.map;
            var miniMap = currentFile.miniMap;

            if(!$.modal.isActive() && Editor.drawn && currentFile.objectSelector.selectorActive == false){
                switch(e.which){
                    case 107: // Plus Key
                        map.zoomMap("in",miniMap,"center");
                    break;
                    case 109: // Minus Key
                        map.zoomMap("out",miniMap,"center");
                    break;
                };
            }
        },400,true));
    
        this.document.on("keydown.editor",throttle(function(e){
            if(!Editor.currentFile){return;}
            var currentFile = Editor.currentFile;
            var map = currentFile.map;
            var miniMap = currentFile.miniMap;

            if(!$.modal.isActive() && Editor.drawn && currentFile.objectSelector.selectorActive == false){ 
                // Keys will not pan the screen when the object selector is active
                if(currentFile.state.state == "openSelector" && !currentFile.objectsSelected()){
                    // Checks whether map objects are selected and disables map pan if true
                    switch(e.which){ // note that the map moves in the opposite direction of the arrow press
                        case 37:
                            map.animateMoveMap(1,0,miniMap);
                        break;
                        case 38:
                            map.animateMoveMap(0,1,miniMap);
                        break;
                        case 39:
                            map.animateMoveMap(-1,0,miniMap);
                        break;
                        case 40:
                            map.animateMoveMap(0,-1,miniMap);
                        break;
                    }
                }
            }
            return false; // prevents the default action for the key events
        },83,true)) // Throttle the map move so that the animation is roughly continuous while the button is down
    }

    this.unsetBindings = function(){
        this.map.off('.editor');
        this.document.off('.editor');
        this.miniMapContainer.off('.editor');
        $("svg",this.map).off('.editor');
    }

    this.objectSelectorBindings = function(){
        // Activates the object selector window.  Basically preventing map keyboard commands from triggering while active.
        this.objectSelector.on("mousedown",function(){
            Editor.currentFile.objectSelector.activateSelectorWindow();
        })

        var selectorInput = $(".selectorInput",this.objectSelector);

        // This is necessary for text boxes which need to update as they are typed
        // Not using this means that the contents will be lost upon loss of focus
        // These inputs are designated with textInput class, to distinguish from inputs which should be
        // finalized more formally (i.e. coordinates shouldn't update until the number is finished)
        selectorInput.filter('.textInput').on("input",function(e,ui){ 
            Editor.currentFile.objectSelector.propertyChange(this,e);
        })

        selectorInput.filter(':not(.distance)').on("change",function(e){ // Binds an event to the selector inputs with .selectorInput class triggering on value change
            Editor.currentFile.objectSelector.propertyChange(this,e);
        })

        selectorInput.on("spin",function(e,ui){ // Binds an event to the selector inputs with .selectorInput class triggering on spinner spin
            Editor.currentFile.objectSelector.propertyChange(this,e,ui);
        })

        selectorInput.filter('.distance').on("spinstart",function(e,ui){ // Binds an event to the selector inputs with .selectorInput class triggering on spinner spin
            var event = e.originalEvent.which;
            var spinKeys = [13,33,34,38,40];
            if($.inArray(event,spinKeys) != -1 || $(e.originalEvent.currentTarget).hasClass("ui-spinner-button")){
                var target = $(e.currentTarget);
                var unparsed = target.val();
                var parsed = parseToInches(unparsed);
                target.val(parsed);                
            }
        })

        selectorInput.filter('.distance').on("spinstop",function(e,ui){ // Binds an event to the selector inputs with .selectorInput class triggering on spinner spin
            try{
                var event = e.originalEvent.which;
                var spinKeys = [13,33,34,38,40];
                if($.inArray(event,spinKeys) != -1 || $(e.originalEvent.currentTarget).hasClass("ui-spinner-button")){
                    var target = $(e.currentTarget);
                    var inches = target.val();
                    var unitSystem = Editor.currentFile.getUnitSystem();
                    var decimal = unitSystem == "Metric" ? 2 : 0;
                    var formatted = renderLength(parseToInches(inches),{system:unitSystem,decimal:decimal});
                    target.val(formatted);               
                }               
            } catch(_){}
        })

        selectorInput.filter('.distance').on("change",function(e){ // Binds an event to the selector inputs with .selectorInput class triggering on value change
            var target = $(e.currentTarget);
            var unparsed = target.val();
            var parsed = parseToInches(unparsed);
            target.val(parsed);
            Editor.currentFile.objectSelector.propertyChange(this,e);
        })

        selectorInput.on("slide",function(e,ui){ // Binds an event to the selector inputs with .selectorInput class triggering on slider slide
            console.log("slide");
            if(Editor.isSet()){
                Editor.currentFile.objectSelector.propertyChange(this,e,ui);
            }
        })

        selectorInput.on("ifChecked",function(e,ui){ // Binds an event to the selector inputs with .selectorInput class triggering on slider slide
            if(Editor.isSet()){
                var thisInput = $(this);
                var checkedList = [thisInput.attr("data")];
                thisInput.closest("li").siblings().find(".checked input").each(function(){
                    checkedList.push($(this).attr("data"));
                })
                var objHolder = {};
                objHolder.id = thisInput.closest("ul")[0].id;
                objHolder.type = "checkList";
                Editor.currentFile.objectSelector.propertyChange(objHolder,checkedList);
            }
        })

        selectorInput.on("ifUnchecked",function(e,ui){ // Binds an event to the selector inputs with .selectorInput class triggering on slider slide
            if(Editor.isSet()){
                var thisInput = $(this);
                var checkedList = [];
                thisInput.closest("li").siblings().find(".checked input").each(function(){
                    checkedList.push($(this).attr("data"));
                })
                var index = checkedList.indexOf(thisInput.attr("data"));
                if(index > -1){
                    checkedList.splice(index,1);
                }
                var objHolder = {};
                objHolder.id = thisInput.closest("ul")[0].id;
                objHolder.type = "checkList";
                Editor.currentFile.objectSelector.propertyChange(objHolder,checkedList);
            }
        })

        this.objectSelector.find('.checkListHeader').on("click",function(){
            var header = $(this);
            var chevron = (header.children("span"));
            header.siblings().toggle();
            if(chevron.hasClass("fa-chevron-down")){
                chevron.removeClass("fa-chevron-down").addClass("fa-chevron-right");
            } else {
                chevron.removeClass("fa-chevron-right").addClass("fa-chevron-down");
            }
        })
    }

    this.screenSizeBindings = function(){  // Controls map area and navbar sizes and positions on resize
        $(window).resize(function(){
            $("#infoDiv").outerHeight(window.innerHeight 
                - $("#lowerRightSelectorPanel").outerHeight()
                - $("#miniMapContainer").outerHeight()
                - $("#systembarButtons").outerHeight()
                - $("#toolbarButtons").outerHeight()
                - $("#objectButtons").outerHeight()
                );
            // Updates map position on window resize so that it doesn't get positioned outside of bounds
            if(Editor.isSet()){
                Editor.currentFile.map.constrainedMove(
                    Editor.currentFile.map.x(),
                    Editor.currentFile.map.y(),
                    Editor.currentFile.miniMap
                    );
            }
            $('#objectSelector').slimScroll({
                position: 'right',
                height:"auto",
                railVisible: true,
                alwaysVisible: false,
                color: "#51BCFA",
                disableFadeOut:true
            });
        });

        $("#fitMap").click(function(){ // Handles fitMap button on miniMap
            if(Editor.drawn){
                Editor.currentFile.map.fitMap(Editor.currentFile.miniMap);
            }
        }) 
    }

    this.architectureButtonBindings = function(){
        $("#drawColumn").click(function(){Editor.currentFile.state.setState("createColumn");})
        $("#drawSink").click(function(){Editor.currentFile.state.setState("drawSink");})
        $("#drawToilet").click(function(){Editor.currentFile.state.setState("drawToilet");})
        $("#drawElevator").click(function(){Editor.currentFile.state.setState("createElevator");})
        $("#drawStairs").click(function(){Editor.currentFile.state.setState("createStairs");})
        $("#drawWall").click(function(){Editor.currentFile.state.setState("createWall");})
        $("#addDoor").click(function(){
            var currentFile = Editor.currentFile;
            currentFile.state.triggerNewRevisionStep();
            currentFile.controllers.architect.addSubcategory("Door");
        })
        $("#addWindow").click(function(){
            var currentFile = Editor.currentFile;
            currentFile.state.triggerNewRevisionStep();
            currentFile.controllers.architect.addSubcategory("Window");
        })
    }

    this.zoneButtonBindings = function(){
        $("#setZone").click(function(){Editor.currentFile.state.setState("drawZone");}) 
        $("#zoneBox").click(function(){Editor.currentFile.state.setState("drawZoneBox");}) 
        $("#moveZone").click(function(){Editor.currentFile.state.setState("moveZone");}) 
        $("#zonePoint").click(function(){Editor.currentFile.controllers.zones.addNewPoint();})
        $("#wallZone").click(function(){
            var currentFile = Editor.currentFile;
            currentFile.state.triggerNewRevisionStep();
            currentFile.controllers.zones.checkWallZone(currentFile.architect);
        })        
    }

    this.roomButtonBindings = function(){
        $("#setRoom").click(function(){Editor.currentFile.state.setState("drawRoom");})
        $("#roomBox").click(function(){Editor.currentFile.state.setState("drawRoomBox");})
        $("#moveRoom").click(function(){Editor.currentFile.state.setState("moveRoom");})
        $("#roomPoint").click(function(){Editor.currentFile.controllers.rooms.addNewPoint();})
        $("#wallRoom").click(function(){Editor.currentFile.state.setState({type:'auto room'});})
    }

    this.furnitureButtonBindings = function(){
        $("#addDesk").click(function(){
            if(Editor.currentFile){
                Editor.currentFile.state.setState({type:'placeFurniture',subtype:'Desk'});
            }
        })
        $("#addLDesk").click(function(){
            if(Editor.currentFile){
                Editor.currentFile.state.setState({type:'placeFurniture',subtype:'LDesk'});
            }
        })
        $("#addTable").click(function(){
            if(Editor.currentFile){
                Editor.currentFile.state.setState({type:'placeFurniture',subtype:'Table'});
            }
        })
        $("#addCubicle").click(function(){
            if(Editor.currentFile){
                Editor.currentFile.state.setState({type:'placeFurniture',subtype:'Cubicle'});
            }
        })
        $("#addCubicleEntrance").click(function(){
            if(Editor.currentFile){
                var currentFile = Editor.currentFile;
                currentFile.state.triggerNewRevisionStep();
                currentFile.controllers.furniture.addSubObject("CubicleEntrance","Cubicle");
                currentFile.state.setState({status:'placeFurnitureSubobject',subtype:'CubicleEntrance'});
            }
        })
    }

    this.seatButtonBindings = function(){
        $("#addSeat").click(function(){
            if(Editor.currentFile){
                Editor.currentFile.state.setState('placeSeat');
            }
        })

        $("#objectAssignSeat").click(function(){
            if(Editor.currentFile){
                var officeID = Editor.currentFile.getOfficeID();
                Editor.assignUserTable = Maptician.Editor.assignUserTable || 
                    new $Map.Components.Editor.AssignUserTable();
                var seatDept;
                try{
                    var seatID = Editor.currentFile.objectSelector.selected.id;
                    seatDept = Editor.currentFile.controllers.seats.objects[seatID].department.deptName;
                } catch(err){}
                Editor.assignUserTable.open(officeID,seatDept);
            }
        })

        $("#objectUnassignSeat").click(function(){
            if(Editor.currentFile){
                var seatID = Editor.currentFile.objectSelector.selected.id;
                Editor.currentFile.dataConnections.removeAssignment(seatID);
            }
        })

        $("#objectReservableSeat").click(function(){
            if(Editor.currentFile){
                var currentFile = Editor.currentFile;
                var seatID = currentFile.objectSelector.selected.id;
                currentFile.dataConnections.removeAssignment(seatID);
                currentFile.dataConnections.seats[seatID].toggleReservable();
                currentFile.objectSelector.updateSelector();
            }            
        })

        $("#addKiosk").click(function(){
            if(Editor.currentFile){
                Editor.currentFile.state.setState('placeKiosk');
            }
        })

        $("#addStairsMaplink").click(function(){
            if(Editor.currentFile){
                Editor.currentFile.state.setState({action:'placeMaplink',type:'StairsMaplink'});
            }
        })

        $("#addDoorMaplink").click(function(){
            if(Editor.currentFile){
                Editor.currentFile.state.setState({action:'placeMaplink',type:'DoorMaplink'});
            }
        })

        $("#addElevatorMaplink").click(function(){
            if(Editor.currentFile){
                Editor.currentFile.state.setState({action:'placeMaplink',type:'ElevatorMaplink'});
            }
        })

        $("#objectSetConnection").click(function(){
            if(Editor.currentFile){
                var currentFile = Editor.currentFile;
                var officeID = currentFile.getOfficeID();
                var mapID = currentFile.getMapID();
                var maplinkID = currentFile.controllers.maplinks.selected[0];
                var type = currentFile.controllers.maplinks.objects[maplinkID].type;
                $Map.ModalTables.setMaplinkTable(officeID,mapID,maplinkID,type);
            }
        })

        $("#objectClearConnection").click(function(){
            if(Editor.currentFile){
                var currentFile = Editor.currentFile;
                var maplinkID = currentFile.controllers.maplinks.selected[0];
                currentFile.dataConnections.removeMaplink(maplinkID);
                currentFile.objectSelector.updateSelector();
            }
        })
        $("#addEmployee").click(function(){Editor.currentFile.state.setState('placeEmployee');})
    }

    this.selectorBindings = function(){ // Handles the selector checkboxes and enables/disables based on parent status
        $('#selectorAccordion input').each(function(){
            var self = $(this),
            label = self.next(),
            label_text = label.text();
            label.remove();
            self.iCheck({
              checkboxClass: 'icheckbox_line-blue',
              radioClass: 'iradio_line-blue',
              insert: '<div class="icheck_line-icon"></div>' + label_text
            });
        });

        $('#objectRoomEquipment,#objectRoomAccess,#objectRoomAmeneties').find('input').each(function(){
            $(this).iCheck({checkboxClass: 'icheckbox_polaris'});
        });

        $("#layerFilters input").on('ifChecked',function(){
            if(Editor.currentFile){
                Editor.currentFile.setLayerVisibility($(this).attr("data"),'checked');
            }
        })

        $("#layerFilters input").on('ifUnchecked',function(){
            if(Editor.currentFile){
                Editor.currentFile.setLayerVisibility($(this).attr("data"),'unchecked');
            }
        })
        $('#selectorAccordion>ul>li>div>input').on('ifChecked', function(event){
            $(event.target).parent().parent().find(".sublist input").iCheck("enable")
        });

        $('#selectorAccordion>ul>li>div>input').on('ifUnchecked', function(event){
            $(event.target).parent().parent().find(".sublist input").iCheck("disable")
        });

        $('#objectResizeMap').click(function(){
            if(Editor.currentFile){
                Maptician.components.resizeMap();
            }
        })

        $('#objectCropMap').click(function(){
            if(Editor.currentFile){
                Maptician.components.cropMap();
            }
        })
    }

    this.objectButtonBindings = function(){ // Handles Delete/Duplicate/Undo/Redo/Snap-to-Grid functions

        $("#delete").click(function(){
            if(Editor.isSet()){
                Editor.currentFile.keyboardRouter.keyPress({which:46}); // Treats the click like a delete key press
            }
        })

        $("#duplicate").click(function(){
            if(Editor.isSet()){
                Editor.currentFile.state.triggerNewRevisionStep();
                for(var controller in Editor.currentFile.controllers){
                    Editor.currentFile.controllers[controller].duplicate(
                        Editor.currentFile.dataConnections
                        );
                }
            }
        })

        $("#undo").click(function(){
            if(Editor.isSet()){
                Editor.currentFile.state.undo(Editor.currentFile.controllers);
            }
        })

        $("#redo").click(function(){
            if(Editor.isSet()){
                Editor.currentFile.state.redo(Editor.currentFile.controllers);
            }
        })

        $("#snap").click(function(){
            if(Editor.isSet()){
                if(Editor.currentFile.map.snapGridToggle()){
                    $("#snap i").removeClass("fa-grid-off");
                    $("#snap i").addClass("fa-grid-on");
                } else {
                    $("#snap i").removeClass("fa-grid-on");
                    $("#snap i").addClass("fa-grid-off");               
                }
            }
        })
    }

    this.closeFile = function(){
        if(this.isSet()){
            var newFileID;
            var currentFileID = this.currentFile.isScenario() ? this.currentFile.scenarioID : this.currentFile.getMapID();
            var openFiles = $("#editorMenu li a");
            var len = openFiles.length;
            this.currentFile.clear();
            for(var i = 0;i < len;i++){ // Checks if there are any open files without the closed file id
                if(openFiles[i].id != currentFileID){
                    newFileID = openFiles[i].id;
                    break;
                }
            }
            console.log('newFileID',newFileID)
            if(newFileID){ // If other files are open, changes the active file to the first in the list
                this.changeFile(newFileID);
            } else { // If no other files are open, reverts to quick start mode
                this.hideMapElements();
                $("#editorStartOptions").show();
                this.currentFile = undefined;
                this.drawn = false;
            }
            delete this.files[currentFileID];
            for(var i = 0;i < len;i++){ // Removes the li in the left nav
                if(openFiles[i].id == currentFileID){
                    $(openFiles[i]).parent().remove();
                    break;
                }
            }
            this.setLeftNav();
        }
    }

    this.saveMap = function(){
        if(this.isSet()){
            var fileObject = this.currentFile.save();
            var data = {data:JSON.stringify(fileObject)};
            console.log('Data to save:',data)
            if(fileObject.scenario){
                $.ajax({
                    type:"POST",
                    url: "api/scenarios/saveScenario",
                    data:data,
                    dataType:'json',
                    success:function(result){
                        console.log('Save Successful:',result)
                    }
                })  
            } else {
                $.ajax({type:"POST",url: "/savemap",data:data,dataType:'json',success:function(result){
                    console.log('Save Successful:',result)}
                })                
            }
        } 
    }

    this.branchMap = function(){
        if(this.isSet()){
            this.currentFile.hide(); // Removes all screen svg for the current file
            var id = generateUUID(); // Creates unique identifier for the map
            var file = this.currentFile.save(); // Saves the file content for branching - doesn't save current file
            var name = this.currentFile.getName() + "(copy)";
            this.files[id] = new MapEditorInstance(10,10,id,name);
            this.currentFile = this.files[id];
            $("#files").append("<li class='lev-2'><a id='"+id+"' href='#'>"+name+"</a></li>");
            this.currentFile.load(file);
        }
    }

    this.branchScenario = function(){
        var that = this;
        if(this.isSet()){
            
            swal.setDefaults({
              confirmButtonText: 'Next &rarr;',
              showCancelButton: true,
              animation: false,
              allowOutsideClick: false,
              progressSteps: ['1', '2', '3']
            })

            var steps = [
              {
                type:'info',
                title: 'Branch a Scenario',
                html: '<p>Banching a scenario is useful you want to test layout or assignment changes without impacting' +
                    ' the current map.  Once you have found the desired configuration, you can then set the scenario' +
                    ' to go "live".  This will overwrite the existing map and implement the scenario in its place.</p>' +
                    ' <p>You can branch multiple scenarios off a map, allowing you to select amongst the best of multiple' +
                    ' options.  You can also branch a scenario off a scenario and either can go live for the original map.</p>'
              },
              {
                type:'question',
                title: 'Scenario Name',
                html: '<p>Scenarios are identifiable by a scenario name as well as by their map name.  Since you can have' +
                    ' multiple scenarios available for a map, it is important to be able to distinguish between them.</p>' +
                    '<p>Please enter a name for this scenario below:</p>',
                input:'text',
                inputValidator:function(value){
                    return new Promise(function(resolve,reject){
                        if(value){
                            resolve();
                        } else {
                            reject('Please enter a name for your scenario.')
                        }
                    })
                }
              },
              {
                type:'question',
                title: 'Number of Branches',
                html: '<p>You can create multiple scenarios of a map at the same time.  This is useful when multiple configuration' +
                    ' options should be compared against one another.</p>' +
                    ' <p>Note: <i>If there are common parts of the expected options, it may save time to branch further scenarios ' +
                    ' only after all the common elements have been added.</i></p>' +
                    ' <p>How many scenarios should be created right now?</p>',
                input: 'range',
                inputAttributes: {
                    min:1,
                    max:5,
                    step:1
                },
                inputValue:1
              }
            ]

            swal.queue(steps)
            .then(function(result){
              swal.resetDefaults();
              var name = result[1];
              var count = result[2];
              var message;
              that.currentFile.hide(); // Removes all screen svg for the current file
              var file = that.currentFile.save(); // Saves the file content for branching - doesn't save current file
              file.connections = file.dataConnections; // sets an alias
              var id = file.id; // mapID for the scenario
              var mapName = that.currentFile.getName(); // mapName for the scenario
              for(var i = 0;i < count;i++){
                console.log('calling branch')
                branch(file,id,mapName,name,i,count);
              }
              console.log('finished loop')
              that.currentFile.redraw(); // Redraws all screen svg for the current file
              if(count > 1){
                message = "Your scenarios have been created and saved.";
              } else {
                message = "Your scenario has been created and saved.";
              }
              return swal({
                title: 'All done!',
                html: message,
                confirmButtonText: 'OK'
              })
            })
            .catch(function(err){
                console.log(err);
            });

            var branch = function(file,id,mapName,name,count,total){
                var scenarioID = generateUUID(); // Creates unique identifier for the scenario
                file.live = false;
                file.scenario = true;
                file.scenarioID = scenarioID;
                if(total>1){
                    file.scenarioName = name + " " + (count+1);
                } else {
                    file.scenarioName = name;
                }
                that.files[scenarioID] = new MapEditorInstance(10,10,id,mapName);
                $("#editorMenu .files").append("<li class='lev-2'>" + "<a id='" + scenarioID + "' href='#'>" +
                    "<i class='fa fa-flow-tree' style='font-size: 15px;''></i>" + file.scenarioName +
                    "</a></li>");
                that.files[scenarioID].loadScenario(file);
                that.files[scenarioID].hide(); // Removes all screen svg for the created scenario file
            }
        }        
    }

    this.toggleLive = function(){
        var that = this;
        if(this.isSet()){
            if(this.currentFile.isScenario()){
                swal.setDefaults({
                  showCancelButton: true,
                  animation: false,
                  allowOutsideClick: false,
                  progressSteps: ['1', '2']
                })

                var steps = [
                  {
                    type:'info',
                    title: 'Implementing a Scenario',
                    confirmButtonText: 'Continue',
                    html: '<p>Implementing a scenario will overwrite the original map with the current scenario.' +
                        ' This will also remove the current scenario from the scenario list.</p>' +
                        ' <p><b>Note:</b> Once a scenario has been implemented, some changes (such as changes in seat assignments)' +
                        ' cannot be easily undone.</p>' +
                        ' <p>Do you wish to proceed with the implementation process?</p>'
                  },
                  {
                    type:'question',
                    title: 'Scenario Active Mode',
                    html: '<p>You have the option of having the scenario implement in "active mode" or "inactive mode".</p>' +
                        '  <p>If the scenario is implemented in active mode, then the map and all its active elements' +
                        ' (seats/assignents/etc.) will go live immediately for all users.</p>' +
                        ' <p>If you choose to implement the scenario in inactive mode, the map and its elements will not be' +
                        ' public until you choose to activate it manually.</p>' +
                        '<p>How should the scenario be implemented?</p>',
                    input: 'radio',
                    inputOptions:{
                      true: 'Active Mode',
                      false: 'Inactive Mode',
                    },
                    inputValue: 'true',
                    confirmButtonText: 'Ok',
                    inputValidator:function(value){
                        return new Promise(function (resolve, reject) {
                          if (value) {
                            resolve()
                          } else {
                            reject('You must select an option.')
                          }
                        })
                    }
                  }
                ]

                swal.queue(steps)
                .then(function(result){
                    swal.resetDefaults();
                    $Map.Editor.currentFile.updateLive(result[1] == "true");
                    var file = that.currentFile.save();
                    var data = {data:JSON.stringify(file)};
                    var mapID = file.id;
                    $.ajax({
                        type:"POST",
                        url: "/api/scenarios/implementScenario",
                        data:data,
                        dataType:'json',
                        success:function(data){
                            console.log('Save Successful:',result)
                            $.ajax({
                                type:"GET",
                                url: "/loadMapFile",
                                data:data,
                                success:function(result){
                                    Maptician.Editor.closeFile();
                                    Maptician.Editor.loadFile(result);
                                }
                            })
                        }
                    })
                })
                .catch(function(err){
                    console.log(err);
                });
            } else {
                var live = this.currentFile.getLiveStatus();
                if(live){ // This will warn that live will be turned off
                    swal({
                          title: "Deactivating the Map",
                          text: "This will save and deactivate the current map.  All seats, rooms, and zones will no longer be reflected" +
                          " in the system, reports, or analytics.  Any seat assignments or reservations will also be removed.  These can" +
                          " be restored later by reactivating the map.  Are you sure you want to deactivate this map?",
                          type: "warning",
                          showCancelButton: true,
                          confirmButtonColor: "#525252",    
                          confirmButtonText: "Continue with Deactivate",
                          cancelButtonText: "Cancel",
                          closeOnConfirm: true,
                          closeOnCancel: true
                        })
                    .then(function(isConfirm){
                        if (isConfirm === true) {
                            $Map.Editor.currentFile.updateLive(!live);
                            $("#toggleLive").attr("title","Map is Inactive");
                            $Map.Editor.saveMap();
                        }
                    })
                } else { // This will warn that live will be turned on
                    swal({
                          title: "Activating the Map",
                          text: "This will save and activate the current map.  This will make all seats, rooms, and zones visible within " + 
                          "Maptician and will set any included seat assignments.  If individuals are assigned elsewhere, this may " +
                          "cause their current seat assignments to be changed to those in this map.  Are you sure you want to " +
                          "activate this map?" ,
                          type: "warning",
                          showCancelButton: true,
                          confirmButtonColor: "#525252",    
                          confirmButtonText: "Continue with Activation",
                          cancelButtonText: "Cancel",
                        })
                    .then(function(isConfirm){
                        if (isConfirm) {
                            $Map.Editor.currentFile.updateLive(!live);
                            $("#toggleLive").attr("title","Map is Live");
                            $Map.Editor.saveMap();
                        }                        
                    })
                }                
            }
        }
    }

    this.open = function(e){
        var targetNode = $(e.target).parent();
        var targetID = e.target.id;
        var currentID = this.currentFile && this.currentFile.getMapID();
        console.log(targetID,currentID)
        console.log(this.visible)
        if(this.visible){
            if(targetNode.hasClass("lev-2") && targetID != currentID){
                this.changeFile(targetID);
            }
        } else {
            this.currentFile ? this.showMapElements() : this.hideMapElements();
            if(targetNode.hasClass("lev-2")){
                targetNode.closest(".lev-1").addClass("selected").siblings().removeClass("selected");
                targetID != currentID ? this.changeFile(targetID) : this.redraw();
            } else {
                this.redraw();
            }
        }
        this.mapArea.show();
        this.navBar.show();
        console.log('setting bindings')
        this.setBindings();
        this.visible = true;
    }

    this.exit = function(){
        this.hide();
        $(".lev-2",this.fileMenu).removeClass("selected");
        this.mapArea.hide();
        this.navBar.hide();
        this.quickStart.hide();
        console.log('unsetting bindings')
        this.unsetBindings();
        this.visible = false;
        this.drawn = false;
    }

    this.hideMapElements = function(){ // Generally necessary when the Editor is open but no file is loaded
        this.quickStart.show();
        $("#objectSelector").hide();
        $("#objectType").hide();
        this.map.hide();
        this.miniMap.hide();   
    }

    this.showMapElements = function(){ // Used to show components when a file is open
        this.quickStart.hide();
        $("#objectSelector").show();
        $("#objectType").show();
        this.map.show();
        this.miniMap.show();
    }

    this.isSet = function(){ // Returns true if a editor is set and loaded     
        return this.currentFile != null;
    }

    this.isDrawn = function(){ // Returns whether the editor is currently drawn
        return this.drawn;
    }

    this.initializations();
    this.screenSizeBindings();
    this.architectureButtonBindings();
    this.zoneButtonBindings();
    this.roomButtonBindings();
    this.furnitureButtonBindings();
    this.seatButtonBindings();
    this.selectorBindings();
    this.objectSelectorBindings();
    this.objectButtonBindings();

    this.hasInit = true;
}
MapEditorController.prototype.zoomScale = [.1,.25,.5,.75,1,1.25,1.5,2,3,4,6,8,10,12,15];