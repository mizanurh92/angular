//#################################  Mouse Router Controller #####################################################

function MouseRouterController(controllers,state,map,miniMap,objectSelector,keyboardRouter,dataConnections){
	this.controllers = controllers;
	this.handleRouter = new HandleRouterController(this.controllers,state,map);
	this.dragBox = new DragBoxSelector(generateUUID(),this.controllers,state,map);
	this.svgClickRouter = new SvgClickRouterController(this.controllers,state,map,this.handleRouter,objectSelector);
	this.miniMapMouseDownBtn = false;

	this.mapMouseDown = function(event){
		map.setHandle(); // Necessary for dragging since this gives the origin of the drag relative to the map
		objectSelector.deactivateSelectorWindow();
		state.triggerNewRevisionStep();
		if(event.which == 1){  // Actions which are performed upon left mouse down
            switch(state.state){
            	case "createWall":
	                if(event.ctrlKey){
	                	if(this.controllers.architect.currentlyDrawing == ""){
	                		this.controllers.architect.create("Wall");
	                	} else {
							this.controllers.architect.finishDraw();
			                this.controllers.architect.create("Wall");	                		
	                	}
	                } else {
	                	this.deselectAll();
	                	this.controllers.architect.create("Wall");
	                }
	                objectSelector.selectSVG(this.controllers.architect.getDrawingID(),"architect");
	                state.setState("drawWall");
	                break;
	            case "drawWall":{
	                if(event.ctrlKey){
	                	if(this.controllers.architect.currentlyDrawing == ""){
	                		this.controllers.architect.create("Wall");
	                	} else {
							this.controllers.architect.finishDraw();
			                this.controllers.architect.create("Wall");	                		
	                	}
	                } else {
	                	this.deselectAll();
	                	this.controllers.architect.create("Wall");
	                }
	                objectSelector.selectSVG(this.controllers.architect.getDrawingID(),"architect");
	                state.setState("drawWall");
	                break;	            	
	            }
	            case "createColumn":
	                this.deselectAll();
	                this.controllers.architect.create("Column");
	                state.setState("drawColumn");
	                objectSelector.updateSelector();
	                break;
	            case "dragArchitectPlaceable":
	                 this.controllers.architect.finalizeDragNew();
	                 break;
	            case "createElevator":
	                this.deselectAll();
	                this.controllers.architect.create("Elevator");
	                state.setState("drawElevator");
	                break;
	            case "createStairs":
	                this.deselectAll();
	                this.controllers.architect.create("Stairs");
	                objectSelector.selectSVG(this.controllers.architect.getDrawingID(),"architect");
	                state.setState("drawStairs");
	                break;
	            case "placeDoor":
	                this.controllers.architect.finalizePlaceDoor();
	                state.setState("openSelector");
	                break;
	            case "placeWindow":
	                this.controllers.architect.finalizePlaceWindow();
	                state.setState("openSelector");
	               	break;
	            case "dragNewEmployee":
	            	this.controllers.dataObject.finalizePlace();
	            	state.setState("openSelector");
	            	break;
	            case "dragNewSeat":
	            	this.controllers.seats.finalizePlace(dataConnections);
	            	state.setState("openSelector");
	            	break;
	            case "dragNewKiosk":
	            	this.controllers.kiosks.finalizePlace();
	            	state.setState("openSelector");
	            	break;
	            case "dragNewMaplink":
	            	this.controllers.maplinks.finalizePlace();
	            	state.setState("openSelector");
	            	break;
	            case "dragNewFurniture":
	            	this.controllers.furniture.finalizePlace();
	            	state.setState("openSelector");
	            	break;
	            case "drawZone":
		            this.controllers.zones.drawPoint(map); // Creates a new zone point at the selected location
		            break;
		        case "drawZoneBox":
		        	this.controllers.zones.create(this.controllers);
		        	break;
		        case "drawRoom":
		            if(this.controllers.rooms.currentlyDrawing == ""){this.controllers.rooms.create();}
		            this.controllers.rooms.drawPoint(map);
		            break;
		        case "drawRoomBox":
	            	this.controllers.rooms.create(this.controllers);
	            	break;
	            case "openSelector":
	            	state.setState("dragBox");
	            	this.dragBox.create(map);
	            	break;
            }

            switch(state.state.type){
            	case "auto room":
            		var coords = this.controllers.rooms.destroyAreaPoint(); // Returns the user selected point for the auto-room
            		// Returns an object containing all architectural objects which might make up the perimeter of a room, i.e., walls
            		// columns, stairs, elevators, etc...  These are indexed by the object id and contain line segments making up their
            		// perimiters.
            		var outlines = this.controllers.architect.getOutlineSegments();
            		// Uses the starting point and perimeter to create a room that bounds the starting point -very computationally expensive
            		this.controllers.rooms.createAutoArea(coords,outlines); 
					state.setState("openSelector");
            	break;
            }

            switch(state.state.status){
            	case "placeFurnitureSubobject":
					this.controllers.furniture.finalizePlace(state.state.subtype);
	            	state.setState("openSelector");
            	break;
            }

            if(this.controllers.architect.objectsAreSelected() && (event.target.classList[0] != "architect" && event.target.classList[0] != "pointHandle")){ // Deselects the walls if a non-wall is left-clicked
                this.controllers.architect.deselectAll();
            }
	        if(this.controllers.zones.objectsAreSelected() && (event.target.classList[0] != "Zone" && event.target.classList[0] != "pointHandle")){ // Deselects the zones if a non-zone is left-clicked
	            this.controllers.zones.deselectAll();
	        } 
	        if(this.controllers.rooms.objectsAreSelected() && (event.target.classList[0] != "Room" && event.target.classList[0] != "pointHandle")){ // Deselects the walls if a non-wall is left-clicked
	            this.controllers.rooms.deselectAll();
	        }
	        if(this.controllers.seats.objectsAreSelected() && (event.target.classList[0] != "Seat")){ // Deselects the walls if a non-wall is left-clicked
	            this.controllers.seats.deselectAll();
	        }
	        if(this.controllers.kiosks.objectsAreSelected() && (event.target.classList[0] != "Kiosk")){ // Deselects the walls if a non-wall is left-clicked
	            this.controllers.kiosks.deselectAll();
	        }
	        if(this.controllers.maplinks.objectsAreSelected() && (event.target.classList[0] != "Maplink")){ // Deselects the walls if a non-wall is left-clicked
	            this.controllers.maplinks.deselectAll();
	        }
	        if(this.controllers.furniture.objectsAreSelected() && (event.target.classList[0] != "furniture" && event.target.classList[0] != "pointHandle")){ // Deselects the walls if a non-wall is left-clicked
	            this.controllers.furniture.deselectAll();
	        }                         
        }
	    
	    // Actions which are performed upon right mouse down
	    if(event.which == 3){  
	        state.rightDown = true;
	        // A right click while drawing zones or rooms by points will finalize the draw and close the area
	        if(state.state == "drawRoom"){this.controllers.rooms.finalizeArea(dataConnections,objectSelector);}
	        if(state.state == "drawRoomBox"){this.controllers.rooms.cancelDraw();}
	        if(state.state == "drawZone"){this.controllers.zones.finalizeArea(dataConnections,objectSelector);}
	        if(state.state == "drawZoneBox"){this.controllers.zones.cancelDraw();}
	        if(this.controllers.architect.currentlyDrawing != "" || state.state == "createWall"){
	        	this.controllers.architect.cancelDraw();
	        	state.setState("openSelector");
	        }
	    }

	    // Actions which are performed on any mouse down
	    if(state.state == "dragArchitectPlaceable"){state.setState("openSelector");} // Sets the new object in place at the point of mouse down
	}
	
	this.documentMouseMove = function(event){	
		map.currentMousePos.x = event.pageX-map.mapContainer.pos.x-$("#side-menu").width();
        map.currentMousePos.y = event.pageY-map.mapContainer.pos.y;
        if(event.ctrlKey && state.state == "drawWall"){
        	this.controllers.architect.draw();
        }

		if(event.which == 1){  // Actions which are performed upon left mouse down
			// Draw Events
			switch(state.state){
				case "drawWall":
	            case "drawCurveWall":
	            	this.controllers.architect.draw();
	            	objectSelector.updateSelector();
	            	break;
				case "drawColumn":
					this.controllers.architect.draw();
	            	objectSelector.updateSelector();
	            	break;	            	
	            case "drawElevator":
	            	this.controllers.architect.draw();
	            	objectSelector.updateSelector();
	            	break;
	            case "drawStairs":
	            	this.controllers.architect.draw();
	            	objectSelector.updateSelector();
	            	break;
	            case "drawZoneBox":
	            	this.controllers.zones.drawBox();
	            	break;
	            case "drawRoomBox":
	            	this.controllers.rooms.drawBox();
	            	break;
	            case "dragBox":
	            	this.dragBox.drawBox(map);
	            	break;
			}
			
			// Drag Events
			switch(state.state){
	        	case "dragArchitect":
	        		this.controllers.architect.dragActive();
	        		objectSelector.updateSelector();
	        		break;
	        	case "dragFurniture":
	        		this.controllers.furniture.dragActive();
	        		objectSelector.updateSelector();
	        		break;
	        	case "dragSeat":
	        		this.controllers.seats.dragActive();
	        		break;
	        	case "dragKiosk":
	        		this.controllers.kiosks.dragActive();
	        		break;
	        	case "dragMaplink":
	        		this.controllers.maplinks.dragActive();
	        		break;
	        	case "moveZone":
	        		this.controllers.zones.dragActive();
	        		break;
	        	case "moveRoom":
	        		this.controllers.rooms.dragActive();
	        		break;
		        case "dragOpenDoor":
		            this.controllers.architect.dragOpenDoor();
		            objectSelector.updateSelector();
		            break;
		        case "dragHandle":
		            this.handleRouter.routeHandleDrag();
		            objectSelector.updateSelector();
		            break;
		        case "dragDoorJam":
		            this.controllers.architect.dragDoorJam();
		            objectSelector.updateSelector();
		            break;
		        case "dragWindowFrame":
		            this.controllers.architect.dragWindowFrame();
		            objectSelector.updateSelector();
		            break;
	        }  
		}
		
		// Mouse move events which don't require a mouse button to be held down
        if(state.state == "placeDoor"){
        	this.controllers.architect.dragPlaceDoor();
        	objectSelector.updateSelector();
        }
        if(state.state == "placeWindow"){
        	this.controllers.architect.dragPlaceWindow();
        	objectSelector.updateSelector();
        }
		if(state.state == "drawZone"){this.controllers.zones.showNextPoint();} // User is clicking on sequential points to create a zone
        if(state.state == "drawRoom"){this.controllers.rooms.showNextPoint();}
        if(state.state == "dragArchitectPlaceable"){this.controllers.architect.dragNew();}
        if(state.state == "dragNewEmployee"){this.controllers.dataObject.dragNew();}
        if(state.state == "dragNewSeat"){this.controllers.seats.dragNew();}
        if(state.state == "dragNewKiosk"){this.controllers.kiosks.dragNew();}
        if(state.state == "dragNewMaplink"){this.controllers.maplinks.dragNew();}
        if(state.state == "dragNewFurniture"){this.controllers.furniture.dragNew();}
        if(state.state.status && state.state.status == "placeFurnitureSubobject"){
        	this.controllers.furniture.dragNew(state.state.subtype);
        }
	}

	this.documentMouseUp = function(event){
		this.miniMapMouseDownBtn = false;
		if(event.which == 3){state.rightDown = false;}
		
		switch(state.state){		
			case "miniMapDrag":
			case "dragCubicle":
			case "dragDoor":
			case "dragOpenDoor":
			case "dragDoorJam":
			case "dragWindow":
			case "dragWindowFrame":
			case "dragArchitect":	
				this.controllers.architect.finalizeDrag();
				state.setState("openSelector");
				break;
			case "dragFurniture":	
				this.controllers.furniture.finalizeDrag();
				state.setState("openSelector");
				break;
			case "dragDataObject":
				this.controllers.dataObject.finalizeDrag();
				state.setState("openSelector");
				break;			
			case "dragSeat":
				this.controllers.seats.finalizeDrag(dataConnections);
				state.setState("openSelector");
				break;
			case "dragKiosk":
				this.controllers.kiosks.finalizeDrag();
				state.setState("openSelector");
				break;
			case "dragMaplink":
				this.controllers.maplinks.finalizeDrag();
				state.setState("openSelector");
				break;
			case "dragHandle":
				for(var i in this.controllers){
					this.controllers[i].finalizeHandleDrag(dataConnections);
				}
				state.setState("openSelector");
				break;
			case "drawWall":
				if(event.ctrlKey){
					// this.controllers.architect.finishDraw();
	    			//this.controllers.architect.create("Wall");
	    			//state.setState('createWall');
				} else {
					this.controllers.architect.finishDraw();
					state.setState('createWall');
				}
				break;
			case "drawColumn":
			case "drawSink":
			case "drawToilet":
			case "drawElevator":
			case "drawStairs":
			    this.controllers.architect.finishDraw();
            	state.setState("openSelector");
            	break;					
			case "drawZoneBox":
				this.controllers.zones.finishDraw(dataConnections,objectSelector);
            	state.setState("openSelector");
				break;
			case "drawRoomBox":
	            this.controllers.rooms.finishDraw(dataConnections,objectSelector);
	            state.setState("openSelector");					
				break;
			case "moveZone":
				this.controllers.zones.finalizeDrag(dataConnections);
				break;
			case "moveRoom":
				this.controllers.rooms.finalizeDrag(dataConnections);
				break;
			case "dragBox":
				if(event.which == 1){
					this.dragBox.finalizeDraw();
				}
				state.setState("openSelector");
				break;
		}
	}

	this.mapMouseMove = function(event){
		
		if(event.which == 1){  // Actions which are performed upon left mouse down

		}

		if(event.which == 3){  // Actions which are performed upon right mouse down
	        if(state.rightDown){
	        	map.constrainedMove(map.currentMousePos.x-map.handle.x,map.currentMousePos.y-map.handle.y,miniMap);
	        }
		}

		// Actions taken based on state
		if(state.state.type && state.state.type == "auto room"){
			this.controllers.rooms.dragAreaPoint();
		}
	}

	this.miniMapMouseDown = function(event){
		this.setMousePos(event);
		this.miniMapMouseDownBtn = true;
        if(event.target.id == "miniViewBox"){
        	miniMap.setViewHandle(state); // Sets the handle on the mini-map viewbox for dragging
        }
        if(event.target.id == "miniMapSVG"){
        	miniMap.setViewHandle(state);
        	miniMap.moveViewHandle(state);
        }		
	}

	this.miniMapMouseMove = function(event){
		this.setMousePos(event);
		if(this.miniMapMouseDownBtn){
			miniMap.mouseDrag(map);
		}
	}

	this.setMousePos = function(event){
		map.currentMousePos.x = event.offset.x;
		map.currentMousePos.y = event.offset.y;	
	}

	this.mapMouseEnter = function(event){
        if(state.state == "drawZone"){
            if(this.controllers.zones.currentlyDrawing == ""){this.controllers.zones.create(this.controllers);}
            this.controllers.zones.drawAreaMapEnter();      	
        }
        if(state.state == "drawRoom"){
            if(this.controllers.rooms.currentlyDrawing == ""){this.controllers.rooms.create(this.controllers);}
            this.controllers.rooms.drawAreaMapEnter();      	
        }
        if(state.state == "drawSink"){
            state.triggerNewRevisionStep();
            this.controllers.architect.create("Sink");
            state.state = "dragArchitectPlaceable";        	
        }
        if(state.state == "drawToilet"){
            state.triggerNewRevisionStep();
            this.controllers.architect.create("Toilet");
            state.state = "dragArchitectPlaceable";        	
        }
        if(state.state == "placeSeat"){
            state.triggerNewRevisionStep();
            this.controllers.seats.create("Seat");
            state.state = "dragNewSeat";        	
        }
        if(state.state == "placeKiosk"){
            state.triggerNewRevisionStep();
            this.controllers.kiosks.create("Kiosk");
            state.state = "dragNewKiosk";        	
        }
        if(state.state.action == "placeMaplink"){
            state.triggerNewRevisionStep();
            this.controllers.maplinks.create(state.state.type);
            state.state = "dragNewMaplink";
        }
        if(state.state.type && state.state.type == "placeFurniture" && !state.state.subobject){
            state.triggerNewRevisionStep();
            this.controllers.furniture.create(state.state.subtype,this.controllers);
            state.state = "dragNewFurniture";        	
        }
        if(state.state.type && state.state.type == "auto room"){
        	this.controllers.rooms.createAreaPoint();
        }
	}

	this.mapMouseLeave = function(event){
        if(state.state.type && state.state.type == "auto room"){
        	this.controllers.rooms.destroyAreaPoint();
        }		
	}

	this.deselectAll = function(){
        for(var i in this.controllers){
        	this.controllers[i].deselectAll();
        }
	}

}