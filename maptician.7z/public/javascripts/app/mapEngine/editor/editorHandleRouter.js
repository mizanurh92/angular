//#################################  Handle Router Controller #####################################################

function HandleRouterController(controllers,state,map){
	this.controllers = {};
	this.map = map;
	this.state = state;
	for(var obj in controllers){
		this.controllers[controllers[obj].prefix] = controllers[obj];
	}
	this.routeHandlePress = function(id){
		this.state.dragHandle = id;
		var module = id.slice(0,2);
		this.controllers[module].handlePress(id,id.slice(6),controllers);
	}
	this.routeHandleDrag = function(){
		var module = this.state.dragHandle.slice(0,2);
		this.controllers[module].handleDrag();
	}
	this.routeHandleSelect = function(id){
		var module = id.slice(0,2);
		this.controllers[module].handleSelect(id,id.slice(6));
	}
}