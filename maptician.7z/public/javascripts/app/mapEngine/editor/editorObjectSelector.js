//#################################  Object Selector Interface Controller #####################################################

function EditorSelectorController(controllers,settings){
	this.controllers = controllers;
	this.settings = settings; // Settings controller

	this.lastCategory = "";
	this.selectedCategory = "";
	this.selectorActive = false;
	this.selected = {}; // Selected should have a controller name, id, and possibly subcategory (i.e. window)


	// This function updates the data in the object selector.  It can be called without an argument, in which case the object
	// selector is updated with object which had previously been selected (found in this.selected).  If no object is selected
	// or a "clear" argument is passed, then the object selector will be populated with the general map object
	this.updateSelector = function(clear){
		if(this.selected.id == undefined || clear){
			this.selectSVG();
			return
		}

		var properties = this.controllers[this.selected.controller].getProperties(this.selected.id,this.selected.subcategory);

		if(properties == undefined) return;

		for(var i in properties.data){
			switch(properties.data[i].type){
				case "label":
					this.updateLabel(i,properties.data[i].value);
				break;
				case "drop-down":
					this.updateDropDown(i,properties.data[i].value);
				break;
				case "spinner":
					this.updateSpinner(i,properties.data[i].value);
				break;
				case "text":
					this.updateText(i,properties.data[i].value);
				break;
				case "slider":
					this.updateSlider(i,properties.data[i].value,properties.data[i].min,properties.data[i].max,properties.data[i].slide);
				break;
				case "switch":
					this.updateSwitch(i,properties.data[i].value);
				break;
				case "color":
					this.updateColor(i,properties.data[i].value);
				break;
			}
		}
	}

	this.selectSVG = function(id,controller,subcategory){
		var dataKeys, dividerKeys, properties;
		this.selected.id = id;
		this.selected.controller = controller;
		this.selected.subcategory = subcategory;
		
		if(controller){
			properties = this.controllers[controller].getProperties(id,subcategory);
		} else {
			properties = this.settings.getProperties();
		}

		dataKeys = Object.keys(properties.data);
		dividerKeys = Object.keys(properties.dividers);
		if(dataKeys.length == 0){ // Catch if no data is received
			this.updateLabel("objectType","unknown");
			return null;
		}

		// Hides all object selector items
		$("#infoTable .mapObjectSelector,#infoTable .selectorDivider").css("display","none").removeClass('activeDisplay'); 

		// Unhides selector dividers (selector category titles) based on the list from the object
		for(var i = 0;i < dividerKeys.length;i++){
			$("#infoTable .selectorDivider#"+dividerKeys[i]).css("display","table-row");
		}

		// Unhides selector object controls based on data received
		for(var i = 0;i < dataKeys.length;i++){
			$("#infoTable #"+dataKeys[i]).closest(".mapObjectSelector").css("display","table-row").addClass('activeDisplay');
		}

		for(var i in properties.data){ // i is the html id of the object control
			switch(properties.data[i].type){
				case "label":
					this.updateLabel(i,properties.data[i].value);
				break;
				case "drop-down":
					this.updateDropDown(i,properties.data[i].value);
				break;
				case "spinner":
					this.updateSpinner(i,properties.data[i].value);
				break;
				case "text":
					this.updateText(i,properties.data[i].value);
				break;
				case "slider":
					this.updateSlider(i,properties.data[i].value,properties.data[i].min,properties.data[i].max,properties.data[i].slide);
				break;
				case "switch":
					this.updateSwitch(i,properties.data[i].value);
				break;
				case "color":
					this.updateColor(i,properties.data[i].value);
				break;
				case "checks":
					this.updateChecks(i,properties.data[i].value); // Should be an array
				break;
			}
		}
	}

	this.updateLabel = function(object,value){
		$("#"+object).html(value);
	}
	this.updateDropDown = function(object,value){
		$("#"+object).prop({value:value});
	}	
	this.updateSpinner = function(object,value){
		$("#"+object).spinner("value",value);
	}
	this.updateText = function(object,value){
		$("#"+object).prop({value:value});
	}
	this.updateSlider = function(object,value,min,max,slide){
		$("#"+object).slider("option",{value:value,min:min,max:max,slide:slide}); // slide is the function which controls the slider text
	}
	this.updateSwitch = function(object,value){
		$("#"+object).prop("checked",value);
	}
	this.updateColor = function(object,value){
		$("#"+object).prop({value:value});
	}
	this.updateImage = function(object,value){
		$("#"+object).attr({src:value+"?"+Math.random().toString().slice(0,6)}); // The random addition prevents the image from caching
	}
	this.updateChecks = function(object,value){
		$("#"+object).iCheck('uncheck');
		for(var i in value){
			var val = value[i];
			$("#"+object + " input").filter("[data='"+val+"']").iCheck('check');
		}
	}

	this.propertyChange = function(objectSelector,event,ui){
		var id = this.selected.id;
		var property = objectSelector.id;
		if(ui){
			var value = ui.value;
		} else {
			var value;
			if(objectSelector.type == "checkList"){
				value = event; // this is a list of checked values
			} else if($(event.currentTarget).hasClass("switch-input")){
				value = event.target.checked;
			} else {
				value = event.target.value;
			}
		}
		if(this.controllers[this.selected.controller]){
			this.controllers[this.selected.controller].setProperty(id,property,value,this.selected.subcategory);
		} else{
			this.settings.setProperty(id,property,value);
		}
		this.updateSelector();
	}

	this.activateSelectorWindow = function(){
		this.selectorActive = true;
		$("#objectSelector").addClass("selected");
	}

	this.deactivateSelectorWindow = function(){
		this.selectorActive = false;
		$("#objectSelector").removeClass("selected");
	}

	this.active = function(){
		return this.selectorActive;
	}

	this.getSelected = function(){
		return this.selected;
	}

	this.initializeSelectors = function(){
	    $('#openSelectorWrapper').slimScroll({
	            position: 'right',
	            height:"auto",
	            railVisible: true,
	            alwaysVisible: false,
	            color: "gray",
	            disableFadeOut:true,
	            distance:"4px"
	    });

		this.initializeSelectorObjects();

		$(".ui-button-icon-only").removeClass("ui-button-icon-only")
	    $(".ui-corner-tr").removeClass("ui-corner-tr")
	    $(".ui-corner-br").removeClass("ui-corner-br")
	    $(".ui-button-icon").remove();
	}

	this.initializeSelectorObjects = function(){
		// Spinners - could probably configure like the sliders below (objects contain their own option parameters)
		$("#objectRoomCapacity").spinner({max: 1000,min: 0,step:1});	
		$("#objectLength").spinner({max: 60000,min: 1,step:1});	
		$("#objectWidth").spinner({max: 60000,min: 1,step:1});	
		$("#objectDist").spinner({max: 100000,min: 0,step:1});	
		$("#objectAngle").spinner({max: 360,min: -360,step:1});	
		$("#objectLabelSize").spinner({max: 50,min: 1,step:1});	
		$("#objectStairSpacing").spinner({max: 48,min: 1,step:1});	
		$("#objectGridSpacing").spinner({max: 48,min: 1,step:1,icons:{down:'',up:''}});	
	    
	    // Sliders - likely don't need to set any values since each object should pass new options
	    $("#objectStyle").slider({value:0,min: 0,max: 2,step: 1});
	    $("#objectLabelStyle").slider({value:0,min: 0,max: 2,step: 1});
	    $("#objectNameStyle").slider({value:0,min: 0,max: 2,step: 1});
	    $("#objectAreaStyle").slider({value:0,min: 0,max: 2,step: 1});
	    $("#objectDistanceStyle").slider({value:0,min: 0,max: 2,step: 1});
	    
	    $("#objectLabelOrient").slider({value:0,min: 0,max: 2,step: 1});
	    $("#objectHingeDirection").slider({value:0,min: 0,max: 1,step: 1});
	    $("#objectStairDirection").slider({value:0,min: 0,max: 1,step: 1});
	    $("#objectZoomLevel").slider({value:10,min: 0,max: 20,step: 1});
	}

	this.initializeSelectors();
}