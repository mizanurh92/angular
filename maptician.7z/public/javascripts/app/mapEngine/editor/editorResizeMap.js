// This component handles the "Resize" and "Center and Crop" functions for the Map Editor
Maptician.components.resizeMap = function(){ // Called when the "Resize Map" button is pressed in the object selector for the Editor
	var editor = Maptician.Editor;
    editor.metrics = editor.currentFile.getResizeMetrics();
    var metrics = editor.metrics;
    var unitSystem = editor.currentFile.getUnitSystem();    

    $('#resizeNewWidthErr,#resizeNewHeightErr').html('');         
    $("#resizeCurrentWidth").html(renderLength(metrics.currentWidth,{system:unitSystem}));
    $("#resizeCurrentHeight").html(renderLength(metrics.currentHeight,{system:unitSystem}));
    $("#resizeMinWidth").html(renderLength(metrics.minWidth,{system:unitSystem}));
    $("#resizeMinHeight").html(renderLength(metrics.minHeight,{system:unitSystem}));
    $("#resizeNewWidth").val(renderLength(metrics.currentWidth,{system:unitSystem}));
    $("#resizeNewHeight").val(renderLength(metrics.currentHeight,{system:unitSystem}));
    $("#resizeMapModal").modal();

	if(Maptician.components.resizeMap.hasInit){
		
	} else {
        
        $("#resizeMapModal .completeAction").click(function(){ // This function should process the "resize map" feature action
            $('#resizeNewWidthErr,#resizeNewHeightErr').html(''); // Refreshes error messages for each button click
            var currentFile = editor.currentFile;
            var defaultUnit;
            switch(unitSystem){
                case "US":
                    defaultUnit = "feet";
                break;
                case "Metric":
                    defaultUnit = "meters";
                break;
            }
            try{
                var width = parseToInches($("#resizeNewWidth").val(),{defaultUnit:defaultUnit})
            } catch(err){
                $("#resizeNewWidthErr").html('Invalid Entry');
                return;
            }
            try{
                var height = parseToInches($("#resizeNewHeight").val(),{defaultUnit:defaultUnit})
            } catch(err){
                console.log("err")
                $("#resizeNewHeightErr").html('Invalid Entry');
                return;
            }
            if(width < editor.metrics.minWidth){
                $("#resizeNewWidthErr").html('Entered width is less than the minimum.');
                return;
            }
            if(height < editor.metrics.minHeight){
                $("#resizeNewHeightErr").html('Entered height is less than the minimum.');
                return;
            }

            try{
            	currentFile.resizeMap(width,height);
            } catch(_){
            	alert('Unable to resize map') // TODO turn this into a SWAL alert
            }
            
            $.modal.close();
        })

        $("#resizeMapModal .cancelAction").click(function(){
            $.modal.close();
        })
        
		Maptician.components.resizeMap.hasInit = true;
	}
}


Maptician.components.cropMap = function(){ // Called when the "Resize Map" button is pressed in the object selector for the Editor
    var editor = Maptician.Editor;
    editor.metrics = editor.currentFile.getResizeMetrics();
    var metrics = editor.metrics;
    var unitSystem = editor.currentFile.getUnitSystem();    

    $("#topMarginErr,#bottomMarginErr,#leftMarginErr,#rightMarginErr").html('');            
    $("#cropMapControl input").val(20);
    $("#cropMapModal").modal();

    if(Maptician.components.cropMap.hasInit){
        
    } else {
        
        // When the uniform margin input is modified, the inidividual margins are adjusted to that value
        $("#resizeMargin").on("input",function(e){$("#cropMapControl input").val(e.currentTarget.value);})


        $("#cropMapModal .completeAction").click(function(){
            var newWidth,newHeight,shiftLeft,shiftUp;
            var editor = Maptician.Editor;
            var currentFile = editor.currentFile;
            var metrics = editor.metrics;
            var margins = {
                top:$("#resizeTopMargin").val()*1,
                bottom:$("#resizeBottomMargin").val()*1,
                left:$("#resizeLeftMargin").val()*1,
                right:$("#resizeRightMargin").val()*1
            }

            $("#topMarginErr,#bottomMarginErr,#leftMarginErr,#rightMarginErr").html('');

            if(isNumeric(margins.top)){
                margins.top = margins.top < 0 ? 0 : margins.top;
            } else {
                $("#topMarginErr").html('Invalid Entry');
                return;
            }
            if(isNumeric(margins.bottom)){
                margins.bottom = margins.bottom < 0 ? 0 : margins.bottom;
            } else {
                $("#bottomMarginErr").html('Invalid Entry');
                return;
            }
            if(isNumeric(margins.left)){
                margins.left = margins.left < 0 ? 0 : margins.left;
            } else {
                $("#leftMarginErr").html('Invalid Entry');
                return;
            }
            if(isNumeric(margins.right)){
                margins.right = margins.right < 0 ? 0 : margins.right;
            } else {
                $("#rightMarginErr").html('Invalid Entry');
                return;
            }

            newWidth = metrics.usedWidth + margins.left + margins.right;
            newHeight = metrics.usedHeight + margins.top + margins.bottom;
            shiftLeft = margins.left - metrics.left;
            shiftUp = margins.top - metrics.top;
            
            try{
                currentFile.shiftObjects(shiftLeft,shiftUp);
                currentFile.resizeMap(newWidth,newHeight);                
            } catch(_){
                alert("Unable to crop map.") // TODO turn this into a SWAL alert
            }
            $.modal.close();
        })

        $("#cropMapModal .cancelAction").click(function(){
            $.modal.close();
        })

        Maptician.components.cropMap.hasInit = true;
    }
}