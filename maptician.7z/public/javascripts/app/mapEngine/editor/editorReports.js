$Map.Components = $Map.Components || {};
$Map.Components.Editor = $Map.Components.Editor || {};

$Map.Components.Editor.AssignUserTable = function(){
	this.modalElement = $('#assignUserModal');
	this.tableElement = $('#userAssignmentTable');
	this.cancelButton = $("#cancelAssignUser");
	this.searchInput = $("#assignUserSearch");
	this.assignUserButton = $("#assignUser");
	this.departmentFilter = $("#assignUserDepartments");
	this.assignmentStatus = $("#assignUserAvailable");
	this.url = "/api/seats/getUserList";
	this.officeID = null;

	this.table = null; // Holds the dataTables table object
	this.tableOffset = 160;

	this.nameSpace = ".assignUserTable";

	var Editor = Maptician.Editor;
	var Table = this;

	this.open = function(officeID,deptName){
		Table.modalElement.modal();
		this.inits();
		this.officeID = officeID;
		this.setTable(deptName);
	}

	this.exit = function(){
		this.unsetBindings();
		this.officeID = null;
		this.table && this.table.clear().destroy(); // Clears datatable
		this.table = null;		
		this.tableElement.children().remove(); // Removes table remaining table elements (except table)
		$("#assignUserTable").remove(); // Removes iFrame
		this.assignmentStatus.iCheck('destroy') // Removes iCheck formatting
		this.searchInput.val('');
		this.departmentFilter.chosen().val('');
	}

	this.inits = function(){
        this.departmentFilter.chosen({
            placeholder_text_single:"Filter by Department",
            allow_single_deselect: true,
            width:"250px",
            disable_search_threshold: 10
        });

        this.assignmentStatus.iCheck({
			checkboxClass: 'icheckbox_line-blue',
			insert: '<div class="icheck_line-icon"></div><span class="desc">Only Show Unassigned</span>'
		}).iCheck('check');
	}

	this.filterTable = function(){
		var textValue = Table.searchInput.val();
		var departmentValue = Table.departmentFilter.chosen().val();
		var filterAssigned = Table.assignmentStatus.prop('checked');
		var assignedFilter = filterAssigned ? ':selectU' : ''
		var fullValue = textValue + " " + departmentValue + " " + assignedFilter;
		Table.table.search(fullValue).draw();
	}

	this.setBindings = function(){

		this.searchInput.on('input'+this.nameSpace,function(){
			Table.filterTable();
		})

        this.departmentFilter.on( 'change'+this.nameSpace, function () {
			Table.filterTable();
        });

		this.assignmentStatus.on('ifToggled'+this.nameSpace, function () {
			Table.filterTable();
		});

		_attach.call(this.table,"assignUserTable",this.tableOffset,function(height){
			Table.tableElement.parent().css("height",height);
			Table.table.draw();
		});

		this.table.on('select'+this.nameSpace,function(e, dt, type, indexes){
			Table.row = Table.table.rows(indexes);
			Table.data = Table.row.data()[0];
		})

		this.assignUserButton.on('click'+this.nameSpace, function(){
			var userID = Table.data.userID;
			var seatID = Editor.currentFile.getSelected().id;
			var updateType;
			if(Table.data.seats.length > 1 || (Table.data.seats.length == 1 && Table.data.seats[0].seatID != seatID)){
				swal({
				  title: "User is Already Assigned Elsewhere",
				  text: "The selected user is already assigned to a different seat." +
					" You can set the user's seat assignment to the new seat, or you can add an additional assigned seat for the user.",
				  type: "warning",
				  showCancelButton: true,
				  confirmButtonColor: "#525252",    
				  confirmButtonText: "Assign Additional Seat",
				  cancelButtonText: "Change Assignment",
				})
				.then(function(isConfirm){
					Editor.currentFile.dataConnections.assignSeat(seatID,userID,Table.data,'multi');
					$.modal.close();
				})
				.catch(function(err){				
					Editor.currentFile.dataConnections.assignSeat(seatID,userID,Table.data,'move');
					$.modal.close();
				})

			} else {
				updateType = 'move';
				Editor.currentFile.dataConnections.assignSeat(seatID,userID,Table.data,updateType);
				$.modal.close();
			}
		})

		this.cancelButton.on('click'+this.nameSpace,function(){
			$.modal.close();
		})

		this.modalElement.on($.modal.CLOSE+this.nameSpace, function(event, modal) {
			Table.exit();
		});
	}

	this.unsetBindings = function(){
		this.table.off('.dt');
		this.modalElement.off(Table.nameSpace);
	}

	this.setTable = function(deptName){
		this.table = this.tableElement.DataTable({
			ajax: {
				url: this.url,
				data:function(d){
					return {
						officeID: Table.officeID
					};
				}
			},
			select: {
				style: 'single',
				className: 'selected',
				selector: 'tr:not(.selected)'
			},
			scrollY: this.tableElement.parent().height() - this.tableOffset,
			deferRender:true,
			scroller:true,
			paging:true,
			columns:[
				{
					data: {},
					title: "",
					sortable:false,
					'className':'tableProfileImage',
					render: function(user){
						return '<div><img src="'+user.profile+'"></div>';
					}
				},
				{
					data: 'id',
					title: "ID"
				},
				{
					data: 'first',
					title: "First Name"
				},
				{
					data: 'last',
					title: "Last Name"
				},
				{
					data: 'title',
					title: "Title"
				},
				{
					data: 'department.name',
					title: "Department"
				},
				{
					data: {},
					title: "Primary Office",
					render:function(user){
						return user.office ? user.office.name : '';
					}
				},
				{
					data: function(user,type,val,meta){ // Seat Location
						if(type === "type"){
							var currentUsers = $Map.current().dataConnections.users;
							var userID = user.userID;
							if(currentUsers[userID] && currentUsers[userID].seats){
								user.seats = currentUsers[userID].seats;
							}
							var len, seat;
							len = user.seats.length;
							if(len == 0){
								user.seatAssign = "Unassigned";
							} else if(len == 1){
								seat = user.seats[0];
								user.seatAssign = seat.mapName + " - " + seat.seatName;
							} else {
								user.seatAssign = "Multiple";
							}
							return user;							
						} else if(type === 'display'){
							return user.seatAssign;
						} else if(type === 'filter'){
							if(user.seatAssign == "Unassigned"){
								return ":selectU";
							} else {
								return ":selectA";
							}
						}
						return user;
					},
					title: "Current Assignment",
					className:'tableCenterText',
				},
			],
			dom: 'rt<"#assignUserButtonDiv" <"#assignUser.btn"><"#cancelAssignUser.btn">>',
			initComplete: function(){
				Table.table.draw();
				Table.assignUserButton = $("#assignUser").html('Assign')
				Table.cancelButton = $("#cancelAssignUser").html('Cancel')
				Table.setBindings();
			}
		})
		
		// Populates the drop-down menus each time the table is loaded
        this.table.on('xhr.dt',function( e, settings, json, xhr ){
            var departments = {};
            for(var i = 0; i < json.data.length; i++){
                departments[json.data[i].department.name] = {};
            }
            var deptList = Object.keys(departments);
            Table.departmentFilter.empty().append("<option></option>");
            for(var i = 0; i < deptList.length; i++){
                Table.departmentFilter.append("<option>"+deptList[i]+"</option>")
            }

			if(deptName && deptName != "Unassigned"){
				Table.departmentFilter.val(deptName);
				Table.departmentFilter.trigger("chosen:updated");
			}

            Table.departmentFilter.trigger("chosen:updated");

            Table.filterTable();
        }) 
	}
}