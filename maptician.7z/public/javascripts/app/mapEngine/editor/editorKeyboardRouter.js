//#################################  Keyboard Router #####################################################

function KeyboardRouterController(state,map,objectSelector,controllers,dataConnections){
	this.keyUp = function(event){
        if(objectSelector.selectorActive == false){
            switch(event.which){
	            case 17: // Ctrl Key
	                if(state.state == "drawWall"){
	                	controllers.architect.deselectAll();
	                	state.setState("createWall");
	                }
	            break;
        	}
        }
	}
	this.keyPress = function(event){
        if(objectSelector.selectorActive == false){
            switch(event.which){
	            case 89: // 'y' key
	            	if(event.ctrlKey){
	            		event.preventDefault();
	            		state.redo(controllers);
	            	}
	            	return;
	            	break;
	            case 90: // 'z' key
	            	if(event.ctrlKey){
	            		event.preventDefault();
	            		state.undo(controllers);
	            	}
	            	return;
	            	break;
            }
            state.triggerNewRevisionStep();
            switch(event.which){
	            case 27: // Escape Key
	                try{
		                for(var i in controllers){
		                	controllers[i].deselectAll();
		                }                	
	                } catch(err){
	                	console.log(err);
	                }
	                state.setState("openSelector");
	                objectSelector.updateSelector("clear");
	            break;
	            case 46:  // Delete Key
            		for(var i in controllers){
	                	controllers[i].deleteSelected(dataConnections);
	                }    
	            	state.setState("openSelector");
	            	objectSelector.updateSelector("clear");
	            	break;
	            case 13:  // Enter Key
	            	switch(state.state){
	            		case "placeDoor":
		                    controllers.architect.finalizePlaceDoor();
		                    state.setState("openSelector");
		                    break;
		                case "placeWindow":
		                    controllers.architect.finalizePlaceWindow();
		                    state.setState("openSelector");
		                    break;
		                case "drawZone":
		                	controllers.zones.finalizeArea(dataConnections);
		                	state.setState("openSelector");
		                	break;
		                case "drawRoom":
		                	controllers.rooms.finalizeArea(dataConnections);
		                	state.setState("openSelector");
		                	break;		                	
	            	}
	            	break;
	            case 37: // Left Arrow
	            	if(state.state == "openSelector" || state.state == "dragArchitect"){
	            		controllers.architect.moveActive("left");
	            		controllers.furniture.moveActive("left");
	            		controllers.seats.moveActive("left",dataConnections);
	            		controllers.kiosks.moveActive("left");
	            		controllers.maplinks.moveActive("left");
	            	}
	            	break;
	            case 38: // Up Arrow
	            	if(state.state == "openSelector" || state.state == "dragArchitect"){
	            		controllers.architect.moveActive("up");
	            		controllers.furniture.moveActive("up");
	            		controllers.seats.moveActive("up",dataConnections);
	            		controllers.kiosks.moveActive("up");
	            		controllers.maplinks.moveActive("up");
	            	}
	            	break;
	            case 39: // Right Arrow
	            	if(state.state == "openSelector" || state.state == "dragArchitect"){
	            		controllers.architect.moveActive("right");
						controllers.furniture.moveActive("right");
						controllers.seats.moveActive("right",dataConnections);
						controllers.kiosks.moveActive("right");
						controllers.maplinks.moveActive("right");
	            	}
	            	break;
	            case 40: // Down Arrow
	            	if(state.state == "openSelector" || state.state == "dragArchitect"){
	            		controllers.architect.moveActive("down");
	            		controllers.furniture.moveActive("down");
	            		controllers.seats.moveActive("down",dataConnections);
	            		controllers.kiosks.moveActive("down");
	            		controllers.maplinks.moveActive("down");
	            	}
	            	break;
	            case 68: // 'd' key
	            	if(event.ctrlKey){
	            		event.preventDefault();
	            		controllers.architect.duplicate();
	            		controllers.furniture.duplicate();
                		controllers.rooms.duplicate();
                		controllers.zones.duplicate();
                		controllers.seats.duplicate();
                		controllers.kiosks.duplicate();
                		controllers.maplinks.duplicate();
	            	}
	            	break;
        	}
        	objectSelector.updateSelector();
        }
	}
}