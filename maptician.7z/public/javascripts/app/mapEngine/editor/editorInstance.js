function MapEditorInstance(width,height,id,name,officeID,optObj){
    var options = optObj || {};
    var unitSystem = options.unitSystem || "US";
    var floor = options.floor || "";
    var suite = options.suite || "";

    this.live = false;
    this.scenario = false;
    this.map = new MapController(width,height,"Editor");
    this.miniMap = new MiniMapController(this.map);
    this.map.setMiniMap(this.miniMap);
    this.state = new StateController(this.map);
    this.controllers = {
        architect: new ArchitectureController(this.state,this.map),
        zones: new ZoneController(this.state,this.map),
        rooms: new RoomController(this.state,this.map),
        furniture: new FurnitureController(this.state,this.map),
        seats: new SeatController(this.state,this.map),
        kiosks: new KioskController(this.state,this.map),
        maplinks: new MapLinkController(this.state,this.map),
    }
    this.dataConnections = new ConnectionController(this.controllers,name,this.state);
    this.state.setControllers(this.controllers,this.dataConnections);
    this.settings = new SettingsController(id,name,this.map,this.miniMap,unitSystem,officeID,this,{floor:floor,suite:suite});
    this.objectSelector = new EditorSelectorController(this.controllers,this.settings);
    this.keyboardRouter = new KeyboardRouterController(this.state,this.map,this.objectSelector,this.controllers,this.dataConnections);
    this.mouseRouter = new MouseRouterController(
        this.controllers,
        this.state,
        this.map,
        this.miniMap,
        this.objectSelector,
        this.keyboardRouter,
        this.dataConnections
        );
    this.visibleLayers = {
        architect: true,
        zones: true,
        rooms: true,
        furniture: true,
        seats: true,
        kiosks: true
    }

    this.setLayerVisibility = function(layer,value){
        var visible;
        if(layer == undefined){
            for(var i in this.visibleLayers){
                visible = this.visibleLayers[i];
                if(visible){
                    this.controllers[i].redrawLayer();
                } else {
                    this.controllers[i].removeLayer();
                }
            }
            return;
        }

        if(value == 'checked'){
            this.controllers[layer].redrawLayer();
        } else {
            this.controllers[layer].removeLayer();
        }


    }

    // #####################################  Save/Load Functions  ############################################################

    this.updateLive = function(status){
        if(status != undefined){
            this.live = status;
        }
        if(this.live){
            $("#toggleLive").addClass("MainNav-Button_Toggle_On").removeClass("MainNav-Button_Toggle_Off");
        } else {
            $("#toggleLive").addClass("MainNav-Button_Toggle_Off").removeClass("MainNav-Button_Toggle_On");  
        }
    }

    this.getLiveStatus = function(){
        return this.live;
    }

    this.save = function(){
        var file = {};
        if(this.scenario){
            file.scenario = this.scenario;
            file.scenarioName = this.scenarioName;
            file.scenarioID = this.scenarioID;
        }
        file.live = this.live;
        file.id = this.settings.getID();
        file.name = this.settings.getMapName();
        file.officeID = this.settings.getOfficeID();
        file.map = this.map.save();
        file.settings = this.settings.save();
        file.dataConnections = this.dataConnections.save();
        file.controllers = {};
        for(var i in this.controllers){
            file.controllers[i] = this.controllers[i].save();
        }
        console.log(file)
        return file;
    }

    this.load = function(file){
        this.clear();
        this.live = file.live;
        this.state.load();
        this.map.load(file.map)
        this.map.loadView();
        this.miniMap.setMiniMap();
        this.miniMap.setScale();
        this.miniMap.setMinimapView();
        this.settings.load(file.settings);
        for(var i in file.controllers){
            console.log("Loading ",i)
            try{
                this.controllers[i].load(file.controllers[i],this.state,this.dataConnections);
            } catch(err){
                console.log(err);
            }
        }
        // The following determines the type of data connection loading.  If the map has a 'connections' object on it
        // then it should be an inactive map and so use the connections object to simulate live data. If no connection
        // object is present, then the map is live and an ajax based load occurs.
        if(file.connections){
            console.log('Data connections found');
            this.dataConnections.loadInactive(id,file.connections);
        } else {
            this.dataConnections.load(id);
        }
        this.objectSelector.selectSVG();
        this.updateLive();
        console.log("Load Complete");
    }

    this.loadScenario = function(file){
        this.clear();
        this.live = false;
        this.scenario = true;
        this.scenarioID = file.scenarioID;
        this.scenarioName = file.scenarioName;
        this.state.load();
        this.map.load(file.map)
        this.map.loadView();
        this.miniMap.setMiniMap();
        this.miniMap.setScale();
        this.miniMap.setMinimapView();
        this.settings.load(file.settings);
        for(var i in file.controllers){
            console.log("Loading ",i)
            try{
                this.controllers[i].load(file.controllers[i],this.state,this.dataConnections);
            } catch(err){
                console.log(err);
            }
        }
        this.dataConnections.loadInactive(id,file.connections);
        this.objectSelector.selectSVG();
        this.updateLive();
        console.log("Scenario Loaded");
    }

    // #####################################  Map Resize Functions  ############################################################

    // This function gets the border box values for all objects on the map and determines the max and min x and y positions on
    // the map.  This data can then be used to resize the map, or to shift/center the objects.
    this.getResizeMetrics = function(){
        var minimumDimension = 120; // 10ftx10ft
        var top,bottom,left,right,controllerBox;
        var xArray = [];
        var yArray = [];
        for(var controller in this.controllers){
            controllerBox = this.controllers[controller].getBorderBox();
            xArray = xArray.concat(controllerBox.xArray);
            yArray = yArray.concat(controllerBox.yArray);
        }
        top = Math.min.apply(null,yArray);
        bottom = Math.max.apply(null,yArray);
        left = Math.min.apply(null,xArray);
        right = Math.max.apply(null,xArray);

        return {
            top:top,
            bottom:bottom,
            left:left,
            right:right,
            minWidth: isNumeric(right)? right : minimumDimension,
            minHeight: isNumeric(bottom)? bottom : minimumDimension,
            usedWidth: isNumeric(right - left)? right - left : minimumDimension,
            usedHeight:isNumeric(bottom - top)? bottom - top : minimumDimension,
            currentHeight:this.map.originalHeight(),
            currentWidth:this.map.originalWidth(),
        }
    }

    // This function resizes the map by adding or subracting from the bottom or right portions
    this.resizeMap = function(width,height){
        this.map.resizeMap(width,height);
        this.miniMap.setMiniMap();
        this.miniMap.setScale();
        this.miniMap.setMinimapView();
    }

    // Shifts all map objects in all controllers.  This is used when centering or trimming the map.
    this.shiftObjects = function(shiftLeft,shiftUp){
        for(var controller in this.controllers){
            try{
                this.controllers[controller].moveAll(shiftLeft,shiftUp);
            } catch(err){
                console.log(err);
            }
        }        
    }

    // #####################################  Helper Functions  ############################################################

    // This hides and deletes all map objects.
    this.clear = function(){
        for(var i in this.controllers){
            this.controllers[i].removeAll();
        }
    }

    this.getName = function(){
        return this.settings.getMapName();
    }

    this.getMapID = function(){
        return this.settings.getID();
    }

    this.getOfficeID = function(){
        return this.settings.getOfficeID();
    }

    this.getUnitSystem = function(){
        return this.settings.getUnitSystem();
    }

    this.isScenario = function(){
        return this.scenario;
    }

    // Hides all map objects but doesn't delete them
    this.hide = function(){
        this.map.saveView();
        for(var i in this.controllers){
            this.controllers[i].removeLayer();
        }
    }

    this.refreshLayers = function(){
        // for(var i in this.controllers){
        //     this.controllers[i].removeLayer();
        // }        
        // for(var i in this.controllers){
        //     this.controllers[i].redrawLayer();
        // }           
    }

    // Generally called when returning to the map after another map was viewed
    this.redraw = function(){
        this.map.reloadMap();
        this.settings.setUnit();
        for(var i in this.controllers){
            this.controllers[i].redrawLayer();
        }        
        this.objectSelector.selectSVG();
        this.map.loadView();
        this.miniMap.setMiniMap();
        this.miniMap.setScale();
        this.miniMap.setMinimapView();
        this.updateLive();
    }

    // Returns true if a map object is selected
    this.objectsSelected = function(){
        for(var i in this.controllers){
            if(this.controllers[i].objectsAreSelected()){
                return true;
            }
        }
        return false;
    }

    this.getSelected = function(){
        return this.objectSelector.getSelected();
    }

    this.goToPoint = function(point){
        this.miniMap.setMiniMap();
        this.miniMap.setScale();
        this.miniMap.setMinimapView();
        this.map.goToPoint(point);
    }

    this.updateLive();
    this.objectSelector.selectSVG(); // Starting selected object on load should be the map itself
}