//#################################  Viewer SVG Router #####################################################

function SvgClickRouterController(controllers,state,map,handleRouter,objectSelector){
	this.controllers = controllers;
	this.clicked = function(id,svgObject,button,ctrlKey){
        if(svgObject.hasClass("architect")){
            if(state.state == "openSelector") { 
                var subclass;
                if(svgObject.hasClass("door")){subclass = "Door";}
                if(svgObject.hasClass("window")){subclass = "Window";}
	            this.controllers.architect.selectOne(id.slice(1),subclass);
	            state.setState("dragArchitect");
	            this.controllers.architect.startDrag(subclass,controllers);
	            objectSelector.selectSVG(id.slice(1),"architect",subclass);
            }
        }

		if(svgObject.hasClass("Seat")){
	        if(state.state == "openSelector") { 
	            this.controllers.seats.selectOne(id.slice(1));
	            state.setState("dragSeat");
	            objectSelector.selectSVG(id.slice(1),"seats");
	            this.controllers.seats.startDrag("Seat");
	        }
		}

		if(svgObject.hasClass("Kiosk")){
	        if(state.state == "openSelector") { 
	            this.controllers.kiosks.selectOne(id.slice(1));
	            state.setState("dragKiosk");
	            objectSelector.selectSVG(id.slice(1),"kiosks");
	            this.controllers.kiosks.startDrag("Kiosk");
	        }
		}

		if(svgObject.hasClass("Maplink")){
	        if(state.state == "openSelector") { 
	            this.controllers.maplinks.selectOne(id.slice(1));
	            state.setState("dragMaplink");
	            objectSelector.selectSVG(id.slice(1),"maplinks");
	            this.controllers.maplinks.startDrag("Maplink");
	        }
		}

		if(svgObject.hasClass("furniture")){
	        if(state.state == "openSelector") {
	            var objID = id.slice(1);
	            if(svgObject.hasClass("subobject")){
	            	var type = svgObject[0].classList[2];
	            	this.controllers.furniture.selectOne(objID,type);
	            	state.setState("dragFurniture");
	            	objectSelector.selectSVG(objID,"furniture",type);
	            	this.controllers.furniture.startDrag(type);
	            } else {
		            this.controllers.furniture.selectOne(objID);
		            state.setState("dragFurniture");
		            objectSelector.selectSVG(objID,"furniture");
		            this.controllers.furniture.startDrag(this.controllers);	            	
	            }
	        }
		}

		if(svgObject.hasClass("map")){
	        if(state.state == "openSelector") { 
	            objectSelector.selectSVG();
	        }
		}

		if(svgObject.hasClass("Zone")){
	        if(button == 1){
	           	if(state.state == "moveZone"){
	                this.controllers.zones.startDrag();
	                return;
	            }
	            if(ctrlKey){
	            	this.controllers.zones.selectMultiple(id);
	            } else {
	            	this.controllers.zones.selectOne(id);
	            	objectSelector.selectSVG(id,"zones");
	            }
	        }
		}

		if(svgObject.hasClass("Room")){
	        if(button == 1){
	           	if(state.state == "moveRoom"){
	                this.controllers.rooms.startDrag();
	                return;
	            }
	            if(ctrlKey){
	            	this.controllers.rooms.selectMultiple(id);
	            } else {
	            	this.controllers.rooms.selectOne(id);
	            	objectSelector.selectSVG(id,"rooms");
	            }
	        }
		}

		if(svgObject.hasClass("pointHandle")){
	        if(button == 1){
	            state.triggerNewRevisionStep();
	            if(ctrlKey){
	                handleRouter.routeHandleSelect(id);
	            } else{
	                handleRouter.routeHandlePress(id);
	                state.setState("dragHandle");
	            }
	        }
		}
	}
}