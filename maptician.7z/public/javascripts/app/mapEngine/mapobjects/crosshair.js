//#################################  Cross-Hair Controller #####################################################

function scaleAfterZoom(miniMapViewBox,map){ // TODO not called at the moment, but this should scale the crosshair width at different zoom levels
    $("#xCross").css("stroke-width",1/map.scale);
    $("#yCross").css("stroke-width",1/map.scale);
}

function CrossHairController(map){
    this.color = "lightgray";
    this.active = false;
    this.xCross = null;
    this.yCross = null;
    this.create = function(){
        if(this.active == true){
            this.remove();
            var vertLine = document.createElementNS('http://www.w3.org/2000/svg', 'line');
            vertLine.setAttribute('x1',map.pointerCoords().x);
            vertLine.setAttribute('y1',0);
            vertLine.setAttribute('x2',map.pointerCoords().x);
            vertLine.setAttribute('y2',map.map.outerHeight(true)/map.scale);
            vertLine.setAttribute('id',"yCross");
            vertLine.setAttribute('style',"stroke:"+this.color+";stroke-width:1");
            $('#topGroup').append(vertLine);
            this.yCross = $("#yCross");
            var horizLine = document.createElementNS('http://www.w3.org/2000/svg', 'line');
            horizLine.setAttribute('x1',0);
            horizLine.setAttribute('y1',map.pointerCoords().y);
            horizLine.setAttribute('x2',map.map.outerWidth(true)/map.scale);
            horizLine.setAttribute('y2',map.pointerCoords().y);
            horizLine.setAttribute('id',"xCross");
            horizLine.setAttribute('style',"stroke:"+this.color+";stroke-width:1");
            $('#topGroup').append(horizLine);
            this.xCross = $("#xCross");
        }
    };
    this.move = function(xPos,yPos){
        if(this.active){
            this.xCross.attr({
                y1:map.snapRound(yPos),
                y2:map.snapRound(yPos),
            });
            this.yCross.attr({
                x1:map.snapRound(xPos),
                x2:map.snapRound(xPos),
            });
        }
    }
    this.remove = function(){
        this.xCross ? this.xCross.remove() : null;
        this.yCross ? this.yCross.remove() : null;
    }
    this.activate = function(){
        if(this.active === false){
            this.active = true;
            this.create();  
        }
    }
    this.deactivate = function(){
        if(this.active){
            this.remove();
            this.active = false;
        }
    }
}