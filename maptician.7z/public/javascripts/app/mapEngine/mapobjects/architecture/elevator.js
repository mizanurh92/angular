function Elevator(id,state,map){
    MapObject.call(this,"Elevator",id); // Sets Elevator as subclass of MapObject
    this.state = state; // Reference to the State Controller
    this.map = map; // Reference to the Map Controller

    this.type = "Elevator"; // Can be removed - lives on superclass - just here for reminder
    this.id = id; // Can be removed - lives on superclass - just here for reminder
    this.handleDragging = ""; // Can be removed - lives on superclass - just here for reminder
    this.isSelected = false;   // Can be removed - lives on superclass - just here for reminder

    this.fill = "#D3D3D3";  // Fill Color
    this.stroke = "#000000";  // Stroke Color
    this.lineWidth = 2;  // Width of the line stroke
    this.labelStyle = 2; // Determines how the labels are displayed.  Defaults to always showing the labels
    this.labelColor = "#000000";
    this.selectedColor = "#ff0000";
    this.labelSize = 15;
    this.minimumDimension = 36; // Used to set a minimum length or width of the elevator TODO ##### Need to create a minimum dimension control

    this.points = []; // Array containing the points making up the elevator
        // Initial positions
        // 0 - Upper left point
        // 1 - Upper right point
        // 2 - Lower right point
        // 3 - Lower left point
        // 4 - Top Edge Point
        // 5 - Right Edge Point
        // 6 - Bottom Edge Point
        // 7 - Left Edge Point
        // 8 - Rotation handle point

    // The following are aliases to the various elevator svg elements.  This prevents having to do a lookup for each change
    this.elevator = null;

    this.lengthLabel = {};  // Path label object for length label
    this.widthLabel = {};  // Path label object for width label
    this.length = 1;  // Length of the elevator (initially top dimension)
    this.width = 0; // Width of the elevator (initially side dimension)
    this.initialDims = {};  // Holds the initial dimensions of the elevator during a resize event
    this.angle = 0;  // Angle in radians of the elevator with respect to the x-axis
    this.centerPoint = {}; // Calculated and used for rotation
    this.packageParameters = [ // Used in undo/redo/duplicate/save/load methods
        "type",
        "id",
        "fill",
        "stroke",
        "lineWidth",
        "labelStyle",
        "minimumDimension"
    ];
}
    Elevator.prototype = Object.create(MapObject.prototype); // Links the prototype to the superclass
    Elevator.prototype.constructor = Elevator;

// ##########################################  Standard Object Interface Functions  ##################################################################
    
    Elevator.prototype.create = function(){ // This creates all components of the elevator object
        var map = this.map;
        var pos = map.pointerCoords();
        this.points[0] = new point(map.snapRound(pos.x),map.snapRound(pos.y),"AREP00"+this.id); // Upper Left
        this.points[1] = new point(map.snapRound(pos.x),map.snapRound(pos.y),"AREP01"+this.id); // Upper Right
        this.points[2] = new point(map.snapRound(pos.x),map.snapRound(pos.y),"AREP02"+this.id); // Lower Right
        this.points[3] = new point(map.snapRound(pos.x),map.snapRound(pos.y),"AREP03"+this.id); // Lower Left
        this.points[4] = new point((this.points[0].x+this.points[1].x)/2,(this.points[0].y+this.points[1].y)/2,"AREP04"+this.id); // Top Edge
        this.points[5] = new point((this.points[1].x+this.points[2].x)/2,(this.points[1].y+this.points[2].y)/2,"AREP05"+this.id); // Right Edge
        this.points[6] = new point((this.points[2].x+this.points[3].x)/2,(this.points[2].y+this.points[3].y)/2,"AREP06"+this.id); // Bottom Edge
        this.points[7] = new point((this.points[3].x+this.points[0].x)/2,(this.points[3].y+this.points[0].y)/2,"AREP07"+this.id); // Left Edge
        this.createSVG();
        this.addLabels();
    }

    Elevator.prototype.update = function(){
        this.calculateAngle();
        this.calculateLength();
        this.calculateWidth();
        this.updateSVG();
        this.updateSidePoints();
        this.updateRotatePoint();
        this.updateLabels();
    }

    Elevator.prototype.remove = function(){
        this.removeHandles();
        this.removeSVG();
        this.removeLabels();
    }

    Elevator.prototype.redraw = function(){  // Redraws all svg screen objects (if otherwise visible) after they have been removed
        this.createSVG();
        this.setLabelStyle(this.labelStyle);
    }

    Elevator.prototype.activate = function(multiselect){
        this.elevator.css("stroke",this.selectedColor);
        this.isSelected = true;
        if(!multiselect){
            this.drawHandles();
        }
        this.setLabelStyle(this.labelStyle);
    }

    Elevator.prototype.deactivate = function(){
        this.elevator.css("stroke",this.stroke);
        this.isSelected = false;
        this.removeHandles();
        this.setLabelStyle(this.labelStyle);
    }

    Elevator.prototype.getOutlinePoints = function(){
        var pointObject = [];
        for(var i = 0;i < 4;i++){
            pointObject.push(this.points[i].getPoint());
        }
        return pointObject;
    }
    
// ##########################################  Point Handle Functions  ##################################################################

    Elevator.prototype.handlePress = function(handleID){  // Receives a handle press event and saves the mouse location and handle ID for drag process
        for(var i = 0;i < this.points.length;i++){
            this.points[i].setDragReference();
        }
        this.getCenter();
        this.initialDims["widthMargin"] = this.width - this.minimumDimension;
        this.initialDims["lengthMargin"] = this.length - this.minimumDimension;
        this.handleDragging = handleID.slice(4,6)*1;
        if(this.handleDragging == 8){
            this.points[0].setRotateAngle(this.centerPoint.x,this.centerPoint.y,this.angle);
            this.points[1].setRotateAngle(this.centerPoint.x,this.centerPoint.y,this.angle);
            this.points[2].setRotateAngle(this.centerPoint.x,this.centerPoint.y,this.angle);
            this.points[3].setRotateAngle(this.centerPoint.x,this.centerPoint.y,this.angle);
        }
        this.undoPackage = this.createPackage();
    }

    Elevator.prototype.handleDrag = function(){  // Receives a handle drag event and changes the point associated with the handle based on the new location
        rectHandleDrag(
            this.points,
            this.handleDragging,
            this.angle,
            this.minimumDimension,
            this.initialDims,
            this.centerPoint,
            this.width,
            this.length,
            this.map
        );
        this.update();
    }

    Elevator.prototype.finalizeHandleDrag = function(){
        
        this.sendPackages();
    }

    Elevator.prototype.drawHandles = function(){
        for(var i = 0;i < this.points.length;i++){
            this.points[i].drawHandle();
        }
    }

    Elevator.prototype.removeHandles = function(){ // Removes the handles on the wall endpoints
        for(var i = 0;i < this.points.length;i++){
            this.points[i].removeHandle();
        }
    }

    Elevator.prototype.createRotatePoint = function(){
        var distance = 18;
        var topCenterX = (this.points[0].x + this.points[1].x)/2;
        var topCenterY = (this.points[0].y + this.points[1].y)/2;
        this.points[8] = new point(topCenterX + distance * Math.cos(this.angle+Math.PI/2),topCenterY - distance * Math.sin(this.angle+Math.PI/2),"AREP08"+this.id);
    }

    Elevator.prototype.updateRotatePoint = function(){
        if(this.points[8] != undefined){
            var distance = 18;
            this.points[8].updatePosition(this.points[4].x + distance * Math.cos(this.angle+Math.PI/2),this.points[4].y - distance * Math.sin(this.angle+Math.PI/2))
        }
    }

// ##########################################  Application Mechanics (Undo/Redo/Duplicate/Save/Load)  #############################################

    Elevator.prototype.duplicate = function(original){
        for(var i = 0;i < original.points.length;i++){
            this.points.push(new point(original.points[i].x,original.points[i].y,original.points[i].id.substring(0,6)+this.id))
        }
        for(var i = 0;i < this.packageParameters.length;i++){
            if(this.packageParameters[i] != "id"){
                this[this.packageParameters[i]] = original[this.packageParameters[i]];
            }
        }
        this.createSVG();
        this.addLabels();
        this.move(12,12);
    }

    Elevator.prototype.createPackage = function(){
        var package = {points:[]};
        for(var i = 0;i < this.points.length;i++){
            package.points.push(this.points[i].getPoint());
        }
        for(var i = 0;i < this.packageParameters.length;i++){
            package[this.packageParameters[i]] = this[this.packageParameters[i]];
        }
        package.controller = "architect";
        package.packageType = "modify";
        return package;
    }

    Elevator.prototype.loadPackage = function(package){
        // It doesn't matter if it is an undo or redo package, the impact is to reset the object to a former state
        for(var i = 0;i < this.points.length;i++){
            this.points[i].updatePosition(package.points[i].x,package.points[i].y);
        }
        for(var i = 0;i < this.packageParameters.length;i++){
            this[this.packageParameters[i]] = package[this.packageParameters[i]];
        }
        this.update();
    }

    Elevator.prototype.sendPackages = function(){
        // It is important to know that the undo and redo packages aren't the same.  If they are, there was no real action taken and
        // an undo or redo event will have no apparent effect
        var undo = this.undoPackage;
        var redo = this.createPackage();
        var same = true; // Used to determine whether the two packages are the same (no actual event occured)
        for(var i = 0;i < redo.points.length;i++){ // Runs through the points first as the most common event changes
            if(undo.points[i].x != redo.points[i].x || undo.points[i].y != redo.points[i].y){
                same = false;
                break; // breaks as soon as a single difference is found
            }
        }       
        if(same){ // No need to start second loop if a difference was already found
            for(var i = 0;i < this.packageParameters.length;i++){
                if(undo[this.packageParameters[i]] != redo[this.packageParameters[i]]){
                    same = false;
                    break;
                }
            }
        }
        // Packages are sent essentially simultaneously to prevent having mismatched packages if the action isn't finalized
        if(same == false){
            this.state.addUndoPackage(undo);
            this.state.addRedoPackage(redo);
        }
    }

    Elevator.prototype.save = function(){
        var saveFile = {points:[]}
        for(var i = 0;i < this.points.length;i++){
            saveFile.points.push(this.points[i].getSavePoint());
        }
        for(var i = 0;i < this.packageParameters.length;i++){
            saveFile[this.packageParameters[i]] = this[this.packageParameters[i]];
        }
        return saveFile
    }

    Elevator.prototype.load = function(saveFile){
        // Note that this method assumes that the create function has not been called - will not work if it has been
        for(var i = 0;i < saveFile.points.length;i++){
            this.points.push(new point(saveFile.points[i].x,saveFile.points[i].y,saveFile.points[i].id));
        }
        for(var i = 0;i < this.packageParameters.length;i++){
            this[this.packageParameters[i]] = saveFile[this.packageParameters[i]];
        }
        this.createSVG(); 
        this.addLabels();
        this.update();
    }

// ##########################################  Drag and Move Functions  #############################################

    Elevator.prototype.startDrag = function(optionsObj){ // Saves the origin of a drag event for move calculations
        var options = optionsObj || {};
        var subclass = options.subclass || null;
        this.snapCandidates = options.snapPoints || [];
        this.undoPackage = this.createPackage();
        for(var i = 0;i < this.points.length;i++){
            this.points[i].setDragReference();
        }
    }

    Elevator.prototype.drag = function(){ // Drags the wall upon a left-button down on the wall layer svg and dragging the mouse
        var map = this.map;
        var coords = map.pointerCoords(); // gets the latest mouse location
        var xMove = coords.x-map.handle.x/map.scale;
        var yMove = coords.y-map.handle.y/map.scale;

        var isSnapCandidates = this.snapCandidates.length;
        var distDragged;
        if(isSnapCandidates && map.snapGridActive){ // This is necessary to snap objects while snap grid is on
            distDragged = this.points[0].dragOffset(xMove,yMove,{gridResolution:map.snapGridResolution,snapToGrid:false});
        } else{
            distDragged = this.points[0].dragOffset(xMove,yMove,{gridResolution:map.snapGridResolution,snapToGrid:map.snapGridActive});  
        }
        this.points[1].dragOffset(distDragged.x,distDragged.y);
        this.points[2].dragOffset(distDragged.x,distDragged.y);
        this.points[3].dragOffset(distDragged.x,distDragged.y);
        this.update(); 
        
        if(isSnapCandidates){
            var objectSnapped = snapObject(this.getSnapPoints(),this.snapCandidates,
                {points:true,edges:true,sensitivity:this.snapSensitivity});
            if(objectSnapped){
                xMove += objectSnapped.xMove;
                yMove += objectSnapped.yMove;
                console.log(xMove,yMove);
                for(var i = 0;i < 4;i++){
                    this.points[i].dragOffset(xMove,yMove);
                }
            } else if(map.snapGridActive){  // This reimplements snapgrid if no snaps matches are found
                distDragged = this.points[0].dragOffset(xMove,yMove,{gridResolution:map.snapGridResolution,snapToGrid:map.snapGridActive});
                this.points[1].dragOffset(distDragged.x,distDragged.y);
                this.points[2].dragOffset(distDragged.x,distDragged.y);
                this.points[3].dragOffset(distDragged.x,distDragged.y);
            }              
        }
        
        this.update();
    }

    Elevator.prototype.finalizeDrag = function(){
        
        this.sendPackages();
    }

    Elevator.prototype.move = function(direction){ // Moves the wall by an x and y distance, called by the architecture controller as a result of a keyboard press
        var map = this.map;
        this.undoPackage = this.createPackage();
        var x = 0;
        var y = 0;
        switch(direction){
            case "up":
            y = -map.snapGridResolution;
            break;
            case "down":
            y = map.snapGridResolution;
            break;
            case "right":
            x = map.snapGridResolution;
            break;
            case "left":
            x = -map.snapGridResolution;
            break;
        }
        this.points[0].shiftPosition(x,y);
        this.points[1].shiftPosition(x,y);
        this.points[2].shiftPosition(x,y);
        this.points[3].shiftPosition(x,y);
        this.update();
        this.sendPackages();
    }

// ##########################################  Object SVG Functions  ##################################################################

    Elevator.prototype.createSVG = function(){
        var elevator = document.createElementNS('http://www.w3.org/2000/svg', 'path');
        elevator.setAttribute('d',this.getElevatorPath());
        elevator.setAttribute('id',"a"+this.id);
        elevator.setAttribute('class',"architect elevator");
        elevator.setAttribute('pointer-events',"all");
        elevator.setAttribute('style',"stroke-linecap:square;stroke:"+this.stroke+";fill:"+this.fill+";stroke-width:"+this.lineWidth);
        $('#elevators').append(elevator);
        this.elevator = $("#a"+this.id);
    }

    Elevator.prototype.getElevatorPath = function(){
        var path = ""
        path += "M " + this.points[0].x + " " + this.points[0].y; // Start point at upper left of the elevator
        path += "L " + this.points[1].x + " " + this.points[1].y;  // Point at the upper right
        path += "L " + this.points[2].x + " " + this.points[2].y;  // Point at the lower right
        path += "L " + this.points[3].x + " " + this.points[3].y;  // Point at the lower left
        path += "L " + this.points[0].x + " " + this.points[0].y;  // Return and close of position
        path += "M " + this.points[0].x + " " + this.points[0].y;  // Return and close of position
        path += "L " + this.points[2].x + " " + this.points[2].y;  // Point at the lower right
        path += "M " + this.points[1].x + " " + this.points[1].y;  // Point at the upper right
        path += "L " + this.points[3].x + " " + this.points[3].y;  // Point at the lower left
        return path;
    }

    Elevator.prototype.draw = function(){ 
        var map = this.map;
        var pos = map.pointerCoords(); 
        this.points[1].updatePosition(map.snapRound(pos.x),this.points[1].y);
        this.points[2].updatePosition(map.snapRound(pos.x),map.snapRound(pos.y));
        this.points[3].updatePosition(this.points[3].x,map.snapRound(pos.y));
        this.update();
    }

    Elevator.prototype.finalizeDraw = function(){  // To make the initial point numbers and corners consistent in all draw scenarios the
        // following checks to ensure that point zero is at the upper left and the points are numbered clockwise from there
        // If this isn't the case, this function flips the points on the necessary axis to make it the case
        if(this.points[0].y > this.points[3].y){
            var temp0 = this.points[0].getPoint();
            var temp1 = this.points[1].getPoint();
            var temp2 = this.points[2].getPoint();
            var temp3 = this.points[3].getPoint();
            this.points[0].updatePosition(temp3.x,temp3.y);
            this.points[1].updatePosition(temp2.x,temp2.y);
            this.points[2].updatePosition(temp1.x,temp1.y);
            this.points[3].updatePosition(temp0.x,temp0.y);
        }
        if(this.points[0].x > this.points[1].x){
            var temp0 = this.points[0].getPoint();
            var temp1 = this.points[1].getPoint();
            var temp2 = this.points[2].getPoint();
            var temp3 = this.points[3].getPoint();
            this.points[0].updatePosition(temp1.x,temp1.y);
            this.points[1].updatePosition(temp0.x,temp0.y);
            this.points[2].updatePosition(temp3.x,temp3.y);
            this.points[3].updatePosition(temp2.x,temp2.y);
        }
        this.calculateAngle();
        this.createRotatePoint();
        this.update();
        this.setLabelStyle(this.labelStyle);
    }

    Elevator.prototype.checkValid = function(){ // Returns true if this was a validly drawn object
        this.calculateLength();
        this.calculateAngle();
        return this.length > 0 && this.width > 0;
    }

    Elevator.prototype.cancelDraw = function(){
        
        this.remove();
    }

    Elevator.prototype.updateSVG = function(){

        this.elevator.attr("d",this.getElevatorPath());
    }

    Elevator.prototype.removeSVG = function(){
        
        this.elevator ? this.elevator.remove() : null;
    }

    Elevator.prototype.updateSidePoints = function(){
        this.points[4].updatePosition((this.points[0].x+this.points[1].x)/2,(this.points[0].y+this.points[1].y)/2); // Top Edge
        this.points[5].updatePosition((this.points[1].x+this.points[2].x)/2,(this.points[1].y+this.points[2].y)/2); // Right Edge
        this.points[6].updatePosition((this.points[2].x+this.points[3].x)/2,(this.points[2].y+this.points[3].y)/2); // Bottom Edge
        this.points[7].updatePosition((this.points[3].x+this.points[0].x)/2,(this.points[3].y+this.points[0].y)/2); // Left Edge
    }

// ##########################################  Object Calculation Functions  ############################################################

    Elevator.prototype.calculateLength = function(){  // Side Edge
        var xComponent = this.points[0].x - this.points[3].x;
        var yComponent = this.points[0].y - this.points[3].y;
        this.length = Math.sqrt(Math.pow(xComponent,2)+Math.pow(yComponent,2));
        return this.length;
    }

    Elevator.prototype.calculateWidth = function(){  // Top Edge
        var xComponent = this.points[0].x - this.points[1].x;
        var yComponent = this.points[0].y - this.points[1].y;
        this.width = Math.sqrt(Math.pow(xComponent,2)+Math.pow(yComponent,2));
        return this.width;
    }

    Elevator.prototype.calculateAngle = function(){  
        
        this.angle = Math.atan2((this.points[0].y-this.points[1].y),(this.points[1].x-this.points[0].x));
    }

    Elevator.prototype.getCenter = function(){
        this.centerPoint = {
            x:(this.points[0].x + this.points[2].x)/2 ,
            y:(this.points[0].y + this.points[2].y)/2
        }
        return this.centerPoint;
    }
    
// ##########################################   Label Functions  ##################################################################

    Elevator.prototype.setLabelStyle = function(styleNumber){ // Changes the display behavior of the distance labels based on a style number from a slider
        if(styleNumber != undefined){
            this.labelStyle = styleNumber;
        }
        switch(this.labelStyle){
            case 0: // Never show labels
                this.removeLabels();
            break;
            case 1: // Only show labels when selected
                if(this.isSelected == true){
                    this.redrawLabels();
                } else {
                   this.removeLabels(); 
                }
            break;
            case 2: // Always show labels (default)
                this.redrawLabels();
            break;
        }
        return this.labelStyle;
    }

    Elevator.prototype.addLabels = function(){ // Creates a length label object and adds it to the wall 
        if(!(this.lengthLabel instanceof pathTextLabel)){ // Check to ensure that a label doesn't already exist
            var id = generateUUID();
            this.lengthLabel = new pathTextLabel("LL"+id,this.points[3],this.points[0],this.labelColor,this.labelSize,"50%",-5,"elevators");
            this.lengthLabel.draw();
            this.widthLabel = new pathTextLabel("WL"+id,this.points[0],this.points[1],this.labelColor,this.labelSize,"50%",-5,"elevators");
            this.widthLabel.draw();
            this.updateLabels();
        }
    }

    Elevator.prototype.removeLabels = function(){  // Removes the length label from the wall
        this.lengthLabel.remove();
        this.widthLabel.remove();
    }

    Elevator.prototype.redrawLabels = function(){
        this.lengthLabel.redraw();
        this.widthLabel.redraw(); 
    }

    Elevator.prototype.updateLabels = function(){
        this.lengthLabel.updateDist();
        this.widthLabel.updateDist();
    }

// ##########################################  Selector Interface Functions  ######################################################################

    Elevator.prototype.setProperty = function(property,value){
        switch(property){
            case "objectLength":
                this.setobjectLength(value);
            break;
            case "objectWidth":
                this.setobjectWidth(value);
            break;
            case "objectAngle":
                this.setobjectAngle(toRads(value));
            break;
            case "objectStrokeColor":
                console.log("stroke")
                this.setobjectStrokeColor(value);
            break;
            case "objectFillColor":
                this.setobjectFillColor(value);
            break;
            case "objectLabelStyle":
                this.setLabelStyle(value);
            break;
            case "objectLabelColor":
                this.labelColor = value;
                this.lengthLabel.setColor(value);
                this.widthLabel.setColor(value);
            break;
            case "objectLabelSize":
                this.labelSize = value;
                this.lengthLabel.setFontSize(value);
                this.widthLabel.setFontSize(value);
            break;
        }
    }

    Elevator.prototype.getObjectData = function(subcategory,id){  // This function is called when the user selects a wall object
        var thisData = {};
        thisData.data = {
            objectType: {type:"label",value:"Elevator"},
            objectLength: {type:"spinner",value:this.renderLength(this.length)},
            objectWidth: {type:"spinner",value:this.renderLength(this.width)},
            objectAngle: {type:"spinner",value:toDeg(this.angle)},
            objectStrokeColor: {type:"color",value:this.stroke},
            objectFillColor: {type:"color",value:this.fill},
            objectLabelStyleText: {type:"na",value:Elevator.prototype.slide(null,{value:this.labelStyle})},
            objectLabelStyle: {type:"slider",value:this.labelStyle,min:0,max:2,slide:Elevator.prototype.slide},
            objectLabelColor: {type:"na",value:null},
            objectLabelSize: {type:"spinner",value:this.lengthLabel.fontSize},
        }
        thisData.dividers = {
            sizeDivider:true,
            positionDivider:true,
            colorDivider:true,
            labelsDivider:true
        }
        return thisData;
    }

    Elevator.prototype.slide = function(event,ui){
            var message = "";
            switch(ui.value){
                case 0:
                message = "No Labels"
                break;
                case 1:
                message = "Show Labels on Select"
                break;
                case 2:
                message = "Always Show Labels"
                break;
            }
            $( "#objectLabelStyleText" ).html(message);
    }

    Elevator.prototype.setobjectLength = function(value){
        var newX3 = value * Math.cos(this.angle - Math.PI/2) + this.points[0].x;
        var newY3 = -value * Math.sin(this.angle - Math.PI/2) + this.points[0].y;
        var newX2 = value * Math.cos(this.angle - Math.PI/2) + this.points[1].x;
        var newY2 = -value * Math.sin(this.angle - Math.PI/2) + this.points[1].y;
        this.points[2].updatePosition(newX2,newY2);
        this.points[3].updatePosition(newX3,newY3);
        this.update();
    }

    Elevator.prototype.setobjectWidth = function(value){
        var newX1 = value * Math.cos(this.angle) + this.points[0].x;
        var newY1 = -value * Math.sin(this.angle) + this.points[0].y;
        var newX2 = value * Math.cos(this.angle) + this.points[3].x;
        var newY2 = -value * Math.sin(this.angle) + this.points[3].y;
        this.points[1].updatePosition(newX1,newY1);
        this.points[2].updatePosition(newX2,newY2);
        this.update();
    }

    Elevator.prototype.setobjectAngle = function(angle){
        this.getCenter();
        this.points[0].setRotateAngle(this.centerPoint.x,this.centerPoint.y,this.angle);
        this.points[1].setRotateAngle(this.centerPoint.x,this.centerPoint.y,this.angle);
        this.points[2].setRotateAngle(this.centerPoint.x,this.centerPoint.y,this.angle);
        this.points[3].setRotateAngle(this.centerPoint.x,this.centerPoint.y,this.angle);
        this.points[0].rotateAroundCenter(this.centerPoint.x,this.centerPoint.y,angle);
        this.points[1].rotateAroundCenter(this.centerPoint.x,this.centerPoint.y,angle);
        this.points[2].rotateAroundCenter(this.centerPoint.x,this.centerPoint.y,angle);
        this.points[3].rotateAroundCenter(this.centerPoint.x,this.centerPoint.y,angle);
        this.update();
    }

    Elevator.prototype.setobjectStrokeColor = function(color){
        var isOk  = /(^#[0-9A-F]{6}$)|(^#[0-9A-F]{3}$)/i.test(color)
        if(isOk){
            this.stroke = color;
        } else {
            console.log("color not recognized")
        }
        this.elevator.css("stroke",this.stroke);
    }

    Elevator.prototype.setobjectFillColor = function(color){
        var isOk  = /(^#[0-9A-F]{6}$)|(^#[0-9A-F]{3}$)/i.test(color)
        if(isOk){
            this.fill = color;
        } else {;
            console.log("color not recognized")
        }
        this.elevator.css("fill",this.fill);
    }

    Elevator.prototype.setStrokeWidth = function(value){
        this.lineWidth = value;
        this.update();
        return this.lineWidth;
    }

