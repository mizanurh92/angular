function Toilet(id,state,map){
    MapObject.call(this,"Toilet",id); // Sets subclass of MapObject
    this.state = state; // Reference to the State Controller
    this.map = map; // Reference to the Map Controller

    this.type = "Toilet"; // Can be removed - lives on superclass - just here for reminder
    this.id = id; // Can be removed - lives on superclass - just here for reminder
    this.handleDragging = ""; // Can be removed - lives on superclass - just here for reminder
    this.isSelected = false;   // Can be removed - lives on superclass - just here for reminder
    this.fill = "#ffffff";  // Fill Color
    this.selectedColor = "#ff0000";
    this.stroke = "#000000";
    this.lineWidth = 1.25;  // Width of the line stroke

    this.length = 28;  // Length of the object (initially side dimension)
    this.width = 20; // Width of the object (initially top dimension)
    this.points = []; // Array containing the points making up the column
        // Initial positions
        // 0 - Upper left point
        // 1 - Upper right point
        // 2 - Lower right point
        // 3 - Lower left point
        // 4 - Top Edge Point
        // 5 - Right Edge Point
        // 6 - Bottom Edge Point
        // 7 - Left Edge Point
        // 8 - Rotation handle point

    // The following are aliases to the various toilet svg elements.  This prevents having to do a lookup for each change
    this.tank = null;
    this.base = null;
    this.bowl = null;

    this.initialDims = {};  // Holds the initial dimensions of the object during a resize event
    this.defaultSize = {width:20,height:28};
    this.angle = 0;  // Angle in radians of the object with respect to the x-axis
    this.centerPoint = {}; // Calculated and used for rotation
    this.dragAngle = 0; // Used for rotation, gives the starting angle of a rotation event
    this.minimumDimension = 12; // Used to set a minimum length or width of the object
    this.widthMargin = 2;
    this.topMargin = 4;
    this.sinkRounding = 4;
    this.packageParameters = [ // Used in undo/redo/duplicate/save/load methods
            "type",
            "id",
            "fill",
            "stroke",
            "lineWidth",
            "minimumDimension",
            "widthMargin",
            "topMargin",
        ];
}
    Toilet.prototype = Object.create(MapObject.prototype); // Links the prototype to the superclass
    Toilet.prototype.constructor = Toilet;

// ##########################################  Standard Object Interface Functions  ##################################################################

    Toilet.prototype.create = function(){ // This creates all components of the object
        var pos = this.map.pointerCoords();
        this.points[0] = new point(pos.x,pos.y,"ARCP00"+this.id); // Upper Left
        this.points[1] = new point(pos.x+this.defaultSize.width,pos.y,"ARCP01"+this.id); // Upper Right
        this.points[2] = new point(pos.x+this.defaultSize.width,pos.y+this.defaultSize.height,"ARCP02"+this.id); // Lower Right
        this.points[3] = new point(pos.x,pos.y+this.defaultSize.height,"ARCP03"+this.id); // Lower Left
        this.points[4] = new point((this.points[0].x+this.points[1].x)/2,(this.points[0].y+this.points[1].y)/2,"ARCP04"+this.id); // Top Edge
        this.points[5] = new point((this.points[1].x+this.points[2].x)/2,(this.points[1].y+this.points[2].y)/2,"ARCP05"+this.id); // Right Edge
        this.points[6] = new point((this.points[2].x+this.points[3].x)/2,(this.points[2].y+this.points[3].y)/2,"ARCP06"+this.id); // Bottom Edge
        this.points[7] = new point((this.points[3].x+this.points[0].x)/2,(this.points[3].y+this.points[0].y)/2,"ARCP07"+this.id); // Left Edge
        this.createSVG();
    }

    Toilet.prototype.update = function(){
        this.calculateAngle();
        this.calculateLength();
        this.calculateWidth();
        this.updateSVG(); // updates side points in the method
        this.updateRotatePoint();
    }

    Toilet.prototype.remove = function(){
        this.removeHandles();
        this.removeSVG();
    }

    Toilet.prototype.redraw = function(){  // Redraws all svg screen objects (if otherwise visible) after they have been removed
        
        this.createSVG();
    }

    Toilet.prototype.activate = function(multiselect){
        this.tank.css("stroke",this.selectedColor);
        this.base.css("stroke",this.selectedColor);
        this.bowl.css("stroke",this.selectedColor);
        this.isSelected = true;
        if(!multiselect){
            this.drawHandles();
        }
    }

    Toilet.prototype.deactivate = function(){
        this.tank.css("stroke",this.stroke);
        this.base.css("stroke",this.stroke);
        this.bowl.css("stroke",this.stroke);
        this.isSelected = false;
        this.removeHandles();
    }

    Toilet.prototype.getOutlinePoints = function(){ // Returns points for a bounding box for the object
        var pointObject = [];
        for(var i = 0;i < 4;i++){ // Only looks out outer corner points
            pointObject.push(this.points[i].getPoint());
        }
        return pointObject;
    }

// ##########################################  Point Handle Functions  ########################################################

    Toilet.prototype.handlePress = function(handleID){  // Receives a handle press event and saves the mouse location and handle ID for drag process
        for(var i = 0;i < this.points.length;i++){
            this.points[i].setDragReference();
        }
        this.getCenter();
        this.initialDims["widthMargin"] = this.width - this.minimumDimension;
        this.initialDims["lengthMargin"] = this.length - this.minimumDimension;
        this.handleDragging = handleID.slice(4,6)*1;
        if(this.handleDragging == 8){
            this.points[0].setRotateAngle(this.centerPoint.x,this.centerPoint.y,this.angle);
            this.points[1].setRotateAngle(this.centerPoint.x,this.centerPoint.y,this.angle);
            this.points[2].setRotateAngle(this.centerPoint.x,this.centerPoint.y,this.angle);
            this.points[3].setRotateAngle(this.centerPoint.x,this.centerPoint.y,this.angle);
        }
        this.undoPackage = this.createPackage();
    }

    Toilet.prototype.handleDrag = function(){  // Receives a handle drag event and changes the point associated with the handle based on the new location
        rectHandleDrag(
            this.points,
            this.handleDragging,
            this.angle,
            this.minimumDimension,
            this.initialDims,
            this.centerPoint,
            this.width,
            this.length,
            this.map
        );
        this.update();
    }

    Toilet.prototype.finalizeHandleDrag = function(){
        
        this.sendPackages();
    }

    Toilet.prototype.drawHandles = function(){
        for(var i = 0;i < this.points.length;i++){
            this.points[i].drawHandle();
        }
    }

    Toilet.prototype.removeHandles = function(){ // Removes the handles on the wall endpoints
        for(var i = 0;i < this.points.length;i++){
            this.points[i].removeHandle();
        }
    }

    Toilet.prototype.createRotatePoint = function(){
        var distance = 18;
        var topCenterX = (this.points[0].x + this.points[1].x)/2;
        var topCenterY = (this.points[0].y + this.points[1].y)/2;
        this.points[8] = new point(topCenterX + distance * Math.cos(this.angle+Math.PI/2),topCenterY - distance * Math.sin(this.angle+Math.PI/2),"AREP08"+this.id);
    }
    
    Toilet.prototype.updateRotatePoint = function(){
        if(this.points[8] != undefined){
            var distance = 18;
            this.points[8].updatePosition(this.points[4].x + distance * Math.cos(this.angle+Math.PI/2),this.points[4].y - distance * Math.sin(this.angle+Math.PI/2))
        }
    }

// ##########################################  Application Mechanics (Undo/Redo/Duplicate/Save/Load)  #############################################

    Toilet.prototype.duplicate = function(original){
        for(var i = 0;i < original.points.length;i++){
            this.points.push(new point(original.points[i].x,original.points[i].y,original.points[i].id.substring(0,6)+this.id))
        }
        for(var i = 0;i < this.packageParameters.length;i++){
            if(this.packageParameters[i] != "id"){
                this[this.packageParameters[i]] = original[this.packageParameters[i]];
            }
        }
        this.createSVG();
        this.shiftPosition(12,12);
    }

    Toilet.prototype.createPackage = function(){
        var package = {points:[]};
        for(var i = 0;i < this.points.length;i++){
            package.points.push(this.points[i].getPoint());
        }
        for(var i = 0;i < this.packageParameters.length;i++){
            package[this.packageParameters[i]] = this[this.packageParameters[i]];
        }
        package.controller = "architect";
        package.packageType = "modify";
        return package;
    }

    Toilet.prototype.loadPackage = function(package){
        // It doesn't matter if it is an undo or redo package, the impact is to reset the object to a former state
        for(var i = 0;i < this.points.length;i++){
            this.points[i].updatePosition(package.points[i].x,package.points[i].y);
        }
        for(var i = 0;i < this.packageParameters.length;i++){
            this[this.packageParameters[i]] = package[this.packageParameters[i]];
        }
        this.update();
    }

    Toilet.prototype.sendPackages = function(){
        // It is important to know that the undo and redo packages aren't the same.  If they are, there was no real action taken and
        // an undo or redo event will have no apparent effect
        var undo = this.undoPackage;
        var redo = this.createPackage();
        var same = true; // Used to determine whether the two packages are the same (no actual event occured)
        for(var i = 0;i < redo.points.length;i++){ // Runs through the points first as the most common event changes
            if(undo.points[i].x != redo.points[i].x || undo.points[i].y != redo.points[i].y){
                same = false;
                break; // breaks as soon as a single difference is found
            }
        }       
        if(same){ // No need to start second loop if a difference was already found
            for(var i = 0;i < this.packageParameters.length;i++){
                if(undo[this.packageParameters[i]] != redo[this.packageParameters[i]]){
                    same = false;
                    break;
                }
            }
        }
        // Packages are sent essentially simultaneously to prevent having mismatched packages if the action isn't finalized
        if(same == false){
            this.state.addUndoPackage(undo);
            this.state.addRedoPackage(redo);
        }
    }

    Toilet.prototype.save = function(){
        var saveFile = {points:[]}
        for(var i = 0;i < this.points.length;i++){
            saveFile.points.push(this.points[i].getSavePoint());
        }
        for(var i = 0;i < this.packageParameters.length;i++){
            saveFile[this.packageParameters[i]] = this[this.packageParameters[i]];
        }
        return saveFile
    }

    Toilet.prototype.load = function(saveFile){
        // Note that this method assumes that the create function has not been called - will not work if it has been
        for(var i = 0;i < saveFile.points.length;i++){
            this.points.push(new point(saveFile.points[i].x,saveFile.points[i].y,saveFile.points[i].id));
        }
        for(var i = 0;i < this.packageParameters.length;i++){
            this[this.packageParameters[i]] = saveFile[this.packageParameters[i]];
        }
        this.createSVG();    
        this.update();
    }

// ##########################################  Drag and Move Functions  #############################################

    Toilet.prototype.startDrag = function(options){ // Saves the origin of a drag event for move calculations
        console.log('start drag')
        var options = options || {};
        var subclass = options.subclass || null;
        this.snapCandidates = options.snapPoints || [];
        this.undoPackage = this.createPackage();
        for(var i = 0;i < this.points.length;i++){
            this.points[i].setDragReference();
        }
    }

    Toilet.prototype.drag = function(){ // Drags the wall upon a left-button down on the wall layer svg and dragging the mouse
        var map = this.map;
        var coords = map.pointerCoords(); // gets the latest mouse location
        var xMove = coords.x-map.handle.x/map.scale;
        var yMove = coords.y-map.handle.y/map.scale;

        var isSnapCandidates = this.snapCandidates.length;
        var distDragged;
        if(isSnapCandidates && map.snapGridActive){ // This is necessary to snap objects while snap grid is on
            distDragged = this.points[0].dragOffset(xMove,yMove,{gridResolution:map.snapGridResolution,snapToGrid:false});
        } else{
            distDragged = this.points[0].dragOffset(xMove,yMove,{gridResolution:map.snapGridResolution,snapToGrid:map.snapGridActive});  
        }
        this.points[1].dragOffset(distDragged.x,distDragged.y);
        this.points[2].dragOffset(distDragged.x,distDragged.y);
        this.points[3].dragOffset(distDragged.x,distDragged.y);
        this.update(); 
        
        if(isSnapCandidates){
            var objectSnapped = snapObject(this.getSnapPoints(),this.snapCandidates,
                {points:true,edges:true,sensitivity:this.snapSensitivity});
            if(objectSnapped){
                xMove += objectSnapped.xMove;
                yMove += objectSnapped.yMove;
                console.log(xMove,yMove);
                for(var i = 0;i < 4;i++){
                    this.points[i].dragOffset(xMove,yMove);
                }
            } else if(map.snapGridActive){  // This reimplements snapgrid if no snaps matches are found
                distDragged = this.points[0].dragOffset(xMove,yMove,{gridResolution:map.snapGridResolution,snapToGrid:map.snapGridActive});
                this.points[1].dragOffset(distDragged.x,distDragged.y);
                this.points[2].dragOffset(distDragged.x,distDragged.y);
                this.points[3].dragOffset(distDragged.x,distDragged.y);
            }              
        }
        
        this.update();
    }

    Toilet.prototype.finalizeDrag = function(){
        
        this.sendPackages();
    }

    Toilet.prototype.move = function(direction){ // Moves the wall by an x and y distance, called by the architecture controller as a result of a keyboard press
        var map = this.map;
        this.undoPackage = this.createPackage();
        var x = 0;
        var y = 0;
        switch(direction){
            case "up":
            y = -map.snapGridResolution;
            break;
            case "down":
            y = map.snapGridResolution;
            break;
            case "right":
            x = map.snapGridResolution;
            break;
            case "left":
            x = -map.snapGridResolution;
            break;
        }
        this.points[0].shiftPosition(x,y);
        this.points[1].shiftPosition(x,y);
        this.points[2].shiftPosition(x,y);
        this.points[3].shiftPosition(x,y);
        this.update();
        this.sendPackages();
    }

// ##########################################  Object SVG Functions  ##################################################################

    Toilet.prototype.createSVG = function(){
        var tank = document.createElementNS('http://www.w3.org/2000/svg', 'path');
        tank.setAttribute('d',this.getTankPath());
        tank.setAttribute('id',"a"+this.id);
        tank.setAttribute('class',"architect Toilet");
        tank.setAttribute('pointer-events',"all");
        tank.setAttribute('style',"stroke-linecap:square;stroke:"+this.stroke+";fill:"+this.fill+";stroke-width:"+this.lineWidth/4);
        $('#sinks').append(tank);
        this.tank = $("#a" + this.id);

        var base = document.createElementNS('http://www.w3.org/2000/svg', 'path');
        base.setAttribute('d',this.getBasePath());
        base.setAttribute('id',"b"+this.id);
        base.setAttribute('class',"architect sink");
        base.setAttribute('pointer-events',"all");
        base.setAttribute('style',"stroke-linecap:square;stroke:"+this.stroke+";fill:"+this.fill+";stroke-width:"+this.lineWidth/4);
        $('#sinks').append(base);
        this.base = $("#b" + this.id);

        var bowl = document.createElementNS('http://www.w3.org/2000/svg', 'path');
        bowl.setAttribute('id',"c"+this.id);
        bowl.setAttribute('class',"architect sink");
        bowl.setAttribute('d',this.getBowlPath());
        bowl.setAttribute('pointer-events',"all");
        bowl.setAttribute('style',"stroke-linecap:square;stroke:"+this.stroke+";fill:"+this.fill+";stroke-width:"+this.lineWidth/4);
        $('#sinks').append(bowl);
        this.bowl = $("#c" + this.id);

    }

    Toilet.prototype.getTankPath = function(){
        var width = this.width;
        var length = this.length;
        var rounding = .07;
        var tankLength = .28;
        var angle = this.angle;
        var point0 = this.points[0];
        var point1 = this.points[1];
        var point2 = {
            x: point1.x + tankLength * length * Math.cos(angle - Math.PI/2),
            y: point1.y - tankLength * length * Math.sin(angle - Math.PI/2)
        }
        var point3 = {
            x: point0.x + tankLength * length * Math.cos(angle - Math.PI/2),
            y: point0.y - tankLength * length * Math.sin(angle - Math.PI/2)
        }
        var path = ""
        path += "M " + (point0.x + rounding * width * Math.cos(angle)) + " " + (point0.y - rounding * width * Math.sin(angle));
        path += "L " + (point1.x + rounding * width * Math.cos(angle - Math.PI)) + " " + (point1.y - rounding * width * Math.sin(angle - Math.PI));
        path += "S " + point1.x + " " + point1.y;
        path += " " + (point1.x + rounding * width * Math.cos(angle - Math.PI/2)) + " " + (point1.y - rounding * width * Math.sin(angle - Math.PI/2));
        path += "L " + (point2.x + rounding * width * Math.cos(angle + Math.PI/2)) + " " + (point2.y - rounding * width * Math.sin(angle + Math.PI/2));
        path += "S " + point2.x + " " + point2.y;
        path += " " + (point2.x + rounding * width * Math.cos(angle - Math.PI)) + " " + (point2.y - rounding * width * Math.sin(angle - Math.PI));
        path += "L " + (point3.x + rounding * width * Math.cos(angle)) + " " + (point3.y - rounding * width * Math.sin(angle));
        path += "S " + point3.x + " " + point3.y;
        path += " " + (point3.x + rounding * width * Math.cos(angle + Math.PI/2)) + " " + (point3.y - rounding * width * Math.sin(angle + Math.PI/2));
        path += "L " + (point0.x + rounding * width * Math.cos(angle - Math.PI/2)) + " " + (point0.y - rounding * width * Math.sin(angle - Math.PI/2));
        path += "S " + point0.x + " " + point0.y;
        path += " " + (point0.x + rounding * width * Math.cos(angle)) + " " + (point0.y - rounding * width * Math.sin(angle));
        return path;
    }

    Toilet.prototype.getBasePath = function(){
        var width = this.width;
        var length = this.length;
        var tankLength = .28;
        var angle = this.angle;
        var point0 = this.points[0];
        var point3 = {
            x: point0.x + tankLength * length * Math.cos(angle - Math.PI/2),
            y: point0.y - tankLength * length * Math.sin(angle - Math.PI/2)
        }

        var newPoint0 = {
            x: point3.x + .3 * width * Math.cos(angle),
            y: point3.y - .3 * width * Math.sin(angle),
        }
        var newPoint1 = {
            x: point3.x + .7 * width * Math.cos(angle),
            y: point3.y - .7 * width * Math.sin(angle),
        }
        var newPoint2 = {
            x: newPoint1.x + .2 * length * Math.cos(angle-Math.PI/2),
            y: newPoint1.y - .2 * length * Math.sin(angle-Math.PI/2),
        }
        var newPoint3 = {
            x: newPoint0.x + .2 * length * Math.cos(angle-Math.PI/2),
            y: newPoint0.y - .2 * length * Math.sin(angle-Math.PI/2),
        }
       
        var path = ""
        path += "M " + newPoint0.x + " " + newPoint0.y;
        path += " L " + newPoint1.x + " " + newPoint1.y;
        path += " L " + newPoint2.x + " " + newPoint2.y;
        path += " L " + newPoint3.x + " " + newPoint3.y;
        path += " Z";  // Return and close of position
        return path;
    }

    Toilet.prototype.getBowlPath = function(){
        var width = this.width;
        var length = this.length;
        var rounding = .07;
        var tankLength = .28;
        var angle = this.angle;
        var point0 = this.points[0];
        var point1 = this.points[1];
        var point4 = this.points[4]; // top edge
        var point6 = this.points[6]; // bottom edge
        var point2 = {
            x: point1.x + tankLength * length * Math.cos(angle - Math.PI/2),
            y: point1.y - tankLength * length * Math.sin(angle - Math.PI/2)
        }
        var point3 = {
            x: point0.x + tankLength * length * Math.cos(angle - Math.PI/2),
            y: point0.y - tankLength * length * Math.sin(angle - Math.PI/2)
        }
        var topPoint = {
            x: point4.x + .30 * length * Math.cos(angle - Math.PI/2),
            y: point4.y - .30 * length * Math.sin(angle - Math.PI/2)
        }

        var bottomLeftCorner0 = {
            x: point0.x + .8 * length * Math.cos(angle - Math.PI/2),
            y: point0.y - .8 * length * Math.sin(angle - Math.PI/2)
        }

        var bottomLeftCorner1 = {
            x: bottomLeftCorner0.x + .07 * width * Math.cos(angle),
            y: bottomLeftCorner0.y - .07 * width * Math.sin(angle)
        }

        var bottomLeftEdge0 = {
            x: point0.x + .92 * length * Math.cos(angle - Math.PI/2),
            y: point0.y - .92 * length * Math.sin(angle - Math.PI/2)
        }

        var bottomLeftEdge1 = {
            x: bottomLeftEdge0.x + .30 * width * Math.cos(angle),
            y: bottomLeftEdge0.y - .30 * width * Math.sin(angle)
        }

        var bottomRightEdge1 = {
            x: bottomLeftEdge0.x + .70 * width * Math.cos(angle),
            y: bottomLeftEdge0.y - .70 * width * Math.sin(angle)
        }

        var bottomRightCorner0 = {
            x: point1.x + .8 * length * Math.cos(angle - Math.PI/2),
            y: point1.y - .8 * length * Math.sin(angle - Math.PI/2)
        }

        var bottomRightCorner1 = {
            x: bottomRightCorner0.x + .07 * width * Math.cos(angle-Math.PI),
            y: bottomRightCorner0.y - .07 * width * Math.sin(angle-Math.PI)
        }

        var topLeftCorner0 = {
            x: point0.x + .28 * length * Math.cos(angle - Math.PI/2),
            y: point0.y - .28 * length * Math.sin(angle - Math.PI/2)
        }

        var topLeftCorner1 = {
            x: topLeftCorner0.x + .06 * width * Math.cos(angle),
            y: topLeftCorner0.y - .06 * width * Math.sin(angle)
        }

        var topRightCorner0 = {
            x: point1.x + .28 * length * Math.cos(angle - Math.PI/2),
            y: point1.y - .28 * length * Math.sin(angle - Math.PI/2)
        }

        var topRightCorner1 = {
            x: topRightCorner0.x + .06 * width * Math.cos(angle - Math.PI),
            y: topRightCorner0.y - .06 * width * Math.sin(angle - Math.PI)
        }

        var path = ""
        //path += "M " + point6.x + " " + point6.y;
        path += " M " + bottomLeftEdge1.x + " " + bottomLeftEdge1.y;
        path += " C " + bottomLeftCorner1.x + " " + bottomLeftCorner1.y;
        path += " " + topLeftCorner1.x + " " + topLeftCorner1.y;
        path += " " + topPoint.x + " " + topPoint.y;
        path += " C " + topRightCorner1.x + " " + topRightCorner1.y;
        path += " " + bottomRightCorner1.x + " " + bottomRightCorner1.y;
        path += " " + bottomRightEdge1.x + " " + bottomRightEdge1.y;
        path += " Q " + point6.x + " " + point6.y;
        path += " " + bottomLeftEdge1.x + " " + bottomLeftEdge1.y;  // Return and close of position
        return path;
    }

    Toilet.prototype.draw = function(){ 
        var map = this.map;
        var pos = map.pointerCoords(); 
        this.points[1].updatePosition(map.snapRound(pos.x),this.points[1].y);
        this.points[2].updatePosition(map.snapRound(pos.x),map.snapRound(pos.y));
        this.points[3].updatePosition(this.points[3].x,map.snapRound(pos.y));
        this.update();
    }

    Toilet.prototype.finalizeDraw = function(){  // To make the initial point numbers and corners consistent in all draw scenarios the
        // following checks to ensure that point zero is at the upper left and the points are numbered clockwise from there
        // If this isn't the case, this function flips the points on the necessary axis to make it the case
        if(this.points[0].y > this.points[3].y){
            var temp0 = this.points[0].getPoint();
            var temp1 = this.points[1].getPoint();
            var temp2 = this.points[2].getPoint();
            var temp3 = this.points[3].getPoint();
            this.points[0].updatePosition(temp3.x,temp3.y);
            this.points[1].updatePosition(temp2.x,temp2.y);
            this.points[2].updatePosition(temp1.x,temp1.y);
            this.points[3].updatePosition(temp0.x,temp0.y);
        }
        if(this.points[0].x > this.points[1].x){
            var temp0 = this.points[0].getPoint();
            var temp1 = this.points[1].getPoint();
            var temp2 = this.points[2].getPoint();
            var temp3 = this.points[3].getPoint();
            this.points[0].updatePosition(temp1.x,temp1.y);
            this.points[1].updatePosition(temp0.x,temp0.y);
            this.points[2].updatePosition(temp3.x,temp3.y);
            this.points[3].updatePosition(temp2.x,temp2.y);
        }
        this.calculateAngle();
        this.createRotatePoint();
        this.update();
    }

    Toilet.prototype.cancelDraw = function(){
        
        this.remove();
    }

    Toilet.prototype.dragPlace = function(){
        var pos = this.map.pointerCoords(); // gets the latest mouse location
        pos.x = this.map.snapRound(pos.x,undefined,true);
        pos.y = this.map.snapRound(pos.y,undefined,true);
        this.points[0].updatePosition(pos.x,pos.y);
        this.points[1].updatePosition(pos.x+this.defaultSize.width,pos.y);
        this.points[2].updatePosition(pos.x+this.defaultSize.width,pos.y+this.defaultSize.height);
        this.points[3].updatePosition(pos.x,pos.y+this.defaultSize.height);
        this.updateSVG();
    }

    Toilet.prototype.finalizeDragPlace = function(){
        this.createRotatePoint();
        this.update();
    }

    Toilet.prototype.updateSVG = function(){
        this.updateSidePoints();
        this.tank.attr("d",this.getTankPath());
        this.base.attr("d",this.getBasePath());
        this.bowl.attr("d",this.getBowlPath());
    }

    Toilet.prototype.removeSVG = function(){
        this.tank ? this.tank.remove() : null;
        this.base ? this.base.remove() : null;
        this.bowl ? this.bowl.remove() : null;
    }

    Toilet.prototype.updateSidePoints = function(){
        this.points[4].updatePosition((this.points[0].x+this.points[1].x)/2,(this.points[0].y+this.points[1].y)/2); // Top Edge
        this.points[5].updatePosition((this.points[1].x+this.points[2].x)/2,(this.points[1].y+this.points[2].y)/2); // Right Edge
        this.points[6].updatePosition((this.points[2].x+this.points[3].x)/2,(this.points[2].y+this.points[3].y)/2); // Bottom Edge
        this.points[7].updatePosition((this.points[3].x+this.points[0].x)/2,(this.points[3].y+this.points[0].y)/2); // Left Edge
    }

// ##########################################  Object Calculation Functions  ############################################################

    Toilet.prototype.calculateLength = function(){  // Side Edge
        var xComponent = this.points[0].x - this.points[3].x;
        var yComponent = this.points[0].y - this.points[3].y;
        this.length = Math.sqrt(Math.pow(xComponent,2)+Math.pow(yComponent,2));
        return this.length;
    }

    Toilet.prototype.calculateWidth = function(){  // Top Edge
        var xComponent = this.points[0].x - this.points[1].x;
        var yComponent = this.points[0].y - this.points[1].y;
        this.width = Math.sqrt(Math.pow(xComponent,2)+Math.pow(yComponent,2));
        return this.width;
    }

    Toilet.prototype.calculateAngle = function(){  
        
        this.angle = Math.atan2((this.points[0].y-this.points[1].y),(this.points[1].x-this.points[0].x));
    }

    Toilet.prototype.getCenter = function(){
        this.centerPoint = {
            x:(this.points[0].x + this.points[2].x)/2 ,
            y:(this.points[0].y + this.points[2].y)/2
        }
        return this.centerPoint;
    }

// ##########################################  Selector Interface Functions  ############################################################

    Toilet.prototype.setProperty = function(property,value){
        switch(property){
            case "objectLength":
                this.setobjectLength(value);
            break;
            case "objectWidth":
                this.setobjectWidth(value);
            break;
            case "objectAngle":
                this.setobjectAngle(toRads(value));
            break;
            case "objectStrokeColor":
                this.setobjectStrokeColor(value);
            break;
            case "objectFillColor":
                this.setobjectFillColor(value);
            break;
            case "objectLabelStyle":
                this.setLabelStyle(value);
            break;
        }
    }

    Toilet.prototype.getObjectData = function(subcategory,id){  // This function is called when the user selects a wall object
        var thisData = {};
        thisData.data = {
            objectType: {type:"label",value:"Toilet"},
            objectLength: {type:"spinner",value:this.renderLength(this.length)},
            objectWidth: {type:"spinner",value:this.renderLength(this.width)},
            objectAngle: {type:"spinner",value:toDeg(this.angle)},
            objectStrokeColor: {type:"color",value:this.stroke},
            objectFillColor: {type:"color",value:this.fill}
        }
        thisData.dividers = {
            sizeDivider:true,
            positionDivider:true,
            colorDivider:true
        }
        return thisData;
    }

    Toilet.prototype.setobjectLength = function(value){
        var newX3 = value * Math.cos(this.angle - Math.PI/2) + this.points[0].x;
        var newY3 = -value * Math.sin(this.angle - Math.PI/2) + this.points[0].y;
        var newX2 = value * Math.cos(this.angle - Math.PI/2) + this.points[1].x;
        var newY2 = -value * Math.sin(this.angle - Math.PI/2) + this.points[1].y;
        this.points[2].updatePosition(newX2,newY2);
        this.points[3].updatePosition(newX3,newY3);
        this.update();
    }

    Toilet.prototype.setobjectWidth = function(value){
        var newX1 = value * Math.cos(this.angle) + this.points[0].x;
        var newY1 = -value * Math.sin(this.angle) + this.points[0].y;
        var newX2 = value * Math.cos(this.angle) + this.points[3].x;
        var newY2 = -value * Math.sin(this.angle) + this.points[3].y;
        this.points[1].updatePosition(newX1,newY1);
        this.points[2].updatePosition(newX2,newY2);
        this.update();
        return this.width;
    }

    Toilet.prototype.setobjectAngle = function(angle){
        this.getCenter();
        this.points[0].setRotateAngle(this.centerPoint.x,this.centerPoint.y,this.angle);
        this.points[1].setRotateAngle(this.centerPoint.x,this.centerPoint.y,this.angle);
        this.points[2].setRotateAngle(this.centerPoint.x,this.centerPoint.y,this.angle);
        this.points[3].setRotateAngle(this.centerPoint.x,this.centerPoint.y,this.angle);
        this.points[0].rotateAroundCenter(this.centerPoint.x,this.centerPoint.y,angle);
        this.points[1].rotateAroundCenter(this.centerPoint.x,this.centerPoint.y,angle);
        this.points[2].rotateAroundCenter(this.centerPoint.x,this.centerPoint.y,angle);
        this.points[3].rotateAroundCenter(this.centerPoint.x,this.centerPoint.y,angle);
        this.update();
    }

    Toilet.prototype.setobjectStrokeColor = function(color){
        var isOk  = /(^#[0-9A-F]{6}$)|(^#[0-9A-F]{3}$)/i.test(color)
        if(isOk){
            this.stroke = color;
        } else {
            console.log("color not recognized")
        }
        this.tank.css("stroke",this.stroke);
        this.base.css("stroke",this.stroke);
        this.bowl.css("stroke",this.stroke);
    }

    Toilet.prototype.setobjectFillColor = function(color){
        var isOk  = /(^#[0-9A-F]{6}$)|(^#[0-9A-F]{3}$)/i.test(color)
        if(isOk){
            this.fill = color;
        } else {
            console.log("color not recognized")
        }
        this.tank.css("stroke",this.fill);
        this.base.css("stroke",this.fill);
        this.bowl.css("stroke",this.fill);
    }