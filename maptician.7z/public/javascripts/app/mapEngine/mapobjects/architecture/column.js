function Column(id,state,map){
    MapObject.call(this,"Column",id); // Sets Column as subclass of MapObject
    this.state = state; // Reference to the State Controller
    this.map = map; // Reference to the Map Controller

    this.type = "Column"; // Can be removed - lives on superclass - just here for reminder
    this.id = id; // Can be removed - lives on superclass - just here for reminder
    this.handleDragging = ""; // Can be removed - lives on superclass - just here for reminder
    this.isSelected = false;   // Can be removed - lives on superclass - just here for reminder

    this.fill = "#D3D3D3";  // Fill Color
    this.stroke = "#000000";  // Stroke Color
    this.lineWidth = 1;  // Width of the line stroke
    this.labelStyle = 2; // Determines how the labels are displayed.  Defaults to always showing the labels
    this.labelColor = "#000000";
    this.selectedColor = "#ff0000";
    this.labelSize = 15;
    this.minimumDimension = 6; // Used to set a minimum length or width of the column TODO ##### Need to create a minimum dimension control

    this.points = []; // Array containing the points making up the column
        // Initial positions
        // 0 - Upper left point
        // 1 - Upper right point
        // 2 - Lower right point
        // 3 - Lower left point
        // 4 - Top Edge Point
        // 5 - Right Edge Point
        // 6 - Bottom Edge Point
        // 7 - Left Edge Point
        // 8 - Rotation handle point

    // Aliases to the jQuery selection of the respective svg objects
    this.outer = null;
    this.inner = null;

    this.lengthLabel = {};  // Path label object for length label
    this.widthLabel = {};  // Path label object for width label
    this.length = 1;  // Length of the column (initially side dimension)
    this.width = 0; // Width of the column (initially top dimension)    
    this.initialDims = {};  // Holds the initial dimensions of the column during a resize event
    this.angle = 0;  // Angle in radians of the column with respect to the x-axis
    this.centerPoint = {}; // Calculated and used for rotation
    this.dragAngle = 0; // Used for rotation, gives the starting angle of a rotation event
    this.packageParameters = [ // Used in undo/redo/duplicate/save/load methods
        "type",
        "id",
        "fill",
        "stroke",
        "lineWidth",
        "labelStyle",
        "minimumDimension",
    ];    
    
}
    Column.prototype = Object.create(MapObject.prototype); // Links the prototype to the superclass
    Column.prototype.constructor = Column;

// ##########################################  Standard Object Interface Functions  ##################################################################

    Column.prototype.create = function(){ // This creates all components of the column object
        var map = this.map;
        var pos = map.pointerCoords();
        this.points[0] = new point(map.snapRound(pos.x),map.snapRound(pos.y),"ARCP00"+this.id); // Upper Left
        this.points[1] = new point(map.snapRound(pos.x),map.snapRound(pos.y),"ARCP01"+this.id); // Upper Right
        this.points[2] = new point(map.snapRound(pos.x),map.snapRound(pos.y),"ARCP02"+this.id); // Lower Right
        this.points[3] = new point(map.snapRound(pos.x),map.snapRound(pos.y),"ARCP03"+this.id); // Lower Left
        this.points[4] = new point((this.points[0].x+this.points[1].x)/2,(this.points[0].y+this.points[1].y)/2,"ARCP04"+this.id); // Top Edge
        this.points[5] = new point((this.points[1].x+this.points[2].x)/2,(this.points[1].y+this.points[2].y)/2,"ARCP05"+this.id); // Right Edge
        this.points[6] = new point((this.points[2].x+this.points[3].x)/2,(this.points[2].y+this.points[3].y)/2,"ARCP06"+this.id); // Bottom Edge
        this.points[7] = new point((this.points[3].x+this.points[0].x)/2,(this.points[3].y+this.points[0].y)/2,"ARCP07"+this.id); // Left Edge
        this.createSVG();
        this.addLabels();
    }

    Column.prototype.update = function(){
        this.calculateAngle();
        this.calculateLength();
        this.calculateWidth();
        this.updateSVG();
        this.updateSidePoints();
        this.updateRotatePoint();
        this.updateLabels();
    }

    Column.prototype.remove = function(){
        this.removeHandles();
        this.removeSVG();
        this.removeLabels();
    }

    Column.prototype.redraw = function(){  // Redraws all svg screen objects (if otherwise visible) after they have been removed
        this.createSVG();
        this.setLabelStyle(this.labelStyle);
    }

    Column.prototype.activate = function(multiselect){
        this.outer.css("fill",this.selectedColor);
        this.isSelected = true;
        if(!multiselect){
            this.drawHandles();
        }
        this.setLabelStyle(this.labelStyle);
    }

    Column.prototype.deactivate = function(){
        this.outer.css("fill",this.stroke);
        this.isSelected = false;
        this.removeHandles();
        this.setLabelStyle(this.labelStyle);
    }

    Column.prototype.getOutlinePoints = function(){
        var pointObject = [];
        for(var i = 0;i < 4;i++){
            pointObject.push(this.points[i].getPoint());
        }
        return pointObject;
    }

// ##########################################  Point Handle Functions  ##################################################################

    Column.prototype.handlePress = function(handleID){  // Receives a handle press event and saves the mouse location and handle ID for drag process
        for(var i = 0;i < this.points.length;i++){
            this.points[i].setDragReference();
        }
        this.getCenter();
        this.initialDims["widthMargin"] = this.width - this.minimumDimension;
        this.initialDims["lengthMargin"] = this.length - this.minimumDimension;
        this.handleDragging = handleID.slice(4,6)*1;
        if(this.handleDragging == 8){
            this.points[0].setRotateAngle(this.centerPoint.x,this.centerPoint.y,this.angle);
            this.points[1].setRotateAngle(this.centerPoint.x,this.centerPoint.y,this.angle);
            this.points[2].setRotateAngle(this.centerPoint.x,this.centerPoint.y,this.angle);
            this.points[3].setRotateAngle(this.centerPoint.x,this.centerPoint.y,this.angle);
        }
        this.undoPackage = this.createPackage();
    }

    Column.prototype.handleDrag = function(){  // Receives a handle drag event and changes the point associated with the handle based on the new location
        rectHandleDrag(
            this.points,
            this.handleDragging,
            this.angle,
            this.minimumDimension,
            this.initialDims,
            this.centerPoint,
            this.width,
            this.length,
            this.map
        );
        this.update();
    }

    Column.prototype.finalizeHandleDrag = function(){
        
        this.sendPackages();
    }

    Column.prototype.drawHandles = function(){
        for(var i = 0;i < this.points.length;i++){
            this.points[i].drawHandle();
        }
    }

    Column.prototype.removeHandles = function(){ // Removes the handles on the wall endpoints
        for(var i = 0;i < this.points.length;i++){
            this.points[i].removeHandle();
        }
    }

    Column.prototype.createRotatePoint = function(){
        var distance = 18;
        var topCenterX = (this.points[0].x + this.points[1].x)/2;
        var topCenterY = (this.points[0].y + this.points[1].y)/2;
        this.points[8] = new point(topCenterX + distance * Math.cos(this.angle+Math.PI/2),topCenterY - distance * Math.sin(this.angle+Math.PI/2),"AREP08"+this.id);
    }

    Column.prototype.updateRotatePoint = function(){
        if(this.points[8] != undefined){
            var distance = 18;
            this.points[8].updatePosition(this.points[4].x + distance * Math.cos(this.angle+Math.PI/2),this.points[4].y - distance * Math.sin(this.angle+Math.PI/2))
        }
    }

// ##########################################  Application Mechanics (Undo/Redo/Duplicate/Save/Load)  #############################################

    Column.prototype.duplicate = function(original){
        for(var i = 0;i < original.points.length;i++){
            this.points.push(new point(original.points[i].x,original.points[i].y,original.points[i].id.substring(0,6)+this.id))
        }
        for(var i = 0;i < this.packageParameters.length;i++){
            this[this.packageParameters[i]] = original[this.packageParameters[i]];
        }
        this.createSVG();
        this.addLabels();
        this.move(12,12);
    }

    Column.prototype.createPackage = function(){
        var package = {points:[]};
        for(var i = 0;i < this.points.length;i++){
            package.points.push(this.points[i].getPoint());
        }
        for(var i = 0;i < this.packageParameters.length;i++){
            package[this.packageParameters[i]] = this[this.packageParameters[i]];
        }
        package.controller = "architect";
        package.packageType = "modify";
        return package;
    }

    Column.prototype.loadPackage = function(package){
        // It doesn't matter if it is an undo or redo package, the impact is to reset the object to a former state
        for(var i = 0;i < this.points.length;i++){
            this.points[i].updatePosition(package.points[i].x,package.points[i].y);
        }
        for(var i = 0;i < this.packageParameters.length;i++){
            this[this.packageParameters[i]] = package[this.packageParameters[i]];
        }
        this.update();
    }

    Column.prototype.sendPackages = function(){
        // It is important to know that the undo and redo packages aren't the same.  If they are, there was no real action taken and
        // an undo or redo event will have no apparent effect
        var undo = this.undoPackage;
        var redo = this.createPackage();
        var same = true; // Used to determine whether the two packages are the same (no actual event occured)
        for(var i = 0;i < redo.points.length;i++){ // Runs through the points first as the most common event changes
            if(undo.points[i].x != redo.points[i].x || undo.points[i].y != redo.points[i].y){
                same = false;
                break; // breaks as soon as a single difference is found
            }
        }       
        if(same){ // No need to start second loop if a difference was already found
            for(var i = 0;i < this.packageParameters.length;i++){
                if(undo[this.packageParameters[i]] != redo[this.packageParameters[i]]){
                    same = false;
                    break;
                }
            }
        }
        // Packages are sent essentially simultaneously to prevent having mismatched packages if the action isn't finalized
        if(same == false){
            this.state.addUndoPackage(undo);
            this.state.addRedoPackage(redo);
        }
    }

    Column.prototype.save = function(){
        var saveFile = {points:[]}
        for(var i = 0;i < this.points.length;i++){
            saveFile.points.push(this.points[i].getSavePoint());
        }
        for(var i = 0;i < this.packageParameters.length;i++){
            saveFile[this.packageParameters[i]] = this[this.packageParameters[i]];
        }
        return saveFile
    }

    Column.prototype.load = function(saveFile){
        // Note that this method assumes that the create function has not been called - will not work if it has been
        for(var i = 0;i < saveFile.points.length;i++){
            this.points.push(new point(saveFile.points[i].x,saveFile.points[i].y,saveFile.points[i].id));
        }
        for(var i = 0;i < this.packageParameters.length;i++){
            this[this.packageParameters[i]] = saveFile[this.packageParameters[i]];
        }
        this.createSVG(); 
        this.addLabels();
        this.update();
    }

// ##########################################  Drag and Move Functions  #############################################

    Column.prototype.startDrag = function(optionsObj){ // Saves the origin of a drag event for move calculations
        var options = optionsObj || {};
        var subclass = options.subclass || null;
        this.snapCandidates = options.snapPoints || [];
        this.undoPackage = this.createPackage();
        for(var i = 0;i < this.points.length;i++){
            this.points[i].setDragReference();
        }
    }

    Column.prototype.drag = function(){ // Drags the wall upon a left-button down on the wall layer svg and dragging the mouse
        var map = this.map;
        var coords = map.pointerCoords(); // gets the latest mouse location
        var xMove = coords.x-map.handle.x/map.scale;
        var yMove = coords.y-map.handle.y/map.scale;

        var isSnapCandidates = this.snapCandidates.length;
        var distDragged;
        if(isSnapCandidates && map.snapGridActive){ // This is necessary to snap objects while snap grid is on
            distDragged = this.points[0].dragOffset(xMove,yMove,{gridResolution:map.snapGridResolution,snapToGrid:false});
        } else{
            distDragged = this.points[0].dragOffset(xMove,yMove,{gridResolution:map.snapGridResolution,snapToGrid:map.snapGridActive});  
        }
        this.points[1].dragOffset(distDragged.x,distDragged.y);
        this.points[2].dragOffset(distDragged.x,distDragged.y);
        this.points[3].dragOffset(distDragged.x,distDragged.y);
        this.update(); 
        
        if(isSnapCandidates){
            var objectSnapped = snapObject(this.getSnapPoints(),this.snapCandidates,
                {points:true,edges:true,sensitivity:this.snapSensitivity});
            if(objectSnapped){
                xMove += objectSnapped.xMove;
                yMove += objectSnapped.yMove;
                console.log(xMove,yMove);
                for(var i = 0;i < 4;i++){
                    this.points[i].dragOffset(xMove,yMove);
                }
            } else if(map.snapGridActive){  // This reimplements snapgrid if no snaps matches are found
                distDragged = this.points[0].dragOffset(xMove,yMove,{gridResolution:map.snapGridResolution,snapToGrid:map.snapGridActive});
                this.points[1].dragOffset(distDragged.x,distDragged.y);
                this.points[2].dragOffset(distDragged.x,distDragged.y);
                this.points[3].dragOffset(distDragged.x,distDragged.y);
            }              
        }
        
        this.update();
    }

    Column.prototype.finalizeDrag = function(){
        
        this.sendPackages();
    }

    Column.prototype.move = function(direction){ // Moves the wall by an x and y distance, called by the architecture controller as a result of a keyboard press
        var map = this.map;
        this.undoPackage = this.createPackage();
        var x = 0;
        var y = 0;
        switch(direction){
            case "up":
            y = -map.snapGridResolution;
            break;
            case "down":
            y = map.snapGridResolution;
            break;
            case "right":
            x = map.snapGridResolution;
            break;
            case "left":
            x = -map.snapGridResolution;
            break;
        }
        this.points[0].shiftPosition(x,y);
        this.points[1].shiftPosition(x,y);
        this.points[2].shiftPosition(x,y);
        this.points[3].shiftPosition(x,y);
        this.update();
        this.sendPackages();
    }

// ##########################################  Object SVG Functions  ##################################################################

    Column.prototype.createSVG = function(){
        var outerColumn = document.createElementNS('http://www.w3.org/2000/svg', 'path');
        outerColumn.setAttribute('d',this.getColumnPath());
        outerColumn.setAttribute('id',"o"+this.id);
        outerColumn.setAttribute('class',"architect column");
        outerColumn.setAttribute('pointer-events',"all");
        outerColumn.setAttribute('style',"stroke-linecap:square;stroke:"+"none"+";fill:"+this.stroke+";stroke-width:0");
        $('#outerWall').append(outerColumn);
        this.outer = $("#o"+this.id);

        var innerColumn = document.createElementNS('http://www.w3.org/2000/svg', 'path');
        innerColumn.setAttribute('d',this.getInnerColumnPath());
        innerColumn.setAttribute('id',"i"+this.id);
        innerColumn.setAttribute('class',"architect column");
        innerColumn.setAttribute('pointer-events',"all");
        innerColumn.setAttribute('style',"stroke-linecap:square;stroke:"+"none"+";fill:"+this.fill+";stroke-width:0");
        $('#innerWall').append(innerColumn);
        this.inner = $("#i"+this.id);
    }

    Column.prototype.getColumnPath = function(){
        var path = ""
        path += "M " + this.points[0].x + " " + this.points[0].y; // Start point at upper left of the column
        path += "L " + this.points[1].x + " " + this.points[1].y;  // Point at the upper right
        path += "L " + this.points[2].x + " " + this.points[2].y;  // Point at the lower right
        path += "L " + this.points[3].x + " " + this.points[3].y;  // Point at the lower left
        path += "L " + this.points[0].x + " " + this.points[0].y;  // Return and close of position
        return path;
    }

    Column.prototype.getInnerColumnPath = function(){
        var dist = this.lineWidth;
        var upperLeftX = dist * Math.cos(this.angle - Math.PI/4) + this.points[0].x;
        var upperLeftY = -dist * Math.sin(this.angle - Math.PI/4) + this.points[0].y;
        var upperRightX = dist * Math.cos(this.angle - 3 * Math.PI/4) + this.points[1].x;
        var upperRightY = -dist * Math.sin(this.angle - 3 * Math.PI/4) + this.points[1].y;
        var lowerRightX = dist * Math.cos(this.angle + 3 * Math.PI/4) + this.points[2].x;
        var lowerRightY = -dist * Math.sin(this.angle + 3 * Math.PI/4) + this.points[2].y;
        var lowerLeftX = dist * Math.cos(this.angle + Math.PI/4) + this.points[3].x;
        var lowerLeftY = -dist * Math.sin(this.angle + Math.PI/4) + this.points[3].y;
        var path = ""
        path += "M " + upperLeftX + " " + upperLeftY; // Start point at upper left of the column
        path += "L " + upperRightX + " " + upperRightY;  // Point at the upper right
        path += "L " + lowerRightX + " " + lowerRightY;  // Point at the lower right
        path += "L " + lowerLeftX + " " + lowerLeftY;  // Point at the lower left
        path += "L " + upperLeftX + " " + upperLeftY;  // Return and close of position
        return path;
    }

    Column.prototype.draw = function(){ 
        var map = this.map;
        var pos = map.pointerCoords(); 
        this.points[1].updatePosition(map.snapRound(pos.x),this.points[1].y);
        this.points[2].updatePosition(map.snapRound(pos.x),map.snapRound(pos.y));
        this.points[3].updatePosition(this.points[3].x,map.snapRound(pos.y));
        this.update();
    }

    Column.prototype.finalizeDraw = function(){  // To make the initial point numbers and corners consistent in all draw scenarios the
        // following checks to ensure that point zero is at the upper left and the points are numbered clockwise from there
        // If this isn't the case, this function flips the points on the necessary axis to make it the case
        if(this.points[0].y > this.points[3].y){
            var temp0 = this.points[0].getPoint();
            var temp1 = this.points[1].getPoint();
            var temp2 = this.points[2].getPoint();
            var temp3 = this.points[3].getPoint();
            this.points[0].updatePosition(temp3.x,temp3.y);
            this.points[1].updatePosition(temp2.x,temp2.y);
            this.points[2].updatePosition(temp1.x,temp1.y);
            this.points[3].updatePosition(temp0.x,temp0.y);
        }
        if(this.points[0].x > this.points[1].x){
            var temp0 = this.points[0].getPoint();
            var temp1 = this.points[1].getPoint();
            var temp2 = this.points[2].getPoint();
            var temp3 = this.points[3].getPoint();
            this.points[0].updatePosition(temp1.x,temp1.y);
            this.points[1].updatePosition(temp0.x,temp0.y);
            this.points[2].updatePosition(temp3.x,temp3.y);
            this.points[3].updatePosition(temp2.x,temp2.y);
        }
        this.calculateAngle();
        this.createRotatePoint();
        this.update();
        this.setLabelStyle(this.labelStyle);
    }

    Column.prototype.cancelDraw = function(){
        
        this.remove();
    }

    Column.prototype.checkValid = function(){ // Returns true if this was a validly drawn object
        this.calculateLength();
        this.calculateAngle();
        return this.length > 0 && this.width > 0;
    }

    Column.prototype.updateSVG = function(){
        this.outer.attr("d",this.getColumnPath());
        this.inner.attr("d",this.getInnerColumnPath());
    }

    Column.prototype.removeSVG = function(){
        this.outer ? this.outer.remove() : null;
        this.inner ? this.inner.remove() : null;
    }

    Column.prototype.updateSidePoints = function(){
        this.points[4].updatePosition((this.points[0].x+this.points[1].x)/2,(this.points[0].y+this.points[1].y)/2); // Top Edge
        this.points[5].updatePosition((this.points[1].x+this.points[2].x)/2,(this.points[1].y+this.points[2].y)/2); // Right Edge
        this.points[6].updatePosition((this.points[2].x+this.points[3].x)/2,(this.points[2].y+this.points[3].y)/2); // Bottom Edge
        this.points[7].updatePosition((this.points[3].x+this.points[0].x)/2,(this.points[3].y+this.points[0].y)/2); // Left Edge
    }

// ##########################################  Object Calculation Functions  ############################################################

    Column.prototype.calculateLength = function(){  // Side Edge
        var xComponent = this.points[0].x - this.points[3].x;
        var yComponent = this.points[0].y - this.points[3].y;
        this.length = Math.sqrt(Math.pow(xComponent,2)+Math.pow(yComponent,2));
        return this.length;
    }

    Column.prototype.calculateWidth = function(){  // Top Edge
        var xComponent = this.points[0].x - this.points[1].x;
        var yComponent = this.points[0].y - this.points[1].y;
        this.width = Math.sqrt(Math.pow(xComponent,2)+Math.pow(yComponent,2));
        return this.width;
    }

    Column.prototype.calculateAngle = function(){  
        
        this.angle = Math.atan2((this.points[0].y-this.points[1].y),(this.points[1].x-this.points[0].x));
    }

    Column.prototype.getCenter = function(){
        this.centerPoint = {
            x:(this.points[0].x + this.points[2].x)/2 ,
            y:(this.points[0].y + this.points[2].y)/2
        }
        return this.centerPoint;
    }

// ##########################################   Label Functions  ##################################################################

    Column.prototype.setLabelStyle = function(styleNumber){ // Changes the display behavior of the distance labels based on a style number from a slider
        if(styleNumber != undefined){
            this.labelStyle = styleNumber;
        }
        switch(this.labelStyle){
            case 0: // Never show labels
                this.removeLabels();
            break;
            case 1: // Only show labels when selected
                if(this.isSelected == true){
                    this.redrawLabels();
                } else {
                   this.removeLabels(); 
                }
            break;
            case 2: // Always show labels (default)
                this.redrawLabels();
            break;
        }
        return this.labelStyle;
    }

    Column.prototype.addLabels = function(){ // Creates a length label object and adds it to the wall 
        if(!(this.lengthLabel instanceof pathTextLabel)){ // Check to ensure that a label doesn't already exist
            var id = generateUUID();
            this.lengthLabel = new pathTextLabel("LL"+id,this.points[3],this.points[0],this.labelColor,this.labelSize,"50%",-5,"labelGroup");
            this.lengthLabel.draw();
            this.widthLabel = new pathTextLabel("WL"+id,this.points[0],this.points[1],this.labelColor,this.labelSize,"50%",-5,"labelGroup");
            this.widthLabel.draw();
            this.updateLabels();
        }
    }

    Column.prototype.removeLabels = function(){  // Removes the length label from the wall
        this.lengthLabel.remove();
        this.widthLabel.remove();
    }

    Column.prototype.redrawLabels = function(){
        this.lengthLabel.redraw();
        this.widthLabel.redraw(); 
    }

    Column.prototype.updateLabels = function(){
        this.lengthLabel.updateDist();
        this.widthLabel.updateDist();
    }

// ##########################################  Selector Interface Functions  ######################################################################

    Column.prototype.setProperty = function(property,value){
        switch(property){
            case "objectLength":
                this.setobjectLength(value);
            break;
            case "objectWidth":
                this.setobjectWidth(value);
            break;
            case "objectAngle":
                this.setobjectAngle(toRads(value));
            break;
            case "objectStrokeColor":
                this.setobjectStrokeColor(value);
            break;
            case "objectFillColor":
                this.setobjectFillColor(value);
            break;
            case "objectLabelStyle":
                this.setLabelStyle(value);
            break;
            case "objectLabelColor":
                this.labelColor = value;
                this.lengthLabel.setColor(value);
                this.widthLabel.setColor(value);
            break;
            case "objectLabelSize":
                this.labelSize = value;
                this.lengthLabel.setFontSize(value);
                this.widthLabel.setFontSize(value);
            break;
        }
    }

    Column.prototype.getObjectData = function(subcategory,id){  // This function is called when the user selects a wall object
        var thisData = {};
        thisData.data = {
            objectType: {type:"label",value:"Column"},
            objectLength: {type:"spinner",value:this.renderLength(this.length)},
            objectWidth: {type:"spinner",value:this.renderLength(this.width)},
            objectAngle: {type:"spinner",value:toDeg(this.angle)},
            objectStrokeColor: {type:"color",value:this.stroke},
            objectFillColor: {type:"color",value:this.fill},
            objectLabelStyleText: {type:"na",value:Elevator.prototype.slide(null,{value:this.labelStyle})},
            objectLabelStyle: {type:"slider",value:this.labelStyle,min:0,max:2,slide:Elevator.prototype.slide},
            objectLabelColor: {type:"na",value:null},
            objectLabelSize: {type:"spinner",value:this.lengthLabel.fontSize},
        }
        thisData.dividers = {
            sizeDivider:true,
            positionDivider:true,
            colorDivider:true,
            labelsDivider:true
        }
        return thisData;
    }

    Column.prototype.slide = function(event,ui){
            var message = "";
            // 0 is never show labels
            // 1 is only show width on select
            // 2 is show all labels always
            switch(ui.value){
                case 0:
                message = "No Labels"
                break;
                case 1:
                message = "Show Labels on Select"
                break;
                case 2:
                message = "Always Show Labels"
                break;
            }
            $( "#objectLabelStyleText" ).html(message);
    }

    Column.prototype.setobjectLength = function(value){
        var newX3 = value * Math.cos(this.angle - Math.PI/2) + this.points[0].x;
        var newY3 = -value * Math.sin(this.angle - Math.PI/2) + this.points[0].y;
        var newX2 = value * Math.cos(this.angle - Math.PI/2) + this.points[1].x;
        var newY2 = -value * Math.sin(this.angle - Math.PI/2) + this.points[1].y;
        this.points[2].updatePosition(newX2,newY2);
        this.points[3].updatePosition(newX3,newY3);
        this.update();
    }

    Column.prototype.setobjectWidth = function(value){
        var newX1 = value * Math.cos(this.angle) + this.points[0].x;
        var newY1 = -value * Math.sin(this.angle) + this.points[0].y;
        var newX2 = value * Math.cos(this.angle) + this.points[3].x;
        var newY2 = -value * Math.sin(this.angle) + this.points[3].y;
        this.points[1].updatePosition(newX1,newY1);
        this.points[2].updatePosition(newX2,newY2);
        this.update();
        return this.width;
    }

    Column.prototype.setStrokeWidth = function(value){
        this.lineWidth = value;
        this.update();
        return this.lineWidth;
    }

    Column.prototype.setobjectAngle = function(angle){
        this.getCenter();
        this.points[0].setRotateAngle(this.centerPoint.x,this.centerPoint.y,this.angle);
        this.points[1].setRotateAngle(this.centerPoint.x,this.centerPoint.y,this.angle);
        this.points[2].setRotateAngle(this.centerPoint.x,this.centerPoint.y,this.angle);
        this.points[3].setRotateAngle(this.centerPoint.x,this.centerPoint.y,this.angle);
        this.points[0].rotateAroundCenter(this.centerPoint.x,this.centerPoint.y,angle);
        this.points[1].rotateAroundCenter(this.centerPoint.x,this.centerPoint.y,angle);
        this.points[2].rotateAroundCenter(this.centerPoint.x,this.centerPoint.y,angle);
        this.points[3].rotateAroundCenter(this.centerPoint.x,this.centerPoint.y,angle);
        this.update();
    }

    Column.prototype.setobjectStrokeColor = function(color){
        var isOk  = /(^#[0-9A-F]{6}$)|(^#[0-9A-F]{3}$)/i.test(color)
        if(isOk){
            this.stroke = color;
        } else {
            console.log("color not recognized")
        }
        this.outer.css("fill",this.stroke);
        return this.stroke;
    }

    Column.prototype.setobjectFillColor = function(color){
        var isOk  = /(^#[0-9A-F]{6}$)|(^#[0-9A-F]{3}$)/i.test(color)
        if(isOk){
            this.fill = color;
        } else {;
            console.log("color not recognized")
        }
        this.inner.css("fill",this.fill);
        return this.fill;
    }