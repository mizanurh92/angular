function Wall(id,state,map){
    MapObject.call(this,"Wall",id); // Sets Elevator as subclass of MapObject
    this.state = state; // Reference to the State Controller
    this.map = map; // Reference to the Map Controller
    
    this.type = "Wall"; // Can be removed - lives on superclass - just here for reminder
    this.id = id; // Can be removed - lives on superclass - just here for reminder
    this.handleDragging = ""; // Can be removed - lives on superclass - just here for reminder
    this.isSelected = false;   // Can be removed - lives on superclass - just here for reminder
    this.snapSensitivity = 12;

    this.outerWidth = 6;  // Width of the wall (thickness) in inches
    this.innerColor = "#D3D3D3";  // Default inner color
    this.outerColor = "#000000";  // Default outer color
    this.fontSize = 15;
    this.defaultStyle = 1; // Default style shows the measures only on select
    this.drawStyle = 2; // Shows the measures when the wall is being drawn

    this.doorOpen = true;  // Boolean which determines whether non-overriden open doors are displayed
    this.labelStyle = 1; // Determines how the wall label is displayed.  Defaults to always showing the length label
    this.doorCounter = "00"; // Number of doors on the wall - also used with the door ID
    this.windowCounter = "00";  // Number of windows on the wall - also used with the window ID
    this.rightAngleSensitivity = Math.PI/36;

    this.points = []; // Contains points which make up the wall
    this.wallPoints = {}; // Contains bounding points used to snap and interact with other walls
    this.pointAdjusters = {
        2:{active:false},
        3:{active:false},
        4:{active:false},
        5:{active:false},
        6:{active:false},
        7:{active:false},
        8:{active:false},
        9:{active:false},
        10:{active:false},
        11:{active:false}
    };

    this.inner = null;
    this.outer = null;
    this.center = null;

    this.doors = {};  // Object which holds door objects, key is the door's unique ID
    this.windows = {}; // Object which holds window objects, key is the window's unique ID
    
    this.activeColor = "#ff0000"; // Tis is the color the wall will be set to when selected
    this.innerWidth = this.outerWidth -1;  // Inner wall width, which should be sligthly smaller than outer wall for stroke/fill effect
    this.lengthLabel = {};  // Holds a wallLabel object which shows the wall length along the wall
    this.angle = 0;  // Angle in degrees of the wall with respect to the x-axis
    this.length = 0;  // Length of the wall in inches
    this.decimals = {US:0,Metric:2};
    this.dontSnap = [];
    this.addedSnaps = [];

    this.packageParameters = [ // Used in undo/redo/duplicate/save/load methods
        "type",
        "id",
        "outerWidth",
        "innerColor",
        "outerColor",
        "doorOpen",
        "labelStyle",
        "doorCounter",
        "windowCounter",
        "fontSize"
    ];
}
    Wall.prototype = Object.create(MapObject.prototype); // Links the prototype to the superclass
    Wall.prototype.constructor = Wall;

// ##########################################  Standard Object Interface Functions  ##################################################################

    Wall.prototype.getSnapPoints = function(){
        var sensitivity = this.snapSensitivity;
        var snapObject = {
            snapPoints: [],
            bufferBox: [],
            snapEdges: []
        }
        var points = [
            this.pointAdjusters[2].active ? this.pointAdjusters[2] : this.points[2],
            this.pointAdjusters[4].active ? this.pointAdjusters[4] : this.points[4],
            this.pointAdjusters[5].active ? this.pointAdjusters[5] : this.points[5],
            this.pointAdjusters[3].active ? this.pointAdjusters[3] : this.points[3]
            ];
        var theta = this.angle + Math.PI/4;
        var theta2;
        var tempPoint = {};
        var currentPoint;
        for(var i = 0;i < 4;i++){ // Finds the center points of the corner posts of the cubicle as snap points
            theta -= Math.PI/2;
            theta2 = theta + Math.PI;
            currentPoint = {x:points[i].x,y:points[i].y};
            if(!contains(this.dontSnap,i)){
                snapObject.snapPoints.push({x:currentPoint.x,y:currentPoint.y});
            }
            // The following calculates in the opposite direction to create a buffer zone around the cubicle
            // This zone is used to trigger snapping for the cubicle
            tempPoint.x = currentPoint.x + sensitivity * Math.cos(theta2);
            tempPoint.y = currentPoint.y - sensitivity * Math.sin(theta2);
            snapObject.bufferBox.push({x:tempPoint.x,y:tempPoint.y});          
        }
        snapObject.snapPoints = snapObject.snapPoints.concat(this.addedSnaps);
        for(var i = 0;i<4;i++){ // Finds the edges between the snap points above
            snapObject.snapEdges.push({
                start:copyPoint(points[i]),
                end:copyPoint(points[(i+1)%4])
            });
        }
        return snapObject;        
    }

    Wall.prototype.getBorderEdges = function(){
        var edges = [];
        var points = [
            this.pointAdjusters[2].active ? roundPoint(this.pointAdjusters[2]) : roundPoint(this.points[2]),
            this.pointAdjusters[4].active ? roundPoint(this.pointAdjusters[4]) : roundPoint(this.points[4]),
            this.pointAdjusters[5].active ? roundPoint(this.pointAdjusters[5]) : roundPoint(this.points[5]),
            this.pointAdjusters[3].active ? roundPoint(this.pointAdjusters[3]) : roundPoint(this.points[3])
            ];
        for(var i = 0;i<4;i++){ // Finds the edges between the points above
            edges.push({
                start:copyPoint(points[i]),
                end:copyPoint(points[(i+1)%4])
            });
        }
        return edges;      
    }

    Wall.prototype.create = function(map){ // This creates all components of the wall object
        var pos = this.map.pointerCoords();
        var x = this.map.snapRound(pos.x);
        var y = this.map.snapRound(pos.y);
        this.points[0] = new point(x,y,"ARWP00"+this.id); // Start Point
        this.points[1] = new point(x,y,"ARWP01"+this.id); // End Point
        this.points[2] = new point(x,y,"ARWP02"+this.id);
        this.points[3] = new point(x,y,"ARWP03"+this.id);
        this.points[4] = new point(x,y,"ARWP04"+this.id);
        this.points[5] = new point(x,y,"ARWP05"+this.id);
        this.points[6] = new point(x,y,"ARWP06"+this.id); // Inner Start Point
        this.points[7] = new point(x,y,"ARWP07"+this.id); // Inner End Point
        this.points[8] = new point(x,y,"ARWP08"+this.id);
        this.points[9] = new point(x,y,"ARWP09"+this.id);
        this.points[10] = new point(x,y,"ARWP10"+this.id);
        this.points[11] = new point(x,y,"ARWP11"+this.id);
        this.createSVG();
        this.addLabels();
    }

    Wall.prototype.update = function(){  // This is the basic update function that should occur every time a change is made that would affect layout
        this.calculateAngle();
        this.calculateLength();
        this.calculatePoints();
        this.updateDoors();
        this.updateWindows();
        this.updateSVG();
        this.setLabelStyle();
    }

    Wall.prototype.remove = function(){ // Removes all the screen elements of the wall, once done, the door object can be deleted safely
        this.removeHandles();
        this.removeSVG();
        this.removeLabels();
    }

    Wall.prototype.redraw = function(){  // Redraws all svg screen objects (if otherwise visible) after they have been removed
        this.createSVG();
        for(var door in this.doors){
            this.doors[door].redraw();
        }
        for(var window in this.windows){
            this.windows[window].redraw();
        }
        this.update();
    }

    Wall.prototype.activate = function(multiSelect,subclass,subclassID){ // Sets the wall to active status, presumably upon mouse selection by the user
        if(subclass == undefined){
            this.outer.css("fill",this.activeColor);
            this.isSelected = true;
            this.setLabelStyle();
            if(multiSelect){
                this.removeHandles();
            } else {
                this.drawHandles();
            }            
        } else if(subclass == "Window"){
            this.windows[subclassID].activate(false);
        } else if(subclass == "Door"){
            this.doors[subclassID].activate(false);
        }
    }

    Wall.prototype.viewerActivate = function(options){
        options = options || {};
        if(options.subclass && options.subclassID){
            switch(options.subclass){
                case "Window":
                    this.windows[options.subclassID].activate(false);
                break;
                case "Door":
                    this.doors[options.subclassID].activate(false);
                break;
            }
            return;
        }
        this.outer.css("fill",this.activeColor);
        this.isSelected = true;
        this.setLabelStyle();
    }

    Wall.prototype.deactivate = function(){  // Deselects the wall
        this.outer.css("fill",this.outerColor);
        this.isSelected = false;
        this.removeHandles();
        this.setLabelStyle();
    }

    Wall.prototype.getOutlinePoints = function(){
        var pointObject = [];
        for(var i = 2;i < 6;i++){
            pointObject.push(this.points[i].getPoint());
        }
        return pointObject;
    }

    // Used in map resize.  Gets the bounding box of the used part of the map
    Wall.prototype.getBorderBox = function(){
        var xArray = [];
        var yArray = [];
        var pointsLen = this.points.length;
        for(var i = 2;i < 12;i++){
            var adjPoint = this.pointAdjusters[i];
            if(adjPoint.active == true){
                xArray.push(adjPoint.x);
                yArray.push(adjPoint.y);
            } else {
                xArray.push(this.points[i].x);
                yArray.push(this.points[i].y);                  
            }
        }
        return {xArray:xArray,yArray:yArray};
    }

    Wall.prototype.getBoundingPoints = function(dist){ // TODO - I think the number of points can be reduced
        var points = [];
        points.push(this.points[0].getPoint());
        points.push(this.points[1].getPoint());
        points.push(this.points[2].getPoint());
        points.push(this.points[4].getPoint());
        points.push(this.points[5].getPoint());
        points.push(this.points[3].getPoint());
        this.calculateAngle();
        points.push({x:this.points[2].x + dist * Math.cos(this.angle + 3*Math.PI/4),
            y:this.points[2].y - dist * Math.sin(this.angle + 3*Math.PI/4)});
        points.push({x:this.points[4].x + dist * Math.cos(this.angle + Math.PI/4),
            y:this.points[4].y - dist * Math.sin(this.angle + Math.PI/4)});
        points.push({x:this.points[5].x + dist * Math.cos(this.angle - Math.PI/4),
            y:this.points[5].y - dist * Math.sin(this.angle - Math.PI/4)})
        points.push({x:this.points[3].x + dist * Math.cos(this.angle - 3*Math.PI/4),
            y:this.points[3].y - dist * Math.sin(this.angle - 3*Math.PI/4)});

        return points;     
    }


// ##########################################  Point Handle Functions  ##################################################################

    Wall.prototype.handlePress = function(handleID,points){  // Receives a handle press event and saves the mouse location and handle ID for drag process
        if(handleID.slice(2,3)=="D"){
            var doorID = "e" + handleID.slice(3,5) + this.id;
            this.doors[doorID].handlePress(handleID);
            this.doorHandleDragging = handleID;
            return;
        }
        if(handleID.slice(2,3)=="I"){
            var winID = "w" + handleID.slice(3,5) + this.id;
            this.windows[winID].handlePress(handleID);
            this.windowHandleDragging = handleID;
            return;
        }
        this.wallPoints = points;
        for(var i = 0;i < this.points.length;i++){
            this.points[i].setDragReference();
        }
        this.handleDragging = handleID.slice(4,6)*1;
        this.undoPackage = this.createPackage();
        for(var i in this.pointAdjusters){this.pointAdjusters[i].active = false;}
    }

    Wall.prototype.handleDrag = function(){  // Receives a handle drag event and changes the point associated with the handle based on the new location
        var map = this.map;
        if(this.doorHandleDragging != undefined){
            var doorID = "e" + this.doorHandleDragging.slice(3,5) + this.id;
            this.doors[doorID].handleDrag();
            return;            
        }
        if(this.windowHandleDragging != undefined){
            var winID = "w" + this.windowHandleDragging.slice(3,5) + this.id;
            this.windows[winID].handleDrag();
            return;            
        }
        if(this.handleDragging == 0 || this.handleDragging == 1){ // checks that either endpoint is being dragged
            var coords = map.pointerCoords(); // gets the latest mouse location
            var xMove = coords.x-map.handle.x/map.scale;
            var yMove = coords.y-map.handle.y/map.scale;
            this.points[this.handleDragging].dragOffset(xMove,yMove,{gridResolution:map.snapGridResolution,snapToGrid:map.snapGridActive});
            this.update();

            // Portion of the drag process that checks for snap points with other walls
            var intersectList = [];
            if(this.handleDragging == 0){
                var dragEdge = [this.points[2].getPoint(),this.points[3].getPoint()];
                var farEdge = [this.points[4].getPoint(),this.points[5].getPoint()];
            } else {
                var dragEdge = [this.points[4].getPoint(),this.points[5].getPoint()];
                var farEdge = [this.points[2].getPoint(),this.points[3].getPoint()];
            }

            for(var i in this.wallPoints){
                var check = polyInside(dragEdge,this.wallPoints[i].slice(6));
                if(check[0]){
                    intersectList.push([i,check[1]]);
                    break;
                }
            }

            if(intersectList.length>0){ // If an intersection is found with the handle being dragged, get the snap point
                var newCoords = this.getSnapPoint(
                    this.wallPoints[intersectList[0][0]],
                    this.points[this.handleDragging].getPoint(),
                    this.points[Math.abs(this.handleDragging-1)].getPoint()
                    );
                this.points[this.handleDragging].updatePosition(newCoords.x,newCoords.y);
                this.update();
            } else { // If there isn't an intersection with the drag handle, check for an intersection with the other wall side
                for(var i in this.wallPoints){
                    var check = polyInside(farEdge,this.wallPoints[i].slice(6));
                    if(check[0]){
                        intersectList.push([i,check[1]]);
                        break;
                    }
                }
                if(intersectList.length>0){ // If there is an intersection with the other wall side, try to snap to square the walls
                    var newCoords = this.checkRightAngle(
                        this.wallPoints[intersectList[0][0]],
                        this.points[this.handleDragging].getPoint(),
                        this.points[Math.abs(this.handleDragging-1)].getPoint(),
                        this.rightAngleSensitivity
                        );
                    this.points[this.handleDragging].updatePosition(newCoords.x,newCoords.y);
                    this.update();
                }
            }
        }
    }

    Wall.prototype.finalizeHandleDrag = function(){
        
        if(this.doorHandleDragging != undefined){
            var doorID = "e" + this.doorHandleDragging.slice(3,5) + this.id;
            this.doors[doorID].finalizeHandleDrag();
            delete this.doorHandleDragging;
            return;            
        }
        if(this.windowHandleDragging != undefined){
            var winID = "w" + this.windowHandleDragging.slice(3,5) + this.id;
            this.windows[winID].finalizeHandleDrag();
            delete this.windowHandleDragging;
            return;            
        }
        this.update();            
        this.sendPackages();
    }

    Wall.prototype.drawHandles = function(){
        this.points[0].drawHandle();
        this.points[1].drawHandle();        
    }

    Wall.prototype.removeHandles = function(){ // Removes the handles on the wall endpoints
        this.points[0].removeHandle();
        this.points[1].removeHandle();
    }

// ##########################################  Application Mechanics (Undo/Redo/Duplicate/Save/Load)  #############################################

    Wall.prototype.duplicate = function(original){
        for(var i = 0;i < original.points.length;i++){
            this.points.push(new point(original.points[i].x,original.points[i].y,original.points[i].id.substring(0,6)+this.id))
        }
        for(var i = 0;i < this.packageParameters.length;i++){
            if(this.packageParameters[i] != "id"){
                this[this.packageParameters[i]] = original[this.packageParameters[i]];
            }
        }
        this.createSVG();
        this.addLabels();
        this.move(12,12);
        for(var door in original.doors){
            var id = "e"+this.incrementDoor()+this.id;
            this.doors[id] = new Door(id,36,48,"#FFFFFF",this.state,this.map,this);
            this.doors[id].duplicate(original.doors[door]);
        }
        for(var windowObj in original.windows){
            var id = "w"+this.incrementWindow()+this.id;
            this.windows[id] = new WindowClass(id,36,36,"#ffffff",this.outerWidth,this.state,this.map,this);
            this.windows[id].duplicate(original.windows[windowObj]);
        }
        this.update();
    }

    Wall.prototype.createPackage = function(){
        var package = {points:[]};
        for(var i = 0;i < this.points.length;i++){
            package.points.push(this.points[i].getPoint());
        }
        for(var i = 0;i < this.packageParameters.length;i++){
            package[this.packageParameters[i]] = this[this.packageParameters[i]];
        }
        package.controller = "architect";
        package.packageType = "modify";
        return package;
    }

    Wall.prototype.loadPackage = function(package){
        console.log(package.packageType);
        switch(package.packageType){
            case "modify":
                // It doesn't matter if it is an undo or redo package, the impact is to reset the object to a former state
                for(var i = 0;i < this.points.length;i++){
                    this.points[i].updatePosition(package.points[i].x,package.points[i].y);
                }
                for(var i = 0;i < this.packageParameters.length;i++){
                    this[this.packageParameters[i]] = package[this.packageParameters[i]];
                }
                this.update();
            break;
            case "modify door":
                this.doors[package.id].loadPackage(package);
            break;
            case "redo create door":
            case "undo delete door":
                this.doors[package.id] = package.object;
                this.doors[package.id].redraw();
            break;
            case "undo create door":
            case "redo delete door":
                this.doors[package.id].remove();
                delete this.doors[package.id];
            break;
        }
    }

    Wall.prototype.sendPackages = function(){
        // It is important to know that the undo and redo packages aren't the same.  If they are, there was no real action taken and
        // an undo or redo event will have no apparent effect
        var undo = this.undoPackage;
        var redo = this.createPackage();
        var same = true; // Used to determine whether the two packages are the same (no actual event occured)
        for(var i = 0;i < redo.points.length;i++){ // Runs through the points first as the most common event changes
            if(undo.points[i].x != redo.points[i].x || undo.points[i].y != redo.points[i].y){
                same = false;
                break; // breaks as soon as a single difference is found
            }
        }       
        if(same){ // No need to start second loop if a difference was already found
            for(var i = 0;i < this.packageParameters.length;i++){
                if(undo[this.packageParameters[i]] != redo[this.packageParameters[i]]){
                    same = false;
                    break;
                }
            }
        }
        // Packages are sent essentially simultaneously to prevent having mismatched packages if the action isn't finalized
        if(same == false){
            this.state.addUndoPackage(undo);
            this.state.addRedoPackage(redo);
        }
    }

    Wall.prototype.save = function(){
        var saveFile = {points:[],doors:[],windows:[]};
        for(var i = 0;i < 2;i++){
            saveFile.points.push(this.points[i].getPoint());
        }
        for(var door in this.doors){
            saveFile.doors.push(this.doors[door].save());
        }
        for(var windowObj in this.windows){
            saveFile.windows.push(this.windows[windowObj].save());
        }
        for(var i = 0;i < this.packageParameters.length;i++){
            saveFile[this.packageParameters[i]] = this[this.packageParameters[i]];
        }
        return saveFile
    }

    Wall.prototype.load = function(saveFile){
        // Note that this method assumes that the create function has not been called - will not work if it has been
        this.points[0] = new point(0,0,"ARWP00"+this.id); // Start Point
        this.points[1] = new point(0,0,"ARWP01"+this.id); // End Point
        this.points[2] = new point(0,0,"ARWP02"+this.id);
        this.points[3] = new point(0,0,"ARWP03"+this.id);
        this.points[4] = new point(0,0,"ARWP04"+this.id);
        this.points[5] = new point(0,0,"ARWP05"+this.id);
        this.points[6] = new point(0,0,"ARWP06"+this.id); // Inner Start Point
        this.points[7] = new point(0,0,"ARWP07"+this.id); // Inner End Point
        this.points[8] = new point(0,0,"ARWP08"+this.id);
        this.points[9] = new point(0,0,"ARWP09"+this.id);
        this.points[10] = new point(0,0,"ARWP10"+this.id);
        this.points[11] = new point(0,0,"ARWP11"+this.id);

        for(var i = 0;i < 2;i++){
            this.points[i].updatePosition(saveFile.points[i].x,saveFile.points[i].y);
        }
        this.calculatePoints();

        for(var i = 0;i < this.packageParameters.length;i++){
            this[this.packageParameters[i]] = saveFile[this.packageParameters[i]];
        }
        this.innerWidth = this.outerWidth - 1;
        this.createSVG(); 
        this.addLabels();
        this.calculateLength();
        if(saveFile.doors != undefined){
            for(var i = 0;i < saveFile.doors.length;i++){
                var door = saveFile.doors[i];
                this.doors[door.id] = new Door(door.id,door.width,door.dist,door.color,this.state,this.map,this);
                this.doors[door.id].load(door);
            }            
        }
        if(saveFile.windows != undefined){
            for(var i = 0;i < saveFile.windows.length;i++){
                var windowObj = saveFile.windows[i];
                this.windows[windowObj.id] = new WindowClass(windowObj.id,windowObj.width,windowObj.dist,
                    windowObj.color,windowObj.lineWidth,this.state,this.map,this);
                this.windows[windowObj.id].load(windowObj);
            }
        }

        this.update();
    }

    Wall.prototype.createUndoCreatePackage = function(id,type){
        var package = {};
        package.packageType = "undo create "+ type;
        package.controller = "architect";
        package.id = id;
        return package;      
    }

    Wall.prototype.createRedoCreatePackage = function(id,type){
        var package = {};
        package.packageType = "redo create " + type;
        package.controller = "architect";
        package.id = id;
        if(type == "door"){
            package.object = this.doors[id];
        } else if (type == "windows"){
            package.object = this.windows[id];
        }
        return package;
    }

    Wall.prototype.createUndoDeletePackage = function(id,type){
        var package = {};
        package.packageType = "undo delete " + type;
        package.controller = "architect";
        package.id = id;
        if(type == "door"){
            package.object = this.doors[id];
        } else if (type == "windows"){
            package.object = this.windows[id];
        }
        return package;
    }

    Wall.prototype.createRedoDeletePackage = function(id,type){
        var package = {};
        package.packageType = "redo delete " + type;
        package.controller = "architect";
        package.id = id;
        return package;
    }

// ##########################################  Drag and Move Functions  #############################################

    Wall.prototype.startDrag = function(objID,type,points){ // Called by the architecture controller when the body of the svg is pressed (for a drag event)
        if(type == undefined){
            this.wallPoints = points;
            this.undoPackage = this.createPackage();
            for(var i = 0;i < 2;i++){
                this.points[i].setDragReference();
            }     
        } else if(type == "Door") {
            this.doors[objID].startDrag();
        } else if (type == "Window"){
            this.windows[objID].startDrag();
        }
        for(var i in this.pointAdjusters){this.pointAdjusters[i].active = false;}
    }

    Wall.prototype.drag = function(type,id){ // Drags the wall upon a left-button down on the wall layer svg and dragging the mouse
        var map = this.map;
        if(type == undefined){ // Dragging the wall itself
            // The following calculates the distance that the user has dragged the selected object since pressing the left mouse button
            // This is calculated in map coordinate scale, so the division of the map handle location is converted in line.
            var coords = map.pointerCoords(); // gets the latest mouse location
            var xMove = coords.x-map.handle.x/map.scale;
            var yMove = coords.y-map.handle.y/map.scale;
            
            // The following uses point[0] as a reference point for dragging.  If snapGrid is on, then point[0] will align to grid and
            // the other points will move an equivalent distance.  This prevents each point from rounding independently and causing the
            // object to change dimensions slightly as it is being dragged.
            var distDragged = this.points[0].dragOffset(xMove,yMove,{gridResolution:map.snapGridResolution,snapToGrid:map.snapGridActive});
            this.points[1].dragOffset(distDragged.x,distDragged.y);
            this.update();
            
            var thisWall = [this.points[2].getPoint(),this.points[3].getPoint(),this.points[4].getPoint(),this.points[5].getPoint()];
            var intersectList = [];
            for(var i in this.wallPoints){
                var check = polyInside(thisWall,this.wallPoints[i].slice(6));
                if(check[0]){
                    intersectList.push([i,check[1]]);
                }
            }
            if(intersectList.length>0){
                for(var i = 0;i < intersectList.length;i++){
                    if(intersectList[i][1]>1){
                        var newCoords = this.getSnapPoint(this.wallPoints[intersectList[i][0]],this.points[1].getPoint(),this.points[0].getPoint());
                        this.points[1].updatePosition(newCoords.x,newCoords.y);
                    } else{
                        var newCoords = this.getSnapPoint(this.wallPoints[intersectList[i][0]],this.points[0].getPoint(),this.points[1].getPoint());
                        this.points[0].updatePosition(newCoords.x,newCoords.y);
                    }
                }
                this.update();
            }            
        } else if (type == "Door"){
            this.doors[id].drag();
        } else if (type == "Window"){
            this.windows[id].drag();
        }
    }


    Wall.prototype.getSnapPoint = function(snapWall,pointToSnap,farPoint){ // snapWall should be an array with two point objects, 0 being the start
        var xMove = pointToSnap.x - snapWall[0].x;
        var yMove = pointToSnap.y - snapWall[0].y;
        var snapwallDist = Math.sqrt(Math.pow(snapWall[0].y-snapWall[1].y,2)+Math.pow(snapWall[1].x-snapWall[0].x,2));
        var theta1 = Math.atan2((snapWall[0].y-snapWall[1].y),(snapWall[1].x-snapWall[0].x));
        var theta2 = Math.atan2(-yMove,xMove);
        var theta3 = theta2 - theta1;
        var dist = Math.sqrt(Math.pow(xMove,2)+Math.pow(yMove,2));
        var constrainedDist = Math.min(Math.max(dist * Math.cos(theta3),0),snapwallDist);
        
        var rightCheck = this.get90DegPointRange(snapWall,farPoint,6);
        if(constrainedDist >= rightCheck.startRange && constrainedDist <= rightCheck.endRange){
            constrainedDist = rightCheck.dist;
        }
        if(snapwallDist - constrainedDist < 6){constrainedDist = snapwallDist;}
        if(constrainedDist < 6){constrainedDist = 0;}
        var newX = constrainedDist * Math.cos(theta1);
        var newY = -constrainedDist * Math.sin(theta1);
        return {x:snapWall[0].x+newX,y:snapWall[0].y+newY,snapwallDist:snapwallDist,constrainedDist:constrainedDist,snapWall:snapWall}
    }

    Wall.prototype.checkRightAngle = function(snapWall, farPoint, nearPoint, range){ 
        // Goal is to return a far point value if it is close to square with the snapWall and the near point
        var theta1 = Math.atan2((snapWall[0].y-snapWall[1].y),(snapWall[1].x-snapWall[0].x));
        var theta2 = Math.atan2((nearPoint.y-farPoint.y),(farPoint.x - nearPoint.x));
        var theta3 = theta2 - theta1 - Math.PI/2;
        if(Math.abs(theta3%Math.PI)<=range || (Math.PI - Math.abs(theta3%Math.PI))<=range){
            var theta4 = theta1 + Math.PI/2;
            var d1 = getLength(nearPoint,farPoint);
            var d2 = d1 * Math.cos(theta3);
            var snapPoint = {};
            snapPoint.x = d2 * Math.cos(theta4) + nearPoint.x;
            snapPoint.y = -d2 * Math.sin(theta4) + nearPoint.y;
            return snapPoint;
        } else {
            return farPoint;
        }
    }

    Wall.prototype.get90DegPointRange = function(snapWall,pointToSnap,range){ // snapWall should be an array with two point objects, 0 being the start
        var xMove = pointToSnap.x - snapWall[0].x;
        var yMove = pointToSnap.y - snapWall[0].y;
        var snapwallDist = getLength(snapWall[0],snapWall[1]);
        var theta1 = Math.atan2((snapWall[0].y-snapWall[1].y),(snapWall[1].x-snapWall[0].x));
        var theta2 = Math.atan2(-yMove,xMove);
        var theta3 = theta2 - theta1;
        var dist = Math.sqrt(Math.pow(xMove,2)+Math.pow(yMove,2));
        if(dist * Math.cos(theta3) > snapwallDist){
            return false;
        } else if(dist*Math.cos(theta3) < 0){
            return false;
        }
        var constrainedDist = dist * Math.cos(theta3);
        var startRange = constrainedDist - range;
        var endRange = constrainedDist + range;
        if(startRange < 0){startRange = 0;} else if(endRange > snapwallDist){endRange = snapwallDist;}
        return {dist:constrainedDist,startRange:startRange,endRange:endRange};
    }


    Wall.prototype.formatSnapWall = function(snapObjects){
        var thisWall = [
            this.pointAdjusters[2].active ? this.pointAdjusters[2] : this.points[2],
            this.pointAdjusters[4].active ? this.pointAdjusters[4] : this.points[4],
            this.pointAdjusters[5].active ? this.pointAdjusters[5] : this.points[5],
            this.pointAdjusters[3].active ? this.pointAdjusters[3] : this.points[3]            
        ];
        this.dontSnap = [];
        this.addedSnaps = [];
        
        var wallPoint,check;
        for(var i = 0; i < 4; i++){
            wallPoint = thisWall[i];
            for(var j in snapObjects){
                if(j == this.id){continue;}
                if(pointInside({x:wallPoint.x,y:wallPoint.y},snapObjects[j].snapPoints)){
                    this.dontSnap.push(i);
                    break;
                }
            }
        }
        
        var edgesToCheck = [];
        // Creates an array of all wall edges that aren't this wall
        for(var i in snapObjects){
            if(i == this.id){continue;}
            edgesToCheck = edgesToCheck.concat(snapObjects[i].snapEdges);
        }
        
        var snapEdges = this.getSnapPoints().snapEdges;
        var edge;
        // Checks each of this wall's edges for intersections with other edges
        for(var i in snapEdges){
            edge = snapEdges[i];
            for(var j in edgesToCheck){
                check = getSegmentIntersection(edge,edgesToCheck[j]);
                if(check){
                    this.addedSnaps.push(check);
                }
            }
        }
        console.log(this.addedSnaps)
    }

    Wall.prototype.updateIntersections = function(points){
        // Resets point adjusters
        for(var i in this.pointAdjusters){this.pointAdjusters[i].active = false;}
        var thisWall = [this.points[0].getPoint(),this.points[1].getPoint()];
        var intersections = [];

        for(var i in points){
            if(i == this.id){continue;}
            var check = polyInside(thisWall,points[i].slice(6,10));
            if(check[0]){
                intersections.push(points[i]);
            }
        }
        var intersectCount = intersections.length;
        for(var i = 0;i < intersectCount;i++){
            this.checkForEndConnect(intersections[i]);
        }
        this.wallPoints = {};
        this.updateSVGLite();
    }

    Wall.prototype.checkForEndConnect = function(snapWall){   
        // These check whether the walls are equivalent
        if(equalPoints(this.points[1],snapWall[1]) && equalPoints(this.points[0],snapWall[0])){return;}
        if(equalPoints(this.points[0],snapWall[1]) && equalPoints(this.points[1],snapWall[0])){return;}
        
        if(equalPoints(this.points[1],snapWall[1])){
            var theta1 = Math.atan2((snapWall[0].y-snapWall[1].y),(snapWall[1].x-snapWall[0].x)); // Angle (coordinate space) for snap wall
            var theta2 = Math.atan2((this.points[0].y-this.points[1].y),(this.points[1].x-this.points[0].x)); // Angle (coordinate space) for current wall
            if(anglesCollinear(theta1,theta2)){return false;} // If walls are colinear, no adjustments are needed
            var theta5 = Math.PI + theta2 - theta1; // Angle (coordinate space) between outer opening between two walls
            var w1 = this.outerWidth/2; // Distance between current wall center point and outside point
            var w2 = getLength(snapWall[0],snapWall[2]); // Distance between snap wall center point and outside point
            var w3 = getLength(this.points[4].getPoint(),snapWall[4]); // Distance between two wall's outside points
            if(w1 <= w2){  // Equation method depends on which wall is wider (uses law of sines)
                var theta6 = Math.asin((w1/w3)*Math.sin(theta5));
                var theta7 = Math.PI - theta6 - theta5;
            } else {
                var theta7 = Math.asin((w2/w3)*Math.sin(theta5));
                var theta6 = Math.PI - theta7 - theta5;            
            }
            var theta9 = Math.PI/2 - theta6; // Angle (triangle space) between snap wall outer edge point and far intersect point
            var d1 = w3*Math.sin(theta9)/Math.sin(theta5); // Distance between current wall outer edge point and far intersect point
            var theta10 = Math.atan2(w1,d1); // Angle (right triangle measure) from outer intersection to inner intersection
            var d2 = Math.sqrt(Math.pow(d1,2)+Math.pow(w1,2)); // Distance from midpoint intersection to far point intersection
            var theta11 = theta2 - Math.PI + theta10; // Angle (map coord system) between outer intersection and inner intersection
            var innerOuterDist = 0.707106781; // Distance between inner and outer layers at intersections
            var intersect = {
                x: d1 * Math.cos(theta2) + this.points[4].x,
                y: -d1 * Math.sin(theta2) + this.points[4].y
            }
            this.pointAdjusters[4].active = true;
            this.pointAdjusters[4].x = intersect.x;
            this.pointAdjusters[4].y = intersect.y;            
            this.pointAdjusters[10].active = true;
            this.pointAdjusters[10].x = innerOuterDist * Math.cos(theta11) + intersect.x;
            this.pointAdjusters[10].y = -innerOuterDist  * Math.sin(theta11) + intersect.y;
            this.pointAdjusters[7].active = true;  // Inner should be colinear with outer at intersection edges
            this.pointAdjusters[7].x = this.points[1].x;
            this.pointAdjusters[7].y = this.points[1].y;
            this.pointAdjusters[11].active = true;
            this.pointAdjusters[11].x = (2 * d2 - innerOuterDist) * Math.cos(theta11) + intersect.x;
            this.pointAdjusters[11].y = -(2 * d2 - innerOuterDist) * Math.sin(theta11) + intersect.y;
            this.pointAdjusters[5].active = true;
            this.pointAdjusters[5].x = (2 * d2) * Math.cos(theta11) + intersect.x;
            this.pointAdjusters[5].y = -(2 * d2) * Math.sin(theta11) + intersect.y;
        } else if (equalPoints(this.points[0],snapWall[1])){
            var theta1 = Math.atan2((snapWall[0].y-snapWall[1].y),(snapWall[1].x-snapWall[0].x)); // Angle (coordinate space) for snap wall
            var theta2 = Math.atan2((this.points[1].y-this.points[0].y),(this.points[0].x-this.points[1].x)); // Angle (coordinate space) for current wall
            if(anglesCollinear(theta1,theta2)){return false;} // If walls are colinear, no adjustments are needed
            var theta5 = Math.PI + theta2 - theta1; // Angle (coordinate space) between outer opening between two walls
            var w1 = this.outerWidth/2; // Distance between current wall center point and outside point
            var w2 = getLength(snapWall[0],snapWall[2]); // Distance between snap wall center point and outside point
            var w3 = getLength(this.points[3].getPoint(),snapWall[4]); // Distance between two wall's outside points
            if(w1 <= w2){  // Equation method depends on which wall is wider (uses law of sines)
                var theta6 = Math.asin((w1/w3)*Math.sin(theta5));
                var theta7 = Math.PI - theta6 - theta5;
            } else {
                var theta7 = Math.asin((w2/w3)*Math.sin(theta5));
                var theta6 = Math.PI - theta7 - theta5;            
            }
            var theta9 = Math.PI/2 - theta6; // Angle (triangle space) between snap wall outer edge point and far intersect point
            var d1 = w3*Math.sin(theta9)/Math.sin(theta5); // Distance between current wall outer edge point and far intersect point
            var theta10 = Math.atan2(w1,d1); // Angle (right triangle measure) from outer intersection to inner intersection
            var d2 = Math.sqrt(Math.pow(d1,2)+Math.pow(w1,2)); // Distance from midpoint intersection to far point intersection
            var theta11 = theta2 - Math.PI + theta10; // Angle (map coord system) between outer intersection and inner intersection
            var innerOuterDist = 0.707106781; // Distance between inner and outer layers at intersections
            var intersect = {
                x: d1 * Math.cos(theta2) + this.points[3].x,
                y: -d1 * Math.sin(theta2) + this.points[3].y
            }
            this.pointAdjusters[3].active = true;
            this.pointAdjusters[3].x = intersect.x;
            this.pointAdjusters[3].y = intersect.y;            
            this.pointAdjusters[9].active = true;
            this.pointAdjusters[9].x = innerOuterDist * Math.cos(theta11) + intersect.x;
            this.pointAdjusters[9].y = -innerOuterDist  * Math.sin(theta11) + intersect.y;
            this.pointAdjusters[6].active = true;  // Inner should be colinear with outer at intersection edges
            this.pointAdjusters[6].x = this.points[0].x;
            this.pointAdjusters[6].y = this.points[0].y;
            this.pointAdjusters[8].active = true;
            this.pointAdjusters[8].x = (2 * d2 - innerOuterDist) * Math.cos(theta11) + intersect.x;
            this.pointAdjusters[8].y = -(2 * d2 - innerOuterDist) * Math.sin(theta11) + intersect.y;
            this.pointAdjusters[2].active = true;
            this.pointAdjusters[2].x = (2 * d2) * Math.cos(theta11) + intersect.x;
            this.pointAdjusters[2].y = -(2 * d2) * Math.sin(theta11) + intersect.y;
        } else if (equalPoints(this.points[1],snapWall[0])){
            var theta1 = Math.atan2((snapWall[1].y-snapWall[0].y),(snapWall[0].x-snapWall[1].x)); // Angle (coordinate space) for snap wall
            var theta2 = Math.atan2((this.points[0].y-this.points[1].y),(this.points[1].x-this.points[0].x)); // Angle (coordinate space) for current wall
            if(anglesCollinear(theta1,theta2)){return false;} // If walls are colinear, no adjustments are needed
            var theta5 = Math.PI + theta2 - theta1; // Angle (coordinate space) between outer opening between two walls
            var w1 = this.outerWidth/2; // Distance between current wall center point and outside point
            var w2 = getLength(snapWall[0],snapWall[2]); // Distance between snap wall center point and outside point
            var w3 = getLength(this.points[4].getPoint(),snapWall[2]); // Distance between two wall's outside points
            if(w1 <= w2){  // Equation method depends on which wall is wider (uses law of sines)
                var theta6 = Math.asin((w1/w3)*Math.sin(theta5));
                var theta7 = Math.PI - theta6 - theta5;
            } else {
                var theta7 = Math.asin((w2/w3)*Math.sin(theta5));
                var theta6 = Math.PI - theta7 - theta5;            
            }
            var theta9 = Math.PI/2 - theta6; // Angle (triangle space) between snap wall outer edge point and far intersect point
            var d1 = w3*Math.sin(theta9)/Math.sin(theta5); // Distance between current wall outer edge point and far intersect point
            var theta10 = Math.atan2(w1,d1); // Angle (right triangle measure) from outer intersection to inner intersection
            var d2 = Math.sqrt(Math.pow(d1,2)+Math.pow(w1,2)); // Distance from midpoint intersection to far point intersection
            var theta11 = theta2 - Math.PI + theta10; // Angle (map coord system) between outer intersection and inner intersection
            var innerOuterDist = 0.707106781; // Distance between inner and outer layers at intersections
            var intersect = {
                x: d1 * Math.cos(theta2) + this.points[4].x,
                y: -d1 * Math.sin(theta2) + this.points[4].y
            }
            this.pointAdjusters[4].active = true;
            this.pointAdjusters[4].x = intersect.x;
            this.pointAdjusters[4].y = intersect.y;            
            this.pointAdjusters[10].active = true;
            this.pointAdjusters[10].x = innerOuterDist * Math.cos(theta11) + intersect.x;
            this.pointAdjusters[10].y = -innerOuterDist  * Math.sin(theta11) + intersect.y;
            this.pointAdjusters[7].active = true;  // Inner should be colinear with outer at intersection edges
            this.pointAdjusters[7].x = this.points[1].x;
            this.pointAdjusters[7].y = this.points[1].y;
            this.pointAdjusters[11].active = true;
            this.pointAdjusters[11].x = (2 * d2 - innerOuterDist) * Math.cos(theta11) + intersect.x;
            this.pointAdjusters[11].y = -(2 * d2 - innerOuterDist) * Math.sin(theta11) + intersect.y;
            this.pointAdjusters[5].active = true;
            this.pointAdjusters[5].x = (2 * d2) * Math.cos(theta11) + intersect.x;
            this.pointAdjusters[5].y = -(2 * d2) * Math.sin(theta11) + intersect.y;
        } else if (equalPoints(this.points[0],snapWall[0])){
            var theta1 = Math.atan2((snapWall[1].y-snapWall[0].y),(snapWall[0].x-snapWall[1].x)); // Angle (coordinate space) for snap wall
            var theta2 = Math.atan2((this.points[1].y-this.points[0].y),(this.points[0].x-this.points[1].x)); // Angle (coordinate space) for current wall
            if(anglesCollinear(theta1,theta2)){return false;} // If walls are colinear, no adjustments are needed
            var theta5 = Math.PI + theta2 - theta1; // Angle (coordinate space) between outer opening between two walls
            var w1 = this.outerWidth/2; // Distance between current wall center point and outside point
            var w2 = getLength(snapWall[0],snapWall[2]); // Distance between snap wall center point and outside point
            var w3 = getLength(this.points[3].getPoint(),snapWall[2]); // Distance between two wall's outside points
            if(w1 <= w2){  // Equation method depends on which wall is wider (uses law of sines)
                var theta6 = Math.asin((w1/w3)*Math.sin(theta5));
                var theta7 = Math.PI - theta6 - theta5;
            } else {
                var theta7 = Math.asin((w2/w3)*Math.sin(theta5));
                var theta6 = Math.PI - theta7 - theta5;            
            }
            var theta9 = Math.PI/2 - theta6; // Angle (triangle space) between snap wall outer edge point and far intersect point
            var d1 = w3*Math.sin(theta9)/Math.sin(theta5); // Distance between current wall outer edge point and far intersect point
            var theta10 = Math.atan2(w1,d1); // Angle (right triangle measure) from outer intersection to inner intersection
            var d2 = Math.sqrt(Math.pow(d1,2)+Math.pow(w1,2)); // Distance from midpoint intersection to far point intersection
            var theta11 = theta2 - Math.PI + theta10; // Angle (map coord system) between outer intersection and inner intersection
            var innerOuterDist = 0.707106781; // Distance between inner and outer layers at intersections
            var intersect = {
                x: d1 * Math.cos(theta2) + this.points[3].x,
                y: -d1 * Math.sin(theta2) + this.points[3].y
            }
            this.pointAdjusters[3].active = true;
            this.pointAdjusters[3].x = intersect.x;
            this.pointAdjusters[3].y = intersect.y;            
            this.pointAdjusters[9].active = true;
            this.pointAdjusters[9].x = innerOuterDist * Math.cos(theta11) + intersect.x;
            this.pointAdjusters[9].y = -innerOuterDist  * Math.sin(theta11) + intersect.y;
            this.pointAdjusters[6].active = true;  // Inner should be colinear with outer at intersection edges
            this.pointAdjusters[6].x = this.points[0].x;
            this.pointAdjusters[6].y = this.points[0].y;
            this.pointAdjusters[8].active = true;
            this.pointAdjusters[8].x = (2 * d2 - innerOuterDist) * Math.cos(theta11) + intersect.x;
            this.pointAdjusters[8].y = -(2 * d2 - innerOuterDist) * Math.sin(theta11) + intersect.y;
            this.pointAdjusters[2].active = true;
            this.pointAdjusters[2].x = (2 * d2) * Math.cos(theta11) + intersect.x;
            this.pointAdjusters[2].y = -(2 * d2) * Math.sin(theta11) + intersect.y;             
        }
    }

    Wall.prototype.finalizeDrag = function(){
        this.update(); 
        this.sendPackages();
    }

    Wall.prototype.move = function(direction,subcategory,id){ // Moves the wall by an x and y distance
        var map = this.map;
        if(subcategory == undefined){
            var x = 0;
            var y = 0;
            switch(direction){
                case "up":
                y = -map.snapGridResolution;
                break;
                case "down":
                y = map.snapGridResolution;
                break;
                case "right":
                x = map.snapGridResolution;
                break;
                case "left":
                x = -map.snapGridResolution;
                break;
            }
            this.undoPackage = this.createPackage();
            this.points[0].shiftPosition(x,y);
            this.points[1].shiftPosition(x,y);
            this.update();
            this.sendPackages();            
        } else if (subcategory == "Door"){
            this.doors[id].keyCommand(direction);
        } else if (subcategory == "Window"){
            this.windows[id].keyCommand(direction);
        }
    }

// ##########################################  Object SVG Functions  ##################################################################

    Wall.prototype.createSVG = function(){  // Creates the svg elements for the wall layers.  This is a path, not a polygon
        var outerWallLayer = document.createElementNS('http://www.w3.org/2000/svg', 'path');
        outerWallLayer.setAttribute('d',this.createPath("outer"));
        outerWallLayer.setAttribute('id',"o"+this.id);
        outerWallLayer.setAttribute('class',"architect wall");
        outerWallLayer.setAttribute('style',"fill:"+this.outerColor);
        $('#outerWall').append(outerWallLayer);
        this.outer = $("#o"+this.id);

        var innerWallLayer = document.createElementNS('http://www.w3.org/2000/svg', 'path');
        innerWallLayer.setAttribute('d',this.createPath("inner"));
        innerWallLayer.setAttribute('id',"i"+this.id);
        innerWallLayer.setAttribute('class',"architect wall");
        innerWallLayer.setAttribute('style',"fill:"+this.innerColor);
        $('#innerWall').append(innerWallLayer);
        this.inner = $("#i"+this.id);

        var centerWallPath = document.createElementNS('http://www.w3.org/2000/svg', 'path');
        centerWallPath.setAttribute('d',this.createPath("center"));
        centerWallPath.setAttribute('id',"c"+this.id);
        centerWallPath.setAttribute('pointer-events',"none");
        centerWallPath.setAttribute('visibility',"hidden");
        centerWallPath.setAttribute('class',"architect wall");
        $('#innerWall').append(centerWallPath);
        this.center = $("#c"+this.id);
    }

    Wall.prototype.createPath = function(type){
        path = "";
        if(type == "outer"){
            path += "M " + this.points[0].x + " " + this.points[0].y; // Starting point for Wall (Outer Center Start)
            
            if(this.pointAdjusters[2].active){
                path += " L " + this.pointAdjusters[2].x + " " + this.pointAdjusters[2].y; // (Outer Left Corner Start)
            } else{
                path += " L " + this.points[2].x + " " + this.points[2].y; // (Outer Left Corner Start)
            } 
            
            if(this.pointAdjusters[4].active){
                path += " L " + this.pointAdjusters[4].x + " " + this.pointAdjusters[4].y; // (Outer Left Corner End)
            } else {
                path += " L " + this.points[4].x + " " + this.points[4].y; // (Outer Left Corner End)
            }
            
            path += " L " + this.points[1].x + " " + this.points[1].y; // Ending point for Wall (Outer Center End)
            
            if(this.pointAdjusters[5].active){
                path += " L " + this.pointAdjusters[5].x + " " + this.pointAdjusters[5].y; // (Outer Right Corner End)
            } else{
                path += " L " + this.points[5].x + " " + this.points[5].y; /// (Outer Right Corner End)
            } 
            
            if(this.pointAdjusters[3].active){
                path += " L " + this.pointAdjusters[3].x + " " + this.pointAdjusters[3].y; // (Outer Right Corner Start)
            } else{
                path += " L " + this.points[3].x + " " + this.points[3].y; // (Outer Right Corner Start)
            }            

        } else if (type == "inner") {
            
            if(this.pointAdjusters[6].active){
                path += " M " + this.pointAdjusters[6].x + " " + this.pointAdjusters[6].y; // (Inner Center Start)
            } else{
                path += " M " + this.points[6].x + " " + this.points[6].y; //(Inner Center Start)
            } 

            if(this.pointAdjusters[8].active){
                path += " L " + this.pointAdjusters[8].x + " " + this.pointAdjusters[8].y; // (Inner Left Corner Start)
            } else{
                path += " L " + this.points[8].x + " " + this.points[8].y; // (Inner Left Corner Start)
            } 

            if(this.pointAdjusters[10].active){
                path += " L " + this.pointAdjusters[10].x + " " + this.pointAdjusters[10].y; // (Inner Left Corner End)
            } else {
                path += " L " + this.points[10].x + " " + this.points[10].y; // (Inner Left Corner End)
            }

            if(this.pointAdjusters[7].active){
                path += " L " + this.pointAdjusters[7].x + " " + this.pointAdjusters[7].y; // (Inner Center End)
            } else{
                path += " L " + this.points[7].x + " " + this.points[7].y; // (Inner Center End)
            } 

            if(this.pointAdjusters[11].active){
                path += " L " + this.pointAdjusters[11].x + " " + this.pointAdjusters[11].y; // (Inner Right Corner End)
            } else{
                path += " L " + this.points[11].x + " " + this.points[11].y; // (Inner Right Corner End)
            } 

            if(this.pointAdjusters[9].active){
                path += " L " + this.pointAdjusters[9].x + " " + this.pointAdjusters[9].y; // (Inner Right Corner Start)
            } else {
                path += " L " + this.points[9].x + " " + this.points[9].y; // (Inner Right Corner Start)
            }
            
        } else if (type == "center") {
            path += "M " + this.points[0].x + " " + this.points[0].y; // Starting point
            path += " L " + this.points[1].x + " " + this.points[1].y; // Ending point   
            return path;       
        }
        path += " Z "; // Close the path
        return path;
    }

    Wall.prototype.setWallPoints = function(points){
        this.wallPoints = points;
    }

    Wall.prototype.draw = function(){  // Handler for the mouse drag to draw a wall from a mouse click while in draw-wall state 
        this.labelStyle = this.drawStyle;
        var map = this.map;
        var pos = map.pointerCoords(); // Creates a variable with the current mouse position
        this.points[1].updatePosition(map.snapRound(pos.x),map.snapRound(pos.y));  // Updates the endpoint to the current mouse position
        
        // The following section enables the snap-to-wall functionality during the draw process
        this.calculatePoints();
        var thisWall = [
            this.points[4].getPoint(),
            this.points[5].getPoint()
            ];
        var intersectList = [];
        for(var i in this.wallPoints){
            var check = polyInside(thisWall,this.wallPoints[i].slice(6));
            if(check[0]){
                intersectList.push([i,check[1]]);
                break;
            }
        }
        if(intersectList.length>0){
            var newCoords = this.getSnapPoint(
                this.wallPoints[intersectList[0][0]], // snapwall
                this.points[1].getPoint(),
                this.points[0].getPoint()
                );
            this.points[1].updatePosition(newCoords.x,newCoords.y);
        }

        this.update();
    }
    
    Wall.prototype.finalizeDraw = function(){ // Finalizes the wall draw creation process
        this.labelStyle = this.defaultStyle;
        this.update();
    }

    Wall.prototype.cancelDraw = function(){ // If the user cancels the wall draw process, this removes the temporary walls on the map
        //the object is deleted in the architect class
        this.remove();
    }

    Wall.prototype.checkValid = function(){ // Returns true if this was a validly drawn object
        this.calculateLength();
        return this.length > 0;
    }

    Wall.prototype.updateSVG = function(){
        this.outer.attr("d",this.createPath("outer"));
        this.inner.attr("d",this.createPath("inner"));
        this.center.attr("d",this.createPath("center"));        
    }

    Wall.prototype.updateSVGLite = function(){
        this.outer.attr("d",this.createPath("outer"));
        this.inner.attr("d",this.createPath("inner"));      
    }   

    Wall.prototype.removeSVG = function(){
        this.outer.remove(); // Outer layer
        this.inner.remove(); // Inner layer
        this.center.remove(); // Center path
        this.removeAttachedSVG(); // Removes door and window SVG
    }

    Wall.prototype.removeAttachedSVG = function(){  // Removes all screen elements of the wall, but maintains all object data, enables recreation or saving
        for(var door in this.doors){
            this.doors[door].deactivate();
            this.doors[door].remove();
        }
        for(var windowObj in this.windows){
            this.windows[windowObj].deactivate();
            this.windows[windowObj].remove();
        }
    }

// ##########################################  Object Calculation Functions  ############################################################

    Wall.prototype.calculatePoints = function(){
        this.points[2].updatePosition(
            this.points[0].x + (this.outerWidth/2) * Math.cos(this.angle + Math.PI/2),
            this.points[0].y - (this.outerWidth/2) * Math.sin(this.angle + Math.PI/2)
            );
        this.points[3].updatePosition(
            this.points[0].x + (this.outerWidth/2) * Math.cos(this.angle - Math.PI/2),
            this.points[0].y - (this.outerWidth/2) * Math.sin(this.angle - Math.PI/2)
            );
        this.points[4].updatePosition(
            this.points[1].x + (this.outerWidth/2) * Math.cos(this.angle + Math.PI/2),
            this.points[1].y - (this.outerWidth/2) * Math.sin(this.angle + Math.PI/2)
            );
        this.points[5].updatePosition(
            this.points[1].x + (this.outerWidth/2) * Math.cos(this.angle - Math.PI/2),
            this.points[1].y - (this.outerWidth/2) * Math.sin(this.angle - Math.PI/2)
            );
        this.points[6].updatePosition( // Inner start point
            this.points[0].x + (.5) * Math.cos(this.angle),
            this.points[0].y - (.5) * Math.sin(this.angle)
            )
        this.points[7].updatePosition( // Inner end point
            this.points[0].x + (this.length - .5) * Math.cos(this.angle),
            this.points[0].y - (this.length - .5) * Math.sin(this.angle)
            )
        this.points[8].updatePosition(
            this.points[6].x + (this.innerWidth/2) * Math.cos(this.angle + Math.PI/2),
            this.points[6].y - (this.innerWidth/2) * Math.sin(this.angle + Math.PI/2)
            );
        this.points[9].updatePosition(
            this.points[6].x + (this.innerWidth/2) * Math.cos(this.angle - Math.PI/2),
            this.points[6].y - (this.innerWidth/2) * Math.sin(this.angle - Math.PI/2)
            );
        this.points[10].updatePosition(
            this.points[7].x + (this.innerWidth/2) * Math.cos(this.angle + Math.PI/2),
            this.points[7].y - (this.innerWidth/2) * Math.sin(this.angle + Math.PI/2)
            );
        this.points[11].updatePosition(
            this.points[7].x + (this.innerWidth/2) * Math.cos(this.angle - Math.PI/2),
            this.points[7].y - (this.innerWidth/2) * Math.sin(this.angle - Math.PI/2)
            );              
    }

    Wall.prototype.calculateAngle = function(){  // Calculates the angle of the wall relative to the x-axis, used in various calculations
        this.angle = Math.atan2((this.points[0].y-this.points[1].y),(this.points[1].x-this.points[0].x));
        return this.angle;
    }

    Wall.prototype.calculateLength = function(){  // Calculates the length of the wall in inches and updates the length label to reflect the new value
        this.length = Math.sqrt(Math.pow(this.points[0].x-this.points[1].x,2) + Math.pow(this.points[0].y-this.points[1].y,2));
        if(this.lengthLabel instanceof WallTextLabel){
           this.lengthLabel.setText(this.renderLength(this.length),this); 
        }
    }

    Wall.prototype.isInverted = function(){  // Returns whether the walls start point is further on the x-axis than it's end point
        // useful when working with the distance label since it triggers the label flipping directions
        // otherwise, the label would appear upside down
        return this.points[0].x > this.points[1].x;
    }

// ##########################################  Door Functions  ##################################################################

    Wall.prototype.addDoor = function(){  // Creates a new door object and draws its svg on the wall, also begins the drag place door process
        this.doorID = "e"+this.incrementDoor()+this.id;
        this.doors[this.doorID] = new Door(this.doorID,36,48,"#FFFFFF",this.state,this.map,this);
        this.doors[this.doorID].create(this);
        Maptician.Editor.currentFile.objectSelector.selectSVG(this.doorID,'architect',"Door");
        this.removeLabels();
        this.state.setState("placeDoor"); // Setting the state to "placeDoor" makes the door follow the mouse until the user clicks to set the location
    }
    Wall.prototype.duplicateDoor = function(doorID){
        var id = "e"+this.incrementDoor()+this.id;
        this.doors[id] = new Door(id,36,48,"#FFFFFF",this.state,this.map,this);
        this.doors[id].duplicate(this.doors[doorID]);
    }
    Wall.prototype.incrementDoor = function(){ // Increments the door counter on the wall and returns a door # for use in the doorID
        // note that the door counter doesn't necessarily state the number of doors, but rather how many doors have been created
        // A deleted door will still take up a door space
        this.doorCounter++;
        return ("00" + this.doorCounter).slice(-2);
    }
    Wall.prototype.dragPlaceDoor = function(){ // Called on mouse-move when state is "placeDoor", moves the door being placed based on mouse position
        this.doors[this.doorID].drag(); 
    }
    Wall.prototype.finalizePlaceDoor = function(state){  // Called on mouse-left-click when state is "placeDoor", bascially just deactivates the door once in place
        // has the effect of locking the new door in place
        this.doors[this.doorID].setLabelStyle(2);
        this.doors[this.doorID].deactivate();
        this.state.addUndoPackage(this.createUndoCreatePackage(this.doorID,"door"));
        this.state.addRedoPackage(this.createRedoCreatePackage(this.doorID,"door")); 
        delete this.doorID;
    }
    Wall.prototype.cancelPlaceDoor = function(){  // Removes thew door being placed if the user presses escape
        this.doors[this.doorID].remove();
        delete this.doors[this.doorID];
        delete this.doorID;
    }
    Wall.prototype.updateDoors = function(){  // Updates all child doors with the current wall start and endpoints
        for (var i in this.doors){
            this.doors[i].update(this);
        }
    }
    Wall.prototype.removeDoor = function(doorID){ // Removes a door with a specified ID
        this.doors[doorID].deactivate(this);
        this.state.addUndoPackage(this.createUndoDeletePackage(doorID,"door"));
        this.state.addRedoPackage(this.createRedoDeletePackage(doorID,"door"));
        this.doors[doorID].remove();
        delete this.doors[doorID];
    }

    Wall.prototype.deactivateDoor = function(doorID){ // Deactivates a specified door
        var thisDoorID = "e"+doorID.slice(1);
        this.doors[thisDoorID].deactivate(this);
    }

    Wall.prototype.finalizeDragDoor = function(doorID){
        this.doors[doorID].finalizeDrag();
    }

// ##########################################  Window Functions  ##################################################################

    Wall.prototype.addWindow = function(){ // Creates a new window object and draws its svg on the wall, also begins the drag place window process
        this.windowID = "w"+this.incrementWindow()+this.id;
        this.windows[this.windowID] = new WindowClass(this.windowID,36,36,"#ffffff",this.outerWidth,this.state,this.map,this);
        this.windows[this.windowID].create();
        Maptician.Editor.currentFile.objectSelector.selectSVG(this.windowID,'architect',"Window");
        this.removeLabels();
        this.state.setState("placeWindow");
    }
    Wall.prototype.duplicateWindow = function(winID){
        var id = "w"+this.incrementWindow()+this.id;
        this.windows[id] = new WindowClass(id,36,26,"#ffffff",this.outerWidth,this.state,this.map,this);
        this.windows[id].duplicate(this.windows[winID]);
    }
    Wall.prototype.incrementWindow = function(){ // Increments the window counter on the wall and returns a window # for use in the windowID
        // note that the window counter doesn't necessarily state the number of windows, but rather how many windows have been created
        // A deleted window will still take up a window space
        this.windowCounter++;
        return ("00" + this.windowCounter).slice(-2);
    }
    Wall.prototype.dragPlaceWindow = function(){ // Called on mouse-move when state is "placeWindow", moves the window being placed based on mouse position
        
        this.windows[this.windowID].drag(); 
    }
    Wall.prototype.finalizePlaceWindow = function(){  // Called on mouse-left-click when state is "placeWindow", bascially just deactivates the window once in place
        // has the effect of locking the new window in place
        this.windows[this.windowID].setLabelStyle(2);
        this.windows[this.windowID].deactivate();
        this.state.addUndoPackage(this.createUndoCreatePackage(this.windowID,"window"));
        this.state.addRedoPackage(this.createRedoCreatePackage(this.windowID,"window"));
        delete this.windowID;
    }
    Wall.prototype.cancelPlaceWindow = function(){ // Removes thew window being placed if the user presses escape
        this.windows[this.windowID].remove();
        delete this.windows[this.windowID];
        delete this.windowID;
    }
    Wall.prototype.updateWindows = function(){  // Updates all child windows based on the current position of the wall
        for (var i in this.windows){
            this.windows[i].update();
        }
    }
    Wall.prototype.removeWindows = function(){ // Removes all windows on the wall
        for(var windowObject in this.windows){
            this.windows[windowObject].remove();
            delete this.windows[windowObject];
        }
    }
    Wall.prototype.removeWindow = function(windowID){ // Removes a window with a specified ID
        this.windows[windowID].remove();
        delete this.windows[windowID];
    }

    Wall.prototype.deactivateWindow = function(windowID){ // Deactivates a specified window
        
        this.windows[windowID].deactivate();
    }

    Wall.prototype.finalizeDragWindow = function(windowID){
        this.windows[windowID].finalizeDrag();
    }

// ##########################################  Label Functions  ##################################################################

    Wall.prototype.setLabelStyle = function(styleNumber){ // Changes the display behavior of the distance labels based on a style number from a slider
        if(styleNumber != undefined){
            this.labelStyle = styleNumber;
        }
        switch(this.labelStyle){
            case 0: // Never show labels
                this.removeLabels();
            break;
            case 1: // Only show labels when selected
                if(this.isSelected == true){
                    this.lengthLabel.redraw(this,this.renderLength(this.length));
                } else {
                   this.removeLabels(); 
                }
            break;
            case 2: // Always show labels (default)
                this.lengthLabel.redraw(this,this.renderLength(this.length));
            break;
        }
        return this.labelStyle;
    }

    Wall.prototype.addLabels = function(){ // Creates a length label object and adds it to the wall 
        if(!(this.lengthLabel instanceof WallTextLabel)){ // Check to ensure that a label doesn't already exist
            var id = generateUUID();
            this.lengthLabel = new WallTextLabel(id,"black",this.fontSize,"c"+this.id,"50%",-6);
            this.lengthLabel.draw();
            this.lengthLabel.setText(this.renderLength(this.length),this);
        }
    }

    Wall.prototype.removeLabels = function(){  // Removes the length label from the wall
        if(this.lengthLabel != undefined){
            this.lengthLabel.remove();
        }
    }

// ##########################################  Selector Interface Functions  ######################################################################

    Wall.prototype.setProperty = function(property,value,subcategory,id){
        if(subcategory == "Door"){
            this.doors[id].setProperty(property,value);
            return;
        } else if (subcategory == "Window"){
            this.windows[id].setProperty(property,value);
            return;
        }
        switch(property){
            case "objectLength":
                this.setobjectLength(value);
            break;
            case "objectWidth":
                this.setobjectWidth(value);
            break;
            case "objectStartX":
                this.setPointValue(0,"x",value);
            break;
            case "objectStartY":
                this.setPointValue(0,"y",value);
            break;
            case "objectEndX":
                this.setPointValue(1,"x",value);
            break;
            case "objectEndY":
                this.setPointValue(1,"y",value);
            break;
            case "objectAngle":
                this.setobjectAngle(toRads(value));
            break;
            case "objectStrokeColor":
                this.setobjectStrokeColor(value);
            break;
            case "objectFillColor":
                this.setobjectFillColor(value);
            break;
            case "objectLabelStyle":
                this.setLabelStyle(value);
            break;
            case "objectLabelColor":
                this.lengthLabel.setColor(value);
            break;
            case "objectLabelSize":
                this.fontSize = value;
                this.lengthLabel.setFontSize(value);
            break;
            case "objectDoorToggle":
                this.setDoorVisibility(value);
            break;
        }
    }

    Wall.prototype.getObjectData = function(subcategory,id){  // This function is called when the user selects a wall object
        if(subcategory == "Door"){
            return this.doors[id].getObjectData();
        } else if(subcategory == "Window"){
            return this.windows[id].getObjectData();
        }
        var thisData = {};
        thisData.data = {
            objectType: {type:"label",value:"Wall"},
            objectLength: {type:"spinner",value:this.renderLength(this.length)},
            objectWidth: {type:"spinner",value:this.renderLength(this.outerWidth)},
            objectStartX: {type:"text",value:this.renderLength(this.points[0].x)},
            objectStartY: {type:"text",value:this.renderLength(this.points[0].y)},
            objectEndX: {type:"text",value:this.renderLength(this.points[1].x)},
            objectEndY: {type:"text",value:this.renderLength(this.points[1].y)}, 
            objectAngle: {type:"spinner",value:toDeg(this.angle)},
            objectStrokeColor: {type:"color",value:this.outerColor},
            objectFillColor: {type:"color",value:this.innerColor},
            objectLabelStyleText: {type:"na",value:Wall.prototype.slide(null,{value:this.labelStyle})},
            objectLabelStyle: {type:"slider",value:this.labelStyle,min:0,max:2,slide:Wall.prototype.slide},
            objectLabelColor: {type:"na",value:null},
            objectLabelSize: {type:"spinner",value:this.lengthLabel.fontSize},
            objectDoorCount: {type:"label",value:Object.keys(this.doors).length},
            objectDoorToggle: {type:"switch",value:this.doorOpen},
            objectDoorArcToggle: {type:"switch",value:true},
            objectWindowCount: {type:"label",value:Object.keys(this.windows).length}
        }
        thisData.dividers = {
            sizeDivider:true,
            positionDivider:true,
            colorDivider:true,
            labelsDivider:true,
            doorsDivider:true,
            windowsDivider:true
        }
        return thisData;
    }

    Wall.prototype.getObjectViewerData = function(subcategory,id){
        if(subcategory == "Door"){
            return this.doors[id].getObjectData();
        } else if(subcategory == "Window"){
            return this.windows[id].getObjectData();
        }
        var thisData = {};
        thisData.data = {
            vObjectType: {type:"label",value:"Wall"},
            vObjectLengthText: {type:"label",value:this.renderLength(this.length)},
            vObjectWidthText: {type:"label",value:this.renderLength(this.outerWidth)},
            vObjectLabelStyleText: {type:"na",value:Wall.prototype.slide(null,{value:this.labelStyle})},
            vObjectLabelStyle: {type:"slider",value:this.labelStyle,min:0,max:2,slide:Wall.prototype.slide},
            vObjectLabelType: {type:"switch",value:true},
            vObjectLabelColor: {type:"na",value:null},
            vObjectLabelSize: {type:"spinner",value:this.lengthLabel.fontSize},
        }
        thisData.dividers = {
            vSizeDivider:true,
            vLabelsDivider:true
        }
        return thisData;        
    }

    Wall.prototype.slide = function(event,ui){
            var message = "";
            switch(ui.value){
                case 0:
                message = "No Labels"
                break;
                case 1:
                message = "Show Width Label on Select"
                break;
                case 2:
                message = "Always Show Width Label"
                break;
            }
            $( "#objectLabelStyleText" ).html(message);
    }

    Wall.prototype.setobjectLength = function(length){
        // All child doors and windows will keep their current distances from the start point
        this.length = length;
        this.points[1].updatePosition(
            this.points[0].x + this.length * Math.cos(this.angle),
            this.points[0].y - this.length * Math.sin(this.angle)
            );
        this.update();
    }
    Wall.prototype.setobjectWidth = function(width){  // Changes the wall's width (thickness) along with its child doors and windows
        // Should be constrained to 1-12 inches
        this.outerWidth = width;
        this.innerWidth = width-1;
        this.update();
        for (var i in this.doors){
            this.doors[i].setobjectWidth();
        }
        for (var i in this.windows){
            this.windows[i].setobjectWidth();
        }
    }
    Wall.prototype.setPointValue = function(pointNo,dim,value){
        // All child doors and windows will keep their current distances from the start point
        if(dim == "x"){
            this.points[pointNo].updatePosition(1*value,this.points[pointNo].y); 
       } else {
            this.points[pointNo].updatePosition(this.points[pointNo].x,1*value); 
       }
        this.update();
    }
    Wall.prototype.setobjectAngle = function(angle){
        this.points[1].updatePosition(
            this.points[0].x + this.length * Math.cos(angle),
            this.points[0].y - this.length * Math.sin(angle)
            );
        this.update();
    }
    Wall.prototype.setobjectStrokeColor = function(color){  // Changes the color of the wall's outerLayer, effecting a change in the stroke color
        var isOk  = /(^#[0-9A-F]{6}$)|(^#[0-9A-F]{3}$)/i.test(color)
        if(isOk){
            this.outerColor = color;
        } else {
            message.errorMessage("Color not recognized");
        }
        this.outer.css("fill",this.outerColor);
    }
    Wall.prototype.setobjectFillColor = function(color){ // Changes the color of the wall's innerLayer, effecting a change in the fill color
        var isOk  = /(^#[0-9A-F]{6}$)|(^#[0-9A-F]{3}$)/i.test(color)
        if(isOk){
            this.innerColor = color;
        } else {
            message.errorMessage("Color not recognized");
        }
        this.inner.css("fill",this.innerColor);
    }
    Wall.prototype.setDoorVisibility = function(value){
        this.doorOpen = value;
        for(var i in this.doors){
            this.doors[i].setOpenDoor(this.doorOpen,this);
        }
        console.log(this.doorOpen)
    }