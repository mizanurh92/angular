function Sink(id,state,map){
    MapObject.call(this,"Sink",id); // Sets subclass of MapObject
    this.state = state; // Reference to the State Controller
    this.map = map; // Reference to the Map Controller

    this.type = "Sink"; // Can be removed - lives on superclass - just here for reminder
    this.id = id; // Can be removed - lives on superclass - just here for reminder
    this.handleDragging = ""; // Can be removed - lives on superclass - just here for reminder
    this.isSelected = false;   // Can be removed - lives on superclass - just here for reminder
    this.fill = "#D3D3D3";  // Fill Color
    this.sinkFill = "#A9A9A9";
    this.drainFill = "#808080";
    this.faucetFill = "#D3D3D3";
    this.stroke = "#000000";  // Stroke Color
    this.selectedColor = "#ff0000";
    this.lineWidth = .25;  // Width of the line stroke
    this.length = 0;  // Length of the object (initially side dimension)
    this.width = 0; // Width of the object (initially top dimension)
    this.points = []; // Array containing the points making up the column
        // Initial positions
        // 0 - Upper left point
        // 1 - Upper right point
        // 2 - Lower right point
        // 3 - Lower left point
        // 4 - Top Edge Point
        // 5 - Right Edge Point
        // 6 - Bottom Edge Point
        // 7 - Left Edge Point
        // 8 - Rotation handle point

    // The following are aliases to the various sink svg elements.  This prevents having to do a lookup for each change
    this.outerSink = null;
    this.innerSink = null;
    this.outerDrain = null;
    this.innerDrain = null;
    this.faucetNozzle = null;
    this.faucetCircle = null;

    this.initialDims = {};  // Holds the initial dimensions of the object during a resize event
    this.defaultSize = {width:24,height:24};
    this.angle = 0;  // Angle in radians of the object with respect to the x-axis
    this.centerPoint = {}; // Calculated and used for rotation
    this.dragAngle = 0; // Used for rotation, gives the starting angle of a rotation event
    this.minimumDimension = 12; // Used to set a minimum length or width of the object
    this.widthMargin = 2;
    this.topMargin = 4;
    this.sinkRounding = 4;
    this.packageParameters = [ // Used in undo/redo/duplicate/save/load methods
            "type",
            "id",
            "fill",
            "sinkFill",
            "drainFill",
            "faucetFill",
            "stroke",
            "lineWidth",
            "minimumDimension",
            "widthMargin",
            "topMargin",
            "sinkRounding"
        ];
}
    Sink.prototype = Object.create(MapObject.prototype); // Links the prototype to the superclass
    Sink.prototype.constructor = Sink;

// ##########################################  Standard Object Interface Functions  ##################################################################

    Sink.prototype.create = function(){ // This creates all components of the object
        var pos = this.map.pointerCoords();
        this.points[0] = new point(pos.x,pos.y,"ARCP00"+this.id); // Upper Left
        this.points[1] = new point(pos.x+this.defaultSize.width,pos.y,"ARCP01"+this.id); // Upper Right
        this.points[2] = new point(pos.x+this.defaultSize.width,pos.y+this.defaultSize.height,"ARCP02"+this.id); // Lower Right
        this.points[3] = new point(pos.x,pos.y+this.defaultSize.height,"ARCP03"+this.id); // Lower Left
        this.points[4] = new point((this.points[0].x+this.points[1].x)/2,(this.points[0].y+this.points[1].y)/2,"ARCP04"+this.id); // Top Edge
        this.points[5] = new point((this.points[1].x+this.points[2].x)/2,(this.points[1].y+this.points[2].y)/2,"ARCP05"+this.id); // Right Edge
        this.points[6] = new point((this.points[2].x+this.points[3].x)/2,(this.points[2].y+this.points[3].y)/2,"ARCP06"+this.id); // Bottom Edge
        this.points[7] = new point((this.points[3].x+this.points[0].x)/2,(this.points[3].y+this.points[0].y)/2,"ARCP07"+this.id); // Left Edge
        this.createSVG();
    }

    Sink.prototype.update = function(){
        this.calculateAngle();
        this.calculateLength();
        this.calculateWidth();
        this.updateSVG(); // updates side points in the method
        this.updateRotatePoint();
    }

    Sink.prototype.remove = function(){
        this.removeHandles();
        this.removeSVG();
    }

    Sink.prototype.redraw = function(){  // Redraws all svg screen objects (if otherwise visible) after they have been removed
        
        this.createSVG();
    }

    Sink.prototype.activate = function(multiselect){
        this.outerSink.css("stroke","red");
        this.isSelected = true;
        if(!multiselect){
            this.drawHandles();
        }
    }

    Sink.prototype.deactivate = function(){
        this.outerSink.css("stroke",this.fill);
        this.isSelected = false;
        this.removeHandles();
    }

    Sink.prototype.getOutlinePoints = function(){ // Returns points for a bounding box for the object
        var pointObject = [];
        for(var i = 0;i < 4;i++){ // Only looks out outer corner points
            pointObject.push(this.points[i].getPoint());
        }
        return pointObject;
    }

// ##########################################  Point Handle Functions  ########################################################

    Sink.prototype.handlePress = function(handleID){  // Receives a handle press event and saves the mouse location and handle ID for drag process
        for(var i = 0;i < this.points.length;i++){
            this.points[i].setDragReference();
        }
        this.getCenter();
        this.initialDims["widthMargin"] = this.width - this.minimumDimension;
        this.initialDims["lengthMargin"] = this.length - this.minimumDimension;
        this.handleDragging = handleID.slice(4,6)*1;
        if(this.handleDragging == 8){
            this.points[0].setRotateAngle(this.centerPoint.x,this.centerPoint.y,this.angle);
            this.points[1].setRotateAngle(this.centerPoint.x,this.centerPoint.y,this.angle);
            this.points[2].setRotateAngle(this.centerPoint.x,this.centerPoint.y,this.angle);
            this.points[3].setRotateAngle(this.centerPoint.x,this.centerPoint.y,this.angle);
        }
        this.undoPackage = this.createPackage();
    }

    Sink.prototype.handleDrag = function(){  // Receives a handle drag event and changes the point associated with the handle based on the new location
        rectHandleDrag(
            this.points,
            this.handleDragging,
            this.angle,
            this.minimumDimension,
            this.initialDims,
            this.centerPoint,
            this.width,
            this.length,
            this.map
        );
        this.update();
    }

    Sink.prototype.finalizeHandleDrag = function(){
        
        this.sendPackages();
    }

    Sink.prototype.drawHandles = function(){
        for(var i = 0;i < this.points.length;i++){
            this.points[i].drawHandle();
        }
    }

    Sink.prototype.removeHandles = function(){ // Removes the handles on the wall endpoints
        for(var i = 0;i < this.points.length;i++){
            this.points[i].removeHandle();
        }
    }

    Sink.prototype.createRotatePoint = function(){
        var distance = 18;
        var topCenterX = (this.points[0].x + this.points[1].x)/2;
        var topCenterY = (this.points[0].y + this.points[1].y)/2;
        this.points[8] = new point(topCenterX + distance * Math.cos(this.angle+Math.PI/2),topCenterY - distance * Math.sin(this.angle+Math.PI/2),"AREP08"+this.id);
    }
    
    Sink.prototype.updateRotatePoint = function(){
        if(this.points[8] != undefined){
            var distance = 18;
            this.points[8].updatePosition(this.points[4].x + distance * Math.cos(this.angle+Math.PI/2),this.points[4].y - distance * Math.sin(this.angle+Math.PI/2))
        }
    }

// ##########################################  Application Mechanics (Undo/Redo/Duplicate/Save/Load)  #############################################

    Sink.prototype.duplicate = function(original){
        for(var i = 0;i < original.points.length;i++){
            this.points.push(new point(original.points[i].x,original.points[i].y,original.points[i].id.substring(0,6)+this.id))
        }
        for(var i = 0;i < this.packageParameters.length;i++){
            if(this.packageParameters[i] != "id"){
                this[this.packageParameters[i]] = original[this.packageParameters[i]];
            }
        }
        this.createSVG();
        this.move(12,12);
    }

    Sink.prototype.createPackage = function(){
        var package = {points:[]};
        for(var i = 0;i < this.points.length;i++){
            package.points.push(this.points[i].getPoint());
        }
        for(var i = 0;i < this.packageParameters.length;i++){
            package[this.packageParameters[i]] = this[this.packageParameters[i]];
        }
        package.controller = "architect";
        package.packageType = "modify";
        return package;
    }

    Sink.prototype.loadPackage = function(package){
        // It doesn't matter if it is an undo or redo package, the impact is to reset the object to a former state
        for(var i = 0;i < this.points.length;i++){
            this.points[i].updatePosition(package.points[i].x,package.points[i].y);
        }
        for(var i = 0;i < this.packageParameters.length;i++){
            this[this.packageParameters[i]] = package[this.packageParameters[i]];
        }
        this.update();
    }

    Sink.prototype.sendPackages = function(){
        // It is important to know that the undo and redo packages aren't the same.  If they are, there was no real action taken and
        // an undo or redo event will have no apparent effect
        var undo = this.undoPackage;
        var redo = this.createPackage();
        var same = true; // Used to determine whether the two packages are the same (no actual event occured)
        for(var i = 0;i < redo.points.length;i++){ // Runs through the points first as the most common event changes
            if(undo.points[i].x != redo.points[i].x || undo.points[i].y != redo.points[i].y){
                same = false;
                break; // breaks as soon as a single difference is found
            }
        }       
        if(same){ // No need to start second loop if a difference was already found
            for(var i = 0;i < this.packageParameters.length;i++){
                if(undo[this.packageParameters[i]] != redo[this.packageParameters[i]]){
                    same = false;
                    break;
                }
            }
        }
        // Packages are sent essentially simultaneously to prevent having mismatched packages if the action isn't finalized
        if(same == false){
            this.state.addUndoPackage(undo);
            this.state.addRedoPackage(redo);
        }
    }

    Sink.prototype.save = function(){
        var saveFile = {points:[]}
        for(var i = 0;i < this.points.length;i++){
            saveFile.points.push(this.points[i].getSavePoint());
        }
        for(var i = 0;i < this.packageParameters.length;i++){
            saveFile[this.packageParameters[i]] = this[this.packageParameters[i]];
        }
        return saveFile
    }

    Sink.prototype.load = function(saveFile){
        // Note that this method assumes that the create function has not been called - will not work if it has been
        for(var i = 0;i < saveFile.points.length;i++){
            this.points.push(new point(saveFile.points[i].x,saveFile.points[i].y,saveFile.points[i].id));
        }
        for(var i = 0;i < this.packageParameters.length;i++){
            this[this.packageParameters[i]] = saveFile[this.packageParameters[i]];
        }
        this.createSVG();    
        this.update();
    }

// ##########################################  Drag and Move Functions  #############################################

    Sink.prototype.startDrag = function(){ // Saves the origin of a drag event for move calculations
        this.undoPackage = this.createPackage();
        for(var i = 0;i < this.points.length;i++){
            this.points[i].setDragReference();
        }
    }

    Sink.prototype.drag = function(){ // Drags the wall upon a left-button down on the wall layer svg and dragging the mouse
        var map = this.map;
        var coords = map.pointerCoords(); // gets the latest mouse location
        var xMove = coords.x-map.handle.x/map.scale + 4/map.scale;
        var yMove = coords.y-map.handle.y/map.scale;

        var distDragged = this.points[0].dragOffset(xMove,yMove,{gridResolution:map.snapGridResolution,snapToGrid:map.snapGridActive});
        this.points[1].dragOffset(distDragged.x,distDragged.y);
        this.points[2].dragOffset(distDragged.x,distDragged.y);
        this.points[3].dragOffset(distDragged.x,distDragged.y);
        this.update();
    }

    Sink.prototype.finalizeDrag = function(){
        
        this.sendPackages();
    }

    Sink.prototype.move = function(direction){ // Moves the wall by an x and y distance, called by the architecture controller as a result of a keyboard press
        var map = this.map;
        this.undoPackage = this.createPackage();
        var x = 0;
        var y = 0;
        switch(direction){
            case "up":
            y = -map.snapGridResolution;
            break;
            case "down":
            y = map.snapGridResolution;
            break;
            case "right":
            x = map.snapGridResolution;
            break;
            case "left":
            x = -map.snapGridResolution;
            break;
        }
        this.points[0].shiftPosition(x,y);
        this.points[1].shiftPosition(x,y);
        this.points[2].shiftPosition(x,y);
        this.points[3].shiftPosition(x,y);
        this.update();
        this.sendPackages();
    }

// ##########################################  Object SVG Functions  ##################################################################

    Sink.prototype.createSVG = function(){
        var outerSink = document.createElementNS('http://www.w3.org/2000/svg', 'path');
        outerSink.setAttribute('d',this.getOuterPath());
        outerSink.setAttribute('id',"a"+this.id);
        outerSink.setAttribute('class',"architect sink");
        outerSink.setAttribute('pointer-events',"all");
        outerSink.setAttribute('style',"stroke-linecap:square;stroke:"+this.stroke+";fill:"+this.fill+";stroke-width:"+this.lineWidth/4);
        $('#sinks').append(outerSink);
        this.outerSink = $("#a"+this.id);

        var innerSink = document.createElementNS('http://www.w3.org/2000/svg', 'path');
        innerSink.setAttribute('d',this.getInnerPath());
        innerSink.setAttribute('id',"b"+this.id);
        innerSink.setAttribute('class',"architect sink");
        innerSink.setAttribute('pointer-events',"all");
        innerSink.setAttribute('style',"stroke-linecap:square;stroke:"+this.stroke+";fill:"+this.sinkFill+";stroke-width:"+this.lineWidth/4);
        $('#sinks').append(innerSink);
        this.innerSink = $("#b"+this.id);

        var center = this.getCenter();
        var outerDrain = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
        outerDrain.setAttribute('id',"c"+this.id);
        outerDrain.setAttribute('class',"architect sink");
        outerDrain.setAttribute('cx',center.x);
        outerDrain.setAttribute('cy',center.y);
        outerDrain.setAttribute('r',2);
        outerDrain.setAttribute('pointer-events',"all");
        outerDrain.setAttribute('style',"stroke-linecap:square;stroke:"+this.stroke+";fill:"+this.faucetFill+";stroke-width:"+this.lineWidth/4);
        $('#sinks').append(outerDrain);
        this.outerDrain = $("#c"+this.id);

        var innerDrain = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
        innerDrain.setAttribute('id',"d"+this.id);
        innerDrain.setAttribute('class',"architect sink");
        innerDrain.setAttribute('cx',center.x);
        innerDrain.setAttribute('cy',center.y);
        innerDrain.setAttribute('r',1);
        innerDrain.setAttribute('pointer-events',"all");
        innerDrain.setAttribute('style',"stroke-linecap:square;stroke:"+this.stroke+";fill:"+this.drainFill+";stroke-width:0");
        $('#sinks').append(innerDrain);
        this.innerDrain = $("#d"+this.id);

        var faucetCirclePointX = (this.topMargin/2) * Math.cos(this.angle - Math.PI/2) + this.points[4].x;
        var faucetCirclePointY = -(this.topMargin/2) * Math.sin(this.angle - Math.PI/2) + this.points[4].y;

        var faucetNozzle = document.createElementNS('http://www.w3.org/2000/svg', 'path');
        faucetNozzle.setAttribute('d',this.getFaucetPath({x:faucetCirclePointX,y:faucetCirclePointY}));
        faucetNozzle.setAttribute('id',"e"+this.id);
        faucetNozzle.setAttribute('class',"architect sink");
        faucetNozzle.setAttribute('pointer-events',"all");
        faucetNozzle.setAttribute('style',"stroke-linecap:square;stroke:"+this.stroke+";fill:"+this.faucetFill+";stroke-width:"+this.lineWidth/4);
        $('#sinks').append(faucetNozzle);
        this.faucetNozzle = $("#e"+this.id);

        var faucetCircle = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
        faucetCircle.setAttribute('id',"f"+this.id);
        faucetCircle.setAttribute('class',"architect sink");
        faucetCircle.setAttribute('cx',faucetCirclePointX);
        faucetCircle.setAttribute('cy',faucetCirclePointY);
        faucetCircle.setAttribute('r',1.5);
        faucetCircle.setAttribute('pointer-events',"all");
        faucetCircle.setAttribute('style',"stroke-linecap:square;stroke:"+this.stroke+";fill:"+this.faucetFill+";stroke-width:"+this.lineWidth/4);
        $('#sinks').append(faucetCircle);
        this.faucetCircle = $("#f"+this.id);
    }

    Sink.prototype.getOuterPath = function(){
        var path = ""
        path += "M " + this.points[0].x + " " + this.points[0].y; // Start point at upper left
        path += "L " + this.points[1].x + " " + this.points[1].y;  // Point at the upper right
        path += "L " + this.points[2].x + " " + this.points[2].y;  // Point at the lower right
        path += "L " + this.points[3].x + " " + this.points[3].y;  // Point at the lower left
        path += "Z";  // Return and close of position
        return path;
    }

    Sink.prototype.getFaucetPath = function(center){
        var faucetWidth = 2;
        var faucetLength = 6;
        var pointULX = (faucetWidth/2) * Math.cos(this.angle - Math.PI) + center.x;
        var pointULY = -(faucetWidth/2) * Math.sin(this.angle - Math.PI) + center.y;
        
        var pointURX = (faucetWidth/2) * Math.cos(this.angle) + center.x;
        var pointURY = -(faucetWidth/2) * Math.sin(this.angle) + center.y;
        
        var pointLLX = (faucetLength) * Math.cos(this.angle - Math.PI/2) + pointULX;
        var pointLLY = -(faucetLength) * Math.sin(this.angle - Math.PI/2) + pointULY;
        var pointLRX = (faucetLength) * Math.cos(this.angle - Math.PI/2) + pointURX;
        var pointLRY = -(faucetLength) * Math.sin(this.angle - Math.PI/2) + pointURY;
        var path = ""
        path += "M " + pointULX + " " + pointULY; // Start point at upper left
        path += " L " + pointURX + " " + pointURY;  // Point at the upper right
        path += " L " + pointLRX + " " + pointLRY;  // Point at the lower right
        path += " L " + pointLLX + " " + pointLLY;  // Point at the lower left
        path += " Z";  // Return and close of position
        return path;
    }

    Sink.prototype.getInnerPath = function(){
        var dist = Math.sqrt(Math.pow(this.topMargin,2)+Math.pow(this.widthMargin,2));
        var innerAngle = -Math.atan2(this.topMargin,this.widthMargin);
        var rounded = 2;

        var upperLeftX = dist * Math.cos(this.angle + innerAngle) + this.points[0].x;
        var upperLeftY = -dist * Math.sin(this.angle + innerAngle) + this.points[0].y;
        var upperLeftX1 = rounded * Math.cos(this.angle) + upperLeftX;
        var upperLeftY1 = -rounded * Math.sin(this.angle) + upperLeftY;
        var upperLeftX2 = rounded * Math.cos(this.angle - Math.PI/2) + upperLeftX;
        var upperLeftY2 = -rounded * Math.sin(this.angle - Math.PI/2) + upperLeftY;

        var upperRightX = dist * Math.cos(this.angle - Math.PI - innerAngle) + this.points[1].x;
        var upperRightY = -dist * Math.sin(this.angle - Math.PI - innerAngle) + this.points[1].y;
        var upperRightX1 = rounded * Math.cos(this.angle + Math.PI) + upperRightX;
        var upperRightY1 = -rounded * Math.sin(this.angle + Math.PI) + upperRightY;
        var upperRightX2 = rounded * Math.cos(this.angle - Math.PI/2) + upperRightX;
        var upperRightY2 = -rounded * Math.sin(this.angle - Math.PI/2) + upperRightY;

        var lowerRightX = dist * Math.cos(this.angle + Math.PI + innerAngle) + this.points[2].x;
        var lowerRightY = -dist * Math.sin(this.angle + Math.PI + innerAngle) + this.points[2].y;
        var lowerRightX1 = rounded * Math.cos(this.angle + Math.PI/2) + lowerRightX;
        var lowerRightY1 = -rounded * Math.sin(this.angle + Math.PI/2) + lowerRightY;
        var lowerRightX2 = rounded * Math.cos(this.angle + Math.PI) + lowerRightX;
        var lowerRightY2 = -rounded * Math.sin(this.angle + Math.PI) + lowerRightY;

        var lowerLeftX = dist * Math.cos(this.angle - innerAngle) + this.points[3].x;
        var lowerLeftY = -dist * Math.sin(this.angle - innerAngle) + this.points[3].y;
        var lowerLeftX1 = rounded * Math.cos(this.angle) + lowerLeftX;
        var lowerLeftY1 = -rounded * Math.sin(this.angle) + lowerLeftY;
        var lowerLeftX2 = rounded * Math.cos(this.angle + Math.PI/2) + lowerLeftX;
        var lowerLeftY2 = -rounded * Math.sin(this.angle + Math.PI/2) + lowerLeftY;

        var path = ""
        path += "M " + upperLeftX2 + " " + upperLeftY2;
        path += "S " + upperLeftX + " " + upperLeftY; 
        path += " " + upperLeftX1 + " " + upperLeftY1;

        path += "L " + upperRightX1 + " " + upperRightY1;
        path += "S " + upperRightX + " " + upperRightY; 
        path += " " + upperRightX2 + " " + upperRightY2;

        path += "L " + lowerRightX1 + " " + lowerRightY1;
        path += "S " + lowerRightX + " " + lowerRightY; 
        path += " " + lowerRightX2 + " " + lowerRightY2;

        path += "L " + lowerLeftX1 + " " + lowerLeftY1;
        path += "S " + lowerLeftX + " " + lowerLeftY;
        path += " " + lowerLeftX2 + " " + lowerLeftY2; 
        path += "Z";
        return path;
    }

    Sink.prototype.draw = function(){ 
        var map = this.map;
        var pos = map.pointerCoords(); 
        this.points[1].updatePosition(map.snapRound(pos.x),this.points[1].y);
        this.points[2].updatePosition(map.snapRound(pos.x),map.snapRound(pos.y));
        this.points[3].updatePosition(this.points[3].x,map.snapRound(pos.y));
        this.update();
    }

    Sink.prototype.finalizeDraw = function(){  // To make the initial point numbers and corners consistent in all draw scenarios the
        // following checks to ensure that point zero is at the upper left and the points are numbered clockwise from there
        // If this isn't the case, this function flips the points on the necessary axis to make it the case
        if(this.points[0].y > this.points[3].y){
            var temp0 = this.points[0].getPoint();
            var temp1 = this.points[1].getPoint();
            var temp2 = this.points[2].getPoint();
            var temp3 = this.points[3].getPoint();
            this.points[0].updatePosition(temp3.x,temp3.y);
            this.points[1].updatePosition(temp2.x,temp2.y);
            this.points[2].updatePosition(temp1.x,temp1.y);
            this.points[3].updatePosition(temp0.x,temp0.y);
        }
        if(this.points[0].x > this.points[1].x){
            var temp0 = this.points[0].getPoint();
            var temp1 = this.points[1].getPoint();
            var temp2 = this.points[2].getPoint();
            var temp3 = this.points[3].getPoint();
            this.points[0].updatePosition(temp1.x,temp1.y);
            this.points[1].updatePosition(temp0.x,temp0.y);
            this.points[2].updatePosition(temp3.x,temp3.y);
            this.points[3].updatePosition(temp2.x,temp2.y);
        }
        this.calculateAngle();
        this.createRotatePoint();
        this.update();
    }

    Sink.prototype.cancelDraw = function(){
        
        this.remove();
    }

    Sink.prototype.dragPlace = function(){
        var pos = this.map.pointerCoords(); // gets the latest mouse location
        pos.x = this.map.snapRound(pos.x,undefined,true);
        pos.y = this.map.snapRound(pos.y,undefined,true);
        this.points[0].updatePosition(pos.x,pos.y);
        this.points[1].updatePosition(pos.x+this.defaultSize.width,pos.y);
        this.points[2].updatePosition(pos.x+this.defaultSize.width,pos.y+this.defaultSize.height);
        this.points[3].updatePosition(pos.x,pos.y+this.defaultSize.height);
        this.updateSVG();
    }

    Sink.prototype.finalizeDragPlace = function(){
        this.createRotatePoint();
        this.update();
    }

    Sink.prototype.updateSVG = function(){
        var center, faucetCenterX, faucetCenterY;
        this.outerSink.attr("d",this.getOuterPath());
        this.innerSink.attr("d",this.getInnerPath());
        center = this.getCenter();
        this.outerDrain.attr({cx:center.x,cy:center.y});
        this.innerDrain.attr({cx:center.x,cy:center.y});
        this.updateSidePoints(); // Needed because the next part uses the top side point (4)
        faucetCenterX = (this.topMargin/2) * Math.cos(this.angle - Math.PI/2) + this.points[4].x;
        faucetCenterY = -(this.topMargin/2) * Math.sin(this.angle - Math.PI/2) + this.points[4].y;
        this.faucetNozzle.attr("d",this.getFaucetPath({x:faucetCenterX,y:faucetCenterY}));
        this.faucetCircle.attr({cx:faucetCenterX,cy:faucetCenterY});
    }

    Sink.prototype.removeSVG = function(){
        this.outerSink ? this.outerSink.remove() : null;
        this.innerSink ? this.innerSink.remove() : null;
        this.outerDrain ? this.outerDrain.remove() : null;
        this.innerDrain ? this.innerDrain.remove() : null;
        this.faucetNozzle ? this.faucetNozzle.remove() : null;
        this.faucetCircle ? this.faucetCircle.remove() : null;
    }

    Sink.prototype.updateSidePoints = function(){
        this.points[4].updatePosition((this.points[0].x+this.points[1].x)/2,(this.points[0].y+this.points[1].y)/2); // Top Edge
        this.points[5].updatePosition((this.points[1].x+this.points[2].x)/2,(this.points[1].y+this.points[2].y)/2); // Right Edge
        this.points[6].updatePosition((this.points[2].x+this.points[3].x)/2,(this.points[2].y+this.points[3].y)/2); // Bottom Edge
        this.points[7].updatePosition((this.points[3].x+this.points[0].x)/2,(this.points[3].y+this.points[0].y)/2); // Left Edge
    }

// ##########################################  Object Calculation Functions  ############################################################

    Sink.prototype.calculateLength = function(){  // Side Edge
        var xComponent = this.points[0].x - this.points[3].x;
        var yComponent = this.points[0].y - this.points[3].y;
        this.length = Math.sqrt(Math.pow(xComponent,2)+Math.pow(yComponent,2));
        return this.length;
    }

    Sink.prototype.calculateWidth = function(){  // Top Edge
        var xComponent = this.points[0].x - this.points[1].x;
        var yComponent = this.points[0].y - this.points[1].y;
        this.width = Math.sqrt(Math.pow(xComponent,2)+Math.pow(yComponent,2));
        return this.width;
    }

    Sink.prototype.calculateAngle = function(){  
        
        this.angle = Math.atan2((this.points[0].y-this.points[1].y),(this.points[1].x-this.points[0].x));
    }

    Sink.prototype.getCenter = function(){
        this.centerPoint = {
            x:(this.points[0].x + this.points[2].x)/2 ,
            y:(this.points[0].y + this.points[2].y)/2
        }
        return this.centerPoint;
    }

// ##########################################  Selector Interface Functions  ############################################################

    Sink.prototype.setProperty = function(property,value){
        switch(property){
            case "objectLength":
                this.setobjectLength(value);
            break;
            case "objectWidth":
                this.setobjectWidth(value);
            break;
            case "objectAngle":
                this.setobjectAngle(toRads(value));
            break;
            case "objectStrokeColor":
                this.setobjectStrokeColor(value);
            break;
            case "objectFillColor":
                this.setobjectFillColor(value);
            break;
            case "objectAreaColor":
                this.setobjectAreaColor(value);
            break;
            case "objectLabelStyle":
                this.setLabelStyle(value);
            break;
            case "objectLabelColor":
                this.labelColor = value;
                this.lengthLabel.setColor(value);
                this.widthLabel.setColor(value);
            break;
            case "objectLabelSize":
                this.labelSize = value;
                this.lengthLabel.setFontSize(value);
                this.widthLabel.setFontSize(value);
            break;
        }
    }

    Sink.prototype.getObjectData = function(subcategory,id){  // This function is called when the user selects a wall object
        var thisData = {};
        thisData.data = {
            objectType: {type:"label",value:"Sink"},
            objectLength: {type:"spinner",value:this.renderLength(this.length)},
            objectWidth: {type:"spinner",value:this.renderLength(this.width)},
            objectAngle: {type:"spinner",value:toDeg(this.angle)},
            objectStrokeColor: {type:"color",value:this.stroke},
            objectFillColor: {type:"color",value:this.sinkFill},
            objectAreaColor: {type:"color",value:this.fill},
        }
        thisData.dividers = {
            sizeDivider:true,
            positionDivider:true,
            colorDivider:true
        }
        return thisData;
    }

    Sink.prototype.slide = function(event,ui){
            var message = "";
            switch(ui.value){
                case 0:
                message = "No Labels"
                break;
                case 1:
                message = "Show Labels on Select"
                break;
                case 2:
                message = "Always Show Labels"
                break;
            }
            $( "#objectLabelStyleText" ).html(message);
    }


    Sink.prototype.setobjectLength = function(value){
        var newX3 = value * Math.cos(this.angle - Math.PI/2) + this.points[0].x;
        var newY3 = -value * Math.sin(this.angle - Math.PI/2) + this.points[0].y;
        var newX2 = value * Math.cos(this.angle - Math.PI/2) + this.points[1].x;
        var newY2 = -value * Math.sin(this.angle - Math.PI/2) + this.points[1].y;
        this.points[2].updatePosition(newX2,newY2);
        this.points[3].updatePosition(newX3,newY3);
        this.update();
    }

    Sink.prototype.setobjectWidth = function(value){
        var newX1 = value * Math.cos(this.angle) + this.points[0].x;
        var newY1 = -value * Math.sin(this.angle) + this.points[0].y;
        var newX2 = value * Math.cos(this.angle) + this.points[3].x;
        var newY2 = -value * Math.sin(this.angle) + this.points[3].y;
        this.points[1].updatePosition(newX1,newY1);
        this.points[2].updatePosition(newX2,newY2);
        this.update();
        return this.width;
    }

    Sink.prototype.setStrokeWidth = function(value){
        this.lineWidth = value;
        this.update();
        return this.lineWidth;
    }

    Sink.prototype.setobjectAngle = function(angle){
        this.getCenter();
        this.points[0].setRotateAngle(this.centerPoint.x,this.centerPoint.y,this.angle);
        this.points[1].setRotateAngle(this.centerPoint.x,this.centerPoint.y,this.angle);
        this.points[2].setRotateAngle(this.centerPoint.x,this.centerPoint.y,this.angle);
        this.points[3].setRotateAngle(this.centerPoint.x,this.centerPoint.y,this.angle);
        this.points[0].rotateAroundCenter(this.centerPoint.x,this.centerPoint.y,angle);
        this.points[1].rotateAroundCenter(this.centerPoint.x,this.centerPoint.y,angle);
        this.points[2].rotateAroundCenter(this.centerPoint.x,this.centerPoint.y,angle);
        this.points[3].rotateAroundCenter(this.centerPoint.x,this.centerPoint.y,angle);
        this.update();
    }

    Sink.prototype.setStrokeWidth = function(value){
        this.lineWidth = value;
        this.update();
        return this.lineWidth;
    }

    Sink.prototype.setobjectStrokeColor = function(color){
        var isOk  = /(^#[0-9A-F]{6}$)|(^#[0-9A-F]{3}$)/i.test(color)
        if(isOk){
            this.stroke = color;
        } else {
            console.log("color not recognized")
        }
        this.outerSink.css("stroke",this.stroke);
        this.innerSink.css("stroke",this.stroke);
        this.outerDrain.css("stroke",this.stroke);
        this.innerDrain.css("stroke",this.stroke);
        this.faucetNozzle.css("stroke",this.stroke);
        this.faucetCircle.css("stroke",this.stroke);
    }

    Sink.prototype.setobjectFillColor = function(color){
        var isOk  = /(^#[0-9A-F]{6}$)|(^#[0-9A-F]{3}$)/i.test(color)
        if(isOk){
            this.sinkFill = color;
        } else {;
            console.log("color not recognized")
        }
        this.innerSink.css("fill",this.sinkFill);
    }

    Sink.prototype.setobjectAreaColor = function(color){
        console.log(color)
        var isOk  = /(^#[0-9A-F]{6}$)|(^#[0-9A-F]{3}$)/i.test(color)
        if(isOk){
            this.fill = color;
        } else {;
            console.log("color not recognized")
        }
        this.outerSink.css("fill",this.fill);
    }