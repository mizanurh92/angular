function WindowClass(id,width,dist,color,lineWidth,state,map,wall){
    MapObject.call(this,"Window",id); // Sets Door as subclass of MapObject
    this.state = state; // Reference to the State Controller
    this.map = map; // Reference to the Map Controller
    this.wall = wall;

    this.type = "Window"; // Can be removed - lives on superclass - just here for reminder
    this.id = id; // Can be removed - lives on superclass - just here for reminder
    this.handleDragging = ""; // Can be removed - lives on superclass - just here for reminder
    this.isSelected = false;   // Can be removed - lives on superclass - just here for reminder

	this.width = width;
    this.minimumWidth = 12;
    this.lineWidth = lineWidth;
	this.dist = dist;
	this.color = color;
    this.windowStrokeColor = "#0000ff";
    this.windowFillColor = "#add8e6";
    this.endCapColor = "#a9a9a9";
    this.endCapStroke = "#000000";
    this.areaSelectColor = "#E6CFD3"
    this.endCapSelectColor = "#ff0000";
    this.labelStyle = 4;
    this.labelColor = "#000000";
    this.labelFontSize = 15;
    this.moveStep = 1; // Amount the window will move or resize by with a key command

    this.points = [];

    this.opening = null;
    this.pane = null;
    this.endCapNearExt = null;
    this.endCapNearInt = null;
    this.endCapFarExt = null;
    this.endCapFarInt = null;

    this.multiselect = false;
    this.winDragDist = this.width/2;
    this.labels = [];
    this.endCapPoints = [
        {x:0,y:0},
        {x:0,y:0},
        {x:0,y:0},
        {x:0,y:0},
        {x:0,y:0},
        {x:0,y:0},
        {x:0,y:0},
        {x:0,y:0}
    ];

    this.packageParameters = [ // Used in undo/redo/duplicate/save/load methods
        "type",
        "id",
        "width",
        "minimumWidth",
        "lineWidth",
        "dist",
        "color",
        "windowStrokeColor",
        "windowFillColor",
        "labelStyle",
        "moveStep"
    ];

}
WindowClass.prototype = Object.create(MapObject.prototype); // Links the prototype to the superclass
WindowClass.prototype.constructor = WindowClass;

// ##########################################  Standard Object Interface Functions  ##################################################################

    WindowClass.prototype.create = function(){ // This creates all components of the window object
        this.points[0] = new point(0,0,"ARI"+this.id.slice(1,3)+"0"+this.id.slice(3)); // creates the point closest to the wall start
        this.points[1] = new point(0,0,"ARI"+this.id.slice(1,3)+"1"+this.id.slice(3)); // creates the point furthest from the wall start
        this.createSVG();
        this.addLabels();
    }

    WindowClass.prototype.update = function(){  // This is the basic update function that should occur every time a change is made that would affect layout
        this.constrain();
        this.updateSVG();
        this.updateWidthLabel();
        this.setLabelStyle();
    }

    WindowClass.prototype.remove = function(){  // Removes all the screen elements of the window, once done, the window object can be deleted safely
        this.removeHandles();
        this.removeSVG();        
        this.removeLabels();
    }

    WindowClass.prototype.redraw = function(){ // Redraws the svg objects after they have been removed
        this.createSVG();
        this.setLabelStyle();
    }

    WindowClass.prototype.activate = function(multiselect){ // Sets the window to active status, presumably upon mouse selection by the user
        this.isSelected = true;
        this.opening.css({stroke:this.areaSelectColor}); // Changes the window opening color
        this.endCapNearInt.css({stroke:this.endCapSelectColor});
        this.endCapFarInt.css({stroke:this.endCapSelectColor});

        this.updateWidthLabel();
        this.setLabelStyle(); // Sets the label style based on the current value

        if(!multiselect){
            this.drawHandles();
        }
    }

    WindowClass.prototype.deactivate = function(){ // Deselects the window
        this.isSelected = false;
        this.removeHandles();
        this.setLabelStyle(); // Sets the label style based on the current value
        this.opening.css({stroke:this.color}); // Changes the window opening color
        this.endCapNearInt.css({stroke:this.endCapColor});
        this.endCapFarInt.css({stroke:this.endCapColor});
    }

// ##########################################  Mouse and keyboard event handler Functions  ##################################################################

    WindowClass.prototype.handlePress = function(handleID){ 
        for(var i = 0;i < this.points.length;i++){
            this.points[i].setDragReference();
        }
        this.handleDragging = handleID.slice(5,6)*1;
        this.undoPackage = this.createPackage();
    }

    WindowClass.prototype.handleDrag = function(){ 
        switch(this.handleDragging){
            case 0:
                this.dragInsideEndcap();
            break;
            case 1:
                this.dragOutsideEndcap();
            break;
        }
        this.update();
    }

    WindowClass.prototype.finalizeHandleDrag = function(){

        this.sendPackages();
    }    

    WindowClass.prototype.drawHandles = function(){
        for(var i = 0;i < this.points.length;i++){
            this.points[i].drawHandle();
        }
    }

    WindowClass.prototype.removeHandles = function(){
        for(var i = 0;i < this.points.length;i++){
            this.points[i].removeHandle();
        }      
    }

    WindowClass.prototype.constrain = function(){
        var wall = this.wall;
        if(wall.length < this.width){ // Constrains the door width so that it's not smaller than 12 inches or larger than the length of the wall
            this.width = wall.length;
        } else if (this.width < this.minimumWidth && wall.length > this.minimumWidth){
            this.width = this.minimumWidth;
        }
        this.dist = Math.min(Math.max(this.dist,0),wall.length-this.width); // Constrains the door entrance to the length of the wall
    }

    WindowClass.prototype.dragOutsideEndcap = function(){  // Handler for dragging the outside endcap to adjust the width of the window
        // This function adjusts the width of the window opening by dragging the window frame furthest from the wall start either in or out
        // This function should be used primarily for dragging the outer window frame svg with the mouse
        var wall = this.wall;
        var coords = this.map.pointerCoords();
        var A1 = coords.x - wall.points[0].x;
        var L1 = wall.points[0].y - coords.y;
        var H1 = Math.sqrt(Math.pow(A1,2)+Math.pow(L1,2));
        var theta2 = Math.atan2(L1,A1);
        var theta3 = wall.angle - theta2;
        var dist = H1 * Math.cos(theta3);
        var width = dist - this.dist;
        this.width = this.map.snapRound(Math.min(Math.max(width,12),wall.length-this.dist),1);
    }

    WindowClass.prototype.dragInsideEndcap = function(){  // Handler for dragging the outside endcap to adjust the width of the window (also changes distance)
        // This function adjusts the width of the window opening by moving the window frame nearest to the start of the wall while the furthest point
        // remains stationary.  This is accomplished by changing the width of the window and the distance from the start of the wall.  This function is used
        // when the user drags the window opening point nearest the start of the wall
        var wall = this.wall;
        var coords = this.map.pointerCoords();
        var A1 = coords.x - wall.points[0].x;
        var L1 = wall.points[0].y - coords.y;
        var H1 = Math.sqrt(Math.pow(A1,2)+Math.pow(L1,2));
        var theta2 = Math.atan2(L1,A1);
        var theta3 = wall.angle - theta2;
        var dist = H1 * Math.cos(theta3);
        var width = (this.dist + this.width) - dist;
        this.width = Math.min(Math.max(width,12),wall.length-this.dist);
        this.setobjectDist(dist);
    }

// ##########################################  Application Mechanics (Undo/Redo/Duplicate/Save/Load)  #############################################

    WindowClass.prototype.duplicate = function(original){
        for(var i = 0;i < original.points.length;i++){
            this.points.push(new point(original.points[i].x,original.points[i].y,original.points[i].id.substring(0,6)+this.id))
        }
        for(var i = 0;i < this.packageParameters.length;i++){
            if(this.packageParameters[i] != "id"){
                this[this.packageParameters[i]] = original[this.packageParameters[i]];
            }
        }
        this.createSVG();
        this.addLabels(); // This creates the three part label giving the distance before and after the door, as well as the door itself
        this.setLabelStyle();
        this.update();        
    }

    WindowClass.prototype.createPackage = function(){
        var package = {points:[]};
        for(var i = 0;i < this.points.length;i++){
            package.points.push(this.points[i].getPoint());
        }
        for(var i = 0;i < this.packageParameters.length;i++){
            package[this.packageParameters[i]] = this[this.packageParameters[i]];
        }
        package.controller = "architect";
        package.packageType = "modify window";
        return package;
    }

    WindowClass.prototype.loadPackage = function(package){
        // It doesn't matter if it is an undo or redo package, the impact is to reset the object to a former state
        for(var i = 0;i < this.points.length;i++){
            this.points[i].updatePosition(package.points[i].x,package.points[i].y);
        }
        for(var i = 0;i < this.packageParameters.length;i++){
            this[this.packageParameters[i]] = package[this.packageParameters[i]];
        }
        this.update();
    }

    WindowClass.prototype.sendPackages = function(){
        // It is important to know that the undo and redo packages aren't the same.  If they are, there was no real action taken and
        // an undo or redo event will have no apparent effect
        var undo = this.undoPackage;
        var redo = this.createPackage();
        var same = true; // Used to determine whether the two packages are the same (no actual event occured)
        for(var i = 0;i < redo.points.length;i++){ // Runs through the points first as the most common event changes
            if(undo.points[i].x != redo.points[i].x || undo.points[i].y != redo.points[i].y){
                same = false;
                break; // breaks as soon as a single difference is found
            }
        }       
        if(same){ // No need to start second loop if a difference was already found
            for(var i = 0;i < this.packageParameters.length;i++){
                if(undo[this.packageParameters[i]] != redo[this.packageParameters[i]]){
                    same = false;
                    break;
                }
            }
        }
        // Packages are sent essentially simultaneously to prevent having mismatched packages if the action isn't finalized
        if(same == false){
            this.state.addUndoPackage(undo);
            this.state.addRedoPackage(redo);
        }
    }

    WindowClass.prototype.save = function(){
        var saveFile = {points:[]}
        for(var i = 0;i < this.points.length;i++){
            saveFile.points.push(this.points[i].getSavePoint());
        }
        for(var i = 0;i < this.packageParameters.length;i++){
            saveFile[this.packageParameters[i]] = this[this.packageParameters[i]];
        }
        return saveFile
    }

    WindowClass.prototype.load = function(saveFile){
        // Note that this method assumes that the create function has not been called - will not work if it has been
        for(var i = 0;i < saveFile.points.length;i++){
            this.points.push(new point(saveFile.points[i].x,saveFile.points[i].y,saveFile.points[i].id));
        }
        for(var i = 0;i < this.packageParameters.length;i++){
            this[this.packageParameters[i]] = saveFile[this.packageParameters[i]];
        }
        this.createSVG(); 
        this.addLabels();
        this.update();
    }

// ##########################################  Drag and Move Functions  #############################################

    WindowClass.prototype.startDrag = function(){
        this.undoPackage = this.createPackage();
        // The following creates a distance offset for better dragging of the window opening
        var wall = this.wall;
        var coords = this.map.pointerCoords();
        var A1 = coords.x - wall.points[0].x;
        var L1 = wall.points[0].y - coords.y;
        var H1 = Math.sqrt(Math.pow(A1,2)+Math.pow(L1,2));
        var theta2 = Math.atan2(L1,A1);
        var theta3 = wall.angle - theta2;
        var dist = H1 * Math.cos(theta3);
        this.winDragDist = dist - this.dist;
    }

    WindowClass.prototype.drag = function(){ // Adjusts the distance of the window opening from the starting point of the wall.
        //  Calculated based on the distance of a perpendicular line from the mouse pointer to the wall where the distance
        //  is the distance from the wall start to the wall's intersection with this line.
        var wall = this.wall;
        var coords = this.map.pointerCoords();
        var A1 = coords.x - wall.points[0].x;
        var L1 = wall.points[0].y - coords.y;
        var H1 = Math.sqrt(Math.pow(A1,2)+Math.pow(L1,2));
        var theta2 = Math.atan2(L1,A1);
        var theta3 = wall.angle - theta2;
        var dist = H1 * Math.cos(theta3);
        this.dist = this.map.snapRound(dist - this.winDragDist,1);
        this.update();
    }

    WindowClass.prototype.finalizeDrag = function(){
        
        this.sendPackages();
    }

    WindowClass.prototype.keyCommand = function(direction){  // Handler for keyboard commands, primarily the arrow keys
        this.undoPackage = this.createPackage();
        switch(direction){
            case "up":
                this.width += this.moveStep;
            break;
            case "down":
                this.width -= this.moveStep;
            break;
            case "left":
                this.dist -= this.moveStep;
            break;
            case "right":
                this.dist += this.moveStep;
            break;
        }
        this.update();
        this.sendPackages(); 
    }

// ##########################################  Object SVG Functions  ##################################################################

    WindowClass.prototype.createSVG = function(){
        var windowOpening = document.createElementNS('http://www.w3.org/2000/svg', 'path');
        windowOpening.setAttribute('d',this.setPoints());
        windowOpening.setAttribute('id',"a"+this.id);
        windowOpening.setAttribute('class',"architect window");
        windowOpening.setAttribute('style',"stroke-linecap:"+"butt"+";stroke:"+this.color+";stroke-width:"+this.lineWidth);
        $('#windowOpening').append(windowOpening); 
        this.opening = $("#a" + this.id);

        var windowPane = document.createElementNS('http://www.w3.org/2000/svg', 'path');
        windowPane.setAttribute('d',this.calculateWindowPath());
        windowPane.setAttribute('id',"b"+this.id);
        windowPane.setAttribute('class',"architect window");
        windowPane.setAttribute('style',"stroke-linecap:"+"square"+";stroke:"+this.windowStrokeColor+";fill:"+this.windowFillColor+";stroke-width:.5");
        $('#windowPane').append(windowPane);
        this.pane = $("#b" + this.id);

        this.endCapNearExt = this.createEndCapSVG("c"+this.id,this.lineWidth,this.endCapStroke);
        this.endCapNearInt = this.createEndCapSVG("d"+this.id,this.lineWidth*1-1,this.endCapColor);
        this.endCapFarExt = this.createEndCapSVG("e"+this.id,this.lineWidth,this.endCapStroke);
        this.endCapFarInt = this.createEndCapSVG("f"+this.id,this.lineWidth*1-1,this.endCapColor);
        this.updateEndCaps();
    }

    WindowClass.prototype.createEndCapSVG = function(id,lineWidth,color){ // Creates an endcap path SVG object representing a window endcap/frame
        var wallLayer = document.createElementNS('http://www.w3.org/2000/svg', 'path');
        wallLayer = document.createElementNS('http://www.w3.org/2000/svg', 'path');
        wallLayer.setAttribute('id',id);
        wallLayer.setAttribute('class',"architect window");
        wallLayer.setAttribute('style',"stroke-linecap:"+"butt"+";stroke:"+color+";stroke-width:"+lineWidth);
        $('#doorJam').append(wallLayer);
        return $("#"+id);
    }

    WindowClass.prototype.setPoints = function(){  // Finds the start and end point for the window opening based on the set distance and wall points, returns path
        var wall = this.wall;
        this.points[0].updatePosition(
            this.dist * Math.cos(wall.angle)+wall.points[0].x,
            -this.dist * Math.sin(wall.angle)+wall.points[0].y
            );
        this.points[1].updatePosition(
            (this.dist + this.width) * Math.cos(wall.angle)+wall.points[0].x,
            -(this.dist + this.width) * Math.sin(wall.angle)+wall.points[0].y
            );

        var path = "";
        path += "M " + this.points[0].x + " " + this.points[0].y;
        path += "L " + this.points[1].x + " " + this.points[1].y;       
        return path;
    }

    WindowClass.prototype.updateEndCaps = function(){  // Recalculates points and then recreates and applies the endcaps' svg paths
        var wall = this.wall;
        // Near endcap
        // (exterior)
        this.endCapPoints[0].x = (this.dist - 3) * Math.cos(wall.angle)+wall.points[0].x;
        this.endCapPoints[0].y = -(this.dist - 3) * Math.sin(wall.angle)+wall.points[0].y;
        this.endCapPoints[1].x = (this.dist + 0) * Math.cos(wall.angle)+wall.points[0].x;
        this.endCapPoints[1].y = -(this.dist + 0) * Math.sin(wall.angle)+wall.points[0].y;
        // (interior)
        this.endCapPoints[2].x = (this.dist - 2.5) * Math.cos(wall.angle)+wall.points[0].x;
        this.endCapPoints[2].y = -(this.dist - 2.5) * Math.sin(wall.angle)+wall.points[0].y;
        this.endCapPoints[3].x = (this.dist - .5) * Math.cos(wall.angle)+wall.points[0].x;
        this.endCapPoints[3].y = -(this.dist - .5) * Math.sin(wall.angle)+wall.points[0].y;
        
        // Far endcap
        // (exterior)
        this.endCapPoints[4].x = (this.dist + this.width + 0) * Math.cos(wall.angle)+wall.points[0].x;
        this.endCapPoints[4].y = -(this.dist +this.width + 0) * Math.sin(wall.angle)+wall.points[0].y;
        this.endCapPoints[5].x = (this.dist + this.width + 3) * Math.cos(wall.angle)+wall.points[0].x;
        this.endCapPoints[5].y = -(this.dist +this.width + 3) * Math.sin(wall.angle)+wall.points[0].y;
        // (interior)
        this.endCapPoints[6].x = (this.dist + this.width + .5) * Math.cos(wall.angle)+wall.points[0].x;
        this.endCapPoints[6].y = -(this.dist +this.width + .5) * Math.sin(wall.angle)+wall.points[0].y;
        this.endCapPoints[7].x = (this.dist + this.width + 2.5) * Math.cos(wall.angle)+wall.points[0].x;
        this.endCapPoints[7].y = -(this.dist +this.width + 2.5) * Math.sin(wall.angle)+wall.points[0].y;

        var path = "";
        path = "M "+this.endCapPoints[0].x+" "+this.endCapPoints[0].y+" L "+this.endCapPoints[1].x+" "+this.endCapPoints[1].y;
        this.endCapNearExt.attr({d:path}); // Exterior near endcap
        path = "M "+this.endCapPoints[2].x+" "+this.endCapPoints[2].y+" L "+this.endCapPoints[3].x+" "+this.endCapPoints[3].y;
        this.endCapNearInt.attr({d:path}); // Interior near endcap
        path = "M "+this.endCapPoints[4].x+" "+this.endCapPoints[4].y+" L "+this.endCapPoints[5].x+" "+this.endCapPoints[5].y;
        this.endCapFarExt.attr({d:path}); // Exterior far endcap
        path = "M "+this.endCapPoints[6].x+" "+this.endCapPoints[6].y+" L "+this.endCapPoints[7].x+" "+this.endCapPoints[7].y;
        this.endCapFarInt.attr({d:path}); // Interior far endcap 
    }

    WindowClass.prototype.calculateWindowPath = function(){ // Finds the path for the window pane based on the starting point, wall angle, and window width, returns path
        // Starting Point
        var startX = this.points[0].x;
        var startY = this.points[0].y;

        // Angle Measures
        var theta1 = this.wall.angle; // Angle of the wall the window is placed on
        var theta2 = Math.PI/2-theta1 // Angle of line perpendicular to the wall relative to x-axis

        // Distance Measures
        var dx = -((this.lineWidth)/6) * Math.cos(theta2); // distance to move to the corner of the window frame
        var dy = -((this.lineWidth)/6) * Math.sin(theta2);
        var dx2 = this.width * Math.cos(theta1);  // distance to move to the other end of the window (lenth-wise)
        var dy2 = -this.width * Math.sin(theta1); 
        var dx3 = (this.lineWidth/3) * Math.cos(-theta2); // distance to move to the opposite width-wise edge of the window
        var dy3 = -(this.lineWidth/3) * Math.sin(-theta2);

        // Window SVG path based on orientation and swing direction
        var path = "M " + startX + " " + startY + " m " +  dx + " " + dy + " l " + dx2 + " " + dy2 + " l " + dx3 + " " + dy3 + " l " + -dx2 + " " + -dy2 + " l " + -dx3 + " " + -dy3;

        return path;
    }

    WindowClass.prototype.updateSVG = function(){
        this.opening ? this.opening.attr({d:this.setPoints()}) : null;
        this.pane ? this.pane.attr({d:this.calculateWindowPath()}) : null;
        this.updateEndCaps();        
    }

    WindowClass.prototype.removeSVG = function(){
        this.opening ? this.opening.remove() : null;
        this.pane ? this.pane.remove() : null;
        this.endCapNearExt ? this.endCapNearExt.remove() : null;
        this.endCapNearInt ? this.endCapNearInt.remove() : null;
        this.endCapFarExt ? this.endCapFarExt.remove() : null;
        this.endCapFarInt ? this.endCapFarInt.remove() : null;
    }

// ##########################################  Distance Labels Functions  ######################################################################

    WindowClass.prototype.setLabelStyle = function(styleNumber){  // Changes the display behavior of the distance labels based on a style number from a slider
        var wall = this.wall;
        if(styleNumber != undefined){
            this.labelStyle = styleNumber;
        }
        switch(this.labelStyle){
            case 0: // Never show labels
                this.removeLabels();
            break;
            case 1: // Only show window width when selected
                if(this.isSelected == true){
                    this.labels[0].redraw(wall);
                    this.labels[1].remove();
                    this.labels[2].remove();
                } else {
                   this.removeLabels(); 
                }
            break;
            case 2: // Only show labels when selected (default)
                if(this.isSelected == true){
                    this.labels[0].redraw(wall);
                    this.labels[1].redraw(wall);
                    this.labels[2].redraw(wall);
                } else {
                   this.removeLabels(); 
                }
            break;
            case 3: // Always show window label, hide sides when not selected
                if(this.isSelected == true){
                    this.labels[0].redraw(wall);
                    this.labels[1].redraw(wall);
                    this.labels[2].redraw(wall);
                } else {
                    this.labels[0].redraw(wall);
                    this.labels[1].remove();
                    this.labels[2].remove();
                }
            break;
            case 4: // Always show all labels
                    this.labels[0].redraw(wall);
                    this.labels[1].redraw(wall);
                    this.labels[2].redraw(wall);
            break;
        }
        return this.labelStyle;
    }

    WindowClass.prototype.removeLabels = function(){  // Removes the label svg elements for any active label objects
        for(var i = 0;i < this.labels.length;i++){
            this.labels[i].remove();
        }
    }

    WindowClass.prototype.addLabels = function(){  // Adds all three width label objects and their respective svg elements
        var wall = this.wall;
        var id = generateUUID();
        var path = "c"+wall.id;
        
        // Label for the window itself
        var textLabel = this.renderLength(this.width);
        var xOffset = 100*(this.dist+this.width/2)/wall.length+"%";
        this.labels[0] = new WallTextLabel("0"+id,this.labelColor,this.labelFontSize,path,xOffset,this.labelFontSize);
        this.labels[0].draw();
        this.labels[0].setText(textLabel,wall,xOffset)
        
        // Label for the distance between wall start and the window
        textLabel = this.renderLength(this.dist);
        xOffset = 100*(this.dist/wall.length)/2+"%";
        this.labels[1] = new WallTextLabel("1"+id,this.labelColor,this.labelFontSize,path,xOffset,this.labelFontSize);
        this.labels[1].draw();
        this.labels[1].setText(textLabel,wall,xOffset)
        
        // Label for the distance between the window and the wall end
        textLabel = this.renderLength(wall.length-(this.dist+this.width));
        var endDist = wall.length - (this.dist + this.width);
        xOffset = 100*(this.dist+this.width+endDist/2)/wall.length+"%";
        this.labels[2] = new WallTextLabel("2"+id,this.labelColor,this.labelFontSize,path,xOffset,this.labelFontSize);
        this.labels[2].draw();
        this.labels[2].setText(textLabel,wall,xOffset)
    }

    WindowClass.prototype.updateWidthLabel = function(){ // Repositions the width labels based on the position of the window relative to the wall ends
        var wall = this.wall;
        var textLabel = this.renderLength(this.width);
        var xOffset = 100*(this.dist+this.width/2)/wall.length+"%";
        this.labels[0].setText(textLabel,wall,xOffset,this.labelFontSize/1.5+10)
  
        textLabel = this.renderLength(this.dist);
        xOffset = 100*(this.dist/wall.length)/2+"%";
        if(xOffset.slice(0,-1) < 10){
            xOffset = xOffset.slice(0,-1)/2+"%";
            // Controls the orientation of the text along the path based on whether the wall is inverted
            if(wall.isInverted()){
                this.labels[1].changeAnchor("end");
            } else {
                this.labels[1].changeAnchor("start");
            }
            this.labels[1].setText(textLabel,wall,xOffset,-this.labelFontSize/5-5);
        } else {
            this.labels[1].changeAnchor("middle");
            this.labels[1].setText(textLabel,wall,xOffset,this.labelFontSize/1.5+10);
        }

        textLabel = this.renderLength(wall.length-(this.dist+this.width));
        var endDist = wall.length - (this.dist + this.width);
        xOffset = 100*(this.dist+this.width+endDist/2)/wall.length+"%";
        if(xOffset.slice(0,-1) > 90){
            xOffset = (xOffset.slice(0,-1)*1 + 1*(100-xOffset.slice(0,-1))/2)+"%";
            // Controls the orientation of the text along the path based on whether the wall is inverted
            if(wall.isInverted()){
                this.labels[2].changeAnchor("start");
            } else {
                this.labels[2].changeAnchor("end");
            }
            this.labels[2].setText(textLabel,wall,xOffset,-this.labelFontSize/5-5);
        } else {
            this.labels[2].changeAnchor("middle");
            this.labels[2].setText(textLabel,wall,xOffset,this.labelFontSize/1.5+10);
        }
    }

// ##########################################  Selector Interface Functions  ######################################################################

    WindowClass.prototype.setProperty = function(property,value){
        switch(property){
            case "objectLength":
                this.setobjectLength(value);
            break;
            case "objectDist":
                this.setobjectDist(value);
            break;
            case "objectStrokeColor":
                this.setobjectStrokeColor(value);
            break;
            case "objectFillColor":
                this.setobjectFillColor(value);
            break;
            case "objectAreaColor":
                this.setobjectAreaColor(value);
            break;
            case "objectLabelStyle":
                this.setLabelStyle(value);
            break;            
            case "objectLabelColor":
                this.labels[0].setColor(value);
                this.labels[1].setColor(value);
                this.labels[2].setColor(value);
            break;
            case "objectLabelSize":
                this.labelFontSize = value;
                this.labels[0].setFontSize(value);
                this.labels[1].setFontSize(value);
                this.labels[2].setFontSize(value);
                this.updateWidthLabel();
            break;
        }
    }

    WindowClass.prototype.getObjectData = function(){  // This function is called when the user selects a wall object
        var thisData = {};
        thisData.data = {
            objectType: {type:"label",value:"Window"},
            objectLength: {type:"spinner",value: this.renderLength(this.width)},
            objectDist: {type:"spinner",value:this.renderLength(this.dist)},
            objectStrokeColor: {type:"color",value:this.windowStrokeColor},
            objectFillColor: {type:"color",value:this.windowFillColor},
            objectAreaColor: {type:"color",value:this.color},
            objectLabelStyleText: {type:"na",value:WindowClass.prototype.slide(null,{value:this.labelStyle})},
            objectLabelStyle: {type:"slider",value:this.labelStyle,min:0,max:4,slide:WindowClass.prototype.slide},
            objectLabelColor: {type:"color",value:this.labelColor},
            objectLabelSize: {type:"spinner",value:this.labelFontSize},            
        }
        thisData.dividers = {
            sizeDivider:true,
            positionDivider:true,
            colorDivider:true,
            labelsDivider:true
        }
        return thisData;
    }

    WindowClass.prototype.slide = function(event,ui){
            var message = "";
            switch(ui.value){
                case 0:
                message = "No Labels"
                break;
                case 1:
                message = "Show Width Label on Select"
                break;
                case 2:
                message = "Show All Labels on Select"
                break;
                case 3:
                message = "Always Show Width Label"
                break;
                case 4:
                message = "Always Show All Labels"
                break;
            }
            $( "#objectLabelStyleText" ).html(message);
    }

    WindowClass.prototype.setobjectLength = function(length){ // Sets the length of the door, which modifies the door width property
        this.width = length;
        this.update(); // Redraws the door area based on the new width parameters
        return this.width;
    }
    WindowClass.prototype.setobjectWidth = function(){ // Function is called when the width of the wall is changed
        // It updates all of the necessary line width measurements and redraws the screen objects
        this.lineWidth = this.wall.outerWidth;
        this.remove();
        this.redraw();
        this.update();
    }
    WindowClass.prototype.setobjectDist = function(dist){ // Sets the distance of the start of the door from the start of the wall
        this.dist = dist;
        this.update(); // Redraws the door area based on the new width parameters
        return this.dist; // Returns the final width of the door, which will be updated in the input box
    }


    WindowClass.prototype.setobjectStrokeColor = function(color){
        var isOk  = /(^#[0-9A-F]{6}$)|(^#[0-9A-F]{3}$)/i.test(color)
        if(isOk){
            this.windowStrokeColor = color;
        } else {
            console.log("color not recognized")
        }
        this.pane ? this.pane.css("stroke",this.windowStrokeColor) : null;
        return this.windowStrokeColor;
    }

    WindowClass.prototype.setobjectFillColor = function(color){
        var isOk  = /(^#[0-9A-F]{6}$)|(^#[0-9A-F]{3}$)/i.test(color)
        if(isOk){
            this.windowFillColor = color;
        } else {
            console.log("color not recognized")
        }
        this.pane ? this.pane.css("fill",this.windowFillColor) : null;
        return this.windowFillColor;
    }

    WindowClass.prototype.setobjectAreaColor = function(color){
        var isOk  = /(^#[0-9A-F]{6}$)|(^#[0-9A-F]{3}$)/i.test(color)
        if(isOk){
            this.color = color;
        } else {
            console.log("color not recognized")
        }
        this.opening? this.opening.css("stroke",this.color) : null;
        return this.color;
    }