function Stairs(id,state,map){
    MapObject.call(this,"Stairs",id); // Sets Stairs as subclass of MapObject
    this.state = state; // Reference to the State Controller
    this.map = map; // Reference to the Map Controller

    this.type = "Stairs"; // Can be removed - lives on superclass - just here for reminder
    this.id = id; // Can be removed - lives on superclass - just here for reminder
    this.handleDragging = ""; // Can be removed - lives on superclass - just here for reminder
    this.isSelected = false;   // Can be removed - lives on superclass - just here for reminder

    this.fill = "#ffffff";  // Default inner color
    this.stroke = "#000000";  // Default outer color
    this.arrowColor = "#ff0000";
    this.selectedColor = "#ff0000";
    this.width = 48; // Width of the stairs in inches
    this.lineWidth = 1;  // Width of the stairs outline
    this.stairSpacing = 10; // Default spacing between stairs
    this.arrowActive = true;
    this.stairDirection = 0;

    this.points = []; // Holds points for start and end of stairs

    // The following are aliases to the various stair svg elements.  This prevents having to do a lookup for each change
    this.stairs = null;
    this.arrow = null;

    this.angle = 0;  // Angle in radians of the stairs with respect to the x-axis
    this.length = 0;  // Length of the stairs in inches
    this.stairCount = 0; // Number of stairs in the 
        
    this.packageParameters = [ // Used in undo/redo/duplicate/save/load methods
        "type",
        "id",
        "width",
        "fill",
        "stroke",
        "lineWidth",
        "stairSpacing",
        "arrowActive"
    ];
}
    Stairs.prototype = Object.create(MapObject.prototype); // Links the prototype to the superclass
    Stairs.prototype.constructor = Stairs;

// ##########################################  Standard Object Interface Functions  ##################################################################
    
    Stairs.prototype.create = function(){ // This creates all components of the stair object
        var map = this.map;
        var pos = map.pointerCoords();
        this.points[0] = new point(map.snapRound(pos.x),map.snapRound(pos.y),"ARSP00"+this.id); // Start Point
        this.points[1] = new point(map.snapRound(pos.x),map.snapRound(pos.y),"ARSP01"+this.id); // Start Point
        this.createSVG();
    }

    Stairs.prototype.update = function(){
        this.calculateAngle();
        this.calculateLength();
        this.updateSVG();
    }

    Stairs.prototype.remove = function(){
        this.removeHandles();
        this.removeSVG();
    }

    Stairs.prototype.redraw = function(){
        this.createSVG();
        this.update();
    }

    Stairs.prototype.activate = function(multiselect){
        this.stairs.css("stroke",this.selectedColor);
        this.arrow ? this.arrow.css("stroke",this.stroke) : null;
        this.isSelected = true;
        if(multiselect){ // Makes sure there is no double activation
            this.removeHandles();
        } else {
            this.drawHandles();
        }
    }

    Stairs.prototype.deactivate = function(){
        this.stairs.css("stroke",this.stroke);
        this.arrow ? this.arrow.css("stroke",this.arrowColor) : null;
        this.isSelected = false;
        this.removeHandles();
    }

    Stairs.prototype.getOutlinePoints = function(){
        var pointObject = [];           
        for(var i = 0;i < 2;i++){ // Note that this only looks at the center line and not the corners specifically
            // Shouldn't really matter in most instances and involves more compute cost to calculate corner points on the fly
            pointObject.push(this.points[i].getPoint());
        }
        return pointObject;
    }

// ##########################################  Point Handle Functions  ##################################################################
    
    Stairs.prototype.handlePress = function(handleID){  // Receives a handle press event and saves the mouse location and handle ID for drag process
        for(var i = 0;i < this.points.length;i++){
            this.points[i].setDragReference();
        }
        this.handleDragging = handleID.slice(4,6)*1;
        this.undoPackage = this.createPackage();
    }

    Stairs.prototype.handleDrag = function(){  // Receives a handle drag event and changes the point associated with the handle based on the new location
        if(this.handleDragging == 0 || this.handleDragging == 1){ // checks that either endpoint is being dragged
            var map = this.map;
            var coords = map.pointerCoords(); // gets the latest mouse location
            var xMove = coords.x-map.handle.x/map.scale;
            var yMove = coords.y-map.handle.y/map.scale;
            this.points[this.handleDragging].dragOffset(xMove,yMove,{gridResolution:map.snapGridResolution,snapToGrid:map.snapGridActive});
            this.update();
        }
    }

    Stairs.prototype.finalizeHandleDrag = function(){
        
        this.sendPackages();
    }

    Stairs.prototype.drawHandles = function(){
        for(var i = 0;i < this.points.length;i++){
            this.points[i].drawHandle();
        }  
    }

    Stairs.prototype.removeHandles = function(){ // Removes the handles on the wall endpoints
        for(var i = 0;i < this.points.length;i++){
            this.points[i].removeHandle();
        }
    }

// ##########################################  Application Mechanics (Undo/Redo/Duplicate/Save/Load)  #############################################

    Stairs.prototype.duplicate = function(original){
        for(var i = 0;i < original.points.length;i++){
            this.points.push(new point(original.points[i].x,original.points[i].y,original.points[i].id.substring(0,6)+this.id))
        }
        for(var i = 0;i < this.packageParameters.length;i++){
            if(this.packageParameters[i] != "id"){
                this[this.packageParameters[i]] = original[this.packageParameters[i]];
            }
        }
        this.createSVG();
        this.move(12,12);
    }

    Stairs.prototype.createPackage = function(){
        var package = {points:[]};
        for(var i = 0;i < this.points.length;i++){
            package.points.push(this.points[i].getPoint());
        }
        for(var i = 0;i < this.packageParameters.length;i++){
            package[this.packageParameters[i]] = this[this.packageParameters[i]];
        }
        package.controller = "architect";
        package.packageType = "modify";
        return package;
    }

    Stairs.prototype.loadPackage = function(package){
        // It doesn't matter if it is an undo or redo package, the impact is to reset the object to a former state
        for(var i = 0;i < this.points.length;i++){
            this.points[i].updatePosition(package.points[i].x,package.points[i].y);
        }
        for(var i = 0;i < this.packageParameters.length;i++){
            this[this.packageParameters[i]] = package[this.packageParameters[i]];
        }
        this.update();
    }

    Stairs.prototype.sendPackages = function(){
        // It is important to know that the undo and redo packages aren't the same.  If they are, there was no real action taken and
        // an undo or redo event will have no apparent effect
        var undo = this.undoPackage;
        var redo = this.createPackage();
        var same = true; // Used to determine whether the two packages are the same (no actual event occured)
        for(var i = 0;i < redo.points.length;i++){ // Runs through the points first as the most common event changes
            if(undo.points[i].x != redo.points[i].x || undo.points[i].y != redo.points[i].y){
                same = false;
                break; // breaks as soon as a single difference is found
            }
        }       
        if(same){ // No need to start second loop if a difference was already found
            for(var i = 0;i < this.packageParameters.length;i++){
                if(undo[this.packageParameters[i]] != redo[this.packageParameters[i]]){
                    same = false;
                    break;
                }
            }
        }
        // Packages are sent essentially simultaneously to prevent having mismatched packages if the action isn't finalized
        if(same == false){
            this.state.addUndoPackage(undo);
            this.state.addRedoPackage(redo);
        }
    }

    Stairs.prototype.save = function(){
        var saveFile = {points:[]}
        for(var i = 0;i < this.points.length;i++){
            saveFile.points.push(this.points[i].getSavePoint());
        }
        for(var i = 0;i < this.packageParameters.length;i++){
            saveFile[this.packageParameters[i]] = this[this.packageParameters[i]];
        }
        return saveFile
    }

    Stairs.prototype.load = function(saveFile){
        // Note that this method assumes that the create function has not been called - will not work if it has been
        for(var i = 0;i < saveFile.points.length;i++){
            this.points.push(new point(saveFile.points[i].x,saveFile.points[i].y,saveFile.points[i].id));
        }
        for(var i = 0;i < this.packageParameters.length;i++){
            this[this.packageParameters[i]] = saveFile[this.packageParameters[i]];
        }
        this.createSVG(); 
        this.update();
    }

// ##########################################  Drag and Move Functions  #############################################

    Stairs.prototype.startDrag = function(){ // Saves the origin of a drag event for move calculations
        this.undoPackage = this.createPackage();
        for(var i = 0;i < this.points.length;i++){
            this.points[i].setDragReference();
        }
    }

    Stairs.prototype.drag = function(){ // Drags the wall upon a left-button down on the wall layer svg and dragging the mouse
        var map = this.map;
        var coords = map.pointerCoords(); // gets the latest mouse location
        var xMove = coords.x-map.handle.x/map.scale;
        var yMove = coords.y-map.handle.y/map.scale;
        var distDragged = this.points[0].dragOffset(xMove,yMove,{gridResolution:map.snapGridResolution,snapToGrid:map.snapGridActive});
        this.points[1].dragOffset(distDragged.x,distDragged.y);
        this.update();
    }

    Stairs.prototype.finalizeDrag = function(){
        
        this.sendPackages();
    }

    Stairs.prototype.move = function(direction){ // Moves the wall by an x and y distance
        var map = this.map;
        this.undoPackage = this.createPackage();
        var x = 0;
        var y = 0;
        switch(direction){
            case "up":
            y = -map.snapGridResolution;
            break;
            case "down":
            y = map.snapGridResolution;
            break;
            case "right":
            x = map.snapGridResolution;
            break;
            case "left":
            x = -map.snapGridResolution;
            break;
        }
        this.points[0].shiftPosition(x,y);
        this.points[1].shiftPosition(x,y);
        this.update();
        this.sendPackages();
    }

// ##########################################  Object SVG Functions  ##################################################################

    Stairs.prototype.createSVG = function(){
        var stairBox = document.createElementNS('http://www.w3.org/2000/svg', 'path');
        stairBox.setAttribute('d',this.getBoxPath());
        stairBox.setAttribute('id',"a"+this.id);
        stairBox.setAttribute('class',"architect stairs");
        stairBox.setAttribute('pointer-events',"all");
        stairBox.setAttribute('style',"stroke-linecap:"+"square"+";stroke:"+this.stroke+";fill:"+this.fill+";stroke-width:"+this.lineWidth);
        $('#stairs').append(stairBox);
        this.stairs = $("#a"+this.id);

        if(this.arrowActive){
            var stairLine = document.createElementNS('http://www.w3.org/2000/svg', 'path');
            stairLine.setAttribute('d',this.getArrowPath());
            stairLine.setAttribute('id',"b"+this.id);
            stairLine.setAttribute('class',"architect stairs");
            stairLine.setAttribute('pointer-events',"none");
            stairLine.setAttribute('style',"stroke-linecap:"+"square"+";stroke:"+this.arrowColor+";fill:"+"none"+";stroke-width:3");
            $('#stairs').append(stairLine);            
            this.arrow = $("#b"+this.id);
        }
    }

    Stairs.prototype.getBoxPath = function(){
        this.stairCount = Math.floor(this.length/this.stairSpacing)
        var stairDist = this.stairSpacing + (this.length%this.stairSpacing)/this.stairCount;

        var startX = this.points[0].x;
        var startY = this.points[0].y;

        var theta1 = this.angle;
        var theta2 = theta1 + Math.PI/2;
        var theta3 = theta2 - Math.PI;
        var theta4 = theta1 - Math.PI;

        var segment1X = startX + (this.width/2) * Math.cos(theta2);
        var segment1Y = startY - (this.width/2) * Math.sin(theta2);

        var segment2X = segment1X + (this.length) * Math.cos(theta1);
        var segment2Y = segment1Y - (this.length) * Math.sin(theta1);

        var segment3X = segment2X + (this.width) * Math.cos(theta3);
        var segment3Y = segment2Y - (this.width) * Math.sin(theta3);

        var segment4X = segment3X + (this.length) * Math.cos(theta4);
        var segment4Y = segment3Y - (this.length) * Math.sin(theta4);

        var path = ""
        path += "M " + startX + " " + startY; // Start point at center of start of stairs
        path += "L " + segment1X + " " + segment1Y;  // Point at the left corner at the start of the stairs
        path += "L " + segment2X + " " + segment2Y;  // Point at the left corner at the end of the stairs
        path += "L " + segment3X + " " + segment3Y;  // Point at the right corner at the end of the stairs
        path += "L " + segment4X + " " + segment4Y;  // Point at the right corner at the start of the stairs
        path += "L " + startX + " " + startY; // Start point again

        for(var i = 1;i<this.stairCount;i++){
            var stairStartX = segment1X + (stairDist*i) * Math.cos(theta1);
            var stairStartY = segment1Y - (stairDist*i) * Math.sin(theta1);
            var stairEndX = stairStartX + (this.width) * Math.cos(theta3);
            var stairEndY = stairStartY - (this.width) * Math.sin(theta3);
            path += "M " + stairStartX + " " + stairStartY;
            path += "L " + stairEndX + " " + stairEndY;
        }

        return path;
    }

    Stairs.prototype.getArrowPath = function(){
        var theta1 = this.angle;
        var theta2 = (theta1 - Math.PI) - Math.PI/4;
        var theta3 = (theta1 - Math.PI) + Math.PI/4;

        var startX = this.points[0].x + 0.1 * (this.length) * Math.cos(theta1);
        var startY = this.points[0].y - 0.1 * (this.length) * Math.sin(theta1);
        var endX = startX + 0.8 * (this.length) * Math.cos(theta1);
        var endY = startY - 0.8 * (this.length) * Math.sin(theta1);
        var arrowStartX = endX + 12 * Math.cos(theta2);
        var arrowStartY = endY - 12 * Math.sin(theta2);
        var arrowEndX = endX + 12 * Math.cos(theta3);
        var arrowEndY = endY - 12 * Math.sin(theta3);

        var path = "";
        path += "M " + startX + " " + startY; // Start point at center of start of stairs
        path += "L " + endX + " " + endY;  // Point at the left corner at the start of the stairs
        path += "M " + arrowStartX + " " + arrowStartY; // Start point at center of start of stairs
        path += "L " + endX + " " + endY;  // Point at the left corner at the start of the stairs
        path += "L " + arrowEndX + " " + arrowEndY;  // Point at the left corner at the start of the stairs
        return path;
    }

    Stairs.prototype.draw = function(){ 
        var map = this.map;
        var pos = map.pointerCoords(); 
        this.points[1].updatePosition(map.snapRound(pos.x),map.snapRound(pos.y)); 
        this.update();
    }

    Stairs.prototype.finalizeDraw = function(){

        this.calculateLength();
        this.calculateAngle();
        this.update();
    }

    Stairs.prototype.cancelDraw = function(){
        
        this.remove();
    }

    Stairs.prototype.checkValid = function(){ // Returns true if this was a validly drawn object
        this.calculateLength();
        return this.length > 0;
    }

    Stairs.prototype.updateSVG = function(){
        this.stairs.attr("d",this.getBoxPath());
        this.arrow ? this.arrow.attr("d",this.getArrowPath()) : null;
    }

    Stairs.prototype.removeSVG = function(){
        this.stairs ? this.stairs.remove() : null;
        this.arrow ? this.arrow.remove() : null;
    }

// ##########################################  Object Calculation Functions  ############################################################

    Stairs.prototype.calculateAngle = function(){  
        
        this.angle = Math.atan2((this.points[0].y-this.points[1].y),(this.points[1].x-this.points[0].x));
    }

    Stairs.prototype.calculateLength = function(){
        var xComponent = this.points[0].x - this.points[1].x;
        var yComponent = this.points[0].y - this.points[1].y;
        this.length = Math.sqrt(Math.pow(xComponent,2)+Math.pow(yComponent,2));
    }


// ##########################################  Selector Interface Functions  ######################################################################
    
    Stairs.prototype.setProperty = function(property,value){
        switch(property){
            case "objectLength":
                this.setobjectLength(value);
            break;
            case "objectWidth":
                this.setobjectWidth(value);
            break;
            case "objectAngle":
                this.setobjectAngle(toRads(value));
            break;
            case "objectStrokeColor":
                this.setobjectStrokeColor(value);
            break;
            case "objectFillColor":
                this.setobjectFillColor(value);
            break;
            case "objectStairDirection":
                this.setStairDirection(value);
            break;
            case "objectStairDirectionToggle":
                this.setArrowActive(value);
            break;
            case "objectStairSpacing":
                this.setStairSpacing(value);
            break;
        }
    }

    Stairs.prototype.getObjectData = function(subcategory,id){  // This function is called when the user selects a wall object
        var thisData = {};
        thisData.data = {
            objectType: {type:"label",value:"Stairs"},
            objectLength: {type:"spinner",value:this.renderLength(this.length)},
            objectWidth: {type:"spinner",value:this.renderLength(this.width)},
            objectAngle: {type:"spinner",value:toDeg(this.angle)},
            objectStrokeColor: {type:"color",value:this.stroke},
            objectFillColor: {type:"color",value:this.fill},
            //objectLabelStyleText: {type:"na",value:Stairs.prototype.slide(null,{value:this.labelStyle})},
            //objectLabelStyle: {type:"slider",value:this.labelStyle,min:0,max:2,slide:Wall.prototype.slide},
            //objectLabelType: {type:"switch",value:true},
            //objectLabelColor: {type:"na",value:null},
            //objectLabelSize: {type:"spinner",value:this.lengthLabel.fontSize},
            objectStairSpacing: {type:"spinner",value:this.renderLength(this.stairSpacing)},
            objectStairCount: {type:"label",value:this.stairCount},
            objectStairDirectionToggle: {type:"switch",value:this.arrowActive},
            objectStairDirectionText: {type:"na",value:""},
            objectStairDirection: {type:"slider",value:0,min:0,max:1,slide:Stairs.prototype.slide}
        }
        thisData.dividers = {
            sizeDivider:true,
            positionDivider:true,
            colorDivider:true,
            stairsDivider:true
        }
        return thisData;
    }

    Stairs.prototype.slide = function(event,ui){
            var message = "";
            switch(ui.value){
                case 0:
                message = "To Upstairs"
                break;
                case 1:
                message = "To Downstairs"
                break;
            }
            $( "#objectStairDirectionText" ).html(message);
    }

    Stairs.prototype.setobjectWidth = function(width){
        this.width = width;
        this.update();
        return this.width;
    }

    Stairs.prototype.setobjectLength = function(length){
        this.points[1].updatePosition(
            this.points[0].x + length * Math.cos(this.angle),
            this.points[0].y - length * Math.sin(this.angle)
            )
        this.update();
    }

    Stairs.prototype.setobjectAngle = function(angle){
        this.points[1].updatePosition(
            this.points[0].x + this.length * Math.cos(angle),
            this.points[0].y - this.length * Math.sin(angle)
            )        
        this.update();
    }

    Stairs.prototype.setStrokeWidth = function(width){
        this.stairs.css("stroke-width",width);
        this.arrow ? this.arrow.css("stroke-width",width) : null;
        this.strokeWidth = width;
        return this.strokeWidth;
    }

    Stairs.prototype.setobjectStrokeColor = function(color){
        var isOk  = /(^#[0-9A-F]{6}$)|(^#[0-9A-F]{3}$)/i.test(color)
        if(isOk){
            this.stroke = color;
        } else {
            console.log("color not recognized")
        }
        this.stairs ? this.stairs.css("stroke",this.stroke) : null;
        return this.stroke;
    }

    Stairs.prototype.setobjectFillColor = function(color){
        var isOk  = /(^#[0-9A-F]{6}$)|(^#[0-9A-F]{3}$)/i.test(color)
        if(isOk){
            this.fill = color;
        } else {
            console.log("color not recognized")
        }
        this.stairs ? this.stairs.css("fill",this.fill) : null;
        return this.fill;
    }

    Stairs.prototype.setStairSpacing = function(spacing){
        this.stairSpacing = spacing;
        this.update();
    }

    Stairs.prototype.setArrowActive = function(value){
        this.arrowActive = value;
        this.removeSVG();
        this.redraw();
    }

    Stairs.prototype.setStairDirection = function(direction){
        if(this.stairDirection != direction){
            var tempPoint1 = {x:this.points[0].x,y:this.points[0].y};
            var tempPoint2 = {x:this.points[1].x,y:this.points[1].y};
            this.points[0].updatePosition(tempPoint2.x,tempPoint2.y);
            this.points[1].updatePosition(tempPoint1.x,tempPoint1.y);
            if(direction == 1){
                this.stairDirection = 1;
            } else {
                this.stairDirection = 0;
            }
            this.update();
        }
    }

