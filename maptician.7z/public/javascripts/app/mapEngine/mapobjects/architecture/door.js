function Door(id,width,dist,color,state,map,wall){
    MapObject.call(this,"Door",id); // Sets Door as subclass of MapObject
    this.state = state; // Reference to the State Controller
    this.map = map; // Reference to the Map Controller
    this.wall = wall; // Reference to the parent wall
    
    this.type = "Door";
    this.id = id;
    this.handleDragging = "";
    this.isSelected = false;
   
    this.width = width; // Width of the door (basically the length of the door, not the width of the wall)
    this.minimumWidth = 12; // Gives a minimum width that the door can be changed to - prevents negative and zero length doors
    this.lineWidth = 6; // Thickness of the wall, not to be confused with the door width
    this.dist = dist; // Distance from the start of the wall to the start of the door
    this.color = color; // Color of the door entrance line
    this.activatedColor = "#E6CFD3"; // Color of the entrance when the door is activated
    this.endType = "square"; // For the line segment svg elements (entrance and endcaps), should likely always be square
    this.labelStyle = 2; // Numeric selector which controls how and when the labels are displayed
    this.moveStep = 1; // Amount (in inches) the door will move or resize by with a key command
    this.door = { // Information on the "open door" part of the open door element
        active: true, // Determines whether the door is visible or if just an empty entryway is displayed
        color: "#000000", // Stroke color for the outline of the open door
        fillColor:"#A9A9A9" , // Fill color for the open door
        angle:toRads(45), // Angle in degrees of the open door relative to the wall
        lineWidth:3 // Width of the open door (should be thinner than the wall for hinge purposes)
    };
    this.labelColor = "#000000";
    this.labelFontSize = 15;
    this.style = 0;

    // The following are aliases to the various door svg element.  This prevents having to do a lookup for each change
    this.entrance = null;
    this.door1 = null;
    this.door2 = null;
    this.arc1 = null;
    this.arc2 = null;
    this.endCapNearExt = null;
    this.endCapNearInt = null;
    this.endCapFarExt = null;
    this.endCapFarInt = null;

    this.points = []; // Array which holds point objects for the start and end of the door entrance and the end of the open door

    this.multiSelect = false;
    this.doorDragDist = this.width/2;
    this.labels = []; // Array which holds the label objects for the door distances    
    this.endCapPoints = [ // Collection of coordinates used in the endcaps around the door entrance
        {x:0,y:0},
        {x:0,y:0},
        {x:0,y:0},
        {x:0,y:0},
        {x:0,y:0},
        {x:0,y:0},
        {x:0,y:0},
        {x:0,y:0} 
    ];
    this.packageParameters = [ // Used in undo/redo/duplicate/save/load methods
        "type",
        "id",
        "width",
        "lineWidth",
        "dist",
        "color",
        "endType",
        "labelStyle",
        "door",
        "labelColor",
        "labelFontSize",
        "style"
    ];


}
    Door.prototype = Object.create(MapObject.prototype); // Links the prototype to the superclass
    Door.prototype.constructor = Door;

// ##########################################  Standard Object Interface Functions  ##################################################################

    Door.prototype.create = function(){ // This creates all components of the door object
        this.points[0] = new point(0,0,"ARD"+this.id.slice(1,3)+"0"+this.id.slice(3)); // creates the door point closest to the wall start
        this.points[1] = new point(0,0,"ARD"+this.id.slice(1,3)+"1"+this.id.slice(3)); // creates the door point furthest from the wall start
        this.points[2] = new point(0,0,"ARD"+this.id.slice(1,3)+"2"+this.id.slice(3)); // creates the point at the end of the "open door"        
        this.createSVG();
        this.addLabels(); // This creates the three part label giving the distance before and after the door, as well as the door itself
    }

    Door.prototype.update = function(){ // This is the basic update function that should occur every time a change is made that would affect layout
        this.constrain(); // Prevents the door from leaving the wall's path or having below a threshhold width
        this.updateSVG();
        this.updateWidthLabel(); // Updates the three part distance label
        this.setLabelStyle();
    }

    Door.prototype.remove = function(){
        this.removeHandles();
        this.removeSVG();
        this.removeLabels();
    }

    Door.prototype.redraw = function(){  // Redraws all svg screen objects (if otherwise visible) after they have been removed
        this.createSVG();
        this.setLabelStyle();
    }

    Door.prototype.activate = function(){  // Sets the door to active status, presumably upon mouse selection by the user
        this.isSelected = true;
        this.entrance.css("stroke",this.activatedColor); // Changes the entrance color
        this.updateWidthLabel(); // Updates the three part distance label
        this.setLabelStyle(); // Sets the label style based on the current value
        this.drawHandles();
    }

    Door.prototype.deactivate = function(){ // Deselects the door
        this.isSelected = false;
        this.removeHandles();
        this.setLabelStyle(); // Sets the label style based on the current value
        this.entrance.css("stroke",this.color); // Changes the entrance color
    }

// ##########################################  Mouse and keyboard event handler Functions  ##################################################################

    Door.prototype.handlePress = function(handleID){ 
        for(var i = 0;i < this.points.length;i++){
            this.points[i].setDragReference();
        }
        this.handleDragging = handleID.slice(5,6)*1;
        this.undoPackage = this.createPackage();
    }

    Door.prototype.handleDrag = function(){ 
        switch(this.handleDragging){
            case 0:
                this.dragInsideEndcap();
            break;
            case 1:
                this.dragOutsideEndcap();
            break;
            case 2:
                this.dragDoorAngle();
            break;
        }
        this.update();
    }

    Door.prototype.finalizeHandleDrag = function(){

        this.sendPackages();
    }

    Door.prototype.drawHandles = function(){
        for(var i = 0;i < this.points.length - 1;i++){
            this.points[i].drawHandle();
        }
        if(this.door.active){
            this.points[2].drawHandle();
        }
    }

    Door.prototype.removeHandles = function(){
        for(var i = 0;i < this.points.length;i++){
            this.points[i].removeHandle();
        }      
    }

    Door.prototype.constrain = function(){
        if(this.wall.length < this.width){ // Constrains the door width so that it's not smaller than 12 inches or larger than the length of the wall
            this.width = this.wall.length;
        } else if (this.width < this.minimumWidth && this.wall.length > this.minimumWidth){
            this.width = this.minimumWidth;
        }
        this.dist = Math.min(Math.max(this.dist,0),this.wall.length-this.width); // Constrains the door entrance to the length of the wall
    }

    Door.prototype.dragDoorAngle = function(){ // Handler for dragging the open door to various angles
        var coords = this.map.pointerCoords();
        var theta1,theta2;
        switch(this.style){
            case 0: // Near Hinge
            case 2: // Double Door
                theta1 = getAngle(this.points[0],this.points[1]);
                theta2 = getAngle(this.points[0],coords);
            break;
            case 1: // Far Hinge
                theta1 = getAngle(this.points[1],this.wall.points[1]);
                theta2 = getAngle(this.points[1],coords);
            break;
        }
        this.door.angle = theta2-theta1;
        if(this.door.angle < -Math.PI){this.door.angle = this.door.angle + 2*Math.PI;} // Normalizes angles (180,-180)
    }

    Door.prototype.dragOutsideEndcap = function(){ // Handler for dragging the outside endcap to adjust the width of the door
        var wall = this.wall;
        var coords = this.map.pointerCoords();
        var A1 = coords.x - wall.points[0].x;
        var L1 = wall.points[0].y - coords.y;
        var H1 = Math.sqrt(Math.pow(A1,2)+Math.pow(L1,2));
        var theta2 = Math.atan2(L1,A1);
        var theta3 = wall.angle - theta2;
        var dist = H1 * Math.cos(theta3);
        var width = dist - this.dist;
        this.width = this.map.snapRound(Math.min(Math.max(width,12),wall.length-this.dist),1);
    }

    Door.prototype.dragInsideEndcap = function(){  // Handler for dragging the inside endcap to adjust the width of the door (also changes distance)
        var wall = this.wall;
        var coords = this.map.pointerCoords();
        var A1 = coords.x - wall.points[0].x;
        var L1 = wall.points[0].y - coords.y;
        var H1 = Math.sqrt(Math.pow(A1,2)+Math.pow(L1,2));
        var theta2 = Math.atan2(L1,A1);
        var theta3 = wall.angle - theta2;
        var dist = H1 * Math.cos(theta3);
        var width = (this.dist + this.width) - dist;
        this.width = Math.min(Math.max(width,12),wall.length-this.dist);
        this.setobjectDist(dist);
    }

// ##########################################  Application Mechanics (Undo/Redo/Duplicate/Save/Load)  #############################################

    Door.prototype.duplicate = function(original){
        for(var i = 0;i < original.points.length;i++){
            this.points.push(new point(original.points[i].x,original.points[i].y,original.points[i].id.substring(0,6)+this.id))
        }
        for(var i = 0;i < this.packageParameters.length;i++){
            if(this.packageParameters[i] != "id"){
                this[this.packageParameters[i]] = original[this.packageParameters[i]];
            }
        }
        this.createSVG();
        this.addLabels(); // This creates the three part label giving the distance before and after the door, as well as the door itself
        this.setLabelStyle();
        this.update();        
    }

    Door.prototype.createPackage = function(){
        var package = {points:[]};
        for(var i = 0;i < this.points.length;i++){
            package.points.push(this.points[i].getPoint());
        }
        for(var i = 0;i < this.packageParameters.length;i++){
            package[this.packageParameters[i]] = this[this.packageParameters[i]];
        }
        package.controller = "architect";
        package.packageType = "modify door";
        return package;
    }

    Door.prototype.loadPackage = function(package){
        // It doesn't matter if it is an undo or redo package, the impact is to reset the object to a former state
        for(var i = 0;i < this.points.length;i++){
            this.points[i].updatePosition(package.points[i].x,package.points[i].y);
        }
        for(var i = 0;i < this.packageParameters.length;i++){
            this[this.packageParameters[i]] = package[this.packageParameters[i]];
        }
        this.update();
    }

    Door.prototype.sendPackages = function(){
        // It is important to know that the undo and redo packages aren't the same.  If they are, there was no real action taken and
        // an undo or redo event will have no apparent effect
        var undo = this.undoPackage;
        var redo = this.createPackage();
        var same = true; // Used to determine whether the two packages are the same (no actual event occured)
        for(var i = 0;i < redo.points.length;i++){ // Runs through the points first as the most common event changes
            if(undo.points[i].x != redo.points[i].x || undo.points[i].y != redo.points[i].y){
                same = false;
                break; // breaks as soon as a single difference is found
            }
        }       
        if(same){ // No need to start second loop if a difference was already found
            for(var i = 0;i < this.packageParameters.length;i++){
                if(undo[this.packageParameters[i]] != redo[this.packageParameters[i]]){
                    same = false;
                    break;
                }
            }
        }
        // Packages are sent essentially simultaneously to prevent having mismatched packages if the action isn't finalized
        if(same == false){
            this.state.addUndoPackage(undo);
            this.state.addRedoPackage(redo);
        }
    }

    Door.prototype.save = function(){
        var saveFile = {points:[]}
        for(var i = 0;i < this.points.length;i++){
            saveFile.points.push(this.points[i].getSavePoint());
        }
        for(var i = 0;i < this.packageParameters.length;i++){
            saveFile[this.packageParameters[i]] = this[this.packageParameters[i]];
        }
        return saveFile
    }

    Door.prototype.load = function(saveFile){
        // Note that this method assumes that the create function has not been called - will not work if it has been
        for(var i = 0;i < saveFile.points.length;i++){
            this.points.push(new point(saveFile.points[i].x,saveFile.points[i].y,saveFile.points[i].id));
        }
        for(var i = 0;i < this.packageParameters.length;i++){
            this[this.packageParameters[i]] = saveFile[this.packageParameters[i]];
        }
        this.createSVG(); 
        this.addLabels();
        this.update();
    }

// ##########################################  Drag and Move Functions  #############################################

    Door.prototype.startDrag = function(){
        var wall = this.wall;
        this.undoPackage = this.createPackage();
        // The following creates a distance offset for better dragging of the door opening
        var coords = this.map.pointerCoords();
        var A1 = coords.x - wall.points[0].x;
        var L1 = wall.points[0].y - coords.y;
        var H1 = Math.sqrt(Math.pow(A1,2)+Math.pow(L1,2));
        var theta2 = Math.atan2(L1,A1);
        var theta3 = wall.angle - theta2;
        var dist = H1 * Math.cos(theta3);
        this.doorDragDist = dist - this.dist;
    }

    Door.prototype.drag = function(){  // Handler for the mouse drag of the door entrance (moves the location of the door)
        // This function adjusts the distance of the door entrance from the starting point of the wall.  This is calculated based on the distance of a perpendicular
        // line from the mouse pointer to the wall where the distance is the distance from the wall start to the wall's intersection with this line.
        var wall = this.wall;
        var coords = this.map.pointerCoords();
        var A1 = coords.x - wall.points[0].x;
        var L1 = wall.points[0].y - coords.y;
        var H1 = Math.sqrt(Math.pow(A1,2)+Math.pow(L1,2));
        var theta2 = Math.atan2(L1,A1);
        var theta3 = wall.angle - theta2;
        var dist = H1 * Math.cos(theta3);
        this.dist = this.map.snapRound(dist - this.doorDragDist,1);
        this.update();
    }

    Door.prototype.finalizeDrag = function(){

        this.sendPackages();
    }

    Door.prototype.keyCommand = function(direction){ // Handler for keyboard commands, primarily the arrow keys
        this.undoPackage = this.createPackage();
        switch(direction){
            case "up":
                this.width += this.moveStep;
            break;
            case "down":
                this.width -= this.moveStep;
            break;
            case "left":
                this.dist -= this.moveStep;
            break;
            case "right":
                this.dist += this.moveStep;
            break;
        }
        this.update();
        this.sendPackages(); 
    }

// ##########################################  Object SVG Functions  ##################################################################

    Door.prototype.createSVG = function(){
        // Bear in mind that this element is simply a line segment with a width equivalent to the wall's and not a closed polygon itself
        var doorEntrance = document.createElementNS('http://www.w3.org/2000/svg', 'path');
        doorEntrance.setAttribute('d',this.setPoints());
        doorEntrance.setAttribute('id',"a"+this.id);
        doorEntrance.setAttribute('class',"architect wall door");
        doorEntrance.setAttribute('style',"stroke-linecap:"+"butt"+";stroke:"+this.color+";stroke-width:"+this.lineWidth);
        $('#doorEntrance').append(doorEntrance);
        this.entrance = $("#a"+this.id);
        
        
        this.endCapNearExt = this.createEndCapSVG("d"+this.id,this.lineWidth,"black");
        this.endCapNearInt = this.createEndCapSVG("e"+this.id,this.lineWidth*1-1,"darkgray");
        this.endCapFarExt = this.createEndCapSVG("f"+this.id,this.lineWidth,"black");
        this.endCapFarInt = this.createEndCapSVG("g"+this.id,this.lineWidth*1-1,"darkgray");
        
        this.updateEndCaps();

        if(this.door.active == true){ // If open doors are toggled for the wall, this will draw the open door
            this.drawOpenDoor();
        }
    }

    Door.prototype.drawOpenDoor = function(){ // Creates the open door svg object and appends it to the "doors" layer
        var doorpath = this.calculateOpenDoor();
        switch(this.style){
            case 2:
                var door2 = document.createElementNS('http://www.w3.org/2000/svg', 'path');
                door2.setAttribute('d',doorpath.door2);
                door2.setAttribute('id',"h"+this.id);
                door2.setAttribute('class',"architect wall door");
                door2.setAttribute('style',"stroke-linecap:"+"square"+";stroke:"+this.door.color+";fill:"+this.door.fillColor+";stroke-width:.5");
                $('#doors').append(door2);
                this.door2 = $("#h"+this.id);

                // var arc2 = document.createElementNS('http://www.w3.org/2000/svg', 'path');
                // arc2.setAttribute('d',doorpath.arc);
                // arc2.setAttribute('id',"i"+this.id);
                // arc2.setAttribute('class',"architect wall door");
                // arc2.setAttribute('style',"stroke-linecap:"+"butt"+";stroke:gray;stroke-width:1;fill:none");
                // $('#doorEntrance').append(arc2);
                //this.arc2 = $("#i"+this.id);

            case 0:
            case 1:
                var door = document.createElementNS('http://www.w3.org/2000/svg', 'path');
                door.setAttribute('d',doorpath.door);
                door.setAttribute('id',"b"+this.id);
                door.setAttribute('class',"architect wall door");
                door.setAttribute('style',"stroke-linecap:"+"square"+";stroke:"+this.door.color+";fill:"+this.door.fillColor+";stroke-width:.5");
                $('#doors').append(door);
                this.door1 = $("#b"+this.id);

                if(this.style != 2){
                    var arc = document.createElementNS('http://www.w3.org/2000/svg', 'path');
                    arc.setAttribute('d',doorpath.arc);
                    arc.setAttribute('id',"c"+this.id);
                    arc.setAttribute('class',"architect wall door");
                    arc.setAttribute('style',"stroke-linecap:"+"butt"+";stroke:gray;stroke-width:1;fill:none");
                    $('#doorEntrance').append(arc); 
                    this.arc1 = $("#c"+this.id);                   
                }
            break;
        }
    }

    Door.prototype.createEndCapSVG = function(id,lineWidth,color){ // Creates an endcap path SVG object representing a door endcap/frame
        var wallLayer = document.createElementNS('http://www.w3.org/2000/svg', 'path');
        wallLayer = document.createElementNS('http://www.w3.org/2000/svg', 'path');
        wallLayer.setAttribute('id',id);
        wallLayer.setAttribute('class',"architect wall door");
        wallLayer.setAttribute('style',"stroke-linecap:"+"butt"+";stroke:"+color+";stroke-width:"+lineWidth);
        $('#doorJam').append(wallLayer);
        return $("#"+id);
    }

    Door.prototype.setPoints = function(){ // Finds the start and end point for the door entrance based on the set distance and wall points
        // Used by updateEntrance
        // Mathematically, this is simply getting the x and y components of a right triangle made by the x axis and the angle of the wall
        // The hypotenuses are the distance from the start of the wall and then that plus the width of the door
        // Returns the path for drawing the door entrance
        var wall = this.wall;
        this.points[0].updatePosition(
            this.dist * Math.cos(wall.angle)+wall.points[0].x,
            -this.dist * Math.sin(wall.angle)+wall.points[0].y
            );
        this.points[1].updatePosition(
            (this.dist + this.width) * Math.cos(wall.angle)+wall.points[0].x,
            -(this.dist + this.width) * Math.sin(wall.angle)+wall.points[0].y
            );

        var path = "";
        path += "M " + this.points[0].x + " " + this.points[0].y;
        path += "L " + this.points[1].x + " " + this.points[1].y;       
        return path;
    }

    Door.prototype.calculateOpenDoor = function(){ // Calculates the path of a door and respective swing arc, updates the arc, and returns the door path
        var startX = this.points[0].x;
        var startY = this.points[0].y;
        var endX = this.points[1].x;
        var endY = this.points[1].y;
        
        // Angle Measures
        var theta1 = this.wall.angle; // Angle of the wall the door is placed on
        var theta2a = this.door.angle;  // Positive angle when the door origin is angled from the start end of the wall
        var theta2b = -this.door.angle; // Angle for double door
        var theta2c = this.door.angle-Math.PI; // Negative angle when the door origin is angled away from the start of the wall
        var theta3 = Math.PI/2+theta1 // Angle of line perpendicular to the wall relative to x-axis
        var theta4a = (theta1 + theta2a - Math.PI/2); // Angle of line perpendicular to open door
        var theta4b = (theta1 + theta2b - Math.PI/2); // Angle of line perpendicular to open door
        var theta4c = (theta1 + theta2c - Math.PI/2); // Angle of line perpendicular to open door

        // Distance Measures
        var dx = ((this.lineWidth-.5)/2) * Math.cos(theta3); // distance to move to the corner of the door frame
        var dy = -((this.lineWidth-.5)/2) * Math.sin(theta3);
        if(this.style == 0){
            var dx2a = this.width * Math.cos(theta1+theta2a);  // (theta1 + theta2 is the angle of the door relative to x-axis)
            var dy2a = -this.width * Math.sin(theta1+theta2a); // distance to move to the other end of the door (lenth-wise)
        } else {
            var dx2a = this.width/2 * Math.cos(theta1+theta2a);  // (theta1 + theta2 is the angle of the door relative to x-axis)
            var dy2a = -this.width/2 * Math.sin(theta1+theta2a); // distance to move to the other end of the door (lenth-wise)            
        }
        var dx2b = this.width/2 * Math.cos(theta1+theta2b);  // (theta1 + theta2 is the angle of the door relative to x-axis)
        var dy2b = -this.width/2 * Math.sin(theta1+theta2b); // distance to move to the other end of the door (lenth-wise)
        var dx2c = this.width * Math.cos(theta1+theta2c);  // (theta1 + theta2 is the angle of the door relative to x-axis)
        var dy2c = -this.width * Math.sin(theta1+theta2c); // distance to move to the other end of the door (lenth-wise)
        var dx3a = (this.lineWidth/2-.5) * Math.cos(theta4a); // distance to move to the opposite width-wise edge of the door
        var dy3a = -(this.lineWidth/2-.5) * Math.sin(theta4a);
        var dx3b = (this.lineWidth/2-.5) * Math.cos(theta4b); // distance to move to the opposite width-wise edge of the door
        var dy3b = -(this.lineWidth/2-.5) * Math.sin(theta4b);
        var dx3c = (this.lineWidth/2-.5) * Math.cos(theta4c); // distance to move to the opposite width-wise edge of the door
        var dy3c = -(this.lineWidth/2-.5) * Math.sin(theta4c);

        // Door SVG path based on orientation and swing direction
        var path = {};
        if(Math.sin(this.door.angle)>=0){
            path.door = "M " + startX + " " + startY + " m " +  dx + " " + dy + " l " + dx2a + " " + dy2a + " l " + dx3a + " " + dy3a + " l " + -dx2a + " " + -dy2a + " l " + -dx3a + " " + -dy3a;
            path.door2 = "M " + endX + " " + endY + " m " +  dx + " " + dy + " l " + -dx2b + " " + -dy2b + " l " + dx3b + " " + dy3b + " l " + dx2b + " " + dy2b + " l " + -dx3b + " " + -dy3b;
            path.door3 = "M " + endX + " " + endY + " m " +  dx + " " + dy + " l " + -dx2c + " " + -dy2c + " l " + dx3c + " " + dy3c + " l " + dx2c + " " + dy2c + " l " + -dx3c + " " + -dy3c;
        }else{
            path.door = "M " + startX + " " + startY + " m " +  -dx + " " + -dy + " l " + dx2a + " " + dy2a + " l " + -dx3a + " " + -dy3a + " l " + -dx2a + " " + -dy2a + " l " + dx3a + " " + dy3a;
            path.door2 = "M " + endX + " " + endY + " m " +  -dx + " " + -dy + " l " + -dx2b + " " + -dy2b + " l " + -dx3b + " " + -dy3b + " l " + dx2b + " " + dy2b + " l " + dx3b + " " + dy3b;
            path.door3 = "M " + endX + " " + endY + " m " +  -dx + " " + -dy + " l " + -dx2c + " " + -dy2c + " l " + -dx3c + " " + -dy3c + " l " + dx2c + " " + dy2c + " l " + dx3c + " " + dy3c;
        }

        switch(this.style){
            case 0:
            case 2:
                if(Math.sin(this.door.angle)>=0){
                    this.points[2].updatePosition(startX + dx + dx2a + dx3a/2,startY + dy + dy2a + dy3a/2);
                } else {
                    this.points[2].updatePosition(startX - dx + dx2a - dx3a/2,startY - dy + dy2a - dy3a/2);
                }
            break;
            case 1:
                if(Math.sin(this.door.angle)>=0){
                    this.points[2].updatePosition(endX + dx - dx2c + dx3c/2,endY + dy - dy2c + dy3c/2);
                } else {
                    this.points[2].updatePosition(endX - dx - dx2c - dx3c/2,endY - dy - dy2c - dy3c/2);
                }
                path.door = path.door3;
            break;
        }


        // Offsets for use in drawing the arc (helps match the arc endpoints better)
        switch(this.style){
            case 0:
                var dx2Modified1 = (this.width+.5) * Math.cos(theta1);
                var dy2Modified1 = -(this.width+.5) * Math.sin(theta1);
                var dx2Modified2 = (this.width-.5) * Math.cos(theta1+theta2a);
                var dy2Modified2 = -(this.width-.5) * Math.sin(theta1+theta2a);
            break;
            case 1:
                var dx2Modified1 = (this.width+.5) * Math.cos(theta1);
                var dy2Modified1 = -(this.width+.5) * Math.sin(theta1);
                var dx2Modified2 = (this.width-.5) * Math.cos(theta1+theta2c);
                var dy2Modified2 = -(this.width-.5) * Math.sin(theta1+theta2c);
            break;
            case 2:

            break;         
        }

        // Determines the start and end-point for the arc based on the door measures and angles
        switch(this.style){
            case 0:
                dx3Modified = dx3a;
                dy3Modified = dy3a;
                if(Math.sin(this.door.angle)>=0){
                    var startArcX = startX + dx + dx2Modified1;
                    var startArcY = startY + dy + dy2Modified1;
                    var endArcX = startX + dx + dx2Modified2 + dx3Modified;
                    var endArcY = startY + dy + dy2Modified2 + dy3Modified;
                } else {
                    var startArcX = startX + -dx + dx2Modified1;
                    var startArcY = startY + -dy + dy2Modified1;
                    var endArcX = startX + -dx + dx2Modified2 + -dx3Modified;
                    var endArcY = startY + -dy + dy2Modified2 + -dy3Modified;
                }
            break;
            case 1:
                dx3Modified = dx3c;
                dy3Modified = dy3c;                
                if(Math.sin(this.door.angle)>=0){
                    var startArcX = endX + dx + -dx2Modified1;
                    var startArcY = endY + dy + -dy2Modified1;
                    var endArcX = endX + dx + -dx2Modified2 + dx3Modified;
                    var endArcY = endY + dy + -dy2Modified2 + dy3Modified;
                } else {
                    var startArcX = endX + -dx + -dx2Modified1;
                    var startArcY = endY + -dy + -dy2Modified1;
                    var endArcX = endX + -dx + -dx2Modified2 + -dx3Modified;
                    var endArcY = endY + -dy + -dy2Modified2 + -dy3Modified;
                }
            break;
        }

        switch(this.style){
            case 0:
                if(Math.sin(this.door.angle)>=0){
                    path.arc = "M " + startArcX + " " + startArcY + " A " + this.width + " " + this.width + ", 0, 0, 0, " + endArcX + " " + endArcY;
                } else {
                    path.arc = "M " + startArcX + " " + startArcY + " A " + this.width + " " + this.width + ", 0, 0, 1, " + endArcX + " " + endArcY;
                }
            break;
            case 1:
                if(Math.sin(this.door.angle)>=0){
                    path.arc = "M " + startArcX + " " + startArcY + " A " + this.width + " " + this.width + ", 0, 0, 1, " + endArcX + " " + endArcY;
                } else {
                    path.arc = "M " + startArcX + " " + startArcY + " A " + this.width + " " + this.width + ", 0, 0, 0, " + endArcX + " " + endArcY;
                }
            break;
        }
               
        return path;
    }

    Door.prototype.updateEndCaps = function(){  // Recalculates points and then recreates and applies the endcaps' svg paths
        var wall = this.wall;
        // Near endcap
        // (exterior)
        this.endCapPoints[0].x = (this.dist - 3) * Math.cos(wall.angle)+wall.points[0].x;
        this.endCapPoints[0].y = -(this.dist - 3) * Math.sin(wall.angle)+wall.points[0].y;
        this.endCapPoints[1].x = (this.dist + 0) * Math.cos(wall.angle)+wall.points[0].x;
        this.endCapPoints[1].y = -(this.dist + 0) * Math.sin(wall.angle)+wall.points[0].y;
        // (interior)
        this.endCapPoints[2].x = (this.dist - 2.5) * Math.cos(wall.angle)+wall.points[0].x;
        this.endCapPoints[2].y = -(this.dist - 2.5) * Math.sin(wall.angle)+wall.points[0].y;
        this.endCapPoints[3].x = (this.dist - .5) * Math.cos(wall.angle)+wall.points[0].x;
        this.endCapPoints[3].y = -(this.dist - .5) * Math.sin(wall.angle)+wall.points[0].y;
        
        // Far endcap
        // (exterior)
        this.endCapPoints[4].x = (this.dist + this.width + 0) * Math.cos(wall.angle)+wall.points[0].x;
        this.endCapPoints[4].y = -(this.dist +this.width + 0) * Math.sin(wall.angle)+wall.points[0].y;
        this.endCapPoints[5].x = (this.dist + this.width + 3) * Math.cos(wall.angle)+wall.points[0].x;
        this.endCapPoints[5].y = -(this.dist +this.width + 3) * Math.sin(wall.angle)+wall.points[0].y;
        // (interior)
        this.endCapPoints[6].x = (this.dist + this.width + .5) * Math.cos(wall.angle)+wall.points[0].x;
        this.endCapPoints[6].y = -(this.dist +this.width + .5) * Math.sin(wall.angle)+wall.points[0].y;
        this.endCapPoints[7].x = (this.dist + this.width + 2.5) * Math.cos(wall.angle)+wall.points[0].x;
        this.endCapPoints[7].y = -(this.dist +this.width + 2.5) * Math.sin(wall.angle)+wall.points[0].y;

        var path = "";
        path = "M "+this.endCapPoints[0].x+" "+this.endCapPoints[0].y+" L "+this.endCapPoints[1].x+" "+this.endCapPoints[1].y;
        this.endCapNearExt.attr({d:path}); // Exterior near endcap
        path = "M "+this.endCapPoints[2].x+" "+this.endCapPoints[2].y+" L "+this.endCapPoints[3].x+" "+this.endCapPoints[3].y;
        this.endCapNearInt.attr({d:path}); // Interior near endcap
        path = "M "+this.endCapPoints[4].x+" "+this.endCapPoints[4].y+" L "+this.endCapPoints[5].x+" "+this.endCapPoints[5].y;
        this.endCapFarExt.attr({d:path}); // Exterior far endcap
        path = "M "+this.endCapPoints[6].x+" "+this.endCapPoints[6].y+" L "+this.endCapPoints[7].x+" "+this.endCapPoints[7].y;
        this.endCapFarInt.attr({d:path}); // Interior far endcap 
    }

    Door.prototype.updateSVG = function(){
        this.entrance.attr({d: this.setPoints()}) // Posts the new path string to the door entrance element
        var doorpath = this.calculateOpenDoor();
        this.door1 ? this.door1.attr({d:doorpath.door}) : null; // Updates the door itself if set to show it  
        this.arc1 ? this.arc1.attr({d:doorpath.arc}) : null; // Updates the door arc if set to show it
        this.door2 ? this.door2.attr({d:doorpath.door2}) : null; // Updates the double door itself if set to show it  
        this.updateEndCaps(); // Updates the door frame       
    }

    Door.prototype.removeSVG = function(){
        this.entrance ? this.entrance.remove() : null;
        this.door1 ? this.door1.remove() : null;
        this.door2 ? this.door2.remove() : null;
        this.arc1 ? this.arc1.remove() : null;
        this.arc2 ? this.arc2.remove() : null;
        this.endCapNearExt ? this.endCapNearExt.remove() : null;
        this.endCapNearInt ? this.endCapNearInt.remove() : null;
        this.endCapFarExt ? this.endCapFarExt.remove() : null;
        this.endCapFarExt ? this.endCapFarInt.remove() : null;
    }

// ##########################################  Distance Labels Functions  ######################################################################

    Door.prototype.setLabelStyle = function(styleNumber){ // Changes the display behavior of the distance labels based on a style number from a slider
        var wall = this.wall;
        if(styleNumber != undefined){
            this.labelStyle = styleNumber;
        }
        switch(this.labelStyle){
            case 0: // Never show labels
                this.removeLabels();
            break;
            case 1: // Only show window width when selected
                if(this.isSelected == true){
                    this.labels[0].redraw(wall);
                    this.labels[1].remove();
                    this.labels[2].remove();
                } else {
                   this.removeLabels(); 
                }
            break;
            case 2: // Only show labels when selected (default)
                if(this.isSelected == true){
                    this.labels[0].redraw(wall);
                    this.labels[1].redraw(wall);
                    this.labels[2].redraw(wall);
                } else {
                   this.removeLabels(); 
                }
            break;
            case 3: // Always show window label, hide sides when not selected
                if(this.isSelected == true){
                    this.labels[0].redraw(wall);
                    this.labels[1].redraw(wall);
                    this.labels[2].redraw(wall);
                } else {
                    this.labels[0].redraw(wall);
                    this.labels[1].remove();
                    this.labels[2].remove();
                }
            break;
            case 4: // Always show all labels
                    this.labels[0].redraw(wall);
                    this.labels[1].redraw(wall);
                    this.labels[2].redraw(wall);
            break;
        }
        return this.labelStyle;
    }

    Door.prototype.removeLabels = function(){ // Removes the label svg elements for any active label objects
        for(var i = 0;i < this.labels.length;i++){
            this.labels[i].remove();
        }
    }

    Door.prototype.addLabels = function(){ // Adds all three width label objects and their respective svg elements
        var wall = this.wall;
        var id = generateUUID();
        var path = "c"+wall.id; // Targets the center line path portion of the wall
        
        var textLabel = this.renderLength(this.width);
        var xOffset = 100*(this.dist+this.width/2)/wall.length+"%";
        this.labels[0] = new WallTextLabel("0"+id,this.labelColor,this.labelFontSize,path,xOffset,this.labelFontSize);
        this.labels[0].draw();
        this.labels[0].setText(textLabel,wall,xOffset)
        
        textLabel = this.renderLength(this.dist);
        xOffset = 100*(this.dist/wall.length)/2+"%";
        this.labels[1] = new WallTextLabel("1"+id,this.labelColor,this.labelFontSize,path,xOffset,this.labelFontSize);
        this.labels[1].draw();
        this.labels[1].setText(textLabel,wall,xOffset)
        
        textLabel = this.renderLength(wall.length-(this.dist+this.width));
        var endDist = wall.length - (this.dist + this.width);
        xOffset = 100*(this.dist+this.width+endDist/2)/wall.length+"%";
        this.labels[2] = new WallTextLabel("2"+id,this.labelColor,this.labelFontSize,path,xOffset,this.labelFontSize);
        this.labels[2].draw();
        this.labels[2].setText(textLabel,wall,xOffset)
    }

    Door.prototype.updateWidthLabel = function(){  // Repositions the width labels based on the position of the door relative to the wall ends
        var wall = this.wall;
        var textLabel = this.renderLength(this.width);
        var xOffset = 100*(this.dist+this.width/2)/wall.length+"%";
        this.labels[0].setText(textLabel,wall,xOffset,this.labelFontSize/1.5+10)
  
        textLabel = this.renderLength(this.dist);
        xOffset = 100*(this.dist/wall.length)/2+"%";
        if(xOffset.slice(0,-1) < 10){
            xOffset = xOffset.slice(0,-1)/2+"%";
            if(wall.isInverted()){
                this.labels[1].changeAnchor("end");
            } else {
                this.labels[1].changeAnchor("start");
            }
            this.labels[1].setText(textLabel,wall,xOffset,-this.labelFontSize/5-5);
        } else {
            this.labels[1].changeAnchor("middle");
            this.labels[1].setText(textLabel,wall,xOffset,this.labelFontSize/1.5+10);
        }

        textLabel = this.renderLength(wall.length-(this.dist+this.width));
        var endDist = wall.length - (this.dist + this.width);
        xOffset = 100*(this.dist+this.width+endDist/2)/wall.length+"%";
        if(xOffset.slice(0,-1) > 90){
            xOffset = (xOffset.slice(0,-1)*1 + 1*(100-xOffset.slice(0,-1))/2)+"%";
            if(wall.isInverted()){
                this.labels[2].changeAnchor("start");
            } else {
                this.labels[2].changeAnchor("end");
            }
            this.labels[2].setText(textLabel,wall,xOffset,-this.labelFontSize/5-5);
        } else {
            this.labels[2].changeAnchor("middle");
            this.labels[2].setText(textLabel,wall,xOffset,this.labelFontSize/1.5+10);
        }
    }

// ##########################################  Selector Interface Functions  ######################################################################

    Door.prototype.setProperty = function(property,value){
        switch(property){
            case "objectStyle":
                this.setObjectStyle(value);
            break;  
            case "objectLength":
                this.setobjectLength(value);
            break;
            case "objectDist":
                this.setobjectDist(value);
            break;
            case "objectAngle":
                this.setobjectAngle(toRads(value));
            break;
            case "objectStrokeColor":
                this.setobjectStrokeColor(value);
            break;
            case "objectFillColor":
                this.setobjectFillColor(value);
            break;
            case "objectAreaColor":
                this.setobjectAreaColor(value);
            break;
            case "objectLabelStyle":
                this.setLabelStyle(value);
            break;            
            case "objectLabelColor":
                this.labels[0].setColor(value);
                this.labels[1].setColor(value);
                this.labels[2].setColor(value);
            break;
            case "objectLabelSize":
                this.labelFontSize = value;
                this.labels[0].setFontSize(value);
                this.labels[1].setFontSize(value);
                this.labels[2].setFontSize(value);
                this.updateWidthLabel();
            break;
            case "objectDoorToggle":
                this.setOpenDoor(value);
            break;
            case "objectHingeDirection":
                this.setobjectHingeDirection(value);
            break;
        }
    }

    Door.prototype.getObjectData = function(){  // This function is called when the user selects a wall object
        var thisData = {};
        thisData.data = {
            objectType: {type:"label",value:"Door"},
            objectLength: {type:"spinner",value:this.renderLength(this.width)},
            objectDist: {type:"spinner",value:this.renderLength(this.dist)},
            objectAngle: {type:"spinner",value:toDeg(this.door.angle)},
            objectStrokeColor: {type:"color",value:this.door.color},
            objectFillColor: {type:"color",value:this.door.fillColor},
            objectAreaColor: {type:"color",value:this.color},
            objectStyleText: {type:"na",value:Door.prototype.styleSlide(null,{value:this.style})},
            objectStyle: {type:"slider",value:this.style,min:0,max:2,slide:Door.prototype.styleSlide},
            objectLabelStyleText: {type:"na",value:Door.prototype.slide(null,{value:this.labelStyle})},
            objectLabelStyle: {type:"slider",value:this.labelStyle,min:0,max:4,slide:Door.prototype.slide},
            objectLabelColor: {type:"color",value:this.labelColor},
            objectLabelSize: {type:"spinner",value:this.labelFontSize},            
            objectDoorToggle: {type:"switch",value:this.door.active},
            objectDoorArcToggle: {type:"switch",value:true},
        }
        thisData.dividers = {
            sizeDivider:true,
            positionDivider:true,
            styleDivider:true,
            colorDivider:true,
            labelsDivider:true,
            doorsDivider:true,
        }
        return thisData;
    }

    Door.prototype.setObjectStyle = function(value){
        this.door1 ? this.door1.remove() : null; // Open door
        this.door2 ? this.door2.remove() : null; // Open door
        this.arc1 ? this.arc1.remove() : null; // Main Arc
        this.style = value;
        this.drawOpenDoor();
    }

    Door.prototype.slide = function(event,ui){
            var message = "";
            switch(ui.value){
                case 0:
                message = "No Labels"
                break;
                case 1:
                message = "Show Width Label on Select"
                break;
                case 2:
                message = "Show All Labels on Select"
                break;
                case 3:
                message = "Always Show Width Label"
                break;
                case 4:
                message = "Always Show All Labels"
                break;
            }
            $( "#objectLabelStyleText" ).html(message);
    }

    Door.prototype.styleSlide = function(event,ui){
            var message = "";
            switch(ui.value){
                case 0:
                message = "Near Hinge"
                break;
                case 1:
                message = "Far Hinge"
                break;
                case 2:
                message = "Double Door"
                break;
            }
            $("#objectStyleText").html(message);
    }

    Door.prototype.setobjectLength = function(length){ // Sets the length of the door, which modifies the door width property
        this.width = length;
        this.update(); // Redraws the door area based on the new width parameters
    }

    Door.prototype.setobjectWidth = function(){ // Function is called when the width of the wall is changed
        // It updates all of the necessary line width measurements and redraws the screen objects
        this.lineWidth = this.wall.outerWidth;
        this.door.lineWidth = this.lineWidth/2;
        this.remove();
        this.redraw();
        this.update();
    }

    Door.prototype.setobjectDist = function(dist){ // Sets the distance of the start of the door from the start of the wall
        this.dist = dist;
        this.update(); // Redraws the door area based on the new width parameters
        return this.dist; // Returns the final width of the door, which will be updated in the input box
    }

    Door.prototype.setobjectAngle = function(angle){ // Sets the angle for the open door
        if(!isNumeric(angle)){ // Checks the entered value to ensure it is a number and falls within the permitted range
            message.system("Non-numeric value entered. Please enter a valid number.")
        } else if (angle<-Math.PI){
            this.door.angle = -Math.PI;
        } else if(angle>Math.PI){
            this.door.angle = Math.PI;
        } else {
            this.door.angle = angle;
        }
        this.update(); // Redraws the door area based on the new width parameters
        return this.door.angle;
    }

    Door.prototype.setobjectStrokeColor = function(color){  // Sets the color of the stroke outline for the open door
        var isOk  = /(^#[0-9A-F]{6}$)|(^#[0-9A-F]{3}$)/i.test(color)
        if(isOk){
            this.door.color = color;
        } else {
            console.log("color not recognized")
        }
        this.door1 ? this.door1.css("stroke",this.door.color) : null;
        this.door2 ? this.door2.css("stroke",this.door.color) : null;
        return this.door.color;
    }

    Door.prototype.setobjectFillColor = function(color){  // Sets the color of the door entrance
        var isOk  = /(^#[0-9A-F]{6}$)|(^#[0-9A-F]{3}$)/i.test(color)
        if(isOk){
            this.door.fillColor = color;
        } else {
            console.log("color not recognized")
        }
        this.door1 ? this.door1.css("fill",this.door.fillColor) : null;
        this.door2 ? this.door2.css("fill",this.door.fillColor) : null;
        return this.door.fillColor;
    }

    Door.prototype.setobjectAreaColor = function(color){ // Sets the color of the fill for the open door
        var isOk  = /(^#[0-9A-F]{6}$)|(^#[0-9A-F]{3}$)/i.test(color)
        if(isOk){
            this.color = color;
        } else {
            console.log("color not recognized")
        }
        this.entrance ? this.entrance.css("stroke",this.color) : null;
        return this.color;
    }

    Door.prototype.setOpenDoor = function(active){ // Sets whether the door is visible based on a boolean input
        // This is useful since a wall will sometimes pass an active/inactive value to each of its doors
        this.door.active = active;
        if(this.door.active == true){ // If open doors are toggled for the wall, this will draw the open door
            this.drawOpenDoor();
            if(this.isSelected){
                this.drawHandles();
            }
        } else { // Removes the door if the door is currently active
            this.door1 ? this.door1.remove() : null;
            this.door2 ? this.door2.remove() : null;
            this.arc1 ? this.arc1.remove() : null;
            this.points[2].removeHandle();
        }
        this.update();
    }

    Door.prototype.setobjectHingeDirection = function(direction){ // Changes which direction the door is drawn from, effectively switching hinges
        if(direction == 0){
            this.door.orientation = "near";
        } else {
            this.door.orientation = "far";
        }
        this.update();
    }