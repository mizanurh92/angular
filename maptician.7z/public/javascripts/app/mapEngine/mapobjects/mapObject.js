//#################################  Map Object Class #####################################################
// Should be Superclass for all map objects

function MapObject(type,id){
	this.type = type;
	this.id = id;
	this.handleDragging = "";
	this.isSelected = false;
    this.snapSensitivity = 12;
}

MapObject.prototype.getBorderBox = function(){ // Note that the buffer box for an area is the same as its standard area,
    var xArray = [];
    var yArray = [];
    var pointsLen = this.points.length;
    for(var i = 0;i < pointsLen;i++){
        xArray.push(this.points[i].x);
        yArray.push(this.points[i].y);            
    }
    return {xArray:xArray,yArray:yArray};
}

MapObject.prototype.shiftPosition = function(shiftLeft,shiftUp){
    var keys = Object.keys(this.points);
    var len = keys.length;
    var key,current;
    for(var i = 0;i < len;i++){
        try{
            key = keys[i];
            current = this.points[key];
            current.shiftPosition(shiftLeft,shiftUp);                
        } catch(err){
            console.log(err);
        }
    }
    this.update();
}

// Default function for obtaining snap points for an object.  This should work for most rectangular objects where
// their points are limited to those at the perimeter.  See wall object for example of how to establish a perimeter
// with a subset of an object's points.
MapObject.prototype.getSnapPoints = function(dist){
    if(this.points.length == 0){return;}
    var sensitivity = dist || this.snapSensitivity || 12;
    var snapObject = {
        snapPoints: [],
        bufferBox: [],
        snapEdges: []
    }
    var points = this.points; // Assumes all points are valid perimeter points
    // Assumes object is rectangular with Angle 0 at the horizontal towards the right
    // Also assumes that at an angle of 0, the corners are numbers clockwise starting from the upper left corner [0]
    var theta = this.angle + 5*Math.PI/4;
    var currentPoint;
    for(var i = 0;i < 4;i++){
        theta -= Math.PI/2;
        currentPoint = {x:points[i].x,y:points[i].y};
        snapObject.snapPoints.push({x:currentPoint.x,y:currentPoint.y});
        snapObject.bufferBox.push({
            x:currentPoint.x + sensitivity * Math.cos(theta),
            y:currentPoint.y - sensitivity * Math.sin(theta)
        });          
    }
    for(var i = 0;i<4;i++){ // Finds the edges between the snap points above
        snapObject.snapEdges.push({
            start:copyPoint(snapObject.snapPoints[i]),
            end:copyPoint(snapObject.snapPoints[(i+1)%4])
        });
    }
    return snapObject;        
}

MapObject.prototype.renderLength = function(val,options){
    options = options || {};
    options.system = $Map.unit() || 'US';
    return renderLength(val,options)
}

MapObject.prototype.renderArea = function(val,options){
    options = options || {};
    options.system = $Map.unit() || 'US';
    options.svg = options.svg || false;
    return renderArea(val,options)
}

MapObject.prototype.getObjectViewerData = function(subcategory,id){
    var thisData = {};
    thisData.data = {
        vObjectType: {type:"label",value:this.type},
    }
    thisData.dividers = {

    }
    return thisData;        
}