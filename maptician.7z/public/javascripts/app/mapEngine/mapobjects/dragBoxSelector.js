//#################################  Drag Box Selector #####################################################


function DragBoxSelector(id,controllers,state){
    MapObject.call(this,"dragBox",id);
    this.controllers = controllers;
    this.state = state;
    this.dragBox = null; // alias to the svg
    this.fill = "#4cbeff";  // Fill Color
    this.stroke = "#4cbeff";  // Stroke Color
    this.lineWidth = 1;  // Width of the line stroke
    this.points = [{x:0,y:0},{x:0,y:0}];
}
    DragBoxSelector.prototype.create = function(map){ // This creates all components of the elevator object
        var pos = map.pointerCoords();
        this.points[0] = new point(pos.x,pos.y,"DBS"+this.id); // Start
        this.points[1] = new point(pos.x,pos.y,"DBE"+this.id); // End
        this.createBox();
    }
    DragBoxSelector.prototype.update = function(){
        this.updateBox();
    }
    DragBoxSelector.prototype.remove = function(){
        this.dragBox.remove();
    }
    DragBoxSelector.prototype.createBox = function(){
        var dragBox = document.createElementNS('http://www.w3.org/2000/svg', 'path');
        dragBox.setAttribute('d',this.getBoxPath());
        dragBox.setAttribute('id',this.id);
        dragBox.setAttribute('pointer-events',"none");
        dragBox.setAttribute('style',"stroke-linecap:square;stroke:"+this.stroke+";fill:"+this.fill+";fill-opacity:.2;stroke-width:"+this.lineWidth);
        $('#topGroup').append(dragBox);
        this.dragBox = $("#" + this.id);
    }
    DragBoxSelector.prototype.getBoxPath = function(){
        var path = ""
        path += "M " + this.points[0].x + " " + this.points[0].y; // Start point at upper left of the elevator
        path += "L " + this.points[0].x + " " + this.points[1].y;  // Point at the upper right
        path += "L " + this.points[1].x + " " + this.points[1].y;  // Point at the lower right
        path += "L " + this.points[1].x + " " + this.points[0].y;  // Point at the lower left
        path += "Z";  // Return and close of position
        return path;
    }
    DragBoxSelector.prototype.drawBox = function(map){  
        if(this.points.length>1){
            var pos = map.pointerCoords();
            this.points[1].updatePosition(pos.x,pos.y);
            this.update();
        }
    }
    DragBoxSelector.prototype.finalizeDraw = function(){  // To make the initial point numbers and corners consistent in all draw scenarios the
        var box = {
            top:Math.min(this.points[0].y,this.points[1].y),
            bottom:Math.max(this.points[0].y,this.points[1].y),
            left:Math.min(this.points[0].x,this.points[1].x),
            right:Math.max(this.points[0].x,this.points[1].x),
        }
        var objectFilter = {};
        var filterItems = $('#selectionFilters input').parent().filter(".checked:not(.disabled)");
        for(var i = 0;i < filterItems.length;i++){
            try{
                var dataArray = $(filterItems[i]).children("input").attr("data").split(" ");
                if(!(dataArray[0] in objectFilter)){
                    objectFilter[dataArray[0]] = []; 
                }
                if(dataArray.length>1){
                    for(var j = 1; j < dataArray.length; j++){
                        objectFilter[dataArray[0]].push(dataArray[j]);
                    }
                }
            }
            catch(err){
                console.log(err);
            }
        }
        var containedObjects = {}
        for(var j in this.controllers){
            if(!(j in objectFilter)){continue;} // If the controller select is disabled, a check isn't made
            var filterArray = objectFilter[j]; // Contains the list of object types that are drag selectable
            var objectList = this.controllers[j].getOutlinePoints(filterArray);
            var controllerObjects = [];
            for(var object in objectList){
                var contained = true;
                for(var i = 0;i < objectList[object].length;i++){
                    if(!pointInBox(box,objectList[object][i])){
                        contained = false;
                        break;
                    }
                }
                if(contained){
                    controllerObjects.push(object);
                }
            }
            if(controllerObjects.length){
                containedObjects[j] = controllerObjects;
            }           
        }
        var count = 0;
        for(var i in containedObjects){count += containedObjects[i].length;}
        
        if(count > 1){
            for(var i in containedObjects){
                for(var j in containedObjects[i]){
                    this.controllers[i].selectMultiple(containedObjects[i][j]);
                }
            }
        } else {
            for(var i in containedObjects){
                this.controllers[i].selectOne(containedObjects[i][0]);
            }            
        }
        this.remove();
    }
    DragBoxSelector.prototype.cancelDraw = function(){
        this.remove();
    }
    DragBoxSelector.prototype.updateBox = function(){
        this.dragBox.attr("d",this.getBoxPath());
    }    

