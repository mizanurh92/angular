//#################################  Seat Class #####################################################

function Seat(id,name,state,map){
	MapObject.call(this,"Seat",id); // Sets Seat as subclass of MapObject
    this.state = state; // Reference to the State Controller
    this.map = map; // Reference to the Map Controller

    this.name = name || "";  // This is the name for the specific seat, not the assigned user

    //  assignmentStatus values are 'Assigned' or 'Unassigned'.  
    //  All seats start unassigned (even assigned ones) at load and are updated during the loadSeatAssignments process
    this.assignmentStatus = 'Unassigned';
    this.imageLink = "images/blankprofile.png";
    this.user = null; // If assigned, this will hold the user data for the assigned user    
    
    // Seats default to reservable=false on creation and must be manually made reservable through the nav menu
    // A seat cannot be reservable and assigned
    this.reservable = false;
    this.reservation = null;
    this.department = {
        deptName: "Unassigned",
        deptID:"00000"
    };

	this.nameLabel = {}; // Holds the label object for the seat name
    this.statusLabel = {}; // Holds a label that displays either the assignmentStatus or the user name, if assigned

    // Formatting options
    this.width = 38;
    this.height = 38;
    this.borderColor = '#808080';
    this.borderActive = '#ff0000';
    this.textColor = '#000000';
    this.fontSize = 10;
    this.labelOrient = 0; // 0 is start, 1 is center, 2 is end
    this.labelStyle = 2; // 0 is never show, 1 is show on select, 2 is always show

    // These are populated via the connectionController and are indexed by the zoneID and roomID respectively
    this.zones = {};
    this.rooms = {};

	this.points = [];

    this.seatImage = null; // alias for svg
    this.seatBorder = null;

	this.prefix = 'SE';
	this.packageParameters = [ // Used in undo/redo/duplicate/save/load methods
        "type",
        "id",
        "name",
        "reservable",
        "textColor",
        "labelOrient",
        "fontSize",
        "labelStyle",
        "department"
    ];
    this.dataPackageParameters = [ // Used in seat database creation
        "id",
        "name",
        "reservable",
        "zones",
        "rooms",
        "department"
    ];
}
	Seat.prototype = Object.create(MapObject.prototype); // Links the prototype to the superclass
	Seat.prototype.constructor = Seat;
	
// ##########################################  Seat Assignments and Reservations  #########################################################

    // If user data is passed as an object, then the seat will show as assigned to the user indicated by the
    // userData parameter.  If no parameter is passed, then the seat becomes unassigned.
    Seat.prototype.setAssignment = function(userData,undoable){
        if(undoable !== false){ undoable = true };
        if(undoable){
            this.undoPackage = this.createPackage();
        }
        if(userData){
            this.setStatus(userData.first + ' ' + userData.last);
            this.imageLink = userData.profile || userData.profileImages.smallProfile;
            this.user = userData;
            this.assignmentStatus = "Assigned";
            $("#objectSeatAssignment").html(userData.first + ' ' + userData.last);
            this.reservable = false;
        } else {
            this.setStatus('Unassigned');
            this.imageLink = "images/blankprofile.png";
            this.user = null;
            this.assignmentStatus = "Unassigned";
            $("#objectSeatAssignment").html("Unassigned");
        }
        if(undoable){
            this.sendPackages();
        }
        this.update();
    }

    Seat.prototype.setReservation = function(reservation){
        if(this.reservable){
            this.reservation = reservation;
            var user = reservation.user;
            console.log(reservation)
            this.imageLink = user.profileImages.smallProfile;
            this.setStatus(user.first + " " + user.last);
            this.setNameLabel("Reserved by");
            this.seatBorder ? this.seatBorder.attr('fill',this.borderActive) : null;
        }
        this.update();
    }

    Seat.prototype.checkReservation = function(){
        if(this.reservable && this.reservation){
            var now = moment().valueOf();
            var end = this.reservation.end;
            if(now > end || this.reservation === null){
                this.clearReservation();
            }
        } else if(this.reservable){
            this.clearReservation();
        }
    }

    Seat.prototype.clearReservation = function(){
        this.reservation = null;
        this.setStatus('Reservable');
        this.imageLink = "images/blankprofile.png";
        this.update();
    }

    Seat.prototype.setReservationToNull = function(){
        this.reservation = null;
    }

    // This function toggles whether the seat is marked as reservable, meaning that it can be reverved through the 
    // navigator or other interface and that it is not assignable and/or assigned to a particular user on a permanent
    // basis.  If any user was assigned to the seat, this will clear that assignment.  If a seat is not reservable, then
    // it is considered to be assignable.
    Seat.prototype.toggleReservable = function(value){
        this.setAssignment(); // Removes any existing seat assignments
        this.reservable = value !== undefined ? value : !this.reservable;
        if(this.reservable){
            this.setStatus("Reservable");
        }
    }

    // Clears the current assignment, if one exists.  Basically an alias for setAssignment with no parameter
    Seat.prototype.resetAssignment = function(){
        this.setAssignment(); // Removes any existing seat assignments
    }

    // Sets the status label either with Unassigned or Reservable, or an user name if the seat is assigned
    Seat.prototype.setStatus = function(name){
        
        this.statusLabel.updateText(name);
    }

    Seat.prototype.setNameLabel = function(text){
        this.nameLabel.updateText(text);
    }

// ##########################################  Standard Object Interface Functions  #########################################################

	Seat.prototype.create = function(){
		var pos = this.map.pointerCoords();
		this.points[0] = new point(pos.x,pos.y,this.prefix+"P"+'000'+this.id);
		this.createSVG();
		this.addLabels();
	}

	Seat.prototype.dragPlace = function(){
        var pos = this.map.pointerCoords(); // gets the latest mouse location
        pos.x = this.map.snapRound(pos.x,undefined,true);
        pos.y = this.map.snapRound(pos.y,undefined,true);
        this.points[0].updatePosition(pos.x,pos.y);
        this.nameLabel.updatePosition(pos.x,pos.y);
        this.statusLabel.updatePosition(pos.x,pos.y);
        this.update();
	}

    Seat.prototype.finalizeDragPlace = function(){
        
        this.setLabelStyle(this.labelStyle);
    }

	Seat.prototype.update = function(){
		
        this.updateSVG();
	}

	Seat.prototype.remove = function(){ // Removes the visual elements of the seat image and the labels
		this.removeSVG();
		this.removeLabels();
	}

	Seat.prototype.redraw = function(){ // Redraws the seat and labels after they have been 'removed'
		this.createSVG();
		this.setLabelStyle(this.labelStyle);
	}

	Seat.prototype.activate = function(multiSelect){
		this.seatBorder ? this.seatBorder.attr('fill',this.borderActive) : null;
        this.isSelected = true;
        this.setLabelStyle(this.labelStyle);
	}

	Seat.prototype.deactivate = function(){
		if(this.reservation == null){
            this.seatBorder ? this.seatBorder.attr('fill',this.borderColor) : null;
        }
        this.isSelected = false;
        this.setLabelStyle(this.labelStyle);
	}

	Seat.prototype.getOutlinePoints = function(){ // Returns the point in the upper left of the seat
        
        return [this.points[0].getPoint()];
	}

    Seat.prototype.getSnapPoints = function(dist){
        if(this.points.length == 0){return;}
        var sensitivity = dist || this.snapSensitivity || 12;
        var snapObject = {
            snapPoints: [],
            bufferBox: [],
            snapEdges: []
        }
        var points = [];
        points.push(this.points[0]);
        points.push({
            x:points[0].x + this.width,
            y:points[0].y
        })
        points.push({
            x:points[1].x,
            y:points[1].y + this.height
        })
        points.push({
            x:points[0].x,
            y:points[2].y
        })
        // Assumes object is rectangular with Angle 0 at the horizontal towards the right
        // Also assumes that at an angle of 0, the corners are numbers clockwise starting from the upper left corner [0]
        var theta = this.angle + 5*Math.PI/4;
        var currentPoint;
        for(var i = 0;i < 4;i++){
            theta -= Math.PI/2;
            currentPoint = {x:points[i].x,y:points[i].y};
            snapObject.snapPoints.push({x:currentPoint.x,y:currentPoint.y});
            snapObject.bufferBox.push({
                x:currentPoint.x + sensitivity * Math.cos(theta),
                y:currentPoint.y - sensitivity * Math.sin(theta)
            });          
        }
        for(var i = 0;i<4;i++){ // Finds the edges between the snap points above
            snapObject.snapEdges.push({
                start:copyPoint(snapObject.snapPoints[i]),
                end:copyPoint(snapObject.snapPoints[(i+1)%4])
            });
        }
        return snapObject;        
    }

// ##########################################  Application Mechanics (Undo/Redo/Duplicate/Save/Load)  #############################################

    Seat.prototype.duplicate = function(original){
        for(var i = 0;i < original.points.length;i++){
            this.points.push(new point(original.points[i].x,original.points[i].y,original.points[i].id.substring(0,6)+this.id))
        }
        for(var i = 0;i < this.packageParameters.length;i++){
            if(this.packageParameters[i] != "id"){
                this[this.packageParameters[i]] = original[this.packageParameters[i]];
            }
        }
        this.createSVG();
		this.addLabels();
        this.shiftPosition(12,12);
    }

    Seat.prototype.createPackage = function(){
        var package = {points:[]};
        for(var i = 0;i < this.points.length;i++){
            package.points.push(this.points[i].getSavePoint());
        }
        for(var i = 0;i < this.packageParameters.length;i++){
            package[this.packageParameters[i]] = this[this.packageParameters[i]];
        }
        package.user = this.user;
        package.controller = "seats";
        package.packageType = "modify";
        return package;
    }

    Seat.prototype.loadPackage = function(package){
        // It doesn't matter if it is an undo or redo package, the impact is to reset the object to a former state
        for(var i = 0;i < this.points.length;i++){
            this.points[i].updatePosition(package.points[i].x,package.points[i].y);
            this.points[i].id = package.points[i].id;
        }
        for(var i = 0;i < this.packageParameters.length;i++){
            this[this.packageParameters[i]] = package[this.packageParameters[i]];
        }
        this.setAssignment(package.user,false);
        this.update();
        this.updateLabels();
    }

    Seat.prototype.sendPackages = function(){
        // It is important to know that the undo and redo packages aren't the same.  If they are, there was no real action taken and
        // an undo or redo event will have no apparent effect
        var undo = this.undoPackage;
        var redo = this.createPackage();
        var same = true; // Used to determine whether the two packages are the same (no actual event occured)
        for(var i = 0;i < redo.points.length;i++){ // Runs through the points first as the most common event changes
            if(undo.points[i].x != redo.points[i].x || undo.points[i].y != redo.points[i].y){
                same = false;
                break; // breaks as soon as a single difference is found
            }
        }       
        if(same){ // No need to start second loop if a difference was already found
            for(var i = 0;i < this.packageParameters.length;i++){
                if(undo[this.packageParameters[i]] != redo[this.packageParameters[i]]){
                    same = false;
                    break;
                }
            }
        }
        if( (undo.user && undo.user.userID) != (redo.user && redo.user.userID)){
            same = false;
        }
        // Packages are sent essentially simultaneously to prevent having mismatched packages if the action isn't finalized
        if(!same){
            this.state.addUndoPackage(undo);
            this.state.addRedoPackage(redo);
        }
    }

    Seat.prototype.save = function(){
        var saveFile = {points:[]}
        for(var i = 0;i < this.points.length;i++){
            saveFile.points.push(this.points[i].getSavePoint());
        }
        for(var i = 0;i < this.packageParameters.length;i++){
            saveFile[this.packageParameters[i]] = this[this.packageParameters[i]];
        }
        return saveFile
    }

    Seat.prototype.saveData = function(){ // This is used to populate the seat database through the dataController
        var saveFile = {};
        for(var i = 0;i < this.dataPackageParameters.length;i++){
            saveFile[this.dataPackageParameters[i]] = this[this.dataPackageParameters[i]];
        }
        return saveFile        
    }

    Seat.prototype.load = function(saveFile){
        // Note that this method assumes that the create function has not been called - will not work if it has been
        for(var i = 0;i < saveFile.points.length;i++){
            this.points.push(new point(saveFile.points[i].x,saveFile.points[i].y,saveFile.points[i].id));
        }
        for(var i = 0;i < this.packageParameters.length;i++){
            this[this.packageParameters[i]] = saveFile[this.packageParameters[i]];
        }
        this.createSVG(); 
        this.addLabels();
        this.update();
        this.toggleReservable(this.reservable);
    }

// ##########################################  Drag and Move Functions  #############################################

	Seat.prototype.startDrag = function(){
        this.undoPackage = this.createPackage();
        for(var i = 0;i < this.points.length;i++){
            this.points[i].setDragReference();
        }
        this.nameLabel.point.setDragReference();
        this.statusLabel.point.setDragReference();
	}

	Seat.prototype.drag = function(){
        var coords, xMove, yMove, distDragged;
        var map = this.map;
        coords = map.pointerCoords(); // gets the latest mouse location
        xMove = coords.x-map.handle.x/map.scale;
        yMove = coords.y-map.handle.y/map.scale;
        
        distDragged = this.points[0].dragOffset(xMove,yMove,{gridResolution:map.snapGridResolution,snapToGrid:map.snapGridActive});

        this.nameLabel.dragOffset(distDragged.x,distDragged.y);
        this.statusLabel.dragOffset(distDragged.x,distDragged.y);
        this.update(); 
	}

    Seat.prototype.finalizeDrag = function(){
        this.sendPackages(this.state);
    }

	Seat.prototype.move = function(direction){ // Nudges the object one gird unit in any direction 
		var map = this.map;
        var x = 0;
        var y = 0;
        switch(direction){
            case "up":
            y = -map.snapGridResolution;
            break;
            case "down":
            y = map.snapGridResolution;
            break;
            case "right":
            x = map.snapGridResolution;
            break;
            case "left":
            x = -map.snapGridResolution;
            break;
        }
		this.undoPackage = this.createPackage();
        var length = this.points.length;
        for(var i = 0;i < length;i++){
        	this.points[i].shiftPosition(x,y);
        }
        this.nameLabel.shiftPosition(x,y);
        this.statusLabel.shiftPosition(x,y);
        this.update();
        this.sendPackages();
	}

    Seat.prototype.shiftPosition = function(shiftLeft,shiftUp){
        var keys = Object.keys(this.points);
        var len = keys.length;
        var key,current;
        for(var i = 0;i < len;i++){
            try{
                key = keys[i];
                current = this.points[key];
                current.shiftPosition(shiftLeft,shiftUp);                
            } catch(err){
                console.log(err);
            }
        }
        try{
            this.nameLabel ? this.nameLabel.shiftPosition(shiftLeft,shiftUp) : null;
            this.statusLabel ? this.statusLabel.shiftPosition(shiftLeft,shiftUp) : null;            
        } catch (err){
            console.log(err);
        }
        this.update();
    } 

// ##########################################  Object SVG Functions  ##################################################################

	Seat.prototype.createSVG = function(){

        var border = document.createElementNS('http://www.w3.org/2000/svg', 'rect');
            border.setAttribute('pointer-events','none');
            border.setAttribute('fill',this.borderColor);
            border.setAttribute('x',this.points[0].x);
            border.setAttribute('y',this.points[0].y);
            border.setAttribute('rx',2);
            border.setAttribute('ry',2);
            border.setAttribute('height',this.height+2);
            border.setAttribute('width',this.width+2);
            border.setAttribute('id',"a" + this.id);
            border.setAttribute('class',"Seat");
        $("#labelGroup").append(border);
        this.seatBorder = $("#a" + this.id);

        var image = document.createElementNS('http://www.w3.org/2000/svg', 'image');
            image.setAttribute('pointer-events','all');
            image.setAttributeNS('http://www.w3.org/1999/xlink','xlink:href',this.imageLink);
            image.setAttribute('x',this.points[0].x+2);
            image.setAttribute('y',this.points[0].y+2);
            image.setAttribute('height',this.height-2);
            image.setAttribute('width',this.width-2);
            image.setAttribute('id',"b" + this.id);
            image.setAttribute('class',"Seat");
        $("#labelGroup").append(image);
        this.seatImage = $("#b" + this.id);
	}

    Seat.prototype.cancelDraw = function(){
        
        this.remove();
    }

	Seat.prototype.updateSVG = function(){
		this.seatBorder ? this.seatBorder.attr({x:this.points[0].x,y:this.points[0].y}) : null;
		this.seatImage ? this.seatImage.attr({x:this.points[0].x+2,y:this.points[0].y+2}) : null;
        this.seatImage ? this.seatImage.attr('xlink:href',this.imageLink) : null;
	}

	Seat.prototype.removeSVG = function(){
		this.seatBorder ? this.seatBorder.remove() : null;
        this.seatImage ? this.seatImage.remove() : null;
	}

// ##########################################   Label Functions  ##################################################################

    Seat.prototype.setLabelStyle = function(styleNumber){ // Changes the display behavior of the distance labels based on a style number from a slider
        if(styleNumber != undefined){
            this.labelStyle = styleNumber;
        }
        switch(this.labelStyle){
            case 0: // Never show labels
                this.removeLabels();
            break;
            case 1: // Only show labels when selected
                if(this.isSelected == true){
                    this.redrawLabels();
                } else {
                   this.removeLabels(); 
                }
            break;
            case 2: // Always show labels (default)
                this.redrawLabels();
            break;
        }
        return this.labelStyle;
    }

	Seat.prototype.addLabels = function(){
        var xOffset;
        var anchor;
        switch(this.labelOrient){
            case 0:
                xOffset = 0;
                anchor = 'start';
            break;
            case 1:
                xOffset = this.width/2;
                anchor = 'middle';
            break;
            case 2:
                xOffset = this.width;
                anchor = 'end';
            break;
        }
		this.createNameLabel(xOffset,anchor);
		this.createStatusLabel(xOffset,anchor);
	}

	Seat.prototype.createNameLabel = function(xOffset,anchor){
		if(this.nameLabel != {}){
			this.nameLabel = new label(
				this.prefix + "L000" + this.id, // name label's id is subcategory 'L' index 1
				this.prefix + "N000" + this.id, // name label's point id is subscategory 'n'
				this.name,  // text contents
				"inherit",  // font
				this.fontSize, // font size
				this.points[0].x + xOffset, // x coordinate offset
				this.points[0].y, // y coordinate
				this.textColor, // font color
				"none", // pointer events (none by default so mouse-over won't affect shading)
				anchor, // text anchor
				this.height + 2 + this.fontSize, // y offset
				"labelGroup", // where to append the label
				this.type.toLowerCase()+"Label" // class name for the pointer handle
			);
			this.nameLabel.drawLabel();
		};
	}
	
	Seat.prototype.createStatusLabel = function(xOffset,anchor){
		if(this.statusLabel != {}){
			this.statusLabel = new label(
    			this.prefix+"L001"+this.id, // status label's id is subcategory 'L' index 1
    			this.prefix+"S000"+this.id, // status label's point id is subscategory 'a'
    			this.assignmentStatus,  // text contents
    			"inherit",  // font
    			this.fontSize, // font size
                this.points[0].x + xOffset, // x coordinate offset
                this.points[0].y, // y coordinate
    			this.textColor, // font color
    			"none", // pointer events (none by default so mouse-over won't affect shading)
    			anchor, // text anchor
    			this.height + 2 + 2 * this.fontSize, // y offset
    			"labelGroup", // where to append the label
    			this.type.toLowerCase()+"Label" // class name for the pointer handle
			);
			this.statusLabel.drawLabel();
		}
	}

	Seat.prototype.removeLabels = function(){
		if(this.statusLabel.x){this.statusLabel.removeLabel()};
		if(this.nameLabel.x){this.nameLabel.removeLabel()};
	}

	Seat.prototype.redrawLabels = function(){
		this.statusLabel.redraw();
		this.nameLabel.redraw();
	}

    Seat.prototype.updateLabels = function(){
        this.statusLabel.updatePosition(this.points[0].x,this.points[0].y);
        this.nameLabel.updatePosition(this.points[0].x,this.points[0].y);
    }

// ##########################################  Selector Interface Functions  ######################################################################

	Seat.prototype.setProperty = function(property,value){
        switch(property){
            case "objectName":
                this.name = value;
                this.nameLabel.updateText(this.name);
            break;
            case "objectAreaColor":
                this.setobjectAreaColor(value);
            break;
            case "objectLabelColor":
                this.setobjectLabelColor(value);
            break;
            case "objectLabelSize":
            	this.setobjectLabelSize(value);
            break;
            case "objectLabelOrient":
                this.setObjectLabelOrient(value);
            break;
            case "objectLabelStyle":
                this.setLabelStyle(value);
            break;
            case "objectDepartment":
                this.department = JSON.parse(value);
            break;
        }
    }

    Seat.prototype.setObjectLabelOrient = function(value){
        this.labelOrient = value;
        this.removeLabels();
        delete this.statusLabel;
        delete this.nameLabel;
        this.addLabels();
    }

    Seat.prototype.getProperties = function(subcategory,id){
        var thisData = {};
        thisData.data = {
            objectType: {type:"label",value:this.type},
            objectName: {type:"text",value:this.name},
            objectSeatAssignment: {type:"label",value:this.user ? this.user.first + ' ' + this.user.last : "Unassigned"},
            objectAssignSeat: {type:"label",value:'Assign Seat'},
            objectUnassignSeat: {type:"label",value:'Clear Seat'},
            objectLabelStyleText: {type:"na",value:Seat.prototype.slide(null,{value:this.labelStyle})},
            objectLabelStyle: {type:"slider",value:this.labelStyle,min:0,max:2,slide:Seat.prototype.slide},
            objectLabelOrientText: {type:"na",value:Seat.prototype.orientSlide(null,{value:this.labelOrient})},
            objectLabelOrient: {type:"slider",value:this.labelOrient,min:0,max:2,slide:Seat.prototype.orientSlide},
            objectLabelColor: {type:"color",value:this.textColor},
            objectLabelSize: {type:"spinner",value:this.fontSize},
            objectSeatReservableStatus: {type:"label",value: this.reservable ? "Reservable" : 'Not Reservable'},
            objectReservableSeat: {type:"label",value: this.reservable ? "Stop Reservations" : 'Make Reservable'},
            objectDepartment: {type:"drop-down",value:JSON.stringify(this.department)},
        }
        thisData.dividers = {
            seatAssignmentDivider:true,
            seatReserveDivider:true,
            labelsDivider:true
        }
        return thisData;
    }

    Seat.prototype.getObjectViewerData = function(subcategory,id){
        var thisData = {};
        thisData.data = {
            vObjectSeatName: {type:"label",value:this.name}
        }
        thisData.dividers = {
        }
        if(this.user){
            thisData.data.vObjectSeatAssignment = {type:"label",value:this.seatAssignment};
            thisData.data.vObjectAssignedImage = {type:"image",value: this.user.profileImages.mediumProfile};
            thisData.data.vObjectSeatAssignment = {type:"label",value:this.user.first + " " + this.user.last};
            thisData.data.vObjectAssignedEmail = {type:"label",value: this.user.email};
            thisData.data.vObjectAssignedDept = {type:"label",value: 'Dept: '+this.user.employee.department.name};
            thisData.data.vObjectAssignedEmpID = {type:"label",value: 'Employee ID: '+this.user.employee.employeeID};
            thisData.data.vObjectAssignedTitle = {type:"label",value: this.user.employee.title};
            thisData.dividers.vSeatAssignmentDivider = true;
        }
        if(this.reservable){
            thisData.data.vobjectReserveSeat = {type:"label",value:"Reserve Seat"}
            thisData.data.vSeatResStatus = {type:"label",value:"Available"};
            thisData.dividers.vSeatReservationDivider = true;
        }
        if(this.reservation){
            var user = this.reservation.user;
            var end = moment(this.reservation.end);
            var formattedEnd = formatNearOrFar(end);
            var nextAvailability = formatNearOrFar(
                    moment(Maptician.Viewer.currentFile.dataConnections.getNextAvailability(this.id,this.type))
                );
            thisData.data.vSeatResStatus = {type:"label",value:"Reserved"};
            thisData.data.vSeatReservedImage = {type:"image",value: user.profileImages.mediumProfile};
            thisData.data.vSeatReservedBy = {type:"label",value:user.first + " " + user.last};
            thisData.data.vSeatReservedUntil = {type:"label",value:formattedEnd};
            thisData.data.vSeatNextAvail = {type:"label",value:nextAvailability};
            thisData.dividers.vReservationDivider = true;
        } else if(this.reservable) {
            var nextReservation = Maptician.Viewer.currentFile.dataConnections.getNextReservation(this.id,this.type);
            var nextRes;
            if(nextReservation){
                nextRes = formatNearOrFar(moment(nextReservation.start));
            }
            thisData.data.vSeatResAvailUntil = {type:"label",value:nextRes ? nextRes : "1 Week+"};
        }

        return thisData;
    }

    Seat.prototype.slide = function(event,ui){
            var message = "";
            switch(ui.value){
                case 0:
                message = "No Labels"
                break;
                case 1:
                message = "Show Labels on Select"
                break;
                case 2:
                message = "Always Show Labels"
                break;
            }
            $( "#objectLabelStyleText" ).html(message);
    }

    Seat.prototype.orientSlide = function(event,ui){
            var message = "";
            switch(ui.value){
                case 0:
                message = "Left Aligned"
                break;
                case 1:
                message = "Centered"
                break;
                case 2:
                message = "Right Aligned"
                break;
            }
            $( "#objectLabelOrientText" ).html(message);
    }

	Seat.prototype.setName = function(name){
    	this.name = name;
    	this.nameLabel.updateText(name);
    }

	Seat.prototype.setobjectLabelColor = function(color){
    	var isOk  = /(^#[0-9A-F]{6}$)|(^#[0-9A-F]{3}$)/i.test(color)
        if(isOk){
            this.textColor = color;
            this.nameLabel.color = color;
            this.statusLabel.color = color;
            this.nameLabel.redraw();
            this.statusLabel.redraw();
        } else {
            message.errorMessage("Color not recognized");
        }

        return this.nameLabel.color;
    }

	Seat.prototype.setobjectLabelSize = function(size){
        this.fontSize = size;
        this.nameLabel.setFontSize(size);
        this.nameLabel.setYOffset(this.height + size);
        this.statusLabel.setFontSize(size);
        this.statusLabel.setYOffset(this.height + 2 * size);
    }

	Seat.prototype.toggleAreaLabel = function(){
    	
    	this.areaLabel.toggleActive();
    }

	Seat.prototype.toggleNameLabel = function(){
    	
    	this.nameLabel.toggleActive();
    }