function LDesk(id,state,map){
    MapObject.call(this,"LDesk",id); // Sets subclass of MapObject
    this.state = state; // Reference to the State Controller
    this.map = map; // Reference to the Map Controller

    this.type = "LDesk"; // Can be removed - lives on superclass - just here for reminder
    this.id = id; // Can be removed - lives on superclass - just here for reminder
    this.handleDragging = ""; // Can be removed - lives on superclass - just here for reminder
    this.isSelected = false;   // Can be removed - lives on superclass - just here for reminder

    // Styling
    this.fill = "#D3D3D3";  // Fill Color
    this.stroke = "#000000";  // Stroke Color
    this.activeColor = "red"; // Stroke Color when active
    this.lineWidth = .25;  // Width of the outside stroke

    // Labels
    this.labelStyle = 1; // Determines how the labels are displayed.  Defaults to always showing the labels
    this.labelColor = "#000000";
    this.labelSize = 12;
    this.lengthLabel = {};  // Path label object for length label
    this.widthLabel = {};  // Path label object for width label
    this.lLabels = [];

    // Points
    this.points = []; // Array containing the points making up the column
        // Initial positions
        // 0 - Upper left point
        // 1 - Upper right point
        // 2 - Lower right point
        // 3 - Lower left point
        // 4 - Top Edge Point
        // 5 - Right Edge Point
        // 6 - Bottom Edge Point
        // 7 - Left Edge Point
        // 8 - Rotation handle point

    // SVG alias
    this.desk = null;

    // Calculated and Placeholder
    this.length = 0;  // Length of the object (initially side dimension)
    this.width = 0; // Width of the object (initially top dimension)
    this.initialDims = {};  // Holds the initial dimensions of the object during a resize event
    this.angle = 0;  // Angle in radians of the object with respect to the x-axis (top edge)
    this.centerPoint = {}; // Calculated and used for rotation
    this.dragAngle = 0; // Used for rotation, gives the starting angle of a rotation event

    // Constants
    this.minimumDimension = 12; // Used to set a minimum length or width of the object
    this.defaultSize = {width:60,height:30};
    this.packageParameters = [ // Used in undo/redo/duplicate/save/load methods
            "type",
            "id",
            "fill",
            "stroke",
            "lineWidth",
        ];
}
    LDesk.prototype = Object.create(MapObject.prototype); // Links the prototype to the superclass
    LDesk.prototype.constructor = LDesk;

// ##########################################  Standard Object Interface Functions  ##################################################################

    LDesk.prototype.create = function(optObj){ // This creates all components of the object
        var options = optObj || {};
        this.snapCandidates = options.snapPoints || [];
        var pos = this.map.pointerCoords();
        this.points[0] = new point(pos.x,pos.y,"FNCP00"+this.id); // Upper Left
        this.points[1] = new point(pos.x+this.defaultSize.width,pos.y,"FNCP01"+this.id); // Upper Right
        this.points[2] = new point(pos.x+this.defaultSize.width,pos.y+this.defaultSize.height,"FNCP02"+this.id); // Lower Right
        this.points[3] = new point(pos.x,pos.y+this.defaultSize.height,"FNCP03"+this.id); // Lower Left
        this.points[4] = new point((this.points[0].x+this.points[1].x)/2,(this.points[0].y+this.points[1].y)/2,"FNCP04"+this.id); // Top Edge
        this.points[5] = new point((this.points[1].x+this.points[2].x)/2,(this.points[1].y+this.points[2].y)/2,"FNCP05"+this.id); // Right Edge
        this.points[6] = new point((this.points[2].x+this.points[3].x)/2,(this.points[2].y+this.points[3].y)/2,"FNCP06"+this.id); // Bottom Edge
        this.points[7] = new point((this.points[3].x+this.points[0].x)/2,(this.points[3].y+this.points[0].y)/2,"FNCP07"+this.id); // Left Edge
        this.getCenter();
        this.points[9] = new point(this.centerPoint.x,this.centerPoint.y,"FNCP09"+this.id); // L Pivot Point
        this.points[10] = new point(this.centerPoint.x,pos.y+this.defaultSize.height,"FNCP10"+this.id); // L Width Point
        this.points[11] = new point(pos.x,this.centerPoint.y,"FNCP11"+this.id); // L Length Point
        var widthMid = getMidPoint(this.points[9],this.points[10]);
        var lengthMid = getMidPoint(this.points[9],this.points[11]);
        this.points[12] = new point(widthMid.x,widthMid.y,"FNCP12"+this.id);
        this.points[13] = new point(lengthMid.x,lengthMid.y,"FNCP13"+this.id);
        this.createSVG();
    }

    LDesk.prototype.update = function(){
        this.calculateAngle();
        this.calculateLength();
        this.calculateWidth();
        this.updateLPoints();
        this.updateSVG();
        this.updateSidePoints();
        this.updateRotatePoint();
        this.updateLabels();
    }

    LDesk.prototype.remove = function(){
        this.removeHandles();
        this.removeSVG();
        this.removeLabels();
    }

    LDesk.prototype.redraw = function(){  // Redraws all svg screen objects (if otherwise visible) after they have been removed
        this.createSVG();
        this.setLabelStyle(this.labelStyle);
    }

    LDesk.prototype.activate = function(multiselect){
        this.desk.css("stroke",this.activeColor);
        this.isSelected = true;
        if(!multiselect){
            this.drawHandles();
        }
        this.setLabelStyle(this.labelStyle);
    }

    LDesk.prototype.deactivate = function(){
        this.desk.css("stroke",this.stroke);
        this.isSelected = false;
        this.removeHandles();
        this.setLabelStyle(this.labelStyle);
    }

    LDesk.prototype.getOutlinePoints = function(){ // Returns points for a bounding box for the object
        var pointObject = [];
        for(var i = 0;i < 4;i++){ // Only looks out outer corner points
            pointObject.push(this.points[i].getPoint());
        }
        return pointObject;
    }

// ##########################################  Point Handle Functions  ########################################################

    LDesk.prototype.handlePress = function(handleID){  // Receives a handle press event and saves the mouse location and handle ID for drag process
        var len = this.points.length;
        var center = this.getCenter();
        for(var i = 0;i < len;i++){
            this.points[i].setDragReference();
        }
        this.initialDims["widthMargin"] = this.width - this.minimumDimension;
        this.initialDims["lengthMargin"] = this.length - this.minimumDimension;
        this.handleDragging = handleID.slice(4,6)*1;
        if(this.handleDragging == 8){
            this.points[0].setRotateAngle(center.x,center.y,this.angle);
            this.points[1].setRotateAngle(center.x,center.y,this.angle);
            this.points[2].setRotateAngle(center.x,center.y,this.angle);
            this.points[3].setRotateAngle(center.x,center.y,this.angle);
            this.points[9].setRotateAngle(center.x,center.y,this.angle);
        }
        this.undoPackage = this.createPackage();
    }

    LDesk.prototype.handleDrag = function(){  // Receives a handle drag event and changes the point associated with the handle based on the new location
        var map = this.map;
        if(this.handleDragging != 9){
            var angle = rectHandleDrag( // If rotated, it returns the angle necessary to rotate the 9th point
                this.points,
                this.handleDragging,
                this.angle,
                this.minimumDimension,
                this.initialDims,
                this.centerPoint,
                this.width,
                this.length,
                map
            );
        }
        if(this.handleDragging == 8){
            this.points[9].rotateAroundCenter(this.centerPoint.x,this.centerPoint.y,angle);
        } else {
            var coords = map.pointerCoords(); // gets the latest mouse location
            if(this.handleDragging == 9){
                var xMove = coords.x-map.handle.x/map.scale;
                var yMove = coords.y-map.handle.y/map.scale;                
            } else {
                var xMove = 0;
                var yMove = 0;
            }
            var proposed = {
                x: this.points[9].dragReference.x + xMove,
                y: this.points[9].dragReference.y + yMove
            }
            var theta1 = findAngle(this.points[0],proposed,this.points[1]);
            var theta2 = findAngle(this.points[0],proposed,this.points[3]);
            var dist = getLength(this.points[0],proposed);
            var lengthConst, widthConst;
            if(theta2 > Math.PI/2){
                lengthConst = 12;
            } else{
                lengthConst = Math.min(Math.max(12,dist * Math.sin(theta1)),this.length-10);
            }
            if(theta1 > Math.PI/2){
                widthConst = 12;
            } else {
                widthConst = Math.min(Math.max(12,dist * Math.sin(theta2)),this.width-10);
            }
            var theta3 = this.angle - Math.atan2(lengthConst,widthConst);
            var newDist = Math.sqrt(Math.pow(lengthConst,2)+Math.pow(widthConst,2));
            this.points[9].updatePosition(this.points[0].x+newDist*Math.cos(theta3),this.points[0].y-newDist*Math.sin(theta3));
        }
        this.update();
    }

    LDesk.prototype.updateLPoints = function(){
        var theta1 = findAngle(this.points[0],this.points[9],this.points[1]);
        var dist = getLength(this.points[0],this.points[9]);
        var width = dist * Math.cos(theta1);
        var length = dist * Math.sin(theta1);
        this.points[10].updatePosition(this.points[3].x + width * Math.cos(this.angle), this.points[3].y - width * Math.sin(this.angle));
        this.points[11].updatePosition(this.points[0].x + length * Math.cos(this.angle- Math.PI/2), this.points[0].y - length * Math.sin(this.angle - Math.PI/2));
        this.points[12].updatePosition(getMidPoint(this.points[9],this.points[11]));
        this.points[13].updatePosition(getMidPoint(this.points[9],this.points[10]));
        this.points[6].updatePosition(this.points[10].getPoint()); // Bottom Edge
        this.points[7].updatePosition(this.points[11].getPoint()); // Left Edge
    }

    LDesk.prototype.finalizeHandleDrag = function(){
        
        this.sendPackages();
    }

    LDesk.prototype.drawHandles = function(){
        var len = this.points.length;
        for(var i = 0;i < len;i++){
            if(i == 10 || i == 11){
                continue;
            }
            this.points[i].drawHandle();
        }
    }

    LDesk.prototype.removeHandles = function(){ // Removes the handles on the wall endpoints
        var len = this.points.length;
        for(var i = 0;i < len;i++){
            this.points[i].removeHandle();
        }
    }

    LDesk.prototype.createRotatePoint = function(){
        var distance = 18;
        var topCenterX = (this.points[0].x + this.points[1].x)/2;
        var topCenterY = (this.points[0].y + this.points[1].y)/2;
        this.points[8] = new point(
            topCenterX + distance * Math.cos(this.angle+Math.PI/2),
            topCenterY - distance * Math.sin(this.angle+Math.PI/2),
            "FNCP08"+this.id);
    }
    
    LDesk.prototype.updateRotatePoint = function(){
        if(this.points[8]){
            var distance = 18;
            this.points[8].updatePosition(
                this.points[4].x + distance * Math.cos(this.angle+Math.PI/2),
                this.points[4].y - distance * Math.sin(this.angle+Math.PI/2)
            )
        }
    }

// ##########################################  Application Mechanics (Undo/Redo/Duplicate/Save/Load)  #############################################

    LDesk.prototype.duplicate = function(original){
        var len = original.points.length;
        var len2 = this.packageParameters.length;
        var points = original.points;
        var pointObj;
        for(var i = 0;i < len;i++){
            pointObj = points[i];
            this.points.push(new point(pointObj.x,pointObj.y,pointObj.id.substring(0,6)+this.id))
        }
        for(var i = 0;i < len2;i++){
            if(this.packageParameters[i] != "id"){ // Don't want to copy the original object's unique id
                this[this.packageParameters[i]] = original[this.packageParameters[i]]; // Note package parameters can't be objects
            }
        }
        this.createSVG();
        this.addLabels();
        this.move(12,12);
    }

    LDesk.prototype.createPackage = function(){
        var package = {points:[]};
        var len = this.points.length;
        var len2 = this.packageParameters.length;
        for(var i = 0;i < len;i++){
            package.points.push(this.points[i].getPoint());
        }
        for(var i = 0;i < len2;i++){
            package[this.packageParameters[i]] = this[this.packageParameters[i]];
        }
        package.controller = "furniture";
        package.packageType = "modify";
        return package;
    }

    LDesk.prototype.loadPackage = function(package){
        // It doesn't matter if it is an undo or redo package, the impact is to reset the object to a former state
        var len = this.points.length;
        var len2 = this.packageParameters.length;
        for(var i = 0;i < len;i++){
            this.points[i].updatePosition(package.points[i].x,package.points[i].y);
        }
        for(var i = 0;i < len2;i++){
            this[this.packageParameters[i]] = package[this.packageParameters[i]];
        }
        this.update();
    }

    LDesk.prototype.sendPackages = function(){
        // It is important to know that the undo and redo packages aren't the same.  If they are, there was no real action taken and
        // an undo or redo event will have no apparent effect
        var undo = this.undoPackage;
        var redo = this.createPackage();
        var same = true; // Used to determine whether the two packages are the same (no undo/redo-able event occured)
        for(var i = 0;i < redo.points.length;i++){ // Runs through the points first as the most common changes
            if(undo.points[i].x != redo.points[i].x || undo.points[i].y != redo.points[i].y){
                same = false;
                break; // breaks as soon as a single difference is found
            }
        }       
        if(same){ // No need to start second loop if a difference was already found
            for(var i = 0;i < this.packageParameters.length;i++){
                if(undo[this.packageParameters[i]] != redo[this.packageParameters[i]]){
                    same = false;
                    break; // breaks as soon as a single difference is found
                }
            }
        }
        // Packages are sent simultaneously to prevent having mismatched packages if the action isn't finalized
        if(!same){
            this.state.addUndoPackage(undo);
            this.state.addRedoPackage(redo);
        }
    }

    LDesk.prototype.save = function(){
        var saveFile = {points:[]};
        var len = this.points.length;
        var len2 = this.packageParameters.length;
        for(var i = 0;i < len;i++){
            saveFile.points.push(this.points[i].getSavePoint());
        }
        for(var i = 0;i < len2;i++){
            saveFile[this.packageParameters[i]] = this[this.packageParameters[i]];
        }
        return saveFile
    }

    LDesk.prototype.load = function(saveFile){
        // Note that this method assumes that the create function has not been called - will not work if it has been
        var len = saveFile.points.length;
        var len2 = this.packageParameters.length;
        var points = saveFile.points;
        var pointObj;
        for(var i = 0;i < len;i++){
            pointObj = points[i];
            this.points.push(new point(pointObj.x,pointObj.y,pointObj.id));
        }
        for(var i = 0;i < len2;i++){
            this[this.packageParameters[i]] = saveFile[this.packageParameters[i]];
        }
        this.createSVG();
        this.addLabels();   
        this.update();
        this.setLabelStyle();
    }

// ##########################################  Drag and Move Functions  #############################################

    LDesk.prototype.startDrag = function(){ // Saves the origin of a drag event for move calculations
        var len = this.points.length;
        this.undoPackage = this.createPackage();
        for(var i = 0;i < len;i++){
            this.points[i].setDragReference();
        }
        this.points[9].setDragReference();
    }

    LDesk.prototype.drag = function(){ // Drags the wall upon a left-button down on the wall layer svg and dragging the mouse
        var map = this.map;
        var coords = map.pointerCoords(); // gets the latest mouse location
        var xMove = map.snapRound(coords.x-map.handle.x/map.scale);
        var yMove = map.snapRound(coords.y-map.handle.y/map.scale);
        for(var i = 0;i < 4;i++){
            this.points[i].dragOffset(xMove,yMove);
        }
        this.points[9].dragOffset(xMove,yMove);
        this.update(); 
    }

    LDesk.prototype.finalizeDrag = function(){
        this.sendPackages();
    }

    LDesk.prototype.move = function(direction){ // Moves the wall by an x and y distance, called by the architecture controller as a result of a keyboard press
        var map = this.map;
        this.undoPackage = this.createPackage();
        var x = 0;
        var y = 0;
        switch(direction){
            case "up":
            y = -map.snapGridResolution;
            break;
            case "down":
            y = map.snapGridResolution;
            break;
            case "right":
            x = map.snapGridResolution;
            break;
            case "left":
            x = -map.snapGridResolution;
            break;
        }
        for(var i = 0; i < this.points.length; i++){
            this.points[i].shiftPosition(x,y);
        }
        this.update();
        this.sendPackages();
    }

// ##########################################  Object SVG Functions  ##################################################################

    LDesk.prototype.createSVG = function(){
        var outerDesk = document.createElementNS('http://www.w3.org/2000/svg', 'path');
        outerDesk.setAttribute('d',this.getOuterPath());
        outerDesk.setAttribute('id',"a"+this.id);
        outerDesk.setAttribute('class',"furniture desk");
        outerDesk.setAttribute('pointer-events',"all");
        outerDesk.setAttribute('style',"stroke-linecap:square;stroke:"+this.stroke+";fill:"+this.fill+";stroke-width:"+this.lineWidth);
        $('#desks').append(outerDesk);
        this.desk = $("#a" + this.id);
    }

    LDesk.prototype.getOuterPath = function(){
        var path = ""
        path += "M " + this.points[0].x + " " + this.points[0].y; // Start point at upper left
        path += "L " + this.points[1].x + " " + this.points[1].y;  // Point at the upper right
        path += "L " + this.points[2].x + " " + this.points[2].y;  // Point at the lower right
        path += "L " + this.points[10].x + " " + this.points[10].y;
        path += "L " + this.points[9].x + " " + this.points[9].y;
        path += "L " + this.points[11].x + " " + this.points[11].y;
        path += "Z";  // Return and close of position
        return path;
    }

    LDesk.prototype.cancelDraw = function(){
        this.remove();
    }

    LDesk.prototype.dragPlace = function(){
        var pos = this.map.pointerCoords(); // gets the latest mouse location
        pos.x = this.map.snapRound(pos.x,undefined,true);
        pos.y = this.map.snapRound(pos.y,undefined,true);
        this.points[0].updatePosition(pos.x,pos.y);
        this.points[1].updatePosition(pos.x+this.defaultSize.width,pos.y);
        this.points[2].updatePosition(pos.x+this.defaultSize.width,pos.y+this.defaultSize.height);
        this.points[3].updatePosition(pos.x,pos.y+this.defaultSize.height);
        this.getCenter();
        this.points[9].updatePosition(this.centerPoint.x,this.centerPoint.y); // L Point
        this.update();
    }

    LDesk.prototype.finalizeDragPlace = function(){
        this.createRotatePoint();
        this.addLabels();
        this.setLabelStyle(this.labelStyle);
        this.update();
    }

    LDesk.prototype.updateSVG = function(){
        this.desk.attr("d",this.getOuterPath());
    }

    LDesk.prototype.removeSVG = function(){
        this.desk.remove();
    }

    LDesk.prototype.updateSidePoints = function(){
        this.points[4].updatePosition((this.points[0].x+this.points[1].x)/2,(this.points[0].y+this.points[1].y)/2); // Top Edge
        this.points[5].updatePosition((this.points[1].x+this.points[2].x)/2,(this.points[1].y+this.points[2].y)/2); // Right Edge
        //this.points[6].updatePosition((this.points[2].x+this.points[3].x)/2,(this.points[2].y+this.points[3].y)/2); // Bottom Edge
        //this.points[7].updatePosition((this.points[3].x+this.points[0].x)/2,(this.points[3].y+this.points[0].y)/2); // Left Edge
    }

// ##########################################  Object Calculation Functions  ############################################################

    LDesk.prototype.calculateLength = function(){  // Side Edge
        this.length = getLength(this.points[0],this.points[3]);
    }

    LDesk.prototype.calculateWidth = function(){  // Top Edge
        this.width = getLength(this.points[0],this.points[1]);
    }

    LDesk.prototype.calculateAngle = function(){  // Angle of top edge
        this.angle = getAngle(this.points[0],this.points[1]);
    }

    LDesk.prototype.getCenter = function(){ // Assumes rectangle
        this.centerPoint = {
            x:(this.points[0].x + this.points[2].x)/2 ,
            y:(this.points[0].y + this.points[2].y)/2
        }
        return this.centerPoint;
    }

// ##########################################   Label Functions  ##################################################################

    LDesk.prototype.setLabelStyle = function(styleNumber){ // Changes the display behavior of the distance labels based on a style number from a slider
        if(styleNumber != undefined){
            this.labelStyle = styleNumber;
        }
        switch(this.labelStyle){
            case 0: // Never show labels
                this.removeLabels();
            break;
            case 1: // Only show labels when selected
                if(this.isSelected == true){
                    this.redrawLabels();
                } else {
                   this.removeLabels(); 
                }
            break;
            case 2: // Always show labels (default)
                this.redrawLabels();
            break;
        }
        return this.labelStyle;
    }

    LDesk.prototype.addLabels = function(){ // Creates a length label object and adds it to the wall 
        if(!(this.lengthLabel instanceof pathTextLabel)){ // Check to ensure that a label doesn't already exist
            var id = generateUUID();
            this.lengthLabel = new pathTextLabel("LL"+id,this.points[1].getPoint(),this.points[2].getPoint(),this.labelColor,this.labelSize,"50%",-5,"labelGroup");
            this.lengthLabel.draw();
            this.widthLabel = new pathTextLabel("WL"+id,this.points[0].getPoint(),this.points[1].getPoint(),this.labelColor,this.labelSize,"50%",-5,"labelGroup");
            this.widthLabel.draw();
            this.lLabels.push(new pathTextLabel("L0"+id,this.points[2].getPoint(),this.points[10].getPoint(),this.labelColor,this.labelSize*.66,"50%",-5,"labelGroup"));
            this.lLabels.push(new pathTextLabel("L1"+id,this.points[10].getPoint(),this.points[9].getPoint(),this.labelColor,this.labelSize*.66,"50%",-5,"labelGroup"));
            this.lLabels.push(new pathTextLabel("L2"+id,this.points[9].getPoint(),this.points[11].getPoint(),this.labelColor,this.labelSize*.66,"50%",-5,"labelGroup"));
            this.lLabels.push(new pathTextLabel("L3"+id,this.points[11].getPoint(),this.points[0].getPoint(),this.labelColor,this.labelSize*.66,"50%",-5,"labelGroup"));
            for(var i in this.lLabels){
                this.lLabels[i].draw();
            }
            this.updateLabels();
        }
    }

    LDesk.prototype.removeLabels = function(){  // Removes the length label from the wall
        if(this.lengthLabel.remove && this.widthLabel.remove){
            this.lengthLabel.remove();
            this.widthLabel.remove();
            for(var i in this.lLabels){
                this.lLabels[i].remove();
            }
        }
    }

    LDesk.prototype.redrawLabels = function(){
        this.lengthLabel.redraw();
        this.widthLabel.redraw();
        for(var i in this.lLabels){
            this.lLabels[i].redraw();
        }
    }

    LDesk.prototype.updateLabels = function(){
        if(this.lengthLabel.update && this.widthLabel.update){
            this.lengthLabel.update(this.renderLength(this.length),this.points[1].getPoint(),this.points[2].getPoint());
            this.widthLabel.update(this.renderLength(this.width),this.points[0].getPoint(),this.points[1].getPoint());
            this.lLabels[0].update(
                this.renderLength(getLength(this.points[2].getPoint(),this.points[10].getPoint())),
                    this.points[2].getPoint(),
                    this.points[10].getPoint()
                );
            this.lLabels[1].update(
                this.renderLength(getLength(this.points[10].getPoint(),this.points[9].getPoint())),
                    this.points[10].getPoint(),
                    this.points[9].getPoint()
                );
            this.lLabels[2].update(
                this.renderLength(getLength(this.points[9].getPoint(),this.points[11].getPoint())),
                    this.points[9].getPoint(),
                    this.points[11].getPoint()
                );
            this.lLabels[3].update(
                this.renderLength(getLength(this.points[11].getPoint(),this.points[0].getPoint())),
                    this.points[11].getPoint(),
                    this.points[0].getPoint()
                );
        }
    }

// ##########################################  Selector Interface Functions  ############################################################

    LDesk.prototype.setProperty = function(property,value){
        switch(property){
            case "objectLength":
                this.setobjectLength(value);
            break;
            case "objectWidth":
                this.setobjectWidth(value);
            break;
            case "objectAngle":
                this.setobjectAngle(toRads(value));
            break;
            case "objectStrokeColor":
                this.setobjectStrokeColor(value);
            break;
            case "objectFillColor":
                this.setobjectFillColor(value);
            break;
            case "objectAreaColor":
                this.setobjectAreaColor(value);
            break;
            case "objectLabelStyle":
                this.setLabelStyle(value);
            break;
            case "objectLabelColor":
                this.labelColor = value;
                this.lengthLabel.setColor(value);
                this.widthLabel.setColor(value);
            break;
            case "objectLabelSize":
                this.labelSize = value;
                this.lengthLabel.setFontSize(value);
                this.widthLabel.setFontSize(value);
            break;
        }
    }

    LDesk.prototype.getProperties = function(subcategory,id){
        return this.getObjectData(subcategory,id);
    }

    LDesk.prototype.getObjectData = function(subcategory,id){  // This function is called when the user selects a wall object
        var thisData = {};
        thisData.data = {
            objectType: {type:"label",value:"L-Desk"},
            objectLength: {type:"spinner",value:this.renderLength(this.length)},
            objectWidth: {type:"spinner",value:this.renderLength(this.width)},
            objectAngle: {type:"spinner",value:toDeg(this.angle)},
            objectStrokeColor: {type:"color",value:this.stroke},
            objectFillColor: {type:"color",value:this.fill},
            objectLabelStyleText: {type:"na",value:LDesk.prototype.slide(null,{value:this.labelStyle})},
            objectLabelStyle: {type:"slider",value:this.labelStyle,min:0,max:2,slide:LDesk.prototype.slide},
            objectLabelColor: {type:"na",value:this.labelColor},
            objectLabelSize: {type:"spinner",value:this.lengthLabel.fontSize},
        }
        thisData.dividers = {
            sizeDivider:true,
            positionDivider:true,
            colorDivider:true,
            labelsDivider:true
        }
        return thisData;
    }

    LDesk.prototype.slide = function(event,ui){
            var message = "";
            switch(ui.value){
                case 0:
                message = "No Labels"
                break;
                case 1:
                message = "Show Labels on Select"
                break;
                case 2:
                message = "Always Show Labels"
                break;
            }
            $( "#objectLabelStyleText" ).html(message);
    }


    LDesk.prototype.setobjectLength = function(value){
        var newX3 = value * Math.cos(this.angle - Math.PI/2) + this.points[0].x;
        var newY3 = -value * Math.sin(this.angle - Math.PI/2) + this.points[0].y;
        var newX2 = value * Math.cos(this.angle - Math.PI/2) + this.points[1].x;
        var newY2 = -value * Math.sin(this.angle - Math.PI/2) + this.points[1].y;
        this.points[2].updatePosition(newX2,newY2);
        this.points[3].updatePosition(newX3,newY3);
        this.update();
    }

    LDesk.prototype.setobjectWidth = function(value){
        var newX1 = value * Math.cos(this.angle) + this.points[0].x;
        var newY1 = -value * Math.sin(this.angle) + this.points[0].y;
        var newX2 = value * Math.cos(this.angle) + this.points[3].x;
        var newY2 = -value * Math.sin(this.angle) + this.points[3].y;
        this.points[1].updatePosition(newX1,newY1);
        this.points[2].updatePosition(newX2,newY2);
        this.update();
        return this.width;
    }

    LDesk.prototype.setStrokeWidth = function(value){
        this.lineWidth = value;
        this.update();
        return this.lineWidth;
    }

    LDesk.prototype.setobjectAngle = function(angle){
        this.getCenter();
        this.points[0].setRotateAngle(this.centerPoint.x,this.centerPoint.y,this.angle);
        this.points[1].setRotateAngle(this.centerPoint.x,this.centerPoint.y,this.angle);
        this.points[2].setRotateAngle(this.centerPoint.x,this.centerPoint.y,this.angle);
        this.points[3].setRotateAngle(this.centerPoint.x,this.centerPoint.y,this.angle);
        this.points[0].rotateAroundCenter(this.centerPoint.x,this.centerPoint.y,angle);
        this.points[1].rotateAroundCenter(this.centerPoint.x,this.centerPoint.y,angle);
        this.points[2].rotateAroundCenter(this.centerPoint.x,this.centerPoint.y,angle);
        this.points[3].rotateAroundCenter(this.centerPoint.x,this.centerPoint.y,angle);
        this.update();
    }

    LDesk.prototype.setStrokeWidth = function(value){
        this.lineWidth = value;
        this.update();
        return this.lineWidth;
    }

    LDesk.prototype.setobjectStrokeColor = function(color){
        var isOk  = /(^#[0-9A-F]{6}$)|(^#[0-9A-F]{3}$)/i.test(color)
        if(isOk){
            this.stroke = color;
        } else {
            console.log("color not recognized")
        }
        this.desk.css("stroke",this.stroke);
    }

    LDesk.prototype.setobjectFillColor = function(color){
        var isOk  = /(^#[0-9A-F]{6}$)|(^#[0-9A-F]{3}$)/i.test(color)
        if(isOk){
            this.sinkFill = color;
        } else {;
            console.log("color not recognized")
        }
        this.desk.css("fill",this.fill);
    }

