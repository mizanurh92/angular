function Cubicle(id,state,map){
    MapObject.call(this,"Cubicle",id); // Sets subclass of MapObject
    this.state = state; // Reference to the State Controller
    this.map = map; // Reference to the Map Controller

    this.type = "Cubicle"; // Can be removed - lives on superclass - just here for reminder
    this.id = id; // Can be removed - lives on superclass - just here for reminder
    this.handleDragging = ""; // Can be removed - lives on superclass - just here for reminder
    this.isSelected = false;   // Can be removed - lives on superclass - just here for reminder

    // Styling
    this.stroke = "#BEBEBE";  // Stroke Color
    this.areaFill = "#FFFFFF";
    this.cornerPanelColor = "#808080";
    this.cubicleWallThickness = 2;
    this.widthPanels = 3;
    this.lengthPanels = 3;
    this.snapSensitivity = 12;

    // Labels
    this.labelStyle = 1; // Determines how the labels are displayed.  Defaults to always showing the labels
    this.labelColor = "#000000";
    this.labelSize = 12;
    this.lengthLabel;  // Path label object for length label
    this.widthLabel;  // Path label object for width label

    // Points
    this.points = []; // Array containing the points making up the column

    this.cubicleArea = null;
    this.cubiclePost1 = null;
    this.cubiclePost2 = null;
    this.cubiclePost3 = null;
    this.cubiclePost4 = null;
    this.cubiclePanel = null;

    // Subobjects
    this.entrances = {};
    this.entranceCounter = "000";

    // Calculated and Placeholder
    this.length = 0;  // Length of the object (initially side dimension)
    this.width = 0; // Width of the object (initially top dimension)
    this.initialDims = {};  // Holds the initial dimensions of the object during a resize event
    this.angle = 0;  // Angle in radians of the object with respect to the x-axis (top edge)
    this.centerPoint = {}; // Calculated and used for rotation
    this.dragAngle = 0; // Used for rotation, gives the starting angle of a rotation event

    // Constants
    this.minimumDimension = 12; // Used to set a minimum length or width of the object
    this.defaultSize = {width:72,height:72};
    this.rotatePointDist = 18;
    this.packageParameters = [ // Used in undo/redo/duplicate/save/load methods
            "type",
            "id",
            "stroke",
            "areaFill",
            "widthPanels",
            "lengthPanels",
            "labelStyle",
            "labelColor",
            "labelSize",
            "entranceCounter",
        ];
}
    Cubicle.prototype = Object.create(MapObject.prototype); // Links the prototype to the superclass
    Cubicle.prototype.constructor = Cubicle;

// #################################  Standard Object Interface Functions  ###################################

    // This is necessary since we want a cubicle to snap with overlapping panels rather than at the edges
    Cubicle.prototype.getCubicleSnapPoints = function(options){
        options = options || {};
        // The outside option determines whether the snap points are at the center of the posts or at the outer conrers
        options.outside = options.outside === undefined ? false : options.outside;
        
        var sensitivity = this.snapSensitivity;
        var snapObject = {
            snapPoints: [],
            bufferBox: [],
            snapEdges: []
        }
        var widthOffset = options.outside ? 0 : Math.sqrt(2*Math.pow(this.cubicleWallThickness/2,2));
        var theta = this.angle + Math.PI/4; // theta is the angle towards the center of a post
        var theta2; // theta2 is the angle away from the center of a post
        var tempPoint = {};
        var currentPoint;
        for(var i = 0;i < 4;i++){ // Finds the center points of the corner posts of the cubicle as snap points
            theta -= Math.PI/2;
            theta2 = theta + Math.PI;
            currentPoint = this.points[i].getPoint();
            // The following calculates the post center points for each loop point
            tempPoint.x = currentPoint.x + widthOffset * Math.cos(theta);
            tempPoint.y = currentPoint.y - widthOffset * Math.sin(theta);
            snapObject.snapPoints.push(copyPoint(tempPoint));
            // The following calculates in the opposite direction to create a buffer zone around the cubicle
            // This zone is used to trigger snapping for the cubicle
            tempPoint.x = currentPoint.x + sensitivity * Math.cos(theta2);
            tempPoint.y = currentPoint.y - sensitivity * Math.sin(theta2);
            snapObject.bufferBox.push(copyPoint(tempPoint));          
        }
        for(var i = 0;i<4;i++){ // Finds the edges between the snap points above
            snapObject.snapEdges.push({
                start:copyPoint(snapObject.snapPoints[i]),
                end:copyPoint(snapObject.snapPoints[(i+1)%4])
            });
        }
        return snapObject;
    }

    Cubicle.prototype.getSnapPoints = function(){
        // This is used for non-cubicle snapping where the object should snap to the edge of the cubicle
        return this.getCubicleSnapPoints({outside:true});
    }

    Cubicle.prototype.create = function(options){ // This creates all components of the object
        options = options || {};
        this.snapCandidates = options.snapPoints || [];

        var pos = this.map.pointerCoords();
        this.points[0] = new point(pos.x,pos.y,"FNCP00"+this.id); // Upper Left
        this.points[1] = new point(pos.x+this.defaultSize.width,pos.y,"FNCP01"+this.id); // Upper Right
        this.points[2] = new point(pos.x+this.defaultSize.width,pos.y+this.defaultSize.height,"FNCP02"+this.id); // Lower Right
        this.points[3] = new point(pos.x,pos.y+this.defaultSize.height,"FNCP03"+this.id); // Lower Left
        this.points[4] = new point((this.points[0].x+this.points[1].x)/2,(this.points[0].y+this.points[1].y)/2,"FNCP04"+this.id); // Top Edge
        this.points[5] = new point((this.points[1].x+this.points[2].x)/2,(this.points[1].y+this.points[2].y)/2,"FNCP05"+this.id); // Right Edge
        this.points[6] = new point((this.points[2].x+this.points[3].x)/2,(this.points[2].y+this.points[3].y)/2,"FNCP06"+this.id); // Bottom Edge
        this.points[7] = new point((this.points[3].x+this.points[0].x)/2,(this.points[3].y+this.points[0].y)/2,"FNCP07"+this.id); // Left Edge
        this.createSVG();
    }

    Cubicle.prototype.update = function(){
        this.calculateAngle();
        this.calculateLength();
        this.calculateWidth();
        this.updateSVG();
        this.updateSidePoints();
        this.updateRotatePoint();
        this.updateLabels();
        this.updateSubObjects();
    }

    // Removes the object and its subobjects from the screen - does not permanently delete
    Cubicle.prototype.remove = function(subclassID){
        if(subclassID){
            switch(subclassID[2]){
                case "E":
                    this.entrances[subclassID.slice(3,6)].object.remove();
                    this.state.addUndoPackage(this.createUndoDeletePackage(subclassID.slice(3,6),"CubicleEntrance"));
                    this.state.addRedoPackage(this.createRedoDeletePackage(subclassID.slice(3,6),"CubicleEntrance"));
                    delete this.entrances[subclassID.slice(3,6)];
                break;
            }            
        } else {
            this.removeHandles();
            this.removeSVG();
            this.removeLabels();
            this.removeSubObjects();
        }
    }

    // Redraws all svg screen objects (if otherwise visible) after they have been removed
    Cubicle.prototype.redraw = function(){  
        this.createSVG();
        this.setLabelStyle(this.labelStyle);
        this.redrawSubObjects();
    }

    Cubicle.prototype.activate = function(multiselect,subclassID){
        if(subclassID){
            switch(subclassID[2]){
                case "E":
                    this.entrances[subclassID.slice(3,6)].object.activate();
                break;
            }
        } else{
            this.cubicleSelection && this.cubicleSelection.addClass('selected');
            this.isSelected = true;
            multiselect || this.drawHandles();
            this.setLabelStyle();
        }
    }

    Cubicle.prototype.deactivate = function(subclass){
        if(subclass){
            switch(subclass[2]){
                case "E":
                    this.entrances[subclass.slice(3,6)].object.deactivate();
                break;
            }
        } else{
            this.cubicleSelection && this.cubicleSelection.removeClass('selected');
            this.isSelected = false;
            this.removeHandles();
            this.setLabelStyle();
        }
    }

    Cubicle.prototype.getOutlinePoints = function(){ // Returns points for a bounding box for the object
        var pointObject = [];
        for(var i = 0;i < 4;i++){ // Only looks out outer corner points
            pointObject.push(this.points[i].getPoint());
        }
        return pointObject;
    }

// ###################################  Point Handle Functions  ###################################################

    // Receives a handle press event and saves the mouse location and handle ID for drag process
    Cubicle.prototype.handlePress = function(handleID){  
        switch(handleID[2]){
            case "E":  // Entrance Points
                this.handleDragging = handleID.slice(3,6);
                this.entrances[this.handleDragging].object.handlePress(handleID);
            break;
            case "C":  // Cubicle Points
                var len = this.points.length;
                var center = this.getCenter();
                for(var i = 0;i < len;i++){
                    this.points[i].setDragReference();
                }
                this.initialDims.widthMargin = this.width - this.minimumDimension;
                this.initialDims.lengthMargin = this.length - this.minimumDimension;
                this.handleDragging = handleID.slice(4,6)*1;
                if(this.handleDragging == 8){
                    this.points[0].setRotateAngle(center.x,center.y,this.angle);
                    this.points[1].setRotateAngle(center.x,center.y,this.angle);
                    this.points[2].setRotateAngle(center.x,center.y,this.angle);
                    this.points[3].setRotateAngle(center.x,center.y,this.angle);
                }
                this.undoPackage = this.createPackage();
            break;
        }
    }
    
    // Receives a handle drag event and changes the point associated with the handle based on the new location
    Cubicle.prototype.handleDrag = function(id){  
        if(this.handleDragging.length == 3){ // A bit of an ugly way to determine whether an entrance/subobject is being dragged
            this.entrances[this.handleDragging].object.handleDrag(id);
        } else {
            rectHandleDrag(
                this.points,
                this.handleDragging,
                this.angle,
                this.minimumDimension,
                this.initialDims,
                this.centerPoint,
                this.width,
                this.length,
                this.map
            );
            this.update();             
        }
    }

    Cubicle.prototype.finalizeHandleDrag = function(){
        if(this.handleDragging.length == 3){
            this.entrances[this.handleDragging].object.finalizeHandleDrag();
        } else{
            this.sendPackages(); 
        }
        this.handleDragging = null;
    }

    Cubicle.prototype.drawHandles = function(){
        var len = this.points.length;
        for(var i = 0;i < len;i++){
            this.points[i].drawHandle();
        }
    }

    Cubicle.prototype.removeHandles = function(){
        var len = this.points.length;
        for(var i = 0;i < len;i++){
            this.points[i].removeHandle();
        }
    }

    Cubicle.prototype.createRotatePoint = function(){
        var topCenterX = (this.points[0].x + this.points[1].x)/2;
        var topCenterY = (this.points[0].y + this.points[1].y)/2;
        this.points[8] = new point(
            topCenterX + this.rotatePointDist * Math.cos(this.angle+Math.PI/2),
            topCenterY - this.rotatePointDist * Math.sin(this.angle+Math.PI/2),
            "FNCP08"+this.id);
    }
    
    Cubicle.prototype.updateRotatePoint = function(){
        if(this.points[8]){
            this.points[8].updatePosition(
                this.points[4].x + this.rotatePointDist * Math.cos(this.angle+Math.PI/2),
                this.points[4].y - this.rotatePointDist * Math.sin(this.angle+Math.PI/2)
            )
        }
    }

// #######################  Application Mechanics (Undo/Redo/Duplicate/Save/Load)  #################################

    Cubicle.prototype.duplicate = function(original){
        var pointObj;
        var points = original.points;
        var len = original.points.length;
        for(var i = 0;i < len;i++){
            pointObj = points[i];
            this.points.push(new point(pointObj.x,pointObj.y,pointObj.id.substring(0,6)+this.id))
        }

        len = this.packageParameters.length;
        for(var i = 0;i < len;i++){
            if(this.packageParameters[i] != "id"){ // Don't want to copy the original object's unique id
                // Note package parameters can't be objects                
                this[this.packageParameters[i]] = original[this.packageParameters[i]];
            }
        }

        for(var i in original.entrances){
            this.entrances[i] = {};
            this.entrances[i].start = original.entrances[i].start;
            this.entrances[i].end = original.entrances[i].end;
            this.entrances[i].object = new CubicleEntrance(i,this.id,this.areaFill,
                this.cubicleWallThickness,this.state,this.map);
            this.entrances[i].object.duplicate(original.entrances[i].object);
        }

        this.createSVG();
        this.addLabels();
        this.moveByDist(12,12);
    }

    Cubicle.prototype.createPackage = function(){
        var package = {points:[]};
        var len = this.points.length;
        var len2 = this.packageParameters.length;
        for(var i = 0;i < len;i++){
            package.points.push(this.points[i].getPoint());
        }
        for(var i = 0;i < len2;i++){
            package[this.packageParameters[i]] = this[this.packageParameters[i]];
        }
        package.controller = "furniture";
        package.packageType = "modify";
        return package;
    }

    Cubicle.prototype.loadPackage = function(package){
        switch(package.packageType){
            case "modify":
                var len = this.points.length;
                for(var i = 0;i < len;i++){
                    this.points[i].updatePosition(package.points[i].x,package.points[i].y);
                }
                len = this.packageParameters.length;
                for(var i = 0;i < len;i++){
                    this[this.packageParameters[i]] = package[this.packageParameters[i]];
                }
                this.update();
            break;
            case "modify CubicleEntrance":
                this.entrances[package.id.slice(3,6)].object.loadPackage(package);
            break;
            case "redo create CubicleEntrance":
            case "undo delete CubicleEntrance":
                this.entrances[package.id] = package.object;
                this.entrances[package.id].object.redraw(this.points[package.object.start],
                    this.points[package.object.end]);
            break;
            case "undo create CubicleEntrance":
            case "redo delete CubicleEntrance":
                this.entrances[package.id].object.remove();
                delete this.entrances[package.id];
            break;
        }
    }

    Cubicle.prototype.sendPackages = function(){
        // It is important to know that the undo and redo packages aren't the same.  
        // If they are, there was no real action taken and
        // an undo or redo event will have no apparent effect
        var undo = this.undoPackage;
        var redo = this.createPackage();
        var same = true; // Used to determine whether the two packages are the same (no undo/redo-able event occured)
        for(var i = 0;i < redo.points.length;i++){ // Runs through the points first as the most common changes
            if(undo.points[i].x != redo.points[i].x || undo.points[i].y != redo.points[i].y){
                same = false;
                break; // breaks as soon as a single difference is found
            }
        }       
        if(same){ // No need to start second loop if a difference was already found
            for(var i = 0;i < this.packageParameters.length;i++){
                if(undo[this.packageParameters[i]] != redo[this.packageParameters[i]]){
                    same = false;
                    break; // breaks as soon as a single difference is found
                }
            }
        }
        // Packages are sent simultaneously to prevent having mismatched packages if the action isn't finalized
        if(!same){
            this.state.addUndoPackage(undo);
            this.state.addRedoPackage(redo);
        }
    }

    Cubicle.prototype.save = function(){
        var saveFile = {points:[],entrances:[]};
        var len = this.points.length;
        var len2 = this.packageParameters.length;
        for(var i = 0;i < len;i++){
            saveFile.points.push(this.points[i].getSavePoint());
        }
        for(var i in this.entrances){
            saveFile.entrances.push(this.entrances[i].object.save(this.entrances[i].start,this.entrances[i].end));
        }
        for(var i = 0;i < len2;i++){
            saveFile[this.packageParameters[i]] = this[this.packageParameters[i]];
        }
        return saveFile
    }

    Cubicle.prototype.load = function(saveFile){
        // Note that this method assumes that the create function has not been called - will not work if it has been
        var len = saveFile.points.length;
        var len2 = this.packageParameters.length;
        var points = saveFile.points;
        var pointObj;
        for(var i = 0;i < len;i++){
            pointObj = points[i];
            this.points.push(new point(pointObj.x,pointObj.y,pointObj.id));
        }
        for(var i = 0;i < len2;i++){
            this[this.packageParameters[i]] = saveFile[this.packageParameters[i]];
        }
        for(var i = 0;i < saveFile.entrances.length;i++){
            var entID = saveFile.entrances[i].id.slice(3,6);
            this.entrances[entID] = {};
            this.entrances[entID].start = saveFile.entrances[i].startnum;
            this.entrances[entID].end = saveFile.entrances[i].endnum;
            this.entrances[entID].object = new CubicleEntrance(entID,this.id,this.areaFill,
                this.cubicleWallThickness,this.state,this.map);
            this.entrances[entID].object.load(saveFile.entrances[i]);
        }
        this.createSVG();
        this.addLabels();   
        this.update();
        this.setLabelStyle();
    }

    Cubicle.prototype.createUndoCreatePackage = function(id,type){
        var package = {};
        package.packageType = "undo create "+ type;
        package.controller = "furniture";
        package.id = id;
        package.parent = this.id;
        console.log(package)
        return package;      
    }

    Cubicle.prototype.createRedoDeletePackage = function(id,type){
        
        return this.createUndoCreatePackage(id,type);
    }

    Cubicle.prototype.createRedoCreatePackage = function(id,type){
        var package = {};
        package.packageType = "redo create " + type;
        package.controller = "furniture";
        package.id = id;
        if(type == "CubicleEntrance"){
            package.object = this.entrances[id]
        }
        package.parent = this.id;
        return package;
    }

    Cubicle.prototype.createUndoDeletePackage = function(id,type){
        
        return this.createRedoCreatePackage(id,type);
    }

// ##########################################  Drag and Move Functions  #############################################

    Cubicle.prototype.startDrag = function(options){ // Saves the origin of a drag event for move calculations
        options = options || {};
        var subclass = options.subclass || null;
        this.snapCandidates = options.snapPoints || [];

        if(subclass){
            switch(subclass[2]){
                case "E":
                    var start = this.points[this.entrances[subclass.slice(3,6)].start].getPoint();
                    var end = this.points[this.entrances[subclass.slice(3,6)].end].getPoint();
                    this.entrances[subclass.slice(3,6)].object.startDrag(start,end);
                break;
            }
        } else {
            var len = this.points.length;
            this.undoPackage = this.createPackage();
            for(var i = 0;i < len;i++){
                this.points[i].setDragReference();
            }
        }
    }

    // Drags the wall upon a left-button down on the wall layer svg and dragging the mouse
    Cubicle.prototype.drag = function(subclass){ 
        var map = this.map;
        if(subclass){
            switch(subclass[2]){
                case "E":
                    var points = this.getEdgePoints(map);
                    var start = this.points[points.start].getPoint();
                    var end = this.points[points.end].getPoint();
                    var entrance = this.entrances[subclass.slice(3,6)];
                    entrance.start = points.start;
                    entrance.end = points.end;
                    entrance.object.drag(start,end);
                break;
            }
        } else {
            var coords = map.pointerCoords(); // gets the latest mouse location
            var xMove = coords.x-map.handle.x/map.scale;
            var yMove = coords.y-map.handle.y/map.scale;

            var isSnapCandidates = this.snapCandidates.cubicles.length || this.snapCandidates.other.length;

            var distDragged;
            if(isSnapCandidates && map.snapGridActive){ // This is necessary to snap objects while snap grid is on
                distDragged = this.points[0].dragOffset(xMove,yMove,{gridResolution:map.snapGridResolution,
                    snapToGrid:false});
            } else{
                distDragged = this.points[0].dragOffset(xMove,yMove,{gridResolution:map.snapGridResolution,
                    snapToGrid:map.snapGridActive});  
            }
            this.points[1].dragOffset(distDragged.x,distDragged.y);
            this.points[2].dragOffset(distDragged.x,distDragged.y);
            this.points[3].dragOffset(distDragged.x,distDragged.y);
            this.update(); 

            var isSnapCandidates = this.snapCandidates.cubicles.length || this.snapCandidates.other.length;
            if(isSnapCandidates){
                var cubiclesSnapped = snapObject(this.getCubicleSnapPoints(),this.snapCandidates.cubicles,
                    {points:true,edges:true,sensitivity:this.snapSensitivity});
                if(cubiclesSnapped){
                    xMove += cubiclesSnapped.xMove;
                    yMove += cubiclesSnapped.yMove;
                    for(var i = 0;i < 4;i++){
                        this.points[i].dragOffset(xMove,yMove);
                    }                    
                } else {
                    var otherSnapped = snapObject(this.getCubicleSnapPoints({outside:true}),this.snapCandidates.other,
                    {points:true,edges:true,sensitivity:this.snapSensitivity});
                    if(otherSnapped){
                        xMove += otherSnapped.xMove;
                        yMove += otherSnapped.yMove;
                        for(var i = 0;i < 4;i++){
                            this.points[i].dragOffset(xMove,yMove);
                        }                        
                    } else if(map.snapGridActive){
                        distDragged = this.points[0].dragOffset(xMove,yMove,{gridResolution:map.snapGridResolution,
                            snapToGrid:map.snapGridActive});
                        this.points[1].dragOffset(distDragged.x,distDragged.y);
                        this.points[2].dragOffset(distDragged.x,distDragged.y);
                        this.points[3].dragOffset(distDragged.x,distDragged.y);
                    }
                }
            }
            
            this.update(); 
        }
    }

    Cubicle.prototype.finalizeDrag = function(subclass){
        if(subclass){
            switch(subclass[2]){
                case "E":
                    this.entrances[subclass.slice(3,6)].object.finalizeDrag();
                break;
            }
        } else {
            this.sendPackages();            
        }
    }

    Cubicle.prototype.moveByDist = function(x,y){
        this.points[0].shiftPosition(x,y);
        this.points[1].shiftPosition(x,y);
        this.points[2].shiftPosition(x,y);
        this.points[3].shiftPosition(x,y);
        this.update();
    }

    Cubicle.prototype.move = function(direction,subclass){ 
        if(subclass){
            switch(subclass[2]){
                case "E":
                    this.entrances[subclass.slice(3,6)].object.keyCommand(direction);
                break;
            }            
        } else{
            this.undoPackage = this.createPackage();
            var x = 0;
            var y = 0;
            switch(direction){
                case "up":
                y = -this.map.snapGridResolution;
                break;
                case "down":
                y = this.map.snapGridResolution;
                break;
                case "right":
                x = this.map.snapGridResolution;
                break;
                case "left":
                x = -this.map.snapGridResolution;
                break;
            }
            this.points[0].shiftPosition(x,y);
            this.points[1].shiftPosition(x,y);
            this.points[2].shiftPosition(x,y);
            this.points[3].shiftPosition(x,y);
            this.update();
            this.sendPackages();
        }
    }

// ##########################################  Sub-Object Functions  ###############################################

    Cubicle.prototype.addSubObject = function(type){
        this.deactivate();
        var id = this.incrementObject(type);
        switch(type){
            case "CubicleEntrance":
                this.entrances[id] = {};
                this.entrances[id].start = 3;
                this.entrances[id].end = 0;
                this.entrances[id].object = new CubicleEntrance(id,this.id,this.areaFill,this.cubicleWallThickness,this.state,this.map);
                this.entrances[id].object.create(
                    this.points[this.entrances[id].start].getPoint(),
                    this.points[this.entrances[id].end].getPoint()
                    );
            break;
        }
    }

    Cubicle.prototype.incrementObject = function(type){
        switch(type){
            case "CubicleEntrance":
                this.entranceCounter++;
                return ("000" + this.entranceCounter).slice(-3);
            break;
        }
    }

    Cubicle.prototype.updateSubObjects = function(){
        var start,end,entrance;
        for(var i in this.entrances){
            entrance = this.entrances[i];
            start = this.points[entrance.start].getPoint();
            end = this.points[entrance.end].getPoint();
            entrance.object.update(start,end);
        }
    }

    Cubicle.prototype.removeSubObjects = function(){
        for(var i in this.entrances){
            this.entrances[i].object.remove();
        }        
    }

    Cubicle.prototype.redrawSubObjects = function(){
        for(var i in this.entrances){
            this.entrances[i].object.redraw();
        }        
    }

    Cubicle.prototype.getEdgePoints = function(){ // Used for assigning an edge to a cubicle opening object
        var center = this.getCenter();
        var coords = this.map.pointerCoords();
        var theta = makePositiveAngle(Math.atan2(center.y - coords.y,coords.x - center.x) - this.angle);
        var points = {};
        if(theta <= Math.PI/4 || theta > 7*Math.PI/4){
            points.start = 1;
            points.end = 2;
        } else if(theta <= 3*Math.PI/4 && theta > Math.PI/4){
            points.start = 0;
            points.end = 1;
        } else if(theta <= 5*Math.PI/4 && theta > 3*Math.PI/4){
            points.start = 3;
            points.end = 0;
        } else if(theta <= 7*Math.PI/4 && theta > 5*Math.PI/4){
            points.start = 2;
            points.end = 3;
        }
        return points;
    }

// ##########################################  Object SVG Functions  ##############################################

    Cubicle.prototype.createSVG = function(){
        var areaPath = this.getAreaPath();

        var cubicleArea = document.createElementNS('http://www.w3.org/2000/svg', 'path');
        cubicleArea.setAttribute('d',areaPath);
        cubicleArea.setAttribute('id',"a"+this.id);
        cubicleArea.setAttribute('class',"furniture cubicle");
        cubicleArea.setAttribute('pointer-events',"all");
        cubicleArea.setAttribute('style',"stroke-linecap:square;stroke:"+this.stroke+";fill:"+this.areaFill+";stroke-width:"+this.cubicleWallThickness);
        $('#cubicleArea').append(cubicleArea);
        this.cubicleArea = $("#a" + this.id);

        var cubicleSelection = document.createElementNS('http://www.w3.org/2000/svg', 'path');
        cubicleSelection.setAttribute('d',areaPath);
        cubicleSelection.setAttribute('id',"g"+this.id);
        cubicleSelection.setAttribute('class',"mapObj-selection");
        cubicleSelection.setAttribute('style',"stroke-width:"+this.cubicleWallThickness);
        $('#cubicleSelected').append(cubicleSelection);
        this.cubicleSelection = $("#g" + this.id);

        var cubiclePost = document.createElementNS('http://www.w3.org/2000/svg', 'path');
        cubiclePost.setAttribute('d',this.getPostPath(this.points[0],this.angle-Math.PI/4));
        cubiclePost.setAttribute('id',"b"+this.id);
        cubiclePost.setAttribute('class',"furniture cubicle");
        cubiclePost.setAttribute('pointer-events',"all");
        cubiclePost.setAttribute('style',"fill:"+this.cornerPanelColor+";");
        $('#cubicleArea').append(cubiclePost);
        this.cubiclePost1 = $("#b" + this.id);
        
        cubiclePost = document.createElementNS('http://www.w3.org/2000/svg', 'path');
        cubiclePost.setAttribute('d',this.getPostPath(this.points[1],this.angle-3*Math.PI/4));
        cubiclePost.setAttribute('id',"c"+this.id);
        cubiclePost.setAttribute('class',"furniture cubicle");
        cubicleArea.setAttribute('pointer-events',"all");
        cubiclePost.setAttribute('style',"fill:"+this.cornerPanelColor+";");
        $('#cubicleArea').append(cubiclePost);
        this.cubiclePost2 = $("#c" + this.id);
        
        cubiclePost = document.createElementNS('http://www.w3.org/2000/svg', 'path');
        cubiclePost.setAttribute('d',this.getPostPath(this.points[2],this.angle+3*Math.PI/4));
        cubiclePost.setAttribute('id',"d"+this.id);
        cubiclePost.setAttribute('class',"furniture cubicle");
        cubicleArea.setAttribute('pointer-events',"all");
        cubiclePost.setAttribute('style',"fill:"+this.cornerPanelColor+";");
        $('#cubicleArea').append(cubiclePost);
        this.cubiclePost3 = $("#d" + this.id);
        
        cubiclePost = document.createElementNS('http://www.w3.org/2000/svg', 'path');
        cubiclePost.setAttribute('d',this.getPostPath(this.points[3],this.angle+Math.PI/4));
        cubiclePost.setAttribute('id',"e"+this.id);
        cubiclePost.setAttribute('class',"furniture cubicle");
        cubicleArea.setAttribute('pointer-events',"all");
        cubiclePost.setAttribute('style',"fill:"+this.cornerPanelColor+";");
        $('#cubicleArea').append(cubiclePost);
        this.cubiclePost4 = $("#e" + this.id);

        var cubiclePanel = document.createElementNS('http://www.w3.org/2000/svg', 'path');
        cubiclePanel.setAttribute('d',this.getPanelPaths());
        cubiclePanel.setAttribute('id',"f"+this.id);
        cubiclePanel.setAttribute('class',"furniture cubicle");
        cubiclePanel.setAttribute('pointer-events',"all");
        cubiclePanel.setAttribute('style',"stroke:"+this.cornerPanelColor+";stroke-width:"+.25+";");
        $('#cubicleArea').append(cubiclePanel);
        this.cubiclePanel = $("#f" + this.id);
    }

    Cubicle.prototype.getAreaPath = function(){
        var offset = this.cubicleWallThickness/2; // Needed since strokes follow the edge of a path and would end up increasing size
        var cornerOffset = Math.sqrt(2*Math.pow(offset,2));
        var outerOffset0 = {
            x: this.points[0].x + cornerOffset * Math.cos(this.angle - Math.PI/4),
            y: this.points[0].y - cornerOffset * Math.sin(this.angle - Math.PI/4)
        }
        var outerOffset1 = {
            x: this.points[1].x + cornerOffset * Math.cos(this.angle - 3*Math.PI/4),
            y: this.points[1].y - cornerOffset * Math.sin(this.angle - 3*Math.PI/4)
        }
        var outerOffset2 = {
            x: this.points[2].x + cornerOffset * Math.cos(this.angle + 3*Math.PI/4),
            y: this.points[2].y - cornerOffset * Math.sin(this.angle + 3*Math.PI/4)
        }
        var outerOffset3 = {
            x: this.points[3].x + cornerOffset * Math.cos(this.angle + Math.PI/4),
            y: this.points[3].y - cornerOffset * Math.sin(this.angle + Math.PI/4)
        }
        var path = ""
        path += "M " + outerOffset0.x + " " + outerOffset0.y; // Start point at upper left
        path += "L " + outerOffset1.x + " " + outerOffset1.y;  // Point at the upper right
        path += "L " + outerOffset2.x + " " + outerOffset2.y;  // Point at the lower right
        path += "L " + outerOffset3.x + " " + outerOffset3.y;  // Point at the lower left
        path += "Z";  // Return and close of position
        return path;
    }

    Cubicle.prototype.getPostPath = function(ref,angle){ 
        // Angle is the angle between the reference point and opposite corner
        var size = this.cubicleWallThickness;
        var diag = Math.sqrt(2*Math.pow(size,2));
        var point0 = {
            x:ref.x,
            y:ref.y
        }
        var point1 = {
            x:ref.x + size * Math.cos(angle + Math.PI/4),
            y:ref.y - size * Math.sin(angle + Math.PI/4)
        }
        var point2 = {
            x:ref.x + diag * Math.cos(angle),
            y:ref.y - diag * Math.sin(angle)
        }
        var point3 = {
            x:ref.x + size * Math.cos(angle - Math.PI/4),
            y:ref.y - size * Math.sin(angle - Math.PI/4)
        }
        var path = ""
        path += "M " + point0.x + " " + point0.y; // Start point at upper left
        path += "L " + point1.x + " " + point1.y;  // Point at the upper right
        path += "L " + point2.x + " " + point2.y;  // Point at the lower right
        path += "L " + point3.x + " " + point3.y;  // Point at the lower left
        path += "Z";  // Return and close of position
        return path;
    }

    Cubicle.prototype.getPanelPaths = function(){
        var widthPanel = (this.width - 2*this.cubicleWallThickness)/this.widthPanels;
        var lengthPanel = (this.length - 2*this.cubicleWallThickness)/this.lengthPanels;
        var startPoint = {
            x: this.points[0].x + this.cubicleWallThickness * Math.cos(this.angle),
            y: this.points[0].y - this.cubicleWallThickness * Math.sin(this.angle)
        }
        var nextPoint = {};
        path = ""
        for(var i = 0;i < this.widthPanels-1;i++){
            nextPoint.x = startPoint.x+widthPanel*Math.cos(this.angle);
            nextPoint.y = startPoint.y-widthPanel*Math.sin(this.angle);
            path += "M " + nextPoint.x + " " + nextPoint.y;
            path += "l " + (this.cubicleWallThickness*Math.cos(this.angle-Math.PI/2)) + " " + 
                (-this.cubicleWallThickness*Math.sin(this.angle-Math.PI/2));
            startPoint = {x:nextPoint.x,y:nextPoint.y};
        }
        startPoint = {
            x: this.points[2].x + this.cubicleWallThickness * Math.cos(this.angle+Math.PI),
            y: this.points[2].y - this.cubicleWallThickness * Math.sin(this.angle+Math.PI)
        }
        for(var i = 0;i < this.widthPanels-1;i++){
            nextPoint.x = startPoint.x+widthPanel*Math.cos(this.angle+Math.PI);
            nextPoint.y = startPoint.y-widthPanel*Math.sin(this.angle+Math.PI);
            path += "M " + nextPoint.x + " " + nextPoint.y;
            path += "l " + (this.cubicleWallThickness*Math.cos(this.angle+Math.PI/2)) + " " + 
                (-this.cubicleWallThickness*Math.sin(this.angle+Math.PI/2));
            startPoint = {x:nextPoint.x,y:nextPoint.y};
        }
        startPoint = {
            x: this.points[1].x + this.cubicleWallThickness * Math.cos(this.angle-Math.PI/2),
            y: this.points[1].y - this.cubicleWallThickness * Math.sin(this.angle-Math.PI/2)
        }
        for(var i = 0;i < this.lengthPanels-1;i++){
            nextPoint.x = startPoint.x+lengthPanel*Math.cos(this.angle-Math.PI/2);
            nextPoint.y = startPoint.y-lengthPanel*Math.sin(this.angle-Math.PI/2);
            path += "M " + nextPoint.x + " " + nextPoint.y;
            path += "l " + (this.cubicleWallThickness*Math.cos(this.angle+Math.PI)) + " " + 
                (-this.cubicleWallThickness*Math.sin(this.angle+Math.PI));
            startPoint = {x:nextPoint.x,y:nextPoint.y};
        }
        startPoint = {
            x: this.points[3].x + this.cubicleWallThickness * Math.cos(this.angle+Math.PI/2),
            y: this.points[3].y - this.cubicleWallThickness * Math.sin(this.angle+Math.PI/2)
        }
        for(var i = 0;i < this.lengthPanels-1;i++){
            nextPoint.x = startPoint.x+lengthPanel*Math.cos(this.angle+Math.PI/2);
            nextPoint.y = startPoint.y-lengthPanel*Math.sin(this.angle+Math.PI/2);
            path += "M " + nextPoint.x + " " + nextPoint.y;
            path += "l " + (this.cubicleWallThickness*Math.cos(this.angle)) + " " + 
                (-this.cubicleWallThickness*Math.sin(this.angle));
            startPoint = {x:nextPoint.x,y:nextPoint.y};
        }
        return path;
    }

    Cubicle.prototype.cancelDraw = function(){
        
        this.remove();
    }

    Cubicle.prototype.dragPlace = function(type){
        var map = this.map;
        if(type){
            switch(type){
                case "CubicleEntrance":
                    var points = this.getEdgePoints();
                    var start = this.points[points.start].getPoint();
                    var end = this.points[points.end].getPoint();
                    var entrance = this.entrances[("000"+this.entranceCounter).slice(-3)];
                    entrance.start = points.start;
                    entrance.end = points.end;
                    entrance.object.dragPlace(start,end);
                break;
            }
        } else{
            var pos = map.pointerCoords(); // gets the latest mouse location
            var isSnapCandidates = this.snapCandidates.cubicles.length || this.snapCandidates.other.length;

            if(map.snapGridActive){
                pos.x = map.snapRound(pos.x);
                pos.y = map.snapRound(pos.y);
            }
            this.points[0].updatePosition(pos.x,pos.y);
            this.points[1].updatePosition(pos.x+this.defaultSize.width,pos.y);
            this.points[2].updatePosition(pos.x+this.defaultSize.width,pos.y+this.defaultSize.height);
            this.points[3].updatePosition(pos.x,pos.y+this.defaultSize.height);

            if(isSnapCandidates){
                var xMove,yMove;
                var cubiclesSnapped = snapObject(this.getCubicleSnapPoints(),this.snapCandidates.cubicles,
                    {points:true,edges:true,sensitivity:this.snapSensitivity});
                if(cubiclesSnapped){ // Cubicles snap to cubicles before snapping to anything else
                    xMove = cubiclesSnapped.xMove;
                    yMove = cubiclesSnapped.yMove;
                    for(var i = 0;i < 4;i++){
                        this.points[i].shiftPosition(xMove,yMove);
                    }                    
                } else {
                    var otherSnapped = snapObject(this.getCubicleSnapPoints({outside:true}),this.snapCandidates.other,
                    {points:true,edges:true,sensitivity:this.snapSensitivity});
                    if(otherSnapped){
                        xMove = otherSnapped.xMove;
                        yMove = otherSnapped.yMove;
                        for(var i = 0;i < 4;i++){
                            this.points[i].shiftPosition(xMove,yMove);
                        }                        
                    } else if(map.snapGridActive){  // This reimplements snapgrid if no snaps matches are found
                        pos.x = map.snapRound(pos.x,undefined,true);
                        pos.y = map.snapRound(pos.y,undefined,true);
                        this.points[0].updatePosition(pos.x,pos.y);
                        this.points[1].updatePosition(pos.x+this.defaultSize.width,pos.y);
                        this.points[2].updatePosition(pos.x+this.defaultSize.width,pos.y+this.defaultSize.height);
                        this.points[3].updatePosition(pos.x,pos.y+this.defaultSize.height);
                    }
                }
            }
            this.update();            
        }
    }

    Cubicle.prototype.finalizeDragPlace = function(subcategory){
        if(subcategory){
            switch(subcategory){
                case "CubicleEntrance":
                    var objNo = ("000"+this.entranceCounter).slice(-3);
                    this.entrances[objNo].object.finalizeDragPlace();
                    this.state.addUndoPackage(this.createUndoCreatePackage(objNo,subcategory));
                    this.state.addRedoPackage(this.createRedoCreatePackage(objNo,subcategory)); 
                break;
            }
        } else{
            this.createRotatePoint();
            this.addLabels();
            this.setLabelStyle(this.labelStyle);
            this.update();
        }
    }

    Cubicle.prototype.updateSVG = function(){
        var areaPath = this.getAreaPath();
        this.cubicleArea.attr("d",areaPath);
        this.cubicleSelection.attr("d",areaPath)
        this.cubiclePost1.attr("d",this.getPostPath(this.points[0],this.angle-Math.PI/4));
        this.cubiclePost2.attr("d",this.getPostPath(this.points[1],this.angle-3*Math.PI/4));
        this.cubiclePost3.attr("d",this.getPostPath(this.points[2],this.angle+3*Math.PI/4));
        this.cubiclePost4.attr("d",this.getPostPath(this.points[3],this.angle+Math.PI/4));
        this.cubiclePanel.attr("d",this.getPanelPaths());
    }

    Cubicle.prototype.removeSVG = function(){
        this.cubicleArea.remove();
        this.cubicleSelection.remove();
        this.cubiclePost1.remove();
        this.cubiclePost2.remove();
        this.cubiclePost3.remove();
        this.cubiclePost4.remove();
        this.cubiclePanel.remove();
    }

    Cubicle.prototype.updateSidePoints = function(){
        this.points[4].updatePosition((this.points[0].x+this.points[1].x)/2,(this.points[0].y+this.points[1].y)/2); // Top Edge
        this.points[5].updatePosition((this.points[1].x+this.points[2].x)/2,(this.points[1].y+this.points[2].y)/2); // Right Edge
        this.points[6].updatePosition((this.points[2].x+this.points[3].x)/2,(this.points[2].y+this.points[3].y)/2); // Bottom Edge
        this.points[7].updatePosition((this.points[3].x+this.points[0].x)/2,(this.points[3].y+this.points[0].y)/2); // Left Edge
    }

// #######################################  Object Calculation Functions  ##########################################

    Cubicle.prototype.calculateLength = function(){  // Side Edge
        
        this.length = getLength(this.points[0],this.points[3]);
    }

    Cubicle.prototype.calculateWidth = function(){  // Top Edge
        
        this.width = getLength(this.points[0],this.points[1]);
    }

    Cubicle.prototype.calculateAngle = function(){  // Angle of top edge
        
        this.angle = getAngle(this.points[0],this.points[1]);
    }

    Cubicle.prototype.getCenter = function(){ // Assumes rectangle
        this.centerPoint = {
            x:(this.points[0].x + this.points[2].x)/2 ,
            y:(this.points[0].y + this.points[2].y)/2
        }
        return this.centerPoint;
    }

// ##########################################   Label Functions  ###################################################

    // Changes the display behavior of the distance labels based on a style number from a slider
    Cubicle.prototype.setLabelStyle = function(styleNumber){ 
        this.labelStyle = styleNumber === undefined ? this.labelStyle : styleNumber;
        switch(this.labelStyle){
            case 0: // Never show labels
                this.removeLabels();
            break;
            case 1: // Only show labels when selected
                this.isSelected ? this.redrawLabels() : this.removeLabels();
            break;
            case 2: // Always show labels
                this.redrawLabels();
            break;
        }
        return this.labelStyle;
    }

    Cubicle.prototype.addLabels = function(){ // Creates a length label object and adds it to the object
        if(!this.lengthLabel){
            var id = generateUUID();
            this.lengthLabel = new pathTextLabel("LL"+id,this.points[3].getPoint(),this.points[0].getPoint(),this.labelColor,this.labelSize,"50%",-5,"labelGroup");
            this.lengthLabel.draw();
            this.widthLabel = new pathTextLabel("WL"+id,this.points[0].getPoint(),this.points[1].getPoint(),this.labelColor,this.labelSize,"50%",-5,"labelGroup");
            this.widthLabel.draw();
            this.updateLabels();            
        }
    }

    Cubicle.prototype.removeLabels = function(){  // Removes the length label from the wall
        if(this.lengthLabel){
            this.lengthLabel.remove();
            this.widthLabel.remove();
        }
    }

    Cubicle.prototype.redrawLabels = function(){
        if(this.lengthLabel){
            this.lengthLabel.redraw();
            this.widthLabel.redraw(); 
        }
    }

    Cubicle.prototype.updateLabels = function(){
        if(this.lengthLabel){
            this.lengthLabel.update(this.renderLength(this.length),this.points[3].getPoint(),this.points[0].getPoint());
            this.widthLabel.update(this.renderLength(this.width),this.points[0].getPoint(),this.points[1].getPoint());             
        }
    }

// ##########################################  Selector Interface Functions  ########################################

    Cubicle.prototype.setProperty = function(property,value,subcategory,id){
        if(subcategory){
            switch(id[2]){
                case "E": // Entrance
                    thisData = this.entrances[id.slice(3,6)].object.setProperty(property,value);
                break;
            }
        } else{
            switch(property){
                case "objectLength":
                    this.setobjectLength(value);
                break;
                case "objectWidth":
                    this.setobjectWidth(value);
                break;
                case "objectAngle":
                    this.setobjectAngle(toRads(value));
                break;
                case "objectStrokeColor":
                    this.setobjectStrokeColor(value);
                break;
                case "objectFillColor":
                    this.setobjectFillColor(value);
                break;
                case "objectAreaColor":
                    this.setobjectAreaColor(value);
                break;
                case "objectLabelStyle":
                    this.setLabelStyle(value);
                break;
                case "objectLabelColor":
                    this.labelColor = value;
                    this.lengthLabel.setColor(value);
                    this.widthLabel.setColor(value);
                break;
                case "objectLabelSize":
                    this.labelSize = value;
                    this.lengthLabel.setFontSize(value);
                    this.widthLabel.setFontSize(value);
                break;
            }
        }
    }

    Cubicle.prototype.getProperties = function(subcategory,id){
        var thisData = {};
        if(subcategory){
            switch(id[2]){
                case "E": // Entrance
                    thisData = this.entrances[id.slice(3,6)].object.getProperties();
                break;
            }
        } else{
            thisData.data = {
                objectType: {type:"label",value:"Cubicle"},
                objectLength: {type:"spinner",value:this.renderLength(this.length)},
                objectWidth: {type:"spinner",value:this.renderLength(this.width)},
                objectAngle: {type:"spinner",value:toDeg(this.angle)},
                objectStrokeColor: {type:"color",value:this.stroke},
                objectFillColor: {type:"color",value:this.areaFill},
                objectLabelStyleText: {type:"na",value:Cubicle.prototype.slide(null,{value:this.labelStyle})},
                objectLabelStyle: {type:"slider",value:this.labelStyle,min:0,max:2,slide:Cubicle.prototype.slide},
                objectLabelColor: {type:"na",value:this.labelColor},
                objectLabelSize: {type:"spinner",value:this.lengthLabel.fontSize},
            }
            thisData.dividers = {
                sizeDivider:true,
                positionDivider:true,
                colorDivider:true,
                labelsDivider:true
            }            
        }
        return thisData;
    }

    Cubicle.prototype.slide = function(event,ui){
            var message = "";
            switch(ui.value){
                case 0:
                message = "No Labels"
                break;
                case 1:
                message = "Show Labels on Select"
                break;
                case 2:
                message = "Always Show Labels"
                break;
            }
            $( "#objectLabelStyleText" ).html(message);
    }

    Cubicle.prototype.setobjectLength = function(value){
        var newX3 = value * Math.cos(this.angle - Math.PI/2) + this.points[0].x;
        var newY3 = -value * Math.sin(this.angle - Math.PI/2) + this.points[0].y;
        var newX2 = value * Math.cos(this.angle - Math.PI/2) + this.points[1].x;
        var newY2 = -value * Math.sin(this.angle - Math.PI/2) + this.points[1].y;
        this.points[2].updatePosition(newX2,newY2);
        this.points[3].updatePosition(newX3,newY3);
        this.update();
    }

    Cubicle.prototype.setobjectWidth = function(value){
        var newX1 = value * Math.cos(this.angle) + this.points[0].x;
        var newY1 = -value * Math.sin(this.angle) + this.points[0].y;
        var newX2 = value * Math.cos(this.angle) + this.points[3].x;
        var newY2 = -value * Math.sin(this.angle) + this.points[3].y;
        this.points[1].updatePosition(newX1,newY1);
        this.points[2].updatePosition(newX2,newY2);
        this.update();
        return this.width;
    }

    Cubicle.prototype.setStrokeWidth = function(value){
        this.cubicleWallThickness = value;
        this.update();
        return this.cubicleWallThickness;
    }

    Cubicle.prototype.setobjectAngle = function(angle){
        this.getCenter();
        this.points[0].setRotateAngle(this.centerPoint.x,this.centerPoint.y,this.angle);
        this.points[1].setRotateAngle(this.centerPoint.x,this.centerPoint.y,this.angle);
        this.points[2].setRotateAngle(this.centerPoint.x,this.centerPoint.y,this.angle);
        this.points[3].setRotateAngle(this.centerPoint.x,this.centerPoint.y,this.angle);
        this.points[0].rotateAroundCenter(this.centerPoint.x,this.centerPoint.y,angle);
        this.points[1].rotateAroundCenter(this.centerPoint.x,this.centerPoint.y,angle);
        this.points[2].rotateAroundCenter(this.centerPoint.x,this.centerPoint.y,angle);
        this.points[3].rotateAroundCenter(this.centerPoint.x,this.centerPoint.y,angle);
        this.update();
    }

    Cubicle.prototype.setStrokeWidth = function(value){
        this.cubicleWallThickness = value;
        this.update();
        return this.cubicleWallThickness;
    }

    Cubicle.prototype.setobjectStrokeColor = function(color){
        var isOk  = /(^#[0-9A-F]{6}$)|(^#[0-9A-F]{3}$)/i.test(color)
        if(isOk){
            this.stroke = color;
        } else {
            console.log("color not recognized")
        }
        this.cubicleArea.css("stroke",this.stroke);
    }

    Cubicle.prototype.setobjectFillColor = function(color){
        var isOk  = /(^#[0-9A-F]{6}$)|(^#[0-9A-F]{3}$)/i.test(color)
        if(isOk){
            this.areaFill = color;
        } else {;
            console.log("color not recognized")
        }
        this.cubicleArea.css("fill",this.areaFill);
    }