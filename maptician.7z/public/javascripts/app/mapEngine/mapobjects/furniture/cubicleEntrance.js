function CubicleEntrance(id,parentID,fill,lineWidth,state,map){
    MapObject.call(this,"CubicleEntrance",id); // Sets Door as subclass of MapObject
    this.type = "CubicleEntrance";
    this.state = state; // Reference to the State Controller
    this.map = map; // Reference to the Map Controller
    // id is composed of 4 parts for routing purposes, the first 2 digits indicate the controller for the parent object
    // the next point indicates the type of subobject on the parent, the next 3 digits indicate a unique number
    // for the subobject which is its key on the parent's collection object, the remainder of the digits are the
    // id for the parent object.  
    this.id = "FNE"+id+parentID;
    this.handleDragging = "";
    this.isSelected = false;
    this.parent = parentID;

    // Styling
	this.startDist = 10;
    this.endDist = 10;
	this.fill = fill;
    this.postColor = "#808080";
    this.selectedColor = "#E6CFD3";

    // Labels
    this.labels = [];
    this.labelStyle = 4;
    this.labelColor = "#000000";
    this.labelFontSize = 7;

    // Points
    this.points = [];

    // SVG aliases
    this.entrance = null;
    this.posts = null;

    // Calculated and Placeholder
    this.lineWidth = lineWidth; // Thickness of the cubicle walls - populated from parent cubicle
    this.width = 36;
    this.multiselect = false;

    // Constants
    this.minimumWidth = 12;
    this.moveStep = 1; // Amount the window will move or resize by with a key command

    this.packageParameters = [ // Used in undo/redo/duplicate/save/load methods
        "type",
        "id",
        "lineWidth",
        "startDist",
        "endDist",
        "fill",
        "postColor",
        "labelStyle",
        "labelColor",
        "labelFontSize"
    ];

}
CubicleEntrance.prototype = Object.create(MapObject.prototype); // Links the prototype to the superclass
CubicleEntrance.prototype.constructor = CubicleEntrance;

// ##########################################  Standard Object Interface Functions  ##################################################################

    CubicleEntrance.prototype.create = function(startPoint,endPoint){ // This creates all components of the window object
        var length = getLength(startPoint,endPoint);
        if(length < this.width){this.width = length;}
        this.points[0] = new point(startPoint.x,startPoint.y,this.id + "00");
        this.points[1] = new point(endPoint.x,endPoint.y,this.id + "01");
        this.points[2] = new point(startPoint.x,startPoint.y,this.id + "02");
        this.points[3] = new point(endPoint.x,endPoint.y,this.id + "03");
        this.createSVG();
        this.addLabels(); 
    }

    CubicleEntrance.prototype.update = function(start,end){  // This is the basic update function that should occur every time a change is made that would affect layout
        if(start && end){
            this.points[0].updatePosition(start);
            this.points[1].updatePosition(end);
        }
        this.constrain();
        this.updateSVG();
        this.updateWidthLabel();
        this.setLabelStyle();
    }

    CubicleEntrance.prototype.remove = function(){  // Removes all the screen elements of the window, once done, the window object can be deleted safely
        this.removeHandles();
        this.removeSVG();        
        this.removeLabels();
    }

    CubicleEntrance.prototype.redraw = function(start,end){ // Redraws the svg objects after they have been removed
        if(start && end){
            this.points[0].updatePosition(start);
            this.points[1].updatePosition(end);
        }
        this.constrain();
        this.createSVG();
        this.setLabelStyle();
    }

    CubicleEntrance.prototype.activate = function(){
        this.isSelected = true;
        this.entrance.css({stroke:this.selectedColor}); // Changes the opening color
        this.drawHandles();
        this.setLabelStyle();
        this.update();
    }

    CubicleEntrance.prototype.deactivate = function(){
        this.isSelected = false;
        this.removeHandles();
        this.setLabelStyle(); // Sets the label style based on the current value
        this.entrance.css({stroke:this.fill}); // Changes the window opening color
    }

// ##########################################  Mouse and keyboard event handler Functions  ##################################################################

    CubicleEntrance.prototype.handlePress = function(handleID){ 
        for(var i = 0;i < this.points.length;i++){
            this.points[i].setDragReference();
        }
        this.undoPackage = this.createPackage();
    }

    CubicleEntrance.prototype.handleDrag = function(id){ 
        switch(id.slice(-2)*1){
            case 2:
                this.dragInsideEndcap();
            break;
            case 3:
                this.dragOutsideEndcap();
            break;
        }
        this.update();
    }

    CubicleEntrance.prototype.finalizeHandleDrag = function(){

        this.sendPackages();
    }    

    CubicleEntrance.prototype.drawHandles = function(){
        for(var i = 2;i < this.points.length;i++){
            this.points[i].drawHandle();
        }
    }

    CubicleEntrance.prototype.removeHandles = function(){
        for(var i = 2;i < this.points.length;i++){
            this.points[i].removeHandle();
        }          
    }

    CubicleEntrance.prototype.constrain = function(){
        var lineLength = getLength(this.points[0],this.points[1]);
        this.startDist = Math.max(Math.min(this.startDist,lineLength-this.endDist-12),0);
        this.endDist = Math.max(Math.min(this.endDist,lineLength-this.startDist-12),0);
        this.width = lineLength - this.startDist - this.endDist;
    }

    CubicleEntrance.prototype.dragOutsideEndcap = function(){
        var coords = this.map.pointerCoords();
        var A1 = coords.x - this.points[0].x;
        var L1 = this.points[0].y - coords.y;
        var H1 = Math.sqrt(Math.pow(A1,2)+Math.pow(L1,2));
        var theta2 = Math.atan2(L1,A1);
        var theta3 = getAngle(this.points[0],this.points[1]) - theta2;
        var dist = H1 * Math.cos(theta3);
        var width = dist - this.startDist;
        var lineLength = getLength(this.points[0],this.points[1]);
        this.width = this.map.snapRound(Math.min(Math.max(width,12),lineLength-this.startDist),1);
        this.endDist = lineLength - this.width - this.startDist;
    }

    CubicleEntrance.prototype.dragInsideEndcap = function(){
        var coords = this.map.pointerCoords();
        var A1 = coords.x - this.points[0].x;
        var L1 = this.points[0].y - coords.y;
        var H1 = Math.sqrt(Math.pow(A1,2)+Math.pow(L1,2));
        var theta2 = Math.atan2(L1,A1);
        var theta3 = getAngle(this.points[0],this.points[1]) - theta2;
        var dist = H1 * Math.cos(theta3);
        var lineLength = getLength(this.points[0],this.points[1]);

        var width = lineLength - this.endDist - dist;
        width = Math.max(width,12);
        this.width = Math.min(width,lineLength-this.endDist);
        this.startDist = lineLength - this.endDist -this.width;
    }

// ##########################################  Application Mechanics (Undo/Redo/Duplicate/Save/Load)  #############################################

    CubicleEntrance.prototype.duplicate = function(original){
        for(var i = 0;i < original.points.length;i++){
            this.points.push(new point(original.points[i].x,original.points[i].y,this.id + original.points[i].id.substring(-2)))
        }
        for(var i = 0;i < this.packageParameters.length;i++){
            if(this.packageParameters[i] != "id"){
                this[this.packageParameters[i]] = original[this.packageParameters[i]];
            }
        }
        this.createSVG();
        this.addLabels(); // This creates the three part label giving the distance before and after the door, as well as the door itself
        this.setLabelStyle();
        this.update();      
    }

    CubicleEntrance.prototype.createPackage = function(){
        var package = {points:[]};
        for(var i = 0;i < this.points.length;i++){
            package.points.push(this.points[i].getPoint());
        }
        for(var i = 0;i < this.packageParameters.length;i++){
            package[this.packageParameters[i]] = this[this.packageParameters[i]];
        }
        package.controller = "furniture";
        package.packageType = "modify CubicleEntrance";
        package.parent = this.parent;
        return package;
    }

    CubicleEntrance.prototype.loadPackage = function(package,start,end){
        // It doesn't matter if it is an undo or redo package, the impact is to reset the object to a former state
        for(var i = 0;i < this.points.length;i++){
            this.points[i].updatePosition(package.points[i].x,package.points[i].y);
        }
        for(var i = 0;i < this.packageParameters.length;i++){
            this[this.packageParameters[i]] = package[this.packageParameters[i]];
        }
        this.update();
    }

    CubicleEntrance.prototype.sendPackages = function(){
        // It is important to know that the undo and redo packages aren't the same.  If they are, there was no real action taken and
        // an undo or redo event will have no apparent effect
        var undo = this.undoPackage;
        var redo = this.createPackage();
        var same = true; // Used to determine whether the two packages are the same (no actual event occured)
        for(var i = 0;i < redo.points.length;i++){ // Runs through the points first as the most common event changes
            if(undo.points[i].x != redo.points[i].x || undo.points[i].y != redo.points[i].y){
                same = false;
                break; // breaks as soon as a single difference is found
            }
        }       
        if(same){ // No need to start second loop if a difference was already found
            for(var i = 0;i < this.packageParameters.length;i++){
                if(undo[this.packageParameters[i]] != redo[this.packageParameters[i]]){
                    same = false;
                    break;
                }
            }
        }
        // Packages are sent essentially simultaneously to prevent having mismatched packages if the action isn't finalized
        if(same == false){
            this.state.addUndoPackage(undo);
            this.state.addRedoPackage(redo);
        }
    }

    CubicleEntrance.prototype.save = function(startnum,endnum){
        var saveFile = {points:[]}
        for(var i = 0;i < this.points.length;i++){
            saveFile.points.push(this.points[i].getSavePoint());
        }
        for(var i = 0;i < this.packageParameters.length;i++){
            saveFile[this.packageParameters[i]] = this[this.packageParameters[i]];
        }
        saveFile.startnum = startnum;
        saveFile.endnum = endnum;
        return saveFile
    }

    CubicleEntrance.prototype.load = function(saveFile){
        // Note that this method assumes that the create function has not been called - will not work if it has been
        for(var i = 0;i < saveFile.points.length;i++){
            this.points.push(new point(saveFile.points[i].x,saveFile.points[i].y,saveFile.points[i].id));
        }
        for(var i = 0;i < this.packageParameters.length;i++){
            this[this.packageParameters[i]] = saveFile[this.packageParameters[i]];
        }
        this.createSVG(); 
        this.addLabels();
        this.update();
    }

// ##########################################  Drag and Move Functions  #############################################

    CubicleEntrance.prototype.startDrag = function(start,end){ // Occurs at the beginning of a drag event
        this.undoPackage = this.createPackage();
        var coords = this.map.pointerCoords();
        var A1 = coords.x - start.x;
        var L1 = start.y - coords.y;
        var H1 = Math.sqrt(Math.pow(A1,2)+Math.pow(L1,2));
        var theta = getAngle(start,end);
        var theta2 = Math.atan2(L1,A1);
        var theta3 = theta2 - theta;
        var dist = H1 * Math.cos(theta3) - this.width/2; 
        this.dragHandle = dist - this.startDist;
    }

    CubicleEntrance.prototype.drag = function(start,end){ // Occurs with each movement in a drag event
        this.points[0].updatePosition(start);
        this.points[1].updatePosition(end);
        var coords = this.map.pointerCoords();
        var A1 = coords.x - start.x;
        var L1 = start.y - coords.y;
        var H1 = Math.sqrt(Math.pow(A1,2)+Math.pow(L1,2));
        var theta = getAngle(start,end);
        var theta2 = Math.atan2(L1,A1);
        var theta3 = theta2 - theta;
        var dist = this.map.snapRound(H1 * Math.cos(theta3) - this.width/2 - this.dragHandle,1); 
        var lineLength = getLength(start,end);
        dist = Math.min(Math.max(dist,0),lineLength-this.width);
        this.startDist = dist;
        this.endDist = lineLength - this.width - this.startDist;
        this.update(); 
    }

    CubicleEntrance.prototype.finalizeDrag = function(){
        this.sendPackages();
    }

    CubicleEntrance.prototype.dragPlace = function(start,end){
        this.dragHandle = 0;
        this.drag(start,end);      
    }

    CubicleEntrance.prototype.finalizeDragPlace = function(){
        this.labelStyle = 2;
        this.setLabelStyle();
    }

    CubicleEntrance.prototype.keyCommand = function(direction){  // Handler for keyboard commands, primarily the arrow keys
        this.undoPackage = this.createPackage();
        switch(direction){
            case "up":
                this.width += this.moveStep;
                this.endDist -= this.moveStep;
            break;
            case "down":
                this.width -= this.moveStep;
                this.endDist += this.moveStep;
            break;
            case "left":
                this.startDist -= this.moveStep;
                this.endDist += this.moveStep;
            break;
            case "right":
                this.startDist += this.moveStep;
                this.endDist -= this.moveStep;
            break;
        }
        this.update();
        this.sendPackages(); 
    }

// ##########################################  Object SVG Functions  ##################################################################

    CubicleEntrance.prototype.createSVG = function(startPoint,endPoint){
        var entrance = document.createElementNS('http://www.w3.org/2000/svg', 'path');
        entrance.setAttribute('d',this.getEntrancePath());
        entrance.setAttribute('id',"a" + this.id);
        entrance.setAttribute('class',"furniture Cubicle CubicleEntrance subobject");
        entrance.setAttribute('pointer-events',"all");
        entrance.setAttribute('style',"stroke-linecap:"+"butt"+";stroke:"+this.fill+";stroke-width:"+this.lineWidth);
        $('#cubicleEntrance').append(entrance);
        this.entrance = $("#a" + this.id);

        var entrancePosts = document.createElementNS('http://www.w3.org/2000/svg', 'path');
        entrancePosts.setAttribute('d',this.getEntrancePostPath());
        entrancePosts.setAttribute('id',"b" + this.id);
        entrancePosts.setAttribute('class',"furniture Cubicle CubicleEntrance subobject");
        entrancePosts.setAttribute('pointer-events',"all");
        entrancePosts.setAttribute('style',"stroke-linecap:"+"butt"+";stroke:"+this.postColor+";stroke-width:"+this.lineWidth);
        $('#cubicleEntrance').append(entrancePosts);
        this.posts = $("#b" + this.id);
    }

    CubicleEntrance.prototype.getEntrancePath = function(){
        var angle = getAngle(this.points[0].getPoint(),this.points[1].getPoint());
        this.points[2].updatePosition({
            x:this.points[0].x + this.startDist * Math.cos(angle) + (this.lineWidth/2) * Math.cos(angle - Math.PI/2),
            y:this.points[0].y - this.startDist * Math.sin(angle) - (this.lineWidth/2) * Math.sin(angle - Math.PI/2)
        })
        this.points[3].updatePosition({
            x:this.points[1].x + this.endDist * Math.cos(angle - Math.PI) + (this.lineWidth/2) * Math.cos(angle - Math.PI/2),
            y:this.points[1].y - this.endDist * Math.sin(angle - Math.PI) - (this.lineWidth/2) * Math.sin(angle - Math.PI/2)
        })
        var path = ""
        path += "M " + this.points[2].x + " " + this.points[2].y;
        path += "L " + this.points[3].x + " " + this.points[3].y;
        return path;
    }

    CubicleEntrance.prototype.getEntrancePostPath = function(){
        var angle = getAngle(this.points[0].getPoint(),this.points[1].getPoint());
        var path = ""
        if(this.startDist >= 2*this.lineWidth){
            var point1 = {};
            point1.x = this.points[2].x + this.lineWidth * Math.cos(angle + Math.PI);
            point1.y = this.points[2].y - this.lineWidth * Math.sin(angle + Math.PI);
            path += "M " + this.points[2].x + " " + this.points[2].y;
            path += "L " + point1.x + " " + point1.y;            
        }
        if(this.endDist >= 2*this.lineWidth){        
            var point2 = {};        
            point2.x = this.points[3].x + this.lineWidth * Math.cos(angle);
            point2.y = this.points[3].y - this.lineWidth * Math.sin(angle);        
            path += "M " + this.points[3].x + " " + this.points[3].y;
            path += "L " + point2.x + " " + point2.y;
        }
        return path;
    }

    CubicleEntrance.prototype.updateSVG = function(){
        this.entrance.attr({d:this.getEntrancePath()});    
        this.posts.attr({d:this.getEntrancePostPath()});
    }

    CubicleEntrance.prototype.removeSVG = function(){
        this.entrance.remove();
        this.posts.remove();
    }

// ##########################################  Distance Labels Functions  ######################################################################

    CubicleEntrance.prototype.setLabelStyle = function(styleNumber){  // Changes the display behavior of the distance labels based on a style number from a slider
        this.labelStyle = styleNumber != undefined ? styleNumber : this.labelStyle;
        switch(this.labelStyle){
            case 0: // Never show labels
                this.removeLabels();
            break;
            case 1: // Only show window width when selected
                if(this.isSelected == true){
                    this.labels[0].redraw();
                    this.labels[1].remove();
                    this.labels[2].remove();
                } else {
                   this.removeLabels(); 
                }
            break;
            case 2: // Only show labels when selected (default)
                if(this.isSelected == true){
                    this.labels[0].redraw();
                    this.labels[1].redraw();
                    this.labels[2].redraw();
                } else {
                   this.removeLabels(); 
                }
            break;
            case 3: // Always show window label, hide sides when not selected
                if(this.isSelected == true){
                    this.labels[0].redraw();
                    this.labels[1].redraw();
                    this.labels[2].redraw();
                } else {
                    this.labels[0].redraw();
                    this.labels[1].remove();
                    this.labels[2].remove();
                }
            break;
            case 4: // Always show all labels
                    this.labels[0].redraw();
                    this.labels[1].redraw();
                    this.labels[2].redraw();
            break;
        }
        return this.labelStyle;
    }

    CubicleEntrance.prototype.removeLabels = function(){  // Removes the label svg elements for any active label objects
        for(var i = 0;i < this.labels.length;i++){
            this.labels[i].remove();
        }
    }

    CubicleEntrance.prototype.addLabels = function(){  // Adds all three width label objects and their respective svg elements
        var id = generateUUID();
        var start = this.points[0].getPoint();
        var end = this.points[1].getPoint();
        var sideLength = getLength(start,end);
        var xOffset;
        
        xOffset = 100*(this.startDist+this.width/2)/sideLength+"%";
        this.labels[0] = new pathTextLabel("0"+id,start,end,this.labelColor,this.labelFontSize,xOffset,0,'labelGroup');
        this.labels[0].draw();
        this.labels[0].setText(this.renderLength(this.width),start,end,xOffset)
        
        xOffset = 100*(this.startDist/sideLength)/2+"%";
        this.labels[1] = new pathTextLabel("1"+id,start,end,this.labelColor,this.labelFontSize,xOffset,0,'labelGroup');
        this.labels[1].draw();
        this.labels[1].setText(this.renderLength(this.startDist),start,end,xOffset)
        
        xOffset = 100*(this.startDist+this.width+this.endDist/2)/sideLength+"%";
        this.labels[2] = new pathTextLabel("2"+id,start,end,this.labelColor,this.labelFontSize,xOffset,0,'labelGroup');
        this.labels[2].draw();
        this.labels[2].setText(this.renderLength(this.endDist),start,end,xOffset)
    }

    CubicleEntrance.prototype.updateWidthLabel = function(){ // Repositions the width labels based on the position of the window relative to the wall ends
        var start = this.points[0].getPoint();
        var end = this.points[1].getPoint();
        var sideLength = getLength(start,end);
        
        if(start.x > end.x){
            this.labels[2].changeAnchor("start");
            this.labels[1].changeAnchor("end");
        } else {
            this.labels[1].changeAnchor("start");
            this.labels[2].changeAnchor("end");
        }

        var point0xOffset = 100*(this.startDist+this.width/2)/sideLength+"%";
        
        var point1xOffset = 100*(this.startDist/sideLength)/2+"%";
        point1xOffset = point1xOffset.slice(0,-1)/2+"%";        
        
        var point2xOffset = 100*(this.startDist+this.width+this.endDist/2)/sideLength+"%";
        point2xOffset = (point2xOffset.slice(0,-1)*1 + 1*(100-point2xOffset.slice(0,-1))/2)+"%";
        
        this.labels[0].setText(this.renderLength(this.width),start,end,point0xOffset,this.labelFontSize/1.5+10)
        this.labels[1].setText(this.renderLength(this.startDist),start,end,point1xOffset,-this.labelFontSize/5-5);
        this.labels[2].setText(this.renderLength(this.endDist),start,end,point2xOffset,-this.labelFontSize/5-5);
    }

// ##########################################  Selector Interface Functions  ######################################################################

    CubicleEntrance.prototype.setProperty = function(property,value){
        switch(property){
            case "objectWidth":
                this.setobjectWidth(value);
            break;
            case "objectDist":
                this.setobjectDist(value);
            break;
            case "objectStrokeColor":
                this.setobjectStrokeColor(value);
            break;
            case "objectFillColor":
                this.setobjectFillColor(value);
            break;
            case "objectLabelStyle":
                this.setLabelStyle(value);
            break;            
            case "objectLabelColor":
                this.labels[0].setColor(value);
                this.labels[1].setColor(value);
                this.labels[2].setColor(value);
            break;
            case "objectLabelSize":
                this.labelFontSize = value;
                this.labels[0].setFontSize(value);
                this.labels[1].setFontSize(value);
                this.labels[2].setFontSize(value);
                this.updateWidthLabel();
            break;
        }
    }

    CubicleEntrance.prototype.getProperties = function(){  // This function is called when the user selects a wall object
        var thisData = {};
        thisData.data = {
            objectType: {type:"label",value:"Cubicle Entrance"},
            objectWidth: {type:"spinner",value:this.renderLength(this.width)},
            objectFillColor: {type:"color",value:this.fill},
            objectStrokeColor: {type:"color",value:this.postColor},
            objectLabelStyleText: {type:"na",value:CubicleEntrance.prototype.slide(null,{value:this.labelStyle})},
            objectLabelStyle: {type:"slider",value:this.labelStyle,min:0,max:4,slide:CubicleEntrance.prototype.slide},
            objectLabelColor: {type:"color",value:this.labelColor},
            objectLabelSize: {type:"spinner",value:this.labelFontSize},            
        }
        thisData.dividers = {
            sizeDivider:true,
            colorDivider:true,
            labelsDivider:true
        }
        return thisData;
    }

    CubicleEntrance.prototype.slide = function(event,ui){
            var message = "";
            switch(ui.value){
                case 0:
                message = "No Labels"
                break;
                case 1:
                message = "Show Width Label on Select"
                break;
                case 2:
                message = "Show All Labels on Select"
                break;
                case 3:
                message = "Always Show Width Label"
                break;
                case 4:
                message = "Always Show All Labels"
                break;
            }
            $( "#objectLabelStyleText" ).html(message);
    }

    CubicleEntrance.prototype.setobjectWidth = function(value){
        var lineLength = getLength(this.points[0],this.points[1]);
        this.endDist = lineLength - this.startDist - value;
        this.width = value;
        this.update();
    }

    CubicleEntrance.prototype.setobjectDist = function(value){ // Sets the distance of the start of the door from the start of the wall
        var lineLength = getLength(this.points[0],this.points[1]);
        this.startDist = Math.min(value,lineLength-this.width);
        this.endDist = Math.max(lineLength - this.startDist - this.width,0);
        this.update();
    }

    CubicleEntrance.prototype.setobjectFillColor = function(color){  // Sets the color of the door entrance
        var isOk  = /(^#[0-9A-F]{6}$)|(^#[0-9A-F]{3}$)/i.test(color)
        if(isOk){
            this.fill = color;
        } else {
            console.log("color not recognized")
        }
        this.entrance.css("fill",this.fill);
        return this.fill;
    }

    CubicleEntrance.prototype.setobjectStrokeColor = function(color){  // Sets the color of the stroke outline for the open door
        var isOk  = /(^#[0-9A-F]{6}$)|(^#[0-9A-F]{3}$)/i.test(color)
        if(isOk){
            this.postColor = color;
        } else {
            console.log("color not recognized")
        }
        this.posts.css("stroke",this.postColor);
        return this.postColor;
    }