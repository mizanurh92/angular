//#################################  Zone Controller and Class #####################################################

function ZoneController(state,map){
	AreaController.call(this,"ZN","Zone"); // Sets RoomController as subclass of AreaController	
	this.state = state;
    this.map = map; 
}
ZoneController.prototype = Object.create(AreaController.prototype); // Links the prototype to the superclass
ZoneController.prototype.constructor = ZoneController;


function Zone(id,color,state,map){
	AreaClass.call(this,id,color,"Zone","ZN");
	this.rooms = [];
	this.state = state;
    this.map = map;
    this.department = {
        deptName: "Unassigned",
        deptID:"00000"
    };
    this.dataPackageParameters = [ // Used in area type database creation
        "id",
        "name",
        "area",
        "seats",
        "rooms",
        "department"
    ];
}
Zone.prototype = Object.create(AreaClass.prototype);
Zone.prototype.constructor = Zone;


