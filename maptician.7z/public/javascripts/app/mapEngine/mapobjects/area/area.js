//#################################  Area Class #####################################################

function AreaClass(id,color,type,prefix){
	MapObject.call(this,type,id); // Sets AreaClass as subclass of MapObject
	this.name = "";
	this.nameLabel = {};
	this.area = "";
    this.areaLabel = {};
    this.segmentLabels = [];

    this.nameLabelStyle = 2;
    this.areaLabelStyle = 2;
    this.segmentLabelStyle = 2;
    this.labelSize = 13;
    this.labelColor = "#000000";

    this.areaSVG = null; // alias to the svg object for the area polygon
    this.pathSVG = null; // alias to the svg object for area draw paths

    this.pathHandles = []; // circle indicator for the next position of an area path
    this.pathHandleCount = 0;

	this.color = color;
    this.fillOpacity = .3;

	this.points = [];
	this.lastPoint = "000";
	this.opacity = 0;
	this.prefix = prefix;
	this.seats = {};

	this.packageParameters = [ // Used in undo/redo/duplicate/save/load methods
        "type",
        "id",
        "name",
        "area",
        "color",
        "lastPoint",
        "opacity",
        "labelPoint",
        "labelStyle",
        "labelColor",
        "labelSize",
        "showNameLabel",
        "showAreaLabel",
        "nameLabelStyle",
        "areaLabelStyle",
        "segmentLabelStyle",
        "department"
    ];
    this.dataPackageParameters = [ // Used in area type database creation
        "id",
        "name",
        "area",
        "seats",
        "department"
    ];
}
	AreaClass.prototype = Object.create(MapObject.prototype); // Links the prototype to the superclass
	AreaClass.prototype.constructor = AreaClass;
	
	// AreaClass.prototype.area_hover = function(id,fillOpacity){
	//     $("#"+id).velocity("stop");
	//     $("#"+id).velocity({fillOpacity:fillOpacity});
	// }
	
	// AreaClass.prototype.area_exit_hover = function(id,opacity){
 //        $("#"+id).velocity("stop");
	//     $("#"+id).velocity({fillOpacity:opacity});
	// }

// ##########################################  Standard Object Interface Functions  #########################################################

    AreaClass.prototype.getBorderBox = function(){ // Note that the buffer box for an area is the same as its standard area,
        var xArray = [];
        var yArray = [];
        var pointsLen = this.points.length;
        for(var i = 0;i < pointsLen;i++){
            xArray.push(this.points[i].x);
            yArray.push(this.points[i].y);            
        }
        return {xArray:xArray,yArray:yArray};
    }

    AreaClass.prototype.getSnapPoints = function(){ // Note that the buffer box for an area is the same as its standard area,
        // this means that objects will only snap to the area from the inside.
        var snapObject = {
            snapPoints: [],
            bufferBox: [],
            snapEdges: []
        }
        var pointLength = this.points.length;
        for(var i = 0;i < pointLength;i++){ // Finds the center points of the corner posts of the cubicle as snap points
            snapObject.snapPoints.push(this.points[i].getPoint());
            snapObject.bufferBox.push(this.points[i].getPoint()); 
        }
        for(var i = 0;i<pointLength;i++){ // Finds the edges between the snap points above
            snapObject.snapEdges.push({
                start:copyPoint(snapObject.snapPoints[i]),
                end:copyPoint(snapObject.snapPoints[(i+1)%pointLength])
            });
        }
        return snapObject;
    }
	
    AreaClass.prototype.create = function(type,pointList,snapPoints){
        this.snapCandidates = snapPoints;
		switch(type){
			case "Path":
				this.createPath();
				return;
			break;
			case "Box":
				var coords = this.map.pointerCoords();
				var x = this.map.snapRound(coords.x);
				var y = this.map.snapRound(coords.y);
				this.points[0] = new point(x,y,this.prefix+"P"+this.incrementPoint()+this.id);
				this.points[1] = new point(x,y,this.prefix+"P"+this.incrementPoint()+this.id);
				this.points[2] = new point(x,y,this.prefix+"P"+this.incrementPoint()+this.id);
				this.points[3] = new point(x,y,this.prefix+"P"+this.incrementPoint()+this.id);
                this.createSegmentLebels();
			break;
			case "Wall Area":
				var length = pointList.length;
				for(var i = 0;i < length;i++){
			    	var x = pointList[i].x;
			    	var y = pointList[i].y;
					this.points.push(new point(x,y,this.prefix+"P"+this.incrementPoint()+this.id));			
				}
			break;
		}
		this.createSVG();
		this.calculateArea();
		this.addLabels();
	}

	AreaClass.prototype.update = function(){
		this.updateSVG();
		this.calculateArea();
		this.updateLabels();
	}

	AreaClass.prototype.remove = function(){
		this.removeSVG();
		this.removeHandles();
		this.removeLabels();
	}

	AreaClass.prototype.redraw = function(){
		this.createSVG();
        this.setLabelStyle();
	}

	AreaClass.prototype.activate = function(options){
        var options = options || {};
        var multiSelect = options.multiSelect || false;
		if(!options.multiSelect && options.program == "Editor"){
            this.drawHandles();
            this.nameLabel.drawPoint();
        }
        if(this.reservation == null){
            this.areaSVG ? this.areaSVG.velocity("stop") : null;
            this.areaSVG ? this.areaSVG.velocity({fillOpacity:this.fillOpacity}, { duration: 500 }) : null;
            //this.areaSVG ? this.areaSVG.attr('onmouseout',"AreaClass.prototype.area_exit_hover(this.id,"+this.fillOpacity+")") : null;            
        }
        this.isSelected = true;
        this.setLabelStyle();
	}

	AreaClass.prototype.deactivate = function(){
		this.removeHandles();
		if(this.reservation == null){
            this.areaSVG ? this.areaSVG.velocity("stop") : null;
            this.areaSVG ? this.areaSVG.velocity({fillOpacity:this.opacity}, { duration: 500 }) : null;
            //this.areaSVG ? this.areaSVG.attr('onmouseout',"AreaClass.prototype.area_exit_hover(this.id,this.opacity)") : null;            
        }
        this.isSelected = false;
        this.setLabelStyle();
	}

	AreaClass.prototype.getOutlinePoints = function(){
		var maxX = this.points[0].x;
		var minX = this.points[0].x;
		var maxY = this.points[0].y;
		var minY = this.points[0].y;
		var length = this.points.length;
		for(var i = 1; i < length; i++){
			if(maxX < this.points[i].x){maxX = this.points[i].x};
			if(minX > this.points[i].x){minX = this.points[i].x};
			if(maxY < this.points[i].y){maxY = this.points[i].y};
			if(minY > this.points[i].y){minY = this.points[i].y};
		}
		return [{x:minX,y:minY},{x:maxX,y:minY},{x:minX,y:maxY},{x:maxX,y:maxY}];
	}

// ##########################################  Point Handle Functions  ##################################################################	

	AreaClass.prototype.handlePress = function(handleID,optObj){
		console.log('object handle press')
        var options = optObj || {};
        this.snapCandidates = options.snapPoints || [];

        this.handleDragging = handleID.slice(3,6)*1;
		this.dragIndex = "";
		switch(handleID.slice(2,3)){
			case "P":
		        for(var i = 0;i < this.points.length;i++){
		            if(handleID == this.points[i].id){
		            	this.dragIndex = i;
		            	this.points[i].setDragReference();
                        break;
		            }
		        }
			break; 
			case "N":
                this.nameLabel.point ? this.nameLabel.point.setDragReference() : null;
                this.areaLabel.point ? this.areaLabel.point.setDragReference() : null;
			break;
		}
		this.undoPackage = this.createPackage();
	}

	AreaClass.prototype.handleDrag = function(){
        var map = this.map;
        var coords = this.map.pointerCoords(); // gets the latest mouse location
        var xMove = coords.x-map.handle.x/map.scale;
        var yMove = coords.y-map.handle.y/map.scale;		
		switch(this.state.dragHandle.slice(2,3)){
			case "P":
                var dragPoint = this.points[this.dragIndex];
				dragPoint.dragOffset(xMove,yMove,{gridResolution:map.snapGridResolution,snapToGrid:map.snapGridActive});
                this.update();
                var isSnapCandidates = this.snapCandidates.length;
                if(isSnapCandidates){
                    var pointSnapped = snapPointToLine(dragPoint.getPoint(),this.snapCandidates,{points:true,edges:true});
                    if(pointSnapped){
                        xMove += pointSnapped.xMove;
                        yMove += pointSnapped.yMove;
                        dragPoint.dragOffset(xMove,yMove);
                        this.update();                     
                    }
                }
			break; 
			case "N":
				var distDragged = this.nameLabel.dragOffset(
                    xMove,
                    yMove,
                    {gridResolution:map.snapGridResolution,snapToGrid:map.snapGridActive});
                this.areaLabel.point ? this.areaLabel.dragOffset(distDragged.x,distDragged.y) : null;
			break;
		}
	}

    AreaClass.prototype.finalizeHandleDrag = function(){
        this.fixOrientation();
        this.sendPackages();
    }

	AreaClass.prototype.drawHandles = function(){
		var length = this.points.length;
		for(var i = 0; i < length; i++){
			this.points[i].drawHandle();
		}
	}

	AreaClass.prototype.removeHandles = function(){
		var length = this.points.length;
		for(var i = 0;i < length;i++){
			this.points[i].removeHandle();
		}
        this.nameLabel.point ? this.nameLabel.removePoint() : null;
        this.areaLabel.point ? this.areaLabel.removePoint() : null;
	}

// ##########################################  Application Mechanics (Undo/Redo/Duplicate/Save/Load)  #############################################

    AreaClass.prototype.duplicate = function(original){
        for(var i = 0;i < original.points.length;i++){
            this.points.push(new point(original.points[i].x,original.points[i].y,original.points[i].id.substring(0,6)+this.id))
        }
        for(var i = 0;i < this.packageParameters.length;i++){
            if(this.packageParameters[i] != "id"){
                this[this.packageParameters[i]] = original[this.packageParameters[i]];
            }
        }
        this.createSVG();
        this.calculateArea();
		this.addLabels();
        this.createSegmentLebels();
        this.move(12,12);
        this.setLabelStyle();
    }

    AreaClass.prototype.createPackage = function(){
        var package = {points:[]};
        for(var i = 0;i < this.points.length;i++){
            package.points.push(this.points[i].getSavePoint());
        }
        for(var i = 0;i < this.packageParameters.length;i++){
            package[this.packageParameters[i]] = this[this.packageParameters[i]];
        }
        package.labelPoint = this.nameLabel.point ? this.nameLabel.point.getPoint() : null;
        switch(this.type){
            case "Zone":
                package.controller = 'zones';
            break;
            case "Room":
                package.controller = 'rooms';
            break;
        }
        package.packageType = "modify";
        return package;
    }

    AreaClass.prototype.loadPackage = function(package){
        // It doesn't matter if it is an undo or redo package, the impact is to reset the object to a former state
        if(package.points.length > this.points.length){
        	for(var i = 0;i < package.points.length;i++){
        		if(package.points[i].id != this.points[i].id){
        			this.points.splice(i,0,new point(0,0,this.prefix+"P000"+this.id));
        			this.points[i].id = package.points[i].id;
        			break;
        		}
        	}
        } else if(package.points.length < this.points.length){
        	for(var i = 0;i < this.points.length;i++){
        		if(this.points[i].id != package.points[i].id){
        			this.points[i].removeHandle();
        			this.points.splice(i,1);
        			break;
        		}
        	}
        }
        for(var i = 0;i < this.points.length;i++){
            this.points[i].updatePosition(package.points[i].x,package.points[i].y);
            this.points[i].id = package.points[i].id;
        }
        for(var i = 0;i < this.packageParameters.length;i++){
            this[this.packageParameters[i]] = package[this.packageParameters[i]];
        }
        this.nameLabel.point ? this.nameLabel.point.updatePosition(package.labelPoint.x,package.labelPoint.y) : null;
        this.areaLabel.point ? this.areaLabel.point.updatePosition(package.labelPoint.x,package.labelPoint.y) : null;
        this.update();
    }

    AreaClass.prototype.sendPackages = function(){
        // It is important to know that the undo and redo packages aren't the same.  If they are, there was no real action taken and
        // an undo or redo event will have no apparent effect
        var undo = this.undoPackage;
        var redo = this.createPackage();
        var same = true; // Used to determine whether the two packages are the same (no actual event occured)
        for(var i = 0;i < redo.points.length;i++){ // Runs through the points first as the most common event changes
            if(undo.points[i] === undefined || redo.points[i] === undefined){
                break;
            }
            if(undo.points[i].x != redo.points[i].x || undo.points[i].y != redo.points[i].y){
                same = false;
                break; // breaks as soon as a single difference is found
            }
        }       
        if(same){ // No need to start second loop if a difference was already found
            for(var i = 0;i < this.packageParameters.length;i++){
                if(undo[this.packageParameters[i]] != redo[this.packageParameters[i]]){
                    same = false;
                    break;
                }
            }
        }
        // Packages are sent essentially simultaneously to prevent having mismatched packages if the action isn't finalized
        if(same == false){
            this.state.addUndoPackage(undo);
            this.state.addRedoPackage(redo);
        }
    }

    AreaClass.prototype.save = function(){
        var saveFile = {points:[]}
        this.labelPoint = this.nameLabel.getPoint();
        for(var i = 0;i < this.points.length;i++){
            saveFile.points.push(this.points[i].getSavePoint());
        }
        for(var i = 0;i < this.packageParameters.length;i++){
            console.log(this.packageParameters[i])
            saveFile[this.packageParameters[i]] = this[this.packageParameters[i]];
        }
        console.log(saveFile)
        return saveFile
    }

    AreaClass.prototype.saveData = function(){ // This is used when creating the seat database object
        var saveFile = {};
        for(var i = 0;i < this.dataPackageParameters.length;i++){
            saveFile[this.dataPackageParameters[i]] = this[this.dataPackageParameters[i]];
        }
        return saveFile        
    }

    AreaClass.prototype.load = function(saveFile){
        console.log('loading')
        // Note that this method assumes that the create function has not been called - will not work if it has been
        for(var i = 0;i < saveFile.points.length;i++){
            this.points.push(new point(saveFile.points[i].x,saveFile.points[i].y,saveFile.points[i].id));
        }
        for(var i = 0;i < this.packageParameters.length;i++){
            this[this.packageParameters[i]] = saveFile[this.packageParameters[i]];
        }
        this.nameLabelStyle = this.nameLabelStyle || 2;
        this.areaLabelStyle = this.areaLabelStyle || 0;
        this.segmentLabelStyle = this.segmentLabelStyle || 0;
        this.createSVG(); 
        this.addLabels();
        this.createSegmentLebels();
        this.update();
        this.setLabelStyle();
    }

// ##########################################  Drag and Move Functions  #############################################

	AreaClass.prototype.startDrag = function(){
        this.undoPackage = this.createPackage();
        for(var i = 0;i < this.points.length;i++){
            this.points[i].setDragReference();
        }
        this.nameLabel.point.setDragReference();
        this.areaLabel.point.setDragReference();
	}

	AreaClass.prototype.drag = function(){
        var map = this.map;
        var coords = map.pointerCoords(); // gets the latest mouse location
        var xMove = coords.x-map.handle.x/map.scale;
        var yMove = coords.y-map.handle.y/map.scale;
        var length = this.points.length;
        var distDragged = this.points[0].dragOffset(xMove,yMove,{gridResolution:map.snapGridResolution,snapToGrid:map.snapGridActive});
        for(var i = 1;i < length;i++){
        	this.points[i].dragOffset(distDragged.x,distDragged.y);
        }
        this.nameLabel.point.dragOffset(distDragged.x,distDragged.y);
        this.areaLabel.point.dragOffset(distDragged.x,distDragged.y);
        this.update(); 
	}

    AreaClass.prototype.finalizeDrag = function(){
        
        this.sendPackages();
    }

	AreaClass.prototype.move = function(x,y){
		this.undoPackage = this.createPackage();
        var length = this.points.length;
        for(var i = 0;i < length;i++){
        	this.points[i].shiftPosition(x,y);
        }
        this.nameLabel.point.shiftPosition(x,y);
        this.areaLabel.point.shiftPosition(x,y);
        this.update();
        this.sendPackages();
	}

    AreaClass.prototype.shiftPosition = function(shiftLeft,shiftUp){
        var keys = Object.keys(this.points);
        var len = keys.length;
        var key,current;
        for(var i = 0;i < len;i++){
            try{
                key = keys[i];
                current = this.points[key];
                current.shiftPosition(shiftLeft,shiftUp);                
            } catch(err){
                console.log(err);
            }
        }
        try{
            this.nameLabel.point ? this.nameLabel.point.shiftPosition(shiftLeft,shiftUp) : null;
            this.areaLabel.point ? this.areaLabel.point.shiftPosition(shiftLeft,shiftUp) : null;            
        } catch (err){
            console.log(err);
        }
        this.update();
    }    

// ##########################################  Object SVG Functions  ##################################################################

	AreaClass.prototype.createSVG = function(){
		var polygon = document.createElementNS('http://www.w3.org/2000/svg', 'polygon');
		polygon.setAttribute('id',this.id);
		polygon.setAttribute('class',this.type);
		polygon.setAttribute('points',this.getPointString());
        polygon.setAttribute('fill',this.color)
		polygon.setAttribute('style',"stroke-linecap:"+"butt"+";stroke:"+this.color+";stroke-width:"+"1"+";fill-opacity:0");
		$('#'+this.type+'s').append(polygon);
        this.areaSVG = $("#" + this.id);
	}

	AreaClass.prototype.getPointString = function(){
		var pointString = "";
		var pointLength = this.points.length;
		for(var i = 0;i < pointLength;i++){
			pointString += this.points[i].x+","+this.points[i].y+" ";
		}
		return pointString;		
	}

	AreaClass.prototype.drawBox = function(){
        var map = this.map;
        var pos = map.pointerCoords(); 
        this.points[1].updatePosition(map.snapRound(pos.x),this.points[1].y);
        this.points[2].updatePosition(map.snapRound(pos.x),map.snapRound(pos.y));
        this.points[3].updatePosition(this.points[3].x,map.snapRound(pos.y));
        this.update();
		var centerPoint = this.getCenterPoint();
		this.areaLabel.updatePosition ? this.areaLabel.updatePosition(centerPoint.x,centerPoint.y) : null;
		this.nameLabel.updatePosition ? this.nameLabel.updatePosition(centerPoint.x,centerPoint.y) : null;       
	}

    AreaClass.prototype.finalizeDrawBox = function(){  // To make the initial point numbers and corners consistent in all draw scenarios the
        // following checks to ensure that point zero is at the upper left and the points are numbered clockwise from there
        // If this isn't the case, this function flips the points on the necessary axis to make it the case
        if(this.points[0].y > this.points[3].y){
            var temp0 = this.points[0].getPoint();
            var temp1 = this.points[1].getPoint();
            var temp2 = this.points[2].getPoint();
            var temp3 = this.points[3].getPoint();
            this.points[0].updatePosition(temp3.x,temp3.y);
            this.points[1].updatePosition(temp2.x,temp2.y);
            this.points[2].updatePosition(temp1.x,temp1.y);
            this.points[3].updatePosition(temp0.x,temp0.y);
        }
        if(this.points[0].x > this.points[1].x){
            var temp0 = this.points[0].getPoint();
            var temp1 = this.points[1].getPoint();
            var temp2 = this.points[2].getPoint();
            var temp3 = this.points[3].getPoint();
            this.points[0].updatePosition(temp1.x,temp1.y);
            this.points[1].updatePosition(temp0.x,temp0.y);
            this.points[2].updatePosition(temp3.x,temp3.y);
            this.points[3].updatePosition(temp2.x,temp2.y);
        }
        this.update();
        this.fixOrientation();
        this.activate({program:"Editor"})
        this.setLabelStyle();
    }

    AreaClass.prototype.createPathDistLabel = function(){
        var len = this.points.length;
        if(len > 0){
            this.segmentLabels.push(new pathTextLabel(
                "PT"+this.points.length + this.id, // ID for label
                this.points[len-1],
                this.map.pointerCoords(), // temporary point reference since the endpoint hasn't been placed yet
                'black',
                12,
                "50%",
                0,
                'labelGroup'
                ))
            this.segmentLabels[len-1].draw();
            if(this.segmentLabels.length > 1){ // Updates the segment label from previous iteration to the actual point
                this.segmentLabels[this.segmentLabels.length-2].update(null,null,this.points[len-1]);
            }
        }        
    }

    AreaClass.prototype.updatePathDistLabel = function(){
        var len = this.points.length;
        var start = this.points[len-1];
        var end = this.map.pointerCoords({snapRound:true});
        this.segmentLabels[len-1].updateDist(start,end);
    }

    AreaClass.prototype.drawAreaMapEnter = function(){ // Creates a visible point on the map whenever the user first brings the
        // cursor within the map area while in draw area mode.  The point represents where the area point 0 will be.
        if(this.pathHandles.length == 0){
            this.incrementPathIndicator();
        }
    }

    AreaClass.prototype.incrementPathIndicator = function(newPoint){
        var coords = this.map.pointerCoords();
        var x = newPoint && newPoint.x ? newPoint.x : this.map.snapRound(coords.x);
        var y = newPoint && newPoint.y ? newPoint.y : this.map.snapRound(coords.y);

        this.pathHandles.push(new point(x,y,this.prefix+"I"+(this.pathHandleCount || '000')+this.id));
        this.pathHandles[1*this.pathHandleCount].drawHandle({stealth:true});
    }

    AreaClass.prototype.createPath = function(){
        var polyPath = document.createElementNS('http://www.w3.org/2000/svg', 'path');
        polyPath.setAttribute('id',this.id);
        polyPath.setAttribute('style',"stroke-linecap:"+"butt"+";stroke:"+this.color+";stroke-width:"+"1"+";fill:"+"none");
        $('#topGroup').append(polyPath);
        this.pathSVG = $("#" + this.id);
	}

	AreaClass.prototype.addPoint = function(){ // Creates a point object in the location of the mouse click
		var isSnapCandidates = this.snapCandidates.length;
        var coords = this.map.pointerCoords();
    	var x = this.map.snapRound(coords.x)
    	var y = this.map.snapRound(coords.y)
		var pointID = this.prefix+"P"+this.incrementPoint()+this.id;
		this.points.push(new point(x,y,pointID));
        var newPoint = this.points[this.points.length -1];
        if(isSnapCandidates){
            var pointSnapped = snapPointToLine(
                newPoint,
                this.snapCandidates,
                {points:true,edges:true}
                );
            if(pointSnapped){
                newPoint.shiftPosition(pointSnapped.xMove,pointSnapped.yMove);
                this.pathHandles[1*this.pathHandleCount].updatePosition(newPoint);
            }
        }
        this.incrementIndicatorPoint();
        this.incrementPathIndicator(newPoint);
        this.createPathDistLabel();
		if(this.points.length>1){
			var path = "M "+this.points[0].x+" "+this.points[0].y+" L ";
			for(var i = 1;i<this.points.length;i++){
				path += this.points[i].x + " " + this.points[i].y + " ";
			}
			this.pathSVG.attr("d",path);
		}
	}

	AreaClass.prototype.drawNextPoint = function(){ // Creates a line from the point of the last point object to the current mouse location
		var isSnapCandidates = this.snapCandidates.length;
        if(this.points.length>0){
            var map = this.map;
            var coords = map.pointerCoords();
			var x = map.snapRound(coords.x)
    		var y = map.snapRound(coords.y)
			var path = "M "+this.points[0].x+" "+this.points[0].y+" L ";
			for(var i = 1;i<this.points.length;i++){
				path += this.points[i].x + " " + this.points[i].y + " ";
			}
			
            this.pathHandles[1*this.pathHandleCount].updatePosition(x,y);
			
            if(isSnapCandidates){
                var pointSnapped = snapPointToLine(
                    this.pathHandles[1*this.pathHandleCount].getPoint(),
                    this.snapCandidates,
                    {points:true,edges:true}
                    );
                if(pointSnapped){
                    this.pathHandles[1*this.pathHandleCount].shiftPosition(pointSnapped.xMove,pointSnapped.yMove);
                    x += pointSnapped.xMove;
                    y += pointSnapped.yMove;
                }
            }
            path += x + " " + y + " ";
            this.pathSVG.attr("d",path);
            this.updatePathDistLabel();
		} else {
            var map = this.map;
            var coords = map.pointerCoords();
            var x = map.snapRound(coords.x)
            var y = map.snapRound(coords.y)
            this.pathHandles[1*this.pathHandleCount].updatePosition(x,y);
            if(isSnapCandidates){
                var pointSnapped = snapPointToLine(
                    this.pathHandles[1*this.pathHandleCount].getPoint(),
                    this.snapCandidates,
                    {points:true,edges:true}
                    );
                if(pointSnapped){
                    this.pathHandles[1*this.pathHandleCount].shiftPosition(pointSnapped.xMove,pointSnapped.yMove);                   
                }
            }    
        }
	}

	AreaClass.prototype.convertPathToPolygon = function(){
        if(this.points.length < 3){
            this.remove();
            return false; // Sends a flag to remove the object in the controller
        }
        this.pathSVG ? this.pathSVG.remove() : null; // Remove path element
        for(var i in this.pathHandles){
            this.pathHandles[i].removeHandle();
        }
        this.segmentLabels[this.segmentLabels.length-1].update(null,null,this.points[0]);
        delete this.pathHandles;
		this.createSVG();
		this.calculateArea();
		this.addLabels();
        this.fixOrientation();
        this.activate({program:"Editor"});
        this.setLabelStyle();
        return true;
	}

    AreaClass.prototype.cancelDraw = function(){
        
        this.remove();
    }

	AreaClass.prototype.updateSVG = function(){
		
		this.areaSVG ? this.areaSVG.attr("points",this.getPointString()) : null;
	}

	AreaClass.prototype.removeSVG = function(){
		this.areaSVG ? this.areaSVG.remove() : null;
        this.pathSVG ? this.pathSVG.remove() : null;
        for(var i in this.pathHandles){
            this.pathHandles[i].removeHandle();
        }
	}

// ##########################################  Object Calculation Functions  ############################################################

	AreaClass.prototype.incrementPoint = function(){
		this.lastPoint = ("000" + (1*this.lastPoint + 1)).slice(-3);
		return this.lastPoint;
	}

    AreaClass.prototype.incrementIndicatorPoint = function(){
        this.pathHandleCount = ("000" + (1*this.pathHandleCount + 1)).slice(-3);
        return this.pathHandleCount;
    }

	AreaClass.prototype.getPointList = function(){
		var pointLength = this.points.length;
		var points = [];
		for(var i = 0;i < pointLength;i++){
			points.push(this.points[i].getPoint());
		}
		return points;
	}

	AreaClass.prototype.calculateArea = function(){
		this.area = polyArea(this.getPointList());
		return this.area;
	}

	AreaClass.prototype.getCenterPoint = function(){
		var points = this.getOutlinePoints();
		return {x:(points[0].x + points[1].x)/2,y:(points[0].y + points[2].y)/2};
	}

    AreaClass.prototype.fixOrientation = function(){
        var pointLen = this.points.length;
        var edges = [];
        var total = 0;
        var edge;
        if(pointLen > 2){
            for(var i = 0; i < pointLen; i++){
                if(i < pointLen - 1){
                    edges.push({start:this.points[i],end:this.points[i+1]})
                } else {
                    edges.push({start:this.points[i],end:this.points[0]})
                }
            }
            for(var i = 0; i < edges.length; i++){
                edge = edges[i];
                total += (edge.end.x-edge.start.x)*(edge.end.y+edge.start.y);
            }
        }
        if(total < 0){
            var holder = [];
            for(var i = 0; i < pointLen; i++){
                holder.push(this.points[i].getPoint())
            }
            for(var i = 0; i < pointLen; i++){
                this.points[i].updatePosition(holder.pop())
            }
            this.update();
        }
    }

// ##########################################   Label Functions  ##################################################################

    AreaClass.prototype.setLabelStyle = function(options){ // Changes the display behavior of the distance labels based on a style number from a slider
        options = options || {};
        this.nameLabelStyle = options.name != undefined ? options.name : this.nameLabelStyle;
        this.areaLabelStyle = options.area != undefined ? options.area : this.areaLabelStyle;
        this.segmentLabelStyle = options.segment != undefined ? options.segment : this.segmentLabelStyle;

        console.log(this.nameLabelStyle,this.areaLabelStyle,this.segmentLabelStyle)

        switch(this.nameLabelStyle){
            case 0: // Never show labels
                this.nameLabel.point ? this.nameLabel.removeLabel() : null;
            break;
            case 1: // Only show labels when selected
                if(this.isSelected == true){
                    this.nameLabel.point ? this.nameLabel.redraw() : null;
                } else {
                   this.nameLabel.point ? this.nameLabel.removeLabel() : null;
                }
            break;
            case 2: // Always show labels (default)
                this.nameLabel.point ? this.nameLabel.redraw() : null;
            break;
        }

        switch(this.areaLabelStyle){
            case 0: // Never show labels
                this.areaLabel.point ? this.areaLabel.removeLabel() : null;
            break;
            case 1: // Only show labels when selected
                if(this.isSelected == true){
                    this.areaLabel.point ? this.areaLabel.redraw() : null;
                } else {
                   this.areaLabel.point ? this.areaLabel.removeLabel() : null;
                }
            break;
            case 2: // Always show labels (default)
                this.areaLabel.point ? this.areaLabel.redraw() : null;
            break;
        }

        switch(this.segmentLabelStyle){
            case 0: // Never show labels
                for(var i = 0; i < this.segmentLabels.length; i++){
                    this.segmentLabels[i].remove();
                }
            break;
            case 1: // Only show labels when selected
                if(this.isSelected == true){
                    for(var i = 0; i < this.segmentLabels.length; i++){
                        this.segmentLabels[i].redraw();
                    }
                } else {
                    for(var i = 0; i < this.segmentLabels.length; i++){
                        this.segmentLabels[i].remove();
                    }
                }
            break;
            case 2: // Always show labels (default)
                for(var i = 0; i < this.segmentLabels.length; i++){
                    this.segmentLabels[i].redraw();
                }
            break;
        }

    }

	AreaClass.prototype.addLabels = function(){
		this.createNameLabel();
        this.createAreaLabel();
	}

	AreaClass.prototype.createNameLabel = function(){
		var loc;
        if(this.labelPoint){
            loc = this.labelPoint;
        } else {
            loc = this.getCenterPoint();
        }
		// Name Label
		if(this.nameLabel != {}){
			this.nameLabel = new label(
				this.prefix + "L000" + this.id, // name label's id is subcategory 'L' index 1
				this.prefix + "N000" + this.id, // name label's point id is subscategory 'n'
				this.name,  // text contents
				"inherit",  // font
				this.labelSize, // font size
				loc.x, // x coordinate
				loc.y, // y coordinate
				this.labelColor, // font color
				"none", // pointer events (none by default so mouse-over won't affect shading)
				"middle", // text anchor
				-this.labelSize, // y offset
				"labelGroup", // where to append the label
				this.type.toLowerCase()+"Label" // class name for the pointer handle
			);
			this.nameLabel.drawLabel();
		};
	}
	
	AreaClass.prototype.createAreaLabel = function(){
        var loc;
        if(this.labelPoint){
            loc = this.labelPoint;
        } else {
            loc = this.getCenterPoint();
        }
		// Area Label
		if(this.areaLabel != {}){
			this.areaLabel = new label(
			this.prefix+"L001"+this.id, // area label's id is subcategory 'L' index 1
			this.prefix+"a000"+this.id, // area label's point id is subscategory 'a'
			this.renderArea(this.area,{svg:true}),  // text contents
			"inherit",  // font
			this.labelSize, // font size
			loc.x, // x coordinate
			loc.y, // y coordinate
			this.labelColor, // font color
			"none", // pointer events (none by default so mouse-over won't affect shading)
			"middle", // text anchor
			this.labelSize + 9, // y offset
			"labelGroup", // where to append the label
			this.type.toLowerCase()+"Label" // class name for the pointer handle
			);
			this.areaLabel.drawLabel();
		}
	}

    AreaClass.prototype.createSegmentLebels = function(){
        var pointLen = this.points.length;
        var edges = [];
        var edge;
        if(pointLen > 2){
            for(var i = 0; i < pointLen; i++){
                if(i < pointLen - 1){
                    edges.push({start:this.points[i],end:this.points[i+1]})
                } else {
                    edges.push({start:this.points[i],end:this.points[0]})
                }
            }
            for(var i = 0; i < edges.length; i++){
                edge = edges[i];
                this.segmentLabels.push(new pathTextLabel(
                    "PT"+i + this.id, // ID for label
                    edge.start,
                    edge.end,
                    this.labelColor,
                    this.labelSize,
                    "50%",
                    0,
                    'labelGroup'
                    ))
                this.segmentLabels[i].draw();
            }
        }        
    }

	AreaClass.prototype.removeLabels = function(){
        this.nameLabel.point ? this.nameLabel.removeLabel() : null;
        this.areaLabel.point ? this.areaLabel.removeLabel() : null;
        for(var i = 0; i < this.segmentLabels.length; i++){
            this.segmentLabels[i].remove();
        }
	}

	AreaClass.prototype.redrawLabels = function(){
        this.setLabelStyle();
	}

	AreaClass.prototype.updateLabels = function(){
		this.nameLabel.update(this.name);
        this.areaLabel.update(this.renderArea(this.area,{svg:true})); 
        for(var i = 0; i < this.segmentLabels.length; i++){
            this.segmentLabels[i].updateDist();
        }
	}

// ##########################################  Selector Interface Functions  ######################################################################

	AreaClass.prototype.setProperty = function(property,value){
        switch(property){
            case "objectName":
                this.name = value;
                this.nameLabel.updateText(this.name);
            break;
            case "objectAreaColor":
                this.setobjectAreaColor(value);
            break;
            case "objectLabelColor":
                this.setobjectLabelColor(value);
            break;
            case "objectLabelSize":
            	this.setobjectLabelSize(value);
            break;
            case "objectRoomCapacity":
                this.setobjectRoomCapacity(value);
            break;
            case "objectAreaNameToggle":
                //this.showNameLabel = value;
                this.setLabelStyle();
            break;
            case "objectAreaSizeToggle":
                //this.showAreaLabel = value;
                this.setLabelStyle();
            break;
            case "objectNameStyle":
                this.setLabelStyle({name:value});
            break;
            case "objectAreaStyle":
                this.setLabelStyle({area:value});
            break;
            case "objectDistanceStyle":
                this.setLabelStyle({segment:value});
            break;
            case "objectRoomType":
                this.roomType = value;
            break;            
            case "objectRoomEquipment":
                this.equipment = value;
            break;
            case "objectRoomAccess":
                this.accessibility = value;
            break;
            case "objectRoomAmeneties":
                this.ameneties = value;
            break;
            case "objectReservableToggle":
                this.reservable = value;
            break;
            case "objectDepartment":
                this.department = JSON.parse(value);
            break;
        }
    }

    AreaClass.prototype.getObjectData = function(subcategory,id){  // This function is called when the user selects a wall object
        var thisData = {};
        thisData.data = {
            objectType: {type:"label",value:this.type},
            objectName: {type:"text",value:this.name},
            objectArea: {type:"label",value:this.renderArea(this.area)},
            objectAreaColor: {type:"color",value:this.color},
            objectLabelColor: {type:"color",value:this.nameLabel.color},
            objectLabelSize: {type:"spinner",value:this.nameLabel.size},
            objectNameStyleText: {type:"na",value:AreaClass.prototype.nameSlide(null,{value:this.nameLabelStyle})},
            objectNameStyle: {type:"slider",value:this.nameLabelStyle,min:0,max:2,slide:AreaClass.prototype.nameSlide},
            objectAreaStyleText: {type:"na",value:AreaClass.prototype.areaSlide(null,{value:this.areaLabelStyle})},
            objectAreaStyle: {type:"slider",value:this.areaLabelStyle,min:0,max:2,slide:AreaClass.prototype.areaSlide},
            objectDistanceStyleText: {type:"na",value:AreaClass.prototype.distSlide(null,{value:this.segmentLabelStyle})},
            objectDistanceStyle: {type:"slider",value:this.segmentLabelStyle,min:0,max:2,slide:AreaClass.prototype.distSlide},
            objectDepartment: {type:"drop-down",value:JSON.stringify(this.department)},
        }
        thisData.dividers = {
            labelsDivider:true,
            areaDivider:true
        }
        return thisData;
    }

    AreaClass.prototype.getObjectViewerData = function(subcategory,id){
        var thisData = {};
        thisData.data = {
            vObjectType: {type:"label",value:this.type},
            vObjectAreaNameType: {type:"label",value:this.type+" Name:"},
            vObjectAreaName: {type:"label",value:this.name},
            vObjectArea: {type:"label",value:this.renderArea(this.area)},
            vObjectTotalSeats: {type:"label",value:Object.keys(this.seats).length || 0}
        }
        thisData.dividers = {
            vSizeDivider: true,
            vSeatsDivider: true
        }
        if(this.employee){
            thisData.data.vObjectSeatAssignment = {type:"label",value:this.seatAssignment};
            thisData.data.vObjectAssignedImage = {type:"image",value: this.employee.profileImages.mediumProfile};
            thisData.data.vObjectAssignedEmail = {type:"label",value: this.employee.email};
            thisData.data.vObjectAssignedDept = {type:"label",value: 'Dept: '+this.employee.employee.department};
            thisData.data.vObjectAssignedEmpID = {type:"label",value: 'Employee ID: '+this.employee.employee.employeeID};
            thisData.data.vObjectAssignedTitle = {type:"label",value: this.employee.employee.title};
            thisData.dividers.vSeatAssignmentDivider = true;
        }
        return thisData;
    }

    AreaClass.prototype.nameSlide = function(event,ui){
            var message = "";
            switch(ui.value){
                case 0:
                message = "No Labels"
                break;
                case 1:
                message = "Show Labels on Select"
                break;
                case 2:
                message = "Always Show Labels"
                break;
            }
            $( "#objectNameStyleText" ).html(message);
    }

    AreaClass.prototype.areaSlide = function(event,ui){
            var message = "";
            switch(ui.value){
                case 0:
                message = "No Labels"
                break;
                case 1:
                message = "Show Labels on Select"
                break;
                case 2:
                message = "Always Show Labels"
                break;
            }
            $( "#objectAreaStyleText" ).html(message);
    }

    AreaClass.prototype.distSlide = function(event,ui){
            var message = "";
            switch(ui.value){
                case 0:
                message = "No Labels"
                break;
                case 1:
                message = "Show Labels on Select"
                break;
                case 2:
                message = "Always Show Labels"
                break;
            }
            $( "#objectDistanceStyleText" ).html(message);
    }

	AreaClass.prototype.setName = function(name){
    	this.name = name;
    	this.nameLabel.updateText(name);
    }
	AreaClass.prototype.setobjectAreaColor = function(color){
    	var isOk  = /(^#[0-9A-F]{6}$)|(^#[0-9A-F]{3}$)/i.test(color)
        if(isOk){
            this.color = color;
        } else {
            message.errorMessage("Color not recognized");
        }
        this.areaSVG ? this.areaSVG.css("fill",this.color) : null;
        this.areaSVG ? this.areaSVG.css("stroke",this.color) : null;
        return this.color;
    }
	AreaClass.prototype.setobjectLabelColor = function(color){
    	var isOk  = /(^#[0-9A-F]{6}$)|(^#[0-9A-F]{3}$)/i.test(color)
        if(isOk){
            this.nameLabel.color = color;
            this.areaLabel.color = color;
            this.nameLabel.redraw();
            this.areaLabel.redraw();
        } else {
            message.errorMessage("Color not recognized");
        }

        return this.nameLabel.color;
    }
	AreaClass.prototype.setobjectLabelSize = function(size){
        this.nameLabel.size = size;
        this.nameLabel.redraw();
        this.areaLabel.size = size;
        this.areaLabel.redraw();
    }
	AreaClass.prototype.toggleAreaLabel = function(){
    	
    	this.areaLabel.toggleActive();
    }
	AreaClass.prototype.toggleNameLabel = function(){
    	
    	this.nameLabel.toggleActive();
    }