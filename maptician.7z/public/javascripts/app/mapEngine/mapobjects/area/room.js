//#################################  Room Controller and Class #####################################################

function RoomController(state,map){
	AreaController.call(this,"RM","Room"); // Sets RoomController as subclass of AreaController	
    this.state = state;
    this.map = map; 
}
RoomController.prototype = Object.create(AreaController.prototype); // Links the prototype to the superclass
RoomController.prototype.constructor = RoomController;


function Room(id,color,state,map){
	AreaClass.call(this,id,color,"Room","RM");
    this.state = state;
    this.map = map; 
	this.zones = [];
	this.reservable = false;
    this.reservation = null;
    this.department = {
        deptName: "Unassigned",
        deptID:"00000"
    };
    this.capacity = 0;
    this.roomType = null;
    this.equipment = [];
    this.ameneties = [];
    this.accessibility = [];
	this.packageParameters = [ // Used in undo/redo/duplicate/save/load methods
        "type",
        "id",
        "name",
        "area",
        "color",
        "lastPoint",
        "opacity",
        "labelPoint",
        "reservable",
        "capacity",
        "equipment",
        "ameneties",
        "accessibility",
        "roomType",
        "department",
        "nameLabelStyle",
        "areaLabelStyle",
        "segmentLabelStyle",
        "showNameLabel",
        "showAreaLabel",
    ];
    this.dataPackageParameters = [ // Used in area type database creation
        "id",
        "name",
        "area",
        "seats",
        "zones",
        "reservable",
        "capacity",
        "equipment",
        "ameneties",
        "accessibility",
        "roomType",
        "department"
    ];
}
Room.prototype = Object.create(AreaClass.prototype);
Room.prototype.constructor = Room;

Room.prototype.setReservation = function(reservation){
    if(this.reservable){
        this.reservation = reservation;
        var user = reservation.user;
        this.areaSVG ? this.areaSVG.attr('fill','#bc322b') : null;
        this.areaSVG ? this.areaSVG.velocity({fillOpacity:.2}) : null;
        this.areaSVG ? this.areaSVG.attr('onmouseout',"AreaClass.prototype.area_exit_hover(this.id,.2)") : null;
    }
    this.update();
}

Room.prototype.checkReservation = function(){
    if(this.reservable && this.reservation){
        var now = moment().valueOf();
        var end = this.reservation.end;
        if(now > end){
            this.clearReservation();
        }
    } else if(this.reservable){
        this.clearReservation();
    }
}

Room.prototype.clearReservation = function(){
    this.reservation = null;
    this.areaSVG ? this.areaSVG.attr('fill','#32af21') : null;
    this.areaSVG ? this.areaSVG.velocity({fillOpacity:.2}) : null;
    this.areaSVG ? this.areaSVG.attr('onmouseout',"AreaClass.prototype.area_exit_hover(this.id,.2)") : null;
    this.update();
}

Room.prototype.setReservationToNull = function(){
    this.reservation = null;
}

Room.prototype.getObjectData = function(subcategory,id){  // This function is called when the user selects a wall object
    var thisData = {};
    thisData.data = {
        objectType: {type:"label",value:this.type},
        objectName: {type:"text",value:this.name},
        objectArea: {type:"label",value:this.renderArea(this.area)},
        objectAreaColor: {type:"color",value:this.color},
        objectRoomCapacity: {type:"spinner",value:this.capacity},
        objectLabelColor: {type:"color",value:this.nameLabel.color},
        objectLabelSize: {type:"spinner",value:this.nameLabel.size},
        objectNameStyleText: {type:"na",value:AreaClass.prototype.nameSlide(null,{value:this.nameLabelStyle})},
        objectNameStyle: {type:"slider",value:this.nameLabelStyle,min:0,max:2,slide:AreaClass.prototype.nameSlide},
        objectAreaStyleText: {type:"na",value:AreaClass.prototype.areaSlide(null,{value:this.areaLabelStyle})},
        objectAreaStyle: {type:"slider",value:this.areaLabelStyle,min:0,max:2,slide:AreaClass.prototype.areaSlide},
        objectDistanceStyleText: {type:"na",value:AreaClass.prototype.distSlide(null,{value:this.segmentLabelStyle})},
        objectDistanceStyle: {type:"slider",value:this.segmentLabelStyle,min:0,max:2,slide:AreaClass.prototype.distSlide},
        objectRoomType: {type:"drop-down",value:this.roomType},
        objectRoomEquipment: {type:"checks",value:this.equipment},
        objectRoomAccess: {type:"checks",value:this.accessibility},
        objectRoomAmeneties: {type:"checks",value:this.ameneties},
        objectReservableToggle: {type:"switch",value:this.reservable},
        objectDepartment: {type:"drop-down",value:JSON.stringify(this.department)},
    }
    thisData.dividers = {
        roomDivider:true,
        areaDivider:true,
        labelsDivider:true
    }
    return thisData;
}

Room.prototype.toggleReservable = function(val){
    this.reservable = val || !this.reservable;
}

Room.prototype.getObjectViewerData = function(subcategory,id){
    var thisData = {};
    thisData.data = {
        vObjectType: {type:"label",value:this.type},
        vObjectAreaNameType: {type:"label",value:this.type+" Name:"},
        vObjectAreaName: {type:"label",value:this.name},
        vObjectArea: {type:"label",value:this.renderArea(this.area)},
        vObjectTotalSeats: {type:"label",value:Object.keys(this.seats).length || 0},
    }
    thisData.dividers = {
        vSizeDivider: true,
        vSeatsDivider: true
    }
    if(this.reservable){
        thisData.data.vobjectReserveRoom = {type:"label",value:"Reserve Room"}
        thisData.data.vRoomResStatus = {type:"label",value:"Available"};
        thisData.data.vObjectRoomCapacity = {type:"label",value:this.capacity};
        thisData.dividers.vRoomReservationDivider = true;
        delete thisData.data.vObjectTotalSeats;
    }
    if(this.reservation){
        var user = this.reservation.user;
        var end = moment(this.reservation.end);
        var formattedEnd = formatNearOrFar(end);
        var nextAvailability = formatNearOrFar(
                moment(Maptician.Viewer.currentFile.dataConnections.getNextAvailability(this.id,this.type))
            );
        thisData.data.vRoomResStatus = {type:"label",value:"Reserved"};
        thisData.data.vRoomReservedImage = {type:"image",value: user.profileImages && user.profileImages.mediumProfile};
        thisData.data.vRoomReservedBy = {type:"label",value:user.first + " " + user.last};
        thisData.data.vRoomReservedUntil = {type:"label",value:formattedEnd};
        thisData.data.vRoomNextAvail = {type:"label",value:nextAvailability};
    } else if(this.reservable) {
        var nextReservation = Maptician.Viewer.currentFile.dataConnections.getNextReservation(this.id,this.type);
        var nextRes;
        if(nextReservation){
            nextRes = formatNearOrFar(moment(nextReservation.start));
        }
        thisData.data.vRoomResAvailUntil = {type:"label",value:nextRes ? nextRes : "1 Week+"};
    }

    return thisData;
}

Room.prototype.setobjectRoomCapacity = function(value){
    console.log('setting capacity')
    this.capacity = value;
    return this.capacity;

}