
function pathTextLabel(id,startPoint,endPoint,color,fontSize,xOffset,yOffset,location){
    console.log('label created')
    MapObject.call(this,"pathTextLabel",id);
    this.startPoint = startPoint;
    this.endPoint = endPoint;
    this.location = location;
    this.color = color;
    this.fontSize = fontSize;
    this.fontType = "Verdana";
    this.yOffset = yOffset; // Y offset for text to appear above or below line
    this.xOffset = xOffset; // X offset for where along the path the text will be displayed
    this.text = "";
    this.isDrawn = false;
    this.alreadyInverted = false;
    this.pathSVG = null;
    this.textSVG = null;
    this.textPath = null;
}
    pathTextLabel.prototype = Object.create(ObjectController.prototype); // Links the prototype to the superclass
    pathTextLabel.prototype.constructor = pathTextLabel;
    pathTextLabel.prototype.draw = function(){ // Creates a text and textpath svg objects and appends the textpath to the text
        var path = "M " + this.startPoint.x + " " + this.startPoint.y + " L " + this.endPoint.x + " " + this.endPoint.y ;
        var createPath = document.createElementNS('http://www.w3.org/2000/svg', 'path');
        createPath.setAttribute('d',path);
        createPath.setAttribute('id',"path"+this.id);
        createPath.setAttribute('class',"elevator");
        createPath.setAttribute('pointer-events',"none");
        createPath.setAttribute('style',"stroke-linecap:square ; stroke:none ; fill:none");
        $('#'+this.location).append(createPath);
        this.pathSVG = $("#path" + this.id);

        var textObject = document.createElementNS('http://www.w3.org/2000/svg', 'text');
        textObject.setAttribute('pointer-events',"none");
        textObject.setAttribute('font-family',this.fontType);
        textObject.setAttribute('font-size',this.fontSize);
        textObject.setAttribute('fill',this.color);
        textObject.setAttribute('id',this.id);
        $('#'+this.location).append(textObject);
        this.textSVG = $("#" + this.id);
        
        var textPathObject = document.createElementNS('http://www.w3.org/2000/svg', 'textPath');
        textPathObject.setAttributeNS('http://www.w3.org/1999/xlink','href',"#path"+this.id);
        textPathObject.setAttribute('id',"p"+this.id);
        textPathObject.setAttribute('startOffset',this.xOffset);
        textPathObject.setAttribute('text-anchor',"middle");
        this.textSVG.append(textPathObject);
        this.textPath = $("#p" + this.id);

        this.textPath.html("<tspan dy='"+this.yOffset+"'>"+this.text+"</tspan>");
        this.isDrawn = true;
    }
    pathTextLabel.prototype.remove = function(){  // Removes the screen svg elements of the wall label
        if(this.isDrawn == true){
            this.textSVG.remove();
            this.pathSVG.remove();
            this.isDrawn = false;
        }
    }
    pathTextLabel.prototype.redraw = function(){ // Recreates the label if it has had its screen elements removed, uses existing label data
        if(this.isDrawn == false){
            this.draw();
            this.update(this.text,this.startPoint,this.endPoint);
        }
    }
    pathTextLabel.prototype.update = function(text,startPoint,endPoint){
        this.text = text ? text : this.text;
        this.startPoint = startPoint ? startPoint : this.startPoint;
        this.endPoint = endPoint ? endPoint : this.endPoint;
        var path = "M " + this.startPoint.x + " " + this.startPoint.y + " L " + this.endPoint.x + " " + this.endPoint.y;
        this.pathSVG.attr("d",path);
        this.textPath.html("<tspan dy='"+this.yOffset+"'>"+this.text+"</tspan>");
        this.checkInversion();
    }
    pathTextLabel.prototype.updateDist = function(start,end){
        this.startPoint = start || this.startPoint;
        this.endPoint = end || this.endPoint;        
        var path = "M " + this.startPoint.x + " " + this.startPoint.y + " L " + this.endPoint.x + " " + this.endPoint.y;
        this.pathSVG.attr("d",path);
        this.text = renderLength(getLength(this.startPoint,this.endPoint),{system:$Map.unit() || 'US'});
        this.textPath.html("<tspan dy='"+this.yOffset+"'>"+this.text+"</tspan>");
        this.checkInversion();        
    }
    pathTextLabel.prototype.setText = function(text,start,end,xOffset,yOffset){
        if(this.textSVG){
            this.xOffset = xOffset || this.xOffset;
            this.yOffset = yOffset || this.yOffset;
            this.text = text || this.text;            
            this.startPoint = start;
            this.endPoint = end;

            var path = "M " + this.startPoint.x + " " + this.startPoint.y + " L " + this.endPoint.x + " " + this.endPoint.y;
            this.pathSVG.attr("d",path);
          
            // Updates the text on the label
            this.textPath.html("<tspan dy='"+this.yOffset+"'>"+this.text+"</tspan>");

            // Updates the labels along the path based on the path's orientation.  If the path is upside-down, the labels are fliped and rotated
            if(this.isInverted()){
                this.textSVG.attr("transform","rotate(180 "+(start.x+end.x)/2+" "+(start.y+end.y)/2+")");
                this.textPath.attr('startOffset',(100*(1-this.xOffset.slice(0,-1)/100)+"%")); // Offsets need to be flipped when orientation is flipped
            } else { // Resets the rotation and offsets for normal orientation
                this.textSVG.attr("transform","rotate(0)");
                this.textPath.attr('startOffset',this.xOffset);
            }
        } else{
            this.startPoint = start;
            this.endPoint = end;
        }        
    }
    pathTextLabel.prototype.checkInversion = function(){
        // Updates the labels along the path based on the path's orientation.  If the path is upside-down, the labels are fliped and rotated
        if(this.isInverted()){
            this.textSVG.attr("transform","rotate(180 "+(this.startPoint.x+this.endPoint.x)/2+" "+(this.startPoint.y+this.endPoint.y)/2+")");
            this.setYOffset(this.fontSize);
        } else { // Resets the rotation and offsets for normal orientation
            this.textSVG.attr("transform","rotate(0)");
            this.setYOffset(-5);
        }
    }
    pathTextLabel.prototype.isInverted = function(){
        return this.startPoint.x > this.endPoint.x;
    }
    pathTextLabel.prototype.setYOffset = function(offset){  // Changes the y offset of the text label, used to change the over/under orientation of text
        this.yOffset = offset;
        this.textPath.html("<tspan dy='"+this.yOffset+"'>"+this.text+"</tspan>");
    }
    pathTextLabel.prototype.setAnchor = function(anchorType){  // Changes the anchor type of the text label, should be right/middle/left
        this.textPath ? this.textPath.attr('text-anchor',anchorType) : null;
    }
    pathTextLabel.prototype.setColor = function(color){
        if(this.textSVG){
            var isOk  = /(^#[0-9A-F]{6}$)|(^#[0-9A-F]{3}$)/i.test(color)
            if(isOk){
                this.color = color;
            } else {
                console.log("Color not recognized");
            }
            this.textSVG.attr('fill',this.color);
        }        
    }
    pathTextLabel.prototype.setFontSize = function(size){
        this.fontSize = size;
        this.textSVG ? this.textSVG.attr('font-size',this.fontSize) : null;
    }
    pathTextLabel.prototype.changeAnchor = function(anchorType){  // Changes the anchor type of the text label, should be right/middle/left
        this.textPath ? this.textPath.attr('text-anchor',anchorType) : null;
    }





function WallTextLabel(id,color,fontSize,path,xOffset,yOffset){
    this.id = id;
    this.color = color;
    this.fontSize = fontSize;
    this.fontType = "Verdana";
    this.path = path;
    this.yOffset = yOffset; // Y offset for text to appear above or below line
    this.xOffset = xOffset; // X offset for where along the path the text will be displayed
    this.text = "";
    this.isDrawn = false;
    this.textSVG = null;
    this.pathSVG = null;
}
    WallTextLabel.prototype.draw = function(){ // Creates a text and textpath svg objects and appends the textpath to the text
        var textObject = document.createElementNS('http://www.w3.org/2000/svg', 'text');
        textObject.setAttribute('pointer-events',"none");
        textObject.setAttribute('font-family',this.fontType);
        textObject.setAttribute('font-size',this.fontSize);
        textObject.setAttribute('fill',this.color);
        textObject.setAttribute('id',this.id);
        $('#labelGroup').append(textObject);
        this.textSVG = $("#" + this.id);

        var textPathObject = document.createElementNS('http://www.w3.org/2000/svg', 'textPath');
        textPathObject.setAttributeNS('http://www.w3.org/1999/xlink','href',"#"+this.path);
        textPathObject.setAttribute('id',"p"+this.id);
        textPathObject.setAttribute('startOffset',this.xOffset);
        textPathObject.setAttribute('text-anchor',"middle");
        this.textSVG.append(textPathObject);
        this.pathSVG = $("#p" + this.id);

        this.pathSVG.html("<tspan dy='"+this.yOffset+"'>"+this.text+"</tspan>");
        this.isDrawn = true;
    }
    WallTextLabel.prototype.remove = function(){  // Removes the screen svg elements of the wall label
        if(this.isDrawn){
            this.textSVG.remove();
            this.isDrawn = false;
        }
    }
    WallTextLabel.prototype.redraw = function(wall,text){ // Recreates the label if it has had its screen elements removed, uses existing label data
        if(this.isDrawn == false){
            this.draw();
            this.text = text || this.text;
            this.setText(this.text,wall);
        }
    }
    WallTextLabel.prototype.setText = function(text,wall,xOffset,yOffset){ // This function updates the label's text and position, offsets are optional
        if(document.getElementById(this.id)){
            this.xOffset = xOffset || this.xOffset;
            this.yOffset = yOffset || this.yOffset;
            this.text = text || this.text;

            // Updates the text on the label
            this.pathSVG.html("<tspan dy='"+this.yOffset+"'>"+this.text+"</tspan>");

            // Updates the labels along the path based on the path's orientation.  If the path is upside-down, the labels are fliped and rotated
            if(wall.isInverted()){
                this.textSVG.attr("transform","rotate(180 "+(wall.points[0].x+wall.points[1].x)/2+" "+(wall.points[0].y+wall.points[1].y)/2+")");
                this.pathSVG.attr('startOffset',(100*(1-this.xOffset.slice(0,-1)/100)+"%"));
            } else { // Resets the rotation and offsets for normal orientation
                this.textSVG.attr("transform","rotate(0)");
                this.pathSVG.attr('startOffset',this.xOffset);
            }
        }
    }
    WallTextLabel.prototype.setYOffset = function(offset){  // Changes the y offset of the text label, used to change the over/under orientation of text
        this.yOffset = offset;
        this.pathSVG.html("<tspan dy='"+this.yOffset+"'>"+this.text+"</tspan>");
    }
    WallTextLabel.prototype.changeAnchor = function(anchorType){  // Changes the anchor type of the text label, should be right/middle/left
        this.pathSVG ? this.pathSVG.attr('text-anchor',anchorType) : null;
    }
    WallTextLabel.prototype.setColor = function(color){
        if(this.textSVG){
            var isOk  = /(^#[0-9A-F]{6}$)|(^#[0-9A-F]{3}$)/i.test(color)
            if(isOk){
                this.color = color;
            } else {
                console.log("Color not recognized");
            }
            this.textSVG.attr('fill',this.color);
        }        
    }
    WallTextLabel.prototype.setFontSize = function(size){
        if(this.textSVG){
            this.fontSize = size;
            this.textSVG.attr('font-size',this.fontSize);
        }        
    }


function label(id,pointId,text,font,size,x,y,color,pointerEvents,textAnchor,yOffset,appendTo,className){
        MapObject.call(this,"Label",id); // Sets Label as subclass of MapObject
        this.text = text;
        this.font = font;
        this.size = size;
        this.point = new point(x,y,pointId);
        this.x = x;
        this.y = y;
        this.color = color;
        this.pointerEvents = pointerEvents; // visiblePainted, visibileFill, visibleStroke, visible, painted, fill, stroke, all, none, inherit
        this.textAnchor = textAnchor; // start, middle, end, inherit
        this.yOffset = yOffset;
        this.appendTo = appendTo;
        this.labelActive = false;
        this.labelSVG = null;
    }
    label.prototype = Object.create(MapObject.prototype); // Links the prototype to the superclass
    label.prototype.constructor = label;
    label.prototype.drawLabel = function(){
        var textLabel = document.createElementNS('http://www.w3.org/2000/svg', 'text');
            textLabel.setAttribute('pointer-events',this.pointerEvents);
            textLabel.setAttribute('text-anchor',this.textAnchor);
            textLabel.setAttribute('font-size',this.size);
            textLabel.setAttribute('font-weight',"bold");
            textLabel.setAttribute('font-family',this.font);
            textLabel.setAttribute('fill',this.color);
            textLabel.setAttribute('x',this.point.x);
            textLabel.setAttribute('y',this.point.y);
            textLabel.setAttribute('id',this.id);
        $("#"+this.appendTo).append(textLabel);
        this.labelSVG = $("#" + this.id);

        this.labelSVG.html("<tspan dy="+this.yOffset+">"+this.text+"</tspan>");
        this.labelActive = true;
    };
    label.prototype.drawPoint = function(){
        this.point.drawHandle();
    }
    label.prototype.removePoint = function(){
        this.point.removeHandle();
    }
    label.prototype.removeLabel = function(){
        this.labelSVG ? this.labelSVG.remove() : null;
        this.labelActive = false;
    }
    label.prototype.updatePosition = function(x,y){
        this.x = x;
        this.y = y;
        this.point.updatePosition(x,y);
        this.labelSVG.attr(this.point.getPoint());
    }
    label.prototype.getPoint = function(){
        return {x:this.point.x,y:this.point.y};
    }
    label.prototype.dragOffset = function(xmove,ymove,options){
        var totalDrag = this.point.dragOffset(xmove,ymove,options);
        this.labelSVG ? this.labelSVG.attr(this.point.getPoint()) : null;
        return totalDrag;
    }
    label.prototype.shiftPosition = function(x,y){  // Moves the point in the x or y direction a specified amount
        this.point.shiftPosition(x,y);
        this.labelSVG ? this.labelSVG.attr(this.point.getPoint()) : null;
    }
    label.prototype.update = function(text){
        if(this.labelSVG){
            this.labelSVG.attr(this.point.getPoint());
            if(text){
                this.text = text;
                this.labelSVG.html("<tspan dy="+this.yOffset+">"+this.text+"</tspan>");
            }
        }
    }
    label.prototype.redraw = function(){
        this.removeLabel();
        this.drawLabel();
    }
    label.prototype.updateText = function(text){
        this.text = text;
        this.labelSVG.html("<tspan dy="+this.yOffset+">"+this.text+"</tspan>");
    }
    label.prototype.toggleActive = function(){
        if(this.labelActive){
            this.removeLabel();
        } else {
            this.drawLabel();
        }
    }
    label.prototype.setYOffset = function(offset){  // Changes the y offset of the text label, used to change the over/under orientation of text
        this.yOffset = offset;
        this.labelSVG.html("<tspan dy='"+this.yOffset+"'>"+this.text+"</tspan>");
    }
    label.prototype.setFontSize = function(size){
        this.size = size;
        this.labelSVG.attr({"font-size": size});
    }
    label.prototype.animateMove = function(dx,dy,fontSize){
        var x = this.point.x + dx;
        var y = this.point.y + dy;
        this.labelSVG ? this.labelSVG.velocity("stop") : null;
        this.labelSVG ? this.labelSVG.velocity({x:x,y:y,fontSize:fontSize}) : null;
    }