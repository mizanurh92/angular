//#################################  MapLink Class #####################################################

function MapLink(id,state,map){
    MapObject.call(this,"MapLink",id); // Sets Kiosk as subclass of MapObject
    this.state = state; // Reference to the State Controller
    this.map = map; // Reference to the Map Controller

    this.connection = null; // This holds the data for the MapLink object connected to this one, if any

    this.name = "";  // This is the name for the specific seat, not the assigned user

    // Formatting options
    this.radius = 19;
    this.strokeWidth = 2;
    this.stroke = '#000000';
    this.background = '#ffffff';
    this.activeColor = '#ff0000';
    this.screenBackground = '#ffffff';
    this.textColor = '#000000';
    this.fontSize = 10;
    this.labelStyle = 2; // 0 is never show, 1 is show on select, 2 is always show

	this.points = [];

    this.circle = null; // alias for svg

	this.prefix = 'ML';
	this.packageParameters = [ // Used in undo/redo/duplicate/save/load methods
        "type",
        "id",
        "name",
        "connection",
        "stroke",
        "background",
        "textColor",
        "fontSize",
        "labelStyle"
    ];
    this.dataPackageParameters = [
        "id",
        "name"
    ];
}
	MapLink.prototype = Object.create(MapObject.prototype); // Links the prototype to the superclass
	MapLink.prototype.constructor = MapLink;

    MapLink.prototype.getMaplink = function(){
        return {
            link: this.connection,
            type: this.type
        }
    }

    MapLink.prototype.setMaplink = function(connection){
        this.connection = connection;
    }

    MapLink.prototype.removeMaplink = function(){
        this.connection = null;
    }

    MapLink.prototype.getConnectionValidator = function(){
        if(this.connection){
            return {
                maplinkID: this.id,
                connectionID: this.connection.linkID,
                mapID: this.connection.mapID
            }
        } else {
            return null;
        }
    }    

// ##########################################  Standard Object Interface Functions  #########################################################

	MapLink.prototype.create = function(){
        var pos = this.map.pointerCoords();
		this.points[0] = new point(pos.x,pos.y,this.prefix+"P"+'000'+this.id);
		this.createSVG();
		this.addLabels();
	}

	MapLink.prototype.dragPlace = function(){
        var pos = this.map.pointerCoords(); // gets the latest mouse location
        pos.x = this.map.snapRound(pos.x,undefined,true);
        pos.y = this.map.snapRound(pos.y,undefined,true);
        this.points[0].updatePosition(pos.x,pos.y);
        this.nameLabel.updatePosition(pos.x + this.radius + this.strokeWidth/2,pos.y);
        this.update();
	}

    MapLink.prototype.finalizeDragPlace = function(){
        
        this.setLabelStyle(this.labelStyle);
    }

	MapLink.prototype.update = function(){
		
        this.updateSVG();
	}

	MapLink.prototype.remove = function(){ // Removes the visual elements of the seat image and the labels
		this.removeSVG();
		this.removeLabels();
	}

	MapLink.prototype.redraw = function(){ // Redraws the seat and labels after they have been 'removed'
		this.createSVG();
		this.setLabelStyle(this.labelStyle);
	}

	MapLink.prototype.activate = function(multiSelect){
        console.log('activating',this.id)
        this.circle ? this.circle.attr('stroke',this.activeColor) : null;
        this.isSelected = true;
        this.setLabelStyle(this.labelStyle);
	}

	MapLink.prototype.deactivate = function(){
        this.circle ? this.circle.attr('stroke',this.stroke) : null;
        this.isSelected = false;
        this.setLabelStyle(this.labelStyle);
	}

	MapLink.prototype.getOutlinePoints = function(){ // Returns the point in the upper left
        
        return [this.points[0].getPoint()];
	}

// ##########################################  Application Mechanics (Undo/Redo/Duplicate/Save/Load)  #############################################

    MapLink.prototype.duplicate = function(original){
        for(var i = 0;i < original.points.length;i++){
            this.points.push(new point(original.points[i].x,original.points[i].y,original.points[i].id.substring(0,6)+this.id))
        }
        for(var i = 0;i < this.packageParameters.length;i++){
            if(this.packageParameters[i] != "id"){
                this[this.packageParameters[i]] = original[this.packageParameters[i]];
            }
        }
        this.createSVG();
		this.addLabels();
        this.shiftPosition(12,12);
    }

    MapLink.prototype.createPackage = function(){
        var package = {points:[]};
        for(var i = 0;i < this.points.length;i++){
            package.points.push(this.points[i].getSavePoint());
        }
        for(var i = 0;i < this.packageParameters.length;i++){
            package[this.packageParameters[i]] = this[this.packageParameters[i]];
        }
        package.controller = "maplinks";
        package.packageType = "modify";
        return package;
    }

    MapLink.prototype.loadPackage = function(package){
        // It doesn't matter if it is an undo or redo package, the impact is to reset the object to a former state
        for(var i = 0;i < this.points.length;i++){
            this.points[i].updatePosition(package.points[i].x,package.points[i].y);
            this.points[i].id = package.points[i].id;
        }
        for(var i = 0;i < this.packageParameters.length;i++){
            this[this.packageParameters[i]] = package[this.packageParameters[i]];
        }
        this.update();
        this.updateLabels();
    }

    MapLink.prototype.sendPackages = function(){
        // It is important to know that the undo and redo packages aren't the same.  If they are, there was no real action taken and
        // an undo or redo event will have no apparent effect
        var undo = this.undoPackage;
        var redo = this.createPackage();
        var same = true; // Used to determine whether the two packages are the same (no actual event occured)
        for(var i = 0;i < redo.points.length;i++){ // Runs through the points first as the most common event changes
            if(undo.points[i].x != redo.points[i].x || undo.points[i].y != redo.points[i].y){
                same = false;
                break; // breaks as soon as a single difference is found
            }
        }       
        if(same){ // No need to start second loop if a difference was already found
            for(var i = 0;i < this.packageParameters.length;i++){
                if(undo[this.packageParameters[i]] != redo[this.packageParameters[i]]){
                    same = false;
                    break;
                }
            }
        }
        // Packages are sent essentially simultaneously to prevent having mismatched packages if the action isn't finalized
        if(!same){
            this.state.addUndoPackage(undo);
            this.state.addRedoPackage(redo);
        }
    }

    MapLink.prototype.save = function(){
        var saveFile = {points:[]}
        for(var i = 0;i < this.points.length;i++){
            saveFile.points.push(this.points[i].getSavePoint());
        }
        for(var i = 0;i < this.packageParameters.length;i++){
            saveFile[this.packageParameters[i]] = this[this.packageParameters[i]];
        }
        return saveFile
    }

    MapLink.prototype.saveData = function(){ // This is used to populate the seat database through the dataController
        var saveFile = {};
        for(var i = 0;i < this.dataPackageParameters.length;i++){
            saveFile[this.dataPackageParameters[i]] = this[this.dataPackageParameters[i]];
        }
        saveFile.location = this.points[0].getPoint();
        return saveFile        
    }

    MapLink.prototype.load = function(saveFile){
        // Note that this method assumes that the create function has not been called - will not work if it has been
        for(var i = 0;i < saveFile.points.length;i++){
            this.points.push(new point(saveFile.points[i].x,saveFile.points[i].y,saveFile.points[i].id));
        }
        for(var i = 0;i < this.packageParameters.length;i++){
            this[this.packageParameters[i]] = saveFile[this.packageParameters[i]];
        }
        this.createSVG(); 
        this.addLabels();
        this.update();
    }

// ##########################################  Drag and Move Functions  #############################################

	MapLink.prototype.startDrag = function(){
        this.undoPackage = this.createPackage();
        for(var i = 0;i < this.points.length;i++){
            this.points[i].setDragReference();
        }
        this.nameLabel.point.setDragReference();
	}

	MapLink.prototype.drag = function(){
        var coords, xMove, yMove, distDragged;
        var map = this.map;
        coords = map.pointerCoords(); // gets the latest mouse location
        xMove = coords.x-map.handle.x/map.scale;
        yMove = coords.y-map.handle.y/map.scale;
        
        distDragged = this.points[0].dragOffset(xMove,yMove,{gridResolution:map.snapGridResolution,snapToGrid:map.snapGridActive});

        this.nameLabel.dragOffset(distDragged.x,distDragged.y);
        this.update(); 
	}

    MapLink.prototype.finalizeDrag = function(){
        this.sendPackages(this.state);
    }

	MapLink.prototype.move = function(direction){ // Nudges the object one gird unit in any direction 
		var map = this.map;
        var x = 0;
        var y = 0;
        switch(direction){
            case "up":
            y = -map.snapGridResolution;
            break;
            case "down":
            y = map.snapGridResolution;
            break;
            case "right":
            x = map.snapGridResolution;
            break;
            case "left":
            x = -map.snapGridResolution;
            break;
        }
		this.undoPackage = this.createPackage();
        var length = this.points.length;
        for(var i = 0;i < length;i++){
        	this.points[i].shiftPosition(x,y);
        }
        this.nameLabel.shiftPosition(x,y);
        this.update();
        this.sendPackages();
	}

    MapLink.prototype.shiftPosition = function(shiftLeft,shiftUp){ // Used in map resize or center operations
        var keys = Object.keys(this.points);
        var len = keys.length;
        var key,current;
        for(var i = 0;i < len;i++){
            try{
                key = keys[i];
                current = this.points[key];
                current.shiftPosition(shiftLeft,shiftUp);                
            } catch(err){
                console.log(err);
            }
        }
        try{
            this.nameLabel ? this.nameLabel.shiftPosition(shiftLeft,shiftUp) : null;           
        } catch (err){
            console.log(err);
        }
        this.update();
    } 

// ##########################################  Object SVG Functions  ##################################################################

	MapLink.prototype.createSVG = function(){
        var center = this.getCenter();
        var circle = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
        circle.setAttribute('id',"a"+this.id);
        circle.setAttribute('class',"Maplink");
        circle.setAttribute('cx',center.x);
        circle.setAttribute('cy',center.y);
        circle.setAttribute('r',this.radius);
        circle.setAttribute('pointer-events',"all");
        circle.setAttribute('stroke',this.stroke);
        circle.setAttribute('stroke-linecap','square');
        circle.setAttribute('fill',this.background);
        circle.setAttribute('stroke-width',this.strokeWidth);
        $('#labelGroup').append(circle);
        this.circle = $("#a" + this.id);      
	}

    MapLink.prototype.cancelDraw = function(){
        this.remove();
    }

    MapLink.prototype.screenPoints = function(){
        var point = this.points[0];
        var outer = {
            x: point.x + 10,
            y: point.y + 10,
            width: 20,
            height: 13,
            rounding: 2
        }
        var inner = {
            x: point.x + 11,
            y: point.y + 11,
            width: 18,
            height: 11,            
        }
        var arm = {
            x: point.x + 18,
            y: point.y + 22,
            height: 8,
            width: 4
        }
        var base = {
            point0: {
                x: point.x + 14,
                y: point.y + 27
            },
            point1: {
                x: point.x + 26,
                y: point.y + 27
            },
            point2: {
                x: point.x + 28,
                y: point.y + 31
            },
            point3: {
                x: point.x + 12,
                y: point.y + 31
            },
        }
        var basePath = ""
        basePath += "M " + base.point0.x + " " + base.point0.y; // Start point at upper left
        basePath += "L " + base.point1.x + " " + base.point1.y;  // Point at the upper right
        basePath += "L " + base.point2.x + " " + base.point2.y;  // Point at the lower right
        basePath += "L " + base.point3.x + " " + base.point3.y;  // Point at the lower left
        basePath += "Z" // Return and close of position
        return {
            outer: outer,
            inner: inner,
            arm: arm,
            base: basePath
        }
    }

    MapLink.prototype.getCenter = function(){
        return {
            x: this.points[0].x + this.radius + this.strokeWidth/2,
            y: this.points[0].y + this.radius + this.strokeWidth/2
        }
    }

	MapLink.prototype.updateSVG = function(){
        var center = this.getCenter();
		this.circle ? this.circle.attr({cx:center.x,cy:center.y}) : null;
	}

	MapLink.prototype.removeSVG = function(){
		this.circle ? this.circle.remove() : null;
	}

// ##########################################   Label Functions  ##################################################################

    MapLink.prototype.setLabelStyle = function(styleNumber){ // Changes the display behavior of the distance labels based on a style number from a slider
        if(styleNumber != undefined){
            this.labelStyle = styleNumber;
        }
        switch(this.labelStyle){
            case 0: // Never show labels
                this.removeLabels();
            break;
            case 1: // Only show labels when selected
                if(this.isSelected == true){
                    this.redrawLabels();
                } else {
                   this.removeLabels(); 
                }
            break;
            case 2: // Always show labels (default)
                this.redrawLabels();
            break;
        }
        return this.labelStyle;
    }

	MapLink.prototype.addLabels = function(){
		this.createNameLabel();
	}

	MapLink.prototype.createNameLabel = function(){
        if(this.nameLabel != {}){
			this.nameLabel = new label(
				this.prefix + "L000" + this.id, // name label's id is subcategory 'L' index 1
				this.prefix + "N000" + this.id, // name label's point id is subscategory 'n'
				this.name,  // text contents
				"inherit",  // font
				this.fontSize, // font size
				this.points[0].x + this.radius + this.strokeWidth/2, // x coordinate offset
				this.points[0].y, // y coordinate
				this.textColor, // font color
				"none", // pointer events (none by default so mouse-over won't affect shading)
				'middle', // text anchor
				2 * this.radius + this.fontSize + 2, // y offset
				"labelGroup", // where to append the label
				this.type.toLowerCase()+"Label" // class name for the pointer handle
			);
			this.nameLabel.drawLabel();
		};
	}
	
	MapLink.prototype.removeLabels = function(){
		if(this.nameLabel.x){this.nameLabel.removeLabel()};
	}

	MapLink.prototype.redrawLabels = function(){
		this.nameLabel.redraw();
	}

    MapLink.prototype.updateLabels = function(){
        this.nameLabel.updatePosition(this.points[0].x + this.radius,this.points[0].y);
    }

// ##########################################  Selector Interface Functions  ######################################################################

	MapLink.prototype.setProperty = function(property,value){
        switch(property){
            case "objectName":
                this.name = value;
                this.nameLabel.updateText(this.name);
            break;
            case "objectAreaColor":
                this.setobjectAreaColor(value);
            break;
            case "objectLabelColor":
                this.setobjectLabelColor(value);
            break;
            case "objectLabelSize":
            	this.setobjectLabelSize(value);
            break;
            case "objectLabelStyle":
                this.setLabelStyle(value);
            break;
            case "objectStrokeColor":
                this.setobjectStrokeColor(value);
            break;
            case "objectFillColor":
                this.setobjectFillColor(value);
            break;
        }
    }

    MapLink.prototype.getProperties = function(subcategory,id){
        var thisData = {};
        thisData.data = {
            objectType: {type:"label",value:this.getTypeName()},
            objectName: {type:"text",value:this.name},
            objectLabelStyleText: {type:"na",value:MapLink.prototype.slide(null,{value:this.labelStyle})},
            objectLabelStyle: {type:"slider",value:this.labelStyle,min:0,max:2,slide:MapLink.prototype.slide},
            objectLabelColor: {type:"color",value:this.textColor},
            objectLabelSize: {type:"spinner",value:this.fontSize},
            objectStrokeColor: {type:"color",value:this.stroke},
            objectFillColor: {type:"color",value:this.background},
            objectmaplinkConnection: {type:"label",value:this.connection ? this.connection.linkName : "No Connections"},            
            objectSetConnection: {type:"label",value:'Set'},
            objectClearConnection: {type:"label",value:'Clear'},
        }
        thisData.dividers = {
            maplinkDivider:true,
            labelsDivider:true,
            colorDivider:true,
        }
        return thisData;
    }

    MapLink.prototype.getTypeName = function(){
        switch(this.type){
            case "StairsMaplink":
                return "MapLink - Stairs";
            break;
        }
    }

    MapLink.prototype.getObjectViewerData = function(subcategory,id){
        var thisData = {};
        thisData.data = {
            vObjectName: {type:"label",value:this.name}
        }
        thisData.dividers = {
        }
        return thisData;
    }

    MapLink.prototype.slide = function(event,ui){
            var message = "";
            switch(ui.value){
                case 0:
                message = "No Labels"
                break;
                case 1:
                message = "Show Labels on Select"
                break;
                case 2:
                message = "Always Show Labels"
                break;
            }
            $( "#objectLabelStyleText" ).html(message);
    }

	MapLink.prototype.setName = function(name){
    	this.name = name;
    	this.nameLabel.updateText(name);
    }

    MapLink.prototype.setobjectStrokeColor = function(color){
        var isOk  = /(^#[0-9A-F]{6}$)|(^#[0-9A-F]{3}$)/i.test(color)
        if(isOk){
            this.stroke = color;
        } else {
            console.log("color not recognized")
        }
        this.circle.attr("stroke",this.stroke);
        this.arm.attr("fill",this.stroke);
        this.base.attr("fill",this.stroke);
        this.outerScreen.attr({fill:this.stroke,stroke:this.stroke})
        return this.stroke;
    }

    MapLink.prototype.setobjectFillColor = function(color){
        var isOk  = /(^#[0-9A-F]{6}$)|(^#[0-9A-F]{3}$)/i.test(color)
        if(isOk){
            this.background = color;
        } else {;
            console.log("color not recognized")
        }
        this.circle.attr("fill",this.background);
        return this.fill;
    }

	MapLink.prototype.setobjectLabelColor = function(color){
    	var isOk  = /(^#[0-9A-F]{6}$)|(^#[0-9A-F]{3}$)/i.test(color)
        if(isOk){
            this.textColor = color;
            this.nameLabel.color = color;
            this.nameLabel.redraw();
        } else {
            message.errorMessage("Color not recognized");
        }

        return this.nameLabel.color;
    }

	MapLink.prototype.setobjectLabelSize = function(size){
        this.fontSize = size;
        this.nameLabel.setFontSize(size);
        this.nameLabel.setYOffset(2 * this.radius + size + 2);
    }