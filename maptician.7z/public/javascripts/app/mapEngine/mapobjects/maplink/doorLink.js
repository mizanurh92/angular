//#################################  DoorMapLink Class #####################################################

function DoorMaplink(id,state,map){
    MapLink.call(this,id,state,map); // Sets StairsLink as subclass of MapLink (which is also a MapObject)
    this.name = "Door";  // This is the name for the specific seat, not the assigned user
    this.type = "DoorMaplink";

    this.connection = null; // This holds the data for the StairsMapLink object connected to this one, if any

    // Formatting options
    this.radius = 19;
    this.strokeWidth = 2;
    this.stroke = '#000000';
    this.background = '#ffffff';
    this.activeColor = '#ff0000';
    this.screenBackground = '#ffffff';
    this.textColor = '#000000';
    this.fontSize = 10;
    this.labelStyle = 2; // 0 is never show, 1 is show on select, 2 is always show

	this.points = [];

    this.frame = null;
    this.circle = null;
    this.door = null;

	this.prefix = 'ML';
	this.packageParameters = [ // Used in undo/redo/duplicate/save/load methods
        "type",
        "id",
        "name",
        "connection",
        "stroke",
        "background",
        "textColor",
        "fontSize",
        "labelStyle"
    ];
    this.dataPackageParameters = [ // Used in database creation
        "id",
        "name",
        "type",
        "connection"
    ];
}
	DoorMaplink.prototype = Object.create(MapLink.prototype); // Links the prototype to the superclass
	DoorMaplink.prototype.constructor = DoorMaplink;
	
// ##########################################  Object SVG Functions  ##################################################################

	DoorMaplink.prototype.createSVG = function(){
        var center = this.getCenter();

        var circle = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
        circle.setAttribute('id',"a"+this.id);
        circle.setAttribute('class',"Maplink Door");
        circle.setAttribute('cx',center.x);
        circle.setAttribute('cy',center.y);
        circle.setAttribute('r',this.radius);
        circle.setAttribute('pointer-events',"all");
        circle.setAttribute('fill',"white");
        circle.setAttribute('stroke',this.stroke);
        circle.setAttribute('stroke-width',this.strokeWidth);
        $('#labelGroup').append(circle);
        this.circle = $("#a" + this.id);

        var frame = document.createElementNS('http://www.w3.org/2000/svg', 'path');
        frame.setAttribute('id',"b"+this.id);
        frame.setAttribute('class',"Maplink Door");
        frame.setAttribute('d',this.getFramePath());
        frame.setAttribute('pointer-events',"all");
        frame.setAttribute('stroke',this.stroke);
        frame.setAttribute('stroke-linecap','butt');
        frame.setAttribute('stroke-width',1.5);
        frame.setAttribute('fill','none');
        $('#labelGroup').append(frame);
        this.frame = $("#b" + this.id); 

        var door = document.createElementNS('http://www.w3.org/2000/svg', 'path');
        door.setAttribute('id',"c"+this.id);
        door.setAttribute('class',"Maplink Door");
        door.setAttribute('d',this.getDoorPath());
        door.setAttribute('pointer-events',"all");
        door.setAttribute('stroke',this.stroke);
        door.setAttribute('stroke-linecap','butt');
        door.setAttribute('stroke-width',0);
        $('#labelGroup').append(door);
        this.door = $("#c" + this.id); 

        var handle = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
        handle.setAttribute('id',"d"+this.id);
        handle.setAttribute('class',"Maplink Door");
        handle.setAttribute('cx',center.x-1);
        handle.setAttribute('cy',center.y+4);
        handle.setAttribute('r',1);
        handle.setAttribute('pointer-events',"all");
        handle.setAttribute('fill',"white");
        handle.setAttribute('stroke',this.stroke);
        handle.setAttribute('stroke-width',0);
        $('#labelGroup').append(handle);
        this.handle = $("#d" + this.id);

	}

    DoorMaplink.prototype.getDoorPath = function(end,start){
        var point = this.points[0];
        var lowerLeft = {
            x:point.x + 16,
            y:point.y + 37
        };
        var upperLeft = {
            x:point.x + 16,
            y:point.y + 9
        }
        var upperRight = {
            x:point.x + 27,
            y:point.y + 7
        }
        var lowerRight = {
            x:point.x + 27,
            y:point.y + 34
        }
        var framePath = ""
        framePath += "M " + lowerLeft.x + " " + lowerLeft.y;
        framePath += "L " + upperLeft.x + " " + upperLeft.y;
        framePath += "L " + upperRight.x + " " + upperRight.y;
        framePath += "L " + lowerRight.x + " " + lowerRight.y;
        return framePath += "Z";
    }

    DoorMaplink.prototype.getFramePath = function(end,start){
        var point = this.points[0];
        var lowerLeft = {
            x:point.x + 12,
            y:point.y + 34
        };
        var upperLeft = {
            x:point.x + 12,
            y:point.y + 6
        }
        var upperRight = {
            x:point.x + 28,
            y:point.y + 6
        }
        var lowerRight = {
            x:point.x + 28,
            y:point.y + 34
        }
        var framePath = ""
        framePath += "M " + lowerLeft.x + " " + lowerLeft.y;
        framePath += "L " + upperLeft.x + " " + upperLeft.y;
        framePath += "L " + upperRight.x + " " + upperRight.y;
        framePath += "L " + lowerRight.x + " " + lowerRight.y;
        return framePath;
    }

	DoorMaplink.prototype.updateSVG = function(){
        var center = this.getCenter();
		this.circle ? this.circle.attr({cx:center.x,cy:center.y}) : null;
        this.handle ? this.handle.attr({cx:center.x-1,cy:center.y+4}) : null;
        this.frame ? this.frame.attr({d:this.getFramePath()}) : null;
        this.door ? this.door.attr({d:this.getDoorPath()}) : null;
	}

	DoorMaplink.prototype.removeSVG = function(){
		this.circle ? this.circle.remove() : null;
        this.frame ? this.frame.remove() : null;
        this.door ? this.door.remove() : null;
        this.handle ? this.handle.remove() : null;
	}

// ##########################################  Selector Interface Functions  ######################################################################

	DoorMaplink.prototype.setProperty = function(property,value){
        switch(property){
            case "objectName":
                this.name = value;
                this.nameLabel.updateText(this.name);
            break;
            case "objectAreaColor":
                this.setobjectAreaColor(value);
            break;
            case "objectLabelColor":
                this.setobjectLabelColor(value);
            break;
            case "objectLabelSize":
            	this.setobjectLabelSize(value);
            break;
            case "objectLabelStyle":
                this.setLabelStyle(value);
            break;
            case "objectStrokeColor":
                this.setobjectStrokeColor(value);
            break;
            case "objectFillColor":
                this.setobjectFillColor(value);
            break;
        }
    }

    DoorMaplink.prototype.getObjectViewerData = function(subcategory,id){
        var thisData = {};
        thisData.data = {
            vObjectName: {type:"label",value:this.name}
        }
        thisData.dividers = {
        }
        return thisData;
    }

    DoorMaplink.prototype.setobjectStrokeColor = function(color){
        var isOk  = /(^#[0-9A-F]{6}$)|(^#[0-9A-F]{3}$)/i.test(color)
        if(isOk){
            this.stroke = color;
        } else {
            console.log("color not recognized")
        }
        this.circle.attr("stroke",this.stroke);
        this.stairs.attr("fill",this.stroke);
        return this.stroke;
    }

    DoorMaplink.prototype.setobjectFillColor = function(color){
        var isOk  = /(^#[0-9A-F]{6}$)|(^#[0-9A-F]{3}$)/i.test(color)
        if(isOk){
            this.background = color;
        } else {;
            console.log("color not recognized")
        }
        this.innerCircle.attr("fill",this.background);
        return this.fill;
    }

	DoorMaplink.prototype.setobjectLabelColor = function(color){
    	var isOk  = /(^#[0-9A-F]{6}$)|(^#[0-9A-F]{3}$)/i.test(color)
        if(isOk){
            this.textColor = color;
            this.nameLabel.color = color;
            this.nameLabel.redraw();
        } else {
            message.errorMessage("Color not recognized");
        }

        return this.nameLabel.color;
    }