//#################################  ElevatorMapLink Class #####################################################

function ElevatorMaplink(id,state,map){
    MapLink.call(this,id,state,map); // Sets ElevatorMapLink as subclass of MapLink (which is also a MapObject)
    this.name = "Elevator";  // This is the name for the specific seat, not the assigned user
    this.type = "ElevatorMaplink";

    this.connection = null; // This holds the data for the StairsMapLink object connected to this one, if any

    // Formatting options
    this.radius = 19;
    this.strokeWidth = 2;
    this.stroke = '#000000';
    this.background = '#ffffff';
    this.activeColor = '#ff0000';
    this.screenBackground = '#ffffff';
    this.textColor = '#000000';
    this.fontSize = 10;
    this.labelStyle = 2; // 0 is never show, 1 is show on select, 2 is always show

	this.points = [];

    this.circle = null;
    this.frame = null;
    this.door = null;
    this.display = null;
    this.button1 = null;
    this.button2 = null;

	this.prefix = 'ML';
	this.packageParameters = [ // Used in undo/redo/duplicate/save/load methods
        "type",
        "id",
        "name",
        "connection",
        "stroke",
        "background",
        "textColor",
        "fontSize",
        "labelStyle"
    ];
    this.dataPackageParameters = [ // Used in database creation
        "id",
        "name",
        "type",
        "connection"
    ];
}
	ElevatorMaplink.prototype = Object.create(MapLink.prototype); // Links the prototype to the superclass
	ElevatorMaplink.prototype.constructor = ElevatorMaplink;
	
// ##########################################  Object SVG Functions  ##################################################################

	ElevatorMaplink.prototype.createSVG = function(){
        var center = this.getCenter();

        var circle = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
        circle.setAttribute('id',"a"+this.id);
        circle.setAttribute('class',"Maplink Elevator");
        circle.setAttribute('cx',center.x);
        circle.setAttribute('cy',center.y);
        circle.setAttribute('r',this.radius);
        circle.setAttribute('pointer-events',"all");
        circle.setAttribute('fill',"white");
        circle.setAttribute('stroke',this.stroke);
        circle.setAttribute('stroke-width',this.strokeWidth);
        $('#labelGroup').append(circle);
        this.circle = $("#a" + this.id);

        var frame = document.createElementNS('http://www.w3.org/2000/svg', 'rect');
        frame.setAttribute('pointer-events','all');
        frame.setAttribute('stroke',this.stroke);
        frame.setAttribute('stroke-width',1.5);
        frame.setAttribute('fill',"white");
        frame.setAttribute('x',this.points[0].x+10);
        frame.setAttribute('y',this.points[0].y+12);
        frame.setAttribute('rx',.5);
        frame.setAttribute('ry',.5);
        frame.setAttribute('height',18);
        frame.setAttribute('width',20);
        frame.setAttribute('id',"b" + this.id);
        frame.setAttribute('class',"Maplink Elevator");
        $("#labelGroup").append(frame);
        this.frame = $("#b" + this.id);

        var display = document.createElementNS('http://www.w3.org/2000/svg', 'rect');
        display.setAttribute('pointer-events','all');
        display.setAttribute('stroke',this.stroke);
        display.setAttribute('stroke-width',.5);
        display.setAttribute('fill',"white");
        display.setAttribute('x',this.points[0].x+17);
        display.setAttribute('y',this.points[0].y+8);
        display.setAttribute('rx',.5);
        display.setAttribute('ry',.5);
        display.setAttribute('height',2);
        display.setAttribute('width',6);
        display.setAttribute('id',"c" + this.id);
        display.setAttribute('class',"Maplink Elevator");
        $("#labelGroup").append(display);
        this.display = $("#c" + this.id);

        var door = document.createElementNS('http://www.w3.org/2000/svg', 'path');
        door.setAttribute('id',"d"+this.id);
        door.setAttribute('class',"Maplink Elevator");
        door.setAttribute('d',this.getDoorPath());
        door.setAttribute('pointer-events',"all");
        door.setAttribute('stroke',this.stroke);
        door.setAttribute('stroke-linecap','butt');
        door.setAttribute('stroke-width',.5);
        door.setAttribute('fill','none');
        $('#labelGroup').append(door);
        this.door = $("#d" + this.id); 

        var button = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
        button.setAttribute('id',"e"+this.id);
        button.setAttribute('class',"Maplink Elevator");
        button.setAttribute('cx',this.points[0].x+32);
        button.setAttribute('cy',this.points[0].y+20);
        button.setAttribute('r',.5);
        button.setAttribute('pointer-events',"all");
        button.setAttribute('fill',"white");
        button.setAttribute('stroke',this.stroke);
        button.setAttribute('stroke-width',.25);
        $('#labelGroup').append(button);
        this.button1 = $("#e" + this.id);

        var button = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
        button.setAttribute('id',"f"+this.id);
        button.setAttribute('class',"Maplink Elevator");
        button.setAttribute('cx',this.points[0].x+32);
        button.setAttribute('cy',this.points[0].y+22);
        button.setAttribute('r',.5);
        button.setAttribute('pointer-events',"all");
        button.setAttribute('fill',"white");
        button.setAttribute('stroke',this.stroke);
        button.setAttribute('stroke-width',.25);
        $('#labelGroup').append(button);
        this.button2 = $("#f" + this.id);

	}

    ElevatorMaplink.prototype.getDoorPath = function(end,start){
        var point = this.points[0];
        var start = {
            x: point.x + 20,
            y: point.y + 12
        }
        var end = {
            x: point.x + 20,
            y: point.y + 30
        }
        var doorPath = ""
        doorPath += "M " + start.x + " " + start.y;
        doorPath += "L " + end.x + " " + end.y;
        return doorPath;
    }


	ElevatorMaplink.prototype.updateSVG = function(){
        var center = this.getCenter();
		this.circle ? this.circle.attr({cx:center.x,cy:center.y}) : null;
        this.frame ? this.frame.attr({x:this.points[0].x+10,y:this.points[0].y+12}) : null;
        this.display ? this.display.attr({x:this.points[0].x+17,y:this.points[0].y+8}) : null;
        this.door ? this.door.attr({d:this.getDoorPath()}) : null;
        this.button1 ? this.button1.attr({cx:this.points[0].x+32,cy:this.points[0].y+20}) : null;
        this.button2 ? this.button2.attr({cx:this.points[0].x+32,cy:this.points[0].y+22}) : null;
	}

	ElevatorMaplink.prototype.removeSVG = function(){
		this.circle ? this.circle.remove() : null;
        this.frame ? this.frame.remove() : null;
        this.display ? this.display.remove() : null;
        this.door ? this.door.remove() : null;
        this.button1 ? this.button1.remove() : null;
        this.button2 ? this.button2.remove() : null;
	}

// ##########################################  Selector Interface Functions  ######################################################################

	ElevatorMaplink.prototype.setProperty = function(property,value){
        switch(property){
            case "objectName":
                this.name = value;
                this.nameLabel.updateText(this.name);
            break;
            case "objectAreaColor":
                this.setobjectAreaColor(value);
            break;
            case "objectLabelColor":
                this.setobjectLabelColor(value);
            break;
            case "objectLabelSize":
            	this.setobjectLabelSize(value);
            break;
            case "objectLabelStyle":
                this.setLabelStyle(value);
            break;
            case "objectStrokeColor":
                this.setobjectStrokeColor(value);
            break;
            case "objectFillColor":
                this.setobjectFillColor(value);
            break;
        }
    }

    ElevatorMaplink.prototype.getObjectViewerData = function(subcategory,id){
        var thisData = {};
        thisData.data = {
            vObjectName: {type:"label",value:this.name}
        }
        thisData.dividers = {
        }
        return thisData;
    }

    ElevatorMaplink.prototype.setobjectStrokeColor = function(color){
        var isOk  = /(^#[0-9A-F]{6}$)|(^#[0-9A-F]{3}$)/i.test(color)
        if(isOk){
            this.stroke = color;
        } else {
            console.log("color not recognized")
        }
        this.circle.attr("stroke",this.stroke);
        this.stairs.attr("fill",this.stroke);
        return this.stroke;
    }

    ElevatorMaplink.prototype.setobjectFillColor = function(color){
        var isOk  = /(^#[0-9A-F]{6}$)|(^#[0-9A-F]{3}$)/i.test(color)
        if(isOk){
            this.background = color;
        } else {;
            console.log("color not recognized")
        }
        this.innerCircle.attr("fill",this.background);
        return this.fill;
    }

	ElevatorMaplink.prototype.setobjectLabelColor = function(color){
    	var isOk  = /(^#[0-9A-F]{6}$)|(^#[0-9A-F]{3}$)/i.test(color)
        if(isOk){
            this.textColor = color;
            this.nameLabel.color = color;
            this.nameLabel.redraw();
        } else {
            message.errorMessage("Color not recognized");
        }

        return this.nameLabel.color;
    }