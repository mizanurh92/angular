//#################################  StairsLink Class #####################################################

function StairsMaplink(id,state,map){
    MapLink.call(this,id,state,map); // Sets StairsLink as subclass of MapLink (which is also a MapObject)
    this.name = "Stairs";  // This is the name for the specific seat, not the assigned user
    this.type = "StairsMaplink";

    this.connection = null; // This holds the data for the StairsMapLink object connected to this one, if any

    // Formatting options
    this.radius = 19;
    this.strokeWidth = 2;
    this.stroke = '#000000';
    this.background = '#ffffff';
    this.activeColor = '#ff0000';
    this.screenBackground = '#ffffff';
    this.textColor = '#000000';
    this.fontSize = 10;
    this.labelStyle = 2; // 0 is never show, 1 is show on select, 2 is always show

	this.points = [];

    this.innerCircle = null;
    this.circle = null;
    this.arc = null;

	this.prefix = 'ML';
	this.packageParameters = [ // Used in undo/redo/duplicate/save/load methods
        "type",
        "id",
        "name",
        "connection",
        "stroke",
        "background",
        "textColor",
        "fontSize",
        "labelStyle"
    ];
    this.dataPackageParameters = [ // Used in database creation
        "id",
        "name",
        "type",
        "connection"
    ];
}
	StairsMaplink.prototype = Object.create(MapLink.prototype); // Links the prototype to the superclass
	StairsMaplink.prototype.constructor = StairsMaplink;
	
// ##########################################  Object SVG Functions  ##################################################################

	StairsMaplink.prototype.createSVG = function(){
        var center = this.getCenter();

        var circle = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
        circle.setAttribute('id',"b"+this.id);
        circle.setAttribute('class',"Maplink Stairs");
        circle.setAttribute('cx',center.x);
        circle.setAttribute('cy',center.y);
        circle.setAttribute('r',this.radius);
        circle.setAttribute('pointer-events',"all");
        circle.setAttribute('fill',"white");
        $('#labelGroup').append(circle);
        this.innerCircle = $("#b" + this.id);

        var stairsObj = this.getArcPath(230,20,center);
        var stairs = document.createElementNS('http://www.w3.org/2000/svg', 'path');
        stairs.setAttribute('id',"c"+this.id);
        stairs.setAttribute('class',"Maplink Stairs");
        stairs.setAttribute('d',this.getStairPath(stairsObj.start,stairsObj.end));
        stairs.setAttribute('pointer-events',"all");
        stairs.setAttribute('fill',this.stroke);
        $('#labelGroup').append(stairs);
        this.stairs = $("#c" + this.id); 

        var circle = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
        circle.setAttribute('id',"a"+this.id);
        circle.setAttribute('class',"Maplink Stairs");
        circle.setAttribute('cx',center.x);
        circle.setAttribute('cy',center.y);
        circle.setAttribute('r',this.radius);
        circle.setAttribute('pointer-events',"all");
        circle.setAttribute('fill',"none");
        circle.setAttribute('stroke',this.stroke);
        circle.setAttribute('stroke-linecap','square');
        circle.setAttribute('stroke-width',this.strokeWidth);
        $('#labelGroup').append(circle);
        this.circle = $("#a" + this.id);

	}

    StairsMaplink.prototype.getArcPath = function(startAngle,endAngle,center){ // 0 deg starts at X-axis from center point
        var center = center || this.getCenter();
        var radius = this.radius;
        var start = polarToCartesian(center.x, center.y, radius, endAngle);
        var end = polarToCartesian(center.x, center.y, radius, startAngle);
        var largeArcFlag = endAngle - startAngle <= 180 ? "0" : "1";
        var d = [
            "M", start.x, start.y, 
            "A", radius, radius, 0, largeArcFlag, 1, end.x, end.y
        ].join(" ");
        return {d:d, start:start, end:end}     
    }

    StairsMaplink.prototype.getStairPath = function(end,start){
        var height = end.y - start.y; // should be negative
        var width = end.x - start.x;
        var staircount = 4;
        var stairHeight = height/staircount;
        var stairWidth = width/staircount;
        var stairPath = ""
        stairPath += "M " + start.x + " " + start.y; // Start point at upper left
        for(var i = 0; i < staircount; i++){
            stairPath += "L " + (i * stairWidth + start.x) + " " + ((i + 1) * stairHeight + start.y);
            stairPath += "L " + ((i + 1) * stairWidth + start.x) + " " + ((i + 1) * stairHeight + start.y);         
        }
        stairPath += this.getArcPath(230,20).d;
        return stairPath += "Z" // Return and close of position
    }

	StairsMaplink.prototype.updateSVG = function(){
        var center = this.getCenter();
        var stairs = this.getArcPath(230,20,center);
		this.circle ? this.circle.attr({cx:center.x,cy:center.y}) : null;
        this.innerCircle ? this.innerCircle.attr({cx:center.x,cy:center.y}) : null;
        this.stairs ? this.stairs.attr({d:this.getStairPath(stairs.start,stairs.end)}) : null;
	}

	StairsMaplink.prototype.removeSVG = function(){
		this.circle ? this.circle.remove() : null;
        this.innerCircle ? this.innerCircle.remove() : null;
        this.stairs ? this.stairs.remove() : null;
	}

// ##########################################  Selector Interface Functions  ######################################################################

	StairsMaplink.prototype.setProperty = function(property,value){
        switch(property){
            case "objectName":
                this.name = value;
                this.nameLabel.updateText(this.name);
            break;
            case "objectAreaColor":
                this.setobjectAreaColor(value);
            break;
            case "objectLabelColor":
                this.setobjectLabelColor(value);
            break;
            case "objectLabelSize":
            	this.setobjectLabelSize(value);
            break;
            case "objectLabelStyle":
                this.setLabelStyle(value);
            break;
            case "objectStrokeColor":
                this.setobjectStrokeColor(value);
            break;
            case "objectFillColor":
                this.setobjectFillColor(value);
            break;
        }
    }

    StairsMaplink.prototype.getObjectViewerData = function(subcategory,id){
        var thisData = {};
        thisData.data = {
            vObjectName: {type:"label",value:this.name}
        }
        thisData.dividers = {
        }
        return thisData;
    }

    StairsMaplink.prototype.setobjectStrokeColor = function(color){
        var isOk  = /(^#[0-9A-F]{6}$)|(^#[0-9A-F]{3}$)/i.test(color)
        if(isOk){
            this.stroke = color;
        } else {
            console.log("color not recognized")
        }
        this.circle.attr("stroke",this.stroke);
        this.stairs.attr("fill",this.stroke);
        return this.stroke;
    }

    StairsMaplink.prototype.setobjectFillColor = function(color){
        var isOk  = /(^#[0-9A-F]{6}$)|(^#[0-9A-F]{3}$)/i.test(color)
        if(isOk){
            this.background = color;
        } else {;
            console.log("color not recognized")
        }
        this.innerCircle.attr("fill",this.background);
        return this.fill;
    }

	StairsMaplink.prototype.setobjectLabelColor = function(color){
    	var isOk  = /(^#[0-9A-F]{6}$)|(^#[0-9A-F]{3}$)/i.test(color)
        if(isOk){
            this.textColor = color;
            this.nameLabel.color = color;
            this.nameLabel.redraw();
        } else {
            message.errorMessage("Color not recognized");
        }

        return this.nameLabel.color;
    }