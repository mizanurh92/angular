function point(x,y,id){  // A point is an object that allows for a consistent interface for elements and object which rely upon a specific coordinate
	// model.
	this.id = id; // This is the id of the point which is used to route any event relating to the point back to the point and its object
	this.x = x;  // This is the x coordinate of the point with respect to the svg coordinate system
	this.y = y; // This is the y coordinate of the point with respect to the svg coordinate system
	this.dragReference = {};  // This holds the initial point coordinates for use in drag events
	this.dragAngle = 0;  // This holds the initial angle (in radians) relative to a center point for use in rotation events
    this.stroke = "#e54949"; // Outline color of the point handle
    this.fill = "#e54949"; // Normal fill color of the point handle
    this.drawn = false; // Whether the point handle is currently drawn on the screen
    this.currentFile = $Map.current(); // Gets a reference to the parent instance controller
    this.obj = null;
}

// ##########################################  Point Handle Functions  ##################################################################
	
	point.prototype.drawHandle = function(optObj){ // Creates the svg element for the point handle if none exists
    	var options = optObj || {};
    	var stealth = options.stealth || false;
    	// If stealth is true, the handle wont accept pointHandle class mouse events
        if(!this.drawn){
        	var pointSize,strokeWidth;
        	pointSize = 5/this.currentFile.map.scale + this.currentFile.map.scale/20;
        	strokeWidth = 1/this.currentFile.map.scale;

			var handle = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
	        handle.setAttribute('cx',this.x);
	        handle.setAttribute('cy',this.y);
	        handle.setAttribute('r',pointSize);
	        handle.setAttribute('id',this.id);
	        handle.setAttribute('class',stealth ? "":'pointHandle')
	        handle.setAttribute('fill',this.fill);
	        handle.setAttribute('stroke',this.stroke);
	        handle.setAttribute('stroke-width',strokeWidth);
	        handle.setAttribute('fill-opacity',0.35);
	        $("#topGroup").append(handle);
	        this.drawn = true;
	        this.obj = $("#"+this.id);
		}
    }

    point.prototype.isActive = function(){
    	return this.drawn;
    }

	point.prototype.removeHandle = function(){  // Removes the svg element for the point handle if it exists
        if(this.drawn){
			this.obj.remove();
        	this.drawn = false;
        }
    }

	point.prototype.select = function(){ // Selects the current handle (changes its fill color) and returns a point object
		this.obj.attr("fill","blue");
		return this.getPoint();
	}

	point.prototype.deselect = function(){ // Deselects the current handle, changing its fill color back to its default
    	this.obj.attr("fill",this.fill);
	}

	point.prototype.updateHandle = function(){ // Updates the svg component of the point if the point has been drawn
		// Sets the location to the position for the point
		if(this.drawn){ // only updates if the handle is active
	        this.obj.attr("cx",this.x);
	        this.obj.attr("cy",this.y);
		}
	}

// ##########################################  Point Movement Functions  ##################################################################

	point.prototype.getPoint = function(){ // Returns a basic point object {x:,y:} for the location of this point
		return {x:this.x,y:this.y};
	}

	point.prototype.getSavePoint = function(){ // Returns a basic point object {x:,y:} for the location of this point, plus the point id
		return {x:this.x,y:this.y,id:this.id};
	}

	point.prototype.updatePosition = function(x,y){  // Changes the point's position to that of a new set of specified coordinates
		if(x && x.x){ // handles when the coordinates are passed as an object rather than two seperate coordinates
			this.x = x.x;
			this.y = x.y;
		} else {
			this.x = x;
			this.y = y;			
		}
		this.updateHandle();
	}

	point.prototype.shiftPosition = function(x,y){  // Moves the point in the x or y direction a specified amount
		this.x += x;
		this.y += y;
		this.updateHandle();
	}

	point.prototype.setDragReference = function(){ // Saves the current coordinates for use in a drag operation
		this.dragReference = {x:this.x,y:this.y};
		return this.dragReference;
	}

	point.prototype.dragOffset = function(x,y,optObj){  // Moves the current point by amounts in the x and y direction
		// setDragReference must have been called before this function can be used as x and y values will be added relative
		// to those values recorded in the dragReference property.  The optional snapround parameter allows for override of the snap
		// to grid resolution
		var options = optObj || {};
		var snapToGrid = options.snapToGrid || false;
		var gridResolution = options.gridResolution || 12; // Defaults to 1 foot
		if(!snapToGrid){
			this.x = this.dragReference.x + x;
			this.y = this.dragReference.y + y;
		} else {
			this.x = snapround(this.dragReference.x + x,gridResolution);
			this.y = snapround(this.dragReference.y + y,gridResolution);
		}

		this.updateHandle();
		return({x:this.x-this.dragReference.x,y:this.y-this.dragReference.y}) // returns a point object of the total dist. dragged
	}

	point.prototype.cancelDrag = function(){ // If a drag event is canceled, it returns the point to where it was before the drag
		this.x = this.dragReference.x;
		this.y = this.dragReference.y;
		this.updateHandle();
	}

	point.prototype.setRotateAngle = function(centerX,centerY,angle){  // This finds and sets the initial angle of the point relative to a center point and saves it
		// This is used in rotation operations and must be set before the point can be rotated around an arbitrary center point.
		var initialX = this.x - centerX;
		var initialY = centerY - this.y;
		this.dragAngle = Math.atan2(initialY,initialX) - angle;
	}

	point.prototype.rotateAroundCenter = function(centerX,centerY,angle){ // Rotates the point around an arbitrary center point by an amount specified in radians
		// Note that setRotateAngle must have been called before the rotation operation so that the rotation can occur relative to the current position
		var initialX = this.x - centerX;
		var initialY = this.y - centerY;
		var distance = Math.sqrt(Math.pow(initialX,2)+Math.pow(initialY,2));
		
		var newAngle = this.dragAngle + angle;
		var newXComponent = distance * Math.cos(newAngle);
		var newYComponent = distance * Math.sin(newAngle);
		this.updatePosition(centerX + newXComponent,centerY - newYComponent);
	}