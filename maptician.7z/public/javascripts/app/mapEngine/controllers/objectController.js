//#################################  Object Controller #####################################################
// Should be Superclass for all map object controllers (architecture/zones/rooms/cubicles/furniture/...)

function ObjectController(){
	this.objects = {};
	this.selected = [];
	this.currentlyDrawing = "";
	this.handleSelected = {};
	this.multiSelected = false;
	this.layerVisible = true;
}

// This is used to get arrays of x and y values of every point to determine the bounding box for the entire used map
ObjectController.prototype.getBorderBox = function(){
	var objBox;
	var xArray = [];
	var yArray = [];
	for(var obj in this.objects){
		objBox = this.objects[obj].getBorderBox();
		xArray = xArray.concat(objBox.xArray);
		yArray = yArray.concat(objBox.yArray);
	}
	return {xArray:xArray,yArray:yArray};
}

ObjectController.prototype.moveAll = function(shiftLeft,shiftUp){
	var keys = Object.keys(this.objects);
	var len = keys.length;
	var key,current;
	for(var i = 0;i < len;i++){
		try{
			key = keys[i];
			current = this.objects[key];
			current.shiftPosition(shiftLeft,shiftUp);                
		} catch(err){
			console.log(err);
		}
	}
}

// This function takes a controllers object (object containing controllers) and loops through it
// Each controller provides an array of snap point objects and that array is concatenated into a
// global snap object array which is used during the snap process
ObjectController.prototype.getSnapObjects = function(controllers,optObj){
    var options = optObj || {};
    var filterID = options.filterID || null;
    keys = Object.keys(controllers);
    len = keys.length;
    var results = [];
    for(var i = 0; i < len;i++){
        try{
            results = results.concat(controllers[keys[i]].getSnapPoints(filterID));
        } catch(err){
            console.log(err);
        }
    }
    return results;        
}

// This function returns an array of snap point objects for each object in a controller
// There is an optional filterID which prevents an object from snapping to itself
ObjectController.prototype.getSnapPoints = function(filterID){
    var keys = Object.keys(this.objects);
    var len = keys.length;
    var results = [];
    for(var i = 0;i < len;i++){
        var key = keys[i]
        var current = this.objects[key];
        try{
        	if(key != filterID){
        		results.push(current.getSnapPoints());
        	}
        } catch(err){
            console.log(err);
        }
    }
    return results;
}


ObjectController.prototype.removeLayer = function(){ // Hides all screen elements controlled by the  controller, but maintains the underlying data
    if(this.layerVisible == false){
        return;
    }
    for (var i in this.objects){
        try{
            this.objects[i].remove(); // Removes all screen object elements (should be all the svg objects)
        }
        catch(err){
            console.log(err);
        }
    }
    this.layerVisible = false;
}

ObjectController.prototype.redrawLayer = function(){  // Redraws all screen elements if they were removed by the removeLayer function
    if(this.layerVisible){
        return;
    }
    for (var i in this.objects){
        try{
            this.objects[i].redraw(); // Redraws all screen object elements (should be all the svg objects)
        }
        catch(err){
            console.log(err)
        }
    }
    this.layerVisible = true;
}

ObjectController.prototype.getViewerProperties = function(id,subcategory){
    try{
        if(subcategory!=undefined){
            var objID = id.slice(3);
        } else {
            var objID = id;
        }
        console.log("Controller subcategory",subcategory);
        return this.objects[objID].getObjectViewerData(subcategory,id);
    } catch(err){
        console.log(err);
        return {data:"",dividers:""}; // Gives a blank selector on error
    }
}