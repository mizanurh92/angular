//#################################  Furniture Controller #####################################################

function FurnitureController(state,map){
    ObjectController.call(this); // Furniture SeatController as subclass of ObjectController
    // this.objects = {};
    // this.selected = [];
    // this.currentlyDrawing = "";
    // this.handleSelected = {};
    // this.multiSelected = false;
    // this.layerVisible = true;
    this.state = state;
    this.map = map; 
    this.activeSubclass = "";
    this.prefix = "FN";

    //#################################  Object Selection and Activation #####################################################

    this.getOutlinePoints = function(filterArray){ // Returns a set of bounding boxes for all objects
        var pointObject = {};
        for (var item in this.objects){
            try{
                if ( $.inArray( this.objects[item].type, filterArray ) > -1 ){ // Checks to see if the object type is on the filter-for list
                    pointObject[item] = this.objects[item].getOutlinePoints();
                }
            }
            catch(err){
                console.log("Unable to get bounding box for a furniture object");
                console.log(err)
            }
        }
        return pointObject; // object with keys equaling the relevant object id's and contents of their bounding boxes
    }

    this.getBoundingPoints = function(){
        var boundingPoints = [];
        var objKeys = Object.keys(this.objects);
        var objCount = objKeys.length;
        for(var i = 0;i < objCount;i++){
            boundingPoints.push(this.objects[objKeys[i]].getBoundingPoints());
        }
        return boundingPoints;
    }

    this.selectOne = function(id,subclass){  // Selects and activates a single object in the architecture controller, any existing active are deactivated
        this.multiSelected = false;
        this.deselectAll();
        if(subclass == undefined){
            this.selected.push(id); // Adds the current object to the selected array
            this.objects[id].activate(this.multiSelected); // Activates the object with the stated id with multi-select false 
        } else {
            this.activeSubclass = id;
            this.objects[this.activeSubclass.slice(6)].activate(false,this.activeSubclass);
        }
    }

    this.selectMultiple = function(id){  // Selects and activates multiple architectural objects
        // This will not allow the selection of multiple child objects
        if(this.activeSubclass != ""){ // Deactivates any active subclass object
            this.objects[this.activeSubclass.slice(6)].deactivate(this.activeSubclass);
            this.activeSubclass = "";
        }
        if(this.selected.length > 0 && this.multiSelected == false){  // removes handles if a single select happened first
            this.objects[this.selected[0]].deactivate();
            this.objects[this.selected[0]].activate(true); // basically reactivates in multi-select mode
        }
        if(this.selected.indexOf(id) == -1){ // True if the currently selected item is not already in the selected object array
            this.selected.push(id); // Adds the new selected object to the selected array
            this.multiSelected = true; // True even if there is only a single selection, so long as it occured in multi-select mode
            this.objects[id].activate(this.multiSelected);
        } else { // If the selected object has already been selected, this will deselect it (i.e. if it was selected accidentally)
            this.selected.splice(this.selected.indexOf(id),1); // removes from the selected array
            this.objects[id].deactivate();
        }
    }

    this.objectsAreSelected = function(){  // Returns whether any objects are selected
        return this.selected.length > 0 || this.activeSubclass;
    }

    this.deselectAll = function(){  // Cancels any in-progress creations and deselects all objects
        this.cancelDraw(); // Cancels any drawings in progress
        if(this.activeSubclass != ""){ // Deactivates any active subclass object
            this.objects[this.activeSubclass.slice(6)].deactivate(this.activeSubclass);
            this.activeSubclass = "";
        }
        var len = this.selected.length;
        var objID;
        for (var i = 0; i < len; i++){
            objID = this.selected[i];
            try{
                this.objects[objID].deactivate();
            }
            catch(err){
                console.log("Unable to find object to deactivate");
            }
        } // Deactivates all currently active objects
        this.selected = []; // Clears the selected list
        this.multiSelected = false; // Clears the multi-select flag
    }

    //#################################  Object Creation Functions #####################################################

    this.create = function(classType,controllers){
        var id = generateUUID();
        this.deselectAll();
        this.currentlyDrawing = id;
        this.objects[id] = eval("new "+classType+"(id,this.state,this.map)"); // creates the object in the object collection
        if(classType == "Cubicle"){
            this.objects[id].create({snapPoints:this.getCubicleSnapObjects(controllers)}); // populates the object with initial values
        } else {
            this.objects[id].create({snapPoints:this.getSnapObjects(controllers,{filterID:id})}); // populates the object with initial values
        }
        console.log(classType,"created")
    }

    this.addSubObject = function(type,parent){
        if(parent == "Cubicle" && this.selected[0] && this.objects[this.selected[0]].type == "Cubicle"){
            if(this.selected.length == 1){
                this.objects[this.selected[0]].addSubObject(type);
            }            
        }
    }

    this.dragNew = function(subobject){
        if(subobject){
            if(this.selected[0]){
                this.objects[this.selected[0]].dragPlace(subobject);
            }
        } else{
            this.objects[this.currentlyDrawing].dragPlace();
        }
    }

    this.finalizePlace = function(subobject){
        if(subobject){
            if(this.selected[0]){
                this.objects[this.selected[0]].finalizeDragPlace(subobject);
            }
        } else{
            this.objects[this.currentlyDrawing].finalizeDragPlace(subobject);
            this.state.addUndoPackage(this.createUndoCreatePackage(this.currentlyDrawing));
            this.state.addRedoPackage(this.createRedoCreatePackage(this.currentlyDrawing));
            this.currentlyDrawing = "";  
        }
        
    }

    this.cancelDraw = function(){  // Cancels the object currently being drawn/draggedNew and removes it completely
        if(this.state.state == "placeFurnitureSubobject"){ // Cancels any subobject drawings in progress
            console.log("Canceling furniture subobject draw event");
            this.objects[this.activeSubclass.slice(3)].cancelSubDraw();
            this.activeSubclass = "";
        } 
        if(this.currentlyDrawing){
            console.log("Canceling furniture draw event");
            try{
                this.objects[this.currentlyDrawing].cancelDraw();
                delete this.objects[this.currentlyDrawing];
                this.currentlyDrawing = "";
            } catch(err){
                console.log("err");
            }
        }
    }

    this.duplicate = function(){
        var len = this.selected.length
        var newSelected = [];
        for(var i = 0;i<len;i++){ // Duplicates all items in the selected array
            var id = generateUUID();
            this.objects[id] = eval("new "+this.objects[this.selected[i]].type+"(id,this.state,this.map)"); // creates the object in the object collection
            this.objects[id].duplicate(this.objects[this.selected[i]]);
            newSelected.push(id);
        }
        this.deselectAll();
        for(var i = 0;i < newSelected.length;i++){
            this.selectMultiple(id);
        }
    }

    //#############################################  Data Functions #####################################################

    this.pushData = function(id,data){
        if(this.objects[id]){
            this.objects[id].getData(data);
        }
    }

    //#################################  Object Undo/Redo Functions #####################################################

    this.loadPackage = function(package){
        switch(package.packageType){
            case "modify":
                this.objects[package.id].loadPackage(package);
            break;
            case "redo create":
            case "undo delete":
                this.objects[package.id] = package.object;
                this.objects[package.id].redraw();
            break;
            case "undo create":
            case "redo delete":
                this.objects[package.id].remove();
                this.selected = [];
                delete this.objects[package.id];
            break;
            case "undo create CubicleEntrance":
            case "redo delete CubicleEntrance":
            case "undo delete CubicleEntrance":
            case "redo create CubicleEntrance":
            case "modify CubicleEntrance":            
                this.objects[package.parent].loadPackage(package);
            break;
        } 
    }

    this.createUndoDeletePackage = function(id){
        var package = {};
        package.packageType = "undo delete";
        package.controller = "furniture";
        package.id = id;
        package.object = this.objects[id];
        return package;
    }

    this.createRedoCreatePackage = function(id){
        var package = {};
        package.packageType = "redo create";
        package.controller = "furniture";
        package.id = id;
        package.object = this.objects[id];
        return package;
    }

    this.createRedoDeletePackage = function(id){
        var package = {};
        package.packageType = "redo delete";
        package.controller = "furniture";
        package.id = id;
        return package;
    }

    this.createUndoCreatePackage = function(id){
        var package = {};
        package.packageType = "undo create";
        package.controller = "furniture";
        package.id = id;
        return package;       
    }

    //#################################  Object Deletion and Hiding Functions #####################################################

    this.deleteSelected = function(){  // Removes the currently selected object(s), including their svgs and data
        if(this.activeSubclass != ""){ // Deletes any active subclass object
            this.objects[this.activeSubclass.slice(6)].remove(this.activeSubclass);
        } else{
            var len = this.selected.length;
            var objID;
            for (var i = 0; i < len; i++){
                objID = this.selected[i];
                this.objects[objID].remove(); // Removes all currently active object elements
                this.state.addUndoPackage(this.createUndoDeletePackage(objID));
                this.state.addRedoPackage(this.createRedoDeletePackage(objID));
                delete this.objects[objID]; // Deletes the object references in the objects collection
            }
        }
        this.selected = []; // Clears the selected list
        this.activeSubclass = "";    
    }

    this.removeAll = function(){ // Removes all objects from the architecture controller, both data and SVG
        this.deselectAll();
        // WARNING this cannot be undone (should only be used for a load event or where an empty object is needed)
        for (var i in this.objects){
            this.objects[i].remove(); // Removes all object SVG elements
            delete this.objects[i]; // Deletes the object references in the collection
        }
    }

    //#################################  Point Handle Manipulation Functions #####################################################

    this.handlePress = function(handleID,objID){ // General handle press function, applies to any objects with handle objects attached
        this.handleSelected.handleId = handleID;
        this.handleSelected.id = objID;
        try{
            if(objID.length>36){
                var suffix = objID.length-36;
                this.handleSelected.id = objID.slice(0,-suffix);
            }
            this.objects[this.handleSelected.id].handlePress(handleID);
        } catch(err){
            console.log("Cannot find object associated with the point handle.");
            console.log(err)
        }
    }

    this.handleDrag = function(){ // General handle drag function, applies to any objects with handle objects attached
        if(this.handleSelected && this.handleSelected.id){
            try{
                this.objects[this.handleSelected.id].handleDrag(this.handleSelected.handleId);
            } catch (err){
                console.log(err);
            }
        }
    }

    this.finalizeHandleDrag = function(){
        if(this.handleSelected && this.handleSelected.id){
            try{
                this.objects[this.handleSelected.id].finalizeHandleDrag();
            }
            catch(err){
                console.log(err);
            }
        }
    }

    this.handleSelect = function(){
        // Empty on purpose, will likely use for handle-based image manipulations
    }

    //########################################  Object Drag and Move Functions ############################################################

    this.startDrag = function(controllers){  // Sets the move origins for all active objects
        // triggered on click event for SVG
        var objID;
        var currentObj;
        if(this.activeSubclass){
            objID = this.activeSubclass.slice(6);
            this.objects[objID].startDrag({subclass:this.activeSubclass});
        } else{
            var len = this.selected.length;
            for (var i = 0; i < len; i++){
                objID = this.selected[i];
                currentObj = this.objects[objID];
                try{
                    if(currentObj.type == "Cubicle"){
                        currentObj.startDrag({snapPoints:this.getCubicleSnapObjects(controllers)});
                    } else {
                        currentObj.startDrag({snapPoints:this.getSnapObjects(controllers,{filterID:objID})});
                    }
                }
                catch(err){
                    console.log("Object not found.");
                    console.log(err);
                }
            }            
        }
    }

    this.dragActive = function(){  // Drag moves all active objects
        var objID;
        var currentObj;
        if(this.activeSubclass){
            objID = this.activeSubclass.slice(6);
            this.objects[objID].drag(this.activeSubclass);
        } else{
            var len = this.selected.length;
            for (var i = 0; i < len; i++){
                objID = this.selected[i];
                currentObj = this.objects[objID];
                try{
                    currentObj.drag();
                }
                catch(err){
                    console.log("Cannot drag object.");
                    console.log(err);                
                }
            }
        }
    }

    this.getCubicleSnapObjects = function(controllersArg){
        var controllers = controllersArg || {};
        var keys = Object.keys(this.objects);
        var len = keys.length;
        var current;
        var cubicleResults = [];
        var controllerResults = [];
        for(var i = 0;i < len;i++){
            current = this.objects[keys[i]];
            if(current.type != "Cubicle" || keys[i] == this.selected[0] || keys[i] == this.currentlyDrawing){continue;}
            cubicleResults.push(current.getCubicleSnapPoints());
        }
        keys = Object.keys(controllers);
        len = keys.length;
        for(var i = 0; i < len;i++){
            try{
                controllerResults = controllerResults.concat(controllers[keys[i]].getSnapPoints(this.currentlyDrawing || this.selected[0],"Cubicle"));
            } catch(err){
                console.log(err);
            }
        }
        return {cubicles:cubicleResults,other:controllerResults};
    }

    this.getSnapPoints = function(filterID,objectToSnap){
        var results = [];
        for(var item in this.objects){
            try{
                if(item != filterID){
                    switch(objectToSnap){
                        case "Cubicle":
                            if(this.objects[item].type != "Cubicle"){
                                results.push(this.objects[item].getSnapPoints());
                            }
                        break;
                        default:
                            results.push(this.objects[item].getSnapPoints());
                        break;
                    }
                }
            } catch(err){
                console.log(err);
            }
        }
        return results;
    }

    this.finalizeDrag = function(){
        var objID;
        if(this.activeSubclass){
            objID = this.activeSubclass.slice(6);
            this.objects[objID].finalizeDrag(this.activeSubclass);
        } else{
            var len = this.selected.length;
            for (var i = 0; i < len; i++){
                objID = this.selected[i];
                try{
                    this.objects[objID].finalizeDrag();
                }
                catch(err){
                    console.log("Cannot finalize drag object.  Object not found.");
                    console.log(err);                
                }
            }
        }
    }

    this.moveActive = function(direction){  // Accepts changes in x and y values and moves all active objects by those amounts
        var objID;
        if(this.activeSubclass){
            objID = this.activeSubclass.slice(6);
            this.objects[objID].move(direction,this.activeSubclass);
        } else{
            var len = this.selected.length;
            for (var i = 0; i < len; i++){
                objID = this.selected[i];
                try{
                    this.objects[objID].move(direction);
                }
                catch(err){
                    console.log("Cannot find object to move");
                    console.log(err);
                }
            }  
        }              
    }

    //########################################  Save / Load Functions ############################################################

    this.save = function(){
        this.saveFile = {};
        this.saveFile.objects = [];
        for(var i in this.objects){
            this.saveFile.objects.push(this.objects[i].save());
        }
        return this.saveFile;
    }

    this.load = function(file){
        this.deselectAll();
        this.removeAll();
        var len = file.objects.length;
        var object;
        for( var i = 0 ; i < len ; i++ ){
            object = file.objects[i];
            this.objects[object.id] = eval("new "+object.type+"(object.id,this.state,this.map)"); // creates the object in the object collection
            this.objects[object.id].load(object);
        }
    }

    //########################################  Object Property Functions ############################################################

    this.getProperties = function(id,subcategory){
        try{
            if(subcategory){
                var objID = id.slice(6);
            } else {
                var objID = id;
            }
            return this.objects[objID].getProperties(subcategory,id);
        } catch(err){
            console.log(err);
            return {data:"",dividers:""}; // Gives a blank selector on error
        }
    }

    this.setProperty = function(id,property,value,subcategory){
        try{
            if(subcategory!=undefined){
                var objID = id.slice(6);
            } else {
                var objID = id;
            }
            return this.objects[objID].setProperty(property,value,subcategory,id);
        }
        catch(err){
            console.log("Error in setting property");
            console.log(err);
        }
    }

}

FurnitureController.prototype = Object.create(ObjectController.prototype); // Links the prototype to the superclass
FurnitureController.prototype.constructor = FurnitureController;