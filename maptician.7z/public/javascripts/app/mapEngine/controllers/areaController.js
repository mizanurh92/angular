//#################################  Area Controller #####################################################

function AreaController(prefix,objName){
	ObjectController.call(this); // Sets AreaController as subclass of ObjectController	
	// this.objects = {};
	// this.selected = [];
	// this.currentlyDrawing = "";
	// this.handleSelected = {};
	// this.multiSelected = false;
	// this.layerVisible = true;

	// The following two items are an array of colors and a counter used to automatically change default zone colors as more are created
	this.colorArray = ['#a6cee3','#1f78b4','#b2df8a','#33a02c','#fb9a99','#e31a1c','#fdbf6f','#ff7f00','#cab2d6'];
	this.colorCounter = 0;
	this.objectCounter = 0; // Counter for the auto-numbering of zone names
	this.prefix = prefix;
	this.objName = objName;
    this.areaPoint;
	this.selectedHandles = [];
	this.saveParameters = [
        "colorCounter",
        "objectCounter",
        "prefix",
        "objName"
        ];

	//#################################  Object Selection and Activation #####################################################

    this.createAreaPoint = function(){
        var coords = this.map.pointerCoords();
        var id = generateUUID();
        this.areaPoint = new point(coords.x,coords.y,id);
        this.areaPoint.drawHandle({stealth:true});
    }

    this.dragAreaPoint = function(){
        var coords = this.map.pointerCoords();
        this.areaPoint.updatePosition(coords.x,coords.y);
    }

    this.destroyAreaPoint = function(){
        this.areaPoint.removeHandle();
        this.areaPoint = {};
        return this.map.pointerCoords();
    }

    this.createAutoArea = function(start,outlines){
        var cornerPoints = [];
        var startingCorner;
        var currentSegment,currentID,currentPoint,prevID,prevSeg,result;
        
        result = closestSegment(start,outlines); // Finds the first point closest to the nearest architecture line segment
        currentSegment = result.segment;
        currentID = result.objID;
        currentPoint = result.point;
        //new point(currentPoint.x,currentPoint.y,'point1').drawHandle({stealth:true});

        result = closestIntersectingSegment(currentPoint,currentSegment,currentID,outlines,cornerPoints); // Finds the closest intersection from point2
        prevSeg = currentSegment; // The line segment active in the last cycle
        currentSegment = result.segment;
        prevID = currentID; // The architecture object active in the last cycle
        currentID = result.objID;
        currentPoint = result.point;
        //new point(currentPoint.x,currentPoint.y,'point1').drawHandle({stealth:true});
        startingCorner = {x:currentPoint.x,y:currentPoint.y};
        cornerPoints.push({x:currentPoint.x,y:currentPoint.y});

        for(var i = 0;i < 1000;i++){
            if(currentID == prevID){
                result = closestIntersectingSegment(currentPoint,currentSegment,currentID,outlines,cornerPoints);
            } else {
                result = closestIntersectingSegmentWithoutRecross(currentPoint,currentSegment,currentID,prevSeg,prevID,outlines,cornerPoints);
            }
            if(result.point == null){
                break;
            }
            prevSeg = currentSegment;
            currentSegment = result.segment;
            prevID = currentID;
            currentID = result.objID;
            currentPoint = result.point;
            //new point(currentPoint.x,currentPoint.y,'point1').drawHandle({stealth:true});
            cornerPoints.push({x:currentPoint.x,y:currentPoint.y});            
        }
        this.createWallArea(cornerPoints);
    }

    this.createWallArea = function(pointList){
        var id = generateUUID();
        var color = this.colorArray[this.colorCounter%(this.colorArray.length)]; // loops through the color array based on the mod of the counter
        this.objects[id] = eval("new "+this.objName+"(id,color,this.state,this.map)"); // creates the object in the object collection
        this.colorCounter++;
        this.objectCounter++;
        var areaName;
        if (areaName == undefined){areaName = this.objName + " " + this.objectCounter;}
        this.objects[id].name = areaName;
        this.objects[id].create("Wall Area",pointList);
    }

	this.getPointsLists = function(){
        var pointList = {};
        for(var i in this.objects){
            pointList[i] = this.objects[i].getPointList();
        }
        return pointList;
    }

    this.getOutlinePoints = function(){
        var pointObject = {};
        for (var item in this.objects){
            try{
                pointObject[item] = this.objects[item].getOutlinePoints();
            }
            catch(err){
                console.log("Unable to get bounding box for an area object");
                console.log(err)
            }
        }
        return pointObject;
	}

	this.selectOne = function(id){
        var program = this.program || "Editor";
        this.multiSelected = false;
        this.deselectAll();
        this.selected.push(id); // Adds the current object to the selected array
        console.log(id,this.objects)
        this.objects[id].activate({multiSelect:this.multiSelected,program:program});
    }

    this.selectMultiple = function(id){  // Selects and activates multiple objects
        if(this.selected.length > 0 && this.multiSelected == false){  // removes handles if a single select happened first
            this.objects[this.selected[0]].deactivate(); // basically reactivates in multi-select mode
            this.objects[this.selected[0]].activate(true); // basically reactivates in multi-select mode
        }
        if(this.selected.indexOf(id) == -1){ // True if the currently selected item is not already in the selected object array
            this.selected.push(id); // Adds the new selected object to the selected associative array
            this.multiSelected = true; // This will become true even if there is only a single selection so long as it occured in multi-select mode
            this.objects[id].activate(this.multiSelected);
        } else { // If the selected object has already been selected, this will deselect it (i.e. if it was selected accidentally)
            this.selected.splice(this.selected.indexOf(id),1);
            this.objects[id].deactivate();
        }
    }

    this.getSelectedData = function(){ // Returns the object data for a selected object ########################### 
        //  TODO need to figure out multi-select behavior
        if(this.selected.length>0){
            return this.objects[this.selected[0]].getObjectData();  
        } else if(this.currentlyDrawing != "") {
            return this.objects[this.currentlyDrawing].getObjectData();
        }
    }

    this.objectsAreSelected = function(){  // Returns whether any architectural objects or their children are selected
        return this.selected.length > 0;
    }

    this.deselectAll = function(){  // Cancels any in-progress creations and deselects all objects
        this.cancelDraw(); // Cancels any drawings in progress
        var length = this.selected.length;
        for (var i = 0; i < length; i++){
            var objID = this.selected[i];
            try{
                this.objects[objID].deactivate();
            }
            catch(err){
                console.log("Unable to find object to deactivate");
            }
        } // Deactivates all currently active objects
        this.selected = []; // Clears the selected list
        this.handleSelected = {};
        this.selectedHandles = [];
        this.multiSelected = false;
    }

    //#################################  Object Creation Functions #####################################################

    this.create = function(controllers){
    	this.deselectAll();
    	var id = generateUUID();
    	var color = this.colorArray[this.colorCounter%(this.colorArray.length)]; // loops through the color array based on the mod of the counter
    	this.objects[id] = eval("new "+this.objName+"(id,color,this.state,this.map)"); // creates the object in the object collection
    	this.colorCounter++;
    	this.objectCounter++;
    	this.currentlyDrawing = id;
        var snapPoints = this.getSnapObjects(controllers,{filterID:id});
    	if(this.state.state == "draw"+this.objName){
    		console.log('correct creation path')
            this.objects[id].create("Path",null,snapPoints);
    	} else if (this.state.state == "draw"+this.objName+"Box"){
    		this.objects[id].create("Box",null,snapPoints);
    	}
    }

    this.drawBox = function(){
    	if(this.currentlyDrawing){
            try{
                this.objects[this.currentlyDrawing].drawBox();            
            }
            catch(err){
                console.log("Cannot find currently drawing object.");
                console.log(err);
            }
        }
    }

    this.finishDraw = function(dataConnection,objectSelector){  // Routed event handler which passes a finalize draw command to the object currently being drawn
        if(this.currentlyDrawing != ""){
            if(this.objects[this.currentlyDrawing].calculateArea == 0){
                this.cancelDraw(); // If the total area is zero, then the area object wasn't created properly
            } else {
                this.finalizeArea(dataConnection,objectSelector);
            }
        }
    } 

    this.cancelDraw = function(){
    	if(this.currentlyDrawing!=""){
            console.log("Canceling draw event");
            this.objects[this.currentlyDrawing].cancelDraw();
            delete this.objects[this.currentlyDrawing];
            this.currentlyDrawing = "";
            this.objectCounter--;
        }
    }

    this.drawAreaMapEnter = function(){
        this.objects[this.currentlyDrawing].drawAreaMapEnter();
    }

    this.drawPoint = function(){ // Adds a point to the draw zone path
    	
    	this.objects[this.currentlyDrawing].addPoint();
    }

    this.showNextPoint = function(){ // Shows the line associated with the next possible point on the draw zone path
    	
    	if(this.currentlyDrawing != ""){this.objects[this.currentlyDrawing].drawNextPoint();}
    }

    this.finalizeArea = function(dataConnection,objectSelector){
    	if(this.currentlyDrawing){
            this.selected.push(this.currentlyDrawing);
            var areaName;
            var currentlyDrawing;
            var controllerType = null;
            this.state.addUndoPackage(this.createUndoCreatePackage(this.currentlyDrawing));
            this.state.addRedoPackage(this.createRedoCreatePackage(this.currentlyDrawing));
            switch(this.objName){
                case "Room":
                    controllerType = "rooms";
                break;
                case "Zone":
                    controllerType = "zones";
                break;
            }
	    	if (areaName == null){areaName = this.objName+" "+this.objectCounter;}
	    	this.objects[this.currentlyDrawing].name = areaName;
	    	if(this.state.state == "draw"+this.objName){ // If drawing from path
		    	var success = this.objects[this.currentlyDrawing].convertPathToPolygon();
                if(success){
                    objectSelector.selectSVG(this.currentlyDrawing,controllerType,this.objName);
                } else {
                    delete this.objects[this.currentlyDrawing];
                }
		    	this.currentlyDrawing = "";
	    	} else { // If drawing from box
	    		try{
                    this.objects[this.currentlyDrawing].finalizeDrawBox();
                    objectSelector.selectSVG(this.currentlyDrawing,controllerType,this.objName);
                    this.currentlyDrawing = "";
	    		} catch(err){
	    			console.log(err);
	    		}
	    	}
            dataConnection.checkSeatsForZone();
            dataConnection.checkSeatsForRoom();
    	}
    	this.state.setState("openSelector");
    }

    this.duplicate = function(){
        for(var i = 0;i<this.selected.length;i++){
            var id = generateUUID();
            this.objects[id] = eval("new "+this.objects[this.selected[i]].type+"(id)",
                this.objects[this.selected[i]].color,this.state,this.map); // creates the object in the object collection
            this.objects[id].duplicate(this.objects[this.selected[i]]);
        }
    }

    //#################################  Object Undo/Redo Functions #####################################################

    this.loadPackage = function(package){
        switch(package.packageType){
            case "modify":
                this.objects[package.id].loadPackage(package);
            break;
            case "redo create":
            case "undo delete":
                this.objects[package.id] = package.object;
                this.objects[package.id].redraw();
            break;
            case "undo create":
            case "redo delete":
                console.log(package.id);
                console.log(this.objects);
                this.objects[package.id].remove();
                delete this.objects[package.id];
            break;
        } 
    }

    this.createUndoDeletePackage = function(id){
        var package = {};
        package.packageType = "undo delete";
        switch(this.objName){
            case "Zone":
                package.controller = 'zones';
            break;
            case "Room":
                package.controller = 'rooms';
            break;
        }
        package.id = id;
        package.object = this.objects[id];
        return package;
    }

    this.createRedoDeletePackage = function(id){
        var package = {};
        package.packageType = "redo delete";
        switch(this.objName){
            case "Zone":
                package.controller = 'zones';
            break;
            case "Room":
                package.controller = 'rooms';
            break;
        }
        package.id = id;
        return package;
    }

    this.createUndoCreatePackage = function(id){
        var package = {};
        package.packageType = "undo create";
        switch(this.objName){
            case "Zone":
                package.controller = 'zones';
            break;
            case "Room":
                package.controller = 'rooms';
            break;
        }
        package.id = id;
        return package;       
    }

    this.createRedoCreatePackage = function(id){
        var package = {};
        package.packageType = "redo create";
        switch(this.objName){
            case "Zone":
                package.controller = 'zones';
            break;
            case "Room":
                package.controller = 'rooms';
            break;
        }
        package.id = id;
        package.object = this.objects[id];
        return package;
    }

    //#################################  Object Deletion and Hiding Functions #####################################################
    
    this.deleteSelected = function(dataConnection){
    	for (var i = 0; i < this.selected.length; i++){
            var objID = this.selected[i];
            this.objects[objID].remove(); // Removes all currently active object elements
            this.state.addUndoPackage(this.createUndoDeletePackage(objID));
            this.state.addRedoPackage(this.createRedoDeletePackage(objID));
            delete this.objects[objID]; // Deletes the object references in the objects collection
            dataConnection.checkSeatsForZone();
            dataConnection.checkSeatsForRoom();
        } 
        this.selected = []; // Clears the selected list
    }

    this.removeAll = function(){ // Removes all objects from the architecture controller, both data and SVG
        for (var i in this.objects){
            this.objects[i].remove(); // Removes all object SVG elements
            delete this.objects[i]; // Deletes the object references in the collection
        }
        this.selected = []; // Clears the selected list
    }

	//#################################  Point Handle Manipulation Functions #####################################################

    this.handlePress = function(handleID,objectID,controllers){ // General handle press function, applies to any objects with handle objects attached
        console.log('area handle pressed')
        this.handleSelected.handleId = handleID;
        this.handleSelected.id = objectID;
        var snapPoints;
        try{
            snapPoints = this.getSnapObjects(controllers,{filterID:objectID});
            this.objects[objectID].handlePress(handleID,{snapPoints:snapPoints});
        } catch(err){
            console.log("Cannot find object associated with the point handle.");
            console.log(this.objects);
            console.log(objectID);
            console.log(err)
        }
    }

    this.handleDrag = function(){ // General handle drag function, applies to any objects with handle objects attached
        this.objects[this.handleSelected.id].handleDrag();
    }

    this.finalizeHandleDrag = function(dataConnection){
        console.log(this.objName,'finalize handle dragging')
        if(this.handleSelected.id != "" && this.handleSelected.id != undefined){
        	try{
        		this.objects[this.handleSelected.id].finalizeHandleDrag();
                dataConnection.checkSeatsForZone();
                dataConnection.checkSeatsForRoom();
        	}
        	catch(err){
        		console.log(err);
        	}
        }
    }

	this.handleSelect = function(handleID,objectID){
		if(handleID.slice(2,3) == "P"){ // Handle select for addition of a point only works with subcategory "P" handles
			if(this.selectedHandles.length>0){ // True if one or more handles has already been selected
				
				var alreadySelected = false;
				var alreadySelectedIndex = null;
				for(var i = 0;i < this.selectedHandles.length;i++){
					if(this.selectedHandles[i].handleID == handleID){
						alreadySelected = true;
						alreadySelectedIndex = i;
						break;
					}
				}
				console.log(alreadySelected);

				if(alreadySelected){ // True if the point is already selected - Deselects the point
					console.log("Point is already selected");
					this.objects[objectID].points[this.selectedHandles[alreadySelectedIndex].pointIndex].deselect();
					this.selectedHandles.splice(alreadySelectedIndex,1);
					console.log(alreadySelectedIndex)
					console.log(this.selectedHandles)
				} else { // Occurs if the point has not been selected already, but point selections exist
					console.log("Point is not already selected");
					console.log("Currently selected points:"+Object.keys(this.selectedHandles).length)

					if(this.selectedHandles.length > 1){ // True if there are already two or more handles selected
						console.log("deselecting 3rd handle");
						// Deactivates the first point in the list (first point selected)
						var toBeDeactivated = this.selectedHandles[0];
						this.objects[toBeDeactivated.objectID].points[toBeDeactivated.pointIndex].deselect();
						this.selectedHandles.splice(0,1);
					}

					var currentArea = this.objects[objectID];
					for(var i = 0;i < currentArea.points.length;i++){
						if(handleID == currentArea.points[i].id){
							var coordinates = currentArea.points[i].select(); // "Selects" the point and returns the position
							this.selectedHandles.push({
								handleID: handleID,
								objectID: objectID,
								pointIndex: i,
								x: coordinates.x,
								y: coordinates.y
							});
							break
						}
					}
				}

			} else { // Occurs if the selected handle is the first to be selected
				console.log("Start new point selection process");
				var currentArea = this.objects[objectID];
				for(var i = 0;i < currentArea.points.length;i++){
					if(handleID == currentArea.points[i].id){
						console.log("Found matching point");
						var coordinates = currentArea.points[i].select();
						this.selectedHandles.push({
							handleID: handleID,
							objectID: objectID,
							pointIndex: i,
							x: coordinates.x,
							y: coordinates.y
						});
						break;
					}
				}
			}
		}
	}

	this.addNewPoint = function(){ // This function enables the user to add a new point between two adjacent points in an area
		if(this.selectedHandles.length != 2){
			console.log("Incorrect number of points selected");
		} else {
			console.log("Checking for adjacency");
			var newPoint;
			var firstSelected = this.selectedHandles[0];
			var objectID = firstSelected.objectID;
			var firstSelectedIndex = firstSelected.pointIndex;
			var secondSelected = this.selectedHandles[1];
			var secondSelectedIndex = secondSelected.pointIndex;
			var totalPoints = this.objects[objectID].points.length;
			var adjacent = false;

			if ((firstSelectedIndex == 0 && secondSelectedIndex == totalPoints - 1)){
				console.log("adjacent ends")
				newPoint = totalPoints;
				adjacent = true;
				console.log("New point should be:"+newPoint);
			} else if ((secondSelectedIndex == 0 && firstSelectedIndex == totalPoints - 1)){
				console.log("adjacent ends")
				newPoint = totalPoints;
				adjacent = true;
				console.log("New point should be:"+newPoint);
			} else if ((firstSelectedIndex - secondSelectedIndex == 1) || (firstSelectedIndex - secondSelectedIndex == -1)){
				console.log("adjacent inner")
				
				if(firstSelectedIndex > secondSelectedIndex){
					newPoint = firstSelectedIndex;
				} else {
					newPoint = secondSelectedIndex;
				}
				adjacent = true;
				console.log("New point should be:"+newPoint);
			} else {
				console.log("Not adjacent");
			}

			if(adjacent == true){
				var newPointCoords = {
					x: (firstSelected.x + secondSelected.x)/2,
					y: (firstSelected.y + secondSelected.y)/2

				};
				var pointID = this.prefix + "P" + this.objects[objectID].incrementPoint()+objectID;
				var newPointObj = new point(newPointCoords.x,newPointCoords.y,pointID);
				this.objects[objectID].undoPackage = this.objects[objectID].createPackage();
				this.objects[objectID].points.splice(newPoint,0,newPointObj);
				this.objects[objectID].sendPackages();
				this.objects[objectID].deactivate();
				this.objects[objectID].activate();
				this.selectedHandles = [];
			}
		}
	}

	//########################################  Object Drag and Move Functions ############################################################

    this.startDrag = function(){
        for (var i = 0; i < this.selected.length; i++){
            var objID = this.selected[i];
            try{
                this.objects[objID].startDrag();
            }
            catch(err){
                console.log("Object not found.");
                console.log(err);
            }
        } 
    }

    this.dragActive = function(){
        for (var i = 0; i < this.selected.length; i++){
            var objID = this.selected[i];
            try{
                this.objects[objID].drag();
            }
            catch(err){
                console.log("Cannot drag object.  Object not found.");
                console.log(err);                
            }
        } 
    }

    this.finalizeDrag = function(dataConnection){
        console.log("test")
        for (var i = 0; i < this.selected.length; i++){
            var objID = this.selected[i];
            try{
                this.objects[objID].finalizeDrag();
                dataConnection.checkSeatsForZone();
                dataConnection.checkSeatsForRoom();
            }
            catch(err){
                console.log("Cannot finalize drag object.  Object not found.");
                console.log(err);                
            }
        }
        this.state.setState("openSelector");
    }

    this.moveActive = function(x,y){  // Accepts changes in x and y values and moves all active objects by those amounts
        for (var i = 0; i < this.selected.length; i++){
            var objID = this.selected[i];
            try{
                this.objects[objID].move(x,y);
            }
            catch(err){
                console.log("Cannot find object to move");
                console.log(err);
            }
        }
    }

    //########################################  Save / Load Functions ############################################################

    this.save = function(){
        var saveFile = {};
        saveFile.objects = [];
        for(var i in this.objects){
            saveFile.objects.push(this.objects[i].save());
        }
        for(var i = 0; i < this.saveParameters.length;i++){
        	saveFile[this.saveParameters[i]] = this[this.saveParameters[i]];
        }
        console.log(this);
        return saveFile;
    }

    this.load = function(saveFile){
        this.removeAll();
        for(var i = 0; i < this.saveParameters.length;i++){
            this[i] = saveFile[this.saveParameters[i]];
        }
        for(var i=0;i < saveFile.objects.length;i++){
            var object = saveFile.objects[i];
            this.objects[object.id] = eval("new "+object.type+"(object.id,'white',this.state,this.map)",object.color); // creates the object in the object collection
            this.objects[object.id].load(object);
        }
    }

    //########################################  Object Property Functions ############################################################

    this.getProperties = function(id,subcategory){
        try{
            return this.objects[id].getObjectData();
        } catch(err){
            console.log(err);
            return {data:"",dividers:""};
        }
    }

    this.getViewerProperties = function(id,subcategory){
        try{
            if(subcategory!=undefined){
                var objID = id.slice(3);
            } else {
                var objID = id;
            }
            console.log("Controller subcategory",subcategory);
            return this.objects[objID].getObjectViewerData(subcategory,id);
        } catch(err){
            console.log(err);
            return {data:"",dividers:""}; // Gives a blank selector on error
        }
    }

    this.setProperty = function(id,property,value){
        try{
            return this.objects[id].setProperty(property,value);
        }
        catch(err){
            console.log("Error in setting property");
            console.log(err);
        }
    }


    this.setZoneName = function(name){
    	return this.objects[this.selected[0]].setZoneName(name);
    }

    this.setZoneColor = function(color){
    	return this.objects[this.selected[0]].setZoneColor(color);
    }

    this.setZoneFontColor = function(color){
		return this.objects[this.selected[0]].setZoneFontColor(color);
    }

    this.setZoneFontSize = function(size){
    	return this.objects[this.selected[0]].setZoneFontSize(size);
    }

    this.toggleAreaLabel = function(){
    	this.objects[this.selected[0]].toggleAreaLabel();
    }

    this.toggleNameLabel = function(){
    	this.objects[this.selected[0]].toggleNameLabel();
    }

}
AreaController.prototype = Object.create(ObjectController.prototype); // Links the prototype to the superclass
AreaController.prototype.constructor = AreaController;