//#################################  Seat Controller #####################################################

function SeatController(state,map){
    ObjectController.call(this); // Sets SeatController as subclass of ObjectController
    // this.objects = {};
    // this.selected = [];
    // this.currentlyDrawing = "";
    // this.handleSelected = {};
    // this.multiSelected = false;
    // this.layerVisible = true;
    this.state = state;
    this.map = map; 
    this.seatCount = 0;
    this.prefix = "SE";

    //#################################  Object Selection and Activation #####################################################
    
    this.getOutlinePoints = function(filterArray){ // Returns a set of bounding boxes for all objects
        var pointObject = {};
        for (var item in this.objects){
            try{
                if ( $.inArray( this.objects[item].type, filterArray ) > -1 ){ // Checks to see if the object type is on the filter-for list
                    pointObject[item] = this.objects[item].getOutlinePoints();
                }
            }
            catch(err){
                console.log("Unable to get bounding box for a data object");
                console.log(err)
            }
        }
        return pointObject;
    }

    this.getBoundingPoints = function(){
        var boundingPoints = [];
        var objKeys = Object.keys(this.objects);
        var objCount = objKeys.length;
        for(var i = 0;i < objCount;i++){
            boundingPoints.push(this.objects[objKeys[i]].getBoundingPoints());
        }
        return boundingPoints;
    }

    this.selectOne = function(id){  // Selects and activates a single object in the architecture controller, any existing active are deactivated
        this.multiSelected = false;
        this.deselectAll();
        this.objects[id].activate(false);
        this.selected.push(id); // Adds the current object to the selected array
    }

    this.selectMultiple = function(id){  // Selects and activates multiple architectural objects
        if(this.selected.length > 0 && this.multiSelected == false){  // removes handles if a single select happened first
            this.objects[this.selected[0]].deactivate();
            this.objects[this.selected[0]].activate(true); // basically reactivates in multi-select mode
        }
        if(this.selected.indexOf(id) == -1){ // True if the currently selected item is not already in the selected object array
            this.selected.push(id); // Adds the new selected object to the selected array
            this.multiSelected = true; // True even if there is only a single selection, so long as it occured in multi-select mode
            this.objects[id].activate(this.multiSelected);
        } else { // If the selected object has already been selected, this will deselect it (i.e. if it was selected accidentally)
            this.selected.splice(this.selected.indexOf(id),1); // removes from the selected array
            this.objects[id].deactivate();
        }
    }

    this.objectsAreSelected = function(){  // Returns whether any objects are selected
        if(this.selected.length > 0){
            return true;
        } else {
            return false;
        }
    }

    this.deselectAll = function(){  // Cancels any in-progress creations and deselects all objects
        this.cancelDraw(); // Cancels any drawings in progress
        var len = this.selected.length;
        for (var i = 0; i < len; i++){
            var objID = this.selected[i];
            try{
                this.objects[objID].deactivate();
            }
            catch(err){
                console.log("Unable to find object to deactivate");
            }
        } // Deactivates all currently active objects
        this.selected = []; // Clears the selected list
        this.multiSelected = false;
    }

    //#################################  Object Creation Functions #####################################################

    this.create = function(classType){
        this.deselectAll();
        var id = generateUUID();
        this.seatCount++;
        var seatName = ('0' + this.seatCount).length > 2 ? this.seatCount.toString() : '0' + this.seatCount;
        this.currentlyDrawing = id;
        this.objects[id] = eval("new "+classType+"(id,seatName,this.state,this.map)"); // creates the object in the object collection
        this.objects[id].create(map); // populates the object with initial values
        console.log(classType,"created")
    }

    this.dragNew = function(){
        this.objects[this.currentlyDrawing].dragPlace();
    }

    this.finalizePlace = function(){
        this.objects[this.currentlyDrawing].finalizeDragPlace();
        state.addUndoPackage(this.createUndoCreatePackage(this.currentlyDrawing));
        state.addRedoPackage(this.createRedoCreatePackage(this.currentlyDrawing));         
        this.currentlyDrawing = "";
    }

    this.cancelDraw = function(){  // Cancels the object currently being drawn/draggedNew and removes it completely
        if(this.currentlyDrawing!=""){
            console.log("Canceling draw event");
            this.objects[this.currentlyDrawing].cancelDraw();
            delete this.objects[this.currentlyDrawing];
            this.currentlyDrawing = "";
        }
    }

    this.duplicate = function(){
        var len = this.selected.length
        for(var i = 0;i<len;i++){ // Duplicates all items in the selected array
            var id = generateUUID();
            var seatName = 'Duplicate';
            this.objects[id] = eval("new "+this.objects[this.selected[i]].type+"(id,seatName,this.state,this.map)"); // creates the object in the object collection
            this.objects[id].duplicate(this.objects[this.selected[i]]);
        }
    }

    //#################################  Object Undo/Redo Functions #####################################################

    this.loadPackage = function(package){
        switch(package.packageType){
            case "modify":
                this.objects[package.id].loadPackage(package);
            break;
            case "redo create":
            case "undo delete":
                this.objects[package.id] = package.object;
                this.objects[package.id].redraw();
            break;
            case "undo create":
            case "redo delete":
                this.objects[package.id].remove();
                this.selected = [];
                delete this.objects[package.id];
            break;            
        } 
    }

    this.createUndoDeletePackage = function(id){
        var package = {};
        package.packageType = "undo delete";
        package.controller = "seats";
        package.id = id;
        package.object = this.objects[id];
        return package;
    }

    this.createRedoCreatePackage = function(id){
        var package = {};
        package.packageType = "redo create";
        package.controller = "seats";
        package.id = id;
        package.object = this.objects[id];
        return package;
    }

    this.createRedoDeletePackage = function(id){
        var package = {};
        package.packageType = "redo delete";
        package.controller = "seats";
        package.id = id;
        return package;
    }

    this.createUndoCreatePackage = function(id){
        var package = {};
        package.packageType = "undo create";
        package.controller = "seats";
        package.id = id;
        return package;       
    }

    //#################################  Object Deletion and Hiding Functions #####################################################

    this.deleteSelected = function(){  // Removes the currently selected object(s), including their svgs and data
        var len = this.selected.length;
        var dataConnection = $Map.current().dataConnections;
        for (var i = 0; i < len; i++){
            var objID = this.selected[i];

            // Removes the seat assignment data connection if the seat was assigned
            if(dataConnection.seatAssignments[objID]){
                dataConnection.removeAssignment(objID);
            }

            this.objects[objID].remove(); // Removes all currently active object elements
            this.state.addUndoPackage(this.createUndoDeletePackage(objID));
            this.state.addRedoPackage(this.createRedoDeletePackage(objID));
            delete this.objects[objID]; // Deletes the object references in the objects collection
        }
        this.selected = []; // Clears the selected list            
    }

    this.removeAll = function(){ // Removes all objects from the controller, both data and SVG
        // WARNING this cannot be undone (should only be used for a load even where an empty object is needed)
        for (var i in this.objects){
            this.objects[i].remove(); // Removes all object SVG elements
            delete this.objects[i]; // Deletes the object references in the collection
        }
        this.selected = []; // Clears the selected list
    }

    //#################################  Point Handle Manipulation Functions #####################################################

    // These are blank on purpose
    this.handlePress = function(){
    }
    this.handleDrag = function(){
    }
    this.finalizeHandleDrag = function(){
    }
    this.handleSelect = function(){
    }

    //########################################  Object Drag and Move Functions ############################################################

    this.startDrag = function(){  // Sets the move origins for all active objects
        // triggered on click event for SVG
        var len = this.selected.length;
        for (var i = 0; i < len; i++){
            var objID = this.selected[i];
            try{
                this.objects[objID].startDrag();
            }
            catch(err){
                console.log("Object not found.");
                console.log(err);
            }
        }
    }

    this.dragActive = function(){  // Drag moves all active objects
        var len = this.selected.length;
        for (var i = 0; i < len; i++){
            var objID = this.selected[i];
            try{
                this.objects[objID].drag();
            }
            catch(err){
                console.log("Cannot drag object.");
                console.log(err);                
            }
        } 
    }

    this.finalizeDrag = function(dataConnection){
        var len = this.selected.length;
        for (var i = 0; i < len; i++){
            var objID = this.selected[i];
            try{
                this.objects[objID].finalizeDrag();
                dataConnection.checkSeatsForZone(objID);
            }
            catch(err){
                console.log("Cannot finalize drag object.  Object not found.");
                console.log(err);                
            }
        } 
    }

    this.moveActive = function(direction,dataConnection){  // Accepts changes in x and y values and moves all active objects by those amounts
        console.log("moving")
        var len = this.selected.length;
        for (var i = 0; i < len; i++){
            var objID = this.selected[i];
            try{
                this.objects[objID].move(direction);
                dataConnection.checkSeatsForZone(objID);
            }
            catch(err){
                console.log("Cannot find object to move");
                console.log(err);
            }
        }           
    }

    //########################################  Save / Load Functions ############################################################

    this.save = function(){
        this.saveFile = {};
        this.saveFile.objects = [];
        this.saveFile.seatCount = this.seatCount;
        for(var i in this.objects){
            this.saveFile.objects.push(this.objects[i].save());
        }
        return this.saveFile;
    }

    this.load = function(file){
        this.deselectAll();
        this.removeAll();
        this.seatCount = file.seatCount;
        var len = file.objects.length;
        for(var i=0;i < len;i++){
            var object = file.objects[i];
            var seatName = object.name;
            var id = object.id;
            this.objects[object.id] = eval("new "+object.type+"(id,seatName,this.state,this.map)"); // creates the object in the object collection
            this.objects[object.id].load(object);
        }
    }

    //########################################  Object Property Functions ############################################################

    this.getProperties = function(id,subcategory){
        try{
            if(subcategory!=undefined){
                var objID = id.slice(3);
            } else {
                var objID = id;
            }
            console.log("getting properties:",id)
            return this.objects[objID].getProperties(subcategory,id);
        } catch(err){
            console.log(err);
            return {data:"",dividers:""}; // Gives a blank selector on error
        }
    }

    this.getViewerProperties = function(id,subcategory){
        try{
            if(subcategory!=undefined){
                var objID = id.slice(3);
            } else {
                var objID = id;
            }
            console.log("Controller subcategory",subcategory);
            return this.objects[objID].getObjectViewerData(subcategory,id);
        } catch(err){
            console.log(err);
            return {data:"",dividers:""}; // Gives a blank selector on error
        }
    }

    this.setProperty = function(id,property,value,subcategory){
        try{
            if(subcategory!=undefined){
                var objID = id.slice(3);
            } else {
                var objID = id;
            }
            return this.objects[objID].setProperty(property,value,subcategory,id);
        }
        catch(err){
            console.log("Error in setting property");
            console.log(err);
        }
    }

}

SeatController.prototype = Object.create(ObjectController.prototype); // Links the prototype to the superclass
SeatController.prototype.constructor = SeatController;

