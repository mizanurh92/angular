//#################################  Architecture Controller #####################################################

function ArchitectureController(state,map){
    ObjectController.call(this); // Sets ArchitectureController as subclass of ObjectController
    this.state = state;
    this.map = map; 
    this.activeDoor = "";
    this.activeWindow = "";
    this.prefix = "AR";

    //#################################  Object Selection and Activation #####################################################
    
    this.getOutlinePoints = function(filterArray){ // Returns a set of bounding boxes for all architect objects
        var pointObject = {};
        for (var item in this.objects){
            try{
                if ( $.inArray( this.objects[item].type, filterArray ) > -1 ){ // Checks to see if the object type is on the filter-for list
                    pointObject[item] = this.objects[item].getOutlinePoints();
                }
            }
            catch(err){
                console.log("Unable to get bounding box for an architect object");
                console.log(err)
            }
        }
        return pointObject;
    }

    this.getBoundingPoints = function(){
        var boundingPoints = [];
        var objKeys = Object.keys(this.objects);
        var objCount = objKeys.length;
        for(var i = 0;i < objCount;i++){
            boundingPoints.push(this.objects[objKeys[i]].getBoundingPoints());
        }
        return boundingPoints;
    }

    this.getOutlineSegments = function(){
        var outlineObject = {};
        for (var item in this.objects){
            try{
                outlineObject[item] = this.objects[item].getBorderEdges();
            }
            catch(_){

            }
        }
        return outlineObject;        
    }

    this.selectOne = function(id,subclass){  // Selects and activates a single object in the architecture controller, any existing active are deactivated
        this.multiSelected = false;
        this.deselectAll();
        if(subclass == undefined){
            this.selected.push(id); // Adds the current object to the selected array
            this.objects[id].activate(false); // Activates the object with the stated id with multi-select false 
        } else if(subclass == "Window"){
            this.objects[id.slice(3)].activate(false,subclass,id);
            this.activeWindow = id;
        } else if(subclass == "Door"){
            this.objects[id.slice(3)].activate(false,subclass,id);
            this.activeDoor = id;
        }
    }

    this.viewerSelectOne = function(id,subclass){
        this.multiSelected = false;
        this.deselectAll();
        if(subclass == undefined){
            this.selected.push(id); // Adds the current object to the selected array
            this.objects[id].viewerActivate(); // Activates the object with the stated id with multi-select false 
        } else if(subclass == "Window"){
            this.objects[id.slice(3)].viewerActivate({subclass:subclass,subclassID:id});
            this.activeWindow = id;
        } else if(subclass == "Door"){
            this.objects[id.slice(3)].viewerActivate({subclass:subclass,subclassID:id});
            this.activeDoor = id;
        }        
    }

    this.selectMultiple = function(id){  // Selects and activates multiple architectural objects
        // This will not allow the selection of multiple child objects such as door or windows
        if(this.activeDoor != ""){ // Deactivates any active door
            this.objects[this.activeDoor.slice(3)].deactivateDoor(this.activeDoor);
            this.activeDoor = "";
        }
        if(this.activeWindow != ""){  // Deactivates any active window
            this.objects[this.activeWindow.slice(3)].deactivateWindow(this.activeWindow);
            this.activeWindow = "";
        } 
        if(this.selected.length > 0 && this.multiSelected == false){  // removes handles if a single select happened first
            this.objects[this.selected[0]].deactivate();
            this.objects[this.selected[0]].activate(true); // basically reactivates in multi-select mode
        }
        if(this.selected.indexOf(id) == -1){ // True if the currently selected item is not already in the selected object array
            this.selected.push(id); // Adds the new selected object to the selected array
            this.multiSelected = true; // True even if there is only a single selection, so long as it occured in multi-select mode
            this.objects[id].activate(this.multiSelected);
        } else { // If the selected object has already been selected, this will deselect it (i.e. if it was selected accidentally)
            this.selected.splice(this.selected.indexOf(id),1); // removes from the selected array
            this.objects[id].deactivate();
        }
    }

    this.objectsAreSelected = function(){  // Returns whether any architectural objects or their children are selected
        if((this.selected.length > 0) || this.activeDoor != "" || this.activeWindow != ""){
            return true;
        } else {
            return false;
        }
    }

    this.deselectAll = function(){  // Cancels any in-progress creations and deselects all objects and their children
        if(this.state.state == "placeDoor"){ // Cancels any doors in progress
            this.objects[this.selected[0]].cancelPlaceDoor();
        } 
        if(this.state.state == "placeWindow"){ // Cancels any windows in progress
            this.objects[this.selected[0]].cancelPlaceWindow();
        } 
        this.cancelDraw(); // Cancels any drawings in progress
        if(this.activeDoor != ""){
            this.objects[this.activeDoor.slice(3)].deactivateDoor(this.activeDoor);
            this.activeDoor = "";
        }
        if(this.activeWindow != ""){
            this.objects[this.activeWindow.slice(3)].deactivateWindow(this.activeWindow);
            this.activeWindow = "";
        }
        for (var i = 0; i < this.selected.length; i++){
            var objID = this.selected[i];
            try{
                this.objects[objID].deactivate();
            }
            catch(err){
                console.log("Unable to find object to deactivate");
            }
        } // Deactivates all currently active objects
        this.selected = []; // Clears the selected list
        this.multiSelected = false;
    }

    //#################################  Object Creation Functions #####################################################

    this.create = function(classType){
        var id = generateUUID();
        this.currentlyDrawing = id;
        this.objects[id] = eval("new "+classType+"(id,this.state,this.map)"); // creates the object in the object collection
        this.objects[id].create(); // populates the object with initial values
        if(classType == "Wall"){ // This section allows a wall to be drawn using existing wall snapping
            var wallPoints = {};
            for(var objectKey in this.objects){
                if(this.objects[objectKey].type == "Wall" && objectKey != id){
                    wallPoints[objectKey] = this.objects[objectKey].getBoundingPoints(6);
                }
            }
            this.objects[id].setWallPoints(wallPoints);
        }
        console.log(classType," created")
    }

    this.addSubcategory = function(type){
        if(type == "Window"){
            if(this.selected.length == 1 && this.objects[this.selected[0]] instanceof Wall){
                this.objects[this.selected[0]].addWindow();
            }            
        } else if (type == "Door"){
            if(this.selected.length == 1 && this.objects[this.selected[0]] instanceof Wall){
                this.objects[this.selected[0]].addDoor();
            }            
        }
    }

    this.draw = function(){ // Routed event handler passes mouse position to objects for drawing
        try{
            if(this.objects[this.currentlyDrawing]){
                this.objects[this.currentlyDrawing].draw();  
            }   
        }
        catch(err){
            console.log("Cannot find currently drawing object.");
            console.log(err);
        }
    }

    this.finishDraw = function(){  // Routed event handler which passes a finalize draw command to the architecture object currently being drawn
        if(this.currentlyDrawing != ""){
            if(this.objects[this.currentlyDrawing].checkValid()){
                if(this.objects[this.currentlyDrawing].type == "Wall"){this.updateWallCorners();}
                this.objects[this.currentlyDrawing].finalizeDraw();
                this.state.addUndoPackage(this.createUndoCreatePackage(this.currentlyDrawing));
                this.state.addRedoPackage(this.createRedoCreatePackage(this.currentlyDrawing));               
                this.currentlyDrawing = "";
            } else {
                console.log('Invalid wall, cancelling draw')
                this.cancelDraw(); // If the length of the wall is zero, cancel the drawing as it was probably an accidental click
            }
        }
    }    

    this.dragNew = function(){
        this.objects[this.currentlyDrawing].dragPlace();
    }

    this.finalizeDragNew = function(){
        this.objects[this.currentlyDrawing].finalizeDragPlace();
        this.state.addUndoPackage(this.createUndoCreatePackage(this.currentlyDrawing));
        this.state.addRedoPackage(this.createRedoCreatePackage(this.currentlyDrawing));         
        this.currentlyDrawing = "";
    }

    this.cancelDraw = function(){  // Cancels the object currently being drawn/draggedNew and removes it completely
        if(this.currentlyDrawing!=""){
            console.log("Canceling draw event");
            this.objects[this.currentlyDrawing].cancelDraw();
            delete this.objects[this.currentlyDrawing];
            this.currentlyDrawing = "";
        }
    }

    this.duplicate = function(){
        if(this.activeWindow != ""){
            this.objects[this.activeWindow.slice(3)].duplicateWindow(this.activeWindow);
            return;
        }
        if(this.activeDoor != ""){
            this.objects[this.activeDoor.slice(3)].duplicateDoor(this.activeDoor);
            return;
        }
        var len = this.selected.length
        for(var i = 0;i<len;i++){ // Duplicates all items in the selected array
            var id = generateUUID();
            this.objects[id] = eval("new "+this.objects[this.selected[i]].type+"(id,this.state,this.map)"); // creates the object in the object collection
            this.objects[id].duplicate(this.objects[this.selected[i]]);
        }
    }

    //#################################  Object Undo/Redo Functions #####################################################

    this.loadPackage = function(package){
        console.log(package)
        switch(package.packageType){
            case "modify":
                this.objects[package.id].loadPackage(package);
            break;
            case "redo create":
            case "undo delete":
                this.objects[package.id] = package.object;
                this.objects[package.id].redraw();
            break;
            case "undo create":
            case "redo delete":
                this.objects[package.id].remove();
                this.selected = [];
                delete this.objects[package.id];
            break;            
            case "modify door":
            case "modify window":
            case "undo create door":
            case "redo create door":
            case "undo delete door":
            case "redo delete door":
            case "undo create window":
            case "redo create window":
            case "undo delete window":
            case "redo delete window":
                this.objects[package.id.slice(3)].loadPackage(package); // Passes subobject package to parent object for loading
            break;
        } 
    }

    this.createUndoDeletePackage = function(id){
        var package = {};
        package.packageType = "undo delete";
        package.controller = "architect";
        package.id = id;
        package.object = this.objects[id];
        return package;
    }

    this.createRedoCreatePackage = function(id){
        var package = {};
        package.packageType = "redo create";
        package.controller = "architect";
        package.id = id;
        package.object = this.objects[id];
        return package;
    }

    this.createRedoDeletePackage = function(id){
        var package = {};
        package.packageType = "redo delete";
        package.controller = "architect";
        package.id = id;
        return package;
    }

    this.createUndoCreatePackage = function(id){
        var package = {};
        package.packageType = "undo create";
        package.controller = "architect";
        package.id = id;
        return package;       
    }

    //#################################  Object Deletion and Hiding Functions #####################################################

    this.deleteSelected = function(){  // Removes the currently selected object(s), including their svgs and data
        if(this.activeDoor != ""){
            this.objects[this.activeDoor.slice(3)].removeDoor(this.activeDoor);
            this.activeDoor = "";
            return;
        }
        if(this.activeWindow != ""){
            this.objects[this.activeWindow.slice(3)].removeWindow(this.activeWindow);
            this.activeWindow = "";
            return
        }
        var wallAffect = false;
        var len = this.selected.length;
        for (var i = 0; i < len; i++){
            var objID = this.selected[i];
            if(this.objects[objID].type == "Wall") wallAffect = true;
            this.objects[objID].remove(); // Removes all currently active object elements
            this.state.addUndoPackage(this.createUndoDeletePackage(objID));
            this.state.addRedoPackage(this.createRedoDeletePackage(objID));
            delete this.objects[objID]; // Deletes the object references in the objects collection
        }
        if(wallAffect){ // Only update wall corners if walls were affected by the delete
            this.updateWallCorners();
        }
        this.selected = []; // Clears the selected list            
    }

    this.removeAll = function(){ // Removes all objects from the architecture controller, both data and SVG
        // WARNING this cannot be undone (should only be used for a load even where an empty object is needed)
        for (var i in this.objects){
            this.objects[i].remove(); // Removes all object SVG elements
            delete this.objects[i]; // Deletes the object references in the collection
        }
        this.selected = []; // Clears the selected list
    }

    //#################################  Point Handle Manipulation Functions #####################################################

    this.handlePress = function(handleID,objID){ // General handle press function, applies to any objects with handle objects attached
        this.handleSelected.handleId = handleID;
        this.handleSelected.id = objID;
        try{
            if(this.objects[objID].type == "Wall"){
                var wallPoints = {};
                for(var objectKey in this.objects){
                    if(this.objects[objectKey].type == "Wall" && objectKey != objID){
                        wallPoints[objectKey] = this.objects[objectKey].getBoundingPoints(6);
                    }
                }
                this.objects[objID].handlePress(handleID,wallPoints);
            } else {
                this.objects[objID].handlePress(handleID);
            }
        }
        catch(err){
            console.log("Cannot find object associated with the point handle.");
            console.log(err)
        }
    }

    this.handleDrag = function(){ // General handle drag function, applies to any objects with handle objects attached
        
        this.objects[this.handleSelected.id].handleDrag();
    }

    this.finalizeHandleDrag = function(){
        if(this.handleSelected.id != "" && this.handleSelected.id != undefined){
            try{
                if(this.objects[this.handleSelected.id] && this.objects[this.handleSelected.id].type == "Wall"){this.updateWallCorners();}
                this.objects[this.handleSelected.id].finalizeHandleDrag();
            }
            catch(err){
                console.log(err);
            }
        }
    }

    this.handleSelect = function(){
        // Empty on purpose
    }

    //########################################  Object Drag and Move Functions ############################################################

    this.startDrag = function(type,controllers){  // Sets the move origins for all active objects
        if(type != undefined){
            switch(type){
                case "Door":
                    try{
                        this.objects[this.activeDoor.slice(3)].startDrag(this.activeDoor,type);
                        return;
                    }
                    catch(err){
                        console.log(err);
                        return;
                    }
                break;
                case "Window":
                    try{
                        this.objects[this.activeWindow.slice(3)].startDrag(this.activeWindow,type);
                        return;
                    }
                    catch(err){
                        console.log(err);
                        return;
                    }
                break;
            }
        }
        // triggered on click event for SVG
        var len = this.selected.length;
        for (var i = 0; i < len; i++){
            var objID = this.selected[i];
            try{
                if(this.objects[objID].type == "Wall"){
                    var wallPoints = {};
                    for(var objectKey in this.objects){
                        if(this.objects[objectKey].type == "Wall" && objectKey != objID){
                            wallPoints[objectKey] = this.objects[objectKey].getBoundingPoints(6);
                        }
                    }
                    this.objects[objID].startDrag(undefined,undefined,wallPoints);
                } else {
                    this.objects[objID].startDrag({snapPoints:this.getSnapObjects(controllers,{filterID:objID})});
                }
            }
            catch(err){
                console.log("Object not found.");
                console.log(err);
            }
        }
    }

    this.dragActive = function(){  // Drag moves all active objects
        if(this.activeWindow != ""){
            this.objects[this.activeWindow.slice(3)].drag("Window",this.activeWindow);
            return;
        }
        if (this.activeDoor != ""){
            this.objects[this.activeDoor.slice(3)].drag("Door",this.activeDoor);
            return;
        }
        var len = this.selected.length;
        for (var i = 0; i < len; i++){
            var objID = this.selected[i];
            try{
                this.objects[objID].drag();
            }
            catch(err){
                console.log("Cannot drag object.");
                console.log(err);                
            }
        } 
    }

    this.finalizeDrag = function(){
        if(this.activeDoor != ""){
            this.objects[this.activeDoor.slice(3)].finalizeDragDoor(this.activeDoor);
            return;
        }
        if(this.activeWindow != ""){
            this.objects[this.activeWindow.slice(3)].finalizeDragWindow(this.activeWindow)
            return;
        }
        var len = this.selected.length;
        var wallAffect = false;
        for (var i = 0; i < len; i++){
            var objID = this.selected[i];
            try{
                if(this.objects[objID].type == "Wall"){wallAffect = true;}
                this.objects[objID].finalizeDrag();
            }
            catch(err){
                console.log("Cannot finalize drag object.  Object not found.");
                console.log(err);                
            }
        } 
        if(wallAffect){
            this.updateWallCorners();
        }
    }

    this.moveActive = function(direction){  // Accepts changes in x and y values and moves all active objects by those amounts
        if(this.activeDoor != ""){
            this.objects[this.activeDoor.slice(3)].move(direction,"Door",this.activeDoor);
            return;
        }
        if (this.activeWindow != ""){
            this.objects[this.activeWindow.slice(3)].move(direction,"Window",this.activeWindow);
            return;
        }
        var len = this.selected.length;
        var wallAffect = false;
        for (var i = 0; i < len; i++){
            var objID = this.selected[i];
            try{
                this.objects[objID].move(direction);
                if(this.objects[objID].type == "Wall"){wallAffect = true;}
            }
            catch(err){
                console.log("Cannot find object to move");
                console.log(err);
            }
        }           
        if(wallAffect){
            this.updateWallCorners();
        }
    }

    this.moveAll = function(shiftLeft,shiftUp){
        var keys = Object.keys(this.objects);
        var len = keys.length;
        var key,current;
        for(var i = 0;i < len;i++){
            try{
                key = keys[i];
                current = this.objects[key];
                current.shiftPosition(shiftLeft,shiftUp);                
            } catch(err){
                console.log(err);
            }
        }
        try{
            this.updateWallCorners();
        } catch(err){
            console.log(err);
        }
    }    

    //########################################  Save / Load Functions ############################################################

    this.save = function(){
        this.saveFile = {};
        this.saveFile.objects = [];
        for(var i in this.objects){
            this.saveFile.objects.push(this.objects[i].save());
        }
        return this.saveFile;
    }

    this.load = function(file){
        this.deselectAll();
        this.removeAll();
        var len = file.objects.length;
        for(var i=0;i < len;i++){
            var object = file.objects[i];
            this.objects[object.id] = eval("new "+object.type+"(object.id,this.state,this.map)"); // creates the object in the object collection
            this.objects[object.id].load(object);
        }
        this.updateWallCorners();
    }

    //########################################  Object Property Functions ############################################################

    this.getDrawingID = function(){
        return this.currentlyDrawing;
    }

    this.getProperties = function(id,subcategory){
        try{
            if(subcategory!=undefined){
                var objID = id.slice(3);
            } else {
                var objID = id;
            }
            if(this.objects[objID]){
                return this.objects[objID].getObjectData(subcategory,id);                
            }
        } catch(err){
            console.log(err);
            return {data:"",dividers:""}; // Gives a blank selector on error
        }
    }

    this.getViewerProperties = function(id,subcategory){
        try{
            if(subcategory!=undefined){
                var objID = id.slice(3);
            } else {
                var objID = id;
            }
            console.log("Controller subcategory",subcategory);
            return this.objects[objID].getObjectViewerData(subcategory,id);
        } catch(err){
            console.log(err);
            return {data:"",dividers:""}; // Gives a blank selector on error
        }
    }

    this.setProperty = function(id,property,value,subcategory){
        try{
            if(subcategory!=undefined){
                var objID = id.slice(3);
            } else {
                var objID = id;
            }
            return this.objects[objID].setProperty(property,value,subcategory,id);
        }
        catch(err){
            console.log("Error in setting property");
            console.log(err);
        }
    }

    this.getSelectedPoints = function(){  // Returns an associative array (object) of point pairs to be used in creating zones and rooms from wall selections
        // curently unused
        var pointList = {};
        for(var i = 0;i < this.selected.length; i++){
            objID = this.selected[i];
            pointList[objID] = {
                first:this.objects[objID].startPoint.getPoint(),
                second:this.objects[objID].endPoint.getPoint()
            }
        }
        return pointList;
    }    

    //#################################  Wall Functions #####################################################

    this.getWallPoints = function(){ // Gets an object with the points for all walls, along with a bounding box of a given buffer range
        var wallPoints = {};
        for(var objectKey in this.objects){
            if(this.objects[objectKey].type == "Wall"){
                wallPoints[objectKey] = this.objects[objectKey].getBoundingPoints(6);
            }
        }
        return wallPoints;        
    }

    this.updateWallCorners = function(){
        // very expensive function that compares each wall with each other wall - n(n-1)/2
        console.log("Full Wall Corner Update")
        var wallPoints = this.getWallPoints();
        for(var objectKey in this.objects){
            if(this.objects[objectKey].type == "Wall"){
                this.objects[objectKey].updateIntersections(wallPoints);
            }
        }
        var snapWallPoints = this.getSnapWallPoints();
        for(var objectKey in this.objects){
            if(this.objects[objectKey].type == "Wall"){
                this.objects[objectKey].formatSnapWall(snapWallPoints);
            }
        }        
    }

    // This is different than getWallPoints in that it uses the snap points method
    this.getSnapWallPoints = function(){
        var wallPoints = {};
        for(var objectKey in this.objects){
            if(this.objects[objectKey].type == "Wall"){
                wallPoints[objectKey] = this.objects[objectKey].getSnapPoints();
            }
        }
        return wallPoints; 
    }

    //#################################  Door Functions #####################################################

    this.dragPlaceDoor = function(){  // Routed event handler which assists in the initial placement of the door

        this.objects[this.selected[0]].dragPlaceDoor();
    }

    this.finalizePlaceDoor = function(){  // Routed event handler which sets the final starting position for the door

        this.objects[this.selected[0]].finalizePlaceDoor();
    }

    //#################################  Window Functions #####################################################

    this.dragPlaceWindow = function(){  // Routed event handler which assists in the initial placement of the window
        
        this.objects[this.selected[0]].dragPlaceWindow();
    }

    this.finalizePlaceWindow = function(){  // Routed event handler which sets the final starting position for the window
        
        this.objects[this.selected[0]].finalizePlaceWindow();
    }

}
    ArchitectureController.prototype = Object.create(ObjectController.prototype); // Links the prototype to the superclass
    ArchitectureController.prototype.constructor = ArchitectureController;

