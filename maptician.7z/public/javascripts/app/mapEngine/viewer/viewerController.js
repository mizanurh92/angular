function MapViewerController(){
	this.files = {};  // Object containing the open map editor documents - referenced by mapID
	this.currentFile = null; // Pointer holds a reference to the active map file
	this.hasInit = false;
	this.drawn = false;
	this.navBar = $("#viewerRightNavBar");
	this.mapArea = $("#editorArea");
	this.fileMenu = $("#viewerMenu");
	this.fileList = this.fileMenu.find('.files');
	this.map = $("#map");
	this.miniMap = $("#viewerMiniMap");
	var Viewer = this;

	this.loadFile = function(file,options){
		var options = options || {};
		var point = options.point || null;
		var focus = options.focus || null;
		var id = file.id;
		var name = file.name;
		Object.keys(this.files).length ? null : this.showMapElements(); // Inits for first file load
		// TODO might want some kind of confirmation if the file is already loaded and would be over-written
		this.files[id] ? this.files[id].clear() : this.apppendFile(id,name);
		this.currentFile && this.currentFile.hide();
		$Map.unit(file.settings.unitSystem || "US");
		this.files[id] = new MapViewerInstance(file); // Creates an empty map instance and adds it to file list
		this.currentFile = this.files[id]; // Sets the new map instance as currently active
		this.drawn = true;
		this.setLeftNav();
		point && this.currentFile.goToPoint(point);
		focus && this.currentFile.controllers[focus.controller].selectOne(focus.id);
	}

	this.apppendFile = function(id,name){
		if(this.fileList.css("display")=="none"){
			this.fileList.append("<li class='lev-2'><a id='"+id+"' href='#'>"+name+"</a></li>");
			this.fileList.parent().css({height:"45px"});
			this.fileList.hide();
		} else {
			this.fileList.append("<li class='lev-2'><a id='"+id+"' href='#'>"+name+"</a></li>");
		}
	}

	// General starting point for loading based on various available options.  Determines whether
	// the requested map is already loaded, if so, it directs the viewer to that map, if the map
	// is not loaded, it downloads the map and then displays it.  Includes options for moving the
	// view window to a specified location and for activating an object based on controller name
	// and objectID
	this.viewFile = function(options){
		var mapID = options.mapID || null;
		var location = options.location || null; // Point object {x:foo,y:bar}
		var focus = options.focus || null; // Should be an object with a {controller:foo,id:bar}
		var file = options.file || null;
		var data = {
			id: mapID
		}
		if(file){ // If a map file is passed, load the map file
			this.loadFile(file,{point:location,focus:focus});
			return;
		}
		if(mapID && this.files[mapID]){ // If the map is already loaded and a date isn't provided
			this.changeFile(mapID,{point:location,focus:focus});
			return;
		}
		if(mapID){ // File isn't available
			$.ajax({
				type:"GET",
				url: "/loadMapFile",
				data: data,
				success:function(file){
					Viewer.loadFile(file,{point:location,focus:focus});
				}
			})
		}
	}

	// This function handles switching between map files which are alrady loaded.  Additionally
	// it has the option, if it is passed a mapID and a point, and the map is not only alread loaded,
	// but is also currently displayed, the map will shift to the point provided.  If the map isn't
	// displayed, but it is loaded, it loads the map and optionally displays the point view and object focus
	// provided through the options parameter
	this.changeFile = function(id,options){
		var options = options || {};
		var point = options.point || null;
		var focus = options.focus || null;
		if(this.files[id]===undefined){ // Error catching for if the file isn't actually loaded
			console.log("Cannot find loaded file.");
			return;
		} 
		if(this.currentFile.getMapID() == id){
			if(point){
				this.currentFile.goToPoint(point);
			}
			return;
		}
		this.currentFile.hide();
		this.currentFile = this.files[id];
		$Map.unit(this.currentFile.getUnitSystem());
		this.currentFile.redraw();
		this.drawn = true;
		this.setLeftNav();
		if(focus){
			this.currentFile.controllers[focus.controller].selectOne(focus.id);
		}
		if(point){
			this.currentFile.goToPoint(point);
		}
	}

	this.setLeftNav = function(){
		if(this.currentFile){
			var id = this.currentFile.getMapID();
			$(".lev-2",this.fileMenu).removeClass("selected");
			$("#"+id,this.fileMenu).parent().addClass("selected");
		}
	}

	this.hide = function(){
		if(this.drawn && this.currentFile){
			this.currentFile.hide();
			this.drawn = false;
		}
	}

	this.redraw = function(){
		if(!this.drawn && this.currentFile){
			this.currentFile.redraw();
			this.drawn = true;
			this.setLeftNav();      
		}
	}

	this.initializations = function(){ // Initialization required on load
		// Disables right click context menus for the map container area
		// TODO remove the getElement portion in production - this will completely disable contect menus
		document.getElementById("editorArea").addEventListener( "contextmenu", function(e) { // TODO build a context menu system
			e.preventDefault();
		});

		$("#infoDiv").outerHeight(window.innerHeight 
			- $("#lowerRightSelectorPanel").outerHeight()
			- $("#viewerMiniMapContainer").outerHeight()
			- $("#systembarButtons").outerHeight()
			- $("#toolbarButtons").outerHeight()
			- $("#objectButtons").outerHeight()
			);
		
		$("#areasAccordion").accordion({heightStyle: "content"});
		$("#selectorAccordion").accordion({heightStyle: "content"});
	}

	this.setBindings = function(){
		var progController = this;
		var documentObj = $(document);
		var screenMap = $("#map");
		var editorArea = $("#editorArea");
		var miniMap = $("#viewerMiniMapContainer");

		document.ontouchmove = function(event){
			if(progController.drawn){
				event.preventDefault();
			}
		}

		editorArea.on('tap tapstart',function(event,touch){
			if(progController.drawn){
				progController.currentFile.mouseRouter.documentMouseDown(touch[0] || touch );
			}
		})

		miniMap.on('tap tapstart',function(event,touch){
			if(progController.drawn){
				progController.currentFile.mouseRouter.miniMapMouseDown(touch[0] || touch );
			}
		})

		miniMap.on('mousemove tapmove',function(event,touch){
			if(progController.drawn && touch){
				progController.currentFile.mouseRouter.miniMapMouseMove(touch);
			}
		})

		miniMap.on('tapend',function(event){
			if(progController.isSet() && progController.drawn){
				progController.currentFile.mouseRouter.documentMouseUp(event);
			}
		})

		editorArea.on('mousemove tapmove',function(event,touch){
			if(progController.drawn && touch){
				progController.currentFile.mouseRouter.documentMouseMove(touch);
			}
		})

		screenMap.on('mousemove tapmove',function(event){
			if(progController.drawn){
				progController.currentFile.mouseRouter.mapMouseMove(event);
			}
		})

		screenMap.on('tap tapstart',function(event,touch){
			if(progController.drawn){
				progController.currentFile.mouseRouter.mapMouseDown(event);
			}
		})

		documentObj.mouseup(function(event){
			if(progController.isSet() && progController.drawn){
				progController.currentFile.mouseRouter.documentMouseUp(event);
			}
		})

		screenMap.on('tapend',function(event){
			if(progController.isSet() && progController.drawn){
				progController.currentFile.mouseRouter.documentMouseUp(event);
			}
		})

		$("svg",this.map).on("mousedown",function(e){ // Mouse click binding for map objects
			if(e.which == 1 && progController.drawn ){
				var id = e.toElement ? e.toElement.id : e.target.id;
				var object = e.toElement || e.target;
				var jQueryObject = $(object);
				progController.currentFile.mouseRouter.svgClickRouter.clicked(id,jQueryObject,e.which,e.ctrlKey);            
			}
		})

		$(document).on("keydown",function(event){ // Main keyboard interface router
			if(!$.modal.isActive() && progController.isSet() && progController.drawn){ // keyboard router is only used when modal menus aren't active
				progController.currentFile.keyboardRouter.keyPress(event);
			}
		})

		this.screenSizeBindings(progController);
		this.architectureButtonBindings(progController);
		this.zoneButtonBindings(progController);
		this.roomButtonBindings(progController);
		this.seatButtonBindings(progController);
		this.selectorBindings(progController);
		this.mapNavigationBindings(progController);
		this.objectSelectorBindings(progController);
		Maptician.inits.viewerButtonControls(progController);
		Maptician.buttons.radioButtonBar("viewerButtons",["vSearchArea","vSelectorArea"]);
		Maptician.buttons.buttonBar("viewerControlButtons");
	}

	this.objectSelectorBindings = function(progController){
		// Note - There's not a great way to alias the path to objectSelector below.  This is because these listeners are
		// set before the first file is loaded.

		// Activates the object selector window.  Basically preventing map keyboard commands from triggering while active.
		$("#objectSelector").on("mousedown",function(){
			if(progController.isSet()){
				progController.currentFile.objectSelector.activateSelectorWindow();
			}
		})

		// Bound events for various selector input changes
		
		// This is necessary for text boxes which need to update as they are typed
		// Not using this means that the contents will be lost upon loss of focus
		// These inputs are designated with textInput class, to distinguish from inputs which should be
		// finalized more formally (i.e. coordinates shouldn't update until the number is finished)
		$(".selectorInput.textInput").on("input",function(e,ui){ 
			if(progController.isSet() && progController.drawn){
				progController.currentFile.objectSelector.propertyChange(this,e);
			}
		})

		$(".selectorInput").on("change",function(e){ // Binds an event to the selector inputs with .selectorInput class triggering on value change
			console.log("change");
			if(progController.isSet() && progController.drawn){
				progController.currentFile.objectSelector.propertyChange(this,e);
			}
		})

		$(".selectorInput").on("spin",function(e,ui){ // Binds an event to the selector inputs with .selectorInput class triggering on spinner spin
			console.log("spin");
			if(progController.isSet() && progController.drawn){
				progController.currentFile.objectSelector.propertyChange(this,e,ui);
			}
		})

		$(".selectorInput").on("slide",function(e,ui){ // Binds an event to the selector inputs with .selectorInput class triggering on slider slide
			console.log("slide");
			if(progController.isSet() && progController.drawn){
				progController.currentFile.objectSelector.propertyChange(this,e,ui);
			}
		})        
	}


	this.screenSizeBindings = function(progController){  // Controls map area and navbar sizes and positions on resize
		$(window).resize(function(){
			$("#infoDiv").outerHeight(window.innerHeight 
				- $("#lowerRightSelectorPanel").outerHeight()
				- $("#miniMapContainer").outerHeight()
				- $("#systembarButtons").outerHeight()
				- $("#toolbarButtons").outerHeight()
				- $("#objectButtons").outerHeight()
				);
			// Updates map position on window resize so that it doesn't get positioned outside of bounds
			if(progController.isSet()){
				progController.currentFile.map.constrainedMove(
					progController.currentFile.map.x(),
					progController.currentFile.map.y(),
					progController.currentFile.miniMap
					);
			}
			$('#vObjectSelector').slimScroll({
				position: 'right',
				height:"auto",
				railVisible: true,
				alwaysVisible: false,
				color: "#51BCFA",
				disableFadeOut:true
			});
		});    
	}

	this.architectureButtonBindings = function(progController){

	}

	this.zoneButtonBindings = function(progController){
	   
	}

	this.roomButtonBindings = function(progController){
		$("#vobjectReserveRoom").click(function(){
			var roomID = Viewer.currentFile.controllers.rooms.selected[0];
			var room = Viewer.currentFile.controllers.rooms.objects[roomID];
			Maptician.Scheduler.largeCalendar.rooms = Maptician.Scheduler.largeCalendar.rooms || 
				new $Map.components.schedulers.roomCalendar();
			Maptician.Scheduler.largeCalendar.rooms.open(room);
		})
	}

	this.seatButtonBindings = function(progController){
		$("#vobjectReserveSeat").click(function(){
			var seatID = Viewer.currentFile.controllers.seats.selected[0];
			var seat = Viewer.currentFile.controllers.seats.objects[seatID];
			Maptician.Scheduler.largeCalendar.seats = Maptician.Scheduler.largeCalendar.seats || 
				new $Map.components.schedulers.seatCalendar();
			Maptician.Scheduler.largeCalendar.seats.open(seat);
		})
	}

	this.selectorBindings = function(progController){ // Handles the selector checkboxes and enables/disables based on parent status

	}

	this.mapNavigationBindings = function(progController){ // Handles map zooming and panning based on mouse and keyboard input
		var viewerController = progController;

		$("#map").on("dblclick",throttle(function(e){  // Function that zooms the map in by a scalestep on doubleclick of the map
			if(e.ctrlKey && progController.isSet()){ // Only triggers on ctrl+scroll
				progController.currentFile.map.zoomMap("in",progController.currentFile.miniMap,"mouse");
				//progController.currentFile.objectSelector.updateMapSelector();
			}
		},300,false));

		$("#map").on('wheel',throttle(function(e){  // Controls zooming via scroll wheel
			if(e.ctrlKey && progController.isSet() && progController.isDrawn()){ // Only triggers on ctrl+scroll
				if(e.originalEvent.deltaY<0){progController.currentFile.map.zoomMap("in",progController.currentFile.miniMap,"mouse");} 
				else {progController.currentFile.map.zoomMap("out",progController.currentFile.miniMap,"mouse");}
			}
			//objectSelector.updateMapSelector();
		},200,false));

		$(document).on("keydown",throttle(function(e){ // Controls zoom-in and out via the plus and minus keys
			if(!$.modal.isActive() && progController.isSet() && progController.currentFile.objectSelector.selectorActive == false){
				switch(e.which){
					case 107: // Plus Key
						progController.currentFile.map.zoomMap("in",progController.currentFile.miniMap,"center");
					break;
					case 109: // Minus Key
						progController.currentFile.map.zoomMap("out",progController.currentFile.miniMap,"center");
					break;
				};
			}
		},400,true));
	
		$(document).on("keydown",throttle(function(e){
			if(!$.modal.isActive() && progController.isSet() && progController.currentFile.objectSelector.selectorActive == false){ 
				// Keys will not pan the screen when the object selector is active
				if(progController.currentFile.state.state == "openSelector"){ // Appliction state must be in open selector mode
					if(!progController.currentFile.objectsSelected()){ 
						// Checks whether map objects are selected and disables map pan if true
						switch(e.which){ // note that the map moves in the opposite direction of the arrow press
							case 37:
								progController.currentFile.map.animateMoveMap(1,0,progController.currentFile.miniMap);
							break;
							case 38:
								progController.currentFile.map.animateMoveMap(0,1,progController.currentFile.miniMap);
							break;
							case 39:
								progController.currentFile.map.animateMoveMap(-1,0,progController.currentFile.miniMap);
							break;
							case 40:
								progController.currentFile.map.animateMoveMap(0,-1,progController.currentFile.miniMap);
							break;
						}
					}
				}
			}
			return false; // prevents the default action for the key events
		},83,true)) // Throttle the map move so that the animation is roughly continuous while the button is down  

		$("#viewerFitMap").click(function(){ // Handles fitMap button on miniMap
			if(progController.isSet()){
				progController.currentFile.map.fitMap(progController.currentFile.miniMap);
			}
		})


		$("#findPeople").click(function(){
			$("#searchTableArea").children().css("display","none");
			$("#findPeopleTable,#findPeopleTable_wrapper").css("display","block");
			$Map.ViewerTables.findPeopleTable();
		})
		$("#findSeats").click(function(){
			$("#searchTableArea").children().css("display","none");
			$("#findSeatsTable,#findSeatsTable_wrapper").css("display","block");
			$Map.ViewerTables.findSeatsTable();
		})
		$("#findRooms").click(function(){
			$("#searchTableArea").children().css("display","none");
			$("#findRoomsTable,#findRoomsTable_wrapper").css("display","block");
			$Map.ViewerTables.findRoomsTable();
		})
		$("#findZones").click(function(){
			$("#searchTableArea").children().css("display","none");
			$("#findZonesTable,#findZonesTable_wrapper").css("display","block");
			$Map.ViewerTables.findZonesTable();
		})




			 
	}

	this.isSet = function(){ // Returns true if a map is set and loaded
		return this.currentFile != null;
	}

	this.isDrawn = function(){ // Returns whether the viewer is currently drawn
		return this.drawn;
	}

	this.closeFile = function(){ // Closing the current file.  Doesn't close the Viewer.
		if(this.currentFile){
			var newFileID;
			var currentFileID = this.currentFile.getMapID();
			console.log(currentFileID)
			var openFiles = $("#viewerMenu li a");
			console.log(openFiles)
			var len = openFiles.length;
			this.currentFile.clear();
			for(var i = 0;i < len;i++){ // Checks if there are any open files without the closed file id
				if(openFiles[i].id != currentFileID){
					newFileID = openFiles[i].id;
					break;
				}
			}
			if(newFileID){ // If other files are open, changes the active file to the first in the list
				this.changeFile(newFileID);
			} else { // If no other files are open, reverts to quick start mode
				this.hideMapElements();
				this.drawn = false;
				this.currentFile = undefined;
			}
			delete this.files[currentFileID];
			for(var i = 0;i < len;i++){ // Removes the li in the left nav
				if(openFiles[i].id == currentFileID){
					$(openFiles[i]).parent().remove();
					break;
				}
			}
			$("#vSelectorArea").css("display","block").siblings().css("display","none");
			$("#viewerCalendarArea").css("display","none");
		}
	}

	this.open = function(e){ // Opens the viewer
		var targetNode = $(e.target).parent();
		var targetID = e.target.id;
		var currentID = this.currentFile && this.currentFile.getMapID();
		if(this.visible){ // If the viewer is already visible, only change if a new lev-2 file was selected
			if(targetNode.hasClass("lev-2") && targetID != currentID){
				this.changeFile(targetID);
			}
		} else { // Viewer was not active before the click
			this.currentFile ? this.showMapElements() : this.hideMapElements();
			if(targetNode.hasClass("lev-2")){ // An open lev-2 file was selected
				targetNode.closest(".lev-1").addClass("selected").siblings().removeClass("selected");
				targetID != currentID ? this.changeFile(targetID) : null;
			}
			this.redraw();
		}
		this.mapArea.show();
		this.navBar.show();
		this.visible = true;
	}

	this.exit = function(){ // Closes the viewer. Hides, but doesn't close the current file.
		this.hide();
		this.mapArea.hide();
		this.navBar.hide();
		this.visible = false;
		this.drawn = false;        
	}

	this.reloadFile = function(){
		//TODO write refresh function
	}

	this.hideMapElements = function(){
		$("#vSelectorArea").show().siblings().hide();
		$("#vObjectSelector").hide();
		$("#objectType").hide();
		this.map.hide();
		this.miniMap.hide(); 
	}

	this.showMapElements = function(){
		$("#vSelectorArea").show().siblings().hide();
		$("#vObjectSelector").show()
		$("#vObjectType").show()
		this.map.show();
		this.miniMap.show();
	}

	this.showSelector = function(){
		$("#vInfoDiv>div").hide(); 
		$("#vSelectorArea").show();
	}

	this.initializations();
	this.setBindings();
	this.hasInit = true;
}
MapViewerController.prototype.zoomScale = [.1,.25,.5,.75,1,1.25,1.5,2,3,4,6,8,10,12,15];