//#################################  Mouse Router Controller #####################################################

function ViewerMouseRouter(controllers,state,map,miniMap,objectSelector,keyboardRouter,dataConnections){
	this.controllers = controllers;
	this.dragBox = new DragBoxSelector(generateUUID(),this.controllers,state);
	this.svgClickRouter = new ViewerSvgRouter(this.controllers,state,map,objectSelector,dataConnections);
	this.mouseDown = false;
	this.miniMapMouseDownBtn = false;
	this.mapMouseDown = function(event){
		this.mouseDown = true;
        if(this.controllers.architect.objectsAreSelected() && (event.target.classList[0] != "architect")){ // Deselects the walls if a non-wall is left-clicked
            this.controllers.architect.deselectAll();
        }
        if(this.controllers.zones.objectsAreSelected() && (event.target.classList[0] != "Zone")){ // Deselects the zones if a non-zone is left-clicked
            this.controllers.zones.deselectAll();
        } 
        if(this.controllers.rooms.objectsAreSelected() && (event.target.classList[0] != "Room")){ // Deselects the walls if a non-wall is left-clicked
            this.controllers.rooms.deselectAll();
        }
        if(this.controllers.seats.objectsAreSelected() && (event.target.classList[0] != "Seat")){ // Deselects the walls if a non-wall is left-clicked
            this.controllers.seats.deselectAll();
        }
        if(this.controllers.furniture.objectsAreSelected() && (event.target.classList[0] != "furniture")){ // Deselects the walls if a non-wall is left-clicked
            this.controllers.furniture.deselectAll();
        }
        if(this.controllers.kiosks.objectsAreSelected() && (event.target.classList[0] != "Kiosk")){ // Deselects the walls if a non-wall is left-clicked
            this.controllers.kiosks.deselectAll();
        }
        if(this.controllers.maplinks.objectsAreSelected() && (event.target.classList[0] != "Maplink")){ // Deselects the walls if a non-wall is left-clicked
            this.controllers.maplinks.deselectAll();
        }
	}
	
	this.documentMouseMove = function(event){	
		this.setMousePos(event);
	}

	this.mapMouseMove = function(event){
		if(this.mouseDown){
			map.constrainedMove(map.currentMousePos.x-map.handle.x,map.currentMousePos.y-map.handle.y,miniMap);			
		}
	}

	this.documentMouseDown = function(event){
		this.setMousePos(event);
        map.setHandle(); // Necessary for dragging since this gives the origin of the drag relative to the map
	}

	this.miniMapMouseDown = function(event){
		this.setMousePos(event);
		this.miniMapMouseDownBtn = true;
        if(event.target.id == "viewerMiniViewBox"){
        	miniMap.setViewHandle(state); // Sets the handle on the mini-map viewbox for dragging
        }
        if(event.target.id == "viewerMiniMapSVG"){
        	miniMap.setViewHandle(state);
        	miniMap.moveViewHandle(state);
        }		
	}

	this.miniMapMouseMove = function(event){
		this.setMousePos(event);
		if(this.miniMapMouseDownBtn){
			miniMap.mouseDrag(map);
		}
	}

	this.documentMouseUp = function(event){
		this.mouseDown = false;
		this.miniMapMouseDownBtn = false;
		switch(state.state){		
			default:
				state.setState("openSelector");
			break;
		}
	}

	this.mapMouseEnter = function(event){}

	this.deselectAll = function(){
        for(var i in this.controllers){
        	this.controllers[i].deselectAll();
        }
	}

	// takes either a touch event ('touch') or mouse event ('event')
	this.setMousePos = function(event){
		map.currentMousePos.x = event.offset.x;
		map.currentMousePos.y = event.offset.y;	
	}

}