function MapViewerInstance(file){
    this.map;
    this.miniMap;
    this.state;
    this.controllers;
    this.dataConnections;
    this.settings;
    this.objectSelector;
    this.keyboardRouter;
    this.mouseRouter;

    // #####################################  Application Functions  ############################################################
    this.load = function(file){
        this.clear();
        this.units = file.settings.unitSystem;
        $("#mapViewerTitle").html(file.name);
        this.map = new MapController(file.map.originalDim.width,file.map.originalDim.height,'Viewer');
        this.miniMap = new MiniMapController(this.map,{
            miniMapContainer:$("#viewerMiniMapContainer"),
            miniMapSVG: $("#viewerMiniMapSVG"),
            miniMap: $("#viewerMiniMap"),
            viewBox: $("#viewerMiniViewBox"),
            type: "Viewer"
        });
        this.map.setMiniMap(this.miniMap);
        this.state = new StateController(this.map);
        this.controllers = {
            architect: new ArchitectureController(this.state,this.map),
            zones: new ZoneController(this.state,this.map),
            rooms: new RoomController(this.state,this.map),
            furniture: new FurnitureController(this.state,this.map),
            seats: new SeatController(this.state,this.map),
            kiosks: new KioskController(this.state,this.map),
            maplinks: new MapLinkController(this.state,this.map),
        }
        this.dataConnections = new ConnectionController(this.controllers);
        this.settings = new SettingsController(file.id,file.name,this.map,this.minimap,file.settings.unitSystem,file.officeID,this);
        this.objectSelector = new ViewerObjectSelector(this.controllers,this.settings);
        this.keyboardRouter = new ViewerKeyboardRouterController(this.state,this.map,this.objectSelector,this.controllers,this.dataConnections);
        this.mouseRouter = new ViewerMouseRouter(
            this.controllers,
            this.state,
            this.map,
            this.miniMap,
            this.objectSelector,
            this.keyboardRouter,
            this.dataConnections
        );
        this.state.load();
        this.map.load(file.map)
        this.map.loadView();
        this.miniMap.setMiniMap();
        this.miniMap.setScale();
        this.miniMap.setMinimapView();
        this.settings.load(file.settings);
        for(var i in file.controllers){
            console.log("Loading ",i)
            try{
                this.controllers[i].load(file.controllers[i],this.state,this.dataConnections);
                this.controllers[i].program = "Viewer";
            } catch(err){
                console.log(err);
            }
        }
        this.dataConnections.load(file.id,{type:"Viewer"});
        delete this.units;
        console.log("Load Complete");
    }

    // #####################################  Helper Functions  ############################################################

    this.clear = function(){
        for(var i in this.controllers){
            this.controllers[i].removeAll();
        }
        $("#mapViewerTitle").html("");
    }

    this.getMapID = function(){
        return this.settings.getID();
    }

    this.getOfficeID = function(){
        return this.settings.getOfficeID();
    }

    this.getName = function(){
        return this.settings.getMapName();
    }

    this.getUnitSystem = function(){
        return this.settings.getUnitSystem();
    }

    this.getObject = function(controller,id){
        return this.controllers[controller].objects[id];
    }

    this.hide = function(){
        console.log('hiding viewer')
        this.map.saveView();
        for(var i in this.controllers){
            this.controllers[i].removeLayer();
        }
        $("#mapViewerTitle").html("");
    }

    this.refreshLayers = function(){
        // for(var i in this.controllers){
        //     this.controllers[i].removeLayer();
        // }        
        // for(var i in this.controllers){
        //     this.controllers[i].redrawLayer();
        // }           
    }

    this.redraw = function(){
        console.log('redraw')
        this.map.reloadMap();
        this.settings.setUnit();
        for(var i in this.controllers){
            this.controllers[i].redrawLayer();
        }        
        this.objectSelector.selectSVG();
        this.map.loadView();
        this.miniMap.setMiniMap();
        this.miniMap.setScale();
        this.miniMap.setMinimapView();
        $("#mapViewerTitle").html(this.getName());
    }

    this.objectsSelected = function(){
        for(var i in this.controllers){
            if(this.controllers[i].objectsAreSelected()){
                return true;
            }
        }
        return false;
    }

    this.goToPoint = function(point){
        this.miniMap.setMiniMap();
        this.miniMap.setScale();
        this.miniMap.setMinimapView();
        this.map.goToPoint(point);
    }

    this.load(file);
    this.objectSelector.selectSVG();
}