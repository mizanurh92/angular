Maptician.ViewerTables = {};

Maptician.ViewerTables.findPeopleTable = function(){
	var table = Maptician.ViewerTables.findPeopleTable;
	if(!Maptician.Viewer.isSet()){return;}
	var data;
	var dataArray = [];

	if(table.id){
		if(table.id != Maptician.Viewer.currentFile.id){
			table.id = Maptician.Viewer.currentFile.id;
			Maptician.ViewerTables.FindPeopleTable.destroy();
			data = Maptician.Viewer.currentFile.dataConnections.employees;
			for(var i in data){dataArray.push(data[i]);}
		} else {
			return;
		}
	} else {
		table.id = Maptician.Viewer.currentFile.id;
		data = Maptician.Viewer.currentFile.dataConnections.employees;
		for(var i in data){dataArray.push(data[i]);}
	}

	Maptician.ViewerTables.FindPeopleTable = $("#findPeopleTable").DataTable({
		data:dataArray,
		paging:false,
		scrollCollapse:true,
		scrollY:"500px",
		select: true,
		"language":{
			"info": "Showing Employees _START_ to _END_ of _MAX_",
			"lengthMenu": "Show _MENU_ Employees",
			"search": "Filter:"
		},
		columns:[
			{
				data:{},
				sortable:false,
				'className':'tableProfileImage',
				render: function(employee){
					return '<div><img src="'+employee.profileImages.smallProfile+'"></div>';
				}
			},
			{
				data:{}, // Name
				'className':'tableCenterText',
				render: function(employee){
					return employee.first + " " + employee.last;
				}
			},
			{
				data:{}, // Title
				'className':'tableCenterText',
				render: function(employee){
					return employee.employee.title;
				}
			},
			{
				data:{}, // Location
				sortable:false,
				'className':'tableCenterText',
				render: function(employee){
					if(employee.seats && employee.seats.length > 0){
						return "<i class='fa fa-crosshairs fa-lg findPerson'></i>";
					} else {
						return "";
					}
				}
			},
		],
		dom: '<"#employeeListModalTableFilter" and f>rtp'
	})

	if(table.hasInit){

	} else {
		
		// Add event listener for profile image buttons
		$('#findPeopleTable tbody').on('click', '.findPerson', function () {
			var tr = $(this).closest('tr');
			var row = Maptician.ViewerTables.FindPeopleTable.row( tr );
			var data = row.data();
			var seatID = data.seats[0];
			var seat = Maptician.Viewer.currentFile.dataConnections.seats[seatID];
			var state = Maptician.Viewer.currentFile.state;
			Maptician.Viewer.currentFile.controllers.seats.selectOne(seatID,state);
			var loc = seat.points[0].getPoint();
			Maptician.Viewer.currentFile.map.goToPoint(loc);
		});

		table.hasInit = true;
	}
}

Maptician.ViewerTables.findSeatsTable = function(){
	var table = Maptician.ViewerTables.findSeatsTable;
	if(!Maptician.Viewer.isSet()){return;}
	var data;
	var dataArray = [];

	data = Maptician.Viewer.currentFile.dataConnections.seats;
	for(var i in data){dataArray.push(data[i]);}

	if(Maptician.ViewerTables.FindSeatsTable){
		Maptician.ViewerTables.FindSeatsTable.clear().rows.add(dataArray).draw();
		return;
	}

	Maptician.ViewerTables.FindSeatsTable = $("#findSeatsTable").DataTable({
		data:dataArray,
		select: true,
		"language":{
			"info": "Showing Seats _START_ to _END_ of _MAX_",
			"lengthMenu": "Show _MENU_ Seats",
			"search": "Filter:"
		},
		scrollY:$("#vSearchArea").height() - 60,		
		deferRender:true,
		scroller:true,
		paging:true,
		columns:[
			{
				data:{}, // Name
				width: '110px',
				'className':'tableCenterText',
				render: function(seat){
					return seat.name;
				}
			},
			{
				data:{},
				sortable:false,
				width: '50px',
				'className':'tableProfileImage',
				render: function(seat){
					return '<div><img src="'+seat.imageLink+'"></div>';
				}
			},
			{
				data:{}, // Status
				width: '110px',
				'className':'tableCenterText',
				render:function(seat){
					if(seat.assignmentStatus == "Assigned"){
						return seat.user.first + ' ' + seat.user.last;
					} else if(seat.reservable){
						return "Reservable";
					} else{
						return "Unassigned";
					}
				}
			},
			{
				data:{}, // Location
				sortable:false,
				width: '30px',
				'className':'tableCenterText',
				render: function(seat){
					return "<i class='fa fa-crosshairs fa-lg findSeat'></i>";
				}
			},
		],
		dom: 'rt',
	})

	if(table.hasInit){

	} else {
		
		// Add event listener for profile image buttons
		$('#findSeatsTable tbody').on('click', '.findSeat', function () {
			var tr = $(this).closest('tr');
			var row = Maptician.ViewerTables.FindSeatsTable.row( tr );
			var seat = row.data();
			var seatID = seat.id;
			var state = Maptician.Viewer.currentFile.state;
			Maptician.Viewer.currentFile.controllers.seats.selectOne(seatID,state);
			var loc = seat.points[0].getPoint();
			Maptician.Viewer.currentFile.map.goToPoint(loc);
		});

		table.hasInit = true;
	}
}

Maptician.ViewerTables.findRoomsTable = function(){
	var table = Maptician.ViewerTables.findRoomsTable;
	if(!Maptician.Viewer.isSet()){return;}
	var data;
	var dataArray = [];

	data = Maptician.Viewer.currentFile.dataConnections.rooms;
	for(var i in data){dataArray.push(data[i]);}

	if(Maptician.ViewerTables.FindRoomsTable){
		Maptician.ViewerTables.FindRoomsTable.clear().rows.add(dataArray).draw();
		return;
	}
	
	Maptician.ViewerTables.FindRoomsTable = $("#findRoomsTable").DataTable({
		data:dataArray,
		paging:false,
		scrollCollapse:true,
		scrollY:"500px",
		select: true,
		"language":{
			"info": "Showing Rooms _START_ to _END_ of _MAX_",
			"lengthMenu": "Show _MENU_ Rooms",
			"search": "Filter:"
		},
		columns:[
			{
				data:{}, // Name
				width: '100px',
				'className':'tableCenterText',
				render: function(room){
					return room.name;
				}
			},
			{
				data:{}, // Zone
				width: '100px',
				'className':'tableCenterText',
				render: function(room){
					if(room.zones.length>0){
						return room.zones[0].name;
					} else {
						return '';
					}
				}
			},
			{
				data:{}, // Area
				width: '70px',
				'className':'tableCenterText',
				render: function(room){
					return renderArea(room.area);
				}
			},
			{
				data:{}, // Find
				sortable:false,
				width: '30px',
				'className':'tableCenterText',
				render: function(room){
					return "<i class='fa fa-crosshairs fa-lg findRoom'></i>";
				}
			},
		],
		dom: '<"#employeeListModalTableFilter" and f>rtp'
	})

	if(table.hasInit){

	} else {
		
		// Add event listener for profile image buttons
		$('#findRoomsTable tbody').on('click', '.findRoom', function () {
			var tr = $(this).closest('tr');
			var row = Maptician.ViewerTables.FindRoomsTable.row( tr );
			var room = row.data();
			var roomID = room.id;
			var state = Maptician.Viewer.currentFile.state;
			Maptician.Viewer.currentFile.controllers.rooms.selectOne(roomID,state);
			var loc = room.getCenterPoint();
			Maptician.Viewer.currentFile.map.goToPoint(loc);
		});

		table.hasInit = true;
	}
}

Maptician.ViewerTables.findZonesTable = function(){
	if(!Maptician.Viewer.isSet()){return;} // Cancels the call if the viewer isn't loaded
	var table = Maptician.ViewerTables.findZonesTable;
	var data;
	var dataArray = [];

	data = Maptician.Viewer.currentFile.dataConnections.zones;
	for(var i in data){dataArray.push(data[i]);}

	if(Maptician.ViewerTables.FindZonesTable){
		Maptician.ViewerTables.FindZonesTable.clear().rows.add(dataArray).draw();
		return;
	}

	Maptician.ViewerTables.FindZonesTable = $("#findZonesTable").DataTable({
		data:dataArray,
		paging:false,
		scrollCollapse:true,
		scrollY:"500px",
		select: true,
		"language":{
			"info": "Showing Rooms _START_ to _END_ of _MAX_",
			"lengthMenu": "Show _MENU_ Rooms",
			"search": "Filter:"
		},
		columns:[
			{
				data:{}, // Name
				width: '100px',
				'className':'tableCenterText',
				render: function(zone){
					return zone.name;
				}
			},
			{
				data:{}, // Seats
				width: '50px',
				'className':'tableCenterText',
				render: function(zone){
					if(Object.keys(zone.seats).length>0){
						return Object.keys(zone.seats).length;
					} else {
						return '';
					}
				}
			},
			{
				data:{}, // Rooms
				width: '50px',
				'className':'tableCenterText',
				render: function(zone){
					if(zone.rooms.length>0){
						return zone.rooms.length;
					} else {
						return '';
					}
				}
			},
			{
				data:{}, // Area
				width: '70px',
				'className':'tableCenterText',
				render: function(zone){
					return renderArea(zone.area);
				}
			},
			{
				data:{}, // Find
				width: '30px',
				sortable:false,
				'className':'tableCenterText',
				render: function(zone){
					return "<i class='fa fa-crosshairs fa-lg findZone'></i>";
				}
			},
		],
		dom: '<"#employeeListModalTableFilter" and f>rtp'
	})

	if(table.hasInit){

	} else {
		
		// Add event listener for profile image buttons
		$('#findZonesTable tbody').on('click', '.findZone', function () {
			var tr = $(this).closest('tr');
			var row = Maptician.ViewerTables.FindZonesTable.row( tr );
			var zone = row.data();
			var zoneID = zone.id;
			var state = Maptician.Viewer.currentFile.state;
			Maptician.Viewer.currentFile.controllers.zones.selectOne(zoneID,state);
			var loc = zone.getCenterPoint();
			Maptician.Viewer.currentFile.goToPoint(loc);
		});

		table.hasInit = true;
	}
}