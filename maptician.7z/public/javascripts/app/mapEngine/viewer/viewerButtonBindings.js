Maptician.inits.viewerButtonControls = function(progController){

    // ########################################## Load Map #################################################
            
    $("#viewerLoadMap").click(function(){ // Gets the file names and displays them in a load files modal
        if(Maptician.Viewer){
            Maptician.ModalTables.loadViewerFileTable();
        }
    })

    // ########################################## Close Map #################################################

    $("#viewerCloseMap").click(function(){
        if(Maptician.Viewer){
            Maptician.Viewer.closeFile();
        }
    })

    // // ########################################## Refresh Map #################################################

    $("#viewerCloseMap").click(function(){
        if(Maptician.Viewer){
            Maptician.Viewer.reloadFile();
        }
    })

    // // ########################################## Print Map #################################################

    $("#viewerPrintMap").click(function(){
        if(Maptician.Viewer){
            Maptician.inits.printDiv("map");
        }
    })

    // // ########################################## Download Map #################################################

    $("#viewerDownloadMap").on("click", function(){
        if(Maptician.Viewer){
            var $svg = $('#mapDesigner');
            Maptician.inits.convertToPdf($svg[0], function (doc) {
            // Get the file name and download the pdf
            var filename = "officeMapSVG.pdf";
            Maptician.inits.downloadPdf(filename, doc);
        });
        }
    })
    $("#addNewReq").click(function(){// Gets the file names and displays them in a load files modal
        var selectedDetails=document.getElementsByClassName("mapObjectSelector activeDisplay");
        if(selectedDetails[0]){
            $('#addNewRequestModal').modal({
                  clickClose: false
              });
           var selectedtype=selectedDetails[0].firstChild.innerHTML;
           selectedtype = selectedtype.replace("\:", "");
            $("#amenetiesRow").css("display","none");
            switch(selectedtype){
                case "Seat":
                     var seatNo=$("#vObjectSeatName").html();
                     var empName=$("#vObjectSeatAssignment").html();
                     var empEmail=$("#vObjectAssignedEmail").html();
                     var empID=$("#vObjectAssignedEmpID").html();
                     $("#issueRaisedFor").html(selectedtype+" "+seatNo);
                break;
                case "Room Name":
                    var roomName=$("#vObjectAreaName").html();
                    $("#issueRaisedFor").html(roomName);
                    $("#equipmentsRow").css("display","table-row");
                    /*Maptician.assets.equipment = '';
                    for (var i=0;i<Maptician.assets.equipments.length;i++){
                       Maptician.assets.equipment += '<option value="'+ Maptician.assets.equipments[i] + '">' + Maptician.assets.equipments[i] + '</option>';
                    }
                    $('#equipments').append(Maptician.assets.equipment);
                    for (var i=0;i<Maptician.assets.ameneties.length;i++){
                       Maptician.assets.amenety += '<option value="'+ Maptician.assets.ameneties[i] + '">' + Maptician.assets.ameneties[i] + '</option>';
                    }
                    $('#ameneties').append(Maptician.assets.amenety);*/
                break;   
                case "Name":
                    var roomName=$("#vObjectName").html();
                    $("#issueRaisedFor").html(roomName);
                    $("#equipmentsRow").css("display","table-row");
                break;     
                case "Zone Name":
                    var roomName=$("#vObjectAreaName").html();
                    $("#issueRaisedFor").html(roomName);
                    $("#amenetiesRow").css("display","table-row");
                break;  
            }
        }
        else{
            swal({
                title: 'Sorry!',
                text: 'Please select any map object',
                timer: 10000,
                showConfirmButton: true,
                type: 'error'
            })
        }
    })
    $("#addNewRequestModal").validate({
            rules: {
                categories: {
                    required: true
                },
                severity: {
                    required: true
                },
                description: {
                    required: true,
                    maxlength: 100,
                    minlength:2
                }
            },
            messages: { 
              categories: "Please select a Category", 
              severity:"Please select a Severity", 
              description: {
                required:"Description field is required",
                validLength: "Please enter upto 100 chars"
                },             
            },
            submitHandler:function(form,event){
                var requestData={
                        description:$("#description").val(),
                        officeID:$Map.Viewer.currentFile.getOfficeID(),
                        officeName:Maptician.ModalTables.selectedOfficeName,
                        requestedBy:$("#profileName strong").html(),
                        mapname:$("#mapViewerTitle").html(),
                        mapID:$Map.Viewer.currentFile.getMapID(),
                        name:$("#issueRaisedFor").html(),
                        severity:$("#severity").val(),
                        categoryName:$("#categories").val(),
                        equipment:$("#equipments").val()
                    }
                    var data={data:requestData};
                    console.log(data);
                $.ajax({
                    type: "POST",
                    url: "api/maintenance/request/saveMaintenanceRequest",
                    data: data
                })
                .then(function(result){
                    console.log(result)
                   if(result){
                        swal({
                            title: 'Success',
                            text: 'Your request has been submitted sucessfully',
                            showConfirmButton: true,
                            type: 'success',
                            timer: 10000,
                            confirmButtonText: 'OK',
                        })
                        Maptician.inits.closeReqPopUp("addNewRequestModal");
                    } else {
                        swal({
                            title: 'Sorry!',
                            text: 'Something went wrong while sending your message.  Please try again later.',
                            timer: 10000,
                            showConfirmButton: true,
                            type: 'error'
                        })                      
                    }
                })
                .catch(function(err){
                    $.modal.close();
                    swal({
                        title: 'Sorry!',
                        text: 'Something went wrong while sending your message.  Please try again later.',
                        timer: 10000,
                        showConfirmButton: true,
                        type: 'error'
                    })
                })

                //$.modal.close();
            }
        })
    $("#cancelReqBtn").click(function(){
        Maptician.inits.closeReqPopUp("addNewRequestModal");
    })
}
Maptician.inits.closeReqPopUp=function(divId){
        $.modal.close();
        document.getElementById(divId).reset();
        $("label.error").remove();
}
Maptician.inits.printDiv=function(divId){

    var divToPrint=document.getElementById(divId);
    var backgroundContainer=divToPrint.lastChild;
    divToPrint.removeChild(backgroundContainer);//remove background svg
    var newWin=window.open('','Print-Window');

    newWin.document.open();

    newWin.document.write('<html><body onload="window.print()">'+divToPrint.innerHTML+'</body></html>');

    newWin.document.close();
    divToPrint.appendChild(backgroundContainer);
    setTimeout(function(){newWin.close();},1);

}
Maptician.inits.convertToPdf=function(svg, callback){
        // Call svgAsDataUri from saveSvgAsPng.js
    window.svgAsDataUri(svg, {}, function (svgUri) {
        // Create an anonymous image in memory to set 
        // the png content to
        var $image = $('<img>'),
            image = $image[0];

        // Set the image's src to the svg png's URI
        image.src = svgUri;
        image.crossorigin="*";
        //console.log(image);
        $image.on('load', function () {
            // Once the image is loaded, create a canvas and
            // invoke the jsPDF library
            var canvas = document.createElement('canvas'),
                ctx = canvas.getContext('2d'),
                doc = new jsPDF('portrait', 'pt', 'a2'),
                imgWidth = image.width,
                imgHeight = image.height;

                pageHeight= doc.internal.pageSize.height;
                console.log(pageHeight);
                // Before adding new content
                //y = 1800 // Height position of new content
                
            // Set the canvas size to the size of the image
            canvas.width = imgWidth;
            canvas.height = imgHeight;
            // Draw the image to the canvas element
            ctx.fillStyle = "#FFFFFF";
            ctx.fillRect(0, 0, canvas.width, canvas.height);
            ctx.drawImage(image, 0, 0, imgWidth, imgHeight);
            // Add the image to the pdf
            var dataUrl = canvas.toDataURL('image/jpeg');
            doc.addImage(dataUrl, 'JPEG', 0, 0, imgWidth, imgHeight);
            if (imgHeight >= pageHeight)
                {
                  doc.addPage();
                  imgHeight = 0 // Restart height position
                }
            callback(doc);
        });

    });
}
 Maptician.inits.downloadPdf = function(fileName, pdfDoc) {
    // Dynamically create a link
    var $link = $('<a>'),
        link = $link[0],
        dataUriString = pdfDoc.output('dataurlstring');

    // On click of the link, set the HREF and download of it
    // so that it behaves as a link to a file
    $link.on('click', function () {
        link.href = dataUriString;
        link.download = fileName;
        $link.detach(); // Remove it from the DOM once the download starts
    });

    // Add it to the body and immediately click it
    $('body').append($link);
    $link[0].click();
}