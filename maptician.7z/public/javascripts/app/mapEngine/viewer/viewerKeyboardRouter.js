//#################################  Viewer Keyboard Router #####################################################

function ViewerKeyboardRouterController(state,map,objectSelector,controllers,dataConnections){
	this.keyUp = function(event){
        if(objectSelector.selectorActive == false){
        }
	}
	this.keyPress = function(event){
        if(objectSelector.selectorActive == false){
            switch(event.which){
	            case 27: // Escape Key
	                try{
		                for(var i in controllers){
		                	controllers[i].deselectAll();
		                }                	
	                } catch(err){
	                	console.log(err);
	                }
	                state.setState("openSelector");
	                objectSelector.updateSelector("clear");
	            break;
	            case 13:  // Enter Key
	            	switch(state.state){
		                	
	            	}
	            	break;
	            case 37: // Left Arrow

	            	break;
	            case 38: // Up Arrow

	            	break;
	            case 39: // Right Arrow

	            	break;
	            case 40: // Down Arrow

	            	break;
        	}
        	objectSelector.updateSelector();
        }
	}
}