Maptician.Scheduler = Maptician.Scheduler || {};
Maptician.Scheduler.largeCalendar = {};

$Map.components = $Map.components || {};
$Map.components.schedulers = $Map.components.schedulers || {};

$Map.components.schedulers.seatCalendar = function(){
	this.namespace = 'seatCalendar';
	this.type = "seats";
	this.currentObj = null;
	this.url = "/api/reservations/reservations";
	this.saveURL = "/api/reservations/savereservation";
	this.updateURL = "/api/reservations/changereservation";
	this.removeURL = "/api/reservations/deleteReservation";
	this.calendarArea = $("#viewerCalendarArea");
	this.calendarDiv = $("#viewerLargeCalendar");
	this.calendarNav = $("#vMeetingMaker");
	this.navHeader = this.calendarNav.children('.header');
	this.reservationTitle = $("#reservationName");
	this.reservationOwner = $("#scheduledBy");
	this.privacyToggle = $("#reservationPrivacyToggle");
	this.bulletinToggle = $("#reservationBulletinToggle");
	this.bulletinMessage = $("#reservationBulletinMessage");
	this.start = $("#schedulerStart");
	this.end = $("#schedulerEnd");
	this.duration = $("#largeScheduleDuration");
	this.saveButton = $("#largeSchedulerSave");
	this.closeButton = $("#largeSchedulerCancel");
	this.deleteButton = $("#largeSchedulerDelete");
	this.objInfoHeader = $("#resObjInfoDivider");
	this.objName = $("#resObjName");
	this.objDept = $("#resObjDept");
	this.objCapacity = $("#resObjCapacity");
	this.objSize = $("#resObjSize");
	this.objType = $("#resObjType");
	this.objEquipment = $("#resObjEquipment");
	this.objAmeneties = $("#resObjAmeneties");
	this.objAccessibility = $("#resObjAccessibility");
	this.CalendarObj = null;

	var Calendar = this;

	this.open = function(obj){
		this.navHeader.html('Seat Reservations');
		this.currentObj = obj; // Seat object
		this.setFields(); // Initializes date widgets
		this.setProperties(); // Loads info about seat
		this.setBindings();
		this.calendarArea.show();
		this.loadCalendar();
	}

	this.exit = function(){
		this.currentObj = null;
		this.CalendarObj.fullCalendar('destroy'); // Kills the calendar completely
		this.CalendarObj = null;
		this.calendarArea.hide();
		this.unsetBindings();
		this.unsetFields();
	}

	this.refresh = function(){
		this.CalendarObj.fullCalendar('removeEvents');
		this.CalendarObj.fullCalendar('refetchEvents');
	}

	this.loadCalendar = function(){
		Calendar.CalendarObj = this.calendarDiv.fullCalendar({
		    eventSources: [
		        {
		            url: Calendar.url,
		            type: 'GET',
		            data: function(){
		            	return {
		            		id: Calendar.currentObj.id,
		            		type: Calendar.type
		            	}
		            },
		            error: function(err) {
		                console.log('There was an error while fetching events!');
		            },
		        }
		    ],
			defaultView:'agendaWeek',
			header:{
				left: 'prev,next today',
				center: 'title',
				right: 'month,agendaWeek,agendaDay'
			},
			height: Calendar.calendarArea.height(),
			unselectCancel:'#vMeetingMaker,.fc-addToCalendar-button,.mbsc-mobiscroll',
			timezone:'local',
			editable: true,
			selectable: true,
			selectHelper: true,
			selectOverlap: false,
			allDaySlot:false,
		    windowResize: function(view) {
		        Calendar.CalendarObj.fullCalendar('option', 'height', Calendar.calendarArea.height());
		    },
			// This controls the population of the side selector on dragging from the calendar
			select: function(start,end,jsEvent,view,resource){ 
				// If an existing event had been selected, reset fields
				Calendar.eventSelected ? Calendar.resetFields() : null;
				Calendar.autoSelect = null;
				Calendar.selectCreationMode = true;
				Calendar.clearSelected();
				Calendar.setTimeSelectors(start,end);
				Calendar.CalendarObj.fullCalendar('rerenderEvents'); // Necessary???
				Calendar.setModifyAuthorization(true);
			},
			unselect:function(view,jsEvent){
				Calendar.selectCreationMode = false;
			},
			eventDrop: function (event, delta, revertFunc, jsEvent, ui, view) {
				Calendar.changeEvent(event);
			},
			eventResize: function (event, delta, revertFunc, jsEvent, ui, view) {
				Calendar.changeEvent(event);
			},
			eventDataTransform:function(event){
				event.start = moment(event.start).local().format();
				event.end = moment(event.end).local().format();
				event.id = event.resID;
				if(event.resID === Calendar.autoSelect){ event.className.push("selected"); }
				return event;
			},
			eventClick:function(event,jsEvent,view){
				Calendar.autoSelect = null;
				Calendar.clearSelected();
				Calendar.selectExistingEvent(event);
				Calendar.setTimeSelectors(event.start,event.end);
				Calendar.CalendarObj.fullCalendar('updateEvent',event);
			},
		});
	}

	this.clearSelected = function(){
		this.CalendarObj.fullCalendar('clientEvents',function(event){ // Unselects events
			var index = event.className.indexOf('selected'); // Finds if the event is selected
			if(index > -1){ 
				event.className.splice(index,1);
				Calendar.CalendarObj.fullCalendar('updateEvent',event);
			} // Removes the 'selected' class
		})		
	}

	this.setTimeSelectors = function(start,end){
		// Calculates the current timezone start and end for the range
		var momentStart,momentEnd,diff;
		momentStart = start._ambigZone ? start.add(start._d.getTimezoneOffset(),'minutes') : start;
		momentEnd = end._ambigZone ? end.add(end._d.getTimezoneOffset(),'minutes') : end;
		diff = momentEnd.preciseDiff(momentStart);
		
		// Sets the start/end/duration to the selected range
		this.duration.html(diff);
		this.start.mobiscroll('setVal',new Date(momentStart.valueOf()),true);
		this.end.mobiscroll('setVal',new Date(momentEnd.valueOf()),true);		
	}

	this.setModifyAuthorization = function(authorized){
		if(authorized){
			this.reservationTitle.prop("disabled",false);
			this.privacyToggle.closest("tr").show();
			this.start.mobiscroll('enable');
			this.end.mobiscroll('enable');
			this.saveButton.removeClass("disabled");
			this.deleteButton.removeClass("disabled");
		} else {
			this.reservationTitle.prop("disabled",true);
			this.privacyToggle.closest("tr").hide();
			this.start.mobiscroll('disable');
			this.end.mobiscroll('disable');
			this.saveButton.addClass("disabled");
			this.deleteButton.addClass("disabled");			
		}		
	}

	this.selectExistingEvent = function(event){
		event.className.push("selected");
		this.eventSelected = true;
		this.saveButton.html("Update"); // Save should become "Update"
		this.reservationTitle.val(event.title);
		this.setModifyAuthorization(event.authorized);
		if(event.authorized){
			this.privacyToggle.prop("checked",event.private);
			this.reservationOwner.html("").closest("tr").hide();
		} else {
			this.reservationOwner.html(event.userName).closest("tr").show();
		}
	}

	this.warnOfScheduleConflict = function(){
		swal({
			title: "Scheduling Conflict",
			text: "Your requested reservation conflicts with another reservation." + 
				" Please choose an alternative reservation time.",
			type: "warning",
			confirmButtonColor: "#525252",    
			confirmButtonText: "OK",
			closeOnConfirm: true,
		})
	}

	this.warnOfNegativeTime = function(){
		swal({
			title: "Invalid Times",
			text: "The end of your requested reservation occurs before its start." + 
				" Please choose an alternative reservation time.",
			type: "warning",
			confirmButtonColor: "#525252",    
			confirmButtonText: "OK",
			closeOnConfirm: true,
		})
	}

	this.checkForIntersection = function(checkEvent){
		var start = checkEvent.start;
		var end = checkEvent.end;
		var intersections = Calendar.CalendarObj.fullCalendar('clientEvents',function(event){
			return event.end > start && event.start < end && checkEvent.resID != event.resID
		})
		return intersections.length ? true : false;		
	}

	this.formatEvent = function(event){ // Creates a database event entry out of a FullCalendar Event
		return {
			resID: event.resID,
			seatID: event.seatID,
			title: event.title,
			private: event.private,
			start: event.start.format(),
			end: event.end.format(),
			userID: event.userID || null, // null if a new event, will be added by the server
			mapID: $Map.Viewer.currentFile.getMapID(),
			officeID: $Map.Viewer.currentFile.getOfficeID(),
			deptID: this.currentObj.department.deptID
		}
	}

	this.addToCalendar = function(){ // Creates an event out of form data and saves to database
		var startMoment = moment(this.start.mobiscroll('getVal'));
		var endMoment = moment(this.end.mobiscroll('getVal'));
		if(startMoment > endMoment){
			this.warnOfNegativeTime();
			return;
		}		
		var resID = generateUUID();
		var event = {
			id: resID, // Used internally by the calendar
			resID: resID,
			seatID: this.currentObj.id,
			title  : this.reservationTitle.val(),
			private: this.privacyToggle.prop("checked"),
			start  : startMoment,
			end : endMoment,
		};

		if(this.checkForIntersection(event)){ // Checks if the event has a conflict
			this.warnOfScheduleConflict(); // Warns user of conflict
			return; // Aborts the save process
		}

		this.saveEvent(event); // Sends the event to the server

		Calendar.CalendarObj.fullCalendar( 'unselect' );
	}

	this.updateEvent = function(event){
		var startMoment = moment(this.start.mobiscroll('getVal'));
		var endMoment = moment(this.end.mobiscroll('getVal'));
		if(startMoment > endMoment){
			this.warnOfNegativeTime();
			return;
		}
		var updated = {
			id: event.resID, // Used internally by the calendar
			resID: event.resID,
			seatID: this.currentObj.id,
			userID: event.userID,
			title  : this.reservationTitle.val(),
			start  : startMoment,//.format(),
			end : endMoment,//.format(),
		};

		if(this.checkForIntersection(event)){ // Checks if the event has a conflict
			this.warnOfScheduleConflict(); // Warns user of conflict
			return; // Aborts the save process
		}

		this.changeEvent(updated);		
	}

	this.saveEvent = function(event){
		$.ajax({
			type:"POST",
			data:{
				reservation: this.formatEvent(event),
				type: this.type
			},
			url: this.saveURL,
			success: function(result){
				var start = moment(result.start);
				var end = moment(result.end);
				Calendar.setTimeSelectors(start,end);
				Calendar.autoSelect = event.resID;
				Calendar.CalendarObj.fullCalendar('refetchEvents');
				var mapID = $Map.Viewer.currentFile.getMapID();
				$Map.Viewer.currentFile.dataConnections.loadReservations(mapID);
			}, // End of Success callback
			error: function(error){
				console.log('Error saving reservations');
				if(error.responseJSON && error.responseJSON.conflict){
					Calendar.warnOfScheduleConflict();
				}
			}
		}) // End of AJAX Call 		
	}

	this.changeEvent = function(event){ // Updates an existing event with the server 
		$.ajax({
			type:"POST",
			data:{
				reservation: this.formatEvent(event),
				type: this.type,
			},
			url: this.updateURL,
			success: function(result,test1,test2){
				var start = moment(result.start);
				var end = moment(result.end);
				Calendar.setTimeSelectors(start,end);
				Calendar.autoSelect = event.resID; 
				Calendar.CalendarObj.fullCalendar('refetchEvents');
				var mapID = $Map.Viewer.currentFile.getMapID();
				$Map.Viewer.currentFile.dataConnections.loadReservations(mapID);
				// TODO get better access to controller and mapID
			}, // End of Success callback
			error: function(error){
				console.log('Error saving reservations');
				if(error.responseJSON && error.responseJSON.conflict){
					Calendar.warnOfScheduleConflict();
				}
			}
		}) // End of AJAX Call 
	}

	this.removeEvent = function(){
		var event = Calendar.CalendarObj.fullCalendar('clientEvents',function(event){
			return event.className.indexOf('selected') != -1;
		})[0]

		if(event === undefined || event.authorized === false){return;}

		$.ajax({
			type:"DELETE",
			data:{
				reservation: this.formatEvent(event),
				type: this.type
			},
			url: this.removeURL,
			success: function(result){
				Calendar.CalendarObj.fullCalendar('refetchEvents');
				var mapID = $Map.Viewer.currentFile.getMapID();
				$Map.Viewer.currentFile.dataConnections.loadReservations(mapID);
			}, // End of Success callback
			error: function(error){
				console.log('Error deleting reservations');
			}
		}) // End of AJAX Call 		
	}

	this.resetFields = function(){ // Resets fields when creating a new event
		this.reservationTitle.val('');
		//this.bulletinMessage.val('');
		this.privacyToggle.prop("checked",false);
		//this.bulletinToggle.prop("checked",false);
		this.reservationOwner.html("").closest("tr").hide();
		this.saveButton.html("Add"); // Save should become "Add"
		this.eventSelected = false;
	}

	this.setFields = function(){
		this.start.add(this.end).mobiscroll().datetime({
			theme:'mobiscroll',
			display:'bubble',
			buttons:['now','cancel','set'],
			steps: { 
			    minute: 5,
			    zeroBased: true
			}
		})		
	}

	this.unsetFields = function(){
		
		this.start.add(this.end).mobiscroll('destroy');
	}

	this.setProperties = function(){
		// Ensure inapplicable (generally room based) fields are hidden
		this.bulletinToggle.closest("tr").hide();
		this.bulletinMessage.html("").closest("tr").hide();
		this.objCapacity.html("").closest("tr").hide();
		this.objSize.html("").closest("tr").hide();
		this.objEquipment.html("").closest("tr").hide(); // Need to add for seat
		this.objAmeneties.html("").closest("tr").hide(); // Need to add for seat
		this.objAccessibility.html("").closest("tr").hide(); // Need to add for seat
		this.objType.html("").closest("tr").hide(); // Need to add for seat
		
		// Objects to Populate
		this.objName.html(this.currentObj.name);
		this.objDept.html(this.currentObj.department.deptName);
	}

	this.setBindings = function(){
		this.saveButton.on("click." + this.namespace,function(event){
			if(Calendar.selectCreationMode){
				Calendar.addToCalendar();
			} else {
				var event = Calendar.CalendarObj.fullCalendar('clientEvents',function(event){
					return event.className.indexOf('selected') != -1;
				})
				if(event.length && event[0].authorized){
					Calendar.updateEvent(event[0]);
				}
			}
		})

		this.closeButton.on("click." + this.namespace,function(){
			Calendar.exit();
		})

		this.deleteButton.on("click." + this.namespace,function(){
			Calendar.removeEvent();
		})
	}

	this.unsetBindings = function(){
		this.saveButton.off(this.namespace);
		this.closeButton.off(this.namespace);
		this.deleteButton.off(this.namespace);
	}
}
$Map.components.schedulers.seatCalendar.prototype.constructor = $Map.components.schedulers.seatCalendar;

$Map.components.schedulers.roomCalendar = function(){
	this.namespace = 'roomCalendar';
	this.type = "rooms";
	this.currentObj = null;
	this.url = "/api/reservations/reservations";
	this.saveURL = "/api/reservations/savereservation";
	this.updateURL = "/api/reservations/changereservation";
	this.removeURL = "/api/reservations/deleteReservation";
	this.calendarArea = $("#viewerCalendarArea");
	this.calendarDiv = $("#viewerLargeCalendar");
	this.calendarNav = $("#vMeetingMaker");
	this.navHeader = this.calendarNav.children('.header');
	this.reservationTitle = $("#reservationName");
	this.reservationOwner = $("#scheduledBy");
	this.privacyToggle = $("#reservationPrivacyToggle");
	this.bulletinToggle = $("#reservationBulletinToggle");
	this.bulletinMessage = $("#reservationBulletinMessage");
	this.start = $("#schedulerStart");
	this.end = $("#schedulerEnd");
	this.duration = $("#largeScheduleDuration");
	this.saveButton = $("#largeSchedulerSave");
	this.closeButton = $("#largeSchedulerCancel");
	this.deleteButton = $("#largeSchedulerDelete");
	this.objInfoHeader = $("#resObjInfoDivider");
	this.objName = $("#resObjName");
	this.objDept = $("#resObjDept");
	this.objCapacity = $("#resObjCapacity");
	this.objSize = $("#resObjSize");
	this.objType = $("#resObjType");
	this.objEquipment = $("#resObjEquipment");
	this.objAmeneties = $("#resObjAmeneties");
	this.objAccessibility = $("#resObjAccessibility");
	this.CalendarObj = null;

	var Calendar = this;

	this.open = function(obj){
		this.navHeader.html('Room Reservations');
		this.currentObj = obj; // Room object
		this.setFields(); // Initializes date widgets
		this.setProperties(); // Loads info about room
		this.setBindings();
		this.calendarArea.show();
		this.loadCalendar();
	}

	this.exit = function(){
		this.currentObj = null;
		this.CalendarObj.fullCalendar('destroy'); // Kills the calendar completely
		this.autoSelect = null;
		this.calendarArea.hide();
		this.unsetBindings();
		this.unsetFields();
	}

	this.refresh = function(){
		this.CalendarObj.fullCalendar('removeEvents');
		this.CalendarObj.fullCalendar('refetchEvents');
	}

	this.loadCalendar = function(){
		Calendar.CalendarObj = this.calendarDiv.fullCalendar({
		    eventSources: [
		        {
		            url: Calendar.url,
		            type: 'GET',
		            data: function(){
		            	return {
		            		id: Calendar.currentObj.id,
		            		type: Calendar.type
		            	}
		            },
		            error: function(err) {
		                console.log('There was an error while fetching events!');
		            },
		        }
		    ],
			defaultView:'agendaWeek',
			header:{
				left: 'prev,next today',
				center: 'title',
				right: 'month,agendaWeek,agendaDay'
			},
			height: Calendar.calendarArea.height(),
			unselectCancel:'#vMeetingMaker,.fc-addToCalendar-button,.mbsc-mobiscroll',
			timezone:'local',
			editable: true,
			selectable: true,
			selectHelper: true,
			selectOverlap: false,
			allDaySlot:false,
		    windowResize: function(view) {
		        Calendar.CalendarObj.fullCalendar('option', 'height', Calendar.calendarArea.height());
		    },
			// This controls the population of the side selector on dragging from the calendar
			select: function(start,end,jsEvent,view,resource){ 
				// If an existing event had been selected, reset fields
				Calendar.eventSelected ? Calendar.resetFields() : null;
				Calendar.autoSelect = null;
				Calendar.selectCreationMode = true;
				Calendar.clearSelected();
				Calendar.setTimeSelectors(start,end);
				Calendar.CalendarObj.fullCalendar('rerenderEvents'); // Necessary???
				Calendar.setModifyAuthorization(true);
			},
			unselect:function(view,jsEvent){
				Calendar.selectCreationMode = false;
			},
			eventDrop: function (event, delta, revertFunc, jsEvent, ui, view) {
				Calendar.changeEvent(event);
			},
			eventResize: function (event, delta, revertFunc, jsEvent, ui, view) {
				Calendar.changeEvent(event);
			},
			eventDataTransform:function(event){
				event.start = moment(event.start).local().format();
				event.end = moment(event.end).local().format();
				event.id = event.resID;
				if(event.resID === Calendar.autoSelect){ event.className.push("selected"); }
				return event;
			},
			eventClick:function(event,jsEvent,view){
				Calendar.autoSelect = null;
				Calendar.clearSelected();
				Calendar.selectExistingEvent(event);
				Calendar.setTimeSelectors(event.start,event.end);
				Calendar.CalendarObj.fullCalendar('updateEvent',event);
			},
		});
	}

	this.clearSelected = function(){
		this.CalendarObj.fullCalendar('clientEvents',function(event){ // Unselects events
			var index = event.className.indexOf('selected'); // Finds if the event is selected
			if(index > -1){ 
				event.className.splice(index,1);
				Calendar.CalendarObj.fullCalendar('updateEvent',event);
			} // Removes the 'selected' class
		})		
	}

	this.setTimeSelectors = function(start,end){
		// Calculates the current timezone start and end for the range
		var momentStart,momentEnd,diff;
		momentStart = start._ambigZone ? start.add(start._d.getTimezoneOffset(),'minutes') : start;
		momentEnd = end._ambigZone ? end.add(end._d.getTimezoneOffset(),'minutes') : end;
		diff = momentEnd.preciseDiff(momentStart);
		
		// Sets the start/end/duration to the selected range
		this.duration.html(diff);
		this.start.mobiscroll('setVal',new Date(momentStart.valueOf()),true);
		this.end.mobiscroll('setVal',new Date(momentEnd.valueOf()),true);		
	}

	this.setModifyAuthorization = function(authorized){
		if(authorized){
			this.reservationTitle.prop("disabled",false);
			this.bulletinMessage.prop("disabled",false);
			this.privacyToggle.closest("tr").show();
			this.bulletinToggle.closest("tr").show();
			this.start.mobiscroll('enable');
			this.end.mobiscroll('enable');
			this.saveButton.removeClass("disabled");
			this.deleteButton.removeClass("disabled");
		} else {
			this.reservationTitle.prop("disabled",true);
			this.bulletinMessage.prop("disabled",true);
			this.privacyToggle.closest("tr").hide();
			this.bulletinToggle.closest("tr").hide();
			this.start.mobiscroll('disable');
			this.end.mobiscroll('disable');
			this.saveButton.addClass("disabled");
			this.deleteButton.addClass("disabled");			
		}		
	}

	this.selectExistingEvent = function(event){
		event.className.push("selected");
		this.eventSelected = true;
		this.saveButton.html("Update"); // Save should become "Update"
		this.reservationTitle.val(event.title);
		this.setModifyAuthorization(event.authorized);
		if(event.authorized){
			this.privacyToggle.prop("checked",event.private === "true" || event.private === true);
			this.bulletinToggle.prop("checked",event.bulletin === "true" || event.bulletin === true);
			this.bulletinMessage.val(event.message);
			this.reservationOwner.html("").closest("tr").hide();
		} else {
			this.reservationOwner.html(event.userName).closest("tr").show();
		}
	}

	this.warnOfScheduleConflict = function(){
		swal({
			title: "Scheduling Conflict",
			text: "Your requested reservation conflicts with another reservation." + 
				" Please choose an alternative reservation time.",
			type: "warning",
			confirmButtonColor: "#525252",    
			confirmButtonText: "OK",
			closeOnConfirm: true,
		})
	}

	this.warnOfNegativeTime = function(){
		swal({
			title: "Invalid Times",
			text: "The end of your requested reservation occurs before its start." + 
				" Please choose an alternative reservation time.",
			type: "warning",
			confirmButtonColor: "#525252",    
			confirmButtonText: "OK",
			closeOnConfirm: true,
		})
	}

	this.checkForIntersection = function(checkEvent){
		var start = checkEvent.start;
		var end = checkEvent.end;
		var intersections = Calendar.CalendarObj.fullCalendar('clientEvents',function(event){
			return event.end > start && event.start < end && checkEvent.resID != event.resID
		})
		return intersections.length ? true : false;		
	}

	this.formatEvent = function(event){ // Creates a database event entry out of a FullCalendar Event
		return {
			resID: event.resID,
			roomID: event.roomID,
			title: event.title,
			private: event.private,
			bulletin: event.bulletin,
			message: event.message,
			start: event.start.format(),
			end: event.end.format(),
			userID: event.userID || null, // null if a new event, will be added by the server
			mapID: $Map.Viewer.currentFile.getMapID(),
			officeID: $Map.Viewer.currentFile.getOfficeID(),
			deptID: this.currentObj.department.deptID
		}
	}

	this.addToCalendar = function(){ // Creates an event out of form data and saves to database
		var startMoment = moment(this.start.mobiscroll('getVal'));
		var endMoment = moment(this.end.mobiscroll('getVal'));
		if(startMoment > endMoment){
			this.warnOfNegativeTime();
			return;
		}		
		var resID = generateUUID();
		var event = {
			id: resID, // Used internally by the calendar
			resID: resID,
			roomID: this.currentObj.id,
			title  : this.reservationTitle.val(),
			bulletin: this.bulletinToggle.prop("checked"),
			message: this.bulletinMessage.val(),
			private: this.privacyToggle.prop("checked"),
			start  : startMoment,
			end : endMoment,
		};

		if(this.checkForIntersection(event)){ // Checks if the event has a conflict
			this.warnOfScheduleConflict(); // Warns user of conflict
			return; // Aborts the save process
		}

		this.saveEvent(event); // Sends the event to the server

		Calendar.CalendarObj.fullCalendar( 'unselect' );
	}

	this.updateEvent = function(event){
		var startMoment = moment(this.start.mobiscroll('getVal'));
		var endMoment = moment(this.end.mobiscroll('getVal'));
		if(startMoment > endMoment){
			this.warnOfNegativeTime();
			return;
		}
		var updated = {
			id: event.resID, // Used internally by the calendar
			resID: event.resID,
			roomID: this.currentObj.id,
			bulletin: this.bulletinToggle.prop("checked"),
			message: this.bulletinMessage.val(),
			private: this.privacyToggle.prop("checked"),			
			userID: event.userID,
			title  : this.reservationTitle.val(),
			start  : startMoment,
			end : endMoment,
		};

		if(this.checkForIntersection(event)){ // Checks if the event has a conflict
			this.warnOfScheduleConflict(); // Warns user of conflict
			return; // Aborts the save process
		}

		this.changeEvent(updated);		
	}

	this.saveEvent = function(event){
		$.ajax({
			type:"POST",
			data:{
				reservation: this.formatEvent(event),
				type: this.type
			},
			url: this.saveURL,
			success: function(result){
				var start = moment(result.start);
				var end = moment(result.end);
				Calendar.setTimeSelectors(start,end);
				Calendar.autoSelect = event.resID;
				Calendar.CalendarObj.fullCalendar('refetchEvents');
				var mapID = $Map.Viewer.currentFile.getMapID();
				$Map.Viewer.currentFile.dataConnections.loadReservations(mapID);
			}, // End of Success callback
			error: function(error){
				console.log('Error saving reservations');
				if(error.responseJSON && error.responseJSON.conflict){
					Calendar.warnOfScheduleConflict();
				}
			}
		}) // End of AJAX Call 		
	}

	this.changeEvent = function(event){ // Updates an existing event with the server 
		$.ajax({
			type:"POST",
			data:{
				reservation: this.formatEvent(event),
				type: this.type,
			},
			url: this.updateURL,
			success: function(result,test1,test2){
				var start = moment(result.start);
				var end = moment(result.end);
				Calendar.setTimeSelectors(start,end);
				Calendar.autoSelect = event.resID; 
				Calendar.CalendarObj.fullCalendar('refetchEvents');
				var mapID = $Map.Viewer.currentFile.getMapID();
				$Map.Viewer.currentFile.dataConnections.loadReservations(mapID);
				// TODO get better access to controller and mapID
			}, // End of Success callback
			error: function(error){
				console.log('Error saving reservations');
				if(error.responseJSON && error.responseJSON.conflict){
					Calendar.warnOfScheduleConflict();
				}
			}
		}) // End of AJAX Call 
	}

	this.removeEvent = function(){
		var event = Calendar.CalendarObj.fullCalendar('clientEvents',function(event){
			return event.className.indexOf('selected') != -1;
		})[0]

		if(event === undefined || event.authorized === false){return;}

		$.ajax({
			type:"DELETE",
			data:{
				reservation: this.formatEvent(event),
				type: this.type
			},
			url: this.removeURL,
			success: function(result){
				Calendar.CalendarObj.fullCalendar('refetchEvents');
				var mapID = $Map.Viewer.currentFile.getMapID();
				$Map.Viewer.currentFile.dataConnections.loadReservations(mapID);
			}, // End of Success callback
			error: function(error){
				console.log('Error deleting reservations');
			}
		}) // End of AJAX Call 		
	}

	this.resetFields = function(){ // Resets fields when creating a new event
		this.reservationTitle.val('');
		this.bulletinMessage.val('');
		this.privacyToggle.prop("checked",false);
		this.bulletinToggle.prop("checked",false);
		this.reservationOwner.html("").closest("tr").hide();
		this.saveButton.html("Add"); // Save should become "Add"
		this.eventSelected = false;
	}

	this.setFields = function(){
		this.start.add(this.end).mobiscroll().datetime({
			theme:'mobiscroll',
			display:'bubble',
			buttons:['now','cancel','set'],
			steps: { 
			    minute: 5,
			    zeroBased: true
			}
		});
	}

	this.unsetFields = function(){
		
		this.start.add(this.end).mobiscroll('destroy');
	}

	this.setProperties = function(){
		// Objects to activate
		this.bulletinToggle.prop("checked",false).closest("tr").show();
		this.privacyToggle.prop("checked",false).closest("tr").show();
		this.bulletinMessage.html("").closest("tr").show();	
		this.objCapacity.html("").closest("tr").show();
		this.objSize.html("").closest("tr").show();
		this.objEquipment.html("").closest("tr").show(); // Need to add for seat
		this.objAmeneties.html("").closest("tr").show(); // Need to add for seat
		this.objAccessibility.html("").closest("tr").show(); // Need to add for seat

		// Objects to Populate
		this.objName.html(this.currentObj.name);
		this.objType.empty().html(this.currentObj.roomType).closest("tr").show();
		this.objType.html() ? null : this.objType.hide(); // Hides if no room type is available
		this.objDept.html(this.currentObj.department.deptName);
		this.objCapacity.empty().html(this.currentObj.capacity).closest("tr").show();
		this.objCapacity.html() ? null : this.objCapacity.hide(); // Hides if no capacity is available
		this.objSize.html(renderArea(this.currentObj.area,{svg:false}))
		this.objEquipment.empty().closest("tr").show();
		for(var i in this.currentObj.equipment){
			this.objEquipment.append("<li>"+this.currentObj.equipment[i]+"</li>");
		}
		this.objEquipment.children().length ? null : this.objEquipment.closest("tr").hide();
		this.objAmeneties.empty().closest("tr").show();
		for(var i in this.currentObj.ameneties){
			this.objAmeneties.append("<li>"+this.currentObj.ameneties[i]+"</li>");
		}
		this.objAmeneties.children().length ? null : this.objAmeneties.closest("tr").hide();
		this.objAccessibility.empty().closest("tr").show();
		for(var i in this.currentObj.accessibility){
			this.objAccessibility.append("<li>"+this.currentObj.accessibility[i]+"</li>");
		}
		this.objAccessibility.children().length ? null : this.objAccessibility.closest("tr").hide();
	}

	this.setBindings = function(){
		this.saveButton.on("click." + this.namespace,function(event){
			if(Calendar.selectCreationMode){
				Calendar.addToCalendar();
			} else {
				var event = Calendar.CalendarObj.fullCalendar('clientEvents',function(event){
					return event.className.indexOf('selected') != -1;
				})
				if(event.length && event[0].authorized){
					Calendar.updateEvent(event[0]);
				}
			}
		})

		this.closeButton.on("click." + this.namespace,function(){
			Calendar.exit();
		})

		this.deleteButton.on("click." + this.namespace,function(){
			Calendar.removeEvent();
		})
	}

	this.unsetBindings = function(){
		this.saveButton.off(this.namespace);
		this.closeButton.off(this.namespace);
		this.deleteButton.off(this.namespace);
	}
}
$Map.components.schedulers.seatCalendar.prototype.constructor = $Map.components.schedulers.seatCalendar;