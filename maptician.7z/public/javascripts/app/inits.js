$Map.inits = $Map.inits || {};

$Map.inits.setValidators = function(){
	$.validator.methods.email = function( value ) {
		return /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/.test( value );
	}

	$.validator.methods.strongPassword = function( value ) {
		return /(?=^.{8,15}$)((?!.*\s)(?=.*[A-Z])(?=.*[a-z])(?=(.*\d){1,}))((?!.*[",;&|'])|(?=(.*\W){1,}))(?!.*[",;&|'])^.*$/.test( value );
	}

	$.validator.methods.website = function( value ) {
		return /^((http:\/\/www\.)|(www\.)|(http:\/\/))[a-zA-Z0-9._-]+\.[a-zA-Z.]{2,5}$/.test( value );
	}

	$.validator.methods.fullName = function( value ) {
	  return /^[a-z ,.'-]+$/i.test( value );
	}

	$.validator.methods.letNumSpac = function( value ) {
	  return /^[A-Za-z0-9 _]*[A-Za-z0-9][A-Za-z0-9 _]*$/i.test( value );
	}

	$.validator.methods.sameAsPass = function( value ) {
	  return $("#newPassword").val() == value;
	}

	$.validator.methods.diffFromOld = function( value ) {
	  return $("#oldPassword").val() != value;
	}
}

$Map.inits.setFlowUpLabels = function(){
	$('#officesRightNav .FlowupLabels').FlowupLabels();
	
	$('#departmentsRightNav .FlowupLabels').FlowupLabels();

	$('#newMapModal .FlowupLabels').FlowupLabels({
		class_focused:"focused-narrow",
		class_populated:"populated-narrow"
	});

	$('#officeFormModal .FlowupLabels').FlowupLabels({
		class_focused:"focused-narrow",
		class_populated:"populated-narrow"
	});	

	$('#departmentFormModal .FlowupLabels').FlowupLabels({
		class_focused:"focused-narrow",
		class_populated:"populated-narrow"
	});	

}

$Map.inits.setSelectorDividers = function(){
	$('.selectorDivider').click(function(){
		var toggleIndicator = $(this).find('.fa');
		toggleIndicator.toggleClass('fa-chevron-right').toggleClass('fa-chevron-down');
		if(toggleIndicator.hasClass('fa-chevron-right')){
			$(this).nextUntil('.selectorDivider').hide();
		} else {
			$(this).nextUntil('.selectorDivider').filter('.activeDisplay').show();
		}
	})	
}