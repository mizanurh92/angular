$Map.Components.CompanyAnalytics = function(companyController){
	console.log('Started Company Analytics Controller')
	this.companyController = companyController;
	this.reportSelector = $("#companyAnalytics select.analytics-select");
	this.openReport = null;
	var Analytics = this;

	this.open = function(){
		this.reportSelector.val(0);
		this.setBindings();
	}

	this.exit = function(){
		this.openReport.report.exit();
		this.openReport = null;
		this.unsetBindings();
	}

	this.setBindings = function(){
		this.reportSelector.on('change',function(){
			
			var index = 1*$(this).val();
			console.log(index)

			if(Analytics.openReport && Analytics.openReport.index != index){
				Analytics.openReport.report.exit();				
			}

			switch(index){
				case 0:
				break;
				case 1:
					Analytics.capacityByState = Analytics.capacityByState || 
						new $Map.Components.CompanyAnalytics.capacityByState;
					Analytics.capacityByState.open();
					Analytics.openReport = {index:index,report:Analytics.capacityByState};
				break;
				case 2:
				break;
				case 3:
				break;
				// case 2:
				// 	Reports.roomList = Reports.roomList || new $Map.Components.OfficesReports.roomList();
				// 	Reports.roomList.open(Reports.officeController.officeSelected);
				// 	Reports.openReport = {index:index,report:Reports.roomList};
				// break;
				// case 3:
				// 	Reports.zoneList = Reports.zoneList || new $Map.Components.OfficesReports.zoneList();
				// 	Reports.zoneList.open(Reports.officeController.officeSelected);
				// 	Reports.openReport = {index:index,report:Reports.zoneList};
				// break;
				// case 4:
				// 	Reports.occupantList = Reports.occupantList || new $Map.Components.OfficesReports.occupantList();
				// 	Reports.occupantList.open(Reports.officeController.officeSelected);
				// 	Reports.openReport = {index:index,report:Reports.occupantList};
				// break;
				// case 5:
				// 	Reports.visitorList = Reports.visitorList || new $Map.Components.OfficesReports.visitorList();
				// 	Reports.visitorList.open(Reports.officeController.officeSelected);
				// 	Reports.openReport = {index:index,report:Reports.visitorList};
				// break;
			}
		})
	}

	this.unsetBindings = function(){
		this.reportSelector.off('change');
	}
}
$Map.Components.CompanyAnalytics.prototype.constructor = $Map.Components.CompanyAnalytics;

$Map.Components.CompanyAnalytics.capacityByState = function(){
	// General Parameters
	this.group = 'capacityByState';
	this.namespace = 'capacityByState';
	this.fileName = 'seat_capacity_type_by_day';
	this.url = '../api/company/analytics/capacityByState';

	// Screen Objects
	this.contentWrapper = $("#companyAnalytics");
	this.tile0 = this.contentWrapper.find('.tile-0');
	this.tile1 = this.contentWrapper.find('.tile-1');
	this.tile2 = this.contentWrapper.find('.tile-2');
	this.tile3 = this.contentWrapper.find('.tile-3');
	this.tile4 = this.contentWrapper.find('.tile-4');
	this.tile5 = this.contentWrapper.find('.tile-5');
	this.tile6 = this.contentWrapper.find('.tile-6');
	this.tile7 = this.contentWrapper.find('.tile-7');
	this.tile8 = this.contentWrapper.find('.tile-8');
	this.tile9 = this.contentWrapper.find('.tile-9');
	this.downloadButton = this.contentWrapper.find('.download-btn');
	this.resetButton = this.contentWrapper.find('.reset-btn')

	var Analytics = this;

	// Formatting Options
	var numberFormat = d3.format(".0f");
	var decimalFormat = d3.format(".2f");
	var percentFormat = d3.format(".0%");
	var dateFormat = d3.time.format("%Y-%m-%d");
	var shortDate = d3.time.format("%b-%d '%y");
	var longDate = d3.time.format("%B %d, %Y");	

	this.open = function(){
		this.setTiles();
		this.setCharts();
		this.getData();
		this.setBindings();
	}

	this.exit = function(){
		this.unsetCharts();
		this.unsetTiles();
		this.clearData();
		this.unsetBindings();
	}

	this.update = function(){
		this.unsetCharts();
		this.unsetTiles();
		this.clearData();
		this.setTiles();
		this.setCharts();
		this.getData();
	}

	this.setTiles = function(){
		this.tile0.css({display:"inline-block"}).addClass('full-width half-high main-chart')
			.html("<strong class='header absolute'>Office Seat Capacity By State</strong>");
		this.tile1.css({display:"inline-flex"}).addClass('left-third svg-chart')
			.html("<strong class='header absolute'>Seat Use Type</strong>");
		this.tile2.css({display:"inline-flex"}).addClass('center-third svg-chart')
			.html("<strong class='header absolute'>Seat Status</strong>");
		this.tile3.css({display:"inline-flex"}).addClass('right-third svg-chart')
			.html("<strong class='header absolute'>Department</strong>");
		this.tile4.css({display:"none"}).html("");
		this.tile5.css({display:"none"}).html("");
		this.tile6.css({display:"none"}).html("");
		this.tile7.css({display:"none"}).html("");
		this.tile8.css({display:"none"}).html("");		
		this.tile9.css({display:"none"}).html("");
	}

	this.unsetTiles = function(){
		this.tile0.css({display:"none"}).removeClass("full-width half-high main-chart").html("");
		this.tile1.css({display:"none"}).removeClass("dc-select-box").html("");
		this.tile2.css({display:"none"}).removeClass("dc-select-box").html("");
		this.tile3.css({display:"none"}).removeClass("dc-select-box").html("");
		this.tile4.css({display:"none"}).html("");
		this.tile5.css({display:"none"}).html("");
		this.tile6.css({display:"none"}).html("");
		this.tile7.css({display:"none"}).html("");
		this.tile8.css({display:"none"}).html("");
		this.tile9.css({display:"none"}).html("");
	}

	this.setCharts = function(){
		this.chart0 = dc.geoChoroplethChart(this.tile0[0],this.group);
		this.chart1 = dc.pieChart(this.tile1[0],this.group);
		this.chart2 = dc.rowChart(this.tile2[0],this.group);
		this.chart3 = dc.rowChart(this.tile3[0],this.group);
		//this.chart4 = dc.selectMenu(this.tile4[0],this.group);
		//this.chart5 = dc.selectMenu(this.tile5[0],this.group);
		//this.chart6 = dc.numberDisplay(this.tile6[0],this.group);
		//this.chart7 = dc.numberDisplay(this.tile7[0],this.group);
		//this.chart8 = dc.numberDisplay(this.tile8[0],this.group);
		//this.chart9 = dc.numberDisplay(this.tile9[0],this.group);
	}

	this.unsetCharts = function(){
		dc.deregisterAllCharts(this.group);
		this.chart0 = null;
		this.chart1 = null;
		this.chart2 = null;
		this.chart3 = null;
		//this.chart4 = null;
		//this.chart5 = null;
		//this.chart6 = null;
		//this.chart7 = null;
		//this.chart8 = null;
		//this.chart9 = null;
	}

	this.getData = function(){
		$.ajax({
			type:"GET",
			url: this.url
		})
		.then(function(data){
			//data = Analytics.formatData(data);
			if(Analytics.stateJSON){
				Analytics.setDataObjects(data);
				Analytics.configureCharts();
				if(!data.length){return;}
				Analytics.renderCharts();				
			} else {
				d3.json("../us-states.json",function(stateJSON){
					console.log(data,stateJSON);
					Analytics.stateJSON = stateJSON;
					Analytics.setDataObjects(data);
					Analytics.configureCharts();
					if(!data.length){return;}
					Analytics.renderCharts();					
				})
			}
		})
		.catch(function(err){
			console.log(err);
		})
	}	

	this.setDataObjects = function(data){
		this.data = crossfilter(data);

	    this.groupAll = this.data.groupAll();

		// Dimensions and group for usChart
		this.statesDim = this.data.dimension(function (d) {
			return d["state"];
		});
		this.statesGroup = this.statesDim.group();

		// Dimensions and group for seatTypeChart
		this.typeDim = this.data.dimension(function (d) {
			if(d["reservable"]){
				return "Reservable";
			} else {
				return "Assignable";
			}
		});
		this.typeGroup = this.typeDim.group();

		// Dimensions and group for seatStatusChart
		this.statusDim = this.data.dimension(function (d) {
			if(d["reservable"]){
				return "Reservable";
			} else if(d["assignmentStatus"] == "Unassigned"){
				return "Unassigned";
			} else {
				return "Assigned"
			}
		});
		this.statusGroup = this.statusDim.group();	

		// Dimensions and group for seatDeptChart
		this.departmentDim = this.data.dimension(function(d){
			return d.department;
		})
		this.departmentGroup = this.departmentDim.group();
	}

	this.configureCharts = function(){
		this.chart0
			.width(900)
			.height(500)
			.dimension(this.statesDim)
			.group(this.statesGroup)
			.colors(d3.scale.quantize().range(["#E2F2FF", "#C4E4FF", "#9ED2FF", "#81C5FF", "#6BBAFF", "#51AEFF", "#36A2FF", "#1E96FF", "#0089FF", "#0061B5"]))
			.colorDomain([0, 200])
			.colorCalculator(function (d) { return d ? Analytics.chart0.colors()(d) : '#ccc'; })
			.overlayGeoJson(Analytics.stateJSON.features, "state", function (d) {
				return d.properties.name;
			})
			.valueAccessor(function(kv) {
				return kv.value;
			})
			.title(function (d) {
				return "State: " + d.key + "\nTotal Capacity: " + numberFormat(d.value ? d.value : 0) + (d.value == 1 ? " Seat" :" Seats");
			})
			.useViewBoxResizing(true)

		this.chart1
			.width(280)
			.height(280)
			.radius(120)
			.dimension(this.typeDim)
			.group(this.typeGroup)
			.label(function (d) {
			    return d.key;
			})
			.renderLabel(true)
			.transitionDuration(350)
			.title(function (d) {
				return d.key + ": " + d.value + "\n" + Math.floor(d.value / Analytics.groupAll.value() * 100) + '%';
			})
			.useViewBoxResizing(true)

		this.chart2
			.width(280)
			.height(280)
			.useViewBoxResizing(true)
			.margins({top: 20, left: 10, right: 10, bottom: 20})
			.dimension(this.statusDim)
			.group(this.statusGroup)
			.ordinalColors(['#3182bd', '#6baed6', '#9ecae1', '#c6dbef', '#dadaeb'])
			.label(function (d) {
			    return d.key;
			})
			.title(function (d) {
			    return d.value;
			})
			.elasticX(true)
			.xAxis()
			.ticks(4)

		this.chart3
			.width(280)
			.height(280)
			.useViewBoxResizing(true)
			.margins({top: 20, left: 10, right: 10, bottom: 20})
			.dimension(this.departmentDim)
			.group(this.departmentGroup)
			.ordinalColors(['#3182bd', '#6baed6', '#9ecae1', '#c6dbef', '#dadaeb'])
			.label(function (d) {
			    return d.key;
			})
			.title(function (d) {
			    return d.value;
			})
			.elasticX(true)
			.xAxis()
			.ticks(4)
	}

	this.refreshData = function(){ // TODO get this working for this chart
		$.ajax({
			type:"GET",
			url: this.url,
			data: {officeID:this.officeID}
		})
		.then(function(data){
			data = Analytics.formatData(data);
			try{
				Analytics.data.remove();
				Analytics.data.add(data);
			} catch (err) {
				console.log(err);
			}
			Analytics.renderCharts();
		})
		.catch(function(err){
			console.log(err);
		})		
	}

	this.clearData = function(){
		this.data = null;
		this.groupAll = null;
		this.statesDim = null;
		this.statesGroup = null;
		this.typeDim = null;
		this.typeGroup = null;
		this.statusDim = null;
		this.statusGroup = null;
		this.departmentDim = null;
		this.departmentGroup = null;
	}

	this.formatData = function(data){
		var formatted = [];
		data.forEach(function(d){})
		return formatted;
	}

	this.renderCharts = function(){
		console.log('rendering charts')
		dc.renderAll(this.group);
	}

	this.setBindings = function(){
		this.resetButton.on('click.'+this.namespace,function(){
			dc.filterAll(Analytics.group);
			dc.redrawAll(Analytics.group);
		})

		this.downloadButton.on('click.'+this.namespace,function(){
		    var data = Analytics.mainDim.top(Infinity);
		    data = data.map(function(d){
		    	var formatted = {
		    		Date: longDate(d.date),
		    		Department: d.department,
		    		Map: d.map,
		    		Suite: d.suite,
		    		Floor: d.floor,
		    		Seats: d.capacity
		    	}
		    	return formatted;
		    })
		    var blob = new Blob([d3.csv.format(data)], {type: "text/csv;charset=utf-8"});
		    saveAs(blob, Analytics.fileName+'.csv');
		})
	}

	this.unsetBindings = function(){
		this.resetButton.off('.'+this.namespace);
		this.downloadButton.off('.'+this.namespace);		
	}
}
$Map.Components.CompanyAnalytics.capacityByState.prototype.constructor = 
	$Map.Components.CompanyAnalytics.capacityByState;
