$Map.Components = $Map.Components || {};

$Map.Components.Company = function(){
	this.namespace = 'company';
	this.area = $("#companyArea");
	this.topNav = $("#topNav");
	this.tabSelectors = $("#companyTabSelectors");
	this.tabs = $("#companyTabSelectors").find('li');
	this.tabOpen = null;
	var Company = this;

	this.open = function(){
		this.area.show();
		this.tabSelectors.show();
		this.setBindings(this.namespace);
		this.tabSelect(0);
		this.isOpen = true;
	}

	this.exit = function(){
		this.unsetBindings(this.namespace);
	}

	this.tabSelect = function(index){
		this.tabs.removeClass('active');
		$(this.tabs[index]).addClass('active');
		this.area.find('.subContent').hide();
		$(this.area.find('.subContent')[index]).show();

		switch(index){
			case 0:
				this.summary = this.summary || new $Map.Components.Company.summary(this);
				this.summary.open();
				this.tabOpen = this.summary;
			break;
			case 1:
				this.users = this.users || new $Map.Components.Company.userMgmtList(this);
				this.users.open();
				this.tabOpen = this.users;
			break;
			case 2:
				this.reports = this.reports || new $Map.Components.CompanyReports(this);
				this.reports.open();
				this.tabOpen = this.reports;
			break;
			case 3:
				this.analytics = this.analytics || new $Map.Components.CompanyAnalytics(this);
				this.analytics.open();
				this.tabOpen = this.analytics;
			break;
			case 4:
				// this.officeTable.draw();
				// $Map.OfficeTables.kioskList({officeID:this.officeSelected});
			break;
		}
	}


	this.setBindings = function(namespace){

		this.tabs.on('click.' + namespace, function(){
			Company.tabSelect($(this).index())
		})

	}

	this.unsetBindings = function(namespace){
		this.tabs.off('.'+namespace);

	}
}
$Map.Components.Company.prototype.constructor = $Map.Components.Company;

$Map.Components.Company.userMgmtList = function(){
	this.url = '../api/company/users/userList';
	this.tableContainer = $("#companyUsers .table-container")
	this.tableElement = $("#companyUsersTable");
	this.tableColumns = 8;
	this.table = null;
	this.editor = null;
	this.tableOffset = 110;
	this.namespace = 'userMgmtList';
	var report = this;

	this.open = function(officeID){
		//this.createFooter();
		this.setEditor();
		this.setEditorSelectors();
		this.setTable();
		this.setBindings(this.namespace);
		this.isOpen = true;
	}

	this.exit = function(){
		this.unsetBindings();
		this.table && this.table.clear().destroy(); // Clears datatable
		this.editor && this.editor.destroy();
		this.table = null;		
		this.editor = null;
		this.tableElement.children().remove(); // Removes table remaining table elements (except table)
		this.isOpen = false;
	}

	this.update = function(officeID){
		report.table.ajax.reload();
	}

	this.setTable = function(){
		this.table = this.table || this.tableElement.DataTable({
			ajax: {
				url: this.url
			},
			rowId: 'userID',
			select: {
				style: 'single',
				className: 'selected',
				selector: 'tr:not(.selected)'
			},
			scrollY: report.tableContainer.height() - this.tableOffset,
			deferRender:true,
			scroller:true,
			paging:true,
			autoWidth:true,
			columns:[
				{
					width: 50,
					data: {},
					class: 'tableProfileImage userProfileImage',
					render: function(user){
						return '<div><img src="'+user.profile+'"></div>';
					}
				},				
				{
					width: 75,
					title: "Name",
					data: {},
					class: 'leftAlign',
					render: function(user){
						return user.first + " " + user.last;
					}
				},
				{
					width: 50,
					title: "Employee ID",
					data: {},
					class: 'centerAlign',
					render: function(user){
						if(user.employee && user.employee.employeeID){
							return user.employee.employeeID;
						} else{
							return "";
						}
					}
				},
				{
					width: 30,
					title: "Title",
					data: {},
					class: 'centerAlign',
					render: function(user){
						if(user.employee && user.employee.title){
							return user.employee.title;
						} else {
							return "";
						}
					}
				},
				{
					width: 40,
					title: "Department",
					data: {},
					class: 'centerAlign',
					render: function(user){
						if(user.employee && user.employee.department && user.employee.department.name){
							return user.employee.department.name;
						} else {
							return "";
						}  
					}
				},
				{
					width: 30,
					title: "Office",
					data: {},
					class: 'centerAlign',
					render: function(user){
						if(user.office && user.office.name){
							return user.office.name;
						} else {
							return "";
						}  
					}
				},
				{
					width: 70,
					title: "Seat",
					data: {},
					class: 'centerAlign',
					render: function(user){
					var len = user.seats.length;
						if(len > 1){
							return '<a class="seatDrillDown" href="#">'+'Multiple'+'</a>';
						} else if (len == 1){
							var seat = user.seats[0];
							return seat.mapName + " - Seat: " + seat.seatName;
						} else {
							return "Unassigned";
						}
					}
				},
				{
					width: 60,
					title: "Email",
					data: {},
					class: 'leftAlign',
					render: function(user){
						return user.email
					}
				},
			],
			dom: '<".standardTableFilterDiv" and f><".standardTableButtonDiv" and B>rt',
			buttons: [
				{text:"Bulk Upload",editor:report.editor,action: function ( e, dt, node, config ) {bulkOperations()}},
				{extend:"create",editor:report.editor},
				{extend:"edit",editor:report.editor},
				{extend:"remove",editor:report.editor},
			],
			initComplete: function(){
				//report.table.scroller.measure();
			}
		})
	}

	this.setEditor = function(){
		this.editor = new $.fn.dataTable.Editor({
			ajax:{
				create:{
					type:'POST',
					url: '../api/employees/createNewEmployee'
				},
				remove:{
					type:'DELETE',
					url: '../api/employees/deleteEmployee'
				},
				edit:{
					type:'PUT',
					url: '../api/employees/editEmployee'
				},
			},
			table: this.tableElement[0],
			idSrc: 'userID',
			fields:[
				{
					label:"Employee ID",
					name:"employee.employeeID"
				},
				{
					label:"First Name",
					name:"first"
				},
				{
					label:"Last Name",
					name:"last"
				},
				{
					label:"Email",
					name:"email"
				},
				{
					label:"Title",
					name:"employee.title"
				},
				{
					label:"Department",
					name:"employee.department",
					type: "select",
					options: []
				},
				{
					label:"Office",
					name:"office",
					type: "select",
					options: []
				}
			]
		});
	}

	this.setEditorSelectors = function(){
		$.ajax({
			type:"GET",
			url: "/api/company/users/selectList/",
			success: function(result){
				report.editor.field('employee.department').update(result.departments);
				report.editor.field('office').update(result.offices);
			}, // End of Success callback
			error: function(error){
				console.log('error loading departments');
			}
		})
	}

	this.setBindings = function(namespace){
		table = this.table;

		// Resizes the table based on a change in the height of parent element (resize event)
		// Does this by creating an iframe in the same space and listening for a resize
		_attach.call(table,this.namespace,this.tableOffset,function(height){
			report.tableElement.parent().css("height",height - 30);
			table.draw();
		});

		// Redraws the map when the leftNav is maximized or minimized.
		// Needed to keep the columns and headers aligned during the resize
		$("#sidebarMin,#sidebarMax").on('click.'+namespace,function(){
			var tableContext = table;
			setTimeout(function(){
				tableContext.draw();
			},300)
		})

		// Add event listener for opening seat table modal for all seats
		table && table.on('click.'+namespace, 'td.userProfileImage', function () {
			var row = report.table.row($(this).closest('tr'))
			var data = row.data();
			var userID = data.userID;
			img = $(this).find('img');
			src = data.profile;
			$Map.Profile = $Map.Profile || {};
			$Map.Profile.userProfileController = $Map.Profile.userProfileController ||
				new $Map.Components.Profile.UserProfileController;
			console.log(data);
			$Map.Profile.userProfileController.open(userID,img,data,row);
			//var seats = data.seats;
			//var seatIDArray = [];
			//for(var i in seats){seatIDArray.push(seats[i].seatID)}
			//$Map.ModalTables.seatTable(seatIDArray);
		});

	}

	this.unsetBindings = function(){
		$(document).off('.'+this.namespace);
		$("#"+this.namespace).remove(); // Remove iframe
	}

	this.createFooter = function(){
		var footer = "";
		footer += "<tfoot><tr>";
		for(var i = 0; i < this.tableColumns; i++){footer+= "<td></td>"}
		footer += "</tr></tfoot>";
		this.tableElement.append(footer);
	}
	var bulkOperations=function(){
		Maptician.BulkUpload = {};
		Maptician.BulkUpload.hasInit=false;
		Maptician.BulkUpload.mapingOption = ["Email", "First", "Last", "Cell", "UserType", "Password", "UserStatus", "EmployeeID", "Title", "Department", "Office", "CodeRequired", "Contactable"];
		Maptician.BulkUpload.mapingOptionName=["Email ID","First Name","Last Name","Cell Number","User Type","Password","User Status","Employee ID","Title","Department","Office","Code Required","Contactable"]; 
	    Maptician.BulkUpload.option = '';
	    Maptician.BulkUpload.dynamicSelect=function(){
	    if(Maptician.BulkUpload.gotData){
	        //$("#bulkUploadList tr:nth-child(1) > td").addClass("headerdata");
	        //var length=0;
	        var selectBox="";
	        var length=$("#bulkUploadList tr:nth-child(1) > td").length;
	        var selectBox=$("#bulkUploadMappingForm > tbody > tr:nth-child(1) > td #selectOption").html();
	        for(var i=1;i<length;i++){
	            $("#bulkUploadMappingForm > tbody > tr:nth-child(1) > td .fl_wrap #selectOption").append(selectBox);
	        }
	    }
}
Maptician.BulkUpload.dynamicHeader=function(){
    Maptician.BulkUpload.headerChecked = $('input[name="headerCheck"]').is(':checked');
    var customeHeader=$("#bulkUploadList tr:nth-child(1)").html();
    $("#bulkUploadList").prepend("<tr>"+customeHeader+"</tr>");
    $("#bulkUploadList tr:nth-child(2) td").removeClass("headerdata");
    if(Maptician.BulkUpload.headerChecked){
        $("#bulkUploadList tr:nth-child(2) td").addClass("cointainsHeader");
    }
}
//remove all html element on close of popup
Maptician.BulkUpload.closeBulkOpertion=function(){
    $.modal.close();
    $("#successNo,#failedNo,#bulkUploadList,#errorLogModalTable").html("");
    $("#BulkUploadOptionModal #bulkUploadFileSelectionTab,p.successMsg, p.errorMsg, #errorLogModalTable,#bulkUploadDataMappingTab .spinner,#exportToExcelButton").show();
    $("#BulkUploadOptionModal #bulkUploadDataMappingTab,#bulkUploadErrorLogModal").hide();
    $("#selectOption > select:not(:first),#selectOption > select option:not(:first)").remove();
    $("div.successDiv").css("display", "none");
    $("#columnErrorMsg").removeClass("errorMsg");
    $('input[name=uploadType][value="bulkAdd"],#isContainsHeader').prop('checked', 'true');
    $('#drop').html("Drag & Drop file here");
    $('#bulkUploadStep1Btn').attr('disabled', 'disabled');
    $('#bulkUploadFormWrapper').trigger("reset");
    Maptician.BulkUpload.hasInit=true;
    report.table.ajax.reload();
}



//this function map the key with value pair 
Maptician.BulkUpload.dataMaping=function(){
    var typeOfUpload=$('input[name=uploadType]:checked').val();
    $("#bulkUploadBtn").off().on("click",function(){
        Maptician.BulkUpload.sendDataToSave(typeOfUpload,Maptician.BulkUpload.headerChecked);
    })
    
}
//this function validate duplicate key
Maptician.BulkUpload.validateDuplicateKey = function (headers,arr){
    var found = false;
    var message = null;
    for(var i=0;i <headers.length;i++){
        var value = $(headers[i]).html();
        if(value!=""){
            for(var j=0;j<arr.length;j++){
                if(value == arr[j]){
                    found = true;
                    break;
                }
            }
            if(found){
                message = value + " cannot be mapped to multiple columns";
                break;
            }else{
                arr.push(value);
            }
        }
    }
    if(arr.length == 0){
        message = "Please map the columns to proceed";
    }
    return message;
}

//this function validate cotains key
Maptician.BulkUpload.containsAll=function (needles, haystack){ 
  for(var i = 0 , len = needles.length; i < len; i++){
     if($.inArray(needles[i], haystack) == -1) return false;
  }
  return true;
}

//This function validate all the required fields are mapped by User in step 2. 
//Error is thrown if the required field is not mapped.
Maptician.BulkUpload.validateRequiredKey = function (headers,arr,typeOfUpload){
    var requiredmessage = null;
    if(typeOfUpload == "bulkUpdate"){
        var requiredHeader = ["EmployeeID"];
        if(!Maptician.BulkUpload.containsAll(requiredHeader,arr)){
             requiredmessage="Please map the columns which needs to be updated with respect to the Employee ID";
        }
    }
    else{
        var requiredHeader = ["Email","First","UserType","UserStatus","EmployeeID"];
        if(!Maptician.BulkUpload.containsAll(requiredHeader,arr)){
             requiredmessage="Please map Email ID, First Name, Employee ID, User Type and User Status to proceed";
            //var current = [1, 2, 3, 4],
                //prev = [1, 2, 4],
            /* var missing = null;

            var i = 0,lenC = requiredHeader.length;

            for ( ; i < lenC; i++ ) {
                if ( arr.indexOf(requiredHeader[i]) == -1 ) missing = requiredHeader[i]; // Current[i] isn't in prev
            }

            alert(missing);*/
        }
    }
    return requiredmessage;
}

//This function prepare the key value of json data.Keys are the select option what user has selected in the modal w.r.t to the columns 
// Once the json data is prepared , it is submitted to the rest api and success and error view is created based on te response from the server.
Maptician.BulkUpload.sendDataToSave=function(typeOfUpload,headerChecked){
    var headerValue=[];
    var keyLength=$("#bulkUploadList tr:nth-child(1) > td").length;
    for(var i=0;i<keyLength;i++){
            var valueOfSelect=document.getElementsByClassName("bulkUploadMapingSelect")[i].value;
            headerValue.push(valueOfSelect);
            var str=document.getElementsByClassName("headerdata")[i].innerHTML;
            var res = str.replace(str, valueOfSelect);
            document.getElementsByClassName("headerdata")[i].innerHTML = res;
        }
    var myRows = [];
    var $headers = $("#bulkUploadList tr:nth-child(1) > td.headerdata");
    var arr = [];
    var msg = '';
    msg=Maptician.BulkUpload.validateDuplicateKey($headers,arr);
    var newmsg=Maptician.BulkUpload.validateRequiredKey($headers,arr,typeOfUpload);
    if(msg!=null){
        $( "#columnErrorMsg").addClass("errorMsg");
        $("#duplicateMsg").html(msg);
        return false;
    }
    if(newmsg!=null){
        $( "#columnErrorMsg").addClass("errorMsg");
        $("#duplicateMsg").html(newmsg);
        return false;
    }
    
    var $rows = $("#bulkUploadList tr").each(function(index) {
      $cells = $(this).find("td");
      myRows[index] = {};
      $cells.each(function(cellIndex) {
        if($($headers[cellIndex]).html()!=""){
            myRows[index][$($headers[cellIndex]).html()] = $(this).html();
        }
      });    
    });
    myRows.shift();
   
    if(headerChecked){
        myRows.shift();
    }
    var myjson = JSON.stringify(myRows);
    var data ={
        data : myjson
    }
    var url = typeOfUpload == "bulkUpdate"? "/api/employees/bulk/updateBulkUser": "/api/employees/bulk/addBulkUser";
    //$("#spinner").show();
   // $("#bulkUploadDataMappingTab .spinner").show();//spinner will show while loading the data from the server
    jQuery.ajax({type:"POST",url:url,data:data,
    success:function(result){
        $("#bulkUploadDataMappingTab .spinner").hide();
        $("#BulkUploadOptionModal #bulkUploadDataMappingTab").hide();
        $("#bulkUploadErrorLogModal").show();
        if(result.failed == 0){
            $("p.successMsg, p.errorMsg, #errorLogModalTable,#exportToExcelButton").hide();
            $("#allSuccessNo").html(result.success);
            if(typeOfUpload == "bulkUpdate"){
                $("div.successDiv").css("display", "block");
                $("div.successDiv #operationType").html(" user(s) successfully updated");
            }else{
                $("div.successDiv").css("display", "block");
                $("div.successDiv #operationType").html(" user(s) successfully added");
            }
            
            Maptician.BulkUpload.hasInit = true; 
        }else{
        $("#successNo").html(result.success);
        $("#failedNo").html(result.failed);
        
        var col = [];
        var lastCol=[];
        for (var b = 0; b < result.error.length; b++) {
            for (var key in result.error[b]) {
                if (col.indexOf(key) === -1) {
                    col.push(key);
                }
            }
        }
        // CREATE DYNAMIC TABLE.
        var table = document.createElement("table");
         var errorlogObj=[];
        // CREATE HTML TABLE HEADER ROW USING THE EXTRACTED HEADERS ABOVE.
               // TABLE ROW.
        var tr = table.insertRow(-1);                   // TABLE ROW.

        for (var i = 0; i < col.length; i++) {
            var th = document.createElement("th");      // TABLE HEADER.
            th.innerHTML = col[i];
            tr.appendChild(th);
        }

        // ADD JSON DATA TO THE TABLE AS ROWS.
        for (var a = 0; a < result.error.length; a++) {

            tr = table.insertRow(-1);

            for (var j = 0; j < col.length-1; j++) {
                var tabCell = tr.insertCell(-1);
                tabCell.innerHTML = result.error[a][col[j]];
            }
            for (var k = col.length-1; k < col.length; k++) {
                var tabCell = tr.insertCell(-1);
                tabCell.innerHTML='';
               
                for(var l=0;l<result.error[a].errorObj.length;l++){
                    //tr = table.insertRow(-1);
                    var valueInList = "<li>" + result.error[a].errorObj[l].errorMsg + "</li>";
                    tabCell.innerHTML+=valueInList;
                }

                
            }
        }

        // FINALLY ADD THE NEWLY CREATED TABLE WITH JSON DATA TO A CONTAINER.
        var divContainer = document.getElementById("errorLogModalTable");
        divContainer.innerHTML = "";
        divContainer.appendChild(table);
        $("#errorLogModalTable > table > tbody > tr:nth-child(1) > th:nth-child(1)").html("Record Number");
        $("#errorLogModalTable > table > tbody > tr:nth-child(1) > th:nth-child(2)").html("Employee ID");
        $("#errorLogModalTable > table > tbody > tr:nth-child(1) > th:nth-child(3)").html("Error Message(s)");

        $("#exportToExcelButton").on("click",function(){
            function s2ab(s) {
                if(typeof ArrayBuffer !== 'undefined') {
                    var buf = new ArrayBuffer(s.length);
                    var view = new Uint8Array(buf);
                    for (var i=0; i!=s.length; ++i) view[i] = s.charCodeAt(i) & 0xFF;
                    return buf;
                } else {
                    var buf = new Array(s.length);
                    for (var i=0; i!=s.length; ++i) buf[i] = s.charCodeAt(i) & 0xFF;
                    return buf;
                }
            }
            function export_table_to_excel(id, type) {
                var wb = XLSX.utils.table_to_book(document.getElementById(id), {sheet:"Sheet 1"});
                var wbout = XLSX.write(wb, {bookType:type, bookSST:true, type: 'binary'});
                var fname = 'bulkUploadErrorLogTable.' + type;
                try {
                    saveAs(new Blob([s2ab(wbout)],{type:"application/octet-stream"}), fname);
                } catch(e) { if(typeof console != 'undefined') console.log(e, wbout); }
                return wbout;
                }

                export_table_to_excel('errorLogModalTable','xlsx');
        })
  
        
        }
    },
    error: function (error) {
        $("#bulkUploadDataMappingTab .spinner").hide();
    }
    });
    $("#closeModal").on("click", function() {
        Maptician.BulkUpload.closeBulkOpertion();
    })
    
}
	    this.dataParing=function(){
		    for (var i=0;i<Maptician.BulkUpload.mapingOption.length;i++){
		       Maptician.BulkUpload.option += '<option value="'+ Maptician.BulkUpload.mapingOption[i] + '">' + Maptician.BulkUpload.mapingOptionName[i] + '</option>';
		    }
		    $('#selectOption select:nth-child(1)').append(Maptician.BulkUpload.option);
		    if(!Maptician.BulkUpload.hasInit){
		        var X = XLSX;
		        var XW = {
		            /* worker message */
		            msg: 'xlsx',
		            /* worker scripts */
		            worker: './javascripts/app/company/xlsxworker.js'
		        };
		        var global_wb;
		        var process_wb = (function() {
		            var OUT = document.getElementById('out');
		            var HTMLOUT = document.getElementById('bulkUploadList');
		            var to_html = function to_html(workbook) {
		                HTMLOUT.innerHTML = "";
		                workbook.SheetNames.forEach(function(sheetName) {
		                    var htmlstr = X.write(workbook, {sheet:sheetName, type:'binary', bookType:'html'});
		                    HTMLOUT.innerHTML += htmlstr;
		                    $("#selectOption > select:not(:first)").remove();
		                    Maptician.BulkUpload.gotData=true;
		                    Maptician.BulkUpload.dynamicSelect();
		                    Maptician.BulkUpload.dynamicHeader();
		                    $("#bulkUploadList tr:nth-child(1) td").addClass("headerdata");
		                    $("#bulkUploadDataMappingTab .spinner").hide();
		                });
		                return "";
		            };
		            return function process_wb(wb) {
		                global_wb = wb;
		                var output = "";
		                output = to_html(wb);
		                if(OUT.innerText === undefined) OUT.textContent = output;
		                else OUT.innerText = output;
		                if(typeof console !== 'undefined') console.log("output", new Date());
		            };
		        })();
		        var setfmt = window.setfmt = function setfmt() { if(global_wb) process_wb(global_wb); };
		        var do_file = (function() {
		            var rABS = typeof FileReader !== "undefined" && (FileReader.prototype||{}).readAsBinaryString;
		            var use_worker = typeof Worker !== 'undefined';
		            var xw = function xw(data, cb) {
		                var worker = new Worker(XW.worker);
		                worker.onmessage = function(e) {
		                    switch(e.data.t) {
		                        case 'ready': break;
		                        case 'e': console.error(e.data.d); break;
		                        case XW.msg: cb(JSON.parse(e.data.d)); break;
		                    }
		                };
		                worker.postMessage({d:data,b:rABS?'binary':'array'});
		            };
		            return function do_file(files) {
		                var f = files[files.length-1];
		                Maptician.BulkUpload.fileType = f.name.split('.').pop();
		                
		                $('#bulkUploadStep1Btn').removeAttr('disabled');
		                console.log(Maptician.BulkUpload.fileType);
		                if(Maptician.BulkUpload.fileType=="xlsx" || Maptician.BulkUpload.fileType=="xls"){
		                    var reader = new FileReader();
		                    reader.onload = function(e) {
		                        if(typeof console !== 'undefined') console.log("onload", new Date(), rABS, use_worker);
		                        var data = e.target.result;
		                        if(!rABS) data = new Uint8Array(data);
		                        if(use_worker) xw(data, process_wb);
		                        else process_wb(X.read(data, {type: rABS ? 'binary' : 'array'}));
		                    };
		                    if(rABS) reader.readAsBinaryString(f);
		                    else reader.readAsArrayBuffer(f);
		                }
		                else if(Maptician.BulkUpload.fileType=="csv"){
		                    if (typeof (FileReader) != "undefined") {
		                    Maptician.BulkUpload.fileTypeIsCsv=true;
		                    $('#bulkUploadStep1Btn').removeAttr('disabled');
		                    var csvParser = new SimpleExcel.Parser.CSV();
		                    csvParser.setDelimiter(',');
		                    csvParser.loadFile(f, function () {

		                        // draw HTML table based on sheet data
		                        var sheet = csvParser.getSheet();
		                        var table = document.getElementById('bulkUploadList');
		                        table.innerHTML = "";
		                        sheet.forEach(function (el, i) {                    
		                            var row = document.createElement('tr');
		                            el.forEach(function (el, i) {
		                                var cell = document.createElement('td');
		                                cell.innerHTML = el.value;
		                                row.appendChild(cell);
		                            });
		                            table.appendChild(row);
		                        });  
		                        var rowCount = table.rows.length; 
		                        $("#selectOption > select:not(:first)").remove();
		                         $("#bulkUploadList tr:nth-child(1) td").addClass("headerdata");
		                         $("#bulkUploadDataMappingTab .spinner").hide();
		                        Maptician.BulkUpload.gotData=true;
		                        Maptician.BulkUpload.dynamicSelect();
		                        Maptician.BulkUpload.dynamicHeader();
		                        table.deleteRow(rowCount);                 
		                    });
		                    } else {
		                        swal({
		                            title: "Bulk Upload Error",
		                            text: "This browser does not support HTML5",
		                            type: "error",
		                        });
		                    }     
		                }
		                else{
		                    swal({
		                        title: "Bulk Upload Error",
		                        text: "Please select a .xlsx, .xls or .csv file",
		                        type: "error",
		                    });
		                    document.getElementById("xlf").value = "";
		                    $('#bulkUploadStep1Btn').attr('disabled', 'disabled');
		                    $('#bulkUploadFormWrapper').trigger("reset");
		                }
		                
		            };
		        })();
		        var drop = document.getElementById('drop');
		        if(!drop.addEventListener) return;
		        function handleDrop(e) {
		            e.stopPropagation();
		            e.preventDefault();
		            do_file(e.dataTransfer.files);
		            var file = e.dataTransfer.files[0];
		             if(Maptician.BulkUpload.fileType=="xlsx" || Maptician.BulkUpload.fileType=="xls" ||Maptician.BulkUpload.fileType=="csv"){
		                e.target.innerHTML=file.name;
		                var input=document.getElementById("xlf");
		                input.value = '';
		                if(!/safari/i.test(navigator.userAgent)){
		                  input.type = ''
		                  input.type = 'file'
		                }
		           }
		        }
		        function handleDragover(e) {
		            e.stopPropagation();
		            e.preventDefault();
		            e.dataTransfer.dropEffect = 'copy';
		        }
		        drop.addEventListener('dragenter', handleDragover, false);
		        drop.addEventListener('dragover', handleDragover, false);
		        drop.addEventListener('drop', handleDrop, false);
		        var xlf = document.getElementById('xlf');
		        if(!xlf.addEventListener) return;
		        function handleFile(e) { 
		            do_file(e.target.files);
		            $('#drop').text("Drag & Drop file here");
		        }
		        xlf.addEventListener('change', handleFile, false);
		        $("#bulkUploadStep1Btn").on("click",function(){
		            $("#BulkUploadOptionModal #bulkUploadFileSelectionTab").hide();
		            $("#BulkUploadOptionModal #bulkUploadDataMappingTab").show();
		            $("#duplicateMsg").html("");
		            Maptician.BulkUpload.dataMaping();
		        })
		        $("#bulkUploadGoBackBtn").off().on("click",function(){
		            $("#BulkUploadOptionModal #bulkUploadFileSelectionTab,#bulkUploadDataMappingTab .spinner").show();
		            $("#BulkUploadOptionModal #bulkUploadDataMappingTab,#bulkUploadDataMappingTab .spinner").hide();
		            //$("#bulkUploadList tr:nth-child(2)").remove();
		            $("#columnErrorMsg").removeClass("errorMsg");
		        })
		    }      
		}
		$('#BulkUploadOptionModal').modal({
	        clickClose: false
	      });
	    document.getElementById("xlf").value = "";
	    this.dataParing();
	    $("#BulkUploadOptionModal .close-modal ").on("click",function(){
	        Maptician.BulkUpload.closeBulkOpertion();   
	    })
	}

}
$Map.Components.Company.userMgmtList.prototype.constructor = $Map.Components.Company.userMgmtList;

$Map.Components.CompanyReports = function(companyController){
	this.companyController = companyController;
	this.reportSelector = $("#companyReports select.reports-select");
	this.openReport = null;
	var Reports = this;

	// Office List - done
	// Map List
	// User List
	// Seat List
	// Room List
	// Zone List
	// Kiosk List
	// Visitor Log
	// Message Use

	this.open = function(){
		this.reportSelector.val(0);
		this.setBindings();
	}

	this.exit = function(){
		this.openReport.report.exit();
		this.openReport = null;
		this.unsetBindings();
	}

	this.setBindings = function(){
		this.reportSelector.on('change',function(){
			var index = 1*$(this).val();
			console.log('selected:',index)
			if(Reports.openReport && Reports.openReport.index != index){
				Reports.openReport.report.exit();				
			}

			switch(index){
				case 0:
				break;				
				case 1:
					console.log('selected1')
					Reports.officeList = Reports.officeList || new $Map.Components.CompanyReports.officeList();
					Reports.officeList.open();
					Reports.openReport = {index:index,report:Reports.officeList};
				break;
				case 2:
					Reports.mapList = Reports.mapList || new $Map.Components.CompanyReports.mapList();
					Reports.mapList.open();
					Reports.openReport = {index:index,report:Reports.mapList};
				break;
				case 3:
					Reports.seatList = Reports.seatList || new $Map.Components.CompanyReports.seatList();
					Reports.seatList.open();
					Reports.openReport = {index:index,report:Reports.seatList};
				break;
				case 4:
					Reports.userList = Reports.userList || new $Map.Components.CompanyReports.userList();
					Reports.userList.open();
					Reports.openReport = {index:index,report:Reports.userList};
				break;
				case 5:
					Reports.zoneList = Reports.zoneList || new $Map.Components.CompanyReports.zoneList();
					Reports.zoneList.open();
					Reports.openReport = {index:index,report:Reports.zoneList};
				break;
				case 6:
					Reports.roomList = Reports.roomList || new $Map.Components.CompanyReports.roomList();
					Reports.roomList.open();
					Reports.openReport = {index:index,report:Reports.roomList};
				break;
				case 7:
					Reports.occupantList = Reports.occupantList || new $Map.Components.CompanyReports.occupantList();
					Reports.occupantList.open();
					Reports.openReport = {index:index,report:Reports.occupantList};
				break;
				case 8:
					Reports.visitorList = Reports.visitorList || new $Map.Components.CompanyReports.visitorList();
					Reports.visitorList.open();
					Reports.openReport = {index:index,report:Reports.visitorList};
				break;
			}
		})
	}

	this.unsetBindings = function(){
		this.reportSelector.off('change');
	}
}
$Map.Components.CompanyReports.prototype.constructor = $Map.Components.CompanyReports;

$Map.Components.CompanyReports.officeList = function(){
	this.url = '../api/company/reports/officeList';
	this.tableContainer = $("#companyReports .table-container")
	this.tableElement = $("#companyReportTable");
	this.tableColumns = 11;
	this.table = null;
	this.tableOffset = 110;
	this.namespace = 'officeListReport';
	var report = this;

	this.open = function(officeID){
		this.createFooter();
		this.setTable();
		this.setBindings(this.namespace);
		this.isOpen = true;
	}

	this.exit = function(){
		this.unsetBindings();
		this.table && this.table.clear().destroy(); // Clears datatable
		this.table = null;		
		this.tableElement.children().remove(); // Removes table remaining table elements (except table)
		this.isOpen = false;
	}

	this.update = function(officeID){
		report.table.ajax.reload();
	}

	this.setTable = function(){
		this.table = this.table || this.tableElement.DataTable({
			ajax: {
				url: this.url
			},
			rowId: 'officeName',
			select: {
				style: 'single',
				className: 'selected',
				selector: 'tr:not(.selected)'
			},
			scrollY: report.tableContainer.height() - this.tableOffset,
			deferRender:true,
			scroller:true,
			paging:true,
			autoWidth:true,
			fixedHeader:{
				footer: true
			},
			columns:[
				{
					width: 100,
					title: "Office Name",
					data: {},
					class: 'leftAlign',
					render: function(office){
						return office.officeName || "";
					}
				},
				{
					width: 50,
					title: "City",
					data: {},
					class: 'centerAlign',
					render: function(office){
						return office.city || "";
					}
				},
				{
					width: 30,
					title: "State",
					data: {},
					class: 'centerAlign',
					render: function(office){
						return office.state || "";
					}
				},
				{
					width: 30,
					title: "Maps",
					data: {},
					class: 'centerAlign',
					render: function(office){
						if(office.mapCount){
							return '<a class="mapDrillDown" href="#">'+office.mapCount+'</a>';
						} else {
							if(office.maps){
								office.mapCount = office.maps.length;                              
							} else {
								office.mapCount = 0;
								return office.mapCount
							}
							return '<a class="mapDrillDown" href="#">'+office.mapCount+'</a>';
						}
					}
				},
				{
					width: 30,
					title: "Zones",
					data: {},
					class: 'centerAlign',
					render: function(office){
						if(office.zoneCount){
							return '<a class="zoneDrillDown" href="#">'+office.zoneCount+'</a>';
						} else {
							if(office.zones){
								office.zoneCount = office.zones.length;                              
							} else {
								office.zoneCount = 0;
								return office.zoneCount
							}
							return '<a class="zoneDrillDown" href="#">'+office.zoneCount+'</a>';
						}
					}
				},
				{
					width: 30,
					title: "Rooms",
					data: {},
					class: 'centerAlign',
					render: function(office){
						if(office.roomCount){
							return '<a class="roomDrillDown" href="#">'+office.roomCount+'</a>';
						} else {
							if(office.rooms){
								office.roomCount = office.rooms.length;                              
							} else {
								office.roomCount = 0;
								return office.roomCount
							}
							return '<a class="roomDrillDown" href="#">'+office.roomCount+'</a>';
						}
					}
				},
				{
					width: 30,
					title: "Seats",
					data: {},
					class: 'centerAlign',
					render: function(office){
						if(office.seatCount){
							return '<a class="seatDrillDown" href="#">'+office.seatCount+'</a>';
						} else {
							if(office.seats){
								office.seatCount = office.seats.length;                              
							} else {
								office.seatCount = 0;
								return office.seatCount
							}
							return '<a class="seatDrillDown" href="#">'+office.seatCount+'</a>';
						}
					}
				},
				{
					width: 30,
					title: "Assigned",
					data: {},
					class: 'centerAlign',
					render: function(office){
						var seats = office.seats;
						var result = 0;
						if(office.assignedSeats){
							return '<a class="assignedSeatDrillDown" href="#">'+office.assignedSeats+'</a>';
						} else {
							for(var i in seats){
								if(seats[i].assignmentStatus == "Assigned"){
									result += 1;
								}
							}
							office.assignedSeats = result;
							if(result == 0){
								return result;
							}
							return '<a class="assignedSeatDrillDown" href="#">'+office.assignedSeats+'</a>';
						}
					}
				},
				{
					width: 30,
					title: "Available",
					data: {},
					class: 'centerAlign',
					render: function(office){
						var seats = office.seats;
						var result = 0;
						if(office.availableSeats){
							return '<a class="unassignedSeatDrillDown" href="#">'+office.availableSeats+'</a>';
						} else {
							for(var i in seats){
								if(seats[i].assignmentStatus == "Unassigned" && seats[i].reservable == false){
									result += 1;
								}
							}
							office.availableSeats = result;
							if(result == 0){
								return result;
							}
							return '<a class="unassignedSeatDrillDown" href="#">'+office.availableSeats+'</a>';
						}
					}
				},
				{
					width: 50,
					title: "Utilization",
					data: {},
					render: function(office){
						var assignableSeats = office.assignedSeats + office.availableSeats;
						var value = 100 * office.assignedSeats / assignableSeats;
						if(assignableSeats == 0){value = 0;}
						var myString = "";
						myString += '<div class="cssProgress"><div class="progress3">';
						myString += '<div class="cssProgress-bar cssProgress-success" data-percent="';
						myString += value;
						myString += '" style="width:';
						myString += value;
						myString += '%;"><span class="cssProgress-label">';
						myString += round(value,0);
						myString += '%</span></div></div></div>';
						return myString;
					}
				},
				{
					width: 30,
					title: "Reservable",
					data: {},
					class: 'centerAlign',
					render: function(office){
						var seats = office.seats;
						var result = 0;
						if(office.reservableSeats){
							return '<a class="reservedSeatsDrilldown" href="#">'+office.reservableSeats+'</a>';
						} else {
							for(var i in seats){
								if(seats[i].reservable){
									result += 1;
								}
							}
							office.reservableSeats = result;
							if(result == 0){
								return result;
							}
							return '<a class="reservedSeatsDrilldown" href="#">'+office.reservableSeats+'</a>';
						}
					}
				},
			],
			footerCallback: function(row,data,start,end,display){
				var api = this.api();
	 
				var maps = api
					.column(3,{search:'applied'})
					.data()
					.reduce( function (a, b) {
						return b.mapCount + a;
					}, 0 );
				$( api.column( 3 ).footer() ).html(
					maps
				);

				var zones = api
					.column(4,{search:'applied'})
					.data()
					.reduce( function (a, b) {
						return b.zoneCount + a;
					}, 0 );
				$( api.column( 4 ).footer() ).html(
					zones
				);

				var rooms = api
					.column(5,{search:'applied'})
					.data()
					.reduce( function (a, b) {
						return b.roomCount + a;
					}, 0 );
				$( api.column( 5 ).footer() ).html(
					rooms
				);

				var seats = api
					.column(6,{search:'applied'})
					.data()
					.reduce( function (a, b) {
						return b.seatCount + a;
					}, 0 );
				$( api.column( 6 ).footer() ).html(
					seats
				);

				var assignedSeats = api
					.column(7,{search:'applied'})
					.data()
					.reduce( function (a, b) {
						return b.assignedSeats + a;
					}, 0 );
				$( api.column( 7 ).footer() ).html(
					assignedSeats
				);

				var availableSeats = api
					.column(8,{search:'applied'})
					.data()
					.reduce( function (a, b) {
						return b.availableSeats + a;
					}, 0 );
				$( api.column( 8 ).footer() ).html(
					availableSeats
				);

				var assignable = assignedSeats + availableSeats;
				var value = seats > 0 ? 100 * assignedSeats / assignable : "NA";
				var myString = "";
				myString += '<div class="cssProgress"><div class="progress3">';
				myString += '<div class="cssProgress-bar cssProgress-success" data-percent="';
				myString += value;
				myString += '" style="width:';
				myString += value;
				myString += '%;"><span class="cssProgress-label">';
				myString += value !== null ? round(value,0) +"%" : "N/A";
				myString += '</span></div></div></div>';
				$( api.column( 9 ).footer() ).html(
					myString
				);

				var reservableSeats = api
					.column(10,{search:'applied'})
					.data()
					.reduce( function (a, b) {
						return b.reservableSeats + a;
					}, 0 );
				$( api.column( 10 ).footer() ).html(
					reservableSeats
				);
			},
			dom: 'brt'
		})
	}

	this.setBindings = function(namespace){
		table = this.table;

		// Handles row selection
		// table && table.on( 'select.' + namespace , function ( e, dt, type, indexes ) {
		// 	report.selector = table.rows(indexes);
		// 	report.selected = report.selector.data().toArray()[0].mapID;
		// })

		// Resizes the table based on a change in the height of parent element (resize event)
		// Does this by creating an iframe in the same space and listening for a resize
		_attach.call(table,this.namespace,this.tableOffset,function(height){
			report.tableElement.parent().css("height",height - 30);
			table.draw();
		});

		// Redraws the map when the leftNav is maximized or minimized.
		// Needed to keep the columns and headers aligned during the resize
		$("#sidebarMin,#sidebarMax").on('click.'+namespace,function(){
			var tableContext = table;
			setTimeout(function(){
				tableContext.draw();
			},300)
		})

		// Add event listener for opening seat table modal for all seats
		table && table.on('click.'+namespace, 'td a.mapDrillDown', function () {
			var data = report.table.row($(this).closest('tr')).data();
			var maps = data.maps;
			var mapIDArray = [];
			for(var i in maps){mapIDArray.push(maps[i])}
			$Map.ModalTables.mapTable(mapIDArray);
		});
		
		// Add event listener for opening seat table modal for all seats
		table && table.on('click.'+namespace, 'td .seatDrillDown', function () {
			var data = report.table.row($(this).closest('tr')).data();
			var seats = data.seats;
			var seatIDArray = [];
			for(var i in seats){seatIDArray.push(seats[i].seatID)}
			$Map.ModalTables.seatTable(seatIDArray);
		});

		// Add event listener for opening seat table modal for assigned seats
		table && table.on('click.'+namespace, 'td .assignedSeatDrillDown', function () {
			var data = report.table.row($(this).closest('tr')).data();
			var seats = data.seats;
			var seatIDArray = [];
			for(var i in seats){
				if(seats[i].assignmentStatus == "Assigned"){
					seatIDArray.push(seats[i].seatID)
				}
			}
			$Map.ModalTables.seatTable(seatIDArray);
		});

		// Add event listener for opening seat table modal for unassigned seats
		table && table.on('click.'+namespace, 'td .unassignedSeatDrillDown', function () {
			var data = report.table.row($(this).closest('tr')).data();
			var seats = data.seats;
			var seatIDArray = [];
			for(var i in seats){
				if(seats[i].assignmentStatus == "Unassigned" && seats[i].reservable == false){
					seatIDArray.push(seats[i].seatID)
				}
			}
			$Map.ModalTables.seatTable(seatIDArray);
		});

		// Add event listener for opening seat table modal for reservable seats
		table && table.on('click.'+namespace, 'td .reservedSeatsDrilldown', function () {
			var data = report.table.row($(this).closest('tr')).data();
			var seats = data.seats;
			var seatIDArray = [];
			for(var i in seats){
				if(seats[i].reservable){
					seatIDArray.push(seats[i].seatID)
				}
			}
			$Map.ModalTables.seatTable(seatIDArray);
		});

		// Add event listener for opening room table modal when room data cells are clicked
		table && table.on('click.'+namespace, 'td .roomDrillDown', function () {
			var data = report.table.row($(this).closest('tr')).data();
			var rooms = data.rooms;
			var roomIDArray = [];
			for(var i in rooms){
				roomIDArray.push(rooms[i])
			}
			$Map.ModalTables.roomTable(roomIDArray);
		});

		// Add event listener for opening zone table modal when zone data cells are clicked
		table && table.on('click.'+namespace, 'td .zoneDrillDown', function () {
			var data = report.table.row($(this).closest('tr')).data();
			var zones = data.zones;
			var zoneIDArray = [];
			for(var i in zones){
				zoneIDArray.push(zones[i])
			}
			$Map.ModalTables.zoneTable(zoneIDArray);
		});

		// // Add event listener for the edit button
		// table && table.on('click.'+namespace,'.editMapButton', function () {
		// 	var data = table.row($(this).closest('tr')).data();
		// 	var editData = {
		// 		id: data.mapID
		// 	}
		// 	$.ajax({type:"GET",url: "/loadMapFile",data:editData,
		// 		success:function(result){
		// 			$("#editorMenu a").trigger('click');
		// 			$Map.Editor.loadFile(result);
		// 		}
		// 	})
		// });

		// // Add event listener for the view button
		// table && table.on('click.'+namespace,'.viewMapButton', function () {
		// 	var data = table.row($(this).closest('tr')).data();
		// 	var editData = {
		// 		id: data.mapID
		// 	}
		// 	$.ajax({type:"GET",url: "/loadMapFile",data:editData,
		// 		success:function(result){
		// 			$("#viewerMenu a").trigger('click');
		// 			$Map.Viewer.loadFile(result);
		// 		}
		// 	})
		// });
	}

	this.unsetBindings = function(){
		$(document).off('.'+this.namespace);
		$("#"+this.namespace).remove(); // Remove iframe
	}

	this.createFooter = function(){
		var footer = "";
		footer += "<tfoot><tr>";
		for(var i = 0; i < this.tableColumns; i++){footer+= "<td></td>"}
		footer += "</tr></tfoot>";
		this.tableElement.append(footer);
	}
}
$Map.Components.CompanyReports.officeList.prototype.constructor = $Map.Components.CompanyReports.officeList;

$Map.Components.CompanyReports.mapList = function(){
	this.url = '../api/company/reports/mapList';
	this.tableContainer = $("#companyReports .table-container")
	this.tableElement = $("#companyReportTable");
	this.tableColumns = 12;
	this.table = null;
	this.tableOffset = 110;
	this.namespace = 'mapListReport';
	var report = this;

	this.open = function(officeID){
		this.createFooter();
		this.setTable();
		this.setBindings(this.namespace);
		this.isOpen = true;
	}

	this.exit = function(){
		this.unsetBindings();
		this.table && this.table.clear().destroy(); // Clears datatable
		this.table = null;		
		this.tableElement.children().remove(); // Removes table remaining table elements (except table)
		this.isOpen = false;
	}

	this.update = function(officeID){
		report.table.ajax.reload();
	}

	this.setTable = function(){
		this.table = this.table || this.tableElement.DataTable({
			ajax: {
				url: this.url
			},
			rowId: 'mapID',
			select: {
				style: 'single',
				className: 'selected',
				selector: 'tr:not(.selected)'
			},
			scrollY: report.tableContainer.height() - this.tableOffset,
			deferRender:true,
			scroller:true,
			paging:true,
			autoWidth:true,
			fixedHeader:{
				footer: true
			},
			columns:[
				{
					width: 100,
					title: "Map Name",
					data: {},
					class: 'leftAlign',
					render: function(map){
						return map.name || "";
					}
				},
				{
					width: 50,
					title: "City",
					data: {},
					class: 'centerAlign',
					render: function(map){
						return map.city || "";
					}
				},
				{
					width: 30,
					title: "State",
					data: {},
					class: 'centerAlign',
					render: function(map){
						return map.state || "";
					}
				},
				{
					width: 30,
					title: "Seats",
					data: {},
					class: 'centerAlign',
					render: function(map){
						if(map.seatCount){
							return '<a class="seatDrillDown" href="#">'+map.seatCount+'</a>';
						} else {
							if(map.seats){
								map.seatCount = Object.keys(map.seats).length;                				
							} else {
								map.seatCount = 0;
								return map.seatCount
							}
							return '<a class="seatDrillDown" href="#">'+map.seatCount+'</a>';
						}
					}
				},
				{
					width: 30,
					title: "Assignable",
					data: {},
					class: 'centerAlign',
					render: function(map){
						var seats = map.seats;
						var result = 0;
						if(map.assignableSeats){
							return '<a class="assignableSeatDrilldown" href="#">'+map.assignableSeats+'</a>';
						} else {
							for(var i in seats){
								if(seats[i].reservable == false){
									result += 1;
								}
							}
							map.assignableSeats = result;
							if(result == 0){
								return result;
							}
							return '<a class="assignableSeatDrilldown" href="#">'+map.assignableSeats+'</a>';
						}
					}
				},
				{
					width: 30,
					title: "Assigned",
					data: {},
					class: 'centerAlign',
					render: function(map){
						var seats = map.seats;
						var result = 0;
						if(map.assignedSeats){
							return '<a class="assignedSeatDrillDown" href="#">'+map.assignedSeats+'</a>';
						} else {
							for(var i in seats){
								if(seats[i].assignmentStatus == "Assigned"){
									result += 1;
								}
							}
							map.assignedSeats = result;
							if(result == 0){
								return result;
							}
							return '<a class="assignedSeatDrillDown" href="#">'+map.assignedSeats+'</a>';
						}
					}
				},
				{
					width: 30,
					title: "Available",
					data: {},
					class: 'centerAlign',
					render: function(map){
						var seats = map.seats;
						var result = 0;
						if(map.availableSeats){
							return '<a class="unassignedSeatDrillDown" href="#">'+map.availableSeats+'</a>';
						} else {
							for(var i in seats){
								if(seats[i].assignmentStatus == "Unassigned" && seats[i].reservable == false){
									result += 1;
								}
							}
							map.availableSeats = result;
							if(result == 0){
								return result;
							}
							return '<a class="unassignedSeatDrillDown" href="#">'+map.availableSeats+'</a>';
						}
					}
				},
				{
					width: 30,
					title: "Utilization",
					data: {},
					class: 'centerAlign',
					render: function(map){
						var value = 100 * map.assignedSeats / map.assignableSeats;
						if(map.assignableSeats == 0){value = 0;}
						var myString = "";
						myString += '<div class="cssProgress"><div class="progress3">';
						myString += '<div class="cssProgress-bar cssProgress-success" data-percent="';
						myString += value;
						myString += '" style="width:';
						myString += value;
						myString += '%;"><span class="cssProgress-label">';
						myString += round(value,0);
						myString += '%</span></div></div></div>';
						return myString;
					}
				},
				{
					width: 30,
					title: "Reservable",
					data: {},
					class: 'centerAlign',
					render: function(map){
						var seats = map.seats;
						var result = 0;
						if(map.reservableSeats){
							return '<a class="reservableSeatDrilldown" href="#">'+map.reservableSeats+'</a>';
						} else {
							for(var i in seats){
								if(seats[i].reservable){
									result += 1;
								}
							}
							map.reservableSeats = result;
							if(result == 0){
								return result;
							}
							return '<a class="reservableSeatDrilldown" href="#">'+map.reservableSeats+'</a>';
						}
					}
				},
				{
					width: 50,
					title: "Rooms",
					data: {},
					class: 'centerAlign',
					render: function(map){
						if(map.roomCount){
							return '<a class="roomDrillDown" href="#">'+map.roomCount+'</a>';
						} else {
							if(map.rooms){
								map.roomCount = Object.keys(map.rooms).length;                				
							} else {
								map.roomCount = 0;
							}
							return '<a class="roomDrillDown" href="#">'+map.roomCount+'</a>';
						}
					}
				},
				{
					width: 30,
					title: "Zones",
					data: {},
					class: 'centerAlign',
					render: function(map){
						if(map.zoneCount){
							return '<a class="zoneDrillDown" href="#">'+map.zoneCount+'</a>';
						} else {
							if(map.zones){
								map.zoneCount = Object.keys(map.zones).length;                				
							} else {
								map.zoneCount = 0;
							}
							return '<a class="zoneDrillDown" href="#">'+map.zoneCount+'</a>';
						}
					}
				},
				{
					width: 50,
					data: {},
					"orderable":false,
					render: function(map){
						var myString = "";
						myString += '<div class="btn viewMapButton">View</div><div class="btn editMapButton">Edit</div>';
						return myString;
					},
				}
			],
			footerCallback: function ( row, data, start, end, display ) {
				var api = this.api();
	 
				var seats = api
					.column(3,{search:'applied'})
					.data()
					.reduce( function (a, b) {
						return b.seatCount + a;
					}, 0 );
				$( api.column( 3 ).footer() ).html(
					seats
				);

				var assignable = api
					.column(4,{search:'applied'})
					.data()
					.reduce( function (a, b) {
						return b.assignableSeats + a;
					}, 0 );
				$( api.column( 4 ).footer() ).html(
					assignable
				);

				var assignedSeats = api
					.column(5,{search:'applied'})
					.data()
					.reduce( function (a, b) {
						return b.assignedSeats + a;
					}, 0 );
				$( api.column( 5 ).footer() ).html(
					assignedSeats
				);

				var availableSeats = api
					.column(6,{search:'applied'})
					.data()
					.reduce( function (a, b) {
						return b.availableSeats + a;
					}, 0 );
				$( api.column( 6 ).footer() ).html(
					availableSeats
				);

				var value = seats > 0 ? 100 * assignedSeats / assignable : "NA";
				var myString = "";
				myString += '<div class="cssProgress"><div class="progress3">';
				myString += '<div class="cssProgress-bar cssProgress-success" data-percent="';
				myString += value;
				myString += '" style="width:';
				myString += value;
				myString += '%;"><span class="cssProgress-label">';
				myString += value !== null ? round(value,0) +"%" : "N/A";
				myString += '</span></div></div></div>';
				$( api.column( 7 ).footer() ).html(
					myString
				);

				var reservableSeats = api
					.column(8,{search:'applied'})
					.data()
					.reduce( function (a, b) {
						return b.reservableSeats + a;
					}, 0 );
				$( api.column( 8 ).footer() ).html(
					reservableSeats
				);

				var rooms = api
					.column(9,{search:'applied'})
					.data()
					.reduce( function (a, b) {
						return b.roomCount + a;
					}, 0 );
				$( api.column( 9 ).footer() ).html(
					rooms
				);

				var zones = api
					.column(10,{search:'applied'})
					.data()
					.reduce( function (a, b) {
						return b.zoneCount + a;
					}, 0 );
				$( api.column( 10 ).footer() ).html(
					zones
				);
			},
			dom: 'brt'
		})
	}

	this.setBindings = function(namespace){
		table = this.table;

		// Resizes the table based on a change in the height of parent element (resize event)
		// Does this by creating an iframe in the same space and listening for a resize
		_attach.call(table,this.namespace,this.tableOffset,function(height){
			report.tableElement.parent().css("height",height - 30);
			table.draw();
		});

		// Redraws the map when the leftNav is maximized or minimized.
		// Needed to keep the columns and headers aligned during the resize
		$("#sidebarMin,#sidebarMax").on('click.'+namespace,function(){
			var tableContext = table;
			setTimeout(function(){
				tableContext.draw();
			},300)
		})




		// Add event listener for opening seat table modal for all seats
		table && table.on('click.'+namespace, 'td a.seatDrillDown', function () {
			var data = report.table.row($(this).closest('tr')).data();
			var seats = data.seats;
			var seatIDArray = [];
			for(var i in seats){seatIDArray.push(seats[i].seatID)}
			$Map.ModalTables.seatTable(seatIDArray);
		});
		
		// Add event listener for opening seat table modal for all seats
		table && table.on('click.'+namespace, 'td .assignableSeatDrilldown', function () {
			var data = report.table.row($(this).closest('tr')).data();
			var seats = data.seats;
			var seatIDArray = [];
			for(var i in seats){
				if(seats[i].reservable == false){
					seatIDArray.push(seats[i].seatID)
				}
			}
			$Map.ModalTables.seatTable(seatIDArray);
		});

		// Add event listener for opening seat table modal for assigned seats
		table && table.on('click.'+namespace, 'td .assignedSeatDrillDown', function () {
			var data = report.table.row($(this).closest('tr')).data();
			var seats = data.seats;
			var seatIDArray = [];
			for(var i in seats){
				if(seats[i].assignmentStatus == "Assigned"){
					seatIDArray.push(seats[i].seatID)
				}
			}
			$Map.ModalTables.seatTable(seatIDArray);
		});

		// Add event listener for opening seat table modal for unassigned seats
		table && table.on('click.'+namespace, 'td .unassignedSeatDrillDown', function () {
			var data = report.table.row($(this).closest('tr')).data();
			var seats = data.seats;
			var seatIDArray = [];
			for(var i in seats){
				if(seats[i].assignmentStatus == "Unassigned" && seats[i].reservable == false){
					seatIDArray.push(seats[i].seatID)
				}
			}
			$Map.ModalTables.seatTable(seatIDArray);
		});

		// Add event listener for opening seat table modal for reservable seats
		table && table.on('click.'+namespace, 'td .reservableSeatDrilldown', function () {
			var data = report.table.row($(this).closest('tr')).data();
			var seats = data.seats;
			var seatIDArray = [];
			for(var i in seats){
				if(seats[i].reservable){
					seatIDArray.push(seats[i].seatID)
				}
			}
			$Map.ModalTables.seatTable(seatIDArray);
		});

		// Add event listener for opening room table modal when room data cells are clicked
		table && table.on('click.'+namespace, 'td .roomDrillDown', function () {
			var data = report.table.row($(this).closest('tr')).data();
			var rooms = data.rooms;
			var roomIDArray = [];
			for(var i in rooms){
				roomIDArray.push(rooms[i])
			}
			$Map.ModalTables.roomTable(roomIDArray);
		});

		// Add event listener for opening zone table modal when zone data cells are clicked
		table && table.on('click.'+namespace, 'td .zoneDrillDown', function () {
			var data = report.table.row($(this).closest('tr')).data();
			var zones = data.zones;
			var zoneIDArray = [];
			for(var i in zones){
				zoneIDArray.push(zones[i])
			}
			$Map.ModalTables.zoneTable(zoneIDArray);
		});

		// Add event listener for the view button
		table && table.on('click.'+namespace,'.viewMapButton', function () {
			var data = table.row($(this).closest('tr')).data();
			var editData = {
				id: data.mapID
			}
			$.ajax({type:"GET",url: "/loadMapFile",data:editData,
				success:function(result){
					$("#viewerMenu a").trigger('click');
					$Map.Viewer.loadFile(result);
				}
			})
		});

		// Add event listener for the edit button
		table && table.on('click.'+namespace,'.editMapButton', function () {
			var data = table.row($(this).closest('tr')).data();
			var editData = {
				id: data.mapID
			}
			$.ajax({type:"GET",url: "/loadMapFile",data:editData,
				success:function(result){
					$("#editorMenu a").trigger('click');
					$Map.Editor.loadFile(result);
				}
			})
		});

	}

	this.unsetBindings = function(){
		$(document).off('.'+this.namespace);
		$("#"+this.namespace).remove(); // Remove iframe
	}

	this.createFooter = function(){
		var footer = "";
		footer += "<tfoot><tr>";
		for(var i = 0; i < this.tableColumns; i++){footer+= "<td></td>"}
		footer += "</tr></tfoot>";
		this.tableElement.append(footer);
	}
}
$Map.Components.CompanyReports.mapList.prototype.constructor = $Map.Components.CompanyReports.mapList;

$Map.Components.CompanyReports.seatList = function(){
	this.url = '../api/company/reports/seatList';
	this.tableContainer = $("#companyReports .table-container")
	this.tableElement = $("#companyReportTable");
	this.tableColumns = 9;
	this.table = null;
	this.tableOffset = 50;
	this.namespace = 'seatListReport';
	var report = this;

	this.open = function(officeID){
		//this.createFooter();
		this.setTable();
		this.setBindings(this.namespace);
		this.isOpen = true;
	}

	this.exit = function(){
		this.unsetBindings();
		this.table && this.table.clear().destroy(); // Clears datatable
		this.table = null;		
		this.tableElement.children().remove(); // Removes table remaining table elements (except table)
		this.isOpen = false;
	}

	this.update = function(officeID){
		report.table.ajax.reload();
	}

	this.setTable = function(){
		this.table = this.table || this.tableElement.DataTable({
			ajax: {
				url: this.url
			},
			rowId: 'seatID',
			select: {
				style: 'single',
				className: 'selected',
				selector: 'tr:not(.selected)'
			},
			scrollY: report.tableContainer.height() - this.tableOffset,
			deferRender:true,
			scroller:true,
			paging:true,
			autoWidth:true,
			columns:[
				{
					width: 50,
					data: {},
					class: 'tableProfileImage',
					render: function(seat){
						var path = seat.imagePath || "./../images/blankprofile.png";
						return '<div><img src="'+path+'"></div>';
					}
				},				
				{
					width: 75,
					title: "Seat Name",
					data: {},
					class: 'leftAlign',
					render: function(seat){
						return seat.seatName || "";
					}
				},
				{
					width: 50,
					title: "Department",
					data: {},
					class: 'leftAlign',
					render: function(seat){
						return seat.department || "";
					}
				},
				{
					width: 75,
					title: "Map Name",
					data: {},
					class: 'leftAlign',
					render: function(seat){
						return seat.mapName || "";
					}
				},
				{
					width: 30,
					title: "Type",
					data: {},
					class: 'centerAlign',
					render: function(seat){
						if(seat.reservable){
							return "Reservable";
						} else {
							return "Assignable";
						}
					}
				},
				{
					width: 30,
					title: "Assigned To",
					data: {},
					class: 'centerAlign',
					render: function(seat){
						if(seat.assignmentStatus == "Assigned"){
							return seat.first + ' ' + seat.last;
						} else if(seat.reservable){
							return "N/A";
						} else{
							return "Unassigned";
						}
					}
				},
				{
					width: 30,
					title: "Zone",
					data: {},
					class: 'centerAlign',
					render: function(seat){
						if(seat.zoneCount && seat.zoneCount != 0){
							return '<a class="zoneDrillDown" href="#">'+seat.zoneCount+'</a>';
						} else {
							if(seat.zones && seat.zones.length){
								seat.zoneCount = seat.zones.length;                             
							} else {
								seat.zoneCount = 0;
								return seat.zoneCount;
							}
							return '<a class="zoneDrillDown" href="#">'+seat.zoneCount+'</a>';
						}
					}
				},
				{
					width: 30,
					title: "Room",
					data: {},
					class: 'centerAlign',
					render: function(seat){
						if(seat.roomCount && seat.roomCount != 0){
							return '<a class="roomDrillDown" href="#">'+seat.roomCount+'</a>';
						} else {
							if(seat.rooms && seat.rooms.length){
								seat.roomCount = seat.rooms.length;                             
							} else {
								seat.roomCount = 0;
								return seat.roomCount;
							}
							return '<a class="roomDrillDown" href="#">'+seat.roomCount+'</a>';
						}
					}
				},
				{
					width: 50,
					data: {},
					"orderable":false,
					'className':'buttonCenter',
					render: function(seat){
						if(seat.reservable){
							var myString = "";
							myString += '<div class="btn seatCalendarButton">Reservations</div>';
							return myString;                        
						} else {
							return "";
						}
					},
				}
			],
			dom: 'brt'
		})
	}

	this.setBindings = function(namespace){
		table = this.table;

		// Resizes the table based on a change in the height of parent element (resize event)
		// Does this by creating an iframe in the same space and listening for a resize
		_attach.call(table,this.namespace,this.tableOffset,function(height){
			report.tableElement.parent().css("height",height + 30);
			table.draw();
		});

		// Redraws the map when the leftNav is maximized or minimized.
		// Needed to keep the columns and headers aligned during the resize
		$("#sidebarMin,#sidebarMax").on('click.'+namespace,function(){
			var tableContext = table;
			setTimeout(function(){
				tableContext.draw();
			},300)
		})

		// Add event listener for opening room table modal when room data cells are clicked
		table && table.on('click.'+namespace, 'td .roomDrillDown', function () {
			var data = report.table.row($(this).closest('tr')).data();
			var rooms = data.rooms;
			var roomIDArray = [];
			for(var i in rooms){
				roomIDArray.push(rooms[i]);
			}
			$Map.ModalTables.roomTable(roomIDArray);
		});

		// Add event listener for opening zone table modal when zone data cells are clicked
		table && table.on('click.'+namespace, 'td .zoneDrillDown', function () {
			var data = report.table.row($(this).closest('tr')).data();
			var zones = data.zones;
			var zoneIDArray = [];
			for(var i in zones){
				zoneIDArray.push(zones[i]);
			}
			$Map.ModalTables.zoneTable(zoneIDArray);
		});

	}

	this.unsetBindings = function(){
		$(document).off('.'+this.namespace);
		$("#"+this.namespace).remove(); // Remove iframe
	}

	this.createFooter = function(){
		var footer = "";
		footer += "<tfoot><tr>";
		for(var i = 0; i < this.tableColumns; i++){footer+= "<td></td>"}
		footer += "</tr></tfoot>";
		this.tableElement.append(footer);
	}
}
$Map.Components.CompanyReports.seatList.prototype.constructor = $Map.Components.CompanyReports.seatList;

$Map.Components.CompanyReports.userList = function(){
	this.url = '../api/company/reports/userList';
	this.tableContainer = $("#companyReports .table-container")
	this.tableElement = $("#companyReportTable");
	this.tableColumns = 8;
	this.table = null;
	this.tableOffset = 110;
	this.namespace = 'userListReport';
	var report = this;

	this.open = function(officeID){
		//this.createFooter();
		this.setTable();
		this.setBindings(this.namespace);
		this.isOpen = true;
	}

	this.exit = function(){
		this.unsetBindings();
		this.table && this.table.clear().destroy(); // Clears datatable
		this.table = null;		
		this.tableElement.children().remove(); // Removes table remaining table elements (except table)
		this.isOpen = false;
	}

	this.update = function(officeID){
		report.table.ajax.reload();
	}

	this.setTable = function(){
		this.table = this.table || this.tableElement.DataTable({
			ajax: {
				url: this.url
			},
			rowId: 'userID',
			select: {
				style: 'single',
				className: 'selected',
				selector: 'tr:not(.selected)'
			},
			scrollY: report.tableContainer.height() - this.tableOffset,
			deferRender:true,
			scroller:true,
			paging:true,
			autoWidth:true,
			columns:[
				{
					width: 50,
					data: {},
					class: 'tableProfileImage',
					render: function(user){
						return '<div><img src="'+user.profile+'"></div>';
					}
				},				
				{
					width: 75,
					title: "Name",
					data: {},
					class: 'leftAlign',
					render: function(user){
						return user.first + " " + user.last;
					}
				},
				{
					width: 50,
					title: "Employee ID",
					data: {},
					class: 'centerAlign',
					render: function(user){
						if(user.employee && user.employee.employeeID){
							return user.employee.employeeID;
						} else{
							return "";
						}
					}
				},
				{
					width: 30,
					title: "Title",
					data: {},
					class: 'centerAlign',
					render: function(user){
						if(user.employee && user.employee.title){
							return user.employee.title;
						} else {
							return "";
						}
					}
				},
				{
					width: 40,
					title: "Department",
					data: {},
					class: 'centerAlign',
					render: function(user){
						if(user.employee && user.employee.department && user.employee.department.name){
							return user.employee.department.name;
						} else {
							return "";
						}  
					}
				},
				{
					width: 30,
					title: "Office",
					data: {},
					class: 'centerAlign',
					render: function(user){
						if(user.office && user.office.name){
							return user.office.name;
						} else {
							return "";
						}  
					}
				},
				{
					width: 70,
					title: "Seat",
					data: {},
					class: 'centerAlign',
					render: function(user){
					var len = user.seats.length;
						if(len > 1){
							return '<a class="seatDrillDown" href="#">'+'Multiple'+'</a>';
						} else if (len == 1){
							var seat = user.seats[0];
							return seat.mapName + " - Seat: " + seat.seatName;
						} else {
							return "Unassigned";
						}
					}
				},
				{
					width: 60,
					title: "Email",
					data: {},
					class: 'leftAlign',
					render: function(user){
						return user.email
					}
				},
			],
			dom: 'brt'
		})
	}

	this.setBindings = function(namespace){
		table = this.table;

		// Resizes the table based on a change in the height of parent element (resize event)
		// Does this by creating an iframe in the same space and listening for a resize
		_attach.call(table,this.namespace,this.tableOffset,function(height){
			report.tableElement.parent().css("height",height - 30);
			table.draw();
		});

		// Redraws the map when the leftNav is maximized or minimized.
		// Needed to keep the columns and headers aligned during the resize
		$("#sidebarMin,#sidebarMax").on('click.'+namespace,function(){
			var tableContext = table;
			setTimeout(function(){
				tableContext.draw();
			},300)
		})

		table && table.on('click.'+namespace, 'td .seatDrillDown', function () {
			var data = report.table.row($(this).closest('tr')).data();
			var seats = data.seats;
			var seatIDArray = [];
			for(var i in seats){seatIDArray.push(seats[i].seatID)}
			$Map.ModalTables.roomTable(seatIDArray);
		});

	}

	this.unsetBindings = function(){
		$(document).off('.'+this.namespace);
		$("#"+this.namespace).remove(); // Remove iframe
	}

	this.createFooter = function(){
		var footer = "";
		footer += "<tfoot><tr>";
		for(var i = 0; i < this.tableColumns; i++){footer+= "<td></td>"}
		footer += "</tr></tfoot>";
		this.tableElement.append(footer);
	}
}
$Map.Components.CompanyReports.userList.prototype.constructor = $Map.Components.CompanyReports.userList;

$Map.Components.CompanyReports.zoneList = function(){
	this.url = '../api/company/reports/zoneList';
	this.tableContainer = $("#companyReports .table-container")
	this.tableElement = $("#companyReportTable");
	this.tableColumns = 11;
	this.table = null;
	this.tableOffset = 110;
	this.namespace = 'zoneListReport';
	var report = this;

	this.open = function(officeID){
		this.createFooter();
		this.setTable();
		this.setBindings(this.namespace);
		this.isOpen = true;
	}

	this.exit = function(){
		this.unsetBindings();
		this.table && this.table.clear().destroy(); // Clears datatable
		this.table = null;		
		this.tableElement.children().remove(); // Removes table remaining table elements (except table)
		this.isOpen = false;
	}

	this.update = function(officeID){
		report.table.ajax.reload();
	}

	this.setTable = function(){
		this.table = this.table || this.tableElement.DataTable({
			ajax: {
				url: this.url
			},
			rowId: 'zoneID',
			select: {
				style: 'single',
				className: 'selected',
				selector: 'tr:not(.selected)'
			},
			scrollY: report.tableContainer.height() - this.tableOffset,
			deferRender:true,
			scroller:true,
			paging:true,
			autoWidth:true,
			fixedHeader:{
				footer: true
			},
			columns:[
				{
					width: 75,
					title: "Zone",
					data: {},
					class: 'leftAlign',
					render: function(zone){
						return zone.zoneName || "";
					}
				},
				{
					width: 75,
					title: "Office",
					data: {},
					class: 'leftAlign',
					render: function(zone){
						return zone.office || "";
					}
				},
				{
					width: 75,
					title: "Map",
					data: {},
					class: 'leftAlign',
					render: function(zone){
						return zone.mapName || "";
					}
				},
				{
					width: 50,
					title: "Department",
					data: {},
					class: 'centerAlign',
					render: function(zone){
						return zone.department || "";
					}
				},
				{
					width: 50,
					title: "Area",
					data: {},
					class: 'centerAlign',
					render: function(zone){
						return renderArea(zone.area) || "";
					}
				},
				{
					width: 30,
					title: "Seats",
					data: {},
					class: 'centerAlign',
					render: function(zone){
						if(zone.seatCount && zone.seatCount > 0){
							return '<a class="seatDrillDown" href="#">'+zone.seatCount+'</a>';
						} else {
							var length = Object.keys(zone.seats).length;
							if(length){
								zone.seatCount = length;                             
							} else {
								zone.seatCount = 0;
								return zone.seatCount;
							}
							return '<a class="seatDrillDown" href="#">'+zone.seatCount+'</a>';
						}
					}
				},
				{
					width: 30,
					title: "Assignable",
					data: {},
					class: 'centerAlign',
					render: function(zone){
						var seats = zone.seats;
						var result = 0;
						if(zone.assignableSeats && zone.assignableSeats > 0){
							return '<a class="assignableSeatDrilldown" href="#">'+zone.assignableSeats+'</a>';
						} else {
							for(var i in seats){
								if(seats[i].reservable == false){
									result += 1;
								}
							}
							zone.assignableSeats = result;
							if(result == 0){
								return result;
							}
							return '<a class="assignableSeatDrilldown" href="#">'+zone.assignableSeats+'</a>';
						}
					}
				},
				{
					width: 30,
					title: "Assigned",
					data: {},
					class: 'centerAlign',
					render: function(zone){
						var seats = zone.seats;
						var result = 0;
						if(zone.assignedSeats){
							return '<a class="assignedSeatDrillDown" href="#">'+zone.assignedSeats+'</a>';
						} else {
							for(var i in seats){
								if(seats[i].assignmentStatus == "Assigned"){
									result += 1;
								}
							}
							zone.assignedSeats = result;
							if(result == 0){
								return result;
							}
							return '<a class="assignedSeatDrillDown" href="#">'+zone.assignedSeats+'</a>';
						}
					}
				},
				{
					width: 30,
					title: "Available",
					data: {},
					class: 'centerAlign',
					render: function(zone){
					var seats = zone.seats;
					var result = 0;
						if(zone.availableSeats){
							return '<a class="unassignedSeatDrillDown" href="#">'+zone.availableSeats+'</a>';
						} else {
							for(var i in seats){
								if(seats[i].assignmentStatus == "Unassigned" && seats[i].reservable == false){
									result += 1;
								}
							}
							zone.availableSeats = result;
							if(result == 0){
								return result;
							}
							return '<a class="unassignedSeatDrillDown" href="#">'+zone.availableSeats+'</a>';
						}
					}
				},
				{
					width: 30,
					title: "Utilization",
					data: {},
					class: 'centerAlign',
					render: function(zone){
						var value = 100 * zone.assignedSeats / zone.assignableSeats;
						if(zone.assignableSeats == 0) value = null;
						var myString = "";
						myString += '<div class="cssProgress"><div class="progress3">';
						myString += '<div class="cssProgress-bar cssProgress-success" data-percent="';
						myString += value || 0;
						myString += '" style="width:';
						myString += value || 0;
						myString += '%;"><span class="cssProgress-label">';
						myString += value !== null ? round(value,0) +"%" : "N/A";
						myString += '</span></div></div></div>';
						return myString;
					}
				},
				{
					width: 30,
					title: "Reservable",
					data: {},
					class: 'centerAlign',
					render: function(zone){
						var seats = zone.seats;
						var result = 0;
						if(zone.reservableSeats){
							return '<a class="reservableSeatDrilldown" href="#">'+zone.reservableSeats+'</a>';
						} else {
							for(var i in seats){
								if(seats[i].reservable){
									result += 1;
								}
							}
							zone.reservableSeats = result;
							if(result == 0){
								return result;
							}
							return '<a class="reservableSeatDrilldown" href="#">'+zone.reservableSeats+'</a>';
						}
					}
				},
			],
			footerCallback: function ( row, data, start, end, display ) {
				var api = this.api();
	 
				var size = api
					.column(4,{search:'applied'})
					.data()
					.reduce( function (a, b) {
						return b.area + a;
					}, 0 );
				$( api.column( 4 ).footer() ).html(
					renderArea(size)
				);

				var seatCount = api
					.column(5,{search:'applied'})
					.data()
					.reduce( function (a, b) {
						return b.seatCount + a;
					}, 0 );
				$( api.column( 5 ).footer() ).html(
					seatCount
				);

				var assignableSeats = api
					.column(6,{search:'applied'})
					.data()
					.reduce( function (a, b) {
						return b.assignableSeats + a;
					}, 0 );
				$( api.column( 6 ).footer() ).html(
					assignableSeats
				);

				var assignedSeats = api
					.column(7,{search:'applied'})
					.data()
					.reduce( function (a, b) {
						return b.assignedSeats + a;
					}, 0 );
				$( api.column( 7 ).footer() ).html(
					assignedSeats
				);

				var availableSeats = api
					.column(8,{search:'applied'})
					.data()
					.reduce( function (a, b) {
						return b.availableSeats + a;
					}, 0 );
				$( api.column( 8 ).footer() ).html(
					availableSeats
				);

				var value = assignableSeats > 0 ? 100 * assignedSeats / assignableSeats : "NA";
				var myString = "";
				myString += '<div class="cssProgress"><div class="progress3">';
				myString += '<div class="cssProgress-bar cssProgress-success" data-percent="';
				myString += value;
				myString += '" style="width:';
				myString += value;
				myString += '%;"><span class="cssProgress-label">';
				myString += isNumeric(value) ? round(value,0) +"%" : "N/A";
				myString += '</span></div></div></div>';
				$( api.column( 9 ).footer() ).html(
					myString
				);

				var reservableSeats = api
					.column(10,{search:'applied'})
					.data()
					.reduce( function (a, b) {
						return b.reservableSeats + a;
					}, 0 );
				$( api.column( 10 ).footer() ).html(
					reservableSeats
				);
			},
			dom: 'brt'
		})
	}

	this.setBindings = function(namespace){
		table = this.table;

		// Resizes the table based on a change in the height of parent element (resize event)
		// Does this by creating an iframe in the same space and listening for a resize
		_attach.call(table,this.namespace,this.tableOffset,function(height){
			report.tableElement.parent().css("height",height - 30);
			table.draw();
		});

		// Redraws the map when the leftNav is maximized or minimized.
		// Needed to keep the columns and headers aligned during the resize
		$("#sidebarMin,#sidebarMax").on('click.'+namespace,function(){
			var tableContext = table;
			setTimeout(function(){
				tableContext.draw();
			},300)
		})

		// Add event listener for opening seat table modal for all seats
		table && table.on('click.'+namespace, 'td a.seatDrillDown', function () {
			var data = report.table.row($(this).closest('tr')).data();
			var seats = data.seats;
			var seatIDArray = [];
			for(var i in seats){seatIDArray.push(i)}
			$Map.ModalTables.seatTable(seatIDArray);
		});
		
		// Add event listener for opening seat table modal for all seats
		table && table.on('click.'+namespace, 'td .assignableSeatDrilldown', function () {
			var data = report.table.row($(this).closest('tr')).data();
			var seats = data.seats;
			var seatIDArray = [];
			for(var i in seats){
				if(seats[i].reservable == false){
					seatIDArray.push(i)
				}
			}
			$Map.ModalTables.seatTable(seatIDArray);
		});

		// Add event listener for opening seat table modal for assigned seats
		table && table.on('click.'+namespace, 'td .assignedSeatDrillDown', function () {
			var data = report.table.row($(this).closest('tr')).data();
			var seats = data.seats;
			var seatIDArray = [];
			for(var i in seats){
				if(seats[i].assignmentStatus == "Assigned"){
					seatIDArray.push(i)
				}
			}
			$Map.ModalTables.seatTable(seatIDArray);
		});

		// Add event listener for opening seat table modal for unassigned seats
		table && table.on('click.'+namespace, 'td .unassignedSeatDrillDown', function () {
			var data = report.table.row($(this).closest('tr')).data();
			var seats = data.seats;
			var seatIDArray = [];
			for(var i in seats){
				if(seats[i].assignmentStatus == "Unassigned" && seats[i].reservable == false){
					seatIDArray.push(i)
				}
			}
			$Map.ModalTables.seatTable(seatIDArray);
		});

		// Add event listener for opening seat table modal for reservable seats
		table && table.on('click.'+namespace, 'td .reservableSeatDrilldown', function () {
			var data = report.table.row($(this).closest('tr')).data();
			var seats = data.seats;
			var seatIDArray = [];
			for(var i in seats){
				if(seats[i].reservable){
					seatIDArray.push(i)
				}
			}
			$Map.ModalTables.seatTable(seatIDArray);
		});

	}

	this.unsetBindings = function(){
		$(document).off('.'+this.namespace);
		$("#"+this.namespace).remove(); // Remove iframe
	}

	this.createFooter = function(){
		var footer = "";
		footer += "<tfoot><tr>";
		for(var i = 0; i < this.tableColumns; i++){footer+= "<td></td>"}
		footer += "</tr></tfoot>";
		this.tableElement.append(footer);
	}
}
$Map.Components.CompanyReports.zoneList.prototype.constructor = $Map.Components.CompanyReports.zoneList;

$Map.Components.CompanyReports.roomList = function(){
	this.url = '../api/company/reports/roomList';
	this.tableContainer = $("#companyReports .table-container")
	this.tableElement = $("#companyReportTable");
	this.tableColumns = 11;
	this.table = null;
	this.tableOffset = 110;
	this.namespace = 'roomListReport';
	var report = this;

	this.open = function(officeID){
		this.createFooter();
		this.setTable();
		this.setBindings(this.namespace);
		this.isOpen = true;
	}

	this.exit = function(){
		this.unsetBindings();
		this.table && this.table.clear().destroy(); // Clears datatable
		this.table = null;		
		this.tableElement.children().remove(); // Removes table remaining table elements (except table)
		this.isOpen = false;
	}

	this.update = function(officeID){
		report.table.ajax.reload();
	}

	this.setTable = function(){
		this.table = this.table || this.tableElement.DataTable({
			ajax: {
				url: this.url
			},
			rowId: 'roomID',
			select: {
				style: 'single',
				className: 'selected',
				selector: 'tr:not(.selected)'
			},
			scrollY: report.tableContainer.height() - this.tableOffset,
			deferRender:true,
			scroller:true,
			paging:true,
			autoWidth:true,
			columns:[
				{
					width: 75,
					title: "Room",
					data: {},
					class: 'leftAlign',
					render: function(room){
						return room.roomName || "";
					}
				},
				{
					width: 75,
					title: "Office",
					data: {},
					class: 'leftAlign',
					render: function(room){
						return room.office || "";
					}
				},
				{
					width: 75,
					title: "Map",
					data: {},
					class: 'leftAlign',
					render: function(room){
						return room.mapName || "";
					}
				},
				{
					width: 50,
					title: "Department",
					data: {},
					class: 'centerAlign',
					render: function(room){
						return room.department || "";
					}
				},
				{
					width: 50,
					title: "Reservable",
					data: {},
					class: 'centerAlign',
					render: function(room){
						if(room.reservable){
							return "Yes";
						} else {
							return "No";
						}
					}
				},				
				{
					width: 50,
					title: "Area",
					data: {},
					class: 'centerAlign',
					render: function(room){
						return renderArea(room.area) || "";
					}
				},
				{
					width: 30,
					title: "Seats",
					data: {},
					class: 'centerAlign',
					render: function(room){
						if(room.seatCount && room.seatCount > 0){
							return '<a class="seatDrillDown" href="#">'+room.seatCount+'</a>';
						} else {
							var length = Object.keys(room.seats).length;
							if(length){
								room.seatCount = length;                             
							} else {
								room.seatCount = 0;
								return room.seatCount;
							}
							return '<a class="seatDrillDown" href="#">'+room.seatCount+'</a>';
						}
					}
				},
				{
					width: 30,
					title: "Assigned",
					data: {},
					class: 'centerAlign',
					render: function(room){
						var seats = room.seats;
						var result = 0;
						if(room.assignedSeats){
							return '<a class="assignedSeatDrillDown" href="#">'+room.assignedSeats+'</a>';
						} else {
							for(var i in seats){
								if(seats[i].assignmentStatus == "Assigned"){
									result += 1;
								}
							}
							room.assignedSeats = result;
							if(result == 0){
								return result;
							}
							return '<a class="assignedSeatDrillDown" href="#">'+room.assignedSeats+'</a>';
						}
					}
				},
				{
					width: 30,
					title: "Available",
					data: {},
					class: 'centerAlign',
					render: function(room){
						var seats = room.seats;
						var result = 0;
						if(room.availableSeats){
							return '<a class="unassignedSeatDrillDown" href="#">'+room.availableSeats+'</a>';
						} else {
							for(var i in seats){
								if(seats[i].assignmentStatus == "Unassigned"){
									result += 1;
								}
							}
							room.availableSeats = result;
							if(result == 0){
								return result;
							}
							return '<a class="unassignedSeatDrillDown" href="#">'+room.availableSeats+'</a>';
						}
					}
				},
				{
					width: 30,
					title: "Utilization",
					data: {},
					class: 'centerAlign',
					render: function(room){
						var value = 100 * room.assignedSeats / room.seatCount;
						if(room.seatCount == 0) value = null;
						var myString = "";
						myString += '<div class="cssProgress"><div class="progress3">';
						myString += '<div class="cssProgress-bar cssProgress-success" data-percent="';
						myString += value || 0;
						myString += '" style="width:';
						myString += value || 0;
						myString += '%;"><span class="cssProgress-label">';
						myString += value !== null ? round(value,0) +"%" : "N/A";
						myString += '</span></div></div></div>';
						return myString;
					}
				},
				{
					width: 30,
					title: "Reservable",
					data: {},
					class: 'centerAlign',
					render: function(room){
						var seats = room.seats;
						var result = 0;
						if(room.reservableSeats){
							return '<a class="reservableSeatDrilldown" href="#">'+room.reservableSeats+'</a>';
						} else {
							for(var i in seats){
								if(seats[i].reservable){
									result += 1;
								}
							}
							room.reservableSeats = result;
							if(result == 0){
								return result;
							}
							return '<a class="reservableSeatDrilldown" href="#">'+room.reservableSeats+'</a>';
						}
					}
				},
			],
			footerCallback: function ( row, data, start, end, display ) {
				var api = this.api();
	 
				var reservable = api
					.column(4,{search:'applied'})
					.data()
					.reduce( function (a, b) {
						return (b.reservable ? 1 : 0) + a;
					}, 0 );
				$( api.column( 4 ).footer() ).html(
					reservable
				);

				var size = api
					.column(5,{search:'applied'})
					.data()
					.reduce( function (a, b) {
						return b.area + a;
					}, 0 );
				$( api.column( 5 ).footer() ).html(
					renderArea(size)
				);

				var seatCount = api
					.column(6,{search:'applied'})
					.data()
					.reduce( function (a, b) {
						return b.seatCount + a;
					}, 0 );
				$( api.column( 6 ).footer() ).html(
					seatCount
				);

				var assignedSeats = api
					.column(7,{search:'applied'})
					.data()
					.reduce( function (a, b) {
						return b.assignedSeats + a;
					}, 0 );
				$( api.column( 7 ).footer() ).html(
					assignedSeats
				);

				var availableSeats = api
					.column(8,{search:'applied'})
					.data()
					.reduce( function (a, b) {
						return b.availableSeats + a;
					}, 0 );
				$( api.column( 8 ).footer() ).html(
					availableSeats
				);

				var assignableSeats = assignedSeats + availableSeats;
				var value = assignableSeats > 0 ? 100 * assignedSeats / assignableSeats : "NA";
				var myString = "";
				myString += '<div class="cssProgress"><div class="progress3">';
				myString += '<div class="cssProgress-bar cssProgress-success" data-percent="';
				myString += value;
				myString += '" style="width:';
				myString += value;
				myString += '%;"><span class="cssProgress-label">';
				myString += isNumeric(value) ? round(value,0) +"%" : "N/A";
				myString += '</span></div></div></div>';
				$( api.column( 9 ).footer() ).html(
					myString
				);

				var reservableSeats = api
					.column(10,{search:'applied'})
					.data()
					.reduce( function (a, b) {
						return b.reservableSeats + a;
					}, 0 );
				$( api.column( 10 ).footer() ).html(
					reservableSeats
				);
			},
			dom: 'brt'
		})
	}

	this.setBindings = function(namespace){
		table = this.table;

		// Resizes the table based on a change in the height of parent element (resize event)
		// Does this by creating an iframe in the same space and listening for a resize
		_attach.call(table,this.namespace,this.tableOffset,function(height){
			report.tableElement.parent().css("height",height - 30);
			table.draw();
		});

		// Redraws the map when the leftNav is maximized or minimized.
		// Needed to keep the columns and headers aligned during the resize
		$("#sidebarMin,#sidebarMax").on('click.'+namespace,function(){
			var tableContext = table;
			setTimeout(function(){
				tableContext.draw();
			},300)
		})

		// Add event listener for opening seat table modal for all seats
		table && table.on('click.'+namespace, 'td a.seatDrillDown', function () {
			var data = report.table.row($(this).closest('tr')).data();
			var seats = data.seats;
			var seatIDArray = [];
			for(var i in seats){seatIDArray.push(i)}
			$Map.ModalTables.seatTable(seatIDArray);
		});
		
		// Add event listener for opening seat table modal for assigned seats
		table && table.on('click.'+namespace, 'td .assignedSeatDrillDown', function () {
			var data = report.table.row($(this).closest('tr')).data();
			var seats = data.seats;
			var seatIDArray = [];
			for(var i in seats){
				if(seats[i].assignmentStatus == "Assigned"){
					seatIDArray.push(i)
				}
			}
			$Map.ModalTables.seatTable(seatIDArray);
		});

		// Add event listener for opening seat table modal for unassigned seats
		table && table.on('click.'+namespace, 'td .unassignedSeatDrillDown', function () {
			var data = report.table.row($(this).closest('tr')).data();
			var seats = data.seats;
			var seatIDArray = [];
			for(var i in seats){
				if(seats[i].assignmentStatus == "Unassigned" && seats[i].reservable == false){
					seatIDArray.push(i)
				}
			}
			$Map.ModalTables.seatTable(seatIDArray);
		});

		// Add event listener for opening seat table modal for reservable seats
		table && table.on('click.'+namespace, 'td .reservableSeatDrilldown', function () {
			var data = report.table.row($(this).closest('tr')).data();
			var seats = data.seats;
			var seatIDArray = [];
			for(var i in seats){
				if(seats[i].reservable){
					seatIDArray.push(i)
				}
			}
			$Map.ModalTables.seatTable(seatIDArray);
		});

	}

	this.unsetBindings = function(){
		$(document).off('.'+this.namespace);
		$("#"+this.namespace).remove(); // Remove iframe
	}

	this.createFooter = function(){
		var footer = "";
		footer += "<tfoot><tr>";
		for(var i = 0; i < this.tableColumns; i++){footer+= "<td></td>"}
		footer += "</tr></tfoot>";
		this.tableElement.append(footer);
	}
}
$Map.Components.CompanyReports.roomList.prototype.constructor = $Map.Components.CompanyReports.roomList;