$Map.Components.Company.summary = function(){
	this.url = '../api/company/users/userList';
	this.container = $("#companySummary");
	this.data = null;

	// Tiles
	this.tiles = this.container.children('.summary-tile');
	this.tile0 = $(this.tiles[0]);
	this.tile1 = $(this.tiles[1]);
	this.tile2 = $(this.tiles[2]);
	this.tile3 = $(this.tiles[3]);
	this.tile4 = $(this.tiles[4]);
	this.tile5 = $(this.tiles[5]);
	this.tile6 = $(this.tiles[6]);
	this.tile7 = $(this.tiles[7]);
	this.tile8 = $(this.tiles[8]);


	this.utilizationTable = null;
	this.sizeTable = null;


	this.tableOffset = 110;
	this.namespace = 'companySummary';
	var summary = this;

	this.open = function(officeID){
		if(!this.isOpen){
			this.formatTiles();
			this.getData();
			this.isOpen = true;			
		}
	}

	this.exit = function(){
		this.unsetBindings();
		this.utilizationTable && this.utilizationTable.clear().destroy(); // Clears datatable
		this.sizeTable && this.sizeTable.clear().destroy(); // Clears datatable
		this.tiles.empty();
		this.utilizationTable = null;		
		this.sizeTable = null;
		this.isOpen = false;
	}

	this.getData = function(){
		$.ajax({
			type:"GET",
			url: "/api/company/summary/summary/"
		})
		.then(function(results){
			console.log(results)
			summary.data = results;
			summary.setNumberTiles();
			summary.setUtilizationTable();
			summary.setSizeTable();
			summary.setVisitorTable();
			summary.setBindings();
		})
		.catch(function(err){
			console.log(err);
		})
	}

	this.formatTiles = function(){
		var headers = [
			'Offices',
			'Users',
			'Seats',
			'Rooms',
			'Kiosks',
			'Area',
			'Office Utilization',
			'Office Size',
			'Office Visitors'
		]
		for(var i = 0; i < 6; i++){
			$(this.tiles[i]).html("<strong class='header absolute'>"+headers[i]+
				"</strong><span></span>");
		}
		for(var i = 6; i < 9; i++){
			$(this.tiles[i]).html("<strong class='header absolute'>"+headers[i]+
				"</strong><div class='table-container display compact'><table></table></div>");
		}
	}

	this.setNumberTiles = function(){
		this.tile0.children('span').html(this.data.offices);
		this.tile1.children('span').html(this.data.users);
		this.tile2.children('span').html(this.data.seats);
		this.tile3.children('span').html(this.data.rooms);
		this.tile4.children('span').html(this.data.kiosks);
		this.tile5.children('span').html(renderArea(this.data.area*144));
	}

	this.setUtilizationTable = function(){
		console.log(this.utilizationTable)
		this.utilizationTable = this.utilizationTable || this.tile6.find('table').DataTable({
			data: this.data.officeData,
			rowId: 'userID',
			scrollY: summary.tile6.find('table').parent().height() - this.tableOffset,
			deferRender:true,
			scroller:true,
			paging:true,
			autoWidth:true,
			fixedHeader:{
				footer: true
			},
			columns:[	
				{
					width: 50,
					data: {},
					class: 'leftAlign',
					render: function(office){
						return office.name;
					}
				},
				{
					width: 50,
					title: "Utilization",
					data: {},
					render: function(office){
						var assignableSeats = office.assigned + office.unassigned;
						var value = 100 * office.assigned / assignableSeats;
						value = value ? value : 0;
						var myString = "";
						myString += '<div class="cssProgress"><div class="progress3">';
						myString += '<div class="cssProgress-bar cssProgress-success" data-percent="';
						myString += value;
						myString += '" style="width:';
						myString += value;
						myString += '%;"><span class="cssProgress-label">';
						myString += round(value,0);
						myString += '%</span></div></div></div>';
						return myString;
					}
				},
			],
			dom: 'rt',
		})		
	}

	this.setSizeTable = function(){
		this.sizeTable = this.sizeTable || this.tile7.find('table').DataTable({
			data: this.data.officeData,
			rowId: 'userID',
			scrollY: summary.tile7.find('table').parent().height() - this.tableOffset,
			deferRender:true,
			scroller:true,
			paging:true,
			autoWidth:true,
			fixedHeader:{
				footer: true
			},
			columns:[	
				{
					width: 50,
					data: {},
					class: 'leftAlign',
					render: function(office){
						return office.name || "";
					}
				},
				{
					width: 50,
					title: "Users",
					data: {},
					class: 'centerAlign',
					render: function(office){
						return office.users || "";
					}
				},
				{
					width: 50,
					title: "Seats",
					data: {},
					class: 'centerAlign',
					render: function(office){
						return office.seats || "";
					}
				},
				{
					width: 50,
					title: "Area",
					data: {},
					class: 'centerAlign',
					render: function(office){
						return office.area ? renderArea(office.area*144) : 0;
					}
				},
			],
			dom: 'rt',
		})		
	}

	this.setVisitorTable = function(){
		var table = this.tile8.find('table');
		table.empty();
		table.css({
			width: "100%",
			height: "100%"
		})
		var data = [
			'Today',
			this.data.visitors.today,
			'This Week',
			this.data.visitors.thisWeek,
			'This Month',
			this.data.visitors.thisMonth,
			'This Year',
			this.data.visitors.thisYear,
			''
		]
		for(var i = 0; i < 9; i++){
			table.append('<tr class="visitor-row"><td>'+data[i]+'</td></tr>')
		}

	}

	this.update = function(officeID){
		report.table.ajax.reload();
	}

	this.setBindings = function(){
		var table1 = this.utilizationTable;
		var table2 = this.sizeTable;

		// Resizes the table based on a change in the height of parent element (resize event)
		// Does this by creating an iframe in the same space and listening for a resize
		_attach.call(table1,this.namespace,this.tableOffset,function(height){
			summary.tile6.find('dataTables_scrollBody table').parent().css("height",height);
			summary.tile7.find('dataTables_scrollBody table').parent().css("height",height);
			table1.draw();
			table2.draw();
		});

		// Redraws the map when the leftNav is maximized or minimized.
		// Needed to keep the columns and headers aligned during the resize
		$("#sidebarMin,#sidebarMax").on('click.'+this.namespace,function(){
			var tableContext = table;
			setTimeout(function(){
				tableContext.draw();
			},300)
		})

	}

	this.unsetBindings = function(){
		$(document).off('.'+this.namespace);
		$("#"+this.namespace).remove(); // Remove iframe
	}

	this.createFooter = function(){
		var footer = "";
		footer += "<tfoot><tr>";
		for(var i = 0; i < this.tableColumns; i++){footer+= "<td></td>"}
		footer += "</tr></tfoot>";
		this.tableElement.append(footer);
	}
}
$Map.Components.Company.summary.prototype.constructor = $Map.Components.Company.summary;