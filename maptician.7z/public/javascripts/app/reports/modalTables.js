Maptician.ModalTables = {};

Maptician.ModalTables.mapTable = function(mapArray){
	var mapTable = Maptician.ModalTables.mapTable;
	mapTable.mapParam = mapArray;

	if(Maptician.ModalTables.MapTable){
		Maptician.ModalTables.MapTable.ajax.reload();
		$('#mapListModal').modal();
		return;
	}

	$('#mapListModal').modal();

	Maptician.ModalTables.MapTable = $("#mapModalTable").DataTable({
		ajax: {
			"url":"/api/reports/modalreports/maps",
			data:function(d){
				return {data:mapTable.mapParam};
			}
		},
		"language":{
			"info": "Showing Maps _START_ to _END_ of _MAX_",
			"lengthMenu": "Show _MENU_ Maps",
			"Find Rooms": "Filter Maps:"
		},
		scrollY:$("#mapListModal").height() - 165,
        deferRender:true,
        scroller:true,
        paging:true,
		columns:[
			{
				data:'mapName',
				'className':'leftAlign',
			},
			{
                data: {}, // Zone list
            	"orderable":true,
            	'className':'centerAlign',
            	render: function(map){
            		if(map.zoneCount){
            			return '<a class="modalTableZones" href="#">'+map.zoneCount+'</a>';
            		} else {
            			if(map.zones){
                			map.zoneCount = Object.keys(map.zones).length;                				
            			} else {
            				map.zoneCount = 0;
            			}
            			return '<a class="modalTableZones" href="#">'+map.zoneCount+'</a>';
            		}
                },
			},
			{
                data: {}, // Room list
            	"orderable":true,
            	'className':'centerAlign',
            	render: function(map){
            		if(map.roomCount){
            			return '<a class="modalTableRooms" href="#">'+map.roomCount+'</a>';
            		} else {
            			if(map.rooms){
                			map.roomCount = Object.keys(map.rooms).length;                				
            			} else {
            				map.roomCount = 0;
            			}
            			return '<a class="modalTableRooms" href="#">'+map.roomCount+'</a>';
            		}
                },
			},
        	{           	
                data:{},  // Number of seats
            	'className':'centerAlign',
                render: function(map){
            		if(map.seatCount){
            			return '<a class="modalTableSeats" href="#">'+map.seatCount+'</a>';
            		} else {
            			if(map.seats){
                			map.seatCount = Object.keys(map.seats).length;                				
            			} else {
            				map.seatCount = 0;
            				return map.seatCount
            			}
            			return '<a class="modalTableSeats" href="#">'+map.seatCount+'</a>';
            		}
                },
        	},
        	{          	
                data:{},  // Assigned seats
            	'className':'centerAlign',
            	render: function(map){
            		var seats = map.seats;
            		var result = 0;
            		if(map.assignedSeats){
            			return '<a class="modalAssignedTableSeats" href="#">'+map.assignedSeats+'</a>';
            		} else {
                		for(var i in seats){
                			if(seats[i].assignmentStatus == "Assigned"){
                				result += 1;
                			}
                		}
                		map.assignedSeats = result;
                		if(result == 0){
                			return result;
                		}
                		return '<a class="modalAssignedTableSeats" href="#">'+map.assignedSeats+'</a>';
            		}
                },
        	},
        	{           	
                data:{},
            	'className':'centerAlign',
            	render: function(map){ // Available Seats
            		var seats = map.seats;
            		var result = 0;
            		if(map.availableSeats){
            			return '<a class="modalUnassignedTableSeats" href="#">'+map.availableSeats+'</a>';
            		} else {
                		for(var i in seats){
                			if(seats[i].assignmentStatus == "Unassigned" && seats[i].reservable == false){
                				result += 1;
                			}
                		}
                		map.availableSeats = result;
                		if(result == 0){
                			return result;
                		}
                		return '<a class="modalUnassignedTableSeats" href="#">'+map.availableSeats+'</a>';
            		}
                },
        	},
            {              	
                data: {}, // Seat Utilization
            	render: function(map){ 
            		var seats = map.assignedSeats + map.availableSeats;
            		var value = 100 * map.assignedSeats / seats;
            		if(seats == 0){value = 0;}
            		var myString = "";
            		myString += '<div class="cssProgress"><div class="progress3">';
            		myString += '<div class="cssProgress-bar cssProgress-success" data-percent="';
            		myString += value;
            		myString += '" style="width:';
            		myString += value;
            		myString += '%;"><span class="cssProgress-label">';
            		myString += round(value,0);
            		myString += '%</span></div></div></div>';
            		return myString;
                },
            },
            {               
                data:{},  // Number of reservable seats
                'className':'centerAlign',
                render: function(map){
                    var seats = map.seats;
                    var result = 0;
                    if(map.reservableSeats){
                        return '<a class="modalTableReserveSeats" href="#">'+map.reservableSeats+'</a>';
                    } else {
                        for(var i in seats){
                            if(seats[i].reservable){
                                result += 1;
                            }
                        }
                        map.reservableSeats = result;
                        if(result == 0){
                            return result;
                        }
                        return '<a class="modalTableReserveSeats" href="#">'+map.reservableSeats+'</a>';
                    }
                },
            }
		],
        footerCallback: function ( row, data, start, end, display ) {
            var api = this.api();

            var zones = api
                .column(1,{search:'applied'})
                .data()
                .reduce( function (a, b) {
                    return b.zoneCount + a;
                }, 0 );
            $( api.column( 1 ).footer() ).html(
                zones
            );
            
            var rooms = api
                .column(2,{search:'applied'})
                .data()
                .reduce( function (a, b) {
                    return b.roomCount + a;
                }, 0 );
            $( api.column( 2 ).footer() ).html(
                rooms
            );
 
            var seats = api
                .column(3,{search:'applied'})
                .data()
                .reduce( function (a, b) {
                    return b.seatCount + a;
                }, 0 );
            $( api.column( 3 ).footer() ).html(
                seats
            );

            var assignedSeats = api
                .column(4,{search:'applied'})
                .data()
                .reduce( function (a, b) {
                    return b.assignedSeats + a;
                }, 0 );
            $( api.column( 4 ).footer() ).html(
                assignedSeats
            );

            var availableSeats = api
                .column(5,{search:'applied'})
                .data()
                .reduce( function (a, b) {
                    return b.availableSeats + a;
                }, 0 );
            $( api.column( 5 ).footer() ).html(
                availableSeats
            );

            var assignable = assignedSeats + availableSeats;
            var value = assignable > 0 ? 100 * assignedSeats / assignable : "NA";
            var myString = "";
            myString += '<div class="cssProgress"><div class="progress3">';
            myString += '<div class="cssProgress-bar cssProgress-success" data-percent="';
            myString += value;
            myString += '" style="width:';
            myString += value;
            myString += '%;"><span class="cssProgress-label">';
            myString += value !== null ? round(value,0) +"%" : "N/A";
            myString += '</span></div></div></div>';
            $( api.column( 6 ).footer() ).html(
                myString
            );

            var reservableSeats = api
                .column(7,{search:'applied'})
                .data()
                .reduce( function (a, b) {
                    return b.reservableSeats + a;
                }, 0 );
            $( api.column( 7 ).footer() ).html(
                reservableSeats
            );

        },
		dom: '<".standardTableFilterDiv" and f><".standardTableButtonDiv" and B>rt',
	})

	var MapTable = Maptician.ModalTables.MapTable;

	if(mapTable.hasInit){ // Sets up bindings on first run

	} else {

        _attach.call(MapTable,'mapModalFrame',165,function(height){
            $("#mapModalTable").parent().css("height",height)
        });

		mapTable.hasInit = true;
	}
	$('#mapListModal').modal();
}

Maptician.ModalTables.roomTable = function(roomArray,options){
	var roomTable = Maptician.ModalTables.roomTable;
    if(options && options.title){
        $('#roomListModal').find('.header').html(options.title);
    } else {
        $('#roomListModal').find('.header').html("Rooms");
    }
	roomTable.roomParam = roomArray;

	if(Maptician.ModalTables.RoomTable){
		Maptician.ModalTables.RoomTable.ajax.reload();
		$('#roomListModal').modal();
		return;
	}

	$('#roomListModal').modal();

	Maptician.ModalTables.RoomTable = $("#roomModalTable").DataTable({
		ajax: {
			"url":"/api/reports/modalreports/rooms",
			data:function(d){
				return {data:roomTable.roomParam};
			}
		},
		"language":{
			"info": "Showing Rooms _START_ to _END_ of _MAX_",
			"lengthMenu": "Show _MENU_ Rooms",
			"Find Rooms": "Filter Rooms:"
		},
		select: true,
		scrollY:$("#roomListModal").height() - 165,
        deferRender:true,
        scroller:true,
        paging:true,
		columns:[
			{
				data:'roomName',
				'className':'leftAlign',
			},
			{
				data: {}, // Room Area
				'className':'centerAlign',
				render: function(room){
					return renderArea(room.area);
				},
			},
			{
				data: {}, // Seats in Room
				'className':'centerAlign',
				render: function(room){
            		if(room.seatCount){
            			return '<a class="modalRoomSeats" href="#">'+room.seatCount+'</a>';
            		} else {
            			if(room.seats){
                			room.seatCount = Object.keys(room.seats).length;                				
            			} else {
            				room.seatCount = 0;
            				return room.seatCount
            			}
            			return '<a class="modalRoomSeats" href="#">'+room.seatCount+'</a>';
            		}
				},
			},
			{
				data: {}, // Seats Assigned
				'className':'centerAlign',
				render: function(room){
            		var seats = room.seats;
            		var result = 0;
            		if(room.assignedSeats){
            			return '<a class="modalRoomAssignedSeats" href="#">'+room.assignedSeats+'</a>';
            		} else {
                		for(var i in seats){
                			if(seats[i].assignmentStatus == "Assigned"){
                				result += 1;
                			}
                		}
                		room.assignedSeats = result;
                		if(result == 0){
                			return result;
                		}
                		return '<a class="modalRoomAssignedSeats" href="#">'+room.assignedSeats+'</a>';
            		}
				},
			},
			{
				data: {}, // Seats Available
				'className':'centerAlign',
				render: function(room){
            		var seats = room.seats;
            		var result = 0;
            		if(room.availableSeats){
            			return '<a class="modalRoomUnassignedSeats" href="#">'+room.availableSeats+'</a>';
            		} else {
                		for(var i in seats){
                			if(seats[i].assignmentStatus == "Unassigned"){
                				result += 1;
                			}
                		}
                		room.availableSeats = result;
                		if(result == 0){
                			return result;
                		}
                		return '<a class="modalRoomUnassignedSeats" href="#">'+room.availableSeats+'</a>';
            		}
				},
			},
			{
				data: {}, // Seats Reservable
				'className':'centerAlign',
				render: function(room){
					return 0;
				},
			},
			{
				data: {}, // Percentage Utilized
				'className':'tableCenterText',
				render: function(room){
					var value = 100 * room.assignedSeats / room.seatCount;
					if(room.seatCount == 0){value = 0;}
						var myString = "";
						myString += '<div class="cssProgress"><div class="progress3">';
						myString += '<div class="cssProgress-bar cssProgress-success" data-percent="';
						myString += value;
						myString += '" style="width:';
						myString += value;
						myString += '%;"><span class="cssProgress-label">';
						myString += value !== null ? round(value,0) +"%" : "N/A";
						myString += '</span></div></div></div>';
					return myString;
				},
			}
		],
		footerCallback: function ( row, data, start, end, display ) {
            var api = this.api();
 
            // Total over all pages
            var roomSize = api
                .column(1,{search:'applied'})
                .data()
                .reduce( function (a, b) {
                    return b.area + a;
                }, 0 );
            // Update footer
            $( api.column( 1 ).footer() ).html(
                renderArea(roomSize)
            );

            var seatCapacity = api
                .column(2,{search:'applied'})
                .data()
                .reduce( function (a, b) {
                    return b.seatCount + a;
                }, 0 );
            $( api.column( 2 ).footer() ).html(
                seatCapacity
            );

            var assignedSeats = api
                .column(3,{search:'applied'})
                .data()
                .reduce( function (a, b) {
                    return b.assignedSeats + a;
                }, 0 );
            $( api.column( 3 ).footer() ).html(
                assignedSeats
            );

            var availableSeats = api
                .column(4,{search:'applied'})
                .data()
                .reduce( function (a, b) {
                    return b.availableSeats + a;
                }, 0 );
            $( api.column( 4 ).footer() ).html(
                availableSeats
            );

            var reservableSeats = api
                .column(5,{search:'applied'})
                .data()
                .reduce( function (a, b) {
                    //return b.reservableSeats + a;
                    return 0;
                }, 0 );
            $( api.column( 5 ).footer() ).html(
                reservableSeats
            );


            var value = seatCapacity > 0 ? 100 * assignedSeats / seatCapacity : "NA";
			var myString = "";
			myString += '<div class="cssProgress"><div class="progress3">';
			myString += '<div class="cssProgress-bar cssProgress-success" data-percent="';
			myString += value;
			myString += '" style="width:';
			myString += value;
			myString += '%;"><span class="cssProgress-label">';
			myString += value !== null ? round(value,0) +"%" : "N/A";
			myString += '</span></div></div></div>';
            $( api.column( 6 ).footer() ).html(
                myString
            );

        },
		dom: '<".standardTableFilterDiv" and f><".standardTableButtonDiv" and B>rt',
	})
	if(this.hasInit){ // Sets up bindings on first run

	} else {

        _attach.call(Maptician.ModalTables.RoomTable,'roomModalFrame',165,function(height){
            $("#roomModalTable").parent().css("height",height)
        });

		this.hasInit = true;
	}
	$('#roomListModal').modal();
}

Maptician.ModalTables.zoneTable = function(zoneArray,options){
	var zoneTable = Maptician.ModalTables.zoneTable;
    if(options && options.title){
        $('#zoneListModal').find('.header').html(options.title);
    } else {
        $('#zoneListModal').find('.header').html("Zones");
    }
	zoneTable.zoneParam = zoneArray;

	if(Maptician.ModalTables.ZoneTable){
		Maptician.ModalTables.ZoneTable.ajax.reload();
		$('#zoneListModal').modal();
		return;
	}

	$('#zoneListModal').modal();

	Maptician.ModalTables.ZoneTable = $("#zoneModalTable").DataTable({
		ajax: {
			"url":"/api/reports/modalreports/zones",
			data:function(d){
				return {data:zoneTable.zoneParam};
			}
		},
		"language":{
			"info": "Showing Zones _START_ to _END_ of _MAX_",
			"lengthMenu": "Show _MENU_ Zones",
			"search": "Find Zones:"
		},
		select: true,
		scrollY:$("#zoneListModal").height() - 165,
        deferRender:true,
        scroller:true,
        paging:true,		
		columns:[
			{
				data:'zoneName',
				'className':'leftAlign',
			},
			{
				data: {}, // Zone Area
				'className':'centerAlign',
				render: function(zone){
					return renderArea(zone.area);
				},
			},
			{
				data: {}, // Seats in Zone
				'className':'centerAlign',
				render: function(zone){
            		if(zone.seatCount){
            			return '<a class="modalZoneSeats" href="#">'+zone.seatCount+'</a>';
            		} else {
            			if(zone.seats){
                			zone.seatCount = Object.keys(zone.seats).length;                				
            			} else {
            				zone.seatCount = 0;
            				return zone.seatCount
            			}
            			return '<a class="modalZoneSeats" href="#">'+zone.seatCount+'</a>';
            		}
				},
			},
			{
				data: {}, // Seats Assigned
				'className':'centerAlign',
				render: function(zone){
            		var seats = zone.seats;
            		var result = 0;
            		if(zone.assignedSeats){
            			return '<a class="modalZoneAssignedSeats" href="#">'+zone.assignedSeats+'</a>';
            		} else {
                		for(var i in seats){
                			if(seats[i].assignmentStatus == "Assigned"){
                				result += 1;
                			}
                		}
                		zone.assignedSeats = result;
                		if(result == 0){
                			return result;
                		}
                		return '<a class="modalZoneAssignedSeats" href="#">'+zone.assignedSeats+'</a>';
            		}
				},
			},
			{
				data: {}, // Seats Available
				'className':'centerAlign',
				render: function(zone){
            		var seats = zone.seats;
            		var result = 0;
            		if(zone.availableSeats){
            			return '<a class="modalZoneUnassignedSeats" href="#">'+zone.availableSeats+'</a>';
            		} else {
                		for(var i in seats){
                			if(seats[i].assignmentStatus == "Unassigned"){
                				result += 1;
                			}
                		}
                		zone.availableSeats = result;
                		if(result == 0){
                			return result;
                		}
                		return '<a class="modalZoneUnassignedSeats" href="#">'+zone.availableSeats+'</a>';
            		}
				},
			},
			{
				data: {}, // Seats Reservable
				'className':'centerAlign',
				render: function(zone){
					return 0;
				},
			},
			{
				data: {}, // Percentage Utilized
				'className':'tableCenterText',
				render: function(zone){
					var value = 100 * zone.assignedSeats / zone.seatCount;
					if(zone.seatCount == 0){value = 0;}
						var myString = "";
						myString += '<div class="cssProgress"><div class="progress3">';
						myString += '<div class="cssProgress-bar cssProgress-success" data-percent="';
						myString += value;
						myString += '" style="width:';
						myString += value;
						myString += '%;"><span class="cssProgress-label">';
						myString += value !== null ? round(value,0) +"%" : "N/A";
						myString += '</span></div></div></div>';
					return myString;
				},
			}
		],
		footerCallback: function ( row, data, start, end, display ) {
            var api = this.api();
 
            // Total over all pages
            var zoneSize = api
                .column(1,{search:'applied'})
                .data()
                .reduce( function (a, b) {
                    return b.area + a;
                }, 0 );
            // Update footer
            $( api.column( 1 ).footer() ).html(
                renderArea(zoneSize)
            );

            var seatCapacity = api
                .column(2,{search:'applied'})
                .data()
                .reduce( function (a, b) {
                    return b.seatCount + a;
                }, 0 );
            $( api.column( 2 ).footer() ).html(
                seatCapacity
            );

            var assignedSeats = api
                .column(3,{search:'applied'})
                .data()
                .reduce( function (a, b) {
                    return b.assignedSeats + a;
                }, 0 );
            $( api.column( 3 ).footer() ).html(
                assignedSeats
            );

            var availableSeats = api
                .column(4,{search:'applied'})
                .data()
                .reduce( function (a, b) {
                    return b.availableSeats + a;
                }, 0 );
            $( api.column( 4 ).footer() ).html(
                availableSeats
            );

            var reservableSeats = api
                .column(5,{search:'applied'})
                .data()
                .reduce( function (a, b) {
                    return 0;
                }, 0 );
            $( api.column( 5 ).footer() ).html(
                reservableSeats
            );

            var value = seatCapacity > 0 ? 100 * assignedSeats / seatCapacity : "NA";
			var myString = "";
			myString += '<div class="cssProgress"><div class="progress3">';
			myString += '<div class="cssProgress-bar cssProgress-success" data-percent="';
			myString += value;
			myString += '" style="width:';
			myString += value;
			myString += '%;"><span class="cssProgress-label">';
			myString += value !== null ? round(value,0) +"%" : "N/A";
			myString += '</span></div></div></div>';
            $( api.column( 6 ).footer() ).html(
                myString
            );

        },
		dom: '<".standardTableFilterDiv" and f><".standardTableButtonDiv" and B>rt',
	})
	if(this.hasInit){ // Sets up bindings on first run

	} else {

        _attach.call(Maptician.ModalTables.ZoneTable,'zoneModalFrame',165,function(height){
            $("#zoneModalTable").parent().css("height",height)
        });

		this.hasInit = true;
	}
	$('#zoneListModal').modal();
}

Maptician.ModalTables.seatTable = function(seatArray,options){
	var seatTable = Maptician.ModalTables.seatTable;
    if(options && options.title){
        $('#seatListModal').find('.header').html(options.title);
    } else {
        $('#seatListModal').find('.header').html("Seats");
    }
    
	seatTable.seatParam = seatArray;

    if(Maptician.ModalTables.SeatTable){
		Maptician.ModalTables.SeatTable.ajax.reload();
		$('#seatListModal').modal();
		return;
	}

	$('#seatListModal').modal();

	Maptician.ModalTables.SeatTable = $("#seatModalTable").DataTable({
		ajax: {
			"url":"/api/reports/modalreports/seats",
			data:function(d){
				return {data:seatTable.seatParam};
			}
		},
		"language":{
			"info": "Showing Seats _START_ to _END_ of _MAX_",
			"lengthMenu": "Show _MENU_ Seats",
			"search": "Find Seats:"
		},		
		select: true,
		scrollY:$("#seatListModal").height() - 130,
        deferRender:true,
        scroller:true,
        paging:true,
		columns:[
			{
				data:{},
				'className':'tableProfileImage',
				render: function(seat){
					if(seat.assignmentStatus == "Assigned"){
						return '<div><img src="'+seat.user.profileImage+'"></div>';
					} else {
						return '<div><img src="'+"images/blankprofile.png"+'"></div>';
					}					
				}
			},
			{
				data:'seatName', // Seat Name
				'className':'leftAlign'
			},
			{
				data: {}, // Type
				'className':'centerAlign',
				render:function(seat){
					if(seat.reservable){
						return "Reservable";
					} else {
						return "Assignable";
					}
				}
			},
			{
				data: {}, // Assigned To
				'className':'leftAlign',
				render:function(seat){
					if(seat.assignmentStatus == "Assigned"){
						return seat.user.first + ' ' + seat.user.last;
					} else if(seat.reservable){
						return "N/A";
					} else{
						return "Unassigned";
					}
				}
			},
			{
				data: 'mapName', // Map Name
				'className':'leftAlign'
			},
            {
            	data: {},
            	"orderable":true,
            	'className':'centerAlign',
            	render: function(seat){
            		if(seat.roomCount && seat.roomCount != 0){
            			return '<a class="modalTableRooms" href="#">'+seat.roomCount+'</a>';
            		} else {
            			if(seat.rooms && seat.rooms.length){
                			seat.roomCount = seat.rooms.length;                				
            			} else {
            				seat.roomCount = 0;
            				return seat.roomCount;
            			}
            			return '<a class="modalTableRooms" href="#">'+seat.roomCount+'</a>';
            		}
                },
            },
            {
            	data: {},
            	"orderable":true,
            	'className':'centerAlign',
            	render: function(seat){
            		if(seat.zoneCount && seat.zoneCount != 0){
            			return '<a class="modalTableZones" href="#">'+seat.zoneCount+'</a>';
            		} else {
            			if(seat.zones && seat.zones.length){
                			seat.zoneCount = seat.zones.length;                				
            			} else {
            				seat.zoneCount = 0;
            				return seat.zoneCount;
            			}
            			return '<a class="modalTableZones" href="#">'+seat.zoneCount+'</a>';
            		}
                },
            },
		],
		dom: '<".standardTableFilterDiv" and f><".standardTableButtonDiv" and B>rt',
	})
	if(this.hasInit){ // Sets up bindings on first run

	} else {
		this.hasInit = true;
	}
	$('#seatListModal').modal();	
}

Maptician.ModalTables.employeeTable = function(data,options){
	var employeeTable = Maptician.ModalTables.employeeTable;
	var data = data;
    var employeeData = data.employees;
    var employeeDataArray = [];
    for(var i in employeeData){
    	if(options && options.assignmentStatus){
    		// if(employeeData[i].assignmentStatus == options.assignmentStatus){
    		// 	seatDataArray.push(employeeData[i]);
    		// }
    	} else {
    		employeeDataArray.push(employeeData[i]);
    	}
    }
	if(Maptician.ModalTables.EmployeeTable){
		Maptician.ModalTables.EmployeeTable.destroy();
	}
	Maptician.ModalTables.EmployeeTable = $("#employeeModalTable").DataTable({
		data:employeeDataArray,
		pageLength:5,
		select: true,
		"language":{
			"info": "Showing Employees _START_ to _END_ of _MAX_",
			"lengthMenu": "Show _MENU_ Employees",
			"search": "Filter Employees:"
		},
		columns:[
			{
				data:{},
				'className':'tableProfileImage',
				render: function(employee){
					return '<div><img src="'+employee.imagePath+'"></div>';
				}
			},
			{
				data:'seatName', // Seat Name
				'className':'tableCenterText'
			},
			{
				data: {}, // Assigned To
				'className':'tableCenterText',
				render:function(employee){
					if(employee.employeeName){
						return employee.employeeName;
					} else {
						return "Unassigned";
					}
				}
			},
			{
				data: 'mapName', // Map Name
				'className':'tableCenterText'
			},
			{
				data: {}, // Seats Available
				'className':'tableCenterText',
				render: function(employee){
					var count = 0;
					for(var i in seat.rooms){
						if(Object.keys(seat.rooms).length){
							count += 1;
						}
					}
					return count;
				},
			},
			{
				data: {}, // Seats Reservable
				'className':'tableCenterText',
				render: function(employee){
					var count = 0;
					for(var i in seat.zones){
						if(Object.keys(seat.zones).length){
							count += 1;
						}
					}
					return count;
				},
			}
		],
		dom: '<"#employeeListModalTableFilter" and f><"#employeeListModalTableButtons" and B>rtp'
	})
	if(employeeTable.hasInit){ // Sets up bindings on first run

	} else {
		employeeTable.hasInit = true;
	}
	$('#employeeListModal').modal();	
}

// TODO Office table

Maptician.ModalTables.loadFileTable = function(type){
	var modalTables = Maptician.ModalTables;
	var loadFileTable = modalTables.loadFileTable;
	var editor = Maptician.Editor;
	var viewer = Maptician.Viewer;
	var LoadFileTable;

	loadFileTable.type = type;

	if(Maptician.Editor && Maptician.Editor.visible){
		$("#deleteMapButton").show();
	} else {
		$("#deleteMapButton").hide();
	}

    if(modalTables.LoadFileTable){ // Checks to see if the load files table has already been initialized, if so, reloads data
        modalTables.LoadFileTable.ajax.reload();
        $('#loadMapModal').modal();
        return;
    }

    $('#loadMapModal').modal();

    modalTables.LoadFileTable = $("#loadFileTable").DataTable({
        ajax: "/loadFileList",
        select: 'single',
        language:{
            "info": "Showing Maps _START_ to _END_ of _MAX_",
            "lengthMenu": "Show _MENU_ Files",
            "search": "Search:",
        },
        scrollY:$("#loadMapModal").height() - 165,
      	deferRender:true,
      	scroller:true,
      	paging:true,
        order:[1,'asc'],
        columns: [
            {
                data: {}, // Map Live
                orderable:false,
                width: '10px',
                'className':'centerAlign',
                render: function(map, type, row){
                    if(type==="filter"){
                        if(map.live){
                            return ':active';
                        } else {
                            return ':inactive';
                        }
                    } else {
                        if(map.live){
                            return '<div class="led-green" title="Map is Active" aria-hidden="true"></i>';
                        } else {
                            return '<div class="led-red" title="Map is Inactive" aria-hidden="true"></i>';
                        }
                    }
                },
            },
            {
				data: {}, // Office Name
				width: '200px',
				'className':'leftAlign',
				render: function(map){
					return map.officeName;
				},
			},
            {
				data: {}, // Map Name
				width: '200px',
				'className':'leftAlign',
				render: function(map){
					return map.name;
				},
			},
            {
				data: {}, // City
				width: '100px',
				'className':'leftAlign',
				render: function(map){
					return map.city;
				},
			},
            {
				data: {}, // State
				width: '50px',
				'className':'tableCenterText',
				render: function(map){
					return map.state;
				},
			},
            {
				data: {}, // Floor
				width: '50px',
				'className':'tableCenterText',
				render: function(map){
                    if(map.floor){
                        return map.floor;
                    } else {
                        return "";
                    }
				},
			},
            {
				data: {}, // Suite
				width: '50px',
				'className':'tableCenterText',
				render: function(map){
                    if(map.suite){
                        return map.suite;
                    } else {
                        return "";
                    }
				},
			},
            {
				data: {}, // Last Saved
				width: '250px',
				'className':'tableCenterText',
				render: function(map){
					return moment(map.date).format("MMM DD, YYYY @h:mm a");
				},
			},
            {
            	data: {}, // History Button
				width: '50px',
				'className':'buttonCenter',
                sortable:false,
                render: function(map){
                    var versionButton = '<div class="btn loadVersionButton" title="Versions">'+
                            '<i class="fa fa-versions fa-lg" aria-hidden="true"></i></div>';
                    var scenarioButton = '<div class="btn loadScenariosButton" title="Scenarios">'+
                            '<i class="fa fa-flow-tree fa-lg" aria-hidden="true"></i></div>';
                    if(Maptician.ModalTables.loadFileTable.type == "editor"){
                        return versionButton + scenarioButton;
                    } else {
                        return "";
                    }
                },
            },
        ],
        dom: 'rt',
        initComplete: function(){
            $('#loadMapModal').modal();
        }
    }) // End of DataTable Initialization

    LoadFileTable = modalTables.LoadFileTable;

    if(loadFileTable.hasInit){ // Sets up bindings on first run

    } else {

        $("#loadMapSearch").on( 'input', function () {
            var textValue = $("#loadMapSearch").val();
            var officeValue = $("#loadMapOfficeSelect").chosen().val();
            var statusValue = $('#loadMapStatusSelect').chosen().val();
            if(statusValue=="Active"){
                statusValue = ":active";
            } else if (statusValue == "Inactive"){
                statusValue = ":inactive";
            }            
            var fullValue = textValue + " " + officeValue + " " + statusValue;
            LoadFileTable.search(fullValue).draw();
        } );

        $('#loadMapOfficeSelect').on('change', function(evt, params) {
            var officeValue = params ? params.selected : "";
            var statusValue = $('#loadMapStatusSelect').chosen().val();
            if(statusValue=="Active"){
                statusValue = ":active";
            } else if (statusValue == "Inactive"){
                statusValue = ":inactive";
            }   
            var textValue = $("#loadMapSearch").val();
            var fullValue = textValue + " " + officeValue + " " + statusValue;
            LoadFileTable.search(fullValue).draw();
        });

        $('#loadMapStatusSelect').on('change', function(evt, params) {
            var statusValue = params ? params.selected : "";
            if(statusValue=="Active"){
                statusValue = ":active";
            } else if (statusValue == "Inactive"){
                statusValue = ":inactive";
            }
            var officeValue = $("#loadMapOfficeSelect").chosen().val();
            var textValue = $("#loadMapSearch").val();
            var fullValue = textValue + " " + officeValue + " " + statusValue;
            LoadFileTable.search(fullValue).draw();
        });

        $("#loadMapOfficeSelect").chosen({
            placeholder_text_single:"Filter by Office",
            allow_single_deselect: true,
            width:"200px",
            disable_search_threshold: 10
        });

        $("#loadMapStatusSelect").chosen({
            placeholder_text_single:"Filter by Status",
            allow_single_deselect: true,
            width:"150px",
            disable_search_threshold: 10
        });
        
        LoadFileTable.on('xhr.dt',function( e, settings, json, xhr ){
            var officeNames = {};
            for(var i = 0; i < json.data.length; i++){
                officeNames[json.data[i].officeName] = {};
            }
            var nameList = Object.keys(officeNames);
            var loadSelect = $("#loadMapOfficeSelect");
            loadSelect.empty();
            loadSelect.append("<option></option>")
            for(var i = 0; i < nameList.length; i++){
                loadSelect.append("<option>"+nameList[i]+"</option>")
            }
            loadSelect.trigger("chosen:updated");
        })       

		_attach.call(LoadFileTable,'loadFileTableFrame',165,function(height){
			$("#loadFileTable").parent().css("height",height)
		});

        LoadFileTable.on('click','.loadVersionButton',function(){
            var tr = $(this).closest('tr');
            var row = LoadFileTable.row(tr);
            var data = row.data();
            modalTables.loadFileVersionTable(data);
        })

        LoadFileTable.on('click','.loadScenariosButton',function(){
            var tr = $(this).closest('tr');
            var row = LoadFileTable.row(tr);
            var data = row.data();
            modalTables.loadFileScenarioTable(data);
        })

        $("#loadMapButton").click(function(){
            var selected = LoadFileTable.selectedFile;
            var data = {
                id:selected.id,
                date:selected.date
                }
            $.ajax({
            	type:"GET",
            	url: "/loadMapFile",
            	data:data,
                success:function(result){
                    console.log("Loading file results as",loadFileTable.type)
                    switch(loadFileTable.type){
                        case "editor":
                            Maptician.Editor.loadFile(result);
                        break;
                        case "viewer":
                            Maptician.Viewer.loadFile(result);
                        break;
                    }
                }})
            $.modal.close();
            $("#loadFileTable tr").removeClass("selected");
        })

        $("#cancelLoadMap").click(function(){
            $.modal.close();
            $("#loadFileTable tr").removeClass("selected");
        })

        $("#deleteMapButton").click(function(){
            var selected = LoadFileTable.selectedFile;
            var data = {
                id:selected.id
                }
            swal({
                  title: "Deleting Map",
                  text: "Deleting the Map will permanently remove this map, all its versions, and all associated rooms, seats, and seat assignments." +
                  	" Are you sure you want to delete this map?",
                  type: "warning",
                  showCancelButton: true,
                  confirmButtonColor: "#525252",    
                  confirmButtonText: "Continue with Delete",
                  cancelButtonText: "Cancel Delete"
                })
            .then(function(isConfirm){
                if (isConfirm) {
                    $.ajax({type:"DELETE",url: "/removeMapFile",data:data,
                        success:function(result){
                            $("#loadFileTable tr").removeClass("selected");
                            modalTables.LoadFileTable.ajax.reload();
                        }})
                } else {
                    $("#assignUserModal tr").removeClass("selected");
                }
            })
        })
        
        LoadFileTable.on( 'select', function ( e, dt, type, indexes ) {
            LoadFileTable.selectedFile = LoadFileTable.rows( indexes ).data().toArray()[0];
        })
        
        loadFileTable.hasInit = true;
    }
}

Maptician.ModalTables.loadViewerFileTable = function(){
    var modalTables = Maptician.ModalTables;
    var loadViewerFileTable = modalTables.loadViewerFileTable;
    var viewer = Maptician.Viewer;
    var LoadViewerFileTable;

    if(modalTables.LoadViewerFileTable){ // Checks to see if the load files table has already been initialized, if so, reloads data
        modalTables.LoadViewerFileTable.ajax.reload();
        $('#loadViewerMapModal').modal();
        return;
    }

    $('#loadViewerMapModal').modal();

    modalTables.LoadViewerFileTable = $("#loadViewerFileTable").DataTable({
        ajax: "/loadViewerFileList",
        select: 'single',
        language:{
            "info": "Showing Maps _START_ to _END_ of _MAX_",
            "lengthMenu": "Show _MENU_ Files",
            "search": "Search:",
        },
        scrollY:$("#loadViewerMapModal").height() - 165,
        deferRender:true,
        scroller:true,
        paging:true,
        order:[1,'asc'],
        columns: [
            {
                data: {}, // Office Name
                width: '200px',
                'className':'leftAlign',
                render: function(map){
                    return map.officeName;
                },
            },
            {
                data: {}, // Map Name
                width: '200px',
                'className':'leftAlign',
                render: function(map){
                    return map.name;
                },
            },
            {
                data: {}, // City
                width: '100px',
                'className':'leftAlign',
                render: function(map){
                    return map.city;
                },
            },
            {
                data: {}, // State
                width: '50px',
                'className':'tableCenterText',
                render: function(map){
                    return map.state;
                },
            },
            {
                data: {}, // Floor
                width: '50px',
                'className':'tableCenterText',
                render: function(map){
                    if(map.floor){
                        return map.floor;
                    } else {
                        return "";
                    }
                },
            },
            {
                data: {}, // Suite
                width: '50px',
                'className':'tableCenterText',
                render: function(map){
                    if(map.suite){
                        return map.suite;
                    } else {
                        return "";
                    }
                },
            },
        ],
        dom: 'rt',
        initComplete: function(){
            $('#loadViewerMapModal').modal();
        }
    }) // End of DataTable Initialization

    LoadViewerFileTable = modalTables.LoadViewerFileTable;

    if(loadViewerFileTable.hasInit){ // Sets up bindings on first run

    } else {

        $("#loadViewerMapSearch").on( 'input', function () {
            var textValue = $("#loadViewerMapSearch").val();
            var officeValue = $("#loadViewerMapOfficeSelect").chosen().val();       
            var fullValue = textValue + " " + officeValue;
            LoadViewerFileTable.search(fullValue).draw();
        } );

        $('#loadViewerMapOfficeSelect').on('change', function(evt, params) {
            var officeValue = params ? params.selected : ""; 
            var textValue = $("#loadViewerMapSearch").val();
            var fullValue = textValue + " " + officeValue;
            LoadViewerFileTable.search(fullValue).draw();
        });

        $("#loadViewerMapOfficeSelect").chosen({
            placeholder_text_single:"Filter by Office",
            allow_single_deselect: true,
            width:"200px",
            disable_search_threshold: 10
        });
   
        LoadViewerFileTable.on('xhr.dt',function( e, settings, json, xhr ){
            console.log(e,settings,json,xhr)
            var officeNames = {};
            for(var i = 0; i < json.data.length; i++){
                officeNames[json.data[i].officeName] = {};
            }
            var nameList = Object.keys(officeNames);
            var loadSelect = $("#loadViewerMapOfficeSelect");
            loadSelect.empty();
            loadSelect.append("<option></option>")
            for(var i = 0; i < nameList.length; i++){
                loadSelect.append("<option>"+nameList[i]+"</option>")
            }
            loadSelect.trigger("chosen:updated");
        })       

        _attach.call(LoadViewerFileTable,'loadFileViewerTableFrame',165,function(height){
            $("#loadViewerFileTable").parent().css("height",height)
        });

        $("#loadViewerMapButton").click(function(){
            console.log("load map clicked");
            var selected = LoadViewerFileTable.selectedFile;
            var data = {
                id:selected.id,
                date:selected.date
                }
            Maptician.ModalTables.selectedOfficeName=selected.officeName;
            $.ajax({
                type:"GET",
                url: "/loadMapFile",
                data:data,
                success:function(result){
                    Maptician.Viewer.loadFile(result);
                }})
            $.modal.close();
            $("#loadViewerFileTable tr").removeClass("selected");
        })

        $("#cancelViewerLoadMap").click(function(){
            $.modal.close();
            $("#loadViewerFileTable tr").removeClass("selected");
        })
       
        LoadViewerFileTable.on( 'select', function ( e, dt, type, indexes ) {
            LoadViewerFileTable.selectedFile = LoadViewerFileTable.rows( indexes ).data().toArray()[0];
        })
        
        loadViewerFileTable.hasInit = true;
    }
}

Maptician.ModalTables.loadFileScenarioTable = function(data){
    console.log(data)
    $("#loadScenarioHeader").html("Scenarios for "+data.name);    
    var modalTables = Maptician.ModalTables;
    var loadFileScenarioTable = modalTables.loadFileScenarioTable;
    var LoadFileScenarioTable;

    loadFileScenarioTable.mapParam = data.id;

    if(modalTables.LoadFileScenarioTable){ // Checks to see if the load files table has already been initialized, if so, reloads data
        modalTables.LoadFileScenarioTable.ajax.reload();
        $('#loadScenarioModal').modal({closeExisting:false});
        return;
    }

    $('#loadScenarioModal').modal({closeExisting:false});

    modalTables.LoadFileScenarioTable = $("#loadScenarioFileTable").DataTable({
        ajax: {
            "url":"/api/scenarios/loadScenarioFileList",
            data:function(d){
                console.log(loadFileScenarioTable.mapParam)
                return {id:loadFileScenarioTable.mapParam};
            }
        },
        select: 'single',
        language:{
            "info": "Showing Maps _START_ to _END_ of _MAX_",
            "lengthMenu": "Show _MENU_ Files",
            "search": "Search:",
        },
        scrollY:$("#loadScenarioModal").height() - 125,
        deferRender:true,
        scroller:true,
        paging:true,
        columns: [
            {
                data: {}, // Scenario Name
                width: '100px',
                'className':'leftAlign',
                render: function(scenario){
                    return scenario.scenarioName;
                },
            },
            {
                data: {}, // Map Name
                width: '100px',
                'className':'leftAlign',
                render: function(scenario){
                    return scenario.mapName;
                },
            },
            {
                'className':'centerAlign',
                data: {}, // Seats
                width: '50px',
                render: function(scenario){
                    return scenario.seats;
                },
            },
            {
                data: {}, // Last Saved
                width: '150px',
                'className':'centerAlign',
                render: function(scenario){
                    return moment(scenario.date).format("MMM DD, YYYY @h:mm a");
                },
            },
        ],
        dom: 'rt'
    }) // End of DataTable Initialization

    LoadFileScenarioTable = modalTables.LoadFileScenarioTable;

    if(loadFileScenarioTable.hasInit){ // Functions that should be run on every table load

    } else { // Sets up bindings on first run
        
        _attach.call(LoadFileScenarioTable,'loadScenarioTableFrame',125,function(height){
            $("#loadScenarioFileTable").parent().css("height",height)
        });

        $("#loadMapScenario").click(function(){
            var selected = LoadFileScenarioTable.selectedFile;
            var data = {
                    scenarioID:selected.scenarioID
                }
            $.ajax({
                type:"GET",
                url: "/api/scenarios/loadScenarioFile",
                data:data,
                success:function(result){
                    console.log('Loading Scenario');
                    Maptician.Editor.loadScenario(result);
                    $.modal.close();
                }})
            $.modal.close();
            $("#loadScenarioFileTable tr").removeClass("selected");
        })

        $("#cancelLoadMapScenario").click(function(){
            $.modal.close();
            $("#loadScenarioFileTable tr").removeClass("selected");
        })

        LoadFileScenarioTable.on( 'select', function ( e, dt, type, indexes ) {
            LoadFileScenarioTable.selectedFile = LoadFileScenarioTable.rows( indexes ).data().toArray()[0];
        })

        loadFileScenarioTable.hasInit = true;
    }
}

Maptician.ModalTables.loadFileVersionTable = function(data){
    $("#loadVersionHeader").html("Load Previous Version of "+data.name);    
    var modalTables = Maptician.ModalTables;
    var loadFileVersionTable = modalTables.loadFileVersionTable;
    var LoadFileVersionTable;

    loadFileVersionTable.mapParam = data.id;

    if(modalTables.LoadFileVersionTable){ // Checks to see if the load files table has already been initialized, if so, reloads data
        modalTables.LoadFileVersionTable.ajax.reload();
        $('#loadVersionModal').modal({closeExisting:false});
        return;
    }

    $('#loadVersionModal').modal({closeExisting:false});

    modalTables.LoadFileVersionTable = $("#loadPreviousFileTable").DataTable({
        ajax: {
            "url":"/loadFileVersionList",
            data:function(d){
                return {id:loadFileVersionTable.mapParam};
            }
        },
        select: 'single',
        language:{
            "info": "Showing Maps _START_ to _END_ of _MAX_",
            "lengthMenu": "Show _MENU_ Files",
            "search": "Search:",
        },
        scrollY:$("#loadVersionModal").height() - 125,
        deferRender:true,
        scroller:true,
        paging:true,
        columns: [
            {
                data: {}, // Map Name
                width: '100px',
                'className':'leftAlign',
                render: function(map){
                    return map.name;
                },
            },
            {
                data: {}, // Last Saved
                width: '150px',
                'className':'tableCenterText',
                render: function(map){
                    return moment(map.date).format("MMM DD, YYYY @h:mm a");
                },
            },
        ],
        dom: 'rt'
    }) // End of DataTable Initialization

    LoadFileVersionTable = modalTables.LoadFileVersionTable;

    if(loadFileVersionTable.hasInit){ // Functions that should be run on every table load

    } else { // Sets up bindings on first run
        
        _attach.call(LoadFileVersionTable,'loadVersionTableFrame',125,function(height){
            $("#loadPreviousFileTable").parent().css("height",height)
        });

        $("#loadMapVersion").click(function(){
            var selected = LoadFileVersionTable.selectedFile;
            var data = {
                id:selected.id,
                date:selected.date
                }
            $.ajax({
                type:"GET",
                url: "/loadMapFile",
                data:data,
                success:function(result){
                    Maptician.Editor.loadFile(result);
                    $.modal.close();
                }})
            $.modal.close();
            $("#loadPreviousFileTable tr").removeClass("selected");
        })

        $("#cancelLoadMapVersion").click(function(){
            $.modal.close();
            $("#loadPreviousFileTable tr").removeClass("selected");
        })

        LoadFileVersionTable.on( 'select', function ( e, dt, type, indexes ) {
            LoadFileVersionTable.selectedFile = LoadFileVersionTable.rows( indexes ).data().toArray()[0];
        })


        loadFileVersionTable.hasInit = true;
    }
}

Maptician.ModalTables.setMaplinkTable = function(officeID,mapID,maplinkID,type){
    var modalTables = Maptician.ModalTables;
    var setMaplinkTable = modalTables.setMaplinkTable;
    setMaplinkTable.params = {
        officeID: officeID,
        mapID: mapID,
        type: type
    }
    console.log(setMaplinkTable.params)
    var editor = Maptician.Editor;
    var SetMaplinkTable;
    
    if(setMaplinkTable.hasInit){
        $('#setMaplinkModal').modal();
        modalTables.SetMaplinkTable.ajax.reload();
        return;
    }
    
    $('#setMaplinkModal').modal();

    modalTables.SetMaplinkTable = $('#setMaplinkTable').DataTable({
        ajax: {
            "url":"/api/maplinks/maplinkList",
            data: function(d){
                return setMaplinkTable.params;
            }
        },
        select: 'single',
        scrollY:$("#setMaplinkModal").height()-160,
        deferRender:true,
        scroller:true,
        paging:true,
        columns:[
            {
                title: "Name", // Link Name
                data: {}, 
                className:'leftAlign',
                render: function(link){
                    return link.linkName ? link.linkName : "";
                }
            },
            {
                title: "Floor", // Map Floor
                data: {},
                className:'centerAlign',
                render: function(link){
                    return link.floor ? link.floor : "";
                }
            },
            {
                title: "Suite", // Map Suite
                data: {},
                className:'centerAlign',
                render: function(link){
                    return link.suite ? link.suite : "";
                }
            },
            {
                title: "Status", // Connection Status
                data: {},
                className:'centerAlign',
                render: function(link){
                    return link.connection ? link.connection : "Not Linked";
                }
            }
        ],
        dom: '<"#seatAssignmentFilter" and f>rt'
    })

    SetMaplinkTable = modalTables.SetMaplinkTable;

    if(setMaplinkTable.hasInit){ // Sets up bindings on first run

    } else {

        _attach.call(SetMaplinkTable,'setMaplinkTableFrame',160,function(height){
            $("#setMaplinkTable").parent().css("height",height)
        });

        SetMaplinkTable.on( 'select', function ( e, dt, type, indexes ) {
            SetMaplinkTable.selectedFile = SetMaplinkTable.rows( indexes ).data().toArray()[0];
        })

        $("#setMaplink").click(function(){
            var linkData = SetMaplinkTable.selectedFile;
            var connection = {
                linkID: linkData.linkID,
                linkName: linkData.linkName,
                mapID: linkData.mapID,
                mapName: linkData.mapName,
                floor: linkData.floor,
                suite: linkData.suite,
                location: linkData.location
            }
            var linkID = editor.currentFile.objectSelector.selected.id;
            editor.currentFile.dataConnections.setMaplink(linkID,connection);
            editor.currentFile.objectSelector.updateSelector();  
            $.modal.close();
            $("#setMaplinkModal tr").removeClass("selected");
        })

        $("#cancelSetMaplink").click(function(){
            $.modal.close();
        })
        
        setMaplinkTable.hasInit = true;
    } 
}