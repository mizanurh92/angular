Maptician.PageTables = {};
Maptician.OfficeTables = {};
Maptician.BulkUpload = {};
Maptician.BulkUpload.hasInit=false;

Maptician.PageTables.scenariosTable = function(type){
	var pageTables = Maptician.PageTables;
	var scenariosTable = pageTables.scenariosTable;
	var LoadFileTable;

	if(pageTables.ScenariosTable){ // Checks to see if the load files table has already been initialized, if so, reloads data
		pageTables.ScenariosTable.ajax.reload();
		return;
	}

	pageTables.ScenariosTable = $("#scenariosList").DataTable({
		ajax: "/api/scenarios/loadScenarioList",
		select: 'single',
		language:{
			"info": "Showing Scenarios _START_ to _END_ of _MAX_",
			"lengthMenu": "Show _MENU_ Scenarios",
			"search": "Search:",
		},
		scrollY:$("#scenariosArea").height() - 80,
		deferRender:true,
		scroller:true,
		paging:true,
		order:[1,'asc'],
		columns: [
			{
				data: {}, // Scenario Name
				width: '200px',
				'className':'leftAlign',
				render: function(map){
					return map.scenarioName;
				},
			},
			{
				data: {}, // Map Name
				width: '200px',
				'className':'leftAlign',
				render: function(map){
					return map.mapName;
				},
			},
			{
				data: {}, // Office Name
				width: '200px',
				'className':'leftAlign',
				render: function(map){
					return map.officeName;
				},
			},
			{
				data: {}, // Seats
				width: '50px',
				'className':'tableCenterText',
				render: function(map){
					if(map.seatCount){
						return map.seatCount;
					}
					if(map.seats){
						map.seatCount = Object.keys(map.seats).length;
						return map.seatCount;
					} else {
						return 0;
					}
				},
			},
			{
				data: {}, // Rooms
				width: '50px',
				'className':'tableCenterText',
				render: function(map){
					if(map.roomCount){
						return map.roomCount;
					}
					if(map.rooms){
						map.roomCount = Object.keys(map.rooms).length;
						return map.roomCount;
					} else {
						return 0;
					}
				},
			},
			{
				data: {}, // zones
				width: '50px',
				'className':'tableCenterText',
				render: function(map){
					if(map.zoneCount){
						return map.zoneCount;
					}
					if(map.zones){
						map.zoneCount = Object.keys(map.zones).length;
						return map.zoneCount;
					} else {
						return 0;
					}
				},
			},
			{
				data: {}, // Last Saved
				width: '250px',
				'className':'tableCenterText',
				render: function(map){
					return moment(map.date).format("MMM DD, YYYY @h:mm a");
				},
			},
			{
				data: {}, // History Button
				width: '50px',
				'className':'buttonCenter',
				sortable:false,
				render: function(map){
					var loadScenario = '<div class="btn loadScenarioButton" title="Load Scenario">'+
							'<i class="fa fa-folder-open fa-lg" aria-hidden="true"></i></div>';
					var deleteScenario = '<div class="btn deleteScenarioButton" title="Delete Scenario">'+
							'<i class="fa fa-times-circle fa-lg" aria-hidden="true"></i></div>';
					return loadScenario + deleteScenario;
				},
			},
		],
		dom: 'rt'
	}) // End of DataTable Initialization

	ScenariosTable = pageTables.ScenariosTable;

	if(scenariosTable.hasInit){ // Sets up bindings on first run

	} else {

		$("#scenarioSearch").on( 'input', function () {
			var searchValue = $("#scenarioSearch").val();
			var mapValue = $("#scenarioMapSelect").chosen().val();
			var officeValue = $('#scenarioOfficeSelect').chosen().val();           
			var fullValue = searchValue + " " + mapValue + " " + officeValue;
			ScenariosTable.search(fullValue).draw();
		} );

		$('#scenarioMapSelect').on('change', function(evt, params) {
			var textValue = $("#loadMapSearch").val();
			var mapValue = params ? params.selected : "";
			var officeValue = $('#scenarioOfficeSelect').chosen().val();
			var fullValue = searchValue + " " + mapValue + " " + officeValue;
			ScenariosTable.search(fullValue).draw();
		});

		$('#scenarioOfficeSelect').on('change', function(evt, params) {
			var textValue = $("#loadMapSearch").val();
			var mapValue = $("#scenarioMapSelect").chosen().val();
			var officeValue = params ? params.selected : "";
			var fullValue = searchValue + " " + mapValue + " " + officeValue;
			ScenariosTable.search(fullValue).draw();
		});

		$("#scenarioMapSelect").chosen({
			placeholder_text_single:"Filter by Map",
			allow_single_deselect: true,
			width:"200px",
			disable_search_threshold: 10
		});

		$("#scenarioOfficeSelect").chosen({
			placeholder_text_single:"Filter by Office",
			allow_single_deselect: true,
			width:"200px",
			disable_search_threshold: 10
		});
		
		ScenariosTable.on('xhr.dt',function( e, settings, json, xhr ){
			console.log(e,settings,json,xhr)
			console.log(xhr.getAllResponseHeaders())
			if(!json){return;}
			var officeNameObj = {};
			var mapNameObj = {};

			for(var i = 0; i < json.data.length; i++){
				officeNameObj[json.data[i].officeName] = {};
				mapNameObj[json.data[i].mapName] = {};
			}
			var officeNames = Object.keys(officeNameObj);
			var officeSelect = $("#scenarioOfficeSelect");
			officeSelect.empty();
			officeSelect.append("<option></option>")
			for(var i = 0; i < officeNames.length; i++){
				officeSelect.append("<option>"+officeNames[i]+"</option>")
			}
			officeSelect.trigger("chosen:updated");

			var mapNames = Object.keys(mapNameObj);            
			var mapSelect = $("#scenarioMapSelect");
			mapSelect.empty();
			mapSelect.append("<option></option>")
			for(var i = 0; i < mapNames.length; i++){
				mapSelect.append("<option>"+mapNames[i]+"</option>")
			}
			mapSelect.trigger("chosen:updated");
		})       

		_attach.call(ScenariosTable,'loadFileTableFrame',80,function(height){
			$("#scenariosArea").parent().css("height",height)
		});

		ScenariosTable.on('click','.loadVersionButton',function(){
			var tr = $(this).closest('tr');
			var row = ScenariosTable.row(tr);
			var data = row.data();
			pageTables.loadFileVersionTable(data);
		})

		ScenariosTable.on('click','.loadScenariosButton',function(){
			var tr = $(this).closest('tr');
			var row = ScenariosTable.row(tr);
			var data = row.data();
			pageTables.loadFileScenarioTable(data);
		})

		// $("#loadMapButton").click(function(){
		//     console.log("load map clicked");
		//     var selected = ScenariosTable.selectedFile;
		//     var data = {
		//         id:selected.id,
		//         date:selected.date
		//         }
		//     $.ajax({
		//         type:"GET",
		//         url: "/loadMapFile",
		//         data:data,
		//         success:function(result){
		//             console.log("Loading file results as",loadFileTable.type)
		//             switch(loadFileTable.type){
		//                 case "editor":
		//                     Maptician.Editor.loadFile(result);
		//                 break;
		//                 case "viewer":
		//                     Maptician.Viewer.loadFile(result);
		//                 break;
		//             }
		//         }})
		//     $.modal.close();
		//     $("#loadFileTable tr").removeClass("selected");
		// })

		// $("#cancelLoadMap").click(function(){
		//     $.modal.close();
		//     $("#loadFileTable tr").removeClass("selected");
		// })

		// $("#deleteMapButton").click(function(){
		//     var selected = ScenariosTable.selectedFile;
		//     var data = {
		//         id:selected.id
		//         }
		//     swal({
		//           title: "Deleting Map",
		//           text: "Deleting the Map will permanently remove this map, all its versions, and all associated rooms, seats, and seat assignments." +
		//             " Are you sure you want to delete this map?",
		//           type: "warning",
		//           showCancelButton: true,
		//           confirmButtonColor: "#525252",    
		//           confirmButtonText: "Continue with Delete",
		//           cancelButtonText: "Cancel Delete",
		//           closeOnConfirm: true,
		//           closeOnCancel: true
		//         },
		//         function(isConfirm){
		//             if (isConfirm) {
		//                 $.ajax({type:"DELETE",url: "/removeMapFile",data:data,
		//                     success:function(result){
		//                         $("#loadFileTable tr").removeClass("selected");
		//                         pageTables.ScenariosTable.ajax.reload();
		//                     }})
		//             } else {
		//                 $("#assignUserModal tr").removeClass("selected");
		//             }
		//         });
		// })
		
		ScenariosTable.on( 'select', function ( e, dt, type, indexes ) {
			ScenariosTable.selectedFile = ScenariosTable.rows( indexes ).data().toArray()[0];
		})
		
		scenariosTable.hasInit = true;
	}
}

Maptician.OfficeTables.kioskList = function(options){
	var kioskList = Maptician.OfficeTables.kioskList;
	options = options || {};
	options.officeID ? kioskList.officeID = options.officeID : kioskList.officeID;

	if(kioskList.hasInit && options.destroy != true){
		console.log('reloading',console.log(this))
		Maptician.OfficeTables.KioskList.ajax.reload();
		return;
	}

	if(options.destroy && kioskList.hasInit){
		Maptician.OfficeTables.KioskList.off('click','.kioskCredentialButton');
		Maptician.OfficeTables.KioskList.off('click','.kioskLoginButton');
		Maptician.OfficeTables.KioskList.off('click','.gotoKioskButton');
		Maptician.OfficeTables.KioskList.clear().draw().destroy();
		delete Maptician.OfficeTables.KioskList;
		$('#kioskList').empty();
		kioskList.hasInit = false;
		return;
	}

	Maptician.OfficeTables.KioskList = $('#kioskList').DataTable({
		ajax: {
			"url":"/api/kiosks/visitorKioskList",
			data:function(d){
				return {officeID:kioskList.officeID};
			}
		},
		select: 'single',
		"language":{
			"info": "Showing Kiosks _START_ to _END_ of _MAX_",
			"lengthMenu": "Show _MENU_ Kiosks",
			"search": "Filter Kiosks:"
		},
		scrollY:200,
		deferRender:true,
		scroller:true,
		paging:true,
		columns: [
			{
				data: {}, // Kiosk Name
				title: "Name",
				'className':'leftAlign',
				render: function(kiosk){
					console.log(kiosk)
					return kiosk.kioskName;
				}
			},
			{   
				data: {}, // Map Name
				title: "Map",
				'className':'leftAlign',
				render: function(kiosk){
					return kiosk.mapName;
				}
			},
			{
				data: {}, // Kiosk User Name
				title: "Username",
				'className':'leftAlign',
				render: function(kiosk){
					return kiosk.userName;
				}
			},            
			{
				data: {}, // Action Buttons
				title: "",
				width: '90px',
				'className':'buttonCenter',
				sortable:false,
				render: function(kiosk){
					var kioskCredentialButton = '<div class="btn kioskCredentialButton" title="Set User Name and Password">'+
							'<i class="fa fa-id-card-o fa-lg" aria-hidden="true"></i></div>';
					var kioskLoginButton = '<div class="btn kioskLoginButton" title="Go to login screen">'+
							'<i class="fa fa-home fa-lg" aria-hidden="true"></i></div>';
					var gotoKioskButton = '<div class="btn gotoKioskButton" title="View in Editor">'+
							'<i class="fa fa-crosshairs fa-lg" aria-hidden="true"></i></div>';
					return kioskCredentialButton + kioskLoginButton + gotoKioskButton;
				},
			},
		],
		dom: 'rt',
	})

	var KioskList = Maptician.OfficeTables.KioskList;

	if(kioskList.hasInit){ // Sets up bindings on first run
	} else {

		KioskList.on( 'select', function ( e, dt, type, indexes ) {
			var rowData = KioskList.rows( indexes ).data().toArray();
			kioskList.selected = rowData;
		})

		KioskList.on('click','.kioskLoginButton',function(){
			var tr = $(this).closest('tr');
			var row = KioskList.row(tr);
			var data = row.data();
			console.log(data)
			var win = window.open(window.location.origin + '/kiosklogin?company='+data.companyName+'&user='+data.userName, '_blank');
			if (win) {
				//Browser has allowed it to be opened
				win.focus();
			} else {
				//Browser has blocked it
				alert('Please allow popups for this website');
			}
		})  

		KioskList.on('click','.kioskCredentialButton',function(){
			var tr = $(this).closest('tr');
			var row = KioskList.row(tr);
			var data = row.data();
			Maptician.Modals.setKioskCredentials(data);
		})        
	
		KioskList.on('click','.gotoKioskButton',function(){
			var tr = $(this).closest('tr');
			var row = KioskList.row(tr);
			var data = row.data();
			var editData = {
				id: data.mapID
			}
			if(!Maptician.Editor || !Maptician.Editor.hasInit){Maptician.Editor = new MapEditorController();}
			if(!Maptician.Editor.visible){
				$(".contentArea,#topNav").hide();
				$("#editorArea").css({right:'300px'}).show();
				$('#rightNavBar').show();
				$(".lev-1").removeClass("selected");
				$("#editorMenu").addClass("selected");
				Maptician.Editor.visible = true;
				Maptician.Editor.viewFile({mapID:data.mapID,location:data.location});
			}
		})    

		kioskList.hasInit = true;
	}
}
