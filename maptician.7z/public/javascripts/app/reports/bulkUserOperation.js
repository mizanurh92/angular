Maptician.BulkUpload = {};
Maptician.BulkUpload.hasInit=false;
Maptician.BulkUpload.mapingOption = ["Email", "First", "Last", "Cell", "UserType", "Password", "UserStatus", "EmployeeID", "Title", "Department", "Office", "CodeRequired", "Contactable"];
Maptician.BulkUpload.mapingOptionName=["Email ID","First Name","Last Name","Cell Number","User Type","Password","User Status","Employee ID","Title","Department","Office","Code Required","Contactable"]; 
 
 //This is the starting point of bulk user operation.
Maptician.BulkUpload.bulkOperations=function(){
   // var modalElement = $('#BulkUploadOptionModal'); // Alias to the jQuery modal html element
     $('#BulkUploadOptionModal').modal({
        clickClose: false
      });
    document.getElementById("xlf").value = "";
    Maptician.BulkUpload.dataParing();
    $("#BulkUploadOptionModal .close-modal ").on("click",function(){
        Maptician.BulkUpload.closeBulkOpertion();   
    })
}
//This function parse the data of uploaded file and it has overriden the parsing logic of js-xlsx js 
// We have cusomized the parsing logic to take the blank value of the fileds/cell.
Maptician.BulkUpload.dataParing=function(){
    Maptician.BulkUpload.option = '';
    for (var i=0;i<Maptician.BulkUpload.mapingOption.length;i++){
       Maptician.BulkUpload.option += '<option value="'+ Maptician.BulkUpload.mapingOption[i] + '">' + Maptician.BulkUpload.mapingOptionName[i] + '</option>';
    }
    $('#selectOption select:nth-child(1)').append(Maptician.BulkUpload.option);
    if(!Maptician.BulkUpload.hasInit){
        var X = XLSX;
        var XW = {
            /* worker message */
            msg: 'xlsx',
            /* worker scripts */
            worker: './javascripts/app/reports/xlsxworker.js'
        };
        var global_wb;
        var process_wb = (function() {
            var OUT = document.getElementById('out');
            var HTMLOUT = document.getElementById('bulkUploadList');
            var to_html = function to_html(workbook) {
                HTMLOUT.innerHTML = "";
                workbook.SheetNames.forEach(function(sheetName) {
                    var htmlstr = X.write(workbook, {sheet:sheetName, type:'binary', bookType:'html'});
                    HTMLOUT.innerHTML += htmlstr;
                    $("#selectOption > select:not(:first)").remove();
                    Maptician.BulkUpload.gotData=true;
                    Maptician.BulkUpload.dynamicSelect();
                    Maptician.BulkUpload.dynamicHeader();
                    $("#bulkUploadList tr:nth-child(1) td").addClass("headerdata");
                    $("#bulkUploadDataMappingTab .spinner").hide();
                });
                return "";
            };
            return function process_wb(wb) {
                global_wb = wb;
                var output = "";
                output = to_html(wb);
                if(OUT.innerText === undefined) OUT.textContent = output;
                else OUT.innerText = output;
                if(typeof console !== 'undefined') console.log("output", new Date());
            };
        })();
        var setfmt = window.setfmt = function setfmt() { if(global_wb) process_wb(global_wb); };
        var do_file = (function() {
            var rABS = typeof FileReader !== "undefined" && (FileReader.prototype||{}).readAsBinaryString;
            var use_worker = typeof Worker !== 'undefined';
            var xw = function xw(data, cb) {
                var worker = new Worker(XW.worker);
                worker.onmessage = function(e) {
                    switch(e.data.t) {
                        case 'ready': break;
                        case 'e': console.error(e.data.d); break;
                        case XW.msg: cb(JSON.parse(e.data.d)); break;
                    }
                };
                worker.postMessage({d:data,b:rABS?'binary':'array'});
            };
            return function do_file(files) {
                var f = files[files.length-1];
                Maptician.BulkUpload.fileType = f.name.split('.').pop();
                
                $('#bulkUploadStep1Btn').removeAttr('disabled');
                console.log(Maptician.BulkUpload.fileType);
                if(Maptician.BulkUpload.fileType=="xlsx" || Maptician.BulkUpload.fileType=="xls"){
                    var reader = new FileReader();
                    reader.onload = function(e) {
                        if(typeof console !== 'undefined') console.log("onload", new Date(), rABS, use_worker);
                        var data = e.target.result;
                        if(!rABS) data = new Uint8Array(data);
                        if(use_worker) xw(data, process_wb);
                        else process_wb(X.read(data, {type: rABS ? 'binary' : 'array'}));
                    };
                    if(rABS) reader.readAsBinaryString(f);
                    else reader.readAsArrayBuffer(f);
                }
                else if(Maptician.BulkUpload.fileType=="csv"){
                    if (typeof (FileReader) != "undefined") {
                    Maptician.BulkUpload.fileTypeIsCsv=true;
                    $('#bulkUploadStep1Btn').removeAttr('disabled');
                    var csvParser = new SimpleExcel.Parser.CSV();
                    csvParser.setDelimiter(',');
                    csvParser.loadFile(f, function () {

                        // draw HTML table based on sheet data
                        var sheet = csvParser.getSheet();
                        var table = document.getElementById('bulkUploadList');
                        table.innerHTML = "";
                        sheet.forEach(function (el, i) {                    
                            var row = document.createElement('tr');
                            el.forEach(function (el, i) {
                                var cell = document.createElement('td');
                                cell.innerHTML = el.value;
                                row.appendChild(cell);
                            });
                            table.appendChild(row);
                        });  
                        var rowCount = table.rows.length; 
                        $("#selectOption > select:not(:first)").remove();
                         $("#bulkUploadList tr:nth-child(1) td").addClass("headerdata");
                         $("#bulkUploadDataMappingTab .spinner").hide();
                        Maptician.BulkUpload.gotData=true;
                        Maptician.BulkUpload.dynamicSelect();
                        Maptician.BulkUpload.dynamicHeader();
                        table.deleteRow(rowCount);                 
                    });
                    } else {
                        swal({
                            title: "Bulk Upload Error",
                            text: "This browser does not support HTML5",
                            type: "error",
                        });
                    }     
                }
                else{
                    swal({
                        title: "Bulk Upload Error",
                        text: "Please select a .xlsx, .xls or .csv file",
                        type: "error",
                    });
                    document.getElementById("xlf").value = "";
                    $('#bulkUploadStep1Btn').attr('disabled', 'disabled');
                    $('#bulkUploadFormWrapper').trigger("reset");
                }
                
            };
        })();
        var drop = document.getElementById('drop');
        if(!drop.addEventListener) return;
        function handleDrop(e) {
            e.stopPropagation();
            e.preventDefault();
            do_file(e.dataTransfer.files);
            var file = e.dataTransfer.files[0];
             if(Maptician.BulkUpload.fileType=="xlsx" || Maptician.BulkUpload.fileType=="xls" ||Maptician.BulkUpload.fileType=="csv"){
                e.target.innerHTML=file.name;
                var input=document.getElementById("xlf");
                input.value = '';
                if(!/safari/i.test(navigator.userAgent)){
                  input.type = ''
                  input.type = 'file'
                }
           }
        }
        function handleDragover(e) {
            e.stopPropagation();
            e.preventDefault();
            e.dataTransfer.dropEffect = 'copy';
        }
        drop.addEventListener('dragenter', handleDragover, false);
        drop.addEventListener('dragover', handleDragover, false);
        drop.addEventListener('drop', handleDrop, false);
        var xlf = document.getElementById('xlf');
        if(!xlf.addEventListener) return;
        function handleFile(e) { 
            do_file(e.target.files);
            $('#drop').text("Drag & Drop file here");
        }
        xlf.addEventListener('change', handleFile, false);
        $("#bulkUploadStep1Btn").on("click",function(){
            $("#BulkUploadOptionModal #bulkUploadFileSelectionTab").hide();
            $("#BulkUploadOptionModal #bulkUploadDataMappingTab").show();
            $("#duplicateMsg").html("");
            Maptician.BulkUpload.dataMaping();
        })
        $("#bulkUploadGoBackBtn").off().on("click",function(){
            $("#BulkUploadOptionModal #bulkUploadFileSelectionTab,#bulkUploadDataMappingTab .spinner").show();
            $("#BulkUploadOptionModal #bulkUploadDataMappingTab,#bulkUploadDataMappingTab .spinner").hide();
            //$("#bulkUploadList tr:nth-child(2)").remove();
            $("#columnErrorMsg").removeClass("errorMsg");
        })
    }
    
        
}

//This function dynamicaly creates the select box based on the  number of columns of the excel/csv  
//Select box are created to map the user defined column to the system defined columns.
Maptician.BulkUpload.dynamicSelect=function(){
    if(Maptician.BulkUpload.gotData){
        //$("#bulkUploadList tr:nth-child(1) > td").addClass("headerdata");
        //var length=0;
        var selectBox="";
        var length=$("#bulkUploadList tr:nth-child(1) > td").length;
        var selectBox=$("#bulkUploadMappingForm > tbody > tr:nth-child(1) > td #selectOption").html();
        for(var i=1;i<length;i++){
            $("#bulkUploadMappingForm > tbody > tr:nth-child(1) > td .fl_wrap #selectOption").append(selectBox);
        }
    }
}
Maptician.BulkUpload.dynamicHeader=function(){
    Maptician.BulkUpload.headerChecked = $('input[name="headerCheck"]').is(':checked');
    var customeHeader=$("#bulkUploadList tr:nth-child(1)").html();
    $("#bulkUploadList").prepend("<tr>"+customeHeader+"</tr>");
    $("#bulkUploadList tr:nth-child(2) td").removeClass("headerdata");
    if(Maptician.BulkUpload.headerChecked){
        $("#bulkUploadList tr:nth-child(2) td").addClass("cointainsHeader");
    }
}
//remove all html element on close of popup
Maptician.BulkUpload.closeBulkOpertion=function(){
    $.modal.close();
    $("#successNo,#failedNo,#bulkUploadList,#errorLogModalTable").html("");
    $("#BulkUploadOptionModal #bulkUploadFileSelectionTab,p.successMsg, p.errorMsg, #errorLogModalTable,#bulkUploadDataMappingTab .spinner,#exportToExcelButton").show();
    $("#BulkUploadOptionModal #bulkUploadDataMappingTab,#bulkUploadErrorLogModal").hide();
    $("#selectOption > select:not(:first),#selectOption > select option:not(:first)").remove();
    $("div.successDiv").css("display", "none");
    $("#columnErrorMsg").removeClass("errorMsg");
    $('input[name=uploadType][value="bulkAdd"],#isContainsHeader').prop('checked', 'true');
    $('#drop').html("Drag & Drop file here");
    $('#bulkUploadStep1Btn').attr('disabled', 'disabled');
    $('#bulkUploadFormWrapper').trigger("reset");
    Maptician.BulkUpload.hasInit=true;
    Maptician.PageTables.UserMgmtList.ajax.reload();
}



//this function map the key with value pair 
Maptician.BulkUpload.dataMaping=function(){
    var typeOfUpload=$('input[name=uploadType]:checked').val();
    $("#bulkUploadBtn").off().on("click",function(){
        Maptician.BulkUpload.sendDataToSave(typeOfUpload,Maptician.BulkUpload.headerChecked);
    })
    
}
//this function validate duplicate key
Maptician.BulkUpload.validateDuplicateKey = function (headers,arr){
    var found = false;
    var message = null;
    for(var i=0;i <headers.length;i++){
        var value = $(headers[i]).html();
        if(value!=""){
            for(var j=0;j<arr.length;j++){
                if(value == arr[j]){
                    found = true;
                    break;
                }
            }
            if(found){
                message = value + " cannot be mapped to multiple columns";
                break;
            }else{
                arr.push(value);
            }
        }
    }
    if(arr.length == 0){
        message = "Please map the columns to proceed";
    }
    return message;
}

//this function validate cotains key
Maptician.BulkUpload.containsAll=function (needles, haystack){ 
  for(var i = 0 , len = needles.length; i < len; i++){
     if($.inArray(needles[i], haystack) == -1) return false;
  }
  return true;
}

//This function validate all the required fields are mapped by User in step 2. 
//Error is thrown if the required field is not mapped.
Maptician.BulkUpload.validateRequiredKey = function (headers,arr,typeOfUpload){
    var requiredmessage = null;
    if(typeOfUpload == "bulkUpdate"){
        var requiredHeader = ["EmployeeID"];
        if(!Maptician.BulkUpload.containsAll(requiredHeader,arr)){
             requiredmessage="Please map the columns which needs to be updated with respect to the Employee ID";
        }
    }
    else{
        var requiredHeader = ["Email","First","UserType","UserStatus","EmployeeID"];
        if(!Maptician.BulkUpload.containsAll(requiredHeader,arr)){
             requiredmessage="Please map Email ID, First Name, Employee ID, User Type and User Status to proceed";
            //var current = [1, 2, 3, 4],
                //prev = [1, 2, 4],
            /* var missing = null;

            var i = 0,lenC = requiredHeader.length;

            for ( ; i < lenC; i++ ) {
                if ( arr.indexOf(requiredHeader[i]) == -1 ) missing = requiredHeader[i]; // Current[i] isn't in prev
            }

            alert(missing);*/
        }
    }
    return requiredmessage;
}

//This function prepare the key value of json data.Keys are the select option what user has selected in the modal w.r.t to the columns 
// Once the json data is prepared , it is submitted to the rest api and success and error view is created based on te response from the server.
Maptician.BulkUpload.sendDataToSave=function(typeOfUpload,headerChecked){
    var headerValue=[];
    var keyLength=$("#bulkUploadList tr:nth-child(1) > td").length;
    for(var i=0;i<keyLength;i++){
            var valueOfSelect=document.getElementsByClassName("bulkUploadMapingSelect")[i].value;
            headerValue.push(valueOfSelect);
            var str=document.getElementsByClassName("headerdata")[i].innerHTML;
            var res = str.replace(str, valueOfSelect);
            document.getElementsByClassName("headerdata")[i].innerHTML = res;
        }
    var myRows = [];
    var $headers = $("#bulkUploadList tr:nth-child(1) > td.headerdata");
    var arr = [];
    var msg = '';
    msg=Maptician.BulkUpload.validateDuplicateKey($headers,arr);
    var newmsg=Maptician.BulkUpload.validateRequiredKey($headers,arr,typeOfUpload);
    if(msg!=null){
        $( "#columnErrorMsg").addClass("errorMsg");
        $("#duplicateMsg").html(msg);
        return false;
    }
    if(newmsg!=null){
        $( "#columnErrorMsg").addClass("errorMsg");
        $("#duplicateMsg").html(newmsg);
        return false;
    }
    
    var $rows = $("#bulkUploadList tr").each(function(index) {
      $cells = $(this).find("td");
      myRows[index] = {};
      $cells.each(function(cellIndex) {
        if($($headers[cellIndex]).html()!=""){
            myRows[index][$($headers[cellIndex]).html()] = $(this).html();
        }
      });    
    });
    myRows.shift();
   
    if(headerChecked){
        myRows.shift();
    }
    var myjson = JSON.stringify(myRows);
    var data ={
        data : myjson
    }
    var url = typeOfUpload == "bulkUpdate"? "/api/employees/bulk/updateBulkUser": "/api/employees/bulk/addBulkUser";
    //$("#spinner").show();
   // $("#bulkUploadDataMappingTab .spinner").show();//spinner will show while loading the data from the server
    jQuery.ajax({type:"POST",url:url,data:data,
    success:function(result){
        $("#bulkUploadDataMappingTab .spinner").hide();
        $("#BulkUploadOptionModal #bulkUploadDataMappingTab").hide();
        $("#bulkUploadErrorLogModal").show();
        if(result.failed == 0){
            $("p.successMsg, p.errorMsg, #errorLogModalTable,#exportToExcelButton").hide();
            $("#allSuccessNo").html(result.success);
            if(typeOfUpload == "bulkUpdate"){
                $("div.successDiv").css("display", "block");
                $("div.successDiv #operationType").html(" user(s) successfully updated");
            }else{
                $("div.successDiv").css("display", "block");
                $("div.successDiv #operationType").html(" user(s) successfully added");
            }
            
            Maptician.BulkUpload.hasInit = true; 
        }else{
        $("#successNo").html(result.success);
        $("#failedNo").html(result.failed);
        
        var col = [];
        var lastCol=[];
        for (var b = 0; b < result.error.length; b++) {
            for (var key in result.error[b]) {
                if (col.indexOf(key) === -1) {
                    col.push(key);
                }
            }
        }
        // CREATE DYNAMIC TABLE.
        var table = document.createElement("table");
         var errorlogObj=[];
        // CREATE HTML TABLE HEADER ROW USING THE EXTRACTED HEADERS ABOVE.
               // TABLE ROW.
        var tr = table.insertRow(-1);                   // TABLE ROW.

        for (var i = 0; i < col.length; i++) {
            var th = document.createElement("th");      // TABLE HEADER.
            th.innerHTML = col[i];
            tr.appendChild(th);
        }

        // ADD JSON DATA TO THE TABLE AS ROWS.
        for (var a = 0; a < result.error.length; a++) {

            tr = table.insertRow(-1);

            for (var j = 0; j < col.length-1; j++) {
                var tabCell = tr.insertCell(-1);
                tabCell.innerHTML = result.error[a][col[j]];
            }
            for (var k = col.length-1; k < col.length; k++) {
                var tabCell = tr.insertCell(-1);
                tabCell.innerHTML='';
               
                for(var l=0;l<result.error[a].errorObj.length;l++){
                    //tr = table.insertRow(-1);
                    var valueInList = "<li>" + result.error[a].errorObj[l].errorMsg + "</li>";
                    tabCell.innerHTML+=valueInList;
                }

                
            }
        }

        // FINALLY ADD THE NEWLY CREATED TABLE WITH JSON DATA TO A CONTAINER.
        var divContainer = document.getElementById("errorLogModalTable");
        divContainer.innerHTML = "";
        divContainer.appendChild(table);
        $("#errorLogModalTable > table > tbody > tr:nth-child(1) > th:nth-child(1)").html("Record Number");
        $("#errorLogModalTable > table > tbody > tr:nth-child(1) > th:nth-child(2)").html("Employee ID");
        $("#errorLogModalTable > table > tbody > tr:nth-child(1) > th:nth-child(3)").html("Error Message(s)");
       /* TableExport($("#errorLogModalTable"), {
                     headings: true,                               // (Boolean), display table headers (th or td elements) in the <thead>, (default: true)
                    footers: true,                              // (Boolean), display table footers (th or td elements) in the <tfoot>, (default: false)
                    formats: ['xlsx'],             // (String[]), filetype(s) for the export, (default: ['xls', 'csv', 'txt'])
                    filename: 'id',                             // (id, String), filename for the downloaded file, (default: 'id')
                    bootstrap: true,                           // (Boolean), style buttons using bootstrap, (default: true)                        // (Boolean), automatically generate the built-in export buttons for each of the specified formats (default: true)
                    position: 'bottom',                         // (top, bottom), position of the caption element relative to table, (default: 'bottom')
                    ignoreRows: null,                           // (Number, Number[]), row indices to exclude from the exported file(s) (default: null)
                    ignoreCols: null,                           // (Number, Number[]), column indices to exclude from the exported file(s) (default: null)
                    trimWhitespace: true                        // (Boolean), remove all leading/trailing newlines, spaces, and tabs from cell text in the exported file(s) (default: false)
                });*/
        $("#exportToExcelButton").on("click",function(){
            function s2ab(s) {
                if(typeof ArrayBuffer !== 'undefined') {
                    var buf = new ArrayBuffer(s.length);
                    var view = new Uint8Array(buf);
                    for (var i=0; i!=s.length; ++i) view[i] = s.charCodeAt(i) & 0xFF;
                    return buf;
                } else {
                    var buf = new Array(s.length);
                    for (var i=0; i!=s.length; ++i) buf[i] = s.charCodeAt(i) & 0xFF;
                    return buf;
                }
            }
            function export_table_to_excel(id, type) {
                var wb = XLSX.utils.table_to_book(document.getElementById(id), {sheet:"Sheet 1"});
                var wbout = XLSX.write(wb, {bookType:type, bookSST:true, type: 'binary'});
                var fname = 'bulkUploadErrorLogTable.' + type;
                try {
                    saveAs(new Blob([s2ab(wbout)],{type:"application/octet-stream"}), fname);
                } catch(e) { if(typeof console != 'undefined') console.log(e, wbout); }
                return wbout;
                }

                export_table_to_excel('errorLogModalTable','xlsx');
        })
  
        
        }
    },
    error: function (error) {
        $("#bulkUploadDataMappingTab .spinner").hide();
    }
    });
    $("#closeModal").on("click", function() {
        Maptician.BulkUpload.closeBulkOpertion();
    })
    
}