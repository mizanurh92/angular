$Map.components.Maintenance = function(){
	this.area = $("#maintenanceArea");
	this.tabSelectors = $("#maintenanceTabSelectors");
	this.tabs = $("#maintenanceTabSelectors").find('li');
	this.responderUrl = '../api/maintenance/request/getAllResponders';
	this.requestUrl = '../api/maintenance/request/getRequests';
	this.tableContainer = $(".maintenanceTable-container");
	this.tableElement = $("#allResponderList");
	this.reqTableElement = $("#allRequestList");
	this.tableColumns = 11;
	this.table = null;
	this.tableOffset = 110;

	this.isOpen = false;
	var Maintenance = this;
	this.open = function(){
		this.area.show();
		this.tabSelectors.show();
		this.setBindings('maintenance');
		this.tabSelect(0);
		this.isOpen = true;
	}

	this.exit = function(){
		this.unsetBindings('maintenance');		
		this.isOpen = false;
/*		this.table && this.table.clear().destroy(); // Clears datatable
		this.reqTable && this.reqTable.clear().destroy(); // Clears datatable*/
	}

	this.setBindings = function(namespace){
		this.tabs.on('click.' + namespace, function(){
			Maintenance.tabSelect($(this).index());
			console.log("bind");
		})
	}

	this.unsetBindings = function(namespace){
		this.tabs.off('.'+namespace);
		console.log("unbind");
	}
	this.tabSelect = function(index){
		this.tabs.removeClass('active');
		$(this.tabs[index]).addClass('active');
		this.area.find('.subContent').hide();
		$(this.area.find('.subContent')[index]).show();

		if(index != 0 && !this.officeSelected){
			$("#notSelected").css({display:"flex"});
		}
		switch(index){
			case 0:
				this.setReqTable();
				this.setReqEditor();
				console.log("hi");
			break;
			case 1:
				/*this.occupants = this.occupants || new $Map.components.OccupantList(this);*/
			break;
			case 2:
				/*this.rightNav.show();*/
			break;
			case 3:
				this.setEditor();
				this.setEditorSelectors();
				this.setTable();
			break;
		}
	}
	/*this.update = function(officeID){
		Maintenance.table.ajax.reload();
	}
*/
//all responder datatable starts here
	this.setTable = function(){
		this.table = this.table || this.tableElement.DataTable({
			ajax: {
				url: this.responderUrl
			},
			rowId: 'catUserMappingID',
			select: {
				style: 'single',
				className: 'selected',
				selector: 'tr:not(.selected)'
			},
			scrollY: Maintenance.tableContainer.height() - this.tableOffset,
			deferRender:true,
			scroller:true,
			paging:true,
			autoWidth:true,
			targets:0,
			columns:[	
				{
					width: 10,
					title: "No",
					data: {},
					class: 'centerAlign',
					 render: function (data, type, row, meta) {
				        return meta.row + meta.settings._iDisplayStart + 1;
				    }
				},			
				{
					width: 75,
					title: "Name",
					data: {},
					class: 'centerAlign',
					render: function(user){
						return user.userName;
					}
				},
				{
					width: 30,
					title: "Category",
					data: {},
					class: 'centerAlign',
					render: function(user){
						if(user.categoryName){
							return user.categoryName;
						} else {
							return "";
						}
					}
				},
				{
					width: 30,
					title: "Office",
					data: {},
					class: 'centerAlign',
					render: function(user){
						console.log(user);
						if(user.office){
							return user.office.name;
						} else {
							return "";
						}  
					}
				}
			],
			dom: '<".standardTableFilterDiv" and f><".standardTableButtonDiv" and B>rt',
			buttons: [
				{extend:"create",editor:Maintenance.editor},
				{extend:"edit",editor:Maintenance.editor},
				{extend:"remove",editor:Maintenance.editor},
			],
			autoFill: {
				columns: ':first-child',
	            editor:  "editor"
	        },
			initComplete: function(){
				//report.table.scroller.measure();
			}
		})
	}
	this.setEditor = function(){
		this.editor = new $.fn.dataTable.Editor({
			ajax:{
				create:{
					type:'POST',
					url: '../api/maintenance/request/saveCatUserMapping'
				},
				remove:{
					type:'DELETE',
					url: '../api/maintenance/request/deleteCatUserMapping'
				},
				edit:{
					type:'PUT',
					url: '../api/maintenance/request/editCatUserMapping'
				},
			},
			table: this.tableElement[0],
			idSrc: 'catUserMappingID',
			fields:[
				{
					label:"Name",
					name:"user",
					type: "select",
					/*multiple: true*/
				},
				{
					label:"Category",
					name:"category",
					type: "select",
					options: [
					]
				},
				{
					label:"Office",
					name:"office",
					type: "select",
					options: []
				}
			]
		});
	}
	this.setEditorSelectors = function(){
		$.ajax({
			type:"GET",
			url: "/api/maintenance/request/selectList/",
			success: function(result){
				Maintenance.editor.field('user').update(result.users);
				Maintenance.editor.field('category').update(result.categories);
				Maintenance.editor.field('office').update(result.offices);
			}, // End of Success callback
			error: function(error){
				console.log('error loading departments');
			}
		})
	}
	// all responders table ends here

	this.timeConverter = function(UNIX_timestamp){
	  var a = new Date(UNIX_timestamp * 1000);
	  var months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
	  var year = a.getFullYear();
	  var month = months[a.getMonth()];
	  var date = a.getDate();
	  var hour = a.getHours();
	  var min = a.getMinutes();
	  var sec = a.getSeconds();
	  var time = date + ' ' + month + ' ' + year + ' ' + hour + ':' + min + ':' + sec ;
	  return time;
	}
	// all request table starts here
	this.setReqTable = function(){
		this.reqTable = this.reqTable || this.reqTableElement.DataTable({
			ajax: {
				url: this.requestUrl
			},
			rowId: 'requestID',
			select: {
				style: 'single',
				className: 'selected',
				selector: 'tr:not(.selected)'
			},
			scrollY: Maintenance.tableContainer.height() - this.tableOffset,
			deferRender:true,
			scroller:true,
			paging:true,
			autoWidth:true,
			targets:0,
			columns:[	
				{
					width: 3,
					title: "No",
					data: {},
					class: 'centerAlign',
					 render: function (data, type, row, meta) {
				        return meta.row + meta.settings._iDisplayStart + 1;
				    }
				},			
				{
					width: 30,
					title: "Description",
					data: {},
					class: 'leftAlign',
					render: function(data){
						console.log(data)
						return data.description;
					}
				},
				{
					width: 30,
					title: "Requester Name",
					data: {},
					class: 'leftAlign',
					render: function(data){
						if(data.userName){
							return data.userName
						} else {
							return "";
						}
					}
				},
				{
					width: 20,
					title: "Service For",
					data: {},
					class: 'leftAlign',
					render: function(data){
						if(data.name){
							return data.name
						} else {
							return "";
						}
					}
				},
				{
					width: 20,
					title: "Office",
					data: {},
					class: 'leftAlign',
					render: function(data){
						if(data.officeName){
							return data.officeName;
						} else {
							return "";
						}  
					}
				},
				{
					width: 15,
					title: "Created Date",
					data: {},
					class: 'leftAlign',
					render: function(data){
						if(data.createdDate){
							return  Maintenance.timeConverter(data.createdDate);
						} else {
							return "";
						}  
					}
				},
				{
					width: 10,
					title: "Priority",
					data: {},
					class: 'leftAlign',
					render: function(data){
						if(data.severity){
							return data.severity;
						} else {
							return "";
						}  
					}
				},
				{
					width: 15,
					title: "Category",
					data: {},
					class: 'leftAlign',
					render: function(data){
						if(data.categoryName){
							return data.categoryName;
						} else {
							return "";
						}  
					}
				},
				{
					width: 20,
					title: "Status",
					data: {},
					class: 'leftAlign',
					render: function(data){
						if(data.status){
							return data.status;
						} else {
							return "";
						}  
					}
				},
				{
					width: 25,
					title: "Responder",
					data: {},
					class: 'leftAlign',
					render: function(data,t,r){
						if(data.responders){
							 if(data.status == "Open"){
	                        	var responderNames=[];
								for(var i=0; i< data.responders.length; i++){
									responderNames.push(data.responders[i].userName)
								}
				                var $select = $("<select></select>");
			                	$.each(responderNames, function(k,v){
			                    	var $option = $("<option></option>", {
			                        	"text": v,
			                            "value": v
			                        });
			                        if(responderNames == v){
			                        	$option.attr("selected", "selected");
			                        }
			                    	$select.append($option);
			                    });
			                    return $select.prop("outerHTML");
		                    }
		                    if(data.status == "InProgress") {
		                    	Maintenance.responderPerCat=data.responders;
	                    		return data.assignedUsername;
		                    }
							
						} else {
							return "";
						}  
					}
				},
				{
					width: 125,
					title: "Action",
					data: {},
					class: 'centerAlign',
					render: function(data){
	                    var acceptButton = '<div class="btn acceptButton" title="Accept">Accept</div>';
	                    var assignButton = '<div class="btn assignButton" title="Assign">Assign</div>';
	                    var replyButton = '<div class="btn replyButton" title="Reply">Reply</div>';
	                    var closeButton = '<div class="btn closeButton" title="Close">Close</div>';
	                    var assignToOtherButton = '<div class="btn assignToOtherButton" title="assignToOtherButton">Assign Others</div>';
	                    if(data.status == "Open"){
	                        return replyButton + assignButton + acceptButton;
	                    }
	                    if(data.status == "InProgress") {
	                    		return replyButton + closeButton + assignToOtherButton;
	                    }
	                    else {
	                        return "";
	                    }
	                }
				}
			],
			dom: 'rt',
			initComplete: function(){
				//report.table.scroller.measure();
			}
		})
	}
	this.setReqEditor = function(){
		var requesttable=$("#allRequestList tbody");
		// Accept button functionality 
		requesttable.on('click','.acceptButton',function(){
        	var data = Maintenance.reqTable.row( $(this).closest('tr') ).data();
        	var acceptdata={data:data.requestID};
          	$.ajax({
                    type: "POST",
                    url: "api/maintenance/request/acceptMaintenanceRequest",
                    data: acceptdata
                })
          		.then(function(result){
                   if(result){
                        swal({
                            title: 'Request sucessfully accepted',
                            text: 'This request has been sucessfully accepted by you.',
                            showConfirmButton: true,
                            type: 'success',
                            timer: 10000,
                            confirmButtonText: 'OK',
                        })
                        Maintenance.reqTable.ajax.reload();
                    } else {
                        swal({
                            title: 'Sorry!',
                            text: 'Something went wrong while sending your message.  Please try again later.',
                            timer: 10000,
                            showConfirmButton: true,
                            type: 'error'
                        })                      
                    }
                })
        })
        //Assign button functionality
        requesttable.on('click','.assignButton',function(){
        	var data=Maintenance.reqTable.row( $(this).closest('tr') ).data();
        	var assignData={};
        	assignData.requestID = data.requestID;
        	var ins = $(this).closest('tr').find("select").map(function() {

		        return $(this).find(":selected").text() // get selected text

		    }).get()
        	var allResponder=data.responders;
        	for(var j=0;j<allResponder.length;j++){
        		if(allResponder[j].userName==ins[0]){
        			assignData.userID = allResponder[j].userID;
        			assignData.userName = allResponder[j].userName;
        		}
        	}
			var finalData={data:assignData};
          	$.ajax({
                    type: "POST",
                    url: "api/maintenance/request/assignToOtherUser",
                    data: finalData
                })
          		.then(function(result){
                   if(result){
                        swal({
                            title: 'Request sucessfully accepted',
                            text: 'This request has been sucessfully assigned.',
                            showConfirmButton: true,
                            type: 'success',
                            timer: 10000,
                            confirmButtonText: 'OK',
                        })
                        Maintenance.reqTable.ajax.reload();
                    } else {
                        swal({
                            title: 'Sorry!',
                            text: 'Something went wrong while sending your message.  Please try again later.',
                            timer: 10000,
                            showConfirmButton: true,
                            type: 'error'
                        })                      
                    }
                })
        })
        //Reply button functionality
        requesttable.on('click','.replyButton',function(){
        	var data = Maintenance.reqTable.row( $(this).closest('tr') ).data();
        	var replyData={};
        	replyData.requestID=data.requestID;
          	$('#replyRequestModal').modal({
                  clickClose: false
              });
          	$("#replyRequestModal").validate({
	            rules: {
	                replyText: {
	                    required: true,
	                    maxlength: 200,
	                    minlength:2
	                }
	            },
	            messages: { 
	              description: {
	                required:"Description field is required",
	                validLength: "Please enter upto 100 chars"
	                }           
	            },
	            submitHandler:function(form,event){
	                replyData.comment=$("#replyText").val();
	                var data={data:replyData};
	                $.ajax({
	                    type: "POST",
	                    url: "api/maintenance/request/replybyUser",
	                    data: data
	                })
	                .then(function(result){
	                   if(result){
	                        swal({
	                            title: 'Success',
	                            text: 'Your request has been submitted sucessfully',
	                            showConfirmButton: true,
	                            type: 'success',
	                            timer: 10000,
	                            confirmButtonText: 'OK',
	                        })
	                        Maptician.inits.closeReqPopUp("replyRequestModal");
	                    } else {
	                        swal({
	                            title: 'Sorry!',
	                            text: 'Something went wrong while sending your message.  Please try again later.',
	                            timer: 10000,
	                            showConfirmButton: true,
	                            type: 'error'
	                        })                      
	                    }
	                })
	                .catch(function(err){
	                    $.modal.close();
	                    swal({
	                        title: 'Sorry!',
	                        text: 'Something went wrong while sending your message.  Please try again later.',
	                        timer: 10000,
	                        showConfirmButton: true,
	                        type: 'error'
	                    })
	                })

	                //$.modal.close();
	            }
	        })
	        $("#cancelRplyBtn,.close-modal").on("click",function(){
	        	Maptician.inits.closeReqPopUp("replyRequestModal");
	        })
        })
        //Assign to Others functionality
        requesttable.on('click','.assignToOtherButton',function(){
        	var data = Maintenance.reqTable.row( $(this).closest('tr') ).data();
        	var assignData={};
        	assignData.requestID=data.requestID;
          	$('#assignToOtherModal').modal({
                  clickClose: false
              });
          	var selector=document.getElementById("assignTo");
          	selector.options.length = 0;
          	Maintenance.responderPerCat.forEach(function(item){
			   var option = document.createElement('option');
			   option.value = item.userName;
			   option.innerHTML = item.userName;
			   selector.appendChild(option);
			})
          	$("#assignToOtherModal").validate({
	            rules: {
	            	assignTo: {
	                    required: true
	                },
	                assignToOthersText: {
	                    required: true,
	                    maxlength: 200,
	                    minlength:2
	                }
	            },
	            messages: { 
	            	assignTo: {
	                required:"Please select"
	                },
	              assignToOthersText: {
	                required:"Description field is required",
	                validLength: "Please enter upto 100 chars"
	                }           
	            },
	            submitHandler:function(form,event){
	                assignData.comment=$("#assignToOthersText").val();
	                var assignUserName=$("#assignTo").val();
		        	for(var a=0;a<Maintenance.responderPerCat.length;a++){
		        		if(Maintenance.responderPerCat[a].userName==assignUserName){
		        			assignData.userID = Maintenance.responderPerCat[a].userID;
		        			assignData.userName = Maintenance.responderPerCat[a].userName;
		        		}
		        	}
	                var data={data:assignData};
	             $.ajax({
                    type: "POST",
                    url: "api/maintenance/request/assignToOtherUser",
                    data: data
	                })
	          		.then(function(result){
                   if(result){
                        swal({
                            title: 'Request sucessfully accepted',
                            text: 'This request has been sucessfully accepted by you.',
                            showConfirmButton: true,
                            type: 'success',
                            timer: 10000,
                            confirmButtonText: 'OK',
                        })
                        Maintenance.reqTable.ajax.reload();
                        Maptician.inits.closeReqPopUp("assignToOtherModal");
                    } else {
                        swal({
                            title: 'Sorry!',
                            text: 'Something went wrong while sending your message.  Please try again later.',
                            timer: 10000,
                            showConfirmButton: true,
                            type: 'error'
                        })                      
                    }
                })
	            }
	        })
	        $("#cancelassignBtn,.close-modal").on("click",function(){
	        	Maptician.inits.closeReqPopUp("assignToOtherModal");
	        })
        })
        //Close button functionality
        requesttable.on('click','.closeButton',function(){
        	var data = Maintenance.reqTable.row( $(this).closest('tr') ).data();
        	var replyData={};
        	replyData.requestID=data.requestID;
          	$('#closeRequestModal').modal({
                  clickClose: false
              });
          	$("#closeRequestModal").validate({
	            rules: {
	                closeText: {
	                    required: true,
	                    maxlength: 200,
	                    minlength:2
	                }
	            },
	            messages: { 
	              closeText: {
	                required:"Description field is required",
	                validLength: "Please enter upto 100 chars"
	                }           
	            },
	            submitHandler:function(form,event){
	                replyData.comment=$("#closeText").val();
	                var data={data:replyData};
	                $.ajax({
	                    type: "POST",
	                    url: "api/maintenance/request/closeRequest",
	                    data: data
	                })
	                .then(function(result){
	                   if(result){
	                        swal({
	                            title: 'Success',
	                            text: 'closed sucessfully',
	                            showConfirmButton: true,
	                            type: 'success',
	                            timer: 10000,
	                            confirmButtonText: 'OK',
	                        })
	                        Maintenance.reqTable.ajax.reload();
	                        Maptician.inits.closeReqPopUp("closeRequestModal");
	                    } else {
	                        swal({
	                            title: 'Sorry!',
	                            text: 'Something went wrong while sending your message.  Please try again later.',
	                            timer: 10000,
	                            showConfirmButton: true,
	                            type: 'error'
	                        })                      
	                    }
	                })
	                .catch(function(err){
	                    $.modal.close();
	                    swal({
	                        title: 'Sorry!',
	                        text: 'Something went wrong while sending your message.  Please try again later.',
	                        timer: 10000,
	                        showConfirmButton: true,
	                        type: 'error'
	                    })
	                })
	            }
	        })
	        $("#cancelcloseBtn,.close-modal").on("click",function(){
	        	Maptician.inits.closeReqPopUp("closeRequestModal");
	        })
        })
	}
}
$Map.components.Maintenance.prototype.constructor = $Map.components.Maintenance;
