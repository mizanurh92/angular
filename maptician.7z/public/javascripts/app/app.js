$(document).ready(function(){
	
	// This function causes the application to refresh the current page if an ajax error returns status 498
	// This error means that the security token isn't present or expired.  On reload, the user will be taken to the
	// landing page.
	$(document).ajaxError(function( event, jqxhr, settings, thrownError ) {
		if(jqxhr.status == 498){
			console.log('Credentials not found or expired, reloading page');
			location.reload();
		}
	});

	// This controls how DataTables displays errors
	$.fn.dataTable.ext.errMode = 'alert'; // Should be set to 'none' in production mode

	$Map.Nav = new $Map.Components.Nav.NavController();

	$Map.inits.setValidators(); // Sets custom validators for forms
	$Map.inits.setFlowUpLabels(); // Repositions labels on text input fields
	$Map.inits.setSelectorDividers(); // Allows min/max on table forms

}) // End of on load



Maptician = {};
$Map = Maptician;
$Map.components = {};



// Returns the controller for the map currently being shown
$Map.controller = function(){
	if($Map.Editor && $Map.Editor.isSet() && $Map.Editor.isDrawn()){
		return $Map.Editor;
	} else if ($Map.Viewer && $Map.Viewer.isSet() && $Map.Viewer.isDrawn()){
		return $Map.Viewer;
	} else {
		return null;
	}
}

// Returns the currently shown map instance, whether from the editor or viewer
$Map.current = function(){
	if($Map.Editor && $Map.Editor.isSet() && $Map.Editor.isDrawn()){
		return $Map.Editor.currentFile;
	} else if ($Map.Viewer && $Map.Viewer.isSet() && $Map.Viewer.isDrawn()){
		return $Map.Viewer.currentFile;
	} else {
		return null;
	}
}

$Map.unit = function(system){
	this.units = system ? system : this.units;
	return this.units;
}