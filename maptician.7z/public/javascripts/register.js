
var current_fs, next_fs, previous_fs; //fieldsets
var left, opacity, scale; //fieldset properties which we will animate
var animating; //flag to prevent quick multi-click glitches


$(document).ready(function(){

	$('.FlowupLabels').FlowupLabels({
		class_focused:"focused-narrow",
		class_populated:"populated-narrow"
	});

	// Creates a mask for the cell phone input.  The question mark allows an invalid or partial number to be entered
	// without the whole input being thrown out
	$("#phone").mask("?(999) 999-9999");
	$("#zip").mask("99999?-9999");

	var Validator = $("form.msform").validate({
		onkeyup: false,
		normalizer: function(value){ // Trims entered values for normalization
			return $.trim(value);
		},
		rules: {
			company: {
				required: true,
				remote: {
					url: '/checkCompany',
					type: "post"
				},
				rangelength: [3, 50]
			},
			website: {
				required: true,
				website: true,
				maxlength: 50,
				rangelength: [8, 50]
			},
			address1:{
				required: true,
				maxlength: 95
			},
			address2:{
				maxlength: 95
			},
			city:{
				required: true,
				rangelength: [2, 50]
			},
			state:{
				required: true,
				rangelength: [2, 15]
			},
			zip:{
				required: true,
				rangelength: [5, 10]
			},
			country:{
				required: true,
				rangelength: [2, 50]
			},
			first:{
				required: true,
				minlength: 2,
				maxlength: 30,
				fullName: true
			},
			last:{
				required: true,
				minlength: 2,
				maxlength: 30,
				fullName: true
			},
			phone:{
				required: true
			},
			email:{
				required: true,
				email: true
			},
			password: {
				required: true,
				password: true,
			},
			cpassword:{
				required: true,
				password: true,
				sameAsPass: true
			}
		},
		messages: {
			company:{
				required: "Please enter your company name",
				remote: "Company name already exists, please choose another."
			},
			website:{
				website: "Invalid website format. e.g. www.domain.com",
				required: "Please enter your website",
			},
			email:{
				email: "Please enter a valid email address",
				required: "Please enter an email address"
			},
			password:{
				required: "Please enter a password",
				password: "Invalid password"
			},
			cpassword:{
				required: "Please enter a password",
				password: "Invalid password",
				sameAsPass: "Passwords do not match"				
			},
			address1:{
				required: "Please enter your street address"
			},
			city:{
				required: "Please enter your city"
			},
			state:{
				required: "Please enter your state"
			},
			zip:{
				required: "Please enter your zip code"
			},
			country:{
				required: "Please enter your country"
			}
		},
		submitHandler:function(form,event){
			var data = {
				company: $('#company').val(),
				email: $('#email').val(),
				password: $('#password').val(),
			}
			var checked = $("#rememberMe").prop('checked');
			if(checked){
				setCookies();
			} else {
				unsetCookies();
			}			
			$("#spinnerIcon").css("display","block");
			$.ajax({
				type:"POST",
				url: "/login",
				data:data,
				dataType:'json',
				success:function(data){
					console.log('success',data)
					if(data.login){
						$("#errorMsg").hide();
						window.location = "./";
					} else {
						$("#errorMsg").html(data.err).show();
						$("#spinnerIcon").hide();
					}
				}
			})
		}
	})


})

$.validator.methods.email = function( value ) {
	return /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/.test( value );
}

$.validator.methods.password = function( value ) {
	return /(?=^.{8,15}$)((?!.*\s)(?=.*[A-Z])(?=.*[a-z])(?=(.*\d){1,}))((?!.*[",;&|'])|(?=(.*\W){1,}))(?!.*[",;&|'])^.*$/.test( value );
}

$.validator.methods.website = function( value ) {
	return /^((http:\/\/www\.)|(www\.)|(http:\/\/))[a-zA-Z0-9._-]+\.[a-zA-Z.]{2,5}$/.test( value );
}

$.validator.methods.fullName = function( value ) {
  return /^[a-z ,.'-]+$/i.test( value );
}

$.validator.methods.sameAsPass = function( value ) {
  return $("#password").val() == value;
}

$(".next").click(function(){
	if(!$("fieldset input").valid()){
		return;
	}
	if(animating) return false;
	animating = true;
	
	current_fs = $(this).parent();
	next_fs = $(this).parent().next();
	
	//activate next step on progressbar using the index of next_fs
	$(".progressbar li").eq($("fieldset").index(next_fs)).addClass("active");
	
	//show the next fieldset
	next_fs.show(); 
	//hide the current fieldset with style

	current_fs.animate({opacity: 0}, {
		step: function(now, mx) {
			//as the opacity of current_fs reduces to 0 - stored in "now"
			//1. scale current_fs down to 80%
			scale = 1 - (1 - now) * 0.2;
			//2. bring next_fs from the right(50%)
			left = (now * 50)+"%";
			//3. increase opacity of next_fs to 1 as it moves in
			opacity = 1 - now;
			current_fs.css({
        'transform': 'scale('+scale+')',
        'position': 'absolute'
      });
			next_fs.css({'left': left, 'opacity': opacity});
		}, 
		duration: 500, 
		complete: function(){
			current_fs.hide();
			animating = false;
		}
	});
});

$(".previous").click(function(){
	if(animating) return false;
	animating = true;
	
	current_fs = $(this).parent();
	previous_fs = $(this).parent().prev();
	
	//de-activate current step on progressbar
	$(".progressbar li").eq($("fieldset").index(current_fs)).removeClass("active");
	
	//show the previous fieldset
	previous_fs.show(); 
	//hide the current fieldset with style

	current_fs.animate({opacity: 0}, {
		step: function(now, mx) {
			//as the opacity of current_fs reduces to 0 - stored in "now"
			//1. scale previous_fs from 80% to 100%
			scale = 0.8 + (1 - now) * 0.2;
			//2. take current_fs to the right(50%) - from 0%
			left = ((1-now) * 50)+"%";
			//3. increase opacity of previous_fs to 1 as it moves in
			opacity = 1 - now;
			current_fs.css({'left': left});
			previous_fs.css({'transform': 'scale('+scale+')', 'opacity': opacity});
		}, 
		duration: 500, 
		complete: function(){
			current_fs.hide();
			animating = false;
		}
	});
});

$('.back').click(function(){
	window.location = "/login";
})

$(".submit").click(function(){
    var data = {
    	company: $("#company").val(),
    	website: $("#website").val(),
    	address1: $("#address1").val(),
    	address2: $("#address2").val(),
    	city: $("#city").val(),
    	state: $("#state").val(),
    	zip: $("#zip").val(),
    	country: $("#country").val(),
    	first: $('#first').val(),
    	last: $('#last').val(),
    	phone: $('#phone').val(),
    	email: $('#email').val(),
    	password: $('#password').val(),
    	cpassword: $('#cpassword').val(),
    }
    $.ajax({
    	type:"POST",
    	url: "/register",
    	data:data,
    	dataType:'json',
    	success:function(data){
	        if(data.login){
				window.location = window.location.origin;
	        }
	    },
	    error:function(data){
	    	console.log(data.responseJSON.error);
	    }
	})
})

// $("#company").on("change",function(e){
// 	console.log('changed')
// 	company = $("#company").val();
// 	if(company){
// 		$.ajax({
// 			type:"POST",
// 			url: "/checkCompany",
// 			data:{company:company},
// 			dataType:'json',
// 	    	success:function(data){
// 				if(data.exists){
// 					console.log('already exists');
// 					$("#errorMsg").html("Company name already exists. Please choose another.").show();
// 				} else {
// 					console.log('is available');
// 					$("#errorMsg").hide();
// 				}
// 		    },
// 		    error:function(error){
// 		    	console.log(error);
// 		    	$("#errorMsg").html("Error checking company name. Please try again later.").show();
// 		    }
// 		})
// 	} else {
// 		$("#errorMsg").hide();
// 	}
// })