// This router api module handles requests relating to meeting/conference room reservations
// It is meant to work in conjunction with fullCalendar.js on the client side
var router = require('express').Router();
var authenticate = require('../../.././middleware/authenticate').authenticate;
var moment = require('moment');
require('moment-precise-range-plugin');

router.post('/savereservation',authenticate,function(req,res){
	if(req.user){
		var userID = req.user.userID;
		var reservation = req.body.reservation;
		var type = req.body.type;
		var collection;
		var companyNo = req.companyNo;
		var	resObject = {
				resID: reservation.resID,
				userID: reservation.userID || userID,
				userName: req.user.first + " " + req.user.last,
				title: reservation.title,
				private: reservation.private == 'true',
				start: moment(reservation.start).valueOf(),
				end: moment(reservation.end).valueOf(),
				mapID: reservation.mapID,
				officeID: reservation.officeID,
				deptID: reservation.deptID
			}

		switch(type){
			case "rooms":
				collection = req.db.get(companyNo + '-room-reservations');
				resObject.roomID = reservation.roomID;
				resObject.bulletin = reservation.bulletin == 'true';
				resObject.message = reservation.message;
				orList = { $or: [ // Used to check for conflicting reservations
						{ start: { $gte: resObject.start , $lte: resObject.end}, 
							roomID:resObject.roomID,
							resID:{$ne:resObject.resID}
						}, 
						{ end: { $gte: resObject.start , $lte: resObject.end}, 
							roomID:resObject.roomID,
							resID:{$ne:resObject.resID}
						} 
					]}			
			break;
			case "seats":
				collection = req.db.get(companyNo + '-seat-reservations');
				resObject.seatID = reservation.seatID;
				orList = { $or: [  // Used to check for conflicting reservations
						{ start: { $gte: resObject.start , $lte: resObject.end},
							seatID:resObject.seatID,
							resID:{$ne:resObject.resID}
						}, 
						{ end: { $gte: resObject.start , $lte: resObject.end},
							seatID:resObject.seatID,
							resID:{$ne:resObject.resID}
						}
					]}				
			break;
		}

		collection.find(orList)
		.then((result)=>{
			if(result.length){
				res.status(300).send({conflict:true});
			} else {
				return collection.insert(resObject);
			}
		})
		.then((result)=>{
			res.status(200).send({start:reservation.start,end:reservation.end});
			return;
		})
		.catch((err)=>{
			console.log(err);
			res.status(300).send();
			return;
		})

	} else {
		res.status(300).send({});
	}
})

router.post('/changereservation',authenticate,function(req,res){
	if(req.user){
		var userID = req.user.userID;
		var reservation = req.body.reservation;
		
		if(reservation.userID != userID){
			res.status(300).send();
			return;
		} // TODO might want to give admins the ability to change people's reservations

		var type = req.body.type;
		var collection;
		var companyNo = req.companyNo;
		var	resObject = {
				resID: reservation.resID,
				userID: reservation.userID || userID,
				userName: req.user.first + " " + req.user.last,
				title: reservation.title,
				private: reservation.private,
				bulletin: reservation.bulletin || null,
				message: reservation.message || null,
				start: moment(reservation.start).valueOf(),
				end: moment(reservation.end).valueOf(),
				mapID: reservation.mapID,
				officeID: reservation.officeID,
				deptID: reservation.deptID
			}

		var orList;

		switch(type){
			case "rooms":
				collection = req.db.get(companyNo + '-room-reservations');
				resObject.roomID = reservation.roomID;
				orList = { $or: [ // Used to check for conflicting reservations
						{ start: { $gte: resObject.start , $lte: resObject.end}, 
							roomID:resObject.roomID,
							resID:{$ne:resObject.resID}
						}, 
						{ end: { $gte: resObject.start , $lte: resObject.end}, 
							roomID:resObject.roomID,
							resID:{$ne:resObject.resID}
						} 
					]}				
			break;
			case "seats":
				collection = req.db.get(companyNo + '-seat-reservations');
				resObject.seatID = reservation.seatID;
				orList = { $or: [  // Used to check for conflicting reservations
						{ start: { $gte: resObject.start , $lte: resObject.end},
							seatID:resObject.seatID,
							resID:{$ne:resObject.resID}
						}, 
						{ end: { $gte: resObject.start , $lte: resObject.end},
							seatID:resObject.seatID,
							resID:{$ne:resObject.resID}
						}
					]}				
			break;
		}

		console.log(JSON.stringify(orList))

		collection.find(orList)
		.then((result)=>{
			console.log('or list results:',result);
			if(result.length){
				res.status(300).send({conflict:true});
			} else {
				return collection.findOneAndUpdate({resID:resObject.resID},resObject);
			}
		})
		.then((result)=>{
			res.status(200).send({start:reservation.start,end:reservation.end});
			return;
		})
		.catch((err)=>{
			console.log(err);
			res.status(300).send();
			return;
		})

	} else {
		res.status(498).send({});
	}
})

router.delete('/deleteReservation',authenticate,function(req,res){
	if(req.user){
		var userID = req.user.userID;
		var reservation = req.body.reservation;
		var type = req.body.type;
		var collection;
		var companyNo = req.companyNo;
		var resID = reservation.resID

		if(reservation.userID != userID){
			res.status(300).send();
			return;
		}

		switch(type){
			case "rooms":
				collection = req.db.get(companyNo + '-room-reservations');
			break;
			case "seats":
				collection = req.db.get(companyNo + '-seat-reservations');
			break;
		}

		collection.findOneAndDelete({resID})
		.then((result)=>{
			res.status(200).send();
			return;
		})
		.catch((err)=>{
			console.log(err);
			res.status(300).send();
			return;
		})

	} else {
		res.status(300).send({});
	}
})

router.get('/reservations',authenticate,function(req,res){
	if(req.user){
		var type = req.query.type; // Room or Seat
		var id = req.query.id; // ID of the room or seat
		var collection;
		var companyNo = req.companyNo;
		var userID = req.user.userID;
		var start = moment(req.query.start).valueOf();
		var end = moment(req.query.end).valueOf();
		var orList;

		switch(type){
			case 'rooms':
				collection = req.db.get(companyNo + '-room-reservations');
				orList = { $or: [ 
						{ start: { $gte: start , $lte: end}, roomID:id}, 
						{ end: { $gte: start , $lte: end}, roomID:id} 
					]}
			break;
			case 'seats':
				collection = req.db.get(companyNo + '-seat-reservations');
				orList = { $or: [ 
						{ start: { $gte: start , $lte: end}, seatID:id}, 
						{ end: { $gte: start , $lte: end}, seatID:id} 
					]}
			break;
		}

		collection.find(orList)
		.then((results)=>{
			var reservation, resID;
			for(var i = 0; i < results.length; i++){
				reservation = results[i];
				resID = reservation.userID;
				reservation.className = ['saved'];
				reservation.overlap = false;
				if(resID != userID){
					reservation.editable = false;
					reservation.authorized = false;
					if(reservation.private){
						reservation.rendering = "background";
						reservation.userID = null;
						reservation.userName = null;
					}
				} else {
					reservation.authorized = true;
					reservation.className.push('authorized');
				}
			}
			res.status(200).send(results);
			return;			
		})
		.catch((err)=>{
			console.log(err);
			res.status(300).send({});
		})

	} else{
		res.status(300).send({});
	}
})

// Used to populate reservation information within a map in viewer mode
router.get('/mapReservations',authenticate,(req,res)=>{
	if(req.user){
		console.log("Finding Map Reservations");
		var companyNo = req.companyNo;
		var mapID = req.query.mapID;
		var seatCollection = req.db.get(companyNo + '-seat-reservations');
		var roomCollection = req.db.get(companyNo + '-room-reservations');
		var userCollection = req.db.get(companyNo + '-users')
		var now = moment().valueOf();
		var nowBuffer = moment().add(7, 'days').valueOf(); // Finds all reservations occuring between now and the buffer period
		var userObj = {};
		var seatRes,roomRes;
		Promise.all([
			seatCollection.find({$and:[
					{ start: { $lte: nowBuffer }, mapID}, 
					{ end: { $gte: now }, mapID} 
				]},{fields:{_id:0,seatID:1,start:1,end:1,title:1,userID:1,resID:1}}),
			roomCollection.find({$and:[
					{ start: { $lte: nowBuffer }, mapID}, 
					{ end: { $gte: now }, mapID} 
				]},{fields:{_id:0,roomID:1,start:1,end:1,title:1,userID:1,resID:1}})
			])
		.then((results)=>{
			seatRes = results[0];
			roomRes = results[1];
			for(var i in seatRes){
				userObj[seatRes[i].userID] = {};
			}
			for(var i in roomRes){
				userObj[roomRes[i].userID] = {};
			}
			var userArray = [];
			for(var i in userObj){
				userArray.push({userID:i});
			}
			if(userArray.length == 0){
				return;
			}
			return userCollection.find({$or:userArray},{fields:{_id:0,password:0,tokenhash:0,companyStatus:0,userStatus:0}});
		})
		.then((userRes)=>{
			if(userRes === undefined){
				res.status(200).send();
				return;
			}
			for(var i in userRes){
				userObj[userRes[i].userID] = userRes[i];
			}
			var userID;
			for(var i in seatRes){
				userID = seatRes[i].userID;
				seatRes[i].user = userObj[userID];
			}
			for(var i in roomRes){
				userID = roomRes[i].userID;
				roomRes[i].user = userObj[userID];
			}
			res.status(200).send({roomReservations:roomRes,seatReservations:seatRes});
		})
		.catch((err)=>{
			console.log(err);
			res.status(300).send({});
		})
	} else{
		res.status(498).send({});
	}
})


module.exports = router;