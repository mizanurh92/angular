var router = require('express').Router();
var authenticate = require('../../.././middleware/authenticate').authenticate;
var utils = require('../../.././utils/utils');
var mailUtil = require('../../.././utils/mail');
var moment = require('moment');
var uuid = utils.uuid;
const Email = require('email-templates');

//Rest Api to assign users to category

router.post('/saveMaintenanceRequest',authenticate,(req,res)=>{
    console.log("Save Maintenance request");
    var maintenanceRequestData = req.body.data; // Parse the Json data coming from UI
    var companyNo = req.companyNo; 
    var mail = req.email;
    var maintenanceRequestDbcollection = req.db.get(companyNo + '-maintenance-request-log'); //Fetch the user data from db 
    var categoryUserMappingCollection = req.db.get(companyNo + '-category-user-mapping '); //Fetch the user data from db   
    var userCollection = req.db.get(companyNo + '-users'); //Fetch the user data from db
    var usersArr=[];
    var userIds,emails,userNames;
    var currentTime = moment().valueOf();
    var requestData={
        userID:req.user.userID,
        userName:maintenanceRequestData.requestedBy,
        requestID:uuid(),
        description:maintenanceRequestData.description,
        officeID:maintenanceRequestData.officeID,
        officeName:maintenanceRequestData.officeName,
        //departmentID:maintenanceRequestData.departmentID,
        mapname:maintenanceRequestData.mapname,
        mapID:maintenanceRequestData.mapID,
        name:maintenanceRequestData.name,
        createdDate:currentTime,
        modifiedDate: currentTime,
        severity:maintenanceRequestData.severity,
        categoryName:maintenanceRequestData.categoryName,
        status:"Open"
    }
    if(maintenanceRequestData.assetType){
        requestData.assetType = maintenanceRequestData.assetType
    }
    if(maintenanceRequestData.equipment){
        requestData.equipment = maintenanceRequestData.equipment
    }
    if(maintenanceRequestData.ameneties){
        requestData.ameneties = maintenanceRequestData.ameneties
    }
    console.log(requestData.officeID);
    Promise.all([
    categoryUserMappingCollection.find({ $and : [{"categoryName":requestData.categoryName},{"office.officeID":requestData.officeID}]},
           {fields:{_id:0,userID:1}})
    ])
    .then((result)=>{
        userIds = result[0];
        return userCollection.find({'userID':{$in: getRawUserIds(userIds)}},{fields:{_id:0,email:1,first:1,last:1}})
    })
    .then((result)=>{
        emails = getRawEmail(result);
        userNames =getUserNames(result);
        console.log(emails);
        maintenanceRequestDbcollection.insert(requestData)
    })
    .then((result)=>{
        sendMailToUser(mail,req.user.email,requestData.userName,'mail');
        sendMailtoResponder(mail,emails,userNames);
        res.status(200).send({success:"true"});
    })
    .catch((err)=>{
        console.log('Error in Saving records :: '+ err);
        errorMsg = "Error in saving user records";
        res.status(300).send({success:"false","error":errorMsg});
    })  
});

function getRawUserIds(userids){
    var userIdArr=[];
    for(var userid of userids){
        userIdArr.push(userid.userID);
    }
    return userIdArr;
}

function getRawEmail(emails){
    var emailIdArr=[];
    for(var email of emails){
        emailIdArr.push(email.email);
    }
    return emailIdArr;
}

function getUserNames(data){
    var userNamesArr=[];
    var toTitleCase = function(str){
        return str.replace(/\w\S*/g, function(txt){return txt.charAt(0).toUpperCase() + 
             txt.substr(1).toLowerCase();});
    }
    for(var obj of data){
        userNamesArr.push(toTitleCase(obj.first) + " "+ toTitleCase(obj.last));
    }
    return userNamesArr;
}

router.post('/acceptMaintenanceRequest',authenticate,(req,res)=>{
    console.log("Accept Maintenance request");
   // var maintenanceRequestData = ;
    var requestID = req.body.data;
    var companyNo = req.companyNo;
    var maintenanceRequestDbcollection = req.db.get(companyNo + '-maintenance-request-log'); //Fetch the user data from db
    var currentTime = moment().valueOf();
    maintenanceRequestDbcollection.findOneAndUpdate(
        {"requestID":requestID},
        {$set: {status:"InProgress",assignedUserId:req.user.userID,assignedUsername:toTitleCase(req.user.first)+" "+toTitleCase(req.user.last)
        ,modifiedDate:currentTime}}
    )
    .then((result)=>{
        res.status(200).send({data:result});
    })
    .catch((err)=>{
        console.log('Error in assigning maintance request :: '+ err);
        errorMsg = "Error in assigning maintance request";
        res.status(300).send({success:"false","error":errorMsg});
    })  
});

router.post('/assignToOtherUser',authenticate,(req,res)=>{
    console.log("Assigned Maintenance request to other");
    var maintenanceRequestData = req.body.data;
    var companyNo = req.companyNo;
    var requestID = maintenanceRequestData.requestID;
    var comment = maintenanceRequestData.comment;
    var maintenanceRequestDbcollection = req.db.get(companyNo + '-maintenance-request-log'); //Fetch the user data from db
    var userID = maintenanceRequestData.userID;
    var userName = maintenanceRequestData.userName;
    var currentTime = moment().valueOf();
    maintenanceRequestDbcollection.findOneAndUpdate(
        {"requestID":requestID},
        {$set: {status:"InProgress",assignedUserId:userID,assignedUsername:userName,modifiedDate:currentTime}},
        { $push: { comments: comment }
    })
    .then((result)=>{
        res.status(200).send({data:result});
    })
    .catch((err)=>{
        console.log('Error in assigning maintance request :: '+ err);
        errorMsg = "Error in assigning maintance request";
        res.status(300).send({success:"false","error":errorMsg});
    }) 
})

function toTitleCase(str){
    return str.replace(/\w\S*/g, function(txt){return txt.charAt(0).toUpperCase() + 
        txt.substr(1).toLowerCase();});
}
router.post('/replybyUser',authenticate,(req,res)=>{
    console.log("Reply by user");
    var maintenanceRequestData = req.body.data;
    var requestID = maintenanceRequestData.requestID;
    var companyNo = req.companyNo;
    var comment = maintenanceRequestData.comment;
    var maintenanceRequestDbcollection = req.db.get(companyNo + '-maintenance-request-log'); //Fetch the user data from db
    var userCollection = req.db.get(companyNo + '-users'); //Fetch the user data from db
    var currentTime = moment().valueOf();
    var userEmail,userName;
    var mail = req.email;
    
    maintenanceRequestDbcollection.find({requestID})
    .then((result)=>{
        maintenanceRecord = result;
        return userCollection.find({"userID":maintenanceRecord[0].userId})
    })
    .then((userResult)=>{
        userEmail = userResult[0].email;
        userName = toTitleCase(userResult[0].first) + " "+ toTitleCase(userResult[0].last);
        return maintenanceRequestDbcollection.findOneAndUpdate(
            {"requestID":requestID},
            { $push: { comments: comment }
        })
    })
    .then((result)=>{
        sendReplyMailToUser(mail,userEmail,userName,'RequestReply',comment);
        res.status(200).send({data:result});
        
    })
    .catch((err)=>{
        console.log('Error in assigning maintance request :: '+ err);
        errorMsg = "Error in assigning maintance request";
        res.status(300).send({success:"false","error":errorMsg});
    }) 
    

})


router.post('/closeRequest',authenticate,(req,res)=>{
	if(req.user){
        var maintenanceRequestData = req.body.data;
        var requestID = maintenanceRequestData.requestID;
        var companyNo = req.companyNo;
        var comment = maintenanceRequestData.comment;
        var maintenanceRequestDbcollection = req.db.get(companyNo + '-maintenance-request-log'); //Fetch the maintenance request log data from db
        var userCollection = req.db.get(companyNo + '-users'); //Fetch the user data from db
        var currentTime = moment().valueOf();
        var userEmail,userName;
        var mail = req.email;
        maintenanceRequestDbcollection.find({requestID})
        .then((result)=>{
            maintenanceRecord = result;
            return userCollection.find({"userID":maintenanceRecord[0].userId})
        })
        .then((userResult)=>{
            userEmail = userResult[0].email;
            userName = toTitleCase(userResult[0].first) + " "+ toTitleCase(userResult[0].last);
            maintenanceRequestDbcollection.findOneAndUpdate(
                {"requestID":requestID},
                {$set: {status:"Closed"}},
                { $push: { comments: comment }
            })
        })
        .then((result)=>{
            sendReplyMailToUser(mail,userEmail,userName,'RequestReply',comment);
            res.status(200).send({data:result});
            
        })
        .catch((err)=>{
            console.log('Error in assigning maintance request :: '+ err);
            errorMsg = "Error in assigning maintance request";
            res.status(300).send({success:"false","error":errorMsg});
        }) 
    }
})

function checkOfficeIDExist(officeArr,officeID){
    for(var tempOfficeID of officeArr){
        if(tempOfficeID == officeID){
            return false;
        }
    }
    return true;
}

function checkCategoryExist(categories,categoryID){
    for(var category of categories){
        if(category == categoryID){
            return false;
        }
    }
    return true;
}

function prepareQuery(mapObjs){
    var query = "$or : ["
    for(var mapObj of mapObjs){
        query+=" { $and: [{categoryID:"+mapObj.categoryID+"}, {officeID:"+mapObj.officeID+"}] },"
    }
    query = query.replace(/,*$/, "");
    query+="]";
}

function sendMailToUser(sgMail,to,userName,renderPug){
    const email = new Email();
    
   email
     .render(renderPug, {
       name: userName
     })
     .then((html)=>{
        sgMail.send(mailUtil.createMessage(to,"Maintenance Request",html))
     })
     .catch((err)=>{
        console.log('Error in Saving records :: '+ err);
        errorMsg = "Error in saving user records";
    }) 
}

function sendReplyMailToUser(sgMail,to,userName,renderPug,comment){
    const email = new Email();
    
   email
     .render(renderPug, {
       name: userName,
       comment:comment
     })
     .then((html)=>{
        sgMail.send(mailUtil.createMessage(to,"Maintenance Request",html))
     })
     .catch((err)=>{
        console.log('Error in Saving records :: '+ err);
    }) 
}

function sendMailtoResponder(sgMail,tos,userNames){
    const email = new Email();
    for(var i=0;i< tos.length;i++) {
        var k=0;
        email
        .render('mail', {
        name: userNames[i]
        })
        .then((html)=>{

            sgMail.send(mailUtil.createMessage(tos[k],"Maintenance Request",html));
            k++;
        })
        .catch((err)=>{
            console.log('Error in Saving records :: '+ err);
        }) 
    }
}

module.exports = router;