var router = require('express').Router();
var authenticate = require('../../.././middleware/authenticate').authenticate;

//Rest Api to assign users to category

router.get('/getRequests',authenticate,function(req,res,next){
	if(req.user){
        var companyNo = req.companyNo;
        var companyID = req.user.companyID;
		var userID = req.user.userID;
		var catUserMappingObjs;
		var requestList =[];
		var mapObjs =[];
		//var data = req.query; 	
		var maintenanceRequestDbcollection = req.db.get(companyNo + '-maintenance-request-log'); //Fetch the user data from db 
        /*maintenanceRequestDbcollection.find({"userId":userID,$or: [{"status": "open"},
		{"status": "InProgress"}]})*/
		var categoryUserMappingCollection = req.db.get(companyNo + '-category-user-mapping '); //Fetch the user data from db  
        //var officeID = data.officeID;
		Promise.all([
			categoryUserMappingCollection.find({"userID":userID})
		])
        .then((results)=>{
			catUserMappingObjs = results[0];
			
			for(var mapObj of catUserMappingObjs){
			   var obj ={
				categoryName:mapObj.categoryName,
				officeID:mapObj.office.officeID
			   }
			   mapObjs.push(obj);
			}
			var arr = getOtherRespondersDbArray(req,mapObjs,categoryUserMappingCollection);
			return Promise.all(arr)
			
		})
		.then((data)=>{
			var i=0;
			for (var mapObj of mapObjs)
			{
				mapObj.responders = data[i];
				i++;
			}
			var query = {};
			if(mapObjs.length > 0){
				query = JSON.parse(prepareQuery(mapObjs));
				console.log(query);
			}else{
				res.status(200).send({data:{}});
				next();
			}
			return maintenanceRequestDbcollection.find(query)
		})
		.then((datas)=>{
			for(var data of datas){
				data.responders=getResponders(data.categoryName,mapObjs);
			}
			console.log("datas ::" + datas);
			res.status(200).send({data:datas});
		})
        .catch((err)=>{
            console.log('Unable to fetch category Mapping users:: '+ err);
            errorMsg = "Unable to fetch category Mapping users";
            res.status(300).send(errorMsg);
        })  
    }
});

function getResponders(categoryName,mapObjs){
	for(var mapObj of mapObjs){
		if(mapObj.categoryName == categoryName){
			return mapObj.responders;
		}
	}
}

function prepareQuery(mapObjs){
	var query = "{ \"$or\" : [";
	//var query;
    for(var mapObj of mapObjs){
        query+= "{ \"$and\": [{\"categoryName\":\""+mapObj.categoryName+"\"}, {\"officeID\":\""+mapObj.officeID+"\"},{ \"status\": { \"$in\": [ \"Open\", \"InProgress\" ] } }] },"
    }
    query = query.replace(/,*$/, "");
	query+="]}";
	return query;
}

router.get('/getAllResponders',authenticate,function(req,res){
	if(req.user){
        var companyNo = req.companyNo;
        var companyID = req.user.companyID;
        //var userID = req.user.userID;
		var categoryUserMappingCollection = req.db.get(companyNo + '-category-user-mapping '); //Fetch the user data from db  
        //var officeID = data.officeID;
		Promise.all([
			categoryUserMappingCollection.find({},{fields:{_id:0,userName:1,office:1,categoryName:1,catUserMappingID:1}})
		])
        .then((data)=>{
			data = data[0];
			res.status(200).send({data});
        })
        .catch((err)=>{
            console.log('Unable to fetch category Mapping users :: '+ err);
            errorMsg = "Unable to fetch category Mapping users";
            res.status(300).send(errorMsg);
        })  
    }
});

router.get('/selectList',authenticate,(req,res)=>{
	if(req.user){
		var companyNo = req.companyNo;		
		var companyCollection = req.db.get('companies');
		var officeCollection = req.db.get(companyNo + '-offices');
		var usersCollection = req.db.get(companyNo + '-users');
		var toTitleCase = function(str){
			return str.replace(/\w\S*/g, function(txt){return txt.charAt(0).toUpperCase() + 
				 txt.substr(1).toLowerCase();});
		}
		Promise.all([
			companyCollection.findOne({companyNo:companyNo},{fields:{_id:0,'tables.category':1}}),
			officeCollection.find(),
			usersCollection.find({"employee":{ $exists: true }})
		])
		.then((result)=>{
			var tables = result[0].tables;
			var offices = result[1];
			var users = result[2];
			var categoryArray = [];
			var officeArray = [];
			var usersArray =[];
			for(var i in tables.category){
				categoryArray.push({
					label: tables.category[i],
					value: {
						name: tables.category[i]
					}
				})
			}
			for(var i in offices){
				officeArray.push({
					label: offices[i].name,
					value: {
						name: offices[i].name,
						officeID: offices[i].officeID
					}
				})
			}
			for(var i in users){
				usersArray.push({
					label: toTitleCase(users[i].first) + " "+ toTitleCase(users[i].last),
					value: {
						userName: toTitleCase(users[i].first) + " "+ toTitleCase(users[i].last),
						userID: users[i].userID
					}
				})
			}
			res.send({categories:categoryArray,offices:officeArray,users:usersArray});
		})
	} else {
	 	console.log('sending null')
	 	res.send({data:null});
	}
})

function getOtherRespondersDbArray(req,mapObjs,categoryUserMappingCollection){
	var arr = []  
	for (var mapObj of mapObjs){
		arr.push(categoryUserMappingCollection.find({categoryName:{ $eq: mapObj.categoryName},userID:{$ne : req.user.userID}},{fields:{_id:0,userName:1,userID:1}}))
	}
	return arr;
}

/*router.get('/getOtherResponders',authenticate,function(req,res){
	if(req.user){
		var companyNo = req.companyNo;	
		var data = req.query;
		var categoryName = data.categoryName;
		var categoryUserMappingCollection = req.db.get(companyNo + '-category-user-mapping '); //Fetch the user data from db   
		Promise.all([
			categoryUserMappingCollection.find({categoryName:{ $eq: categoryName},userID:{$ne : req.user.userID}},{fields:{_id:0,categoryName:1,userName:1,catUserMappingID:1}})
		])
        .then((data)=>{
			data = data[0];
			res.status(200).send({data});
        })
	}
})*/



module.exports = router;