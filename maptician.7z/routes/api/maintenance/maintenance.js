var router = require('express').Router();

router.use('/request',require('./maintenanceRequest'));
router.use('/request',require('./responder'));
router.use('/request',require('./categoryAssignment'));

module.exports = router;