var router = require('express').Router();
var authenticate = require('../../.././middleware/authenticate').authenticate;
var utils = require('../../.././utils/utils');
var moment = require('moment');
var uuid = utils.uuid;
//Rest Api to assign users to category

router.post('/saveCatUserMapping',authenticate ,(req,res)=>{
	if(req.user){
		var companyNo = req.companyNo;
        var categoryUserMappingCollection = req.db.get(companyNo + '-category-user-mapping '); //Fetch the user data from db  
        var usersArr=[];
        var categoryUserData=[];
        //var users;
       // var userCollection = req.db.get(companyNo + '-users'); //Fetch the user data from db
		var data1 = req.body['data'];
        var data2 = data1[0];
        Promise.all([
            categoryUserMappingCollection.find({"office.officeID":data2.office.officeID})
        ])
        .then((result)=>{
            var mappings =  result;
           if(data2.user && validateMapping(mappings,data2.user.userID,data2.category.name)){
               res.status(300).send({error:"User is already assigned to this office"});
               next();
           }
       
		var data = {
            userName:data2.user.userName,
            userID:data2.user.userID,
            createdDate:moment().valueOf(),
            modifiedDate: moment().valueOf(),
            office:data2.office,
            categoryName:data2.category.name,
			catUserMappingID: utils.uuid()
		}
		categoryUserMappingCollection.insert(data)
			.then((result)=>{
				if(result._id){
					var insertedData = [result];
					res.status(200).send({data:insertedData});
				} else {
					res.status(200).send({data:[]});
				}
			})
			.catch((err)=>{
				console.log(2,err);
				res.status(300).send({data:4});
			})
	
    
})
} else {
    console.log('sending null')
    res.send({data:null});
}
})

/*router.post('/saveCatUserMapping',authenticate,(req,res)=>{
    console.log("Maitenance Category User mapping");
    var categoryAssignmentRequestData = JSON.parse(req.body.data); // Parse the Json data coming from UI
    var companyNo = req.companyNo; 
    var mail = req.email;
    var categoryUserMappingCollection = req.db.get(companyNo + '-category_user_mapping '); //Fetch the user data from db  
    var usersArr=[];
    var categoryUserData=[];
    var users;
    var userCollection = req.db.get(companyNo + '-users'); //Fetch the user data from db
    
    userCollection.find({"employee":{ $exists: true }},{fields:{"employee.employeeID":1}})
    .then((result)=>{
        users = result[0];
    })
    .catch((err)=>{
        console.log('Error in Saving records :: '+ err);
        errorMsg = "Unable to fetch Users";
        res.status(300).send(errorMsg);
        next();
    })  
    for(var assignmentData of categoryAssignmentRequestData){
        var usersToAdd = categoryAssignmentRequestData.users.add;
        var usersToDelete = categoryAssignmentRequestData.users.delete;
        for(var user of usersToAdd){
            var user ={
                userID:user.userID,
                username: toTitleCase(user.first) + " "+ toTitleCase(user.last),
            }
            usersArr.push(user);
        }
        var data={};
        if(usersArr.length>0){
            data.categoryID = assignmentData.categoryId;
            data.users=usersArr;
            data.officeID=assignmentData.officeID;
        }
        categoryUserData.push(data);
    }
    Promise.all([
        saveUserDataForUpdate(categoryUserData,req)
    ]) 
    .then((result)=>{
        res.status(200).send({});
    })
    .catch((err)=>{
        console.log('Error in Saving records :: '+ err);
        errorMsg = "Error in saving user records";
        res.status(300).send(errorMsg);
    })  

});*/

function validateMapping(mappings,userID,categoryName){
    var flag = false;
    for (var item of mappings){
        if(item.userID == userID && item.catagoryName == categoryName){
            flag = true;
        }
    }
    return flag
}

//Prepare the Array of objects which will be updated in bulkwrite with updateOne 
function updateBulkUser(updateUserArray){
    var writeArray = [];
	var len = updateUserArray.length;
	if(len == 0){
		console.log("0 User Updated");
		return writeArray;
    }
	for(var i = 0;i < len;i++){
        var categoryId = updateUserArray[i].categoryID;
        //delete updateUserArray[i].employee.employeeID
        var updateObj = updateUserArray[i];
		writeArray.push({
			updateOne: {
				filter: {"categoryID":categoryId,"officeID":updateUserArray[i].officeID},
                //update: $set:updateObj,
                update: {$set: updateObj},
                upsert: true
			}
		})
	}

	console.log(len+" Users Updated");
	return writeArray;
}

function saveUserDataForUpdate(validUserData,req){
    if(validUserData.length >0 ){
        var writeArray = updateBulkUser(validUserData);
        var userCollection = req.db.get(req.companyNo + '-category_user_mapping');
        userCollection.bulkWrite(writeArray)
        .then((result)=>{
            console.log("User Data updated Successfully");
            //res.status(200).send({error:inValidUserData,"failed":inValidUserData.length,"success":validUserData.length});
        })
        .catch((err)=>{
            console.log(err);
            errorMsg = "Error in updating records";
            //res.status(300).send(errorMsg);
        })
    }
}

router.delete('/deleteCatUserMapping',authenticate ,(req,res)=>{
	if(req.user){
		var id = Object.keys(req.query.data)[0];
		var data = req.query.data[id];
		var companyNo = req.companyNo;			
		var categoryUserMappingCollection = req.db.get(companyNo + '-category-user-mapping');
		categoryUserMappingCollection.remove({catUserMappingID:id})
		.then((result)=>{
				console.log(result)
				res.status(200).send({});
		})
		.catch((err)=>{
			console.log(2,err);
			res.status(300).send({data:4});
		})
	} else {
		console.log('sending null')
		res.send({data:null});
	}
})

router.put('/editCatUserMapping',authenticate ,(req,res)=>{
	delete req.body.action;
	var data = utils.unflatten(req.body);
	if(req.user){
         var id = Object.keys(data.data)[0];
         var catagoryName = data.data[id].category.name;
         console.log("catagoryName" + catagoryName);
         data.data[id].categoryName=catagoryName;
        var companyNo = req.companyNo;
        delete data.data[id].category
        delete data.data[id].userName
        data.data[id].modifiedDate=moment().valueOf();
		var categoryUserMappingCollection = req.db.get(companyNo + '-category-user-mapping');
		categoryUserMappingCollection.findOneAndUpdate(
			{catUserMappingID:id},
			{$set:data.data[id]}
		)
		.then((result)=>{
			console.log('result',result);
			var insertedData = [result];
			res.status(200).send({data:insertedData});
		})
		.catch((err)=>{
			console.log(2,err);
			res.status(300).send({data:4});
		})
	} else {
	 	console.log('sending null')
	 	res.send({data:null});
	}
})

/*router.get('/insert',(req,res)=>{
    var userCollection = req.db.get('9-users');

userCollection.insert({"email":"manohar@manakeshwar.com","first":"manohar","last":"patil","tokenhash":"d7b8d31f-c9cd-412f-b154-4056ea0add6f","companyID":"59b9fa9d0918da7710e2c4c1","companyStatus":"active","userStatus":"active","contact":{"cell":""},"userType":"admin","profileImages":{"largeProfile":"http://s3.amazonaws.com/maptician-test-01/59b9fa9d0918da7710e2c4c1/5a31af3e-6224-40b3-a6b8-db761243fb8d/largeProfile.png","mediumProfile":"http://s3.amazonaws.com/maptician-test-01/59b9fa9d0918da7710e2c4c1/5a31af3e-6224-40b3-a6b8-db761243fb8d/smallProfile.png","smallProfile":"http://s3.amazonaws.com/maptician-test-01/59b9fa9d0918da7710e2c4c1/5a31af3e-6224-40b3-a6b8-db761243fb8d/thumbnailProfile.png"},"userID":"5a31af3e-6224-40b3-a6b8-db761243fb8d","password":{"hash":"xk0LTNTsC+awVB8YBtjNzdchRku3hVFxHvR3Zy4s2yqb0daw0kAfLj5dTp/+S0rlsRibzKJ+uaIooNLfzTEGQSVA","salt":"eoU6CkzTGMqNsuOfkGjxA2+ogAfTCQH4lSuEebwlXz2Tffy49tIuNfrqIudDbQ1HJ3XSSV6foPaqjzKtYH3y55GI","keyLength":66,"hashMethod":"pbkdf2","iterations":462039},"employee":{"employeeID":"","department":"unassigned"}})
.then((result)=>{
    console.log('result',result);
});

})*/

module.exports = router;