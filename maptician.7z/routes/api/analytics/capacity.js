var router = require('express').Router();
var authenticate = require('../../.././middleware/authenticate').authenticate;
var utils = require('../../.././utils/utils');
var moment = require('moment');


///////////////////////////////  Office Based Analytics //////////////////////////////////
// The following populated based on a requested officeID

//  #################  Seat Based ####################
// The following return data about seats

// This route returns capacity information (reservable/assigned/unassigned) for each seat in
// an office between the start and end dates.  The data is broken-out by map, department, and date.
// Capacity values are in seats per day and individual seats are not identified.
router.get('/seatCapacityTypeByDay',authenticate,function(req,res){
	if(req.user){
		console.log('Get Reservable Seat Capacity Type and Usage by Office by Day JSON')
		var companyNo = req.companyNo;
		var companyID = req.user.companyID;
		var officeID = req.query.officeID;
		console.log('OfficeID:',officeID)

		var end = moment().endOf('day');
		var start = moment(end).subtract(2,'years').startOf('day');

		var officesCollection = req.db.get(companyNo + '-offices');
		var departmentsCollection = req.db.get(companyNo + '-departments');
		var mapsCollection = req.db.get(companyNo + '-maps');
		var seatsCollection = req.db.get(companyNo + '-seats');
		var offices,maps,seats,departments;
		var orList = [];

		Promise.all([
			officesCollection.find({status:"active"},{fields:{_id:0,officeID:1,name:1}}), // Need employees list
			mapsCollection.find({live:true,officeID},{fields:{_id:0,id:1,name:1,floorNumber:1,suiteNumber:1}}),
			departmentsCollection.find({},{fields:{_id:0}})
		])
		.then((results)=>{
			offices = results[0];
			maps = results[1];
			departments = results[2];

			for(var i = 0; i < maps.length; i++){
				orList.push({
					status:"active",
					mapID: maps[i].id
				})
			}

			if(orList.length == 0){
				res.status(200).send([]); // No applicable maps
				return(false);
			}

			return seatsCollection.find({$or:orList},{fields:{_id:0,mapID:1,seatName:1,assignmentStatus:1,reservable:1,log:1,date:1}});
		})
		.then((results)=>{
			if(results === false){return;}

			seats = results;
			var timePointer = moment(start);
			var timeArray = [];
			while(timePointer.isBefore(end)){
				timeArray.push(timePointer.valueOf());
				timePointer.add(1,'day');
			}
			var length = timeArray.length;
			var mapObj = {};
			var map;
			for(var i = 0; i < maps.length; i++){
				map = maps[i];
				map.seats = [];
				mapObj[map.id] = map;
			}
			var seat, mapID;
			for(var i = 0; i < seats.length; i++){
				seat = seats[i];
				mapObj[seat.mapID].seats.push(seat)
			}
			var deptObj = {};
			for(var i = 0; i < departments.length; i++){
				deptObj[departments[i].deptID] = departments[i];
			}
			var log, entry, nextEntry, active, dept, reservable, assigned, startDate, endDate, dataPos, dataDate, statObj, lastLog;
			var dataPoint;
			var resultArray = [];
			for(var i in mapObj){
				map = mapObj[i];
				map.data = [];
				for(var j = 0; j < length; j++){
					map.data.push({date:timeArray[j]});
				}
				for(var j = 0; j < map.seats.length; j++){
					seat = map.seats[j];
					log = seat.log;
					dataPos = 0;
					for(var k = 0; k < log.length; k++){
						// Gets the start date of the current entry
						entry = log[k];
						startDate = moment(entry.date);
						// Gets the start date of the next entry if it exists, if not, gets the current time
						nextEntry = log[k+1];
						endDate = nextEntry ? moment(nextEntry.date) : moment().utc();
						lastLog = nextEntry ? false : true; // True if there is no next entry
						active = entry.status == "active"; // True if the seat is active in the entry
						if(active == false && lastLog){break;} // No need to continue if the seat is inactive and on the last entry
						dept = entry.deptID ? deptObj[entry.deptID].deptID : "Unassigned"; // The department id for the entry
						reservable = entry.reservable; // True if the seat was reservable for the entry
						// Any seat not reservable is necessarily assignable
						assigned = entry.assignment == "Assigned"; // True if the seat was assigned for the entry
						while(true){
							if(dataPos == length){
								break;
							}
							dataDate = moment(map.data[dataPos].date);
							if(dataDate.isBefore(startDate,'day')){
								dataPos += 1;
								continue;
							}
							if(dataDate.isAfter(endDate,'day')){ // If the date is after the end of the log, move to the next log item
								break;
							}
							if(dataDate.isBetween(startDate,endDate,'day','[]')){
								if(active){
									if(map.data[dataPos][dept] == undefined){
										map.data[dataPos][dept] = {
											reservable: 0,
											assigned: 0,
											unassigned: 0
										};
									}
									statObj = map.data[dataPos][dept];
									statObj.reservable += reservable ? 1 : 0;
									statObj.assigned += assigned ? 1 : 0;
									statObj.unassigned += assigned || reservable ? 0 : 1;
									dataPos += 1;
									continue;									
								} else { // If the seat wasn't active, don't change the data, just move to the next date
									dataPos += 1;
									continue;
								}
							}
							break;
						}
					}
				}
				for(var j = 0; j < length; j++){
					dataDate = map.data[j];
					for(var k in dataDate){
						if(k == "date"){
							continue;
						} else {
							dataPoint = dataDate[k];
							resultArray.push({
								date: dataDate.date,
								mapName: map.name,
								floor: map.floorNumber,
								suite: map.suiteNumber,
								department: deptObj[k].deptName,
								reservable: dataPoint.reservable,
								assigned: dataPoint.assigned,
								unassigned: dataPoint.unassigned
							})
						}
					}
				}
			}
			res.status(200).send(resultArray);
		})
		.catch((err)=>{
			console.log(err);
			res.status(300).send([]);
		})
	} else{
		res.status(300).send([]);
	}	
})

// This route returns total active seat capacity for a given office broken out by day, map, and department
// This does NOT include information about capacity type or reservable capacity usage
router.get('/seatCapacityByDay',authenticate,function(req,res){
	if(req.user){
		console.log('Get Total Seat Capacity by Office by Day JSON')
		var companyNo = req.companyNo;
		var companyID = req.user.companyID;
		var officeID = req.query.officeID;

		var end = moment().endOf('day');
		var start = moment(end).subtract(2,'years').startOf('day');

		var officesCollection = req.db.get(companyNo + '-offices');
		var mapsCollection = req.db.get(companyNo + '-maps');
		var seatsCollection = req.db.get(companyNo + '-seats');
		var departmentsCollection = req.db.get(companyNo + '-departments');

		var offices,maps,seats,departments;
		var orList = [];

		Promise.all([
			officesCollection.find({status:"active"},{fields:{_id:0,officeID:1,name:1}}), // Need employees list
			mapsCollection.find({live:true,officeID},{fields:{_id:0,id:1,name:1,floorNumber:1,suiteNumber:1}}),
			departmentsCollection.find({},{fields:{_id:0}}),
		])
		.then((results)=>{
			offices = results[0];
			maps = results[1];
			departments = results[2];

			for(var i = 0; i < maps.length; i++){
				orList.push({
					status:"active",
					mapID: maps[i].id
				})
			}

			if(orList.length == 0){
				res.status(200).send([]);
				return("End");
			}

			return seatsCollection.find({$or:orList},{fields:{_id:0,mapID:1,seatName:1,assignmentStatus:1,reservable:1,log:1,date:1}});
		})
		.then((results)=>{
			if(results == "End"){
				return;
			}
			seats = results;

			var timePointer = moment(start);
			var timeArray = [];
			while(timePointer.isBefore(end)){
				timeArray.push(timePointer.valueOf());
				timePointer.add(1,'day');
			}
			var length = timeArray.length;
			
			// Adds a seats array onto each map and creates a mapObj which indexes maps by their mapID
			var mapObj = {};
			var map;
			for(var i = 0; i < maps.length; i++){
				map = maps[i];
				map.seats = [];
				mapObj[map.id] = map;
			}

			// Adds each seat to its respective map in the seats array
			var seat, mapID;
			for(var i = 0; i < seats.length; i++){
				seat = seats[i];
				console.log(seats)
				mapObj[seat.mapID].seats.push(seat)
			}

			// Creates a departments obj indexed by deptID.  Basically just used to lookup name from ID
			var deptObj = {};
			for(var i = 0; i < departments.length; i++){
				deptObj[departments[i].deptID] = departments[i].deptName;
			}

			var log, entry, nextEntry, active, dept, reservable, assigned, startDate, endDate, dataPos, dataDate, statObj, lastLog;
			var dataPoint;
			var resultArray = [];
			for(var i in mapObj){
				map = mapObj[i];

				// Creats a data array and fills it with an object for each day of the measured period
				// The day is also provided as .date
				map.data = [];
				for(var j = 0; j < length; j++){
					map.data.push({date:timeArray[j]});
				}

				for(var j = 0; j < map.seats.length; j++){
					seat = map.seats[j];
					log = seat.log;
					dataPos = 0; // Since the log for each seat is sequential, we can keep that to one loop per seat
					for(var k = 0; k < log.length; k++){
						// Gets the start date of the current entry
						entry = log[k];
						startDate = moment(entry.date);
						// Gets the start date of the next entry if it exists, if not, gets the current time
						nextEntry = log[k+1];
						endDate = nextEntry ? moment(nextEntry.date) : moment().utc();
						lastLog = nextEntry ? false : true; // True if there is no next entry
						active = entry.status == "active"; // True if the seat is active in the entry
						if(active == false && lastLog){break;} // No need to continue if the seat is inactive and on the last entry
						dept = entry.deptID; // The department id for the entry
						reservable = entry.reservable; // True if the seat was reservable for the entry
						// Any seat not reservable is necessarily assignable
						assigned = entry.assignment == "Assigned"; // True if the seat was assigned for the entry
						while(true){
							if(dataPos == length){break;}
							dataDate = moment(map.data[dataPos].date); // Date currently being calculated for the seat
							if(dataDate.isBefore(startDate,'day')){
								dataPos += 1;
								continue;
							}
							if(dataDate.isAfter(endDate,'day')){ // If the date is after the end of the log, move to the next log item
								break;
							}
							if(dataDate.isBetween(startDate,endDate,'day','[]')){
								if(active){
									if(map.data[dataPos][dept]){
										map.data[dataPos][dept] += 1;
									} else {
										map.data[dataPos][dept] = 1;
									}
									dataPos += 1;
									continue;									
								} else { // If the seat wasn't active, don't change the data, just move to the next date
									dataPos += 1;
									continue;
								}
							}
							break;
						}
					}
				}
				for(var j = 0; j < length; j++){
					dataDate = map.data[j];
					for(var k in dataDate){
						if(k == "date"){
							continue;
						} else {
							dataPoint = dataDate[k];
							resultArray.push({
								date: dataDate.date,
								mapName: map.name,
								floor: map.floorNumber,
								suite: map.suiteNumber,
								department: deptObj[k],
								capacity: dataPoint
							})
						}
					}
				}
			}
			res.status(200).send(resultArray);
		})
		.catch((err)=>{
			console.log(err);
			res.status(300).send([]);
		})
	} else{
		res.status(300).send([]);
	}	
})

// This route provides an array of seat reservation entries which are aggregated by day
// The information provided for each day includes the date, map, seat, department, floor and suite.
// Along with information on its available capacity and how much of that capacity was used ('reserved').
// Available and used capacities are measured on an hours/day basis.
// A "hoursPerDay" variable is used to determine the capacity per seat per day (in hours) and limits
// the returned "used" result.  i.e. with an 8 hoursPerDay parameter, each seat will show 8 hours per day
// of reservable capacity, and a maximum of 8 hours of usage per day, regardless of whether the actual
// usage exceeds this 8 hours.  This is to normalize the data, especially with reservations that span
// multiple days which would tend to show 300% utilization against an 8 hour day.  Alternatively, showing
// 24 hours of capacity per day would result in very low utilization measures and again give undue weight to
// multi-day or all-day reservations which are unlikely to have the seat actually in use for the duration.
router.get('/seatReservationUsageByDay',authenticate,function(req,res){
	if(req.user){
		console.log('Get Seat Reservation Capacity and Usage by Office by Day')
		var companyNo = req.companyNo;
		var companyID = req.user.companyID;
		var officeID = req.query.officeID;

		var end = moment().endOf('day');
		var start = moment(end).subtract(2,'years').startOf('day');
		var hoursPerDay = 8;

		var mapsCollection = req.db.get(companyNo + '-maps');
		var seatsCollection = req.db.get(companyNo + '-seats');
		var reservationsCollection = req.db.get(companyNo + '-seat-reservations');
		var departmentsCollection = req.db.get(companyNo + '-departments')
		var offices,map,maps,mapObj,mapID,seat,seats,seatID,seatName,reservation,reservations;
		var log, length, entry, nextEntry, active, reservable, startDate, endDate, dataPos, dataDate, startTime, endTime;
		var date, endOfDay, startOfDay, startOfDayVal, duration, hours;
		var departments;
		var orList1 = [];
		var orList2 = [];
		var mapObj = {};
		var resultArray = []; // Returned as result in successful calculation

		Promise.all([
				mapsCollection.find({live:true,officeID},{fields:{_id:0,id:1,name:1,floorNumber:1,suiteNumber:1}}),
				departmentsCollection.find({},{fields:{_id:0}})
			])
		.then((results)=>{
			maps = results[0];
			departments = results[1];

			for(var i = 0; i < maps.length; i++){
				mapID = maps[i].id;
				orList1.push({ start: { $gte: start.valueOf() , $lte: end.valueOf()}, mapID:mapID});
				orList1.push({ end: { $gte: start.valueOf() , $lte: end.valueOf()}, mapID:mapID});
				orList2.push({
					mapID: mapID
				})
			}

			if(orList1.length == 0){
				res.status(200).send([]); // No maps found, return an empty array
				return(false);
			}

			return Promise.all([
					reservationsCollection.find({$or:orList1},{fields:{_id:0,start:1,end:1,mapID:1,seatID:1,deptID:1}}),
					seatsCollection.find({$or:orList2},{fields:{_id:0,mapID:1,seatID:1,seatName:1,reservable:1,log:1}})
				])
		})
		.then((results)=>{
			if(results === false){return;}
			reservations = results[0];
			seats = results[1];

			// Creates an array of moments for the report period, each moment is the start of the day
			var timePointer = moment(start);
			var timeArray = [];
			while(timePointer.isBefore(end)){
				timeArray.push(timePointer.valueOf());
				timePointer.add(1,'day');
			}

			// Creates a departments obj indexed by deptID.  Basically just used to lookup name from ID
			var deptObj = {};
			for(var i = 0; i < departments.length; i++){
				deptObj[departments[i].deptID] = departments[i].deptName;
			}

			// Creates an object of maps, indexed by mapID
			for(var i = 0; i < maps.length; i++){
				map = maps[i];
				map.seats = {};
				map.reservations = [];
				mapObj[map.id] = map;
			}

			// Populates the seats object on each map in the map object
			for(var i = 0; i < seats.length; i++){
				seat = seats[i];
				mapObj[seat.mapID].seats[seat.seatID] = seat;
			}

			// Assigns the reservations to their respective map on the mapObj
			for(var i = 0; i < reservations.length; i++){
				reservation = reservations[i];
				mapObj[reservation.mapID].reservations.push(reservation);
			}

			// Main route logic.  Finds capacity and usage of reservable seats by map, by date
			length = timeArray.length;
			for(var i in mapObj){
				map = mapObj[i];
				map.dataObj = {};
				map.data = [];
				if(Object.keys(map.seats).length == 0){continue;} // Skip this map if it doesn't have seats
				for(var j = 0; j < length; j++){
					map.data.push({date:timeArray[j],departments:{}}); // data is capacity information for reservable seats
				}
				for(var j in map.seats){
					seatID = j;
					seatName = map.seats[j].seatName;
					log = map.seats[j].log;
					dataPos = 0;
					for(var k = 0; k < log.length; k++){
						entry = log[k];
						startDate = moment(entry.date); // Gets the start date of the current entry
						// Gets the start date of the next entry if it exists, if not, gets the current time
						nextEntry = log[k+1];
						endDate = nextEntry ? moment(nextEntry.date) : moment().utc();
						active = entry.status == "active"; // True if the seat is active in the entry
						reservable = entry.reservable; // True if the seat was reservable for the entry
						department = entry.deptID;
						if(active == false || reservable == false){break;} // No need to continue since there's no availability
						while(true){
							if(dataPos == length){break;}
							dataDate = moment(map.data[dataPos].date);
							date = map.data[dataPos];
							if(dataDate.isBefore(startDate,'day')){
								dataPos += 1;
								continue;
							}
							if(dataDate.isAfter(endDate,'day')){break;}
							if(dataDate.isBetween(startDate,endDate,'day','[]')){
								if(date.departments[department] === undefined){
									date.departments[department] = {seats:{}};
								}
								if(date.departments[department].seats[seatID]){
									date.departments[department].seats[seatID].available += hoursPerDay;
								} else {
									date.departments[department].seats[seatID] = {
										available:hoursPerDay,
										used:0,
										seatName: seatName
									};
								}
								dataPos += 1;
								continue;
							}
							console.log('Error occured in loop, condition not caught.  Exiting.')
							break;
						}
					}
				}

				// Changes the map data list to an object indexed by date, this is needed to assign reservation data
				for(var j = 0; j < length; j++){
					map.dataObj[map.data[j].date] = map.data[j];
				}

				// Loops through all the reservations for a map and adds their duration to the appropriate dates and seats
				for(var j = 0; j < map.reservations.length; j++){
					reservation = map.reservations[j];
					startTime = moment(reservation.start);
					endTime = moment(reservation.end);
					seatID = reservation.seatID;
					deptID = reservation.deptID;
					console.log(reservation)
					console.log(deptID)
					while(true){
						endOfDay = moment(startTime).endOf('day');
						startOfDay = moment(startTime).startOf('day');
						startOfDayVal = startOfDay.valueOf();
						date = map.dataObj[startOfDayVal];
						console.log(date,deptID,seatID)
						seat = date.departments[deptID].seats[seatID];
						if(endTime <= endOfDay){
							duration = moment.preciseDiff(startTime,endTime,true);
							hours = duration.hours + duration.minutes/60;
							if(seat){seat.used += hours;}
							break;
						} else {
							duration = moment.preciseDiff(startTime,endOfDay,true);
							hours = duration.hours + duration.minutes/60;
							if(seat){seat.used += hours;}
						}
						startTime = startOfDay.add(1,'day');
					}
				}

				// Reduces hours for a date/seat combination to the daily max
				for(var j in map.dataObj){
					date = map.dataObj[j];
					date.seats = [];
					for(var l in date.departments){
						department = date.departments[l];
						deptID = l;
						for(var k in department.seats){
							seat = department.seats[k];
							seat.deptID = deptID;
							seat.used = seat.used > hoursPerDay ? hoursPerDay : seat.used;
							date.seats.push(seat);
						}
					}
				}

				for(var j in map.dataObj){ // j is date/index, dataObj has seat object and date
					for(var k = 0; k < map.dataObj[j].seats.length; k++){
						seat = map.dataObj[j].seats[k];
						resultArray.push({
							d:j, // date
							st:map.suiteNumber,
							f:map.floorNumber,
							sn: seat.seatName,
							dpt: deptObj[seat.deptID],
							a: seat.available,
							u: seat.used,
						})
					}
				}
			}

			res.status(200).send(resultArray);

		})
		.catch((err)=>{
			console.log(err);
			res.status(300).send([]);
		})
	} else{
		res.status(300).send([]);
	}	
})



// This route provides an array of seat reservation entries which are aggregated by day
// The information provided for each day includes the date, map, seat, department, floor and suite.
// Along with information on its available capacity and how much of that capacity was used ('reserved').
// Available and used capacities are measured on an hours/day basis.
// A "hoursPerDay" variable is used to determine the capacity per seat per day (in hours) and limits
// the returned "used" result.  i.e. with an 8 hoursPerDay parameter, each seat will show 8 hours per day
// of reservable capacity, and a maximum of 8 hours of usage per day, regardless of whether the actual
// usage exceeds this 8 hours.  This is to normalize the data, especially with reservations that span
// multiple days which would tend to show 300% utilization against an 8 hour day.  Alternatively, showing
// 24 hours of capacity per day would result in very low utilization measures and again give undue weight to
// multi-day or all-day reservations which are unlikely to have the seat actually in use for the duration.
router.get('/seatReservationUsageByHour',authenticate,function(req,res){
	if(req.user){
		console.log('Get Seat Reservation Capacity and Usage by Office by Hour')
		var companyNo = req.companyNo;
		var companyID = req.user.companyID;
		var officeID = req.query.officeID;

		var end = moment().endOf('day');
		var start = moment(end).subtract(3,'months').startOf('day');
		var hoursPerHour = 1;

		var mapsCollection = req.db.get(companyNo + '-maps');
		var seatsCollection = req.db.get(companyNo + '-seats');
		var reservationsCollection = req.db.get(companyNo + '-seat-reservations');
		var departmentsCollection = req.db.get(companyNo + '-departments')
		var offices,map,maps,mapObj,mapID,seat,seats,seatID,seatName,reservation,reservations;
		var log, length, entry, nextEntry, active, reservable, startDate, endDate, dataPos, dataDate, startTime, endTime;
		var date, endOfDay, startOfDay, startOfDayVal, duration, hours;
		var departments;
		var orList1 = [];
		var orList2 = [];
		var mapObj = {};
		var resultArray = []; // Returned as result in successful calculation

		Promise.all([
				mapsCollection.find({live:true,officeID},{fields:{_id:0,id:1,name:1,floorNumber:1,suiteNumber:1}}),
				departmentsCollection.find({},{fields:{_id:0}})
			])
		.then((results)=>{
			maps = results[0];
			departments = results[1];

			for(var i = 0; i < maps.length; i++){
				mapID = maps[i].id;
				orList1.push({ start: { $gte: start.valueOf() , $lte: end.valueOf()}, mapID:mapID});
				orList1.push({ end: { $gte: start.valueOf() , $lte: end.valueOf()}, mapID:mapID});
				orList2.push({
					mapID: mapID
				})
			}

			if(orList1.length == 0){
				res.status(200).send([]); // No maps found, return an empty array
				return(false);
			}

			return Promise.all([
					reservationsCollection.find({$or:orList1},{fields:{_id:0,start:1,end:1,mapID:1,seatID:1,deptID:1}}),
					seatsCollection.find({$or:orList2},{fields:{_id:0,mapID:1,seatID:1,seatName:1,reservable:1,log:1}})
				])
		})
		.then((results)=>{
			if(results === false){return;}
			reservations = results[0];
			seats = results[1];

			// Creates an array of moments for the report period, each moment is the start of the hour
			var timePointer = moment(start);
			var timeArray = [];
			while(timePointer.isBefore(end)){
				timeArray.push(timePointer.valueOf());
				timePointer.add(1,'hour');
			}

			// Creates a departments obj indexed by deptID.  Basically just used to lookup name from ID
			var deptObj = {};
			for(var i = 0; i < departments.length; i++){
				deptObj[departments[i].deptID] = departments[i].deptName;
			}

			// Creates an object of maps, indexed by mapID
			for(var i = 0; i < maps.length; i++){
				map = maps[i];
				map.seats = {};
				map.reservations = [];
				mapObj[map.id] = map;
			}

			// Populates the seats object on each map in the map object
			for(var i = 0; i < seats.length; i++){
				seat = seats[i];
				mapObj[seat.mapID].seats[seat.seatID] = seat;
			}

			// Assigns the reservations to their respective map on the mapObj
			for(var i = 0; i < reservations.length; i++){
				reservation = reservations[i];
				mapObj[reservation.mapID].reservations.push(reservation);
			}

			// Main route logic.  Finds capacity and usage of reservable seats by map, by date
			length = timeArray.length;
			for(var i in mapObj){
				map = mapObj[i];
				map.dataObj = {};
				map.data = [];
				if(Object.keys(map.seats).length == 0){continue;} // Skip this map if it doesn't have seats
				for(var j = 0; j < length; j++){
					map.data.push({date:timeArray[j],departments:{}}); // data is capacity information for reservable seats
				}
				for(var j in map.seats){
					seatID = j;
					seatName = map.seats[j].seatName;
					log = map.seats[j].log;
					dataPos = 0;
					for(var k = 0; k < log.length; k++){
						entry = log[k];
						startDate = moment(entry.date); // Gets the start date of the current entry
						// Gets the start date of the next entry if it exists, if not, gets the current time
						nextEntry = log[k+1];
						endDate = nextEntry ? moment(nextEntry.date) : moment().utc();
						active = entry.status == "active"; // True if the seat is active in the entry
						reservable = entry.reservable; // True if the seat was reservable for the entry
						department = entry.deptID;
						if(active == false || reservable == false){break;} // No need to continue since there's no availability
						while(true){
							if(dataPos == length){break;}
							dataDate = moment(map.data[dataPos].date);
							date = map.data[dataPos]; // where the capacity information is stored
							if(dataDate.isBefore(startDate,'hour')){
								dataPos += 1;
								continue;
							}
							if(dataDate.isAfter(endDate,'hour')){break;}
							if(dataDate.isBetween(startDate,endDate,'hour','[]')){
								if(date.departments[department] === undefined){
									date.departments[department] = {seats:{}};
								}
								if(date.departments[department].seats[seatID]){
									date.departments[department].seats[seatID].available += hoursPerHour;
								} else {
									date.departments[department].seats[seatID] = {
										available:hoursPerHour,
										used:0,
										seatName: seatName
									};
								}
								dataPos += 1;
								continue;
							}
							console.log('Error occured in loop, condition not caught.  Exiting.')
							break;
						}
					}
				}

				// Changes the map data list to an object indexed by date, this is needed to assign reservation data
				for(var j = 0; j < length; j++){
					map.dataObj[map.data[j].date] = map.data[j];
				}

				// Loops through all the reservations for a map and adds their duration to the appropriate dates and seats
				for(var j = 0; j < map.reservations.length; j++){
					reservation = map.reservations[j];
					startTime = moment(reservation.start);
					endTime = moment(reservation.end);
					seatID = reservation.seatID;
					deptID = reservation.deptID;
					while(true){
						endOfDay = moment(startTime).endOf('hour');
						startOfDay = moment(startTime).startOf('hour');
						startOfDayVal = startOfDay.valueOf();
						date = map.dataObj[startOfDayVal];
						seat = date.departments[deptID].seats[seatID];
						if(endTime <= endOfDay){
							duration = moment.preciseDiff(startTime,endTime,true);
							hours = duration.hours + duration.minutes/60 + duration.seconds/60;
							if(seat){seat.used += hours;}
							break;
						} else {
							duration = moment.preciseDiff(startTime,endOfDay,true);
							hours = duration.hours + duration.minutes/60 + (1+duration.seconds)/3600;
							if(seat){seat.used += hours;}
						}
						startTime = startOfDay.add(1,'hour');
					}
				}

				// Reduces hours for a date/seat combination to the daily max
				for(var j in map.dataObj){
					date = map.dataObj[j];
					date.seats = [];
					for(var l in date.departments){
						department = date.departments[l];
						deptID = l;
						for(var k in department.seats){
							seat = department.seats[k];
							seat.deptID = deptID;
							seat.used = seat.used > hoursPerHour ? hoursPerHour : seat.used;
							date.seats.push(seat);
						}
					}
				}

				for(var j in map.dataObj){ // j is date/index, dataObj has seat object and date
					for(var k = 0; k < map.dataObj[j].seats.length; k++){
						seat = map.dataObj[j].seats[k];
						resultArray.push({
							d:j, // date
							st:map.suiteNumber,
							f:map.floorNumber,
							sn: seat.seatName,
							dpt: deptObj[seat.deptID],
							a: seat.available,
							u: seat.used,
						})
					}
				}
			}

			res.status(200).send(resultArray);

		})
		.catch((err)=>{
			console.log(err);
			res.status(300).send([]);
		})
	} else{
		res.status(300).send([]);
	}	
})


//  #################  Room Based ####################
// The following return data about seats

// This route provides an array of room reservation entries which are aggregated by day
// The information provided for each day includes the date, map, room, roomType, roomCapacity
// Along with information on its available capacity and how much of that capacity was used ('reserved').
// Available and used capacities are measured on an hours/day basis.
// A "hoursPerDay" variable is used to determine the capacity per room per day (in hours) and limits
// the returned "used" result.  i.e. with an 8 hoursPerDay parameter, each room will show 8 hours per day
// of reservable capacity, and a maximum of 8 hours of usage per day, regardless of whether the actual
// usage exceeds this 8 hours.  This is to normalize the data, especially with reservations that span
// multiple days which would tend to show 300% utilization against an 8 hour day.  Alternatively, showing
// 24 hours of capacity per day would result in very low utilization measures and again give undue weight to
// multi-day or all-day reservations which are unlikely to have the room actually in use for the duration.
router.get('/roomReservationUsageByDay',authenticate,function(req,res){
	if(req.user){
		console.log('Get Capacity by Office by Day JSON')
		var companyNo = req.companyNo;
		var companyID = req.user.companyID;
		var officeID = req.query.officeID;

		var end = moment().endOf('day');
		var start = moment(end).subtract(2,'years').startOf('day');
		var hoursPerDay = 8;

		var mapsCollection = req.db.get(companyNo + '-maps');
		var roomsCollection = req.db.get(companyNo + '-rooms');
		var reservationsCollection = req.db.get(companyNo + '-room-reservations');
		var offices,map,maps,mapObj,mapID,room,rooms,roomID,roomName,reservation,reservations;
		var log, length, entry, nextEntry, active, reservable, startDate, endDate, dataPos, dataDate, startTime, endTime;
		var date, endOfDay, startOfDay, startOfDayVal, duration, hours;
		var orList = [];
		var mapObj = {};
		var resultArray = []; // Returned as result in successful calculation

		Promise.all([
			mapsCollection.find({live:true,officeID},{fields:{_id:0,id:1,name:1,floorNumber:1,suiteNumber:1}}),
			roomsCollection.find({status:"active"},{fields:{_id:0,mapID:1,roomID:1,roomName:1,area:1,reservable:1,capacity:1,roomType:1,log:1}}),
		])
		.then((results)=>{
			maps = results[0];
			rooms = results[1];

			for(var i = 0; i < maps.length; i++){
				map = maps[i];
				orList.push({ start: { $gte: start.valueOf() , $lte: end.valueOf()}, mapID:map.id});
				orList.push({ end: { $gte: start.valueOf() , $lte: end.valueOf()}, mapID:map.id});
			}

			if(orList.length == 0){
				res.status(200).send([]); // No maps found, return an empty array
				return(false);
			}

			return reservationsCollection.find({$or:orList}); // Finds all reservations in the office between the start/end dates
		})
		.then((results)=>{
			if(results === false){return;}
			reservations = results;

			// Creates an array of moments for the report period, each moment is the start of the day
			var timePointer = moment(start);
			var timeArray = [];
			while(timePointer.isBefore(end)){
				timeArray.push(timePointer.valueOf());
				timePointer.add(1,'day');
			}

			// Creates an object of maps, indexed by mapID
			for(var i = 0; i < maps.length; i++){
				map = maps[i];
				map.rooms = {};
				map.reservations = [];
				mapObj[map.id] = map;
			}

			// Populates the room object on each map in the map object
			for(var i = 0; i < rooms.length; i++){
				room = rooms[i];
				mapObj[room.mapID].rooms[room.roomID] = room;
			}

			// Assigns the reservations to their respective map on the mapObj
			for(var i = 0; i < reservations.length; i++){
				reservation = reservations[i];
				mapObj[reservation.mapID].reservations.push(reservation);
			}

			// Main route logic.  Finds capacity and usage of reservable rooms by map, by date
			length = timeArray.length;
			for(var i in mapObj){
				map = mapObj[i];
				map.dataObj = {};
				map.data = [];
				for(var j = 0; j < length; j++){
					map.data.push({date:timeArray[j],rooms:{}}); // data is capacity information for reservable rooms
				}
				for(var j in map.rooms){
					roomID = j;
					log = map.rooms[j].log;
					dataPos = 0;
					for(var k = 0; k < log.length; k++){
						entry = log[k];
						startDate = moment(entry.date); // Gets the start date of the current entry
						// Gets the start date of the next entry if it exists, if not, gets the current time
						nextEntry = log[k+1];
						endDate = nextEntry ? moment(nextEntry.date) : moment().utc();
						active = entry.status == "active"; // True if the seat is active in the entry
						reservable = entry.reservable; // True if the seat was reservable for the entry
						if(active == false || reservable == false){break;} // No need to continue since there's no availability
						while(true){
							if(dataPos == length){break;}
							dataDate = moment(map.data[dataPos].date);
							date = map.data[dataPos];
							if(dataDate.isBefore(startDate,'day')){
								dataPos += 1;
								continue;
							}
							if(dataDate.isAfter(endDate,'day')){break;}
							if(dataDate.isBetween(startDate,endDate,'day','[]')){
								if(date.rooms[roomID]){
									date.rooms[roomID].available += hoursPerDay;
								} else {
									date.rooms[roomID] = {available:hoursPerDay,used:0};
								}
								dataPos += 1;
								continue;
							}
							console.log('Error occured in loop, condition not caught.  Exiting.')
							break;
						}
					}
				}

				// Changes the map data list to an object indexed by date, this is needed to assign reservation data
				for(var j = 0; j < length; j++){
					map.dataObj[map.data[j].date] = map.data[j];
				}

				// Loops through all the reservations for a map and adds their duration to the appropriate dates and rooms
				for(var j = 0; j < map.reservations.length; j++){
					reservation = map.reservations[j];
					startTime = moment(reservation.start);
					endTime = moment(reservation.end);
					roomID = reservation.roomID;
					while(true){
						endOfDay = moment(startTime).endOf('day');
						startOfDay = moment(startTime).startOf('day');
						startOfDayVal = startOfDay.valueOf();
						date = map.dataObj[startOfDayVal];
						room = date.rooms[roomID];
						if(endTime <= endOfDay){
							duration = moment.preciseDiff(startTime,endTime,true);
							hours = duration.hours + duration.minutes/60;
							room.used += hours;
							break;
						} else {
							duration = moment.preciseDiff(startTime,endOfDay,true);
							hours = duration.hours + duration.minutes/60;
							room.used += hours;
						}
						startTime = startOfDay.add(1,'day');
					}
				}

				// Reduces hours for a date/room combination to the daily max
				for(var j in map.dataObj){
					date = map.dataObj[j];
					for(var k in date.rooms){
						room = date.rooms[k];
						room.used = room.used > hoursPerDay ? hoursPerDay : room.used;
					}
				}

				for(var j in map.dataObj){ // j is date/index, dataObj has room object and date
					for(var k in map.dataObj[j].rooms){
						room = map.dataObj[j].rooms[k];
						resultArray.push({
							date:j,
							mapName: map.name,
							suite:map.suiteNumber,
							floor:map.floorNumber,
							roomName: map.rooms[k].roomName,
							available: room.available,
							used: room.used,
							area: map.rooms[k].area,
							capacity: map.rooms[k].capacity,
							roomType: map.rooms[k].roomType
						})
					}
				}
			}

			res.status(200).send(resultArray);

		})
		.catch((err)=>{
			console.log(err);
			res.status(300).send([]);
		})
	} else{
		res.status(300).send([]);
	}	
})



module.exports = router;