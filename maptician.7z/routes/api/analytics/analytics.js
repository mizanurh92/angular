var router = require('express').Router();
var authenticate = require('../../.././middleware/authenticate').authenticate;

router.use('/capacity',require('./capacity'));

module.exports = router;