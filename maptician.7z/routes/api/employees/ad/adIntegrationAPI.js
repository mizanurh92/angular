var router = require('express').Router();
var utils = require('../../../.././utils/utils');
var uuid = utils.uuid;
var config = require('../../../.././config/config');
var profilePath = config.profilePath;
var CryptoJS = require("crypto-js");
var validator = require('../bulk/bulkUserValidator');
function authenticateHashValue(hashValue, message) {
    var isHashValid = false;
    var hash = CryptoJS.HmacSHA256(message, "secret");
    var hashInBase64 = CryptoJS.enc.Base64.stringify(hash);
    if (hashInBase64 == hashValue) {

        isHashValid = true;
    }
    return isHashValid;
}

function authenticate(req, res, next) {
    var companyNo = req.body.companyNo;
    var ipAddress = req.ip;
    var hashvalue = req.headers.hashvalue;
    var isValidIp = false;
    var mongoDBIPListCollection = req.db.get(companyNo + '-adIntegration-ips');
    mongoDBIPListCollection.find({ "ip": { $exists: true } }, { fields: { ip: 1, hash: 1 } })
        .then((results) => {
            var ipList = results[0];
            if (authenticateHashValue(hashvalue, ipList.hash)) {
                for (var ip of ipList.ip) {
                    if (sentIp == ip) {
                        isValidIp = true;
                        next();
                    }
                }
            } else {
                return Promise.reject("Invalid Hash");
            }

            if (!isValidIp) {
                return Promise.reject("Invalid IP request");
            }
        }).catch((e) => {
            next();
        });

}

//REST API for Active Directory Integration and update the 
router.post('/updateActiveDirectoryUser', authenticate, (req, res) => {
    var companyNo = req.body.companyNo;
    var validUserData = [];//To store the valid user record 
    var inValidUserData = [];//To store the invalid user records
    var counter = 1; // Counter variable to sent the recordNumber in the errorLogs back to the caller.
    var user = req.user; //For error logging 
    var userdata = []; // To store the fetched userdata from the database.It will contain all the users with valid employeeId
    var deptData = []; //to store the fetched department data from the database. It will contain all the departments 
    var officeData = [];//to store the fetch office data
    var userCollection = req.db.get(companyNo + '-users'); //Fetch the user data from db
    var departmentsCollection = req.db.get(companyNo + '-departments'); //Fetch the dept data from db.
    var officeCollection = req.db.get(companyNo + '-offices'); //Fetch the offices data from db
    var configuredPrimaryKey = req.body.keyType;
    var bulkAddUserData = req.body.userlist;
    var companyCollection = req.db.get('companies');
    var companyID = "";
    Promise.all([
        officeCollection.find({}, { fields: { officeID: 1, name: 1 } }),
        departmentsCollection.find({}),
        configuredPrimaryKey == "employeeID" ? userCollection.find({ "employee": { $exists: true } }) : userCollection.find({ "email": { $exists: true } }),
        companyCollection.findOne({ companyNo: parseInt(companyNo) }, { fields: { _id: 1 } })
    ])
        .then((results) => {
            officeData = results[0];
            deptData = results[1];
            userdata = results[2];
            companyID = results[3];
            cloneUserData = clone(userdata, configuredPrimaryKey);
            for (var item of bulkAddUserData) {
                var resultObj = isUserExist(item, userdata, configuredPrimaryKey);
                var userExist = resultObj.employeeFound;
                var isUpdate = resultObj.update;
                var updateData = {}; //update object prepared for updating the record in db.
                var office = "unassigned"; //As per document TBD.
                var department = "unassigned"; // By default department value is unassigned.                     
                var errorObj = validator.validateAdIntegrationUser(item);
                if (item.department && item.department != null) {
                    var tempdepartment = findDepartMent(deptData, item.department,errorObj);
                    department = tempdepartment ? tempdepartment : department;
                }
                //setObject('employee.department', department, updateData);
                if (item.office && item.office != null) {
                    var tempOffice = findOffice(officeData, item.office,errorObj);
                    office = tempOffice ? tempOffice : office;
                }
                //updateData.office = office;
                if (errorObj.length > 0) {
                    var value  = configuredPrimaryKey == "employeeID" ? item.employeeId : item.email
                    inValidUserData.push({ "email": value, errorObj });
                    removeUserDataFromClone(cloneUserData, item, configuredPrimaryKey);
                }
                else {
                    //Populate the system generated variables for new User
                    
                    if (!userExist) {
                        updateData.userID = utils.uuid();
                        updateData.employee = { employeeID: getEmptyString(item.employeeId) };
                        setObject('profileImages.largeProfile', profilePath + 'largeProfile.png', updateData);
                        setObject('profileImages.mediumProfile', profilePath + 'smallProfile.png', updateData);
                        setObject('profileImages.smallProfile', profilePath + 'thumbnailProfile.png', updateData);
                        updateData.tokenhash = uuid();
                        updateData.companyID = companyID._id;
                        updateData.email = item.email;
                        updateData.first = item.first;
                        updateData.last = getEmptyString(item.last);
                        setObject('employee.department', department, updateData);
                        updateData.office = office;

                    } else {
                        removeUserDataFromClone(cloneUserData, item, configuredPrimaryKey);
                        //userUpdatable = isUserUpdatable(item,userdata,configuredPrimaryKey);
                        if (item.email && item.email != null) {
                            updateData.email = item.email;
                        }
                        if (userExist && item.first && item.first != null) {
                            updateData.first = item.first;
                        }

                        if (userExist && item.last && item.last != null) {
                            updateData.last = item.last;
                        }
                        if (item.employeeId && item.employeeId != null) {
                            updateData.employeeID = item.employeeId;
                        }

                        if (item.department && item.department != null) {
                            setObject('employee.department', department, updateData);
                        }

                        if (item.office && item.office != null) {
                            updateData.office = office;
                        }
                    }
                    setObject('contact.cell', getEmptyString(item.cell), updateData);
                    //To check if the object is updatable
                    if (isUpdate) {
                        validUserData.push(updateData);
                    }
                    counter++;
                }
            }
            console.log(cloneUserData);


            Promise.all([
                removeRecords(cloneUserData, configuredPrimaryKey, companyNo, req),
                saveValidUserDataForUpdate(validUserData, req, configuredPrimaryKey, companyNo)
            ])
                .then((result) => {
                    res.status(200).send({error:  inValidUserData,"failed":inValidUserData.length,"success":validUserData.length,"deleted":cloneUserData.length});
                })
                .catch((err) => {
                    errorMsg = "Error in updating user records";
                    console.log(errorMsg + err);
                    res.status(300).send(errorMsg);
                })

        })
        .catch((err) => {
            console.log(err);
        })
});

function clone(x, type) {
    if (x === null || x === undefined)
        return x;
    if (x.clone)
        return x.clone();
    if (x.constructor == Array) {
        var r = [];
        for (var i = 0, n = x.length; i < n; i++)
            if (type == "employeeID") {
                r.push(x[i].employee.employeeID);
            } else {
                r.push(x[i].email);
            }
        return r;
    }
    return x;
}

function removeUserDataFromClone(cloneuserdata, item, type) {
    if (type == "email") {
        for (var user of cloneuserdata) {
            if (user && item.email == user) {
                var index = cloneuserdata.indexOf(user);
                cloneuserdata.splice(index, 1);
                break;
            }
        }
    } else {
        for (var user of cloneuserdata) {
            if (user && item.employeeId == user) {
                var index = cloneuserdata.indexOf(user);
                cloneuserdata.splice(index, 1);
                break;
            }
        }
    }
}


function removeRecords(cloneUserData, type, companyNo, req) {
    if (cloneUserData.length > 0) {
        var userCollection = req.db.get(companyNo + '-users');
        type == "employeeID" ? userCollection.remove({ 'employee.employeeID': { $in: cloneUserData } }, function () { }) : userCollection.remove({ email: { $in: cloneUserData } }, function () { });
        console.log(cloneUserData.length + "Users Removed");
    }
}

//This function save the valid user data for bulk updatein db
function saveValidUserDataForUpdate(validUserData, req, key, companyNo) {
    if (validUserData.length > 0) {
        var writeArray = updateBulkUser(validUserData, key);
        var userCollection = req.db.get(companyNo + '-users');
        userCollection.bulkWrite(writeArray)
            .then((result) => {
                console.log("User Data updated Successfully");
                //res.status(200).send({error:inValidUserData,"failed":inValidUserData.length,"success":validUserData.length});
            })
            .catch((err) => {
                console.log(err);
                errorMsg = "Error in updating records";
            })
    }
}

//This function set the key and value to the given object
function setObject(path, value, obj) {
    var schema = obj;  // a moving reference to internal objects within obj
    var pList = path.split('.');
    var len = pList.length;
    for (var i = 0; i < len - 1; i++) {
        var elem = pList[i];
        if (!schema[elem]) schema[elem] = {}
        schema = schema[elem];
    }
    schema[pList[len - 1]] = value;
    // console.log(schema);
}

//Find the department object for the given department Name 
//Set the errorObj if department is not found.
function findDepartMent(deptData,department,errorObj){
    var departmentFound = false;
    for(var item of deptData){
        if(utils.compareStrings(item.deptName,department,true,true)){
            delete item._id;
            return item;
        }
    }
    if(!departmentFound){
        errorObj.push({field : "Department", errorMsg : "Not able to find the mentioned department"});
    }

}

//Find the Office object for the given department Name 
//return null department is not found
function findOffice(officeData,officeName,errorObj){
    var officeFound = false;
    for(var item of officeData){
        if(utils.compareStrings(item.name,officeName,true,true)){
            delete item._id;
            officeFound =true;
            return item;
        }
    }
    if(!officeFound){
        errorObj.push({field : "Office", errorMsg : "Not able to find the mentioned office"});
    }

}
//Prepare the Array of objects which will be updated in bulkwrite with updateOne 
function updateBulkUser(updateUserArray, key) {
    var writeArray = [];
    var len = updateUserArray.length;
    if (len == 0) {
        // console.log("0 User Updated");
        return writeArray;
    }
    for (var i = 0; i < len; i++) {
        //var employeeID = updateUserArray[i].employee.employeeID;
        var updateObj = updateUserArray[i];
        if (key == "employeeID") {
            writeArray.push({
                updateOne: {
                    filter: { "employee.employeeID": updateUserArray[i].employee.employeeID },
                    update: { $set: updateObj },
                    upsert: true
                }
            })
        }
        else {
            writeArray.push({
                updateOne: {
                    filter: { "email": updateUserArray[i].email },
                    update: { $set: updateObj },
                    upsert: true
                }
            })
        }

    }

    console.log(len + " Users Updated");
    return writeArray;
    console.log("array" + writeArray);
}


//This function check if user is already exist in the userdata.If found it will populate the error Object sent by caller. 
//It also check if the employee (via employeeID) is already present in the previous bulk records      

function isUserExist(item, userdata, type) {
    var employeeFound = false;
    var object = { update: true, employeeFound: false };
    if (type == "email") {
        for (var user of userdata) {
            if (user.email && item.email == user.email) {
                if (item.first == user.first
                    && item.last == user.last
                    && getEmptyString(item.cell) == user.contact.cell
                    && compareEmployeeId(item.employeeId,user.employee.employeeID)
                    && compareDepartment(user.employee.department, item.department)
                    && compareOffice(user.office, item.office)) {
                    object.update = false
                }

                object.employeeFound = true;
                break;
            }
        }
    } else {
        for (var user of userdata) {
            if (user.employee && user.employee.employeeID && item.employeeId == user.employee.employeeID) {
                if (item.first == user.first
                    && item.last == user.last
                    && compareEmail(item.email,user.email)
                    && getEmptyString(item.cell) == user.contact.cell
                    && compareDepartment(user.employee.department, item.department)
                    && compareOffice(user.office, item.office)) {
                    object.update = false
                }
                object.employeeFound = true;
                break;
            }
        }
    }

    return object;
}

/*function isUserUpdatable(item,userdata,type){
    var employeeUpdatable = true;
    if(type == "email"){
        for (var user of userdata) {
            if(item.email == user.email
                && item.first == user.first 
                && item.last == user.last
                && getEmptyString(item.cell)==user.contact.cell
                && getEmptyString(item.employeeId) == user.employee.employeeID
                && compareDepartment(user.employee.department,item.department)
                && compareOffice(user.office,item.office) ){
                employeeUpdatable = false;
                break;
            }
        }
    } else{
        for (var user of userdata) {
            if(user.employee && user.employee.employeeID 
                && item.employeeId == user.employee.employeeID 
                && item.first == user.first && user.last  
                && item.last == user.last
                && item.email == user.email
                && getEmptyString(item.cell)==user.contact.cell){
                employeeUpdatable = false;
                break;
            }
        }
    }
   
    return employeeUpdatable;
}*/

function compareDepartment(userDepartment, itemDepartment) {

    if (itemDepartment == null) {
        return true;
    } else if (userDepartment == "unassigned" && itemDepartment == "unassigned") {
        return true;
    } else if (userDepartment && userDepartment.deptName && utils.compareStrings(userDepartment.deptName,itemDepartment,true,true)) {
        return true;
    }
    return false;
}

function compareOffice(userOffice, itemOffice) {
    if (itemOffice == null) {
        return true;
    } else if (userOffice == "unassigned" && itemOffice == "unassigned") {
        return true;
    } else if (userOffice && userOffice.name && utils.compareStrings(userOffice.name,itemOffice,true,true)) {
        return true;
    }
    return false;
}

function compareEmployeeId(itemEmployeeId,userEmployeeId){
    if (itemEmployeeId == null || itemEmployeeId =="") {
        return true;
    } else if (userEmployeeId && utils.compareStrings(itemEmployeeId,userEmployeeId,true,true)) {
        return true;
    }
    return false;

}

function compareEmail(itemEmail,userEmail){
    if (itemEmail == null || itemEmail =="") {
        return true;
    } else if (userEmail && utils.compareStrings(itemEmail,userEmail,true,true)) {
        return true;
    }
    return false;

}

function getEmptyString(value) {
    if (value == null) {
        return "";
    }
    return value;
}

module.exports = router;