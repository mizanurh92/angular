var router = require('express').Router();
var authenticate = require('../../.././middleware/authenticate').authenticate;
var utils = require('../../.././utils/utils');
var uuid = utils.uuid;
var config = require('../../.././config/config');
var profilePath = config.profilePath;

router.use('/bulk',require('./bulk/bulkUser'));
router.use('/ad',require('./ad/adIntegrationAPI'));

router.post('/createNewEmployee',authenticate ,(req,res)=>{
	if(req.user){
		var companyNo = req.companyNo;
		var collection = req.db.get(companyNo + '-users');
		var data1 = req.body['data'];
		var data2 = data1[0];
		var data = {
			email:data2.email,
			first:data2.first,
			last:data2.last,
			companyID:req.user.companyID,
			companyStatus:req.user.companyStatus,
			userStatus:"unassigned",
			employee:{
				employeeID:data2.employee.employeeID,
				title:data2.employee.title,
				department:data2.employee.department
			},
			profileImages:{
				largeProfile: profilePath + 'largeProfile.png',
				mediumProfile: profilePath + 'smallProfile.png',
				smallProfile: profilePath + 'thumbnailProfile.png'
			},
			contact:{},
			office:data2.office,
			userID: utils.uuid(),
			tokenhash: utils.uuid()
		}
		collection.insert(data)
			.then((result)=>{
				if(result._id){
					var insertedData = [result];
					res.status(200).send({data:insertedData});
				} else {
					res.status(200).send({data:[]});
				}
			})
			.catch((err)=>{
				console.log(2,err);
				res.status(300).send({data:4});
			})
	} else {
		console.log('sending null')
		res.send({data:null});
	}
})

router.delete('/deleteEmployee',authenticate ,(req,res)=>{
	if(req.user){
		var id = Object.keys(req.query.data)[0];
		if(id == req.user.userID){ // Ensures the user can't delete their own account
			console.log("same id")
			res.status(300).send({data:4});
		} else{
			var data = req.query.data[id];
			var companyNo = req.companyNo;			
			var userCollection = req.db.get(companyNo + '-users');
			userCollection.remove({userID:data.userID})
				.then((result)=>{
					console.log(result)
					res.status(300).send({});
				})
				.catch((err)=>{
					console.log(2,err);
					res.status(300).send({data:4});
				})
		}
	} else {
		console.log('sending null')
		res.send({data:null});
	}
})

router.put('/editEmployee',authenticate ,(req,res)=>{
	delete req.body.action;
	var data = utils.unflatten(req.body);
	if(req.user){
	 	var id = Object.keys(data.data)[0];
		var companyNo = req.companyNo;
		var userCollection = req.db.get(companyNo + '-users');
		userCollection.findOneAndUpdate(
			{userID:id},
			{$set:data.data[id]}
		)
		.then((result)=>{
			console.log('result',result)
			delete result.password;
			delete result.tokenhash;
			delete result.userStatus;
			delete result._id;
			delete result.userType;
			result.profile = result.profileImages.smallProfile;
			result.seats = [];
			var insertedData = [result];
			res.status(200).send({data:insertedData});
		})
		.catch((err)=>{
			console.log(2,err);
			res.status(300).send({data:4});
		})
	} else {
	 	console.log('sending null')
	 	res.send({data:null});
	}
})

router.get('/profileData',authenticate,(req,res)=>{
	if(req.user){
		var companyNo = req.companyNo;
		var userID = req.user.userID;
		var usersCollection = req.db.get(companyNo + '-users');

		usersCollection.find({userID},{fields:{_id:0,password:0}})
		.then((result)=>{
			var user = result[0];
			var profile = {
				first: user.first || "",
				last: user.last || "",
				email: user.email || "",
				cell: user.cell || "",
				officePhone: user.officePhone || "",
				title: user.employee && user.employee.title || "",
				dept: user.employee && user.employee.department && user.employee.department.name || "",
				employeeID: user.employee && user.employee.employeeID || "",
				acctType: user.userType || "",
				office: user.office && user.office.name || ""
			}
			res.status(200).send(profile);
		})
		.catch((err)=>{
			console.log(err);
			res.status(300).send();
		})
	} else {
		res.status(498).send();
	}
})

router.get('/userProfileData',authenticate,(req,res)=>{
	if(req.user){
		var companyNo = req.companyNo;
		var userID = req.query.userID;
		var usersCollection = req.db.get(companyNo + '-users');
		var deptCollection = req.db.get(companyNo + '-departments');
		var officeCollection = req.db.get(companyNo + '-offices');

		Promise.all([
			usersCollection.find({userID},{fields:{_id:0,password:0}}),
			deptCollection.find({active:true},{fields:{_id:0,deptID:1,deptName:1}}),
			officeCollection.find({status:"active"},{fields:{_id:0,officeID:1,name:1}})
		])
		.then((results)=>{
			console.log(results)
			var user = results[0][0];
			var departments = results[1];
			var offices = results[2];
			var deptObj = {};
			var department;
			for(var i in departments){
				department = departments[i];
				deptObj[department.deptID] = department.deptName;
			}
			var officeObj = {};
			var office;
			for(var i in offices){
				office = offices[i];
				officeObj[office.officeID] = office.name;
			}
			var acctTypes = [
				'user',
				'manager',
				'company admin',
				'admin'
			]
			var profile = {
				first: user.first || "",
				last: user.last || "",
				email: user.email || "",
				cell: user.cell || "",
				officePhone: user.officePhone || "",
				title: user.employee && user.employee.title || "",
				deptID: user.employee && user.employee.department && user.employee.department.deptID || "00000",
				employeeID: user.employee && user.employee.employeeID || "",
				acctType: user.userType || "",
				officeID: user.office && user.office.officeID || "",
				departments: deptObj,
				offices: officeObj,
				acctTypes
			}
			res.status(200).send(profile);
		})
		.catch((err)=>{
			console.log(err);
			res.status(300).send();
		})
	} else {
		res.status(498).send();
	}
})

router.post('/profileData',authenticate,(req,res)=>{
	if(req.user){
		var companyNo = req.companyNo;
		var userID = req.query.userID;
		var usersCollection = req.db.get(companyNo + '-users');
		var deptCollection = req.db.get(companyNo + '-departments');
		var officeCollection = req.db.get(companyNo + '-offices');
		var data = req.body;

		var departments, department, offices, office;

		Promise.all([
			deptCollection.find({deptID:data.dept},{fields:{_id:0,deptName:1}}),
			officeCollection.find({officeID:data.office},{fields:{_id:0,name:1}})
		])
		.then((results)=>{
			departments = results[0];
			offices = results[1];
			
			// Shouldn't happen under normal circumstances, but if the officeID or deptID was
			// changed by the user, or if either were removed since the user populated the list
			// then an error should be thrown to cancel the update.
			if(departments.length == 0 || offices.length == 0){
				throw "Invalid Department of Office";
			}

			department = departments[0].deptName;
			office = offices[0].name;

			return usersCollection.update({userID:data.userID},{$set:{
				email: data.email,
				first: data.firstName,
				last: data.lastName,
				cell: data.cell,
				officePhone: data.officePhone,
				userType: data.acctType,
				employee: {
					employeeID: data.empID,
					title: data.title,
					department: {
						name: department,
						deptID: data.dept
					}
				},
				office: {
					name: office,
					officeID: data.office
				}
			}})
		})
		.then((results)=>{
			console.log(results);
			res.status(200).send();
		})
		.catch((err)=>{
			console.log(err);
			res.status(300).send();
		})

	} else {
		res.status(498).send();
	}
})

router.get('/preferences',authenticate,(req,res)=>{
	if(req.user){
		var companyNo = req.companyNo;
		var userID = req.query.userID || req.user.userID;
		var usersCollection = req.db.get(companyNo + '-users');

		usersCollection.find({userID},{fields:{kioskSearchable:1,contactable:1,codeRequired:1}})
		.then((result)=>{
			var user = result[0];
			console.log(user)
			var profile = {
				searchable: user.kioskSearchable || false,
				contactable: user.contactable || false,
				codeRequired: user.codeRequired || false,
			}
			res.status(200).send(profile);
		})
		.catch((err)=>{
			console.log(err);
			res.status(300).send();
		})
	} else {
		res.status(498).send();
	}
})

router.post('/preferences',authenticate,(req,res)=>{
	if(req.user){
		var companyNo = req.companyNo;
		var userID = req.body.userID || req.user.userID;
		var usersCollection = req.db.get(companyNo + '-users');
		var data = req.body;
		var field;
		var value;
		for(var i in data){
			if(i == 'userID'){continue;}
			field = i;
			value = data[i] == 'true';
			data[i] = value;
		}
		var projection = {};
		projection[field] = true;

		usersCollection.findOneAndUpdate({userID},{$set:data},{projection})
		.then((result)=>{
			res.status(200).send(result[field]);
		})
		.catch((err)=>{
			console.log(err);
			res.status(300).send(!value);
		})
	} else {
		res.status(498).send();
	}
})

module.exports = router;