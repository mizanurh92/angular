var router = require('express').Router();
var utils = require('../../../.././utils/utils');
var uuid = utils.uuid;
var config = require('../../../.././config/config');
var profilePath = config.profilePath;
var authenticate = require('../../../.././middleware/authenticate').authenticate;
var validator = require('./bulkUserValidator');
var credential = require('credential');
var pw = credential();

//Rest Api  handles the add bulk user records.
router.post('/addBulkUser',authenticate,(req,res)=>{
    console.log("Bulk User add");
    var bulkAddUserData = JSON.parse(req.body.data); // Parse the Json data coming from UI
    var companyNo = req.companyNo;    
    var validUserData = []; //To store the valid user record 
    var inValidUserData = []; //To store the invalid user records
    var userdata = []; // To store the fetched userdata from the database.It will contain all the users with valid employeeId
    var deptData = []; //to store the fetched department data from the database. It will contain all the departments 
    var employeeIDArray = []; //To store the employeeId sent via bulk records,to check if thier is no duplicate employeeId present. 
    var userCollection = req.db.get(companyNo + '-users'); //Fetch the user data from db
    var departmentsCollection = req.db.get(companyNo + '-departments'); //Fetch the dept data from db.
    var officeCollection = req.db.get(companyNo + '-offices'); //Fetch the offices data from db
    var counter = 1; // Counter variable to sent the recordNumber in the errorLogs back to the UI.
    var user = req.user; //For error logging  
    var officeData = [];
    var passwordArr = [];
    Promise.all([
        officeCollection.find({},{fields:{officeID:1,name:1}}),
        departmentsCollection.find({}),
        userCollection.find({"employee":{ $exists: true }},{fields:{"employee.employeeID":1}})
    ])
    .then((results)=>{
        officeData = results[0];
        deptData = results[1]; 
        userdata = results[2];    
        
    for(var item of bulkAddUserData) {
            var errorObj = validator.validateAddUser(item);
            var office = "unassigned"; //As per document TBD.
            var department = "unassigned"; // By default department value is unassigned.
            validateUserAlreadyExist(item,userdata,errorObj,employeeIDArray);
            if(item.Department && item.Department!="unasssigned"){
                tempdepartment = findDepartMent(deptData,item.Department,errorObj) ;
                department = tempdepartment ? tempdepartment : department;
            }

            if(item.Office){
                tempOffice = findOffice(officeData,item.Office,errorObj) ;
                office = tempOffice ? tempOffice : tempOffice;
            }

            if(errorObj && errorObj.length > 0){
                inValidUserData.push({"RecordNum":counter,"employeeID":utils.setBlankValue(item.EmployeeID),errorObj});
            }else{
                var passData=null;                 
                var data = {
                        email:item.Email,
                        first:item.First,
                        last:(item.Last?item.Last :""),
                        tokenhash: uuid(),
                        companyID:req.user.companyID,
                        companyStatus:req.user.companyStatus,
                        contact:{
                            cell:(item.Cell?item.Cell:"")
                        },
                        userStatus:item.UserStatus,
                        userType: item.UserType,
                        employee:{
                            employeeID:item.EmployeeID,
                            title:item.Title?item.Title:"",
                            department:department
                        },
                        profileImages:{
                            largeProfile: profilePath + 'largeProfile.png',
                            mediumProfile: profilePath + 'smallProfile.png',
                            smallProfile: profilePath + 'thumbnailProfile.png'
                        },
                        office:item.Office?office:null, 
                        userID:uuid(),
                        contactable: item.Contactable?item.Contactable:"",
                        codeRequired:item.CodeRequired?item.CodeRequired:null,
                    };
                    if(item.Password){
                       passwordArr.push(new Promise (function(resolve, reject){
                            pw.hash(item.Password,function(err, hash){
                                if(err){
                                console.log(err, hash);
                                reject(err);
                                }else{
                                    var passObj = {};
                                    passObj.password = JSON.parse(hash);
                                    resolve(passObj);
                                }
                            });
                        }));
                        data.password = item.Password;
                    }else{
                        data.password = null;
                    }
                validUserData.push(data);
                }
                counter++;
        }
        Promise.all(
            passwordArr
        ).then((result)=>{
            console.log(result);
            savePassword(validUserData,result);
            Promise.all([
               
                saveValidUserData(validUserData,req)
            ])
            .then((result)=>{
                res.status(200).send({error:inValidUserData,"failed":inValidUserData.length,"success":validUserData.length});
            })
            .catch((err)=>{
                console.log('Error in saving records')
                errorMsg = "Error in saving user records";
                res.status(300).send(errorMsg);
            })
        }).catch((err)=>{
            console.log('Error in saving records')
            errorMsg = "Error in saving user records";
            res.status(300).send(errorMsg);
        })
    })
    .catch((err)=>{
        console.log(err);        
    })
});


function savePassword(validUserData,result) {
    var counter = 0;
    for(let i = 0 ;i<validUserData.length;i++){
        if(validUserData[i].password!=null){
            validUserData[i].password = result[counter].password;
            counter++;
        }
    }
    
}

//Rest Api for bulk update operation 
router.post('/updateBulkUser',authenticate,(req,res)=>{
    console.log("Bulk Update User");
    var bulkAddUserData = JSON.parse(req.body.data);
   
    var companyNo = req.companyNo;
    var validUserData = [];//To store the valid user record 
    var inValidUserData = [];//To store the invalid user records
    var counter = 1; // Counter variable to sent the recordNumber in the errorLogs back to the UI.
    var user = req.user; //For error logging 
    var userdata = []; // To store the fetched userdata from the database.It will contain all the users with valid employeeId
    var deptData = []; //to store the fetched department data from the database. It will contain all the departments 
    var officeData = [];
    var passwordArr = [];
    var userCollection = req.db.get(companyNo + '-users'); //Fetch the user data from db
    var departmentsCollection = req.db.get(companyNo + '-departments'); //Fetch the dept data from db.
    var officeCollection = req.db.get(companyNo + '-offices'); //Fetch the offices data from db
    Promise.all([
        officeCollection.find({},{fields:{officeID:1,name:1}}),
        departmentsCollection.find({}),
        userCollection.find({"employee":{ $exists: true }},{fields:{"employee.employeeID":1}})
    ])
    .then((results)=>{
        officeData = results[0];
        deptData = results[1]; 
        userdata = results[2];  
        for(var item of bulkAddUserData) {
            var userExist= isUserExist(item,userdata);
            var errorObj = userExist ? validator.validateUpdateUser(item) : validator.validateAddUser(item);  
            if(item.Department && item.Department!="unasssigned"){
                tempdepartment = findDepartMent(deptData,item.Department,errorObj) ;
                department = tempdepartment ? tempdepartment : department;   
            }
            if(item.Office){
                tempOffice = findOffice(officeData,item.Office,errorObj) ;
                office = tempOffice ? tempOffice : tempOffice;
            }

            if(errorObj.length > 0){
                inValidUserData.push({"RecordNum":counter,"employeeID":utils.setBlankValue(item.EmployeeID),errorObj});
            }else{
                var updateData ={}; //update object prepared for updating the record in db.
                var office = "unassigned"; //As per document TBD.
                var department = "unassigned"; // By default department value is unassigned.
                updateData.employee = { employeeID:item.EmployeeID};
                setObject('employee.department' ,department,updateData);
                updateData.office = office;
                //Populate the system generated variables for new User
                if(!userExist){
                    updateData.userID = utils.uuid();
                    setObject('profileImages.largeProfile' ,profilePath + 'largeProfile.png',updateData);
                    setObject('profileImages.mediumProfile' ,profilePath + 'smallProfile.png',updateData);
                    setObject('profileImages.smallProfile' ,profilePath + 'thumbnailProfile.png',updateData);
                    updateData.tokenhash = uuid();
                    updateData.companyID = req.user.companyID;
                    updateData.companyStatus = req.user.companyStatus;
                }
                if(item.Email){
                    updateData.email = item.Email;
                }
                if(item.First){
                    updateData.first = item.First;
                }
                if(item.Last){
                    updateData.last = item.Last;
                }
                if(item.Cell){
                    setObject('contact.cell' ,item.Cell,updateData);
                }
                if(item.UserStatus){
                    updateData.userStatus = item.UserStatus;
                }    
                if(item.UserType){
                    updateData.userType = item.UserType;
                }  
                if(item.Title){
                    setObject('employee.title' ,item.Title,updateData);
                }
                if(item.CodeRequired){
                    updateData.codeRequired = item.CodeRequired;
                } 
                if(item.Contactable){
                    updateData.contactable = item.contactable;
                } 
                if(item.Password){
                    passwordArr.push(new Promise (function(resolve, reject){
                         pw.hash(item.Password,function(err, hash){
                             if(err){
                                 //console.log(err, data);
                             reject(err);
                             }else{
                                 var passObj = {};
                                 passObj.password = JSON.parse(hash);
                                 resolve(passObj);
                             }
                         });
                     }));
                     updateData.password = item.Password;
                 }else{
                    updateData.password = null;
                 }    
                    //office:item.office
                validUserData.push(updateData);
            }
            counter++;
        }
        Promise.all(
            passwordArr
        ).then((result)=>{
            console.log(result);
            savePassword(validUserData,result);
            Promise.all([
                
                saveValidUserDataForUpdate(validUserData,req)
            ])
            .then((result)=>{
                res.status(200).send({error:inValidUserData,"failed":inValidUserData.length,"success":validUserData.length});
            })
            .catch((err)=>{
                console.log('Error in updating records :: '+ err);
                errorMsg = "Error in updating user records";
                res.status(300).send(errorMsg);
            })
        }).catch((err)=>{
            console.log('Error in updating records ::' + err);
            errorMsg = "Error in updating user records";
            res.status(300).send(errorMsg);
        })
    })
    .catch((err)=>{
        console.log(err);        
    })
});

//This function save the valid user data for bulk add to the Db.
function saveValidUserData(validUserData,req){
    if(validUserData.length > 0 ){
        var writeArray = addBulkUser(validUserData);
        var tempUsercollection = req.db.get(req.companyNo + '-users');	
        tempUsercollection.bulkWrite(writeArray)
        .then((result)=>{
            console.log("User Data saved Successfully");
        })
        .catch((err)=>{
            console.log(err);
        })
    }
}

//This function save the valid user data for bulk updatein db
function saveValidUserDataForUpdate(validUserData,req){
    if(validUserData.length >0 ){
        var writeArray = updateBulkUser(validUserData);
        var userCollection = req.db.get(req.companyNo + '-users');
        userCollection.bulkWrite(writeArray)
        .then((result)=>{
            console.log("User Data updated Successfully");
            //res.status(200).send({error:inValidUserData,"failed":inValidUserData.length,"success":validUserData.length});
        })
        .catch((err)=>{
            console.log(err);
            errorMsg = "Error in updating records";
            //res.status(300).send(errorMsg);
        })
    }
}

//This function set the key and value to the given object
function setObject(path, value,obj) {
    var schema = obj;  // a moving reference to internal objects within obj
    var pList = path.split('.');
    var len = pList.length;
    for(var i = 0; i < len-1; i++) {
        var elem = pList[i];
        if( !schema[elem] ) schema[elem] = {}
        schema = schema[elem];
    }
    schema[pList[len-1]] = value;
    console.log(schema);
}

//Find the department object for the given department Name 
//Set the errorObj if department is not found.
function findDepartMent(deptData,department,errorObj){
    var departmentFound = false;
    for(var item of deptData){
        if(utils.compareStrings(item.deptName,department,true,true)){
            delete item._id;
            return item;
        }
    }
    if(!departmentFound){
        errorObj.push({field : "Department", errorMsg : "Not able to find the mentioned department"});
    }

}

//Find the Office object for the given department Name 
//return null department is not found
function findOffice(officeData,officeName,errorObj){
    var officeFound = false;
    for(var item of officeData){
        if(utils.compareStrings(item.name,officeName,true,true)){
            delete item._id;
            officeFound =true;
            return item;
        }
    }
    if(!officeFound){
        errorObj.push({field : "Office", errorMsg : "Not able to find the mentioned office"});
    }

}

//Prepare the Array of objects which will be updated in bulkwrite with updateOne 
function updateBulkUser(updateUserArray){
    var writeArray = [];
	var len = updateUserArray.length;
	if(len == 0){
		console.log("0 User Updated");
		return writeArray;
    }
	for(var i = 0;i < len;i++){
        var employeeID = updateUserArray[i].employee.employeeID;
        //delete updateUserArray[i].employee.employeeID
        var updateObj = updateUserArray[i];
		writeArray.push({
			updateOne: {
				filter: {"employee.employeeID":employeeID},
                //update: $set:updateObj,
                update: {$set: updateObj},
                upsert: true
			}
		})
	}

	console.log(len+" Users Updated");
	return writeArray;
}


// Prepare the array of valid user data for database insertions.
function addBulkUser(data){
	var writeArray = [];
	var len = data.length;
	if(len == 0){
		console.log("0 Users Added");
		return writeArray;
	}
	for(var i = 0;i < len; i++){
		writeArray.push({insertOne:{document:data[i]}});
	}
	console.log(len+" Users Added");
	return writeArray;
}

//This function check if user is already exist in the userdata.If found it will populate the error Object sent by caller. 
//It also check if the employee (via employeeID) is already present in the previous bulk records      
function validateUserAlreadyExist(item,userdata,errorObj,employeeIDArray) {
    var employeeFound = isUserExist(item,userdata);
    if(employeeFound){
        errorObj.push({field : "employeeID", errorMsg : "Duplicate EmployeeID"});
    }
    else if(!employeeFound){
        //Check if the same employee is thier in current bulk records  
        for (var employeeId of employeeIDArray) {
            if(employeeId == item.EmployeeID){
                errorObj.push({field : "employeeID", errorMsg : "Employee ID is already present in another record"});
                employeeFound = true;
                break;
            }
        }
    }
    if(!employeeFound && item.EmployeeID){
        employeeIDArray.push(item.EmployeeID);
    }
}

function isUserExist(item,userdata){
    var employeeFound = false;
    for (var user of userdata) {
        if(user.employee && user.employee.employeeID && item.EmployeeID == user.employee.employeeID){
            employeeFound = true;
            break;
        }
    }
    return employeeFound;
}


module.exports = router;