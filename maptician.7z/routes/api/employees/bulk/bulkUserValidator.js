var Joi = require('joi');

var addschema = {
    First: Joi.string().max(35).required().regex(/^[ A-Za-z’'-]+$/i).options({
        language: {
            string: {
                regex: {
                    base: ' should be limited to letters and special characters ‘ and –  '
                },
                max: ' should be limited to 35 characters'
            }, // Custom error message
            any: { required: ' is required' }
        }
    }), //First name is required cannot be greater than 35 character and should conatin only number and special character
    Last: Joi.string().optional().allow("").regex(/^[ A-Za-z’'-]+$/i).max(35).options({
        language: {
            string: {
                regex: {
                    base: ' should be limited to letters and special characters ‘ and – '
                },
                max: ' should be limited to 35 characters'
            } // Custom error message
        }
    }).allow(""), //Last cannot be greater than 35 character and should conatin only number and special character  
    Email: Joi.string().max(254).required().regex(/^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/).options({
        language: {
            string: {
                regex: {
                    base: ' should be valid '
                },
                max: ' should be limited to 254 characters'
            },
            any: { required: ' is required' } // Custom error message
        }
    }), //Email is required 
    UserStatus: Joi.string().required().alphanum().max(35).options({
        language: {
            string: {
                max: ' should be limited to 35 characters'
            } // Custom error message
        }
    }),//userstatus is required and aplhanumeric
    UserType: Joi.string().required().alphanum().max(35).options({
        language: {
            string: {
                max: ' should be limited to 35 characters'
            } // Custom error message
        }
    }), // usertype is required ,this is a free-text field limited to 35 alpha-numeric characters
    Password: Joi.string().when('UserStatus', {
        is: 'active', then: Joi.required().options({
            language: {
                any: { required: ' is mandatory if userStatus is active' }
            }
        }), otherwise: Joi.optional().allow("")
    }),
    CodeRequired: Joi.boolean().allow(""),
    Contactable: Joi.boolean().allow(""),
    EmployeeID: Joi.string().required().regex(/^[A-Za-z0-9'-]*$/).options({
        language: {
            string: {
                regex: {
                    base: ' should be limited to numbers, letters and special characters ‘ and –'
                }
            } // Custom error message
        }
    }),
    Cell: Joi.string().regex(/^[0-9]{10}$/).options({
        language: {
            string: {
                regex: {
                    base: ' number should be 10 digits'
                }
            } // Custom error message
        }
    }).allow(""),
    Title: Joi.string().max(35).regex(/^[ A-Za-z0-9’'-]*$/).options({
        language: {
            string: {
                regex: {
                    base: ' should be limited to 35 alpha-numeric characters plus ‘ and – '
                }
            } // Custom error message
        }
    }).allow(""),
    Department: Joi.string().optional().allow(""),
    Office: Joi.string().optional().allow("")
};

var updateschema = {
    First: Joi.string().regex(/^[ A-Za-z’'-]+$/i).max(35).options({
        language: {
            string: {
                regex: {
                    base: ' should be limited to letters and special characters  '
                },
                max: ' should be limited to 35 characters'
            } // Custom error message
        }
    }), //First name is required cannot be greater than 35 character and should conatin only number and special character
    Last: Joi.string().regex(/^[ A-Za-z’'-]*$/).max(35).options({
        language: {
            string: {
                regex: {
                    base: ' should be limited to letters and special characters  '
                },
                max: ' should be limited to 35 characters'
            } // Custom error message
        }
    }).allow(""), //Last cannot be greater than 35 character and should conatin only number and special character 
    Email: Joi.string().max(254).regex(/^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/).options({
        language: {
            string: {
                regex: {
                    base: ' should be valid '
                },
                max: ' should be limited to 254 characters'
            } // Custom error message
        }
    }).not(""), //Email is required  
    UserStatus: Joi.string().alphanum().max(35).not("").optional().options({
        language: {
            string: {
                max: ' should be limited to 35 characters'
            } // Custom error message
        }
    }),//userstatus is optional for update requirement,
    CodeRequired: Joi.boolean().allow("").optional(),
    Contactable: Joi.boolean().allow("").optional(),
    EmployeeID: Joi.string().required().regex(/^[A-Za-z0-9'-]*$/).options({
        language: {
            string: {
                regex: {
                    base: ' should be limited to numbers, letters and special characters ‘ and –'
                }
            } // Custom error message
        }
    }),
    UserType: Joi.string().alphanum().max(35).not("").optional().options({
        language: {
            string: {
                max: ' should be limited to 35 characters'
            } // Custom error message
        }
    }),//UserType is optional and aplhanumeric,
    Cell: Joi.string().regex(/^[0-9]{10}$/).options({
        language: {
            string: {
                regex: {
                    base: ' number should be valid 10 digit character'
                }
            } // Custom error message
        }
    }).allow("").optional(),
    Title: Joi.string().max(35).regex(/^[ A-Za-z0-9’'-]*$/).options({
        language: {
            string: {
                regex: {
                    base: ' should be limited to 35 alpha-numeric characters plus ‘ and – '
                }
            } // Custom error message
        }
    }).allow("").optional(),
    Department: Joi.string().optional().allow("").optional(),
    Office: Joi.string().optional().allow("").optional(),
    Password: Joi.string().optional().allow("").optional()
};


var adintegrationschema = {
    first: Joi.string().regex(/^[ A-Za-z’'-]+$/i).max(35).options({
        language: {
            string: {
                regex: {
                    base: ' should be limited to letters and special characters ‘ and –  '
                },
                max: ' should be limited to 35 characters'
            } // Custom error message
        }
    }), //First name is required cannot be greater than 35 character and should conatin only number and special character
    last: Joi.string().regex(/^[ A-Za-z’'-]*$/).max(35).options({
        language: {
            string: {
                regex: {
                    base: ' should be limited to letters and special characters ‘ and –  '
                },
                max: ' should be limited to 35 characters'
            } // Custom error message
        }
    }).allow(""), //Last cannot be greater than 35 character and should conatin only number and special character 
    email: Joi.string().max(254).regex(/^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/).options({
        language: {
            string: {
                regex: {
                    base: ' should be valid '
                },
                max: ' should be limited to 254 characters'
            } // Custom error message
        }
    }).allow(null).optional(), //Email is required  
    employeeId: Joi.string().optional().regex(/^[A-Za-z0-9'-]*$/).options({
        language: {
            string: {
                regex: {
                    base: ' should be limited to numbers, letters and special characters ‘ and –'
                }
            } // Custom error message
        }
    }).allow(null),
    cell: Joi.string().regex(/^[0-9]{10}$/).options({
        language: {
            string: {
                regex: {
                    base: ' number should be valid 10 digit character'
                }
            } // Custom error message
        }
    }).allow("").optional().allow(null),
    department: Joi.string().optional().allow("").optional().allow(null),
    office: Joi.string().optional().allow("").optional().allow(null)
};

function validateAddUser(item) {
    var errorObj = [];
    var err = Joi.validate(item, addschema, { abortEarly: false });
    if (err.error != null) {
        for (var i in err.error.details) {
            errorObj.push({ field: err.error.details[i].path[0], errorMsg: replaceWithUserFriendlyString(err.error.details[i].message) });
        }
    }
    return errorObj;
}

//var validateUpdateUser = (item) => {
function validateUpdateUser(item) {
    var errorObj = [];
    var err = Joi.validate(item, updateschema, { abortEarly: false });
    if (err.error != null) {
        for (var i in err.error.details) {
            errorObj.push({ field: err.error.details[i].path[0], errorMsg: replaceWithUserFriendlyString(err.error.details[i].message) });
        }
    }
    return errorObj;
}


//var validateUpdateUser = (item) => {
function validateAdIntegrationUser(item) {
    var errorObj = [];
    var err = Joi.validate(item, adintegrationschema, { abortEarly: false });
    if (err.error != null) {
        for (var i in err.error.details) {
            errorObj.push({ field: err.error.details[i].path[0], errorMsg: err.error.details[i].message });
        }
    }
    return errorObj;
}


//To make user friendly error messages 
function replaceWithUserFriendlyString(errorString) {
    var tempString = (errorString.split(" ")[0]).replace(/["']/g, "");
    if (tempString == "EmployeeID") {
        tempString = "Employee ID"
        return errorString.replace(/^\S+/g, tempString);
    }
    else if (tempString == "UserType") {
        tempString = "User Type"
        return errorString.replace(/^\S+/g, tempString);
    }
    else if (tempString == "UserStatus") {
        tempString = "User Status"
        return errorString.replace(/^\S+/g, tempString);
    }
    else if (tempString == "First") {
        tempString = "First Name"
        return errorString.replace(/^\S+/g, tempString);
    }
    else if (tempString == "Last") {
        tempString = "Last Name"
        return errorString.replace(/^\S+/g, tempString);
    }
    else if (tempString == "Email") {
        tempString = "Email ID"
        return errorString.replace(/^\S+/g, tempString);
    }
    return errorString.replace(/["']/g, "");
}

module.exports.validateAddUser = validateAddUser;
module.exports.validateUpdateUser = validateUpdateUser;
module.exports.validateAdIntegrationUser = validateAdIntegrationUser;