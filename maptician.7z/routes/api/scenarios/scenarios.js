var router = require('express').Router();
var authenticate = require('../../.././middleware/authenticate').authenticate;
var utils = require('../../.././utils/utils');
var mapSaveFunctions = require('../../.././utils/mapSaveFunctions');
var saveMapFile = mapSaveFunctions.saveMapFile;
var saveScenarioFile = mapSaveFunctions.saveScenarioFile;
var saveMapSeats = mapSaveFunctions.saveMapSeats;
var saveMapZones = mapSaveFunctions.saveMapZones;
var saveMapRooms = mapSaveFunctions.saveMapRooms;
var saveMapSeatAssignments = mapSaveFunctions.saveMapSeatAssignments;
var updateChangeLogs = mapSaveFunctions.updateChangeLogs;

router.post('/saveScenario', authenticate, function(req,res){
	if(req.user){
		var data = JSON.parse(req.body.data);
		data.date = new Date().getTime();
		data.companyID = req.user.companyID;
		saveScenarioFile(data,req)
			.then((result)=>{
				console.log('Scenario Save Successful');
				res.status(200).send({data:1});
			})
			.catch((err)=>{
				console.log('Error in scenario save',err)
				res.status(300).send({data:2});
			})
	} else {
		res.status(498).send();
	}
})

router.get('/loadScenarioFileList',authenticate,function(req,res){
	console.log('loading scenario file list');
	if(req.user){
		var companyNo = req.companyNo;
		var scenarioCollection = req.db.get(companyNo + '-scenarios');
		var mapID = req.query.id;
		var scenarioArray = [];
		var scenario,scenarioID;

		scenarioCollection.find({id:mapID},{fields:{_id:0,id:1,scenarioID:1,scenarioName:1,date:1,settings:1,connections:1}})
		.then((scenarios)=>{
			for(var i = 0;i < scenarios.length; i++){
				scenario = scenarios[i];
				scenarioID = scenario.scenarioID;
				scenarioArray.push({
					scenarioID,
					scenarioName: scenario.scenarioName,
					mapID: scenario.id,
					mapName: scenario.settings.mapName,
					date: scenario.date,
					seats: Object.keys(scenario.connections.seats).length
				})
			}
			res.send({data:scenarioArray});
		})
		.catch((err) => {
			console.log(err)
			res.send({data:null});
		})
	} else {
		
		res.status(498).send();
	}
})

router.get('/loadScenarioFile',authenticate,function(req,res){
	console.log('loading scenario file');
	if(req.user){
		var companyNo = req.companyNo;
		var scenarioCollection = req.db.get(companyNo + '-scenarios');
		scenarioID= req.query.scenarioID;

		scenarioCollection.find({scenarioID})
		.then((scenario)=>{
			res.send(scenario[0]);
		})
		.catch((err) => {
			console.log(err)
			res.send({data:null});
		})
	} else {
		res.status(498).send();
	}
})

// Used to create the scenario list report in the scenario menu
router.get('/loadScenarioList',authenticate,function(req,res){
	console.log('loading scenario list');
	if(req.user){
		var companyNo = req.companyNo;
		var scenarioCollection = req.db.get(companyNo + '-scenarios');
		var officeCollection = req.db.get(companyNo + '-offices');
		var mapID = req.query.id;
		var scenarioArray = [];
		var scenarios,scenario,scenarioID,offices,office,officeID;
		var officeObj = {};

		Promise.all([
			scenarioCollection.find({},{fields:{_id:0,id:1,scenarioID:1,scenarioName:1,date:1,settings:1,connections:1}}),
			officeCollection.find({},{fields:{officeID:1,name:1}})
		])
		
		.then((results)=>{
			scenarios = results[0];
			offices = results[1];
			for(var i = 0; i < offices.length; i++){
				office = offices[i];
				officeObj[office.officeID] = office.name;
			}
			for(var i = 0;i < scenarios.length; i++){
				scenario = scenarios[i];
				scenarioID = scenario.scenarioID;
				officeID = scenario.settings.officeID;
				scenarioArray.push({
					scenarioID,
					scenarioName: scenario.scenarioName,
					mapID: scenario.id,
					mapName: scenario.settings.mapName,
					officeID,
					officeName: officeObj[officeID],
					date: scenario.date,
					seats: scenario.connections.seats,
					rooms: scenario.connections.rooms,
					zones: scenario.connections.zones,
					assignments: scenario.connections.seatAssignments
				})
			}
			res.send({data:scenarioArray});
		})
		.catch((err) => {
			console.log(err)
			res.send({data:null});
		})
	} else {
		res.status(498).send();
	}
})

router.post('/implementScenario',authenticate,function(req,res){
	console.log('implementing scenario file');
	if(req.user){
		var companyNo = req.companyNo;
		var scenarioCollection = req.db.get(companyNo + '-scenarios');
		var data = JSON.parse(req.body.data);
		data.date = new Date().getTime();
		data.companyID = req.user.companyID;
		var scenarioID = data.scenarioID;
		var mapID = data.id;
        var returnData = {
            id:mapID,
            date:data.date
            }
		Promise.all([
				saveMapFile(data,req),
				saveMapSeats(data,req),
				saveMapZones(data,req),
				saveMapRooms(data,req),
				saveMapSeatAssignments(data,req),
				scenarioCollection.remove({scenarioID})
			])
			.then((result)=>{
				console.log('Save Successful');
				return updateChangeLogs(data,req);
			})
			.then((results)=>{
				console.log('Change logs updated');
				res.status(200).send(returnData);
			})
			.catch((err)=>{
				console.log('Error in save file',err)
				res.status(300).send({data:2});
			})
	} else {
		res.status(498).send();
	}
})

module.exports = router;