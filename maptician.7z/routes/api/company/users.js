var router = require('express').Router();
var authenticate = require('../../.././middleware/authenticate').authenticate;
var utils = require('../../.././utils/utils');
var moment = require('moment');

// User in the user management list to populate department and office options when creating/modifying a user
router.get('/selectList',authenticate,(req,res)=>{
	if(req.user){
		var companyNo = req.companyNo;		
		var departmentCollection = req.db.get(companyNo + '-departments');
		var officeCollection = req.db.get(companyNo + '-offices');
		Promise.all([
			departmentCollection.find(),
			officeCollection.find()
		])
		.then((result)=>{
			var departments = result[0];
			var offices = result[1];
			var deptArray = [];
			var officeArray = [];
			for(var i in departments){
				deptArray.push({
					label: departments[i].deptName,
					value: {
						name: departments[i].deptName,
						deptID: departments[i].deptID
					}
				})
			}
			for(var i in offices){
				officeArray.push({
					label: offices[i].name,
					value: {
						name: offices[i].name,
						officeID: offices[i].officeID
					}
				})
			}
			res.send({departments:deptArray,offices:officeArray});
		})
	} else {
	 	console.log('sending null')
	 	res.send({data:null});
	}
})

router.get('/userList',authenticate,(req,res)=>{
	if(req.user){
		var companyNo = req.companyNo;
		var userCollection = req.db.get(companyNo + '-users');
		var seatAssignmentCollection = req.db.get(companyNo + '-seat-assignments');
		var seatCollection = req.db.get(companyNo + '-seats');
		var companyID = req.user.companyID;
		Promise.all([
			userCollection.find({userID:{ $exists: true }},{fields:{_id:0,email:1,office:1,userID:1,first:1,last:1,employee:1,'profileImages.smallProfile':1}}),
			seatCollection.find({},{fields:{seatID:1,seatName:1,mapName:1}}),
			seatAssignmentCollection.find({})
		])
		.then((docs)=>{
			var users = docs[0];
			var seats = docs[1];
			var assignments = docs[2];
			var userObject = {};
			var seatObject = {};
			var userArray = [];
			var user,userID,seat,seatID,assignment;
			for(var i in users){
				user = users[i];
				userID = user.userID;
				userObject[userID] = user;
				userObject[userID].companyID = companyID;
				userObject[userID].profile = user.profileImages.smallProfile;
				delete userObject[userID].profileImages;
				userObject[userID].seats = [];
			}
			for(var i in seats){
				seat = seats[i];
				seatObject[seat.seatID] = seat;
			}
			for(var i in assignments){
				assignment = assignments[i];
				userID = assignment.userID;
				seatID = assignment.seatID;
				userObject[userID].seats.push({
					seatID,
					seatName:seatObject[seatID].seatName,
					mapName:seatObject[seatID].mapName
				})
			}
			for(var i in userObject){
				userArray.push(userObject[i]);
			}
			res.status(200).send({data:userArray});
		}).catch((err)=>{
			console.log(err);
		})
	}
})

module.exports = router;