var router = require('express').Router();
var authenticate = require('../../.././middleware/authenticate').authenticate;
var utils = require('../../.././utils/utils');
var moment = require('moment');

// This route returns an array of seats for the entire company with various identifiers, including geographic
// This route does not have a time component and simply gives a current state
router.get('/capacityByState',authenticate,function(req,res){
	if(req.user){
		console.log('Route Processing: /api/analytics/capacity/getSeats');
		var companyNo = req.companyNo;
		var companyID = req.user.companyID;
		var officesCollection = req.db.get(companyNo + '-offices');
		var mapsCollection = req.db.get(companyNo + '-maps');
		var seatsCollection = req.db.get(companyNo + '-seats');
		var departmentsCollection = req.db.get(companyNo + '-departments');
		var len, offices, maps, seats, departments, seat, map, office;
		Promise.all([
			officesCollection.find({status:"active"},
				{fields:{_id:0,officeID:1,name:1,state:1,address1:1,address2:1,city:1,zip:1,country:1}}),
			mapsCollection.find({live:true},
				{fields:{_id:0,officeID:1,id:1,name:1,floorNumber:1,suiteNumber:1}}),
			seatsCollection.find({status:"active"},
				{fields:{_id:0,mapID:1,seatName:1,assignmentStatus:1,reservable:1,deptID:1}}),
			departmentsCollection.find({},
				{fields:{_id:0}})
		])
		.then((results)=>{
			offices = results[0];
			maps = results[1];
			seats = results[2];
			departments = results[3];
			var mapObj = {};
			var officeObj = {};
			var deptObj = {};
			len = departments.length;
			for(var i = 0; i < len; i++){
				deptObj[departments[i].deptID] = departments[i];
			}
			len = offices.length;
			for(var i = 0; i < len; i++){
				officeObj[offices[i].officeID] = offices[i];
			}
			len = maps.length;
			for(var i = 0; i < len; i++){
				mapObj[maps[i].id] = maps[i];
			}	
			len = seats.length;
			for(var i = 0; i < len; i++){
				seat = seats[i];
				map = mapObj[seat.mapID];
				office = officeObj[map.officeID];
				seat.mapName = map.name;
				seat.floorNumber = map.floorNumber;
				seat.suiteNumber = map.suiteNumber;
				seat.officName = office.name;
				seat.state = office.state;
				seat.address1 = office.address1;
				seat.address2 = office.address2;
				seat.city = office.city;
				seat.zip = office.zip;
				seat.country = office.country;
				seat.department = deptObj[seat.deptID] ? deptObj[seat.deptID].deptName : "Unassigned";
				delete seat.deptID;
				delete seat.mapID;
			}
			res.status(200).send(seats); // Returns the results to the client
		})
		.catch((err)=>{
			console.log(err)
			res.status(300).send({});
		})
	} else{
		res.status(300).send({});
	}
})

module.exports = router;