var router = require('express').Router();
var authenticate = require('../../.././middleware/authenticate').authenticate;
var utils = require('../../.././utils/utils');
var moment = require('moment');

// api/company/reports/...

router.get('/officeList',authenticate,(req,res)=>{
	if(req.user){
		var companyNo = req.companyNo;
		var db = req.db;
		var officeCollection = db.get(companyNo + '-offices');
		var mapCollection = db.get(companyNo + '-maps');
		var seatCollection = db.get(companyNo + '-seats');
		var seatAssignmentCollection = db.get(companyNo + '-seat-assignments');
		var roomCollection = db.get(companyNo + '-rooms');
		var zoneCollection = db.get(companyNo + '-zones');

		var maps;
		var resultsArray = [];
		
		Promise.all([
				officeCollection.find({status:"active"},{fields:{_id:0,officeID:1,name:1,city:1,state:1}}),
				mapCollection.find({live:true},{fields:{_id:0,id:1,officeID:1}}),
				roomCollection.find({status:'active'},{fields:{_id:0,mapID:1,roomID:1}}),
				zoneCollection.find({status:'active'},{fields:{_id:0,mapID:1,zoneID:1}}),
				seatCollection.find({status:'active'},{fields:{_id:0,mapID:1,seatID:1,reservable:1}}),
				seatAssignmentCollection.find({},{fields:{_id:0,mapID:1,seatID:1}}),
			])
		.then((promResults)=>{
			var offices = promResults[0];
			var maps = promResults[1];
			var rooms = promResults[2];
			var zones = promResults[3];
			var seats = promResults[4];
			var assignments = promResults[5];

			var officeObj = {};
			var office,officeID;
			for(var i in offices){
				office = offices[i];
				officeObj[office.officeID] = {
					officeName: office.name,
					city: office.city,
					state: office.state,
					maps: [],
					rooms: [],
					zones: [],
					seats: []
				}
			}

			var mapObj = {};
			var map,mapID;
			for(var i in maps){
				officeID = maps[i].officeID;
				mapID = maps[i].id;
				mapObj[mapID] = officeID;
				officeObj[officeID].maps.push(mapID);
			}

			var room,roomID;
			for(var i in rooms){
				room = rooms[i];
				roomID = room.roomID;
				mapID = room.mapID;
				officeID = mapObj[mapID];
				officeObj[officeID].rooms.push(roomID);
			}

			var zone,zoneID;
			for(var i in zones){
				zone = zones[i];
				zoneID = zone.zoneID;
				mapID = zone.mapID;
				officeID = mapObj[mapID];
				officeObj[officeID].zones.push(zoneID);
			}

			var seatObj = {};
			var seat,seatID;
			for(var i in seats){
				seat = seats[i];
				seatID = seat.seatID;
				seatObj[seats[i].seatID] = {
					seatID,
					mapID:seat.mapID,
					reservable: seat.reservable,
					assignmentStatus: "Unassigned"
				}
			}

			for(var i in assignments){
				if(seatObj[assignments[i].seatID]){
					seatObj[assignments[i].seatID].assignmentStatus = "Assigned";
				}
			}

			for(var i in seatObj){
				mapID = seatObj[i].mapID;
				officeID = mapObj[mapID];
				officeObj[officeID].seats.push(seatObj[i]);
			}

			var officeArray = [];
			for(var i in officeObj){
				officeArray.push(officeObj[i]);
			}

			res.send({data:officeArray});
		})
		.catch((err)=>{
			console.log(2,err);
			res.status(300).send({data:4});
		})
	} else{
	 	console.log('sending null')
	 	res.send({data:null});		
	}
})

router.get('/mapList',authenticate,(req,res)=>{
	if(req.user){
		var companyNo = req.companyNo;
		var db = req.db;
		var mapCollection = db.get(companyNo + '-maps');
		var seatCollection = db.get(companyNo + '-seats');
		var seatAssignmentCollection = db.get(companyNo + '-seat-assignments');
		var roomCollection = db.get(companyNo + '-rooms');
		var zoneCollection = db.get(companyNo + '-zones');
		var officeCollection = db.get(companyNo + '-offices');
		var offices,maps,seats,rooms,zones,seatAssignments,results;
		var resultsArray = [];
		
		Promise.all([
			officeCollection.find({status:'active'},{fields:{_id:0}}),
			mapCollection.find({live:true},{fields:{_id:0}}),
			seatCollection.find({status:'active'},{fields:{_id:0,mapID:1,seatID:1,seatName:1,imagePath:1,zones:1,rooms:1,reservable:1}}),
			roomCollection.find({status:'active'},{fields:{_id:0,mapID:1,roomName:1,roomID:1,area:1,seats:1}}),
			zoneCollection.find({status:'active'},{fields:{_id:0,mapID:1,zoneName:1,zoneID:1,area:1,seats:1}}),
			seatAssignmentCollection.find({},{ fields:{_id:0,mapID:1,seatID:1,employeeID:1}}),
		])
		.then((promResults)=>{
			offices = promResults[0];
			maps = promResults[1];
			seats = promResults[2];
			rooms = promResults[3];
			zones = promResults[4];
			seatAssignments = promResults[5];

			results = {};

			var officeObj = {};
			var office, officeID;
			for(var i in offices){
				office = offices[i];
				officeID = office.officeID;
				officeObj[officeID] = {
					name: office.name,
					address1: office.address1,
					city: office.city,
					state: office.state,
					zip: office.zip,
					country: office.country
				}
			}

			// This creates the base row object for a map entry
		 	for(var i in maps){
		 		var map = {};
		 		officeID = maps[i].officeID;
		 		office = officeObj[officeID];
		 		map.officeName = office.name;
		 		map.address = office.address1;
		 		map.floor = maps[i].floorNumber;
		 		map.suite = maps[i].suiteNumber;		 		
		 		map.city = office.city;
		 		map.state = office.state;
		 		map.zip = office.zip;
		 		map.country = office.country;
		 		map.mapID = maps[i].id;
		 		map.name = maps[i].name;
		 		map.date = maps[i].date;
		 		map.seats = {};
		 		map.rooms = {};
		 		map.zones = {};
		 		results[map.mapID] = map;
		 	}

	 		for(var i in seats){
				var seatID = seats[i].seatID;
				var mapID = seats[i].mapID;
				results[mapID].seats[seatID] = {
					seatID:seats[i].seatID,
					reservable:seats[i].reservable,
					assignmentStatus:'Unassigned',
				}
			}

			for(var i in seatAssignments){
				var mapID = seatAssignments[i].mapID;
				var seatID = seatAssignments[i].seatID;
				results[mapID].seats[seatID].assignmentStatus = 'Assigned';
			}

			for(var i in rooms){
				var roomID = rooms[i].roomID;
				var mapID = rooms[i].mapID;
				results[mapID].rooms[roomID] = {
					roomID:rooms[i].roomID,
				}					
			}

			for(var i in zones){
				var zoneID = zones[i].zoneID;
				var mapID = zones[i].mapID;
				results[mapID].zones[zoneID] = {
					zoneID:zones[i].zoneID,
				}					
			}

			for(var i in results){
				resultsArray.push(results[i]);
			}
			res.send({data:resultsArray});
		})
		.catch((err)=>{
			console.log(2,err);
			res.status(300).send({data:4});
		})
	} else{
	 	console.log('sending null')
	 	res.send({data:null});		
	}
})

router.get('/seatList',authenticate,(req,res)=>{
	if(req.user){
		var companyNo = req.companyNo;
		var db = req.db;
		var seatCollection = db.get(companyNo + '-seats');
		var seatAssignmentCollection = db.get(companyNo + '-seat-assignments');
		var userCollection = db.get(companyNo + '-users');
		var departmentCollection = db.get(companyNo + '-departments');
		var resultsArray = [];
		var results = {};
		var employeeObj = {};
		var deptObj = {};
		var seat,seatID,userID,employee,departments,dept,deptID;

		Promise.all([
			seatCollection.find({status:'active'},{fields:{_id:0,mapID:1,mapName:1,seatID:1,
				seatName:1,imagePath:1,zones:1,rooms:1,reservable:1,deptID:1}}),
			seatAssignmentCollection.find({},{ fields:{seatID:1,userID:1}}),
			userCollection.find({},{fields:{userID:1,first:1,last:1,profileImages:1}}),
			departmentCollection.find({active:true},{fields:{_id:0,deptName:1,deptID:1}})
		])
		.then((promiseResults)=>{
			var seats = promiseResults[0];
			var seatAssignments = promiseResults[1];
			var employees = promiseResults[2];
			departments = promiseResults[3];

			var len = departments.length;
			for(var i = 0; i < len; i++){
				dept = departments[i];
				deptID = dept.deptID;
				deptObj[deptID] = dept.deptName;
			}

			var empLen = employees.length;
			var seatLen = seats.length;
			var assnLen = seatAssignments.length;
			for(var i = 0;i < empLen;i++){ // creates a user/employee object indexed by userID
				employeeObj[employees[i].userID] = employees[i];
			}

			for(var i = 0; i < seatLen;i++){ // Creates the base results object indexed by seatID
				seat = seats[i];
				seatID = seat.seatID;
				seat.department = deptObj[seat.deptID];
				results[seatID] = seat;
				results[seatID].rooms = Object.keys(seat.rooms);
				results[seatID].zones = Object.keys(seat.zones);
				results[seatID].assignmentStatus = "Unassigned"; // Sets the default to unassigned
			}
			for(var i = 0; i < assnLen; i++){ // Loads updated seat assignment / user data onto the results object
				seatID = seatAssignments[i].seatID;
				userID = seatAssignments[i].userID;
				employee = employeeObj[userID];
				results[seatID].assignmentStatus = 'Assigned'; // If an assignment is found, updates unassigned to assigned
				results[seatID].userID = userID;
				results[seatID].first = employee.first;
				results[seatID].last = employee.last;
				results[seatID].imagePath = employee.profileImages.smallProfile || results[seatID].imagePathsea;
			}
			for(var i in results){ // Turns results object into a results array for use in a formatted table
				resultsArray.push(results[i]);
			}
			res.send({data:resultsArray});
		})
		.catch((err)=>{
			console.log(2,err);
			res.status(300).send({data:4});
		})
	} else{
	 	console.log('sending null')
	 	res.send({data:null});		
	}
})

router.get('/userList',authenticate,(req,res)=>{
	console.log('Getting user list',req.user);
	if(req.user){
		var companyNo = req.companyNo;
		var userCollection = req.db.get(companyNo + '-users');
		var seatAssignmentCollection = req.db.get(companyNo + '-seat-assignments');
		var seatCollection = req.db.get(companyNo + '-seats');
		var companyID = req.user.companyID;
		Promise.all([
			userCollection.find({userID:{ $exists: true }},{fields:{_id:0,email:1,office:1,userID:1,first:1,last:1,employee:1,'profileImages.smallProfile':1}}),
			seatCollection.find({},{fields:{seatID:1,seatName:1,mapName:1}}),
			seatAssignmentCollection.find({})
		])
		.then((docs)=>{
			var users = docs[0];
			var seats = docs[1];
			var assignments = docs[2];
			var userObject = {};
			var seatObject = {};
			var userArray = [];
			var user,userID,seat,seatID,assignment;
			for(var i in users){
				user = users[i];
				userID = user.userID;
				userObject[userID] = user;
				userObject[userID].companyID = companyID;
				userObject[userID].profile = user.profileImages.smallProfile;
				delete userObject[userID].profileImages;
				userObject[userID].seats = [];
			}
			for(var i in seats){
				seat = seats[i];
				seatObject[seat.seatID] = seat;
			}
			for(var i in assignments){
				assignment = assignments[i];
				userID = assignment.userID;
				seatID = assignment.seatID;
				userObject[userID].seats.push({
					seatID,
					seatName:seatObject[seatID].seatName,
					mapName:seatObject[seatID].mapName
				})
			}
			for(var i in userObject){
				userArray.push(userObject[i]);
			}
			res.status(200).send({data:userArray});
		}).catch((err)=>{
			console.log(err);
		})
	}
})

router.get('/zonelist',authenticate,(req,res)=>{
	if(req.user){
		var companyNo = req.companyNo;
		var db = req.db;
		var zoneCollection = db.get(companyNo + '-zones');
		var assignmentCollection = db.get(companyNo + '-seat-assignments');
		var departmentCollection = db.get(companyNo + '-departments');
		var mapColleciton = db.get(companyNo + '-maps');
		var officeCollection = db.get(companyNo + '-offices');
		var departments,dept,deptID;
		var deptObj = {};
		var len, offices, office, maps, map;
		var officeObj = {};
		var mapObj = {};

		Promise.all([
			zoneCollection.find({status:"active"},{fields:{_id:0,status:0}}),
			assignmentCollection.find({},{fields:{seatID:1}}),
			departmentCollection.find({active:true},{fields:{_id:0,deptName:1,deptID:1}}),
			mapColleciton.find({live:true},{fields:{_id:0,id:1,officeID:1}}),
			officeCollection.find({status:"active"},{fields:{_id:0,officeID:1,name:1}})
		])		
		.then((results)=>{
			var zones = results[0];
			var assignments = results[1];
			departments = results[2];
			maps = results[3];
			offices = results[4];
			var assignObj = {};
			var assignLen = assignments.length;
			var zonesLen = zones.length;
			var zone;
			var resultsArray = [];

			len = offices.length;
			for(var i = 0; i < len; i++){
				office = offices[i];
				officeObj[office.officeID] = office.name;
			}

			len = maps.length;
			for(var i = 0; i < len; i++){
				map = maps[i];
				mapObj[map.id] = officeObj[map.officeID];
			}			

			len = departments.length;
			for(var i = 0; i < len; i++){
				dept = departments[i];
				deptID = dept.deptID;
				deptObj[deptID] = dept.deptName;
			}

			for( var i = 0; i < assignLen; i++ ){
				assignObj[assignments[i].seatID] = {};
			}

			for( var i = 0; i < zonesLen; i++ ){
				zone = zones[i];
				zone.office = mapObj[zone.mapID];
				zone.department = deptObj[zone.deptID];
				for( var j in zone.seats){
					if(assignObj[j]){ // j is the seatID and so this is checking to see if an assignment exists for this seat
						zone.seats[j].assignmentStatus = "Assigned";
					} else {
						zone.seats[j].assignmentStatus = "Unassigned";
					}
				}
				resultsArray.push(zone);
			}

			res.status(200).send({data:resultsArray});
		})
		.catch((err)=>{
			console.log(err);
			res.status(300).send();
		})
	} else{
	 	res.status(498).send();	
	}
})

router.get('/roomList',authenticate,(req,res)=>{
	if(req.user){
		var companyNo = req.companyNo;
		var db = req.db;
		var roomsCollection = db.get(companyNo + '-rooms');
		var assignmentCollection = db.get(companyNo + '-seat-assignments');
		var departmentCollection = db.get(companyNo + '-departments');
		var mapColleciton = db.get(companyNo + '-maps');
		var officeCollection = db.get(companyNo + '-offices');
		var departments,dept,deptID;
		var deptObj = {};
		var len, offices, office, maps, map;
		var officeObj = {};
		var mapObj = {};


		Promise.all([
			roomsCollection.find({status:"active"},{fields:{_id:0,status:0,log:0}}),
			assignmentCollection.find({},{fields:{seatID:1}}),
			departmentCollection.find({active:true},{fields:{_id:0,deptName:1,deptID:1}}),
			mapColleciton.find({live:true},{fields:{_id:0,id:1,officeID:1}}),
			officeCollection.find({status:"active"},{fields:{_id:0,officeID:1,name:1}})
		])		
		.then((results)=>{
			var rooms = results[0];
			var assignments = results[1];
			departments = results[2];
			maps = results[3];
			offices = results[4];
			var assignObj = {};
			var assignLen = assignments.length;
			var roomsLen = rooms.length;
			var room;
			var resultsArray = [];

			len = offices.length;
			for(var i = 0; i < len; i++){
				office = offices[i];
				officeObj[office.officeID] = office.name;
			}

			len = maps.length;
			for(var i = 0; i < len; i++){
				map = maps[i];
				mapObj[map.id] = officeObj[map.officeID];
			}			

			len = departments.length;
			for(var i = 0; i < len; i++){
				dept = departments[i];
				deptID = dept.deptID;
				deptObj[deptID] = dept.deptName;
			}

			for( var i = 0; i < assignLen; i++ ){
				assignObj[assignments[i].seatID] = {};
			}

			for( var i = 0; i < roomsLen; i++ ){
				room = rooms[i];
				room.office = mapObj[room.mapID];
				room.department = deptObj[room.deptID];
				for( var j in room.seats){
					if(assignObj[j]){ // j is the seatID and so this is checking to see if an assignment exists for this seat
						room.seats[j].assignmentStatus = "Assigned";
					} else {
						room.seats[j].assignmentStatus = "Unassigned";
					}
					delete room.seats[j].seatName;
				}
				resultsArray.push(room);
			}

			res.status(200).send({data:resultsArray});
		})
		.catch((err)=>{
			console.log(err);
			res.status(300).send();
		})
	} else{
	 	res.status(498).send();	
	}
})

module.exports = router;