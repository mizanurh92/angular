var router = require('express').Router();
var authenticate = require('../../.././middleware/authenticate').authenticate;
var utils = require('../../.././utils/utils');
var moment = require('moment');

// User in the user management list to populate department and office options when creating/modifying a user
router.get('/summary',authenticate,(req,res)=>{
	if(req.user){
		var companyNo = req.companyNo;		

		var officeCollection = req.db.get(companyNo + '-offices');
		var userCollection = req.db.get(companyNo + '-users');
		var seatsCollection = req.db.get(companyNo + '-seats');
		var roomsCollection = req.db.get(companyNo + '-rooms');
		var mapCollection = req.db.get(companyNo + '-maps');
		var visitorCollection = req.db.get(companyNo + '-visitor-log');

		var resultsObj = {};

		var now = moment().valueOf();
		var startOfYear = moment().startOf('year').valueOf();
		var startOfMonth = moment().startOf('month').valueOf();
		var startOfWeek = moment().startOf('week').valueOf();
		var today = moment().startOf('day').valueOf();

		Promise.all([
			roomsCollection.count({status:"active"}),
			userCollection.count({status:"active",kioskID:{$exists:true}}),
			officeCollection.aggregate([
					{$match:{status:"active"}},
					{$group:{_id:'$status',totals:{$sum:'$area'}}}
				]),
			seatsCollection.aggregate([
				{$match:{status:"active",reservable:false}},
				{$group:
					{
						_id: '$mapID',
						assigned:{$sum: {$cond: { if: { $eq:['$assignmentStatus','Assigned'] }, then: 1, else: 0 }}},
						unassigned:{$sum: {$cond: { if: { $eq:['$assignmentStatus','Unassigned'] }, then: 1, else: 0 }}},
					}
				},
			]),
			officeCollection.find({status:"active"},{fields:{_id:0,officeID:1,name:1,area:1}}),
			mapCollection.find({live:true},{fields:{_id:0,id:1,officeID:1}}),
			userCollection.aggregate([
					{$match:{$or:[{userStatus:"active"},{userStatus:"unassigned"}]}},
					{$group:{_id: '$office.officeID',users:{$sum: 1}}}					
				]),
			seatsCollection.aggregate([
				{$match:{status:"active"}},
				{$group:{_id:'$mapID',seats:{$sum: 1}}},
			]),
			visitorCollection.find({date:{$gte:startOfYear,$lte:now}},{fields:{_id:0,date:1}})

		])
		.then((results)=>{
			resultsObj.offices = 0;
			resultsObj.users = 0;
			resultsObj.seats = 0;
			resultsObj.rooms = results[0];
			resultsObj.kiosks = results[1];
			resultsObj.area = results[2][0].totals;
			var seatAssign = results[3];
			var offices = results[4];
			var maps = results[5];
			var users = results[6];
			var seats = results[7];
			var visitors = results[8];
			var officeObj = {};
			var mapObj = {};

			resultsObj.visitors = {
				thisYear: visitors.length,
				thisMonth: 0,
				thisWeek: 0,
				today: 0
			}

			var visit;
			var len = visitors.length;
			for(var i = 0; i < len; i++){
				visit = visitors[i].date;
				resultsObj.visitors.thisMonth += visit > startOfMonth ? 1 : 0;
				resultsObj.visitors.thisWeek += visit > startOfWeek ? 1 : 0;
				resultsObj.visitors.today += visit > today ? 1 : 0;
			}

			len = offices.length;
			resultsObj.offices = offices.length;
			for(var i = 0; i < len; i++){
				officeObj[offices[i].officeID] = offices[i];
			}

			len = maps.length;
			for(var i = 0; i < len; i++){
				mapObj[maps[i].id] = officeObj[maps[i].officeID].officeID;
			}

			var map, officeID, office;
			for( var i in seatAssign){
				map = seatAssign[i];
				officeID = mapObj[map._id];
				office = officeObj[officeID];
				if(office.assigned){
					office.assigned += map.assigned;
				} else {
					office.assigned = map.assigned;
				}
				if(office.unassigned){
					office.unassigned += map.unassigned;
				} else {
					office.unassigned = map.unassigned;
				}
			}

			len = users.length;
			for(var i = 0; i < len; i++){
				officeID = users[i]._id;
				resultsObj.users += users[i].users;
				officeObj[officeID].users = users[i].users;
			}

			var seat;
			len = seats.length;
			for(var i = 0; i < len; i++){
				map = seats[i];
				resultsObj.seats += map.seats;
				office = officeObj[mapObj[map._id]];
				if(office.seats){
					office.seats += map.seats;
				} else {
					office.seats = map.seats;
				}				
			}

			resultsObj.officeData = [];
			for(var i in officeObj){
				resultsObj.officeData.push(officeObj[i])
			}
			
			res.status(200).send(resultsObj);
		})
		.catch((err)=>{
			console.log(err);
			res.status(300).send();
		})
	} else {
	 	res.status(498).send();
	}
})

module.exports = router;