var router = require('express').Router();
var authenticate = require('../../.././middleware/authenticate').authenticate;
var utils = require('../../.././utils/utils');

router.use('/reports',require('./reports'));
router.use('/summary',require('./summary'));
router.use('/analytics',require('./analytics'));
router.use('/users',require('./users'));

module.exports = router;