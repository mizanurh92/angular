var router = require('express').Router();
var utils = require('../../../.././utils/utils');
const uuid = utils.uuid;
var config = require('../../../.././config/config');
var profilePath = config.profilePath;
var authenticate = require('../../../.././middleware/authenticate').authenticate;

router.get('/createTestCompany',function(req,res){
    //var testCompanyData = req.body.data;
    var data = req.query; 
    //var testCompanyData=Object.assign({}, data);
    var testCompanyData=[{"companyName": "Capgemini", "lcase": "capgemini","mailingAddress":
    {"address1":"A1 Technology Park,MIDC","address2":"Talwade","city":"Pune","state":"MH","zip":"411062","country":"India"},
    "website":"capgemini.com","companyStatus":"active","message":"Welcome to Capgemini",
    "profileImage":"Xpanxion-UST+Global+Group+_white.png"},{"companyName": "Syntel", "lcase": "syntel",
    "mailingAddress":{"address1":"A1 Technology Park,MIDC","address2":"Talwade","city":"Pune","state":"MH","zip":"411062",
    "country":"India"},"website":"syntel.co.org","companyStatus":"active","message":"Welcome to Syntel","profileImage":
    "Xpanxion-UST+Global+Group+_white.png"},{"companyName": "UST Global", "lcase": "ust global","mailingAddress":
    {"address1":"1860 prospect rd","address2":"Talwade","city":"red bluff","state":"alaska","zip":"24915","country":"US"},
    "website":"ustglobal.com","companyStatus":"active","message":"Welcome to UST Global","profileImage":"Xpanxion-UST+Global+Group+_white.png"},{"companyName": "Cognizant", "lcase": "cognizant","mailingAddress":{"address1":"6896 thornridge cir","address2":"Talwade","city":"orlando","state":"iowa","zip":"41612","country":"US"},"website":"cognizant.com","companyStatus":"active","message":"Welcome to Cognizant","profileImage":"Xpanxion-UST+Global+Group+_white.png"},{"companyName": "Accenture", "lcase": "accenture","mailingAddress":{"address1":"6176 w gray st","address2":"Talwade","city":"nashville","state":"iowa","zip":"57482","country":"US"},"website":"accenture.com","companyStatus":"active","message":"Welcome to Accenture","profileImage":"Xpanxion-UST+Global+Group+_white.png"},{"companyName": "Xpanxion-UST", "lcase": "xpanxion-ust","mailingAddress":{"address1":"1st floor,Sai Radhe","address2":"pune station","city":"Pune","state":"MH","zip":"411007","country":"India"},"website":"xpanxion.co.in","companyStatus":"active","message":"Welcome to Xpanxion-UST","profileImage":"Xpanxion-UST+Global+Group+_white.png"},{"companyName": "Yash Technology", "lcase": "yesh technology","mailingAddress":{"address1":"gate 3","address2":"Magarpatta","city":"Pune","state":"MH","zip":"411007","country":"India"},"website":"yeshtechnology.com","companyStatus":"active","message":"Welcome to Yash Technology","profileImage":"Xpanxion-UST+Global+Group+_white.png"},{"companyName": "Amazon", "lcase": "amazon","mailingAddress":{"address1":" seattle","address2":"Talwade","city":"Pune","state":"Washington","zip":"206","country":"US"},"website":"amazon.com","companyStatus":"active","message":"Welcome to Amazon","profileImage":"Xpanxion-UST+Global+Group+_white.png"},{"companyName": "Xpanxion-Pune", "lcase": "xpanxion-pune","mailingAddress":{"address1":"Rajib Ghandhi Chawk","address2":"Talwade","city":"Noida","state":"UP","zip":"51225","country":"US"},"website":"xpanxion.com","companyStatus":"active","message":"Welcome to Xpanxion-Delhi","profileImage":"Xpanxion-UST+Global+Group+_white.png"},{"companyName": "Globant", "lcase": "globant","mailingAddress":{"address1":" seattle","address2":"Talwade","city":"Pune","state":"Washington","zip":"51216","country":"US"},"website":"globant.com","companyStatus":"active","message":"Welcome to Globant","profileImage":"Xpanxion-UST+Global+Group+_white.png"}];
    var len=data.noOfCompany;
    var companyCollection=req.db.get('companies');

    var insertArray = [];
    var companyNo=0;
    //console.log(initialDepartmentsList);
    Promise.all([
        companyCollection.find({}),
    ])
    .then((results)=>{
        var companies=results[0];
        for(var a=0;a<companies.length;a++){
            if(companies[a].companyNo && (companies[a].companyNo > companyNo)){
                companyNo = companies[a].companyNo;
            }
        }
        if(len > testCompanyData.length){
            res.status(300).send("No of company should be less than : "+(testCompanyData.length+1)); 
        }
        for(var i=0;i< len;i++){
            var updateData = {}; //update object prepared for updating the record in db.
            updateData.mailingAddress={};
            updateData.companyId = companyNo+i+1;
            if(testCompanyData[i].companyName){
                updateData.companyName = testCompanyData[i].companyName;
            }
            if(testCompanyData[i].lcase){
                updateData.lcase = testCompanyData[i].lcase;
            }
            if(testCompanyData[i].mailingAddress){
                updateData.mailingAddress.address1 = testCompanyData[i].mailingAddress.address1;
                updateData.mailingAddress.address2 = testCompanyData[i].mailingAddress.address2;
                updateData.mailingAddress.city = testCompanyData[i].mailingAddress.city;
                updateData.mailingAddress.state = testCompanyData[i].mailingAddress.state;
                updateData.mailingAddress.zip = testCompanyData[i].mailingAddress.zip;
                updateData.mailingAddress.country = testCompanyData[i].mailingAddress.country;
            }
            if(testCompanyData[i].website){
                updateData.website = testCompanyData[i].website;
            }
            if(testCompanyData[i].companyStatus){
                updateData.companyStatus = testCompanyData[i].companyStatus;
            }
            updateData.creationDate = new Date().getTime();
            if(testCompanyData[i].message){
                updateData.message = testCompanyData[i].message;
            }
            if(testCompanyData[i].profileImage){
                updateData.profileImage = testCompanyData[i].profileImage;
            }
           insertArray.push(updateData);
        }
        var finalArray=updateBulkUser(insertArray);
        companyCollection.bulkWrite(finalArray);

    })
    .then((result)=>{
        res.status(200).send({result:"success"});                              
    })

    .catch((error) => {
            console.log("error:-"+error);
            res.status(300).send();
    });
})
function updateBulkUser(updateUserArray){
    var writeArray = [];
    var len = updateUserArray.length;
    if(len == 0){
        console.log("0 Company Updated");
        return writeArray;
    }
    for(var i = 0;i < len;i++){
        var companyName = updateUserArray[i].companyName;
        //delete updateUserArray[i].employee.employeeID
        var updateObj = updateUserArray[i];
        writeArray.push({
            updateOne: {
                filter: {"companyName":companyName},
                //update: $set:updateObj,
                update: {$set: updateObj},
                upsert: true
            }
        })
    }

    console.log(len+" Company Updated");
    return writeArray;
}
module.exports = router;