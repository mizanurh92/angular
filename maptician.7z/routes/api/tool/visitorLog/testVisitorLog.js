var router = require('express').Router();
const axios = require('axios');
var utils = require('../../../.././utils/utils');

router.post('/createTestVistitorLog',function(req,res){

    var params = {}; 
    console.log("Test Visitor Log Data Creation process");
    var data = JSON.parse(req.body.data);
    var companyNo = data.companyNo;
    var officearr = data.office;
    var visitorLogCollection = req.db.get(companyNo + '-visitor-log');
    var visitorCodesCollection = req.db.get(companyNo + '-visitor-codes');
    var userCollection = req.db.get(companyNo + '-users');
    var visitorLogCollection = req.db.get(companyNo + '-visitor-log');
    var visitorCodesCollection = req.db.get(companyNo + '-visitor-codes');
    var officeCollection = req.db.get(companyNo + '-offices');
    var offices,company,kioskUsers,visitorCodes,sampleUsers;
    var visitorData=[];
    var companyCollection = req.db.get('companies');    
    var sampleCompany = [{name:"Maptician",email:"mayank@maptician.com"},{name:"Xpanxion",email:"priyankag@xpanxion.com"},
                         {name:"Sam Corporation",email:"sam.williams@samcorp.com"},{name:"Neustar INC",email:"Harold@neustar.biz"}];
    var samplePurpose = ["Meetings","Official","Personal","Others"];

    var getCompany = function(){
        var len = sampleCompany.length;
        var index = Math.floor(Math.random() * len);
        return sampleCompany[index];
    }
    var getPurpose = function(){
        var len = samplePurpose.length;
        var index = Math.floor(Math.random() * len);
        return samplePurpose[index];
    }

    var getRandomDate = function(startDate,endDate){
        var start = new Date(startDate+" 10:30");
        var end = new Date(endDate+" 02:10");
        //get the difference between the 2 dates, multiply it by 0-1, 
        // and add it to the start date to get a new date 
        var diff =  end.getTime() - start.getTime();
        var new_diff = diff * Math.random();
        var date = new Date(start.getTime() + new_diff);
        return date;
    }
    var toTitleCase = function(str){
        return str.replace(/\w\S*/g, function(txt){return txt.charAt(0).toUpperCase() + 
             txt.substr(1).toLowerCase();});
    }
    Promise.all([
        officeCollection.find({},{fields:{_id:0,officeID:1,name:1}}),
        userCollection.find({"kioskID":{ $exists: true }}),
        visitorCodesCollection.find({},{fields:{userID:1,visitorCode:1}}),
        companyCollection.findOne({ companyNo: parseInt(companyNo) }, { fields: { _id: 1 } })
                ])
    .then((results)=>{
            offices = results[0];
            kioskUsers = results[1];
            visitorCodes = results[2];
            company = results[3];
            if(!company){
                res.status(300).send("Wrong Company no ::"+companyNo);  
            }
            return axios.get('https://randomuser.me/api/?results=100',{
                params:{
                        nat: params.nat || 'us',
                        exc: params.exc || 'gender,location,login,dob,registered',
                        results: params.results
                }
            })
    })
    .then((data) => {
        users = data.data.results;
        len = users.length;
        console.log(len);
        
        for(var office of officearr){
            var noOfUsers  = office.noOfUser;
            var startDate = office.startDate; //format MM-DD-YYYY example :- 12-01-2017
            var endDate = office.endDate; //format MM-DD-YYYY example :- 12-12-2017
            var officeObj = findOffice(offices,office.name);
            if(noOfUsers > 100){
                res.status(300).send("No of users cannot be greater than 100");
            }
            if(officeObj == null){
                res.status(300).send("Invalid Office ::"+office.name);
            }
            var userArr = findUserOfGivenOffice(kioskUsers,officeObj.officeID);
            for(var i = 0; i < noOfUsers; i++){
                    if(userArr.length == 0){
                       res.status(300).send("There should be alteast one kiosk user mapped to this office "+office.name);
                    }
                    var user = getRanDomUser(userArr);
                    var data ={};
                    var tempUser = users[i];
                    data.name =  toTitleCase(tempUser.name.first)+" " + toTitleCase(tempUser.name.last);
                    var compAndEmail = getCompany();
                    data.company = compAndEmail.name;
                    data.email = compAndEmail.email;
                    data.cell = tempUser.phone;
                    data.purpose = getPurpose();
                    data.visitorCode = getVisitorCodes(visitorCodes)
                    data.kioskID = user.kioskID;
                    data.date = getRandomDate(startDate,endDate).getTime();
                    data.officeID = officeObj.officeID
                    data.detail = "";
                    data.mapID = user.mapID;
                    visitorData.push(data);                
            }
        }
        var writeArray = addBulkVisitorData(visitorData);
        var tempVisitorLogcollection = req.db.get(companyNo + '-visitor-log');	
        tempVisitorLogcollection.bulkWrite(writeArray)
        .then((result)=>{
            console.log("Visitor Log saved Successfully");
            res.status(200).send("Visitor Log saved Successfully");
        })
        .catch((err)=>{
            console.log(err);
            res.status(300).send(err);
        })

    }).catch((error) => {
            console.log("error:-"+error);
            res.status(300).send();
    });
});

function addBulkVisitorData(visitorData){
	var writeArray = [];
	var len = visitorData.length;
	if(len == 0){
		console.log("0 entries added for visitor log");
		return writeArray;
	}
	for(var i = 0;i < len; i++){
		writeArray.push({insertOne:{document:visitorData[i]}});
	}
	console.log(len+" entries added for visitor log");
	return writeArray;
}

function getRanDomUser(userArr){
    var len  = userArr.length;
    return userArr[Math.floor(Math.random() * len)]
}

function getVisitorCodes(visitorCodes){
    var len = visitorCodes.length;
    var viscode =  visitorCodes[Math.floor(Math.random() * len)];
    return viscode.visitorCode;
}

function findUserOfGivenOffice(users,officeID){
    var userArr = [];
    for(var user of users){
        if(user.officeID == officeID){
            userArr.push(user);
        }
    }
    return userArr;
}
//Find the Office object for the given department Name 
//return null department is not found
function findOffice(officeData,officeName){
    for(var item of officeData){
        if(utils.compareStrings(item.name,officeName,true,true)){
            delete item._id;
            officeFound =true;
            return item;
        }
    }
}

module.exports = router;