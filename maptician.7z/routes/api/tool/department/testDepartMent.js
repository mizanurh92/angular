var router = require('express').Router();
var utils = require('../../../.././utils/utils');
var uuid = utils.uuid;
var config = require('../../../.././config/config');
var profilePath = config.profilePath;

router.get('/createTestDepartment',function(req,res){
    var data = req.query; 
    var companyNo = data.companyNo;
    var noOfDepWantToCreate = data.noOfDepWantToCreate;
    var industryName = data.industryType
    var companyCollection=req.db.get('companies');
    var departmentCollection = req.db.get(companyNo + '-departments');
    var companies;
    var insertArray = [];
    var companiesNo=[];
    var departmentsdb=[];
    var departments = {
        'Unassigned': [
            {deptName: "Unassigned", deptID: 0000}
        ],
        'IT': [
            {deptName: "Human Resources", deptID: uuid()},
            {deptName: "Admin", deptID: uuid()},
            {deptName: "Sales", deptID: uuid()},
            {deptName: "Finance", deptID: uuid()},
            {deptName: "Procurement", deptID: uuid()}
        ],
        'Banking': [
            {deptName: "Human Resources", deptID: uuid()},
            {deptName: "Admin", deptID: uuid()},
            {deptName: "Retail Banking", deptID: uuid()},
            {deptName: "Investment Banking", deptID: uuid()},
            {deptName: "Risk", deptID: uuid()},
            {deptName: "Customer Service", deptID: uuid()},
            {deptName: "Digital", deptID: uuid()},
        ],
        'Retail': [  {deptName: "Human Resources", deptID: uuid()},
            {deptName: "Admin", deptID: uuid()},
            {deptName: "Purchase", deptID: uuid()},
            {deptName: "Finance", deptID: uuid()},
            {deptName: "Inventory", deptID: uuid()},
            {deptName: "Customer Service", deptID: uuid()},
            {deptName: "Digital", deptID: uuid()},
            ]
}
    Promise.all([companyCollection.find(),
        departmentCollection.find()])
    .then((results)=>{
        companies=results[0];
        departmentsdb = results[1];
        var companyFound = false;
        for (var company of companies){
            if(company.companyNo == companyNo){
                companyFound = true;
            }
        }
        if(!companyFound){
            res.status(300).send("Company does not exists"); 
        }
        else {
            var deptCollection = req.db.get(companyNo + '-departments');
            var deptList = departments[industryName];
            if(noOfDepWantToCreate > deptList.length){
                res.status(300).send("Department count is greater than dummy department data"); 
            }
            for(var i = 0; i < noOfDepWantToCreate; i++){
                deptList[i].active = Math.floor(Math.random() * 2) ? "active" : "inactive";
                deptList[i].deptNumber = getDepartmentNumber(departmentsdb);
                insertArray.push(deptList[i]);
            }
            var finalArray=updateDepartment(insertArray);
            console.log(finalArray);
            deptCollection.bulkWrite(finalArray);
        }

    })
    .then((result)=>{
        res.status(200).send({result:"success"});                              
    })

    .catch((error) => {
            console.log("error:-"+error);
            res.status(300).send();
    });
})

function updateDepartment(updateDepartmentArray){
    var writeArray = [];
    var len = updateDepartmentArray.length;
    if(len == 0){
        console.log("0 User Updated");
        return writeArray;
    }
    for(var i = 0;i < len;i++){
        var deptName = updateDepartmentArray[i].deptName;
        //delete updateDepartmentArray[i].employee.employeeID
        var updateObj = updateDepartmentArray[i];
        writeArray.push({
            updateOne: {
                filter: {"deptName":deptName},
                //update: $set:updateObj,
                update: {$set: updateObj},
                upsert: true
            }
        })
    }

    console.log(len+" Users Updated");
    return writeArray;
}

function getDepartmentNumber(deptArr){
    var correctDeptNo = false;
    var counter = 0;
    var deptNo;
    while(!correctDeptNo && counter<100){
         deptNo = parseInt(Math.floor(Math.random() * 3));
        correctDeptNo = isDepartnumberAlreadyPresent(deptNo ,deptArr);
        counter = counter + 1;
    }
    return deptNo;
}

function isDepartnumberAlreadyPresent(number , deptArr){
    
    for(var dept of deptArr){
        if(dept.deptNumber == number){
            return false;
        }
    }
    return true;
}

module.exports = router;