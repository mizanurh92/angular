var router = require('express').Router();
var utils = require('../../../.././utils/utils');
const uuid = utils.uuid;
var config = require('../../../.././config/config');
var profilePath = config.profilePath;
var authenticate = require('../../../.././middleware/authenticate').authenticate;

router.get('/createTestVisitorCode',function(req,res){
   var data = req.query; 
   var companyNo=data.companyNo;
    var noOfVisitorCode=data.noOfVisitorCode;
    var index=parseInt(noOfVisitorCode);
    var codeCollection = req.db.get(companyNo + '-visitor-codes');
    var usersCollection = req.db.get(companyNo + '-users');
    var insertArray = [];
    var userId=[];
    var visitorCodes=[];
    var samplePurpose = ["Meetings","Official","Personal","Others"];
    //console.log(initialDepartmentsList);
    var getPurpose = function(){
        var len = samplePurpose.length;
        var index = Math.floor(Math.random() * len);
        return samplePurpose[index];
    }
    var toTitleCase = function(str){
        return str.replace(/\w\S*/g, function(txt){return txt.charAt(0).toUpperCase() + 
             txt.substr(1).toLowerCase();});
    }
    Promise.all([
        usersCollection.find({"employee":{ $exists: true }}),
        codeCollection.find({})
    ])
    .then((results)=>{
        var users=results[0];
        visitorCodes=results[1]; 
        
        if(users.length< index) {
            res.status(300).send({error:"Number of visitor codes should be less than equal to Users length"});  
        }
        for(var a=0;a<users.length;a++){
                var updateData = {}; 
                updateData.userID=users[a].userID;
                updateData.userName=toTitleCase(users[a].first)+" "+toTitleCase(users[a].last);
                updateData.visitorCode=getCode(visitorCodes);
                updateData.type=getPurpose();
                updateData.contact=users[a].contact.cell;
                insertArray.push(updateData);
                index--;
                console.log(index);
                if(index==0){break;}
        }
        var finalArray=updateBulkUser(insertArray);
        codeCollection.bulkWrite(finalArray);

    })
    .then((result)=>{
        res.status(200).send({result:"success"});                              
    })

    .catch((error) => {
            console.log("error:-"+error);
            res.status(300).send();
    });
})

function checkVisitorCodeAlreadyPresent(visitorCodes,codeValue){
    for (var code of visitorCodes){
        if(code.visitorCode == codeValue){
            return false;
        }
    }
    return true;
}

function getCode(visitorCodes){
    var correctCode = false;
    var code;
    while(!correctCode) {
        code = Math.floor(Math.random()*(999-100+1)+100)+"-"+Math.floor(Math.random()*(999-100+1)+100);
        correctCode = checkVisitorCodeAlreadyPresent(visitorCodes,code);
    }
    return code;
}

function updateBulkUser(updateUserArray){
    var writeArray = [];
    var len = updateUserArray.length;
    if(len == 0){
        console.log("0 Company Updated");
        return writeArray;
    }
    for(var i = 0;i < len;i++){
        var userID = updateUserArray[i].userID;
        //delete updateUserArray[i].employee.employeeID
        var updateObj = updateUserArray[i];
        writeArray.push({
            updateOne: {
                filter: {"userID":userID},
                //update: $set:updateObj,
                update: {$set: updateObj},
                upsert: true
            }
        })
    }
    return writeArray;
}
module.exports = router;