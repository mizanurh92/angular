var router = require('express').Router();
var utils = require('../../../.././utils/utils');
var loremIpsum = require('lorem-ipsum')

router.post('/createTestSeatReservation',function(req,res){

    console.log("Test seat reservation");
    var data = JSON.parse(req.body.data);
    var companyNo = data.companyNo;
    var mapname = data.mapName;
    var startDate = data.dateStart;
    var endDate = data.dateEnd;
    var startTime = data.startTime;
    var stHour = startTime.hour;
    var stMin = startTime.min;
    var endTime = data.endTime;
    var etHour = endTime.hour;
    var etMin = endTime.min;
    var isWeekDaysOnly = data.weekDaysOnly;
    var percentageOfSeatReserved = data.perSeatToReserve;
    var noOfElements = data.noOfElements;
    var mapCollection = req.db.get(companyNo + '-maps');
    var seatReservationsCollection = req.db.get(companyNo + '-seat-reservations');
    var seatCollection = req.db.get(companyNo + '-seats');
    var usersCollection = req.db.get(companyNo + '-users');
    var companyCollection = req.db.get('companies'); 
    var users,map,seats;
    var updateData =[];
    var titles = ['Project','Client','Shareholder','Vendor member','Staff','Event Team member']
    var toTitleCase = function(str){
        return str.replace(/\w\S*/g, function(txt){return txt.charAt(0).toUpperCase() + 
             txt.substr(1).toLowerCase();});
    }
    var getTitle = function(index){
        return titles[index];
    }
    var getIncrementalDate = function(startDate,endDate,daysToAdd){
        var start = new Date(startDate);
        var end = new Date(endDate);
        var datearr =[];
        for(var i = start; i.getTime() < end.getTime(); i.setTime(i.getTime() + daysToAdd * (2*3600*1000) )) {
            var newDate = new Date(i);
            datearr.push(newDate);
        }
        return datearr;
    }
    if(isNaN(new Date(startDate)) || isNaN(new Date(endDate))){
        res.status(300).send({error :"Please enter valid date"}); 
        return next(); 
    }
    if(new Date(startDate).getTime() > new Date(endDate).getTime()){
        res.status(300).send({error :"Startdate should be less than Enddate"}); 
        return next(); 
    }
    Promise.all([
        mapCollection.findOne({live:true,name:mapname},{fields:{_id:0,id:1}}),
        usersCollection.find({"employee":{ $exists: true }}),
        companyCollection.findOne({ companyNo: parseInt(companyNo) }, { fields: { _id: 1 } })
    ])
    .then((promResults)=>{
        map = promResults[0];
        users = promResults[1];
        company = promResults[2];
        if(!company){
            res.status(300).send({error:"Wrong Company no ::"+companyNo});
            return next();   
        }
        if(!map){
            res.status(300).send({error : "No Map found for map " + mapname});
            next(); 
        }
        return seatCollection.find({"mapID" :map.id,"reservable":true})
    })
    .then((docs)=>{
        var seats = docs;
        if(seats.length == 0){
            res.status(300).send({error:"Failure ::" + "No seats found for Mapid " + map.id + " and reservable true"});
            next("error");  
        }
        var noOfSeatsTobeReserved = Math.floor((percentageOfSeatReserved/100) * seats.length);
        var resObj =[];
        //var dateObjs = prepareRandomDateObjs(new Date(startDate),new Date(endDate),stHour,stMin,etHour,etMin,isWeekDaysOnly,resObj,noOfElements);       
        var sendDateObjs = [];
        for(var seat of seats){
            var dateObjs = prepareRandomDateObjs(new Date(startDate),new Date(endDate),stHour,stMin,etHour,etMin,isWeekDaysOnly,resObj,noOfElements);
            var tempUserArr = [];
            /*var datearr = getIncrementalDate(startDate,endDate,timeToIncrease)
            if(datearr.length < noOfReservation){
                res.status(300).send({error:"Failure ::" + "NoOfreservation cannot be greater than time range numbers"});
                return next();
                 
            }*/
            var count =0 ;
            for(var i=0;i<dateObjs.length;i++){
                var user;
                if(tempUserArr.length > users.length){
                    if(count > tempUserArr.length){
                        count = 0
                    } else{
                        user = getUserByUserId(users,tempUserArr[count]);
                        count = count + 1;
                    }
                }else {
                    user =  getRandomUser(users,tempUserArr);
                }
                var dateObject = dateObjs[i];
                var	resObject = {
                    resID: utils.uuid(),
                    userID: user.userID,
                    userName: toTitleCase(user.first) + " " + toTitleCase(user.last),
                    title: getTitle(Math.floor(Math.random() * titles.length)),
                    private: Math.floor(Math.random() * 2) ? true : false,
                    bulletin: Math.floor(Math.random() * 2) ? true : false,
                    message: loremIpsum(),
                    start: dateObject.startDate.getTime(),
                    end: dateObject.endDate.getTime() ,
                    mapID: seat.mapID,
                    seatID:seat.seatID,
                    deptID:seat.deptID
                }
                updateData.push(resObject);
                tempUserArr.push(user.userID)
                
            }
            sendDateObjs.push(dateObjs);
            noOfSeatsTobeReserved--;
            console.log(noOfSeatsTobeReserved);
            if(noOfSeatsTobeReserved==0){break;}
        }
        Promise.all([
            seatReservationsCollection.bulkWrite(saveSeatReservation(updateData))
        ])
        .then((result)=>{
            res.status(200).send({result:"success","info":sendDateObjs});   
        })
        .catch((err)=>{
            res.status(300).send({error:"Failure ::" + err});   
        })
    })

})

function saveSeatReservation(data){
	var writeArray = [];
	var len = data.length;
	if(len == 0){
		console.log("0 Seat Reservation record Updated");
		return writeArray;
	}
	for(var i = 0;i < len;i++){
		writeArray.push({insertOne:{document:data[i]}});
    }
	console.log(len+" Seat Reservation record Updated");
	return writeArray;
}

function checkForUserAlreadyExist(user,tempUserArr){
    for(var id in  tempUserArr){
        if(user.userID == id){
            return false;
        }
    }
    return true;
}

function getRandomUser(users,tempUserArr){
    var correctUser = false;
    var user;
    var len = users.length;
    var counter = 0;
    while(!correctUser && counter<100){
        var user = users[Math.floor(Math.random() * len)];
        correctUser = checkForUserAlreadyExist(user,tempUserArr);
        counter = counter + 1;
    }
    return user;
}

function getUserByUserId(users,userID){
    for(var user of users){
        if(user.userID == userID){
            return user;
            break;
        }
    }
}

function prepareRandomDateObjs(startDate,endDate,stHour,stMin,etHour,etMin,weekDay,resObj,noOfElements){
    var oneDay = 24*60*60*1000; 
    var diffDays = Math.round(Math.abs((startDate.getTime() - endDate.getTime())/(oneDay)));
    diffDays = diffDays + 1;
    console.log("diffDays ::" + diffDays);
    var dateObjs = [];
    for(var j=0;j<diffDays;j++){
        var number =  parseInt(Math.floor(Math.random() * noOfElements));
        var checkWeekDay = weekDay ? isWeekDay(startDate) : true;
        console.log("checkWeekDay step 1 ::" + checkWeekDay);
        while(!checkWeekDay){
            diffDays = diffDays - 1;
            startDate.setTime(startDate.getTime() + oneDay); 
            checkWeekDay = isWeekDay(startDate);
        }
        if(number == 0){
            console.log("Zero " + new Date(startDate));
            resObj.push({"zero":new Date(startDate)});
        }
        var tempDateObjs = [];
        var tempStartDate = new Date(startDate);
        tempStartDate.setHours(stHour);
        tempStartDate.setMinutes(stMin);
        var tempEndDate = new Date(startDate);
        tempEndDate.setHours(etHour);
        tempEndDate.setMinutes(etMin);
        from = tempStartDate.getTime();
        to =  tempStartDate.getTime() + (60*90*1000);
        for (var i = 0; i < number; i++) {
            if(!checkItisBeforeEndDate(from,to,tempEndDate)){
                resObj.push({"error": "No more slot found for date " + new Date(startDate)});
                break;
            }
            var st = new Date(from + Math.random() * (to - from));
            et = new Date(st);
            et.setMinutes(st.getMinutes() + getRandomMinutes());
            stMin = et.getMinutes();
            var dateObj = {};
            dateObj.startDate = st;
            dateObj.endDate = et;
            dateObjs.push(dateObj);
            console.log("new date st :: " + st);
            console.log("new date et :: " + et);
            from = et.getTime() + (60*30*1000);
            to =  from + (60*90*1000);
        }
        startDate.setTime(startDate.getTime() + oneDay);
    }
    return dateObjs;
}

function checkItisBeforeEndDate(from,to,endDate){
    
        if(to > endDate.getTime()){
            return false;
        }
        return true;
}

function getRandomMinutes(){
    var minutes = [30,45,60,90,120];
    return minutes[Math.floor(Math.random() * minutes.length)];
}

function isWeekDay(date){
    for(var i = 1;i<=5;i++){
        if(date.getDay() == i){
            return true;
            break;
        }
    }
    return false;
}

module.exports = router;