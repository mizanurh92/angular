var router = require('express').Router();
var utils = require('../../../.././utils/utils');
var moment = require('moment');

router.post('/createTestSeatAssignment',function(req,res,next){

    console.log("Test seat assignment to user");
    var data = JSON.parse(req.body.data);
    var companyNo = data.companyNo;
    var mapname = data.mapName;
    var percentageOfassigned = data.percent;
    var startDate = data.dateStart;
    var endDate = data.dateEnd;
    var noOfDays = data.noOfDays;
    var mapCollection = req.db.get(companyNo + '-maps');
    var seatCollection = req.db.get(companyNo + '-seats');
    var seatAssignmentCollection = req.db.get(companyNo + '-seat-assignments');
    var usersCollection = req.db.get(companyNo + '-users');
    var companyCollection = req.db.get('companies'); 
    var updateData =[];
    var seatAssignMentData=[];
    var users,map;

    var getIncrementalDate = function(startDate,endDate,daysToAdd){
        var start = new Date(startDate+" 10:30");
        var end = new Date(endDate+" 02:10");
        var datearr =[];
        for(var i = start; i.getTime() < end.getTime(); i.setTime(i.getTime() + daysToAdd * 86400000 )) {
            var newDate = new Date(i);
          datearr.push(newDate);
        }
        return datearr;
    }
    if(isNaN(new Date(startDate)) || isNaN(new Date(endDate))){
        res.status(300).send({error :"Please enter valid date"}); 
        return next(); 
    }
    if(new Date(startDate).getTime() > new Date(endDate).getTime()){
        res.status(300).send({error :"Startdate should be less than Enddate"}); 
        return next(); 
    }
    Promise.all([
        mapCollection.findOne({live:true,name:mapname},{fields:{_id:0,id:1,officeID:1}}),
        usersCollection.find({"employee":{ $exists: true }}),
        companyCollection.findOne({ companyNo: parseInt(companyNo) }, { fields: { _id: 1 } })
    ])
    .then((promResults)=>{
        map = promResults[0];
        users = promResults[1];
        company = promResults[2];
        if(!company){
            res.status(300).send({error:"Wrong Company no ::"+companyNo});  
        }
        if(!map){
            res.status(300).send({error : "No Map found for map " + mapname});
        }
        return seatCollection.find({"mapID" :map.id,"assignmentStatus":"Unassigned","reservable":false})
    })
    .then((docs)=>{
        var seats = docs;
        var noOfSeatsTobeAssigned = Math.floor((percentageOfassigned/100) * seats.length);
        if(users.length < noOfSeatsTobeAssigned){
            res.status(300).send({error:"Failure ::" + "Users length is less than no of seats needs to be assigned,"
                                + "either increase the user count or decrease the percentage"});  
        }
        //for(var a=0;a<users.length;a++){
        var tempCounter = 0;
        for(var seat of seats) {
            var log =[];
           // var noOfLogObjectToCreate = getRandomInt(logStart,logend);
            var dateArr = getIncrementalDate(startDate,endDate,noOfDays);
            var imagePath;
            var count =0 ;
            var tempUser;
            var tempcount = 1;
            var tempUsers = createUserWithSpeciedLength(users,tempCounter)
            for(var i =0 ;i<dateArr.length; i++){
                
                if(log.length > users.length){
                    if(count > log.length){
                        count = 0
                    } else{
                        tempUser = getUserByUserId(tempUsers,log[count].id);
                        count = count + 1;
                    }
                } else {
                    tempUser = getRandomUser(tempUsers,log);
                }
                if(tempcount == dateArr.length){
                    tempUser = users[tempCounter];
                } else{
                    tempcount = tempcount + 1;
                }
                log.push(createRandomLogData(tempUser.userID,tempUser.employee.department.deptID,dateArr[i]));
                imagePath = tempUser.profileImages.smallProfile;
            }
            tempCounter = tempCounter + 1;
            seat.log = log;
            seat.assignmentStatus = "Assigned";
            var len = log.length;
            seat.userID = log[len-1].id;
            seat.imagePath = imagePath;
            var seatAssignment = {
                userID : seat.userID,
                mapID : map.id,
                seatID : seat.seatID
            }
            updateData.push(seat);
            seatAssignMentData.push(seatAssignment);
            noOfSeatsTobeAssigned--;
            console.log(noOfSeatsTobeAssigned);
            if(noOfSeatsTobeAssigned==0){break;}
        }
        Promise.all([
            seatCollection.bulkWrite(updateSeats(updateData)),
            seatAssignmentCollection.bulkWrite(updateSeatsAssignment(seatAssignMentData))
        ])
        .then((result)=>{
            res.status(200).send({result:"success"});   
        })
        .catch((err)=>{
            res.status(300).send({error:"Failure ::" + err});   
        })
    })
    .catch((err)=>{
        console.log(2,err);
        res.status(300).send({error:err});
    })

});

/*function shuffleUser(logArr){
    var count = 0;
    while()
    for(var log of logArr){
        if(log.id )
    }

}*/

function createUserWithSpeciedLength(users,item){
    var count = 0;
    var tempUser = [];
    while(count < users.length){
        if(count != item){
            tempUser.push(users[count]);
        }
        count = count + 1;
    }
    return tempUser;
}

function checkVisitorCodeAlreadyPresent(visitorCodes,codeValue){
    for (var code of visitorCodes){
        if(code.visitorCode == codeValue){
            return false;
        }
    }
    return true;
}

function checkForUserAlreadyExist(user,logArr){
    for(var log of logArr){
        if(user.userID == log.id){
            return false;
        }
    }
    return true;
}
function getUserByUserId(users,userID){
    for(var user of users){
        if(user.userID == userID){
            return user;
            break;
        }
    }
}
function getRandomUser(users,logArr){
    var correctUser = false;
    var user;
    var len = users.length;
    var counter = 0;
    while(!correctUser && counter<100){
        var user = users[Math.floor(Math.random() * len)];
        correctUser = checkForUserAlreadyExist(user,logArr);
        counter = counter + 1;
    }
    return user;
}

function createRandomLogData(userID,deptID,date){
    var data = {
        date : date.getTime(),
        assignment :"Assigned",
        status : Math.floor(Math.random() * 2) ? "active" : "inactive",
        id : userID,
        reservable : Math.floor(Math.random() * 2) ? true : false,
        deptID : deptID
    }
    return data;
}

function getRandomInt(min, max) {
    return parseInt(Math.floor(Math.random() * max)) 
}

function updateSeats(data){
	var update = data;
	var writeArray = [];
	var len = update.length;
	if(len == 0){
		console.log("0 Seats Updated");
		return writeArray;
	}
	var updateObj;
	for(var i = 0;i < len;i++){
		writeArray.push({
			updateOne: {
                filter: {mapID:update[i].mapID,seatID:update[i].seatID},
                update: {$set: {
                    assignmentStatus: update[i].assignmentStatus,
                    userID: update[i].userID,
                    imagePath : update[i].imagePath,
                    log : update[i].log
                }
            }
        }})
    }
	console.log(len+" Seats Updated");
	return writeArray;
}

function updateSeatsAssignment(data){
	var writeArray = [];
	var len = data.length;
	if(len == 0){
		console.log("0 Seats assignment data updated");
		return writeArray;
	}
	var updateObj;
    for(var i = 0;i < len;i++) {
        userID = data[i].userID;
		writeArray.push({
			updateOne: {
                filter: {userID},
                update: {$set:data[i]},
                upsert: true // upsert probably isn't necessary
            }
		})
	}

	console.log(len+" Seats assignment data Updated");
	return writeArray;
}

module.exports = router;
