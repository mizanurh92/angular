var router = require('express').Router();
const axios = require('axios');
var AWS = require('aws-sdk');
var utils = require('../../../.././utils/utils');
const uuid = utils.uuid;
var config = require('../../../.././config/config');
var profilePath = config.profilePath;
var authenticate = require('../../../.././middleware/authenticate').authenticate;
var stream = require('stream');
var path = require("path");
var awsBucket = config.bucket;
var request = require('request');
var await = require('await')
//var async = require("async");

//aws credentials
AWS.config = new AWS.Config();
AWS.config.accessKeyId = "AKIAIUQMGWG2232Z6AOA";
AWS.config.secretAccessKey = "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";
AWS.config.region = "us-east-1";
AWS.config.apiVersions = {"s3": "2006-03-01"};
var s3 = new AWS.S3();

router.post('/createTestUser',function(req,res){
        var params = {}; 
        console.log("Test User Data Creation process");
        var data = JSON.parse(req.body.data);
        var companyNo = data.companyNo;
        var officearr = data.office;
        var deptCollection = req.db.get(companyNo + '-departments');
        var officeCollection = req.db.get(companyNo + '-offices');
        var departments, users, len,company;
        var insertArray = [];
        var companyCollection = req.db.get('companies');        
        var titles = {
                'Unassigned': [
                                'Intern'
                ],
                'Accounting': [
                        'Sr. Accountant',
                        'Java Developer',
                        'Controller',
                        'Internal Auditor',
                        'Jr. Accountant',
                        'Payables Specialist',
                        'Compliance Auditor',
                        'Receivables Specialist',
                        'Bookkeeper',
                        'Information Systems Analyst',
                        'Revenue Recognition Specialist',
                        'SOX Compliance Auditor'
                ],
                'Finance': [
                                'CFO',
                                'Sr. Financial Analyst',
                                'FP&A Analyst',
                                'Data Scientist',
                                'Director of Finance',
                                'Financial Analyst',
                                'Finacial Modeler',
                ],
                'Development': [
                                'Sr. Java Developer',
                                'Java Developer',
                                'Jr. Java Developer',
                                'Software Architect',
                                'Enterprise Architect',
                                'Program Manager',
                                'Project Manager',
                                'Product Manager',
                                'Sr. QA Analyst',
                                'QA Analyst',
                                'Jr. QA Analyst',
                                'Automation Engineer',
                                'Technical Writer',
                                'Tech Lead',
                                'DBA',
                ],
                'Marketing': [
                                'Sr. Marketing Associate',
                                'Marketing Associate',
                                'VP Marketing',
                                'SEO Specialist',
                                'Social Media Specialist',
                                'Director of Marketing',
                                'Digital Marketing Lead'
                ],
                'Sales': [
                                'VP Sales',
                                'Director of Sales',
                                'Sales Manager',
                                'Sales Associate',
                                'Outbound Sales Associate',
                                'Sr. Sales Associate'
                ],
                'Executive': [
                                'CEO',
                                'CIO',
                                'COO'
                ],
                'Human Resources':[
                        'VP Human Resources',
                        'HR Specialist',
                        'Compliance Specialist',
                        'Employee Trainer',
                        'Director of Human Resources'
                ],
                'Admin':[
                       'Associate Admin',
                       'Seniour Admin'
               ]
        }

        var getTitle = function(departmentName){
                var titleList = titles[departmentName];
                //console.log(departmentName)
                var len = titleList.length;
                var index = Math.floor(Math.random() * len);
                return titleList[index];
        }

        var toTitleCase = function(str){
            return str.replace(/\w\S*/g, function(txt){return txt.charAt(0).toUpperCase() + 
                 txt.substr(1).toLowerCase();});
        }

        Promise.all([
                officeCollection.find({},{fields:{_id:0,officeID:1,name:1}}),
                deptCollection.find({}),
                companyCollection.findOne({ companyNo: parseInt(companyNo) }, { fields: { _id: 1 } })
                        ])
        .then((results)=>{
                offices = results[0];
                departments = results[1];
                company = results[2];
                if(!company){
                        res.status(300).send("Wrong Company no ::"+companyNo); 
                        return next();  
                }
                return axios.get('https://randomuser.me/api/?results=100',{
                        params:{
                                nat: params.nat || 'us',
                                exc: params.exc || 'gender,location,login,dob,registered',
                                results: params.results
                        }
                })
        })
        .then((data) => {
                users = data.data.results;
                len = users.length;
                console.log(len);
                var counter = 0;
                var userdata = []; 
                for(var office of officearr){
                        var noOfUser = office.noOfUser;
                        var deptArr = office.department;
                        var departmentArr;
                        var officeObj = findOffice(offices,office.name);
                        if(officeObj == null){
                                res.status(300).send("Invalid Office ::"+office.name);
                        }
                        for ( var dept of deptArr) {
                            var department  = findDepartMent(departments,dept.name);
                            if(department ==null){
                                res.status(300).send("Invalid department " + dept.name);
                                return next();   
                            }
                            var noOfUserToCreate = Math.floor((dept.percent/100) * noOfUser);
                            if(noOfUserToCreate > 100){
                                res.status(300).send("No of users cannot be greater than 100");
                                return next(); 
                            }
                            for(var i = 0; i < noOfUserToCreate; i++){
                                var user = users[counter];
                                user.employee = {
                                        employeeID: user.id == null ? Math.floor(1000 + Math.random() * 9000) : user.id.value.slice(-7),
                                        department,
                                        title: getTitle(department.deptName)
                                }
                                user.first = toTitleCase(user.name.first);
                                user.last = toTitleCase(user.name.last);
                                user.userStatus = "unassigned";
                                user.userID = uuid();
                                user.userType = "user";
                                user.tokenhash = uuid();
                                user.office = officeObj;
                                user.contact = {
                                        cell:user.phone
                                };
                                user.contactable = Math.floor(Math.random() * 2) ? true : false; 
                                user.codeRequired = Math.floor(Math.random() * 2) ? true : false; 
                                
                                //download()
                                var largeProfileFile = company._id + '/' + user.userID + '/' + "largeProfile.png"; 
                                var mediumProfileFile = company._id + '/' + user.userID + '/' + "smallProfile.png"; 
                                var smallProfileFile = company._id + '/' + user.userID + '/' + "thumbnailProfile.png";   
                                /*async.eachLimit(user.picture.thumbnail, threads, function(url, next){
                                  download(url, filename, next);
                                }, function(){
                                   console.log('finished');
                                })*/
                                user.profileImages= {
                                        largeProfile: profilePath + largeProfileFile,
                                        mediumProfile: profilePath + mediumProfileFile,
                                        smallProfile: profilePath + smallProfileFile
                                }
                                user.largeProfileFile = largeProfileFile;
                                user.mediumProfileFile = mediumProfileFile;
                                user.smallProfileFile = smallProfileFile;
                                delete user.name;
                                delete user.nat;
                                delete user.phone;
                                
                                userdata.push(user);
                                counter=counter +1 ;
                            }
                            
                        }
                }
                for(var user of userdata) {
                        
                        Promise.all([ download(user.picture.large,user.largeProfileFile),
                                download(user.picture.medium,user.mediumProfileFile),
                                download(user.picture.thumbnail,user.smallProfileFile)])
                        .then((result)=>{
                                console.log("File uploaded");
                        })
                        .catch((err)=>{
                                console.log(err);
                        })
                        delete user.picture;
                        delete user.largeProfileFile;
                        delete user.mediumProfileFile;
                        delete user.smallProfileFile;
                }
                var writeArray = addBulkUser(userdata);
                var tempUsercollection = req.db.get(companyNo + '-users');	
                tempUsercollection.bulkWrite(writeArray)
                .then((result)=>{
                    console.log("User data saved successfully");
                    res.status(200).send("User data saved successfully");
                })
                .catch((err)=>{
                    console.log(err);
                    res.status(300).send(err);
                })

        })
        .catch((error) => {
                console.log("error:-"+error);
                res.status(300).send();
        });
})

//Find the Office object for the given department Name 
//return null department is not found
function findOffice(officeData,officeName){
        for(var item of officeData){
            if(utils.compareStrings(item.name,officeName,true,true)){
                delete item._id;
                officeFound =true;
                return item;
            }
        }
  }

// Prepare the array of valid user data for database insertions.
function addBulkUser(data){
	var writeArray = [];
	var len = data.length;
	if(len == 0){
		console.log("0 Users Added");
		return writeArray;
	}
	for(var i = 0;i < len; i++){
		writeArray.push({insertOne:{document:data[i]}});
	}
	console.log(len+" Users Added");
	return writeArray;
}
//Find the department object for the given department Name 
//Set the errorObj if department is not found.
function findDepartMent(deptData,department){
        for(var item of deptData){
            if(utils.compareStrings(item.deptName,department,true,true)){
                delete item._id;
                return item;
            }
        }
    
 }

 function download (uri,key){
       new Promise(resolve => await(request.head(uri, function(err, res, body){
          console.log('content-type:', res.headers['content-type']);
          console.log('content-length:', res.headers['content-length']);
          request(uri).pipe(uploadFromStream(key)).on('finish', function(){
                  console.log("done");
                  resolve();
          });
        })));
        
}      
    function uploadFromStream(key) {
        var pass = new stream.PassThrough();
        var params = {
            Bucket: awsBucket,
            Key: key,
            Body: pass,
            ACL: 'public-read',
            Metadata: {
                'Content-Type': 'image/png'
            }
        };
        s3.upload(params, function(err, data) {
                if(err != null){
                   console.log("Error ::" + err);
                   res.status(300).send(err);
                }else{
                   console.log(data);
                }
        });
      
        return pass;
    }

module.exports = router;