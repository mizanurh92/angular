var router = require('express').Router();

router.use('/user',require('./user/testUserData'));
router.use('/department',require('./department/testDepartMent'));
router.use('/company',require('./company/testCompany'));
router.use('/visitor',require('./visitorCode/testVisitorCode'));
router.use('/visitorLog',require('./visitorLog/testVisitorLog'));
router.use('/seat',require('./seat/testassignSeat'));
router.use('/seat',require('./seat/testSeatReservation'));
router.use('/room',require('./room/testRoomReservation'));
module.exports = router;