var fs = require('fs');
var AWS = require('aws-sdk');
var router = require('express').Router();
var authenticate = require('../../.././middleware/authenticate').authenticate;
var utils = require('../../.././utils/utils');
var multer = require('multer');
var storage = multer.memoryStorage();
var upload = multer({storage:storage});
var config = require('../../.././config/config');
var awsBucket = config.bucket;
var profilePath = config.profilePath;

//aws credentials
AWS.config = new AWS.Config();
AWS.config.accessKeyId = "AKIAIUQMGWG2232Z6AOA";
AWS.config.secretAccessKey = "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";
AWS.config.region = "us-east-1";
AWS.config.apiVersions = {"s3": "2006-03-01"};
var s3 = new AWS.S3();


router.post('/profiles/myProfile',authenticate,upload.array('croppedImage'),function(req,res){
	if(req.user){
		var company = req.user.companyID;
		var user = req.user.userID;
		var originalname = req.files[0].originalname;
		var fileName = originalname + '.png';
		var filePath = profilePath + company + '/' + user + '/' + fileName;
		var companyNo = req.companyNo;
		var collection = req.db.get(companyNo + '-users');
		var dbItem;

		switch(originalname){
			case 'largeProfile':
				dbItem = {'profileImages.largeProfile':filePath};
			break;
			case 'smallProfile':
				dbItem = {'profileImages.mediumProfile':filePath};
			break;
			case 'thumbnailProfile':
				dbItem = {'profileImages.smallProfile':filePath};
			break;
		}

		var params = {
		    Bucket: awsBucket,
		    Key: company + '/' + user + '/' + fileName,
		    Body: req.files[0].buffer,
		    ACL: 'public-read',
		    Metadata: {
		        'Content-Type': 'image/png'
		    }
		};

	    s3.upload(params, function(err, data){
	    	if(err){
	    		console.log(err)
	    		res.status(300).send({data:4});
	    		return;
	    	}
			collection.findOneAndUpdate({"userID":user.toString()},{$set:dbItem})
				.then((result)=>{
					res.status(200).send({images:result.profileImages})
				})
				.catch((err)=>{
					console.log(2,err);
					res.status(300).send({data:4});
				})
	    })
	} else {
		console.log('sending null')
		res.send({data:null});
	}
})

router.post('/profiles/upload/:user',authenticate,upload.array('croppedImage'),function(req,res){
	if(req.user){
		var company = req.user.companyID;
		var user = req.params.user;
		var originalname = req.files[0].originalname;
		var fileName = originalname + '.png';
		var filePath = profilePath + company + '/' + user + '/' + fileName;
		var companyNo = req.companyNo;
		var collection = req.db.get(companyNo + '-users');
		var dbItem;

		switch(originalname){
			case 'largeProfile':
				dbItem = {'profileImages.largeProfile':filePath};
			break;
			case 'smallProfile':
				dbItem = {'profileImages.mediumProfile':filePath};
			break;
			case 'thumbnailProfile':
				dbItem = {'profileImages.smallProfile':filePath};
			break;
		}

		var params = {
		    Bucket: awsBucket,
		    Key: company + '/' + user + '/' + fileName,
		    Body: req.files[0].buffer,
		    ACL: 'public-read',
		    Metadata: {
		        'Content-Type': 'image/png'
		    }
		};

	    s3.upload(params, function(err, data){
	    	if(err){
	    		res.status(300).send({data:4});
	    		return;
	    	}
			collection.findOneAndUpdate({"userID":user.toString()},{$set:dbItem})
				.then((result)=>{
					res.status(200).send({images:result.profileImages})
				})
				.catch((err)=>{
					console.log(2,err);
					res.status(300).send({data:4});
				})
	    })
	} else {
		console.log('sending null')
		res.send({data:null});
	}
})

router.post('/profiles/getCurrentUserImages',authenticate,function(req,res){
	if(req.user){
		var companyNo = req.companyNo;
		var collection = req.db.get(companyNo + '-users');
		var userID = req.user.userID;
		collection.find({userID:userID.toString()},{fields:{_id:0,profileImages:1}})
		.then((result)=>{
			var userData = result[0];
			res.status(200).send({images:userData.profileImages})
		})
		.catch((err)=>{
			res.status(300).send({data:null});			
		})
	} else{
		res.status(300).send({});
	}
})

router.post('/profiles/getUserImages',authenticate,function(req,res){
	if(req.user){
		var companyNo = req.companyNo;
		var collection = req.db.get(companyNo + '-users');
		var userID = req.body.user;
		collection.find({userID:userID.toString()},{fields:{_id:0,profileImages:1}})
		.then((result)=>{
			var userData = result[0];
			res.status(200).send({images:userData.profileImages})			
		})
		.catch((err)=>{
			res.status(300).send({data:null});			
		})
	} else{
		res.status(300).send({});
	}
})

module.exports = router;