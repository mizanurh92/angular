var router = require('express').Router();
var authenticate = require('../../.././middleware/authenticate').authenticate;
var utils = require('../../.././utils/utils');

// This route populates the table of current departments in the departments menu area
router.get('/navtable',authenticate,function(req,res){
	if(req.user){
		console.log('Get Department List')
		var companyNo = req.companyNo;
		var companyID = req.user.companyID;
		var departmentCollection = req.db.get(companyNo + '-departments');
		departmentCollection.find({},{fields:{_id:0}})
		.then((results)=>{
			var dept;
			for(var i = 0; i < results.length; i++){
				dept = results[i];
				if(dept.active){
					dept.status = "Active";
				} else {
					dept.status = "Inactive";
				}
				delete dept.active;
			}
			res.status(200).send({data:results});
		})
		.catch((err)=>{
			console.log(err);
			res.status(300).send({});
		})
	} else{
		res.status(300).send({});
	}
})

// This route allows the creation of departments through the departments menu table
router.post('/createNewDepartment',authenticate,function(req,res){
	if(req.user){
		var companyNo = req.companyNo;
		var departmentCollection = req.db.get(companyNo + '-departments');		
		var data = req.body.data[0];

		var deptObj = {
			deptID: utils.uuid(),
			deptName: data.deptName,
			deptNumber: data.deptNumber,
			active: true
		}

		departmentCollection.insert(deptObj)
		.then((results)=>{
			if(results.active){
				results.status = "Active";
			} else {
				results.status = "Inactive";
			}
			delete results.active;
			delete results._id;
			res.status(200).send({data:[results]});
		})
		.catch((err)=>{
			console.log(err);
			res.status(300).send({});
		})		

	} else{
		res.status(300).send({});
	}
})

router.put('/editDepartment',authenticate,function(req,res){
	if(req.user){
		console.log('Edit Department')
		var companyNo = req.companyNo;
		var deptartmentCollection = req.db.get(companyNo + '-departments');		
		var deptID = Object.keys(req.body.data)[0];
		var department = req.body.data[deptID];
		var deptObj = {
			deptName: department.deptName,
			deptNumber: department.deptNumber,
			active: department.status == "Active"
		}

		deptartmentCollection.findOneAndUpdate({deptID},{$set:deptObj})
		.then((results)=>{
			if(results.active){
				results.status = "Active";
			} else {
				results.status = "Inactive";
			}
			delete results.active;
			delete results._id;
			res.status(200).send({data:[results]});
		})
		.catch((err)=>{
			console.log(err);
			res.status(300).send();
		})
	} else{
		res.status(498).send();
	}
})


module.exports = router;