var router = require('express').Router();
var authenticate = require('../../.././middleware/authenticate').authenticate;
var utils = require('../../.././utils/utils');

router.use('/reports',require('./reports'));
router.use('/summary',require('./summary'));

// This populates the offices table during the map creation process.
router.get('/newmaptable',authenticate,function(req,res){
	if(req.user){
		console.log('get office list')
		var companyNo = req.companyNo;
		var companyID = req.user.companyID;
		var officeCollection = req.db.get(companyNo + '-offices');
		officeCollection.find({companyID,status:'active'})
		.then((results)=>{
			res.status(200).send({data:results});
		})
		.catch((err)=>{
			console.log(err);
			res.status(300).send({});
		})

	} else{
		res.status(300).send({});
	}
})

// This route populates the table of current offices in the offices menu area
router.get('/navtable',authenticate,function(req,res){
	if(req.user){
		console.log('get office list')
		var companyNo = req.companyNo;
		var companyID = req.user.companyID;
		var officeCollection = req.db.get(companyNo + '-offices');
		officeCollection.find({companyID,status:'active'})
		.then((results)=>{
			res.status(200).send({data:results});
		})
		.catch((err)=>{
			console.log(err);
			res.status(300).send({});
		})

	} else{
		res.status(300).send({});
	}
})

// This route allows the creation of offices through the office menu table
router.post('/createNewOffice',authenticate,function(req,res){
	if(req.user){
		var companyNo = req.companyNo;
		var officeCollection = req.db.get(companyNo + '-offices');		
		var companyID = req.user.companyID;
		var officeID = utils.uuid();
		var data = req.body;
		var officeObj = {
			officeID,
			companyID,
			name: data.name,
			address1: data.address1,
			address2: data.address2,
			city: data.city,
			state: data.state,
			zip: data.zip,
			country: data.country,
			status: 'active'
		}
		officeCollection.insert(officeObj)
		.then((results)=>{
			res.status(200).send({});
		})
		.catch((err)=>{
			console.log(err);
			res.status(300).send({});
		})

	} else{
		res.status(300).send({});
	}
})

// This route removes an office object based on a delete event from the offices menu table
// Doesn't actually delete the office or the associated maps, but rather deactivates them
// this is so that historical analytics can continue to be used with accuracy
router.delete('/removeoffice',authenticate,function(req,res){
	if(req.user){
		var companyNo = req.companyNo;
		var officeCollection = req.db.get(companyNo + '-offices');
		var mapCollection = req.db.get(companyNo + '-maps');
		var roomsCollection = req.db.get(companyNo + '-rooms');
		var seatsCollection = req.db.get(companyNo + '-seats');
		var zonesCollection = req.db.get(companyNo + '-zones');
		var seatAssignCollection = req.db.get(companyNo + '-seat-assignments');
		var companyID = req.user.companyID;
		var data = req.query.data;
		var officeID = Object.keys(data)[0];

		officeCollection.findOneAndUpdate({officeID,companyID},{status:'inactive'}) // Changes the target office to inactive
		.then((results)=>{
			return mapCollection.update({officeID,companyID},{status:'inactive'}); // Changes all assigned maps for the office to inactive
		})
		.then((results)=>{
			return mapCollection.find({officeID,companyID},{id:1}); // Finds the id's of all the maps assigned ot the office and returns them	
		})
		.then((results)=>{
			var orList = [];
			for(i in results){
				orList.push({mapID:results[i].id});
			}
			
			if(orList.length == 0){
				return;
			}

			return Promise.all([ // Using the map id's in an 'or list', this deactivates all seats, rooms, and zones for the map and
					// removes all seat assignments.  The removal of seat assignments should mean that all users assigned to the office will
					// now show up as unassigned unless they are assigned elsewhere.  Restoring the office/map will not restore these assignments.
					seatsCollection.update({$or:orList},{status:'inactive'}),
					roomsCollection.update({$or:orList},{status:'inactive'}),
					zonesCollection.update({$or:orList},{status:'inactive'}),
					seatAssignCollection.remove({$or:orList}),
					// TODO deactivate room and seat reservations starting or ending after the current date/time
				])
		})
		.then((results)=>{
			res.status(200).send({});
		})
		.catch((err)=>{
			console.log(err);
			res.status(300).send({});
		})
	} else{
		res.status(300).send({});
	}
})

router.post('/editoffice',authenticate,function(req,res){
	if(req.user){
		console.log('Edit Office')
		var companyNo = req.companyNo;
		var officeCollection = req.db.get(companyNo + '-offices');		
		var data = req.body;
		var officeID = req.body.officeID;
		delete data.officeID;

		officeCollection.findOneAndUpdate({officeID},{$set:data})
		.then((result)=>{
			res.status(200).send();
		})
		.catch((err)=>{
			console.log(err);
			res.status(300).send();
		})

	} else{
		res.status(498).send();
	}
})


module.exports = router;