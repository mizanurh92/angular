var router = require('express').Router();
var authenticate = require('../../.././middleware/authenticate').authenticate;
var utils = require('../../.././utils/utils');
var moment = require('moment');

// This route populates the table of current maps in the offices menu area
router.get('/mapList',authenticate,function(req,res){
	if(req.user){
		console.log('Get Office Map List Report')
		var companyNo = req.companyNo;
		var officeID = req.query.officeID;
		console.log(req.query)
		
		var mapCollection = req.db.get(companyNo + '-maps');
		var seatCollection = req.db.get(companyNo + '-seats');
		var roomCollection = req.db.get(companyNo + '-rooms');
		var zoneCollection = req.db.get(companyNo + '-zones');


		var orList = [];
		var mapObj = {};
		var map, mapID, seats, seat, rooms, room, zones, zone;
		var resultArray = [];
		mapCollection.find({officeID,live:true},{fields:{_id:0,date:0,officeID:0,live:0}})
		.then((maps)=>{
			console.log(maps)
			for(var i = 0; i < maps.length; i++){
				map = maps[i];
				map.mapID = map.id;
				delete map.id;
				mapID = map.mapID;
				orList.push({
					mapID,
					status:"active"
				});
				map.seats = [];
				map.rooms = [];
				map.zones = [];
				mapObj[mapID] = map;
			}

			if(!orList.length){
				throw "No Maps";
			}

			return Promise.all([
				seatCollection.find({$or:orList},{fields:{_id:0,mapID:1,seatID:1,assignmentStatus:1,reservable:1}}),
				roomCollection.find({$or:orList},{fields:{_id:0,mapID:1,roomID:1}}),
				zoneCollection.find({$or:orList},{fields:{_id:0,mapID:1,zoneID:1}})
			])

		})
		.then((results)=>{
			seats = results[0];
			rooms = results[1];
			zones = results[2];

			for(var i = 0; i < seats.length; i++){
				seat = seats[i];
				mapID = seat.mapID;
				mapObj[mapID].seats.push(seat);
			}

			for(var i = 0; i < rooms.length; i++){
				room = rooms[i];
				mapID = room.mapID;
				mapObj[mapID].rooms.push(room);
			}

			for(var i = 0; i < zones.length; i++){
				zone = zones[i];
				mapID = zone.mapID;
				mapObj[mapID].zones.push(zone);
			}

			for(var i in mapObj){
				resultArray.push(mapObj[i]);
			}
			console.log(resultArray)
			res.status(200).send({data:resultArray});
		})
		.catch((err)=>{
			console.log(err)
			if(err == "No Maps"){
				res.status(300).send({data:resultArray});
			} else {
				res.status(300).send({data:[]});			
			}
		})

	} else{
		res.status(498).send({});
	}
})

// This route populates the table of current seats in the offices menu area
router.get('/seatList',authenticate,function(req,res){
	if(req.user){
		console.log('Get Office Seat List Report')
		var companyNo = req.companyNo;
		var officeID = req.query.officeID;
		
		var mapCollection = req.db.get(companyNo + '-maps');
		var seatCollection = req.db.get(companyNo + '-seats');
		var userCollection = req.db.get(companyNo + '-users');
		var deptCollection = req.db.get(companyNo + '-departments');

		var orList = [];
		var mapObj = {};
		var len, map, mapID, seats, seat, users, user, userID, departments, department, deptID;
		var resultArray = [];
		var userList = [];
		var userObj = {};
		var deptList = [];
		var deptObj = {};
		var promiseList = [];
		var firstIsUser;
		mapCollection.find({officeID,live:true},{fields:{_id:0,name:1,id:1,floorNumber:1,suiteNumber:1}})
		.then((maps)=>{
			for(var i = 0; i < maps.length; i++){
				map = maps[i];
				map.mapID = map.id;
				delete map.id;
				mapID = map.mapID;
				orList.push({
					mapID,
					status:"active"
				});
				mapObj[mapID] = map;
			}

			if(!orList.length){
				throw "No Maps";
			}

			return seatCollection.find({$or:orList},{fields:{_id:0,log:0,date:0,created:0}})
		})
		.then((results)=>{
			seats = results;
			len = seats.length;
			for(var i = 0; i < len; i++){
				seat = seats[i];
				mapID = seat.mapID;
				deptID = seat.deptID;
				userID = seat.userID;
				map = mapObj[mapID];
				seat.mapName = map.name;
				seat.suite = map.suiteNumber;
				seat.floor = map.floorNumber;
				deptObj[deptID] = null;
				if(userID){ userObj[userID] = null; }
				seat.type = seat.reservable ? "Reservable" : "Assignable";
			}

			for( var i in userObj){
				userList.push({
					userID:i
				})
			}

			for( var i in deptObj){
				deptList.push({
					deptID:i
				})
			}

			if(userList.length){
				promiseList.push(userCollection.find({$or:userList},{fields:{_id:0,userID:1,first:1,last:1}}))
				firstIsUser = true;
			}

			if(deptList.length){
				promiseList.push(deptCollection.find({$or:deptList},{fields:{_id:0,deptName:1,deptID:1}}))
			}

			if(promiseList.length){
				return Promise.all(promiseList);
			} else {
				return "None";
			}

			res.status(200).send({data:resultArray});
		})
		.then((results)=>{
			if(results != "None"){
				if(firstIsUser){
					users = results[0] ? results[0] : [];
					departments = results[1] ? results[1] : [];
				} else {
					departments = results[0] ? results[0] : [];
				}
			}

			if(users && users.length){
				len = users.length;
				for(var i = 0; i < len; i++){
					user = users[i];
					userID = user.userID;
					userObj[userID] = user;
				}
			}

			if(departments && departments.length){
				len = departments.length;
				for(var i = 0; i < len; i++){
					department = departments[i];
					deptID = department.deptID;
					deptObj[deptID] = department;
				}
			}

			len = seats.length;
			for(var i = 0; i < len; i++){
				seat = seats[i];
				seat.department = seat.deptID && deptObj[seat.deptID] ? deptObj[seat.deptID].deptName : null;
				seat.assignedTo = seat.userID && userObj[seat.userID] ? userObj[seat.userID].first 
					+ " " + userObj[seat.userID].last : null;
			}

			console.log(seats)
			res.status(200).send({data:seats});

		})
		.catch((err)=>{
			console.log(err)
			if(err == "No Maps"){
				res.status(200).send({data:[]});
			} else {
				res.status(300).send({data:[]});			
			}
		})

	} else{
		res.status(498).send({});
	}
})

// This route populates the table of current rooms in the offices menu area
router.get('/roomList',authenticate,function(req,res){
	if(req.user){
		console.log('Get Office Room List Report')
		var companyNo = req.companyNo;
		var officeID = req.query.officeID;
		
		var mapCollection = req.db.get(companyNo + '-maps');
		var roomCollection = req.db.get(companyNo + '-rooms');
		var deptCollection = req.db.get(companyNo + '-departments');

		var orList = [];
		var mapObj = {};
		var len, map, mapID, rooms, room, roomID, departments, department, deptID;
		var resultArray = [];
		var deptList = [];
		var deptObj = {};
		var promiseList = [];

		mapCollection.find({officeID,live:true},{fields:{_id:0,name:1,id:1,floorNumber:1,suiteNumber:1}})
		.then((maps)=>{
			for(var i = 0; i < maps.length; i++){
				map = maps[i];
				map.mapID = map.id;
				delete map.id;
				mapID = map.mapID;
				orList.push({
					mapID,
					status:"active"
				});
				mapObj[mapID] = map;
			}

			if(!orList.length){
				throw "No Maps";
			}

			return Promise.all([
				roomCollection.find({$or:orList},{fields:{_id:0,log:0,date:0,created:0,
				equipment:0,accessibility:0,ameneties:0,status:0}}),
				deptCollection.find({},{fields:{_id:0}})
			])
		})
		.then((results)=>{
			rooms = results[0];
			departments = results[1];

			for(var i = 0; i < departments.length; i++){
				department = departments[i];
				deptObj[department.deptID] = department;
			}

			len = rooms.length;
			for(var i = 0; i < len; i++){
				room = rooms[i];
				mapID = room.mapID;
				map = mapObj[mapID];
				room.mapName = map.name;
				room.floor = map.floorNumber;
				room.suite = map.suiteNumber;
				room.department = deptObj[room.deptID].deptName;
			}

			res.status(200).send({data:rooms});
		})
		.catch((err)=>{
			console.log(err)
			if(err == "No Maps"){
				res.status(200).send({data:[]});
			} else {
				res.status(300).send({data:[]});			
			}
		})

	} else{
		res.status(498).send({});
	}
})

// This route populates the table of current zones in the offices menu area
router.get('/zoneList',authenticate,function(req,res){
	if(req.user){
		console.log('Get Office Zone List Report')
		var companyNo = req.companyNo;
		var officeID = req.query.officeID;
		
		var mapCollection = req.db.get(companyNo + '-maps');
		var zoneCollection = req.db.get(companyNo + '-zones');
		var deptCollection = req.db.get(companyNo + '-departments');

		var orList = [];
		var mapObj = {};
		var len, map, mapID, zones, zone, zoneID, departments, department, deptID;
		var resultArray = [];
		var deptList = [];
		var deptObj = {};
		var promiseList = [];

		mapCollection.find({officeID,live:true},{fields:{_id:0,name:1,id:1,floorNumber:1,suiteNumber:1}})
		.then((maps)=>{
			len = maps.length;
			for(var i = 0; i < len; i++){
				orList.push({mapID:maps[i].id,status:"active"});
				mapObj[maps[i].id] = maps[i];
			}

			if(!orList.length){ throw "No Maps" }

			return Promise.all([
				zoneCollection.find({$or:orList},{fields:{_id:0,mapName:0,status:0}}),
				deptCollection.find({},{fields:{_id:0}})
			])
		})
		.then((results)=>{
			zones = results[0];
			departments = results[1];

			len = departments.length;
			for(var i = 0; i < len; i++){
				deptObj[departments[i].deptID] = departments[i];
			}

			len = zones.length;
			for(var i = 0; i < len; i++){
				zone = zones[i];
				map = mapObj[zone.mapID];
				zone.mapName = map.name;
				zone.floor = map.floorNumber;
				zone.suite = map.suiteNumber;
				zone.department = deptObj[zone.deptID].deptName;
			}

			res.status(200).send({data:zones});
		})
		.catch((err)=>{
			console.log(err)
			if(err == "No Maps"){
				res.status(200).send({data:[]});
			} else {
				res.status(300).send({data:[]});			
			}
		})

	} else{
		res.status(498).send({});
	}
})

// This route populates the table of current occupants in the offices menu area
router.get('/occupantList',authenticate,function(req,res){
	if(req.user){
		console.log('Get Office Occupant List Report')
		var companyNo = req.companyNo;
		var officeID = req.query.officeID;
		
		var mapCollection = req.db.get(companyNo + '-maps');
		var deptCollection = req.db.get(companyNo + '-departments');
		var seatAssignCollection = req.db.get(companyNo + '-seat-assignments');
		var seatResCollection = req.db.get(companyNo + '-seat-reservations');
		var roomResCollection = req.db.get(companyNo + '-room-reservations');
		var userCollection = req.db.get(companyNo + '-users');
		var seatCollection = req.db.get(companyNo + '-seats');
		var roomCollection = req.db.get(companyNo + '-rooms');

		var currentTime = moment().valueOf();

		var orList1 = []; // mapID only
		var orList2 = []; // mapID with date parameters
		var mapObj = {};
		var len, map, mapID, departments, department, deptID, title, employeeID;
		var resultArray = [];
		var deptList = [];
		var deptObj = {};
		var userObj = {};
		var seatObj = {};
		var roomObj = {};
		var promiseList = [];
		var seatAssign, seatRes, roomRes;
		var user, users, userID;
		var seat, seats, seatID;
		var room, rooms, roomID;
		var userList = [];
		var seatList = [];
		var roomList = [];
		var uniqueUser = [];
		var uniqueSeat = [];
		var uniqueRoom = [];
		var assignment, reservation;

		Promise.all([
			mapCollection.find({officeID,live:true},{fields:{_id:0,name:1,id:1,floorNumber:1,suiteNumber:1}}),
			deptCollection.find({},{fields:{_id:0}})
		])
		.then((results)=>{
			maps = results[0];
			departments = results[1];

			len = maps.length;
			for(var i = 0; i < len; i++){
				orList1.push({mapID:maps[i].id});
				orList2.push({ start:{$lte:currentTime}, end:{$gte:currentTime}, mapID:maps[i].id});
				mapObj[maps[i].id] = maps[i];
			}

			if(!orList1.length){ throw "No Maps" }

			len = departments.length;
			for(var i = 0; i < len; i++){
				deptObj[departments[i].deptID] = departments[i];
			}			

			return Promise.all([
				seatAssignCollection.find({$or:orList1},{fields:{_id:0,userID:1,seatID:1}}),
				seatResCollection.find({$or:orList2},{fields:{_id:0,userID:1,seatID:1}}),
				roomResCollection.find({$or:orList2},{fields:{_id:0,userID:1,roomID:1}}),
			])
		})
		.then((results)=>{
			seatAssign = results[0];
			seatRes = results[1];
			roomRes = results[2];

			len = seatAssign.length;
			for(var i = 0; i < len; i++){
				userList.push(seatAssign[i].userID);
				seatList.push(seatAssign[i].seatID);
			}

			len = seatRes.length;
			for(var i = 0; i < len; i++){
				userList.push(seatRes[i].userID);
				seatList.push(seatRes[i].seatID);				
			}

			len = roomRes.length;
			for(var i = 0; i < len; i++){
				userList.push(roomRes[i].userID);
				roomList.push(roomRes[i].roomID);				
			}

			uniqueUser = [... new Set(userList)];
			uniqueSeat = [... new Set(seatList)];
			uniqueRoom = [... new Set(roomList)];

			var userOr = [],
				seatOr = [],
				roomOr = [];

			userOr.push({'office.officeID':officeID})
			len = uniqueUser.length;
			for(var i = 0; i < len; i++){
				userOr.push({userID:uniqueUser[i]});
			}

			len = uniqueSeat.length;
			seatOr.push({seatID:"####"}) // prevents an empty list
			for(var i = 0; i < len; i++){
				seatOr.push({seatID:uniqueSeat[i]});
			}

			len = uniqueRoom.length;
			roomOr.push({roomID:"####"}) // prevents an empty list
			for(var i = 0; i < len; i++){
				roomOr.push({roomID:uniqueRoom[i]});
			}

			return Promise.all([
				userCollection.find({$or:userOr},{fields:{_id:0,first:1,last:1,'profileImages.smallProfile':1,
					employee:1,office:1,userID:1}}),
				seatCollection.find({$or:seatOr},{fields:{_id:0,seatID:1,seatName:1}}),
				roomCollection.find({$or:roomOr},{fields:{_id:0,roomID:1,roomName:1}})
			])
		})
		.then((results)=>{
			users = results[0];
			seats = results[1];
			rooms = results[2];

			len = seats.length;
			for(var i = 0; i < len; i++){
				seatObj[seats[i].seatID] = seats[i].seatName;
			}

			len = rooms.length;
			for(var i = 0; i < len; i++){
				roomObj[rooms[i].roomID] = rooms[i].roomName;
			}

			len = users.length;
			for(var i = 0; i < len; i++){
				user = users[i];
				if(user.employee){
					title = user.employee.title || "";
					employeeID = user.employee.employeeID || "";
					department = user.employee.department || null;
				}
				userObj[user.userID] = {
					imagePath: user.profileImages.smallProfile,
					name: user.first + ' ' + user.last,
					employeeID,
					title,
					department: department.deptName,
					office: user.office ? user.office.officeID == officeID : false,
					seatAssign: {},
					seatRes: {},
					roomRes: {},
				}
			}

			len = seatAssign.length;
			for(var i = 0; i < len; i++){
				assignment = seatAssign[i];
				userObj[assignment.userID].seatAssign[assignment.seatID] = seatObj[assignment.seatID];
			}

			len = seatRes.length;
			for(var i = 0; i < len; i++){
				reservation = seatRes[i];
				userObj[reservation.userID].seatRes[reservation.seatID] = seatObj[reservation.seatID];
			}

			len = roomRes.length;
			for(var i = 0; i < len; i++){
				reservation = roomRes[i];
				userObj[reservation.userID].roomRes[reservation.roomID] = roomObj[reservation.roomID];			
			}

			for(var i in userObj){
				resultArray.push(userObj[i]);
			}

			res.status(200).send({data:resultArray});
		})
		.catch((err)=>{
			console.log(err)
			if(err == "No Maps"){
				res.status(200).send({data:[]});
			} else {
				res.status(300).send({data:[]});			
			}
		})

	} else{
		res.status(498).send({});
	}
})

// This route populates the table of current zones in the offices menu area
router.get('/visitorList',authenticate,function(req,res){
	if(req.user){
		console.log('Get Office Visitor List Report')
		var companyNo = req.companyNo;
		var officeID = req.query.officeID;
		var start = 1*req.query.start;
		var end = 1*req.query.end;
		
		var visitorLogCollection = req.db.get(companyNo + '-visitor-log');
		var userCollection = req.db.get(companyNo + '-users');
		var mapCollection = req.db.get(companyNo + '-maps');

		var mapObj = {};
		var kioskObj = {};
		var log, maps, kiosks, entry, len;

		Promise.all([
			visitorLogCollection.find({officeID,date:{$gte:start,$lte:end}},{fields:{_id:0,visitorCode:0,officeID:0}}),
			mapCollection.find({officeID},{fields:{_id:0,id:1,name:1}}),
			userCollection.find({officeID},{fields:{_id:0,kioskName:1,kioskID:1}})
		])
		.then((results)=>{
			log = results[0];
			maps = results[1];
			kiosks = results[2];

			len = maps.length;
			for(var i = 0; i < len; i++){mapObj[maps[i].id] = maps[i].name;}

			len = kiosks.length;
			for(var i = 0; i < len; i++){kioskObj[kiosks[i].kioskID] = kiosks[i].kioskName;}

			len = log.length;
			for(var i = 0; i < len; i++){
				entry = log[i];
				entry.kiosk = kioskObj[entry.kioskID];
				entry.map = mapObj[entry.mapID];
				delete entry.kioskID;
				delete entry.mapID;
			}

			res.status(200).send({data:log});
		})
		.catch((err)=>{
			console.log(err)
			res.status(300).send({data:[]});
		})

	} else{
		res.status(498).send({});
	}
})

module.exports = router;