var router = require('express').Router();
var authenticate = require('../../.././middleware/authenticate').authenticate;
var utils = require('../../.././utils/utils');
var moment = require('moment');

// This route populates the table of current maps in the offices menu area
router.get('/summaryData',authenticate,function(req,res){
	if(req.user){
		console.log('Get Office Summary Data')
		var companyNo = req.companyNo;
		
		var officeCollection = req.db.get(companyNo + '-offices');
		var mapCollection = req.db.get(companyNo + '-maps');
		var seatCollection = req.db.get(companyNo + '-seats');
		var roomCollection = req.db.get(companyNo + '-rooms');
		var deptCollection = req.db.get(companyNo + '-departments');
		var userCollection = req.db.get(companyNo + '-users');

		var office, offices, officeID;
		var map, maps, mapID;
		var user, users;
		var seat, seats;
		var room, rooms;
		var departments;
		var len;
		var officeObj = {};
		var deptObj = {};
		var mapObj = {};
		var orList = [];
		var orList2 = [];
		var mapOrList = [];
		var mapOrList2 = [];

		Promise.all([
			officeCollection.find({status:'active'},{fields:{_id:0,officeID:1,name:1}}),
			deptCollection.find({active:true},{fields:{_id:0,deptID:1,deptName:1}})
		])
		.then((results)=>{
			offices = results[0];
			departments = results[1];

			len = departments.length;
			for(var i = 0; i < len; i++){ deptObj[departments[i].deptID] = departments[i].deptName }

			len = offices.length;
			for(var i = 0; i < len; i++){
				office = offices[i];
				officeID = office.officeID;
				orList.push({officeID,live:true});
				orList2.push({"office.officeID":officeID,kioskID:{$exists:false}})
				officeObj[officeID] = {
					name: office.name,
					departments: {}
				};
			}

			if(orList.length == 0){	throw "no offices";	}

			return Promise.all([
				mapCollection.find({$or:orList},{fields:{_id:0,id:1,officeID:1}}),
				userCollection.aggregate([
						{$match:{$or:orList2}},
						{$group:{_id:{officeID:"$office.officeID",deptID:"$employee.department.deptID"},
							officeID:{$first:"$office.officeID"},deptID:{$first:"$employee.department.deptID"},
							count : { $sum : 1 }}},
						{$group:{_id:"$officeID",departments:{$push:{deptID:"$deptID",userCount:"$count"}}}}
					])
			])
		})
		.then((results)=>{
			maps = results[0];
			users = results[1];

			len = maps.length;
			if(len == 0){ throw "no maps"; }
			for(var i = 0; i < len; i++){ 
				map = maps[i];
				mapObj[map.id] = map.officeID;
				mapOrList.push({mapID:map.id,status:"active"}); // For seat search
				mapOrList2.push({mapID:map.id,status:"active",reservable:true}); // For room search
			}

			len = users.length;
			for(var i = 0; i < len; i++){
				office = users[i]; // users are aggregated by office
				officeID = users[i]._id;
				for(var j = 0; j < office.departments.length; j++){
					department = office.departments[j];
					deptID = department.deptID;
					officeObj[officeID].departments[deptID] = {
						occupants: department.userCount
					}
				}
			}

			return Promise.all([
				seatCollection.aggregate([
						{$match:{$or:mapOrList}},
						{$group:{
							_id:{mapID:"$mapID",deptID:"$deptID"},
							mapID:{$first:"$mapID"},
							deptID:{$first:"$deptID"},
							seats:{$push:{reservable:"$reservable",status:"$assignmentStatus"}}
						}}
					]),
				roomCollection.aggregate([
						{$match:{$or:mapOrList2}},
						{$group:{
							_id:{mapID:"$mapID",deptID:"$deptID"},
							mapID:{$first:"$mapID"},
							deptID:{$first:"$deptID"},
							count:{$sum: 1 }
						}},
						{$group:{_id:"$mapID",departments:{$push:{deptID:"$deptID",roomCount:"$count"}}}}
					]),
			])			
		})
		.then((results)=>{
			seats = results[0];
			rooms = results[1];

			len = rooms.length;
			for(var i = 0; i < len; i++){
				map = rooms[i]; // rooms are aggregated by map
				mapID = map._id;
				officeID = mapObj[mapID]; // looks up officeID by mapID
				departments = map.departments;
				for(var j = 0; j < departments.length; j++){
					deptID = departments[j].deptID;
					office = officeObj[officeID];
					if(office.departments[deptID]){
						office.departments[deptID].resRooms = departments[j].roomCount;
					} else {
						office.departments[deptID] = {resRooms:departments[j].roomCount}
					}
				}
			}

			var assignable, assigned, resSeats, len2;
			len = seats.length;
			for(var i = 0; i < len; i++){
				map = seats[i]; // rooms are aggregated by map
				mapID = map.mapID;
				officeID = mapObj[mapID]; // looks up officeID by mapID
				office = officeObj[officeID];
				deptID = map.deptID;
				assignable = 0;
				assigned = 0;
				resSeats = 0;
				len2 = map.seats.length;
				for(var j = 0; j < len2; j++){
					seat = map.seats[j];
					if(seat.reservable){
						resSeats += 1;
					} else {
						assignable += 1;
						assigned += seat.status == "Assigned" ? 1 : 0;
					}
				}
				if(office.departments[deptID]){
					office.departments[deptID].resSeats = resSeats;
					office.departments[deptID].assignable = assignable;
					office.departments[deptID].assigned = assigned;
				} else {
					office.departments[deptID] = {
						resSeats,
						assignable,
						assigned,
					}
				}
			}

			var resultArray = [];
			var officeName, deptName, occupants;
			for(var i in officeObj){
				office = officeObj[i];
				officeName = office.name;
				departments = office.departments;
				for(var j in departments){
					deptName = deptObj[j];
					department = departments[j]
					resultArray.push({
						office:officeName,
						deptName,
						occupants:department.occupants || 0,
						resRoom: department.resRooms || 0,
						resSeat: department.resSeats || 0,
						assignable: department.assignable || 0,
						assigned: department.assigned || 0
					})
				}
			}


		res.status(200).send(resultArray);


		})
		.catch((err)=>{
			console.log(err);
			if(err == "no offices" || err == "no maps"){

			} else {

			}
		})

	} else{
		res.status(498).send({});
	}
})

// This route populates the table of current occupants in the offices menu area
router.get('/occupantList',authenticate,function(req,res){
	if(req.user){
		console.log('Get Office Occupant List Report')
		var companyNo = req.companyNo;
		var officeID = req.query.officeID;
		
		var mapCollection = req.db.get(companyNo + '-maps');
		var deptCollection = req.db.get(companyNo + '-departments');
		var seatAssignCollection = req.db.get(companyNo + '-seat-assignments');
		var seatResCollection = req.db.get(companyNo + '-seat-reservations');
		var roomResCollection = req.db.get(companyNo + '-room-reservations');
		var userCollection = req.db.get(companyNo + '-users');
		var seatCollection = req.db.get(companyNo + '-seats');
		var roomCollection = req.db.get(companyNo + '-rooms');

		var start = moment().startOf('day').valueOf();
		var end = moment().endOf('day').valueOf();

		var orList1 = []; // mapID only
		var orList2 = []; // mapID with date parameters
		var mapObj = {};
		var len, map, mapID, departments, department, deptID, title, employeeID;
		var resultArray = [];
		var deptList = [];
		var deptObj = {};
		var userObj = {};
		var seatObj = {};
		var roomObj = {};
		var promiseList = [];
		var seatAssign, seatRes, roomRes;
		var user, users, userID;
		var seat, seats, seatID;
		var room, rooms, roomID;
		var userList = [];
		var seatList = [];
		var roomList = [];
		var uniqueUser = [];
		var uniqueSeat = [];
		var uniqueRoom = [];
		var assignment, reservation;

		Promise.all([
			mapCollection.find({officeID,live:true},{fields:{_id:0,name:1,id:1,floorNumber:1,suiteNumber:1}}),
			deptCollection.find({},{fields:{_id:0}})
		])
		.then((results)=>{
			maps = results[0];
			departments = results[1];

			len = maps.length;
			for(var i = 0; i < len; i++){
				orList1.push({mapID:maps[i].id});
				orList2.push({ start:{$lte:end}, end:{$gte:start}, mapID:maps[i].id}); // Finds reservations for today
				mapObj[maps[i].id] = maps[i];
			}

			if(!orList1.length){ throw "No Maps" }

			len = departments.length;
			for(var i = 0; i < len; i++){
				deptObj[departments[i].deptID] = departments[i];
			}			

			return Promise.all([
				seatAssignCollection.find({$or:orList1},{fields:{_id:0,userID:1,seatID:1}}),
				seatResCollection.find({$or:orList2},{fields:{_id:0,userID:1,seatID:1}}),
				roomResCollection.find({$or:orList2},{fields:{_id:0,userID:1,roomID:1}}),
			])
		})
		.then((results)=>{
			seatAssign = results[0];
			seatRes = results[1];
			roomRes = results[2];

			len = seatAssign.length;
			for(var i = 0; i < len; i++){
				userList.push(seatAssign[i].userID);
				seatList.push(seatAssign[i].seatID);
			}

			len = seatRes.length;
			for(var i = 0; i < len; i++){
				userList.push(seatRes[i].userID);
				seatList.push(seatRes[i].seatID);				
			}

			len = roomRes.length;
			for(var i = 0; i < len; i++){
				userList.push(roomRes[i].userID);
				roomList.push(roomRes[i].roomID);				
			}

			uniqueUser = [... new Set(userList)];
			uniqueSeat = [... new Set(seatList)];
			uniqueRoom = [... new Set(roomList)];

			var userOr = [],
				seatOr = [],
				roomOr = [];

			userOr.push({'office.officeID':officeID})
			len = uniqueUser.length;
			for(var i = 0; i < len; i++){
				userOr.push({userID:uniqueUser[i]});
			}

			len = uniqueSeat.length;
			seatOr.push({seatID:"####"}) // prevents an empty list
			for(var i = 0; i < len; i++){
				seatOr.push({seatID:uniqueSeat[i]});
			}

			len = uniqueRoom.length;
			roomOr.push({roomID:"####"}) // prevents an empty list
			for(var i = 0; i < len; i++){
				roomOr.push({roomID:uniqueRoom[i]});
			}

			return Promise.all([
				userCollection.find({$or:userOr},{fields:{_id:0,first:1,last:1,'profileImages.mediumProfile':1,
					email:1,cell:1,employee:1,office:1,userID:1}}),
				seatCollection.find({$or:seatOr},{fields:{_id:0,seatID:1,seatName:1,mapID:1}}),
				roomCollection.find({$or:roomOr},{fields:{_id:0,roomID:1,roomName:1,mapID:1}})
			])
		})
		.then((results)=>{
			users = results[0];
			seats = results[1];
			rooms = results[2];

			len = seats.length;
			for(var i = 0; i < len; i++){
				seat = seats[i];
				mapID = seat.mapID;
				map = mapObj[mapID];
				seat.floor = map.floorNumber;
				seat.suite = map.suiteNumber;
				seatObj[seat.seatID] = seat;
			}

			len = rooms.length;
			for(var i = 0; i < len; i++){
				room = rooms[i];
				mapID = room.mapID;
				map = mapObj[mapID];
				room.floor = map.floorNumber;
				room.suite = map.suiteNumber;
				roomObj[room.roomID] = room;
			}

			len = users.length;
			for(var i = 0; i < len; i++){
				user = users[i];
				if(user.employee){
					title = user.employee.title || "";
					employeeID = user.employee.employeeID || "";
					department = user.employee.department || null;
				}
				userObj[user.userID] = {
					userID: user.userID,
					imagePath: user.profileImages.mediumProfile,
					name: user.first + ' ' + user.last,
					email: user.email,
					cell: user.cell,
					employeeID,
					title,
					department: department.name,
					office: user.office ? user.office.officeID == officeID : false,
					seatAssign: {},
					seatRes: {},
					roomRes: {},
				}
			}

			len = seatAssign.length;
			for(var i = 0; i < len; i++){
				assignment = seatAssign[i];
				userObj[assignment.userID].seatAssign[assignment.seatID] = seatObj[assignment.seatID];
			}

			len = seatRes.length;
			for(var i = 0; i < len; i++){
				reservation = seatRes[i];
				userObj[reservation.userID].seatRes[reservation.seatID] = seatObj[reservation.seatID];
			}

			len = roomRes.length;
			for(var i = 0; i < len; i++){
				reservation = roomRes[i];
				userObj[reservation.userID].roomRes[reservation.roomID] = roomObj[reservation.roomID];			
			}

			for(var i in userObj){
				resultArray.push(userObj[i]);
			}

			res.status(200).send({data:resultArray});
		})
		.catch((err)=>{
			console.log(err)
			if(err == "No Maps"){
				res.status(200).send({data:[]});
			} else {
				res.status(300).send({data:[]});			
			}
		})

	} else{
		res.status(498).send({});
	}
})

module.exports = router;