var router = require('express').Router();
var authenticate = require('../../.././middleware/authenticate').authenticate;
var utils = require('../../.././utils/utils');

router.get('/getUserList',authenticate,function(req,res){
	if(req.user){
		console.log('get user list');
		var companyNo = req.companyNo;
		var officeID = req.query.officeID;
		console.log(officeID);
		var userCollection = req.db.get(companyNo + '-users');
		var seatsCollection = req.db.get(companyNo + '-seats');

		var user,users,userID,seat,seatID,assignment,assignments;
		var seatObj = {};

		Promise.all([
			userCollection.aggregate([
				{$match: {userID:{ $exists: true },'office.officeID':officeID}},
				{$project: {userID:1,employee:1,first:1,last:1,profileImages:1,office:1}},
				{$lookup: {
					from: companyNo + '-seat-assignments',
					localField: 'userID',
					foreignField: 'userID',
					as: 'assignments'
				}}				
			]),
			seatsCollection.find({},{fields:{seatID:1,seatName:1,mapName:1}})
		])
		.then((docs)=>{
			users = docs[0];
			seats = docs[1];

			for(var i in seats){
				seat = seats[i];
				seatID = seat.seatID;
				seatObj[seatID] = seat;
			}

			for(var i in users){
				user = users[i];
				userID = user.userID;
				user.seats = [];
				assignments = user.assignments || [];
				for(var j in assignments){
					assignment = assignments[j];
					seatID = assignment.seatID;
					seat = seatObj[seatID];
					user.seats.push({
						seatID: seat.seatID,
						seatName: seat.seatName,
						mapName: seat.mapName
					})
				}
				user.profile = user.profileImages.smallProfile;
				user.id = user.employee.employeeID;
				user.title = user.employee.title;
				user.department = user.employee.department;
				delete user.assignments;
				delete user._id;
				delete user.profileImages;
				delete user.employee;
			}
			
			res.status(200).send({data:users});
		}).catch((err)=>{
			console.log(err);
			res.status(300).send({});
		})
	} else{
		res.status(498).send({});
	}
})


// This function is used when loading a map.  Specifically, it is used to populate the existing seat assignments.
// The function returns two objects, seats and users, each indexed by seatID/userID respectively.  The seats object
// contains all of the assigned seats (not all of the seats period) for a specified map and the respective userID for
// the assignment.  The users object contains the basic user/employee data for all of the users who are assigned a seat
// in the map.
router.get('/seat-assignments/:mapID',authenticate,function(req,res){
	if(req.user || req.kiosk){
		var mapID = req.params.mapID;
		var companyNo = req.companyNo;
		var seatAssignCollection = req.db.get(companyNo + '-seat-assignments');
		var userCollection = req.db.get(companyNo + '-users');

		var assignment, userID, seatID;
		var seatsObj = {}; // seatObj is an object indexed by seatID which contains the seatID and userID for an assignment
		var userObj = {}; // userObj is an object indexed by userID which contains basic user/employee data
		var assignedUserObj = {};
		var complete = false;
		
		seatAssignCollection.find({mapID},{mapID:0,_id:0})
		.then((seatAssignments)=>{
			for(var i in seatAssignments){
				assignment = seatAssignments[i];
				userID = assignment.userID;
				seatID = assignment.seatID;
				seatsObj[seatID] = {
					userID,
					seatID,
					updateType: 'none' // This is used as a starting point for searching for seat changes on a save
				}
				assignedUserObj[userID] = null; // only really need the keys - easy way to create a unique list;
			}
			
			userSearchArray = Object.keys(assignedUserObj);
			for(var i in userSearchArray){
				userSearchArray[i] = {
					userID: userSearchArray[i]
				}
			}

			if(userSearchArray.length == 0){
				res.status(200).send({});
				throw "Completed";
			}

			// Searches for the users identified as assigned to seats within the specified map
			return userCollection.find(
					{$or:userSearchArray},
					{fields:{_id:0,userID:1,email:1,first:1,last:1,employee:1,profileImages:1}}
				);
		})
		.then((users)=>{
			for(var i in users){
				userObj[users[i].userID] = users[i];
			}
			res.status(200).send({seatAssignments:seatsObj,users:userObj});
		})
		.catch((err)=>{
			if(err == "Completed"){
				return;
			}
			console.log(err);
			res.status(300).send({});
		})
	} else{
		res.status(498).send({});
	}
})

router.post('/seat-assignments/',authenticate,function(req,res){
	if(req.user){
		var users = req.body.users;
		var companyNo = req.companyNo;
		var userCollection = req.db.get(companyNo + '-users');
		var userSearchArray = [];
		var userID;
		var userObj = {};
		if(users){
			for(var i = 0;i < users.length; i++){
				userID = users[i];
				userSearchArray.push({userID});
			}
			userCollection.find({$or:userSearchArray},{fields:{userID:1,email:1,first:1,last:1,employee:1,profileImages:1}})
			.then((users)=>{
				for(var i in users){
					userID = users[i].userID
					userObj[userID] = users[i];
				}
				res.status(200).send({users:userObj});
			})
			.catch((err)=>{
				console.log(err);
			})		
		} else {
			res.status(200).send({users:{}});
		}



	} else{
		res.status(498).send({});
	}
})

module.exports = router;