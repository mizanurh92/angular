// The Modal Reports routes populate the drill-down style modal reports in the Maptician App.
// These generally accept a list of objectID's (various types) as a parameter and return the relevant report data
// for those objects

var router = require('express').Router();
var authenticate = require('../../.././middleware/authenticate').authenticate;
var utils = require('../../.././utils/utils');

router.get('/maps',authenticate,function(req,res){
	if(req.user){
		console.log('Get modal map list')
		var companyNo = req.companyNo;
		var mapCollection = req.db.get(companyNo + '-maps');
		var zonesCollection = req.db.get(companyNo + '-zones');
		var roomsCollection = req.db.get(companyNo + '-rooms');
		var seatsCollection = req.db.get(companyNo + '-seats');
		var assignmentCollection = req.db.get(companyNo + '-seat-assignments');
		var zoneObj = {};

		// The query object obtained as a parameter is turned into an find array for use in an 'or' search
		var queryArray = req.query['data'];
		var mapArray = [];
		var mapIDArray = [];
		for(var i = 0;i < queryArray.length;i++){
			mapArray.push({id:queryArray[i]});
			mapIDArray.push({mapID:queryArray[i]});
		}

		Promise.all([
				mapCollection.aggregate([{$match:{$or:mapArray}},{$sort:{date:-1}},{$group:{_id: "$id",mapName: {$first:"$name"}}}]),
				zonesCollection.find({$or:mapIDArray},{fields:{_id:0,zoneID:1,mapID:1}}),
				roomsCollection.find({$or:mapIDArray},{fields:{_id:0,roomID:1,mapID:1}}),
				seatsCollection.find({$or:mapIDArray},{fields:{_id:0,seatID:1,mapID:1,reservable:1}}),
				assignmentCollection.find({$or:mapIDArray},{fields:{_id:0,seatID:1}})
			])
		.then((results)=>{
			var maps = results[0];
			var zones = results[1];
			var rooms = results[2];
			var seats = results[3];
			var assignments = results[4];

			var mapObj = {};
			var map, mapID;
			for(var i in maps){
				map = maps[i];
				mapID = map._id;
				mapObj[mapID] = {
					mapName:map.mapName,
					zones:[],
					rooms:[],
					seats:[]
				}
			}

			for(var i in zones){
				mapID = zones[i].mapID;
				mapObj[mapID].zones.push(zones[i].zoneID);
			}

			for(var i in rooms){
				mapID = rooms[i].mapID;
				mapObj[mapID].rooms.push(rooms[i].roomID);
			}

			var seatObj = {};
			var seat,seatID;
			for(var i in seats){
				seat = seats[i];
				seatID = seat.seatID;
				seatObj[seatID] = {
					mapID: seat.mapID,
					reservable: seat.reservable,
					assignmentStatus: "Unassigned"
				}
			}

			for(var i in assignments){
				seatID = assignments[i].seatID;
				if(seatObj[seatID]){
					seatObj[seatID].assignmentStatus = "Assigned";
				}
			}

			for(var i in seatObj){
				seat = seatObj[i];
				mapID = seat.mapID;
				delete seat.mapID;
				mapObj[mapID].seats.push(seat);
			}

			mapArray = [];
			for(var i in mapObj){
				mapArray.push(mapObj[i]);
			}


			res.status(200).send({data:mapArray});
		})
		.catch((err)=>{
			console.log(err)
			res.status(300).send({});
		})
		


		// // The zone array is used to limit the search to only those zones which are required for the report
		// zonesCollection.find({$or:zoneArray},{fields:{zoneID:1,zoneName:1,area:1,seats:1}})
		// .then((zones)=>{
		// 	var currentZone, zoneID;
		// 	var seatsArray = [];
		// 	for(var i = 0;i < zones.length;i++){
		// 		currentZone = zones[i];
		// 		zoneID = currentZone.zoneID;
		// 		zoneObj[zoneID] = {
		// 			zoneID,
		// 			zoneName:currentZone.zoneName,
		// 			area:currentZone.area,
		// 			seats:currentZone.seats
		// 		}
		// 		for(var j in currentZone.seats){
		// 			currentZone.seats[j].assignmentStatus = "Unassigned"; // Will be updated with assignment data after find
		// 			seatsArray.push({seatID:j,companyID})
		// 		}
		// 	}

		// 	// Checks to see if there are any seats in the zone.  If so, the seat assignment data is found in the db, otherwise
		// 	// the response is sent with the current data and the route is ended
		// 	if(seatsArray.length){
		// 		return assignmentCollection.find({$or:seatsArray},{fields:{mapID:0,companyID:0}});
		// 	} else {
		// 		var zonesArray = [];
		// 		for(var i in zoneObj){
		// 			zonesArray.push(zoneObj[i]);
		// 		}
		// 		res.status(200).send({data:zonesArray}); // Returns the results to the client
		// 		return;				
		// 	}
		// })
		// .then((assignments)=>{
		// 	if(assignments===undefined){return;} // This is needed for if the find operation was skipped due to no seats
		// 	var seatObj = {};
		// 	var currentAssign,seatID;
		// 	for(var i = 0;i < assignments.length;i++){
		// 		currentAssign = assignments[i];
		// 		seatID = currentAssign.seatID;
		// 		seatObj[seatID] = {}; // Doesn't actually need any data in the object, just its existence is enough
		// 	}
		// 	var currentZone,currentSeat;
		// 	for(var i in zoneObj){
		// 		currentZone = zoneObj[i];
		// 		for(var j in currentZone.seats){
		// 			currentSeat = currentZone.seats[j];
		// 			seatID = j;
		// 			if(seatObj[j]){
		// 				currentSeat.assignmentStatus = "Assigned";
		// 			}
		// 		}
		// 	}
		// 	var zonesArray = [];
		// 	for(var i in zoneObj){
		// 		zonesArray.push(zoneObj[i]);
		// 	}
		// 	res.status(200).send({data:zonesArray});
		// })
		// .catch((err)=>{
		// 	console.log(err);
		// 	res.status(300).send({});			
		// })
	} else{
		res.status(300).send({});
	}
})

router.get('/seats',authenticate,function(req,res){
	if(req.user){
		console.log('Get modal seat list')
		var companyNo = req.companyNo;
		var companyID = req.user.companyID;
		var userCollection = req.db.get(companyNo + '-users');
		var assignmentCollection = req.db.get(companyNo + '-seat-assignments');
		var seatsCollection = req.db.get(companyNo + '-seats');

		var seats,assignments;
		var seatObj = {};
		var currentSeat,seatID;

		// The query object obtained as a parameter is turned into an find array for use in an 'or' search
		var queryArray = req.query['data'];

		if(queryArray === undefined || !queryArray.length){
			res.status(200).send({data:[]});
			return;
		}

		var seatArray = [];
		for(var i = 0;i < queryArray.length;i++){
			seatArray.push({seatID:queryArray[i]});
		}

		// The seat array is used to limit the search for seats and seat assignments to only the required seats
		// The seats and assignments collections can be searched simultaneously, but we don't know the applicable employee
		// list yet, and so that search must be done later in the process.
		Promise.all([
				seatsCollection.find({$or:seatArray},{fields:{seatID:1,seatName:1,mapName:1,mapID:1,zones:1,rooms:1,reservable:1}}),
				assignmentCollection.find({$or:seatArray},{fields:{mapID:0}})
			])
		.then((results)=>{
			seats = results[0];
			assignments = results[1];

			// Creates a seatObj which is indexed by seatID and contains the seat data needed for the report
			for(var i = 0;i<seats.length;i++){
				currentSeat = seats[i];
				seatID = currentSeat.seatID;
				seatObj[seatID] = {
					seatID,
					seatName: currentSeat.seatName,
					mapID: currentSeat.mapID,
					mapName: currentSeat.mapName,
					reservable: currentSeat.reservable,
					assignmentStatus: "Unassigned"
				}
				seatObj[seatID].rooms = Object.keys(currentSeat.rooms);
				seatObj[seatID].zones = Object.keys(currentSeat.zones);
			}

			// An array of users/employeeID's is obtained by looping through the seat assignments
			var userArray = [];
			for(var i = 0;i < assignments.length;i++){
				userArray.push({userID:assignments[i].userID});
			}

			// If there are no seat assignments, then the user search can be skipped and the seatObj can be formatted
			// and sent back to the client
			if(userArray.length == 0){
				// Converts the seatObj into an array for use in the report
				var seatArray = [];
				for(var i in seatObj){
					seatArray.push(seatObj[i]);
				}
				res.status(200).send({data:seatArray}); // Returns the results to the client
				return; // skips the user find operation
			}

			// Using the list of assigned employees, an 'or' find is used to get the latest data for these users
			return userCollection.find({$or:userArray},{fields:{userID:1,first:1,last:1,profileImages:1}});
		})
		.then((users)=>{
			if(users===undefined){return;} // This is needed for if the find operation was skipped due to no assigned seats

			// Creates a userObj object which is indexed by employeeID and contains the employee information needed for the report
			var userObj = {};
			var userID,currentUser;
			for(var i = 0;i < users.length;i++){
				currentUser = users[i];
				userID = currentUser.userID;
				userObj[userID] = {
					userID,
					first:currentUser.first,
					last:currentUser.last,
					profileImage:currentUser.profileImages.smallProfile
				}
			}

			// Loops through the seat assignments and adds the assignment/user data to each seat in seatObj. Updates the assigned status as well.
			var currentAssign;
			for(var i = 0;i < assignments.length;i++){
				currentAssign = assignments[i];
				seatID = currentAssign.seatID;
				userID = currentAssign.userID;
				seatObj[seatID].assignmentStatus = "Assigned";
				seatObj[seatID].user = userObj[userID];
			}

			// Converts the seatObj into an array for use in the report
			var seatArray = [];
			for(var i in seatObj){
				seatArray.push(seatObj[i]);
			}

			// Assuming everything completed successfully, the seat array is returned with only the needed information
			res.status(200).send({data:seatArray});
		})
		.catch((err)=>{
			console.log(err);
			res.status(300).send({});
		})
	} else{
		res.status(300).send({});
	}
})

router.get('/rooms',authenticate,function(req,res){
	if(req.user){
		console.log('Get modal room list')
		var companyID = req.user.companyID;
		var companyNo = req.companyNo;
		var roomsCollection = req.db.get(companyNo + '-rooms');
		var assignmentCollection = req.db.get(companyNo + '-seat-assignments');
		var assignments;
		var roomObj = {};

		// The query object obtained as a parameter is turned into an find array for use in an 'or' search
		var queryArray = req.query['data'];

		if(queryArray === undefined || !queryArray.length){
			res.status(200).send({data:[]});
			return;
		}

		var roomArray = [];
		for(var i = 0;i < queryArray.length;i++){
			roomArray.push({roomID:queryArray[i]});
		}

		// The room array is used to limit the search to only those rooms which are required for the report
		roomsCollection.find({$or:roomArray},{fields:{roomID:1,roomName:1,area:1,seats:1}})
		.then((rooms)=>{
			var currentRoom, roomID;
			var seatsArray = [];
			for(var i = 0;i < rooms.length;i++){
				currentRoom = rooms[i];
				roomID = currentRoom.roomID;
				roomObj[roomID] = {
					roomID,
					roomName:currentRoom.roomName,
					area:currentRoom.area,
					seats:currentRoom.seats
				}
				for(var j in currentRoom.seats){
					currentRoom.seats[j].assignmentStatus = "Unassigned"; // Will be updated with assignment data after find
					seatsArray.push({seatID:j})
				}
			}
			if(seatsArray.length){
				return assignmentCollection.find({$or:seatsArray},{fields:{mapID:0}});
			} else {
				var roomsArray = [];
				for(var i in roomObj){
					roomsArray.push(roomObj[i]);
				}
				res.status(200).send({data:roomsArray}); // Returns the results to the client
				return; // skips the user find operation				
			}
		})
		.then((assignments)=>{
			if(assignments===undefined){return;} // This is needed for if the find operation was skipped due to no seats
			var seatObj = {};
			var currentAssign,seatID;
			for(var i = 0;i < assignments.length;i++){
				currentAssign = assignments[i];
				seatID = currentAssign.seatID;
				seatObj[seatID] = {}; // Doesn't actually need any data in the object, just its existence is enough
			}
			var currentRoom,currentSeat;
			for(var i in roomObj){
				currentRoom = roomObj[i];
				for(var j in currentRoom.seats){
					currentSeat = currentRoom.seats[j];
					seatID = j;
					if(seatObj[j]){
						currentSeat.assignmentStatus = "Assigned";
					}
				}
			}
			var roomsArray = [];
			for(var i in roomObj){
				roomsArray.push(roomObj[i]);
			}
			res.status(200).send({data:roomsArray}); // Returns the results to the client
		})
		.catch((err)=>{
			console.log(err);
			res.status(300).send({});			
		})
	} else{
		res.status(300).send({});
	}
})

router.get('/zones',authenticate,function(req,res){
	if(req.user){
		console.log('Get modal zone list')
		var companyID = req.user.companyID;
		var companyNo = req.companyNo;
		var zonesCollection = req.db.get(companyNo + '-zones');
		var assignmentCollection = req.db.get(companyNo + '-seat-assignments');
		var assignments;
		var zoneObj = {};

		// The query object obtained as a parameter is turned into an find array for use in an 'or' search
		var queryArray = req.query['data'];

		if(queryArray === undefined || !queryArray.length){
			res.status(200).send({data:[]});
			return;
		}

		var zoneArray = [];
		for(var i = 0;i < queryArray.length;i++){
			zoneArray.push({zoneID:queryArray[i]});
		}

		// The zone array is used to limit the search to only those zones which are required for the report
		zonesCollection.find({$or:zoneArray},{fields:{zoneID:1,zoneName:1,area:1,seats:1}})
		.then((zones)=>{
			var currentZone, zoneID;
			var seatsArray = [];
			for(var i = 0;i < zones.length;i++){
				currentZone = zones[i];
				zoneID = currentZone.zoneID;
				zoneObj[zoneID] = {
					zoneID,
					zoneName:currentZone.zoneName,
					area:currentZone.area,
					seats:currentZone.seats
				}
				for(var j in currentZone.seats){
					currentZone.seats[j].assignmentStatus = "Unassigned"; // Will be updated with assignment data after find
					seatsArray.push({seatID:j})
				}
			}

			// Checks to see if there are any seats in the zone.  If so, the seat assignment data is found in the db, otherwise
			// the response is sent with the current data and the route is ended
			if(seatsArray.length){
				return assignmentCollection.find({$or:seatsArray},{fields:{mapID:0}});
			} else {
				var zonesArray = [];
				for(var i in zoneObj){
					zonesArray.push(zoneObj[i]);
				}
				res.status(200).send({data:zonesArray}); // Returns the results to the client
				return;				
			}
		})
		.then((assignments)=>{
			if(assignments===undefined){return;} // This is needed for if the find operation was skipped due to no seats
			var seatObj = {};
			var currentAssign,seatID;
			for(var i = 0;i < assignments.length;i++){
				currentAssign = assignments[i];
				seatID = currentAssign.seatID;
				seatObj[seatID] = {}; // Doesn't actually need any data in the object, just its existence is enough
			}
			var currentZone,currentSeat;
			for(var i in zoneObj){
				currentZone = zoneObj[i];
				for(var j in currentZone.seats){
					currentSeat = currentZone.seats[j];
					seatID = j;
					if(seatObj[j]){
						currentSeat.assignmentStatus = "Assigned";
					}
				}
			}
			var zonesArray = [];
			for(var i in zoneObj){
				zonesArray.push(zoneObj[i]);
			}
			res.status(200).send({data:zonesArray});
		})
		.catch((err)=>{
			console.log(err);
			res.status(300).send({});			
		})
	} else{
		res.status(300).send({});
	}
})

router.get('/users',authenticate,function(req,res){
	if(req.user){
		console.log('Get modal user list')
		var companyID = req.user.companyID;
		var companyNo = req.companyNo;
		var zonesCollection = req.db.get(companyNo + '-zones');
		var assignmentCollection = req.db.get(companyNo + '-seat-assignments');
		var assignments;
		var zoneObj = {};

		// The query object obtained as a parameter is turned into an find array for use in an 'or' search
		var queryArray = req.query['data'];
		var zoneArray = [];
		for(var i = 0;i < queryArray.length;i++){
			zoneArray.push({zoneID:queryArray[i]});
		}

		// The zone array is used to limit the search to only those zones which are required for the report
		zonesCollection.find({$or:zoneArray},{fields:{zoneID:1,zoneName:1,area:1,seats:1}})
		.then((zones)=>{
			var currentZone, zoneID;
			var seatsArray = [];
			for(var i = 0;i < zones.length;i++){
				currentZone = zones[i];
				zoneID = currentZone.zoneID;
				zoneObj[zoneID] = {
					zoneID,
					zoneName:currentZone.zoneName,
					area:currentZone.area,
					seats:currentZone.seats
				}
				for(var j in currentZone.seats){
					currentZone.seats[j].assignmentStatus = "Unassigned"; // Will be updated with assignment data after find
					seatsArray.push({seatID:j})
				}
			}

			// Checks to see if there are any seats in the zone.  If so, the seat assignment data is found in the db, otherwise
			// the response is sent with the current data and the route is ended
			if(seatsArray.length){
				return assignmentCollection.find({$or:seatsArray},{fields:{mapID:0}});
			} else {
				var zonesArray = [];
				for(var i in zoneObj){
					zonesArray.push(zoneObj[i]);
				}
				res.status(200).send({data:zonesArray}); // Returns the results to the client
				return;				
			}
		})
		.then((assignments)=>{
			if(assignments===undefined){return;} // This is needed for if the find operation was skipped due to no seats
			var seatObj = {};
			var currentAssign,seatID;
			for(var i = 0;i < assignments.length;i++){
				currentAssign = assignments[i];
				seatID = currentAssign.seatID;
				seatObj[seatID] = {}; // Doesn't actually need any data in the object, just its existence is enough
			}
			var currentZone,currentSeat;
			for(var i in zoneObj){
				currentZone = zoneObj[i];
				for(var j in currentZone.seats){
					currentSeat = currentZone.seats[j];
					seatID = j;
					if(seatObj[j]){
						currentSeat.assignmentStatus = "Assigned";
					}
				}
			}
			var zonesArray = [];
			for(var i in zoneObj){
				zonesArray.push(zoneObj[i]);
			}
			res.status(200).send({data:zonesArray});
		})
		.catch((err)=>{
			console.log(err);
			res.status(300).send({});			
		})
	} else{
		res.status(300).send({});
	}
})

module.exports = router;