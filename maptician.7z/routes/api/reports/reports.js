var router = require('express').Router();
var authenticate = require('../../.././middleware/authenticate').authenticate;

router.use('/modalReports',require('./modalReports'));

module.exports = router;
