var router = require('express').Router();
var authenticate = require('../../.././middleware/authenticate').authenticate;
var utils = require('../../.././utils/utils');
var credential = require('credential');
var pw = credential();


// This route takes an old an a new password and validates the old one.
// If valid, then the user's password becomes the newly entered one.
router.post('/changePassword',authenticate,function(req,res){
	if(req.user){
		console.log('Change User Password')
		var companyNo = req.companyNo;
		var usersCollection = req.db.get(companyNo + '-users');
		var data = req.body;
		var oldPassword = data.oldPassword;
		var newPassword = data.newPassword;
		var userID = req.user.userID;
		console.log('userID:',userID);
		var user, passwordData;

		usersCollection.find({userID,userStatus:"active"},{fields:{_id:0,password:1}})
		.then((doc)=>{
			if(!doc.length){
				throw 'Unable to locate user credentials.';
			};
			user = doc[0];
			passwordData = JSON.stringify(user.password);
			console.log('Checking old password.')
			return pw.verify(passwordData,oldPassword);
		})
		.then((isValid)=>{
			console.log('Old password valid:',isValid)
			if(isValid){
				return pw.hash(newPassword)
			} else {
				throw "Incorrect password entered";
			}
		})
		.then((hash)=>{
			console.log(hash);
			return usersCollection.findOneAndUpdate({userID},{$set:{password:JSON.parse(hash)}});
		})
		.then((result)=>{
			console.log(result);
			res.status(200).send({success:true});
		})
		.catch((err)=>{
			console.log(err);
			res.status(300).send({success:false,err});
		})
	} else{
		res.status(498).send({});
	}
})


// This route closes all user sessions for the current user.  This is a
// security feature and will allow the user to remotely log off from any
// other device (mobile, web, etc.).  This is accomplished by changing the
// secret used to validate the JWT which is used in each request.
router.get('/closeSessions',authenticate,function(req,res){
	if(req.user){
		console.log('Close all user sessions')
		var companyNo = req.companyNo;
		var usersCollection = req.db.get(companyNo + '-users');
		var userID = req.user.userID;
		usersCollection.findOneAndUpdate({userID},{$set:{tokenhash:utils.uuid()}})
		.then((doc)=>{
			res.status(498).send();
		})
		.catch((err)=>{
			res.status(300).send();
		})
	} else{
		res.status(498).send({});
	}
})

module.exports = router;