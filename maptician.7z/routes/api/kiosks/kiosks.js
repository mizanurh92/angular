var router = require('express').Router();
var authenticate = require('../../.././middleware/authenticate').authenticate;
var utils = require('../../.././utils/utils');
var config = require('../../.././config/config');
var moment = require('moment');
var credential = require('credential');
var pw = credential();

// This route is used to populate a list of active kiosks for an office.  
router.get('/visitorKioskList',authenticate,function(req,res){
	if(req.user){
		console.log('Get Visitor Kiosk List')
		var companyNo = req.companyNo;
		var officeID = req.query.officeID;
		var userCollection = req.db.get(companyNo + '-users');
		var companyCollection = req.db.get('companies');
		console.log(officeID)
		Promise.all([
			userCollection.find({userType:"visitor kiosk",officeID,status:'active'},{fields:{password:0,tokenhash:0}}),
			companyCollection.find({companyNo},{fields:{companyName:1}})
		])
		.then((results)=>{
			console.log(results)
			var kiosks = results[0];
			var companyName = results[1][0].companyName;
			for(var i in kiosks){
				kiosks[i].companyName = companyName;
			}
			res.status(200).send({data:kiosks});
		})
		.catch((err)=>{
			console.log(err);
			res.status(300).send({});
		})
	} else{
		res.status(300).send({});
	}
})

router.get('/kioskData',authenticate,function(req,res){
	if(req.kiosk){
		res.send({map:req.kiosk.mapID,kiosk:req.kiosk.kioskID,location:req.kiosk.location});
	} else {
		console.log('No token, sending error to log out user.')
		res.status(498).send();
	}	
})

// This route allows setting a kiosk's username and password
router.post('/credentials',authenticate,function(req,res){
	if(req.user){
		console.log('Set Visitor Kiosk Username and Password')
		var companyNo = req.companyNo;
		var password = req.body.password;
		var userName = req.body.userName;
		var kioskID = req.body.id;
		var userCollection = req.db.get(companyNo + '-users');
		var error = false;

		userCollection.find({kioskID:{$not:{$eq:kioskID}},userType:"visitor kiosk",userName},{fields:{kioskID:1}})
		.then((results)=>{
			if(results[0]){
				res.status(300).send({errorMsg:"User Name already exists, please try another."});
				error = true;
				return('break');
			}
			// TODO Validate Password Strength
			return pw.hash(password);
		})
		.then((results)=>{
			if(error){return;};
			var kioskUser = {
				userName,
				password: JSON.parse(results)
			}
			return userCollection.findOneAndUpdate({kioskID},{$set:kioskUser});
		})
		.then((results)=>{
			if(error){return;}
			res.status(200).send();
		})
		.catch((err)=>{
			console.log(err);
			res.status(300).send({errorMsg:"Unable to update at this time, please try again later."});
		})
	} else{
		res.status(300).send({});
	}
})


// This route prepares a list of all users who are either directly assigned to a given office, or who have current
// seat reservations for that office.  The later matters because someone could be a visitor to the office (from a different office)
// and still reserve a seat.  We want this person to show up on the directory while that reservation is active.  The list
// includes all information about the person with respect to the office (populates a directory), including their title,
// department, and floor/suite/seat if applicable.
router.get('/userlist',authenticate,(req,res)=>{
	console.log('Getting User List for Front Desk Kiosk');
	if(req.kiosk){
		var companyNo = req.companyNo;
		var officeID = req.kiosk.officeID;
		var userCollection = req.db.get(companyNo + '-users');
		var seatCollection = req.db.get(companyNo + '-seats');
		var mapsCollection = req.db.get(companyNo + '-maps');
		var seatReservationsCollection = req.db.get(companyNo + '-seat-reservations');
		
		var len;
		var maps,map,mapID;
		var mapArray = [];
		var mapArray2 = [];
		var mapObj = {};
		var reservations, reservation;
		var	resUserArray = [];
		var resUserList = [];
		var users, user, userID;
		var userObj = {};
		var userList = [];
		var seats, seat;
		var seatList = [];
		var reservable = {};
		var now = moment().valueOf();

		mapsCollection.find({officeID,live:true},{fields:{_id:0,id:1,name:1,floorNumber:1,suiteNumber:1}})
		.then((docs)=>{
			maps = docs;
			
			// Creates an object (indexed by mapID) which contains basic (name, floor, suite) information about each map
			// associated with the specified officeID.
			// Also creates an array of mapID based selectors used below.
			len = maps.length;
			for(var i = 0; i < len; i++){
				map = maps[i];
				mapID = map.id;
				mapArray.push({id:mapID});
				mapArray2.push({mapID:mapID});
				mapObj[mapID] = map;
			}

			return Promise.all([
					seatReservationsCollection.find({$or:mapArray,start:{$lt:now},end:{$gt:now}},{fields:{_id:0,userID:1,seatID:1}}),
					seatCollection.find({$or:mapArray2},{fields:{_id:0,seatName:1,mapName:1,seatID:1,mapID:1,userID:1,reservable:1}})
				]);
		})
		.then((docs)=>{
			reservations = docs[0];
			seats = docs[1];
			console.log('seats',seats)

			// Splits the seats into two seperate lists/objects, one for assigned seats, and one for reservable ones
			// Unassigned seats are discarded since we only care about users here
			len = seats.length;
			for(var i = 0; i < len; i++){
				seat = seats[i];
				mapID = seat.mapID;
				map = mapObj[mapID];
				seat.floor = map.floorNumber;
				seat.suite = map.suiteNumber;
				seat.mapName = map.name;
				if(seat.userID){
					seatList.push(seat);
				}
				if(seat.reservable){
					reservable[seat.seatID] = seat;
				}
			}

			// Finds the users who have current seat reservations in one of the maps
			len = reservations.length;
			for(var i = 0; i < len; i++){
				reservation = reservations[i];
				resUserArray.push({userID:reservation.userID});
				resUserList.push(reservation);
			}

			// Finds the users who have an assigned seat in one of the maps
			len = seats.length;
			for(var i = 0; i < len; i++){
				seat = seats[i];
				resUserArray.push({userID:seat.userID});
			}			

			// Finds the users who have their home office as assigned to the current office (might not have a seat)
			resUserArray.push({'office.officeID':officeID});

			return userCollection.find({$or:resUserArray,userID:{ $exists: true }},
				{fields:{
					_id:0,
					email:1,
					office:1,
					userID:1,
					first:1,
					last:1,
					employee:1,
					phoneNo:1,
					codeRequired:1,
					contactable:1,
					'profileImages.smallProfile':1
				}})
		})
		.then((docs)=>{
			users = docs; // This is all the users assigned to the office or who have an assigned or reserved a seat in the office
			
			// Creates a user object (indexed by userID) and reformats some of the data.
			len = users.length;
			for(var i = 0; i < len; i++){
				user = users[i];
				user.profile = user.profileImages.smallProfile;
				delete user.profileImages;
				userID = user.userID;
				userObj[userID] = user;
			}

			// Adds seats currently reserved by a user to the respective user object
			len = resUserList.length;
			for(var i = 0; i < len; i++){
				reservation = resUserList[i];
				userObj[reservation.userID].seat = reservable[reservation.seatID];
			}

			// Adds seats with an assigned user to the respective user object
			len = seatList.length;
			for(var i = 0; i < len; i++){
				seat = seatList[i];
				userObj[seat.userID].seat = seat;
			}

			// Note - If a user has multiple seats assigned or reserved in a single office, the app will display one of the assigned
			// seats (no particular way to determine which)

			// Changes object to array
			for(var i in userObj){
				userList.push(userObj[i]);
			}
			res.status(200).send({data:userList});

			return seatCollection.find({$or:mapArray},{fields:{_id:0,seatName:1,mapName:1,seatID:1,mapID:1,userID:1,reservable:1}});
		})
		.catch((err)=>{
			console.log(err);
			res.status(300).send({errorMsg:"An error occured while searching for users."});
		})
	} else {
		res.status(498).send({});
	}
})


// Receives a visitor guest log entry from an office kiosk and saves to the database
// If a meeting code is passed as well, the meeting code is checked for validity
// If valid, the user information attached to that meeting code is also returned.
router.post('/visitorLogEntry',authenticate,(req,res)=>{
	if(req.kiosk){
		console.log('Posting a guest log entry');
		var companyNo = req.companyNo;		
		var data = req.body;
		var kiosk = req.kiosk;
		var visitorLogCollection = req.db.get(companyNo + '-visitor-log');
		var visitorCodesCollection = req.db.get(companyNo + '-visitor-codes');
		data.date = new Date().getTime();
		data.kioskID = kiosk.kioskID;
		data.officeID = kiosk.officeID;
		data.mapID = kiosk.mapID;

		visitorLogCollection.insert(data)
		.then((result)=>{
			if(data.visitorCode){
				return visitorCodesCollection.find({visitorCode:data.visitorCode})
			} else {
				res.status(200).send();
				return 'break';
			}
		})
		.then((result)=>{
			if(result == 'break'){
				res.status(200).send({success:true,visitorCode:false});
				return;
			}
			res.status(200).send({success:true,visitorCode:true,code:result[0]});
		})
		.catch((err)=>{
			console.log(err);
			res.status(300).send({errorMsg:"Unable to update at this time, please try again later."});
		})

	} else {
		res.status(498).send({});
	}
})


// This function is used by the front desk kiosk's validation tool to check to see
// if a code is valid before submission.  It also returns the name of the person who
// owns the code.
router.get('/validateCode',authenticate,(req,res)=>{
	if(req.kiosk){
		console.log('Validating Visitor Code');
		var companyNo = req.companyNo;		
		var code = req.query.meetingCodeInput;
		console.log(code)
		var kiosk = req.kiosk;
		var visitorCodesCollection = req.db.get(companyNo + '-visitor-codes');
		var usersCollection = req.db.get(companyNo + '-users');

		visitorCodesCollection.find({visitorCode:code},{fields:{userID:1}})
		.then((result)=>{
			console.log(result)
			if(result.length){ // Code is found
				return usersCollection.find({userID:result[0].userID},{fields:{first:1,last:1}});
			} else { // Code is not found
				return 'break';
			}
		})
		.then((result)=>{
			if(result == 'break'){
				console.log('unable to find code')
				res.status(200).send({result:false});
				return;		
			}
			console.log('Found code and sending name.',result)
			res.status(200).send({result:true,name:result[0].first + ' ' + result[0].last});
			//res.status(200).send({name:result[0].first + ' ' + result[0].last});
			return;
		})
		.catch((err)=>{
			console.log(err);
			res.status(300).send('Unable to complete validation.');			
		})

	} else{
		res.status(498).send({});
	}
})


// This function is used by the front desk kiosk's validation tool to check to see
// if a code is valid before submission. It is different than validateCode because
// it also requires a userID and checks to see if the code is valid and belongs to
// that user.
router.get('/validateUserCode',authenticate,(req,res)=>{
	if(req.kiosk){
		console.log('Validating User Visitor Code');
		var companyNo = req.companyNo;		
		var code = req.query.meetingCodeInput;
		var userID = req.query.userID;
		var kiosk = req.kiosk;
		var visitorCodesCollection = req.db.get(companyNo + '-visitor-codes');

		visitorCodesCollection.find({visitorCode:code,userID})
		.then((result)=>{
			console.log(result)
			if(result.length){ // Code is found
				console.log('Found code.')
				res.status(200).send({result:true});
			} else { // Code is not found
				console.log('unable to find code')
				res.status(200).send({result:false});
			}
		})
		.catch((err)=>{
			console.log(err);
			res.status(300).send('Unable to complete validation.');			
		})
	} else{
		res.status(498).send({});
	}
})


// Route is used to accept a meeting code and visitor information.  The code, once
// validated, is used to identify the code owner.  The code owner is sent a SMS
// message using the Twilio API.  The message includes information about the
// visitor and where the message was sent from.  Once it is determined that the
// message was successfully or unsuccessfully sent. A log entry is made recording
// the visitor, the person being visited, the status of the message, and other
// relevant information.
router.post('/visitorCodeSubmit',authenticate,(req,res)=>{
	if(req.kiosk){
		console.log('Posting a meeting code submission');
		console.log(req.body)
		var companyNo = req.companyNo;		
		var data = req.body;
		var kiosk = req.kiosk;
		var visitorCodesCollection = req.db.get(companyNo + '-visitor-codes');
		var usersCollection = req.db.get(companyNo + '-users');
		var messageLogCollection = req.db.get(companyNo + '-message-log');
		var user;

		console.log('creating message');

		var body = "";

		visitorCodesCollection.find({visitorCode:data.visitorCode})
		.then((result)=>{
			if(result.length){
				user = result[0];
				body += "Visitor Alert: ";
				body += data.guestName;
				if(data.guestCompany){
					body += ", from " + data.guestCompany + ",";
				}
				body += ' is waiting for you at the ';
				body += 'main lobby';
				body += ' kiosk.';
				if(data.guestCell || data.gestEmail){
					body += " This visitor can be reached at ";
					if(data.guestCell && data.guestEmail){
						body +=	data.guestCell + " or " + data.guestEmail + ".";
					} else if(data.guestCell){
						body +=	data.guestCell + ".";
					} else {
						body +=	data.guestEmail + ".";
					}
				}
				console.log(config.messagingServiceSid)
				return req.twilio.messages.create({
					body: body,
					to: user.contact,
					messagingServiceSid: config.messagingServiceSid,
				})	
			} else {
				return('break');
			}
		})
		.then((message)=>{
			if(message == 'break'){
				res.status(300).send({success:false,message:"Unable to validate the visitor code."});
			}
			return messageLogCollection.insert({
				guestName: data.guestName,
				guestCompany: data.guestCompany,
				guestCell: data.guestCell,
				guestEmail: data.guestEmail,
				visitorCode: data.visitorCode,
				userID: user.userID,
				userName: user.userName,
				body: message.body,
				created: message.dateCreated,
				sid: message.sid,
				status: message.status,
				to: message.to,
				price: message.price,
				priceUnit: message.priceUnit
			});
		})
		.then((result)=>{
			res.status(200).send({success:true});			
		})
		.catch((err)=>{
			console.log(err)
			res.status(300).send({success:false,message:"Unable to complete the request at this time."});
		})

	} else{
		res.status(498).send({});
	}
})


// This route is similar to visitorCodeSubmit in that it receives visitor information
// along with a target user to contact.  The primary difference is that there may
// or may not be a visitor code required/provided.  Because of this, the route
// first must determine whether a visitor code was submitted, if so, then it acts
// just like visitorCodeSubmit, if not, then it needs to check to see if the desired
// user requires a code, if not, then it continues with sending the message.
router.post('/contactUserSubmit',authenticate,(req,res)=>{
	if(req.kiosk){
		console.log('Posting a meeting code submission');
		console.log(req.body)
		var companyNo = req.companyNo;		
		var data = req.body;
		var kiosk = req.kiosk;
		var visitorCodesCollection = req.db.get(companyNo + '-visitor-codes');
		var usersCollection = req.db.get(companyNo + '-users');
		var messageLogCollection = req.db.get(companyNo + '-message-log');
		var user;
		var body = "";

		usersCollection.find({userID:data.userID},{fields:{_id:0,codeRequired:1,contactable:1,cell:1}})
		.then((result)=>{
			if(result.length){
				user = result[0];
				if(data.visitorCode && data.codeRequired && user.contactable){ // Code is provided and required
					return visitorCodesCollection.find({visitorCode:data.visitorCode});
				} else if(user.contactable && !user.codeRequired){
					return('continue'); // Code isn't required
				}
			} else { // User isn't found
				return('break');
			}
		})
		.then((result)=>{
			if(result == 'break'){ // User not found
				return('break');
			} else if (result == 'continue'){ // Code wasn't required
				body += "Visitor Alert: ";
				body += data.guestName;
				if(data.guestCompany){
					body += ", from " + data.guestCompany + ",";
				}
				body += ' is waiting for you at the ';
				body += 'main lobby';
				body += ' kiosk.';
				if(data.guestCell || data.gestEmail){
					body += " This visitor can be reached at ";
					if(data.guestCell && data.guestEmail){
						body +=	data.guestCell + " or " + data.guestEmail + ".";
					} else if(data.guestCell){
						body +=	data.guestCell + ".";
					} else {
						body +=	data.guestEmail + ".";
					}
				}
				return req.twilio.messages.create({
					body: body,
					to: user.cell,
					messagingServiceSid: config.messagingServiceSid,
				})
			} else if (result.length){ // Code was required and found
				user = result[0];
				body += "Visitor Alert: ";
				body += data.guestName;
				if(data.guestCompany){
					body += ", from " + data.guestCompany + ",";
				}
				body += ' is waiting for you at the ';
				body += 'main lobby';
				body += ' kiosk.';
				if(data.guestCell || data.gestEmail){
					body += " This visitor can be reached at ";
					if(data.guestCell && data.guestEmail){
						body +=	data.guestCell + " or " + data.guestEmail + ".";
					} else if(data.guestCell){
						body +=	data.guestCell + ".";
					} else {
						body +=	data.guestEmail + ".";
					}
				}
				return req.twilio.messages.create({
					body: body,
					to: user.contact,
					messagingServiceSid: config.messagingServiceSid,
				})
			} else {
				return('break2'); // Code was required but not found
			}
		})
		.then((message)=>{
			if(message == 'break'){ // From initial break
				res.status(300).send({success:false,message:"Unable to contact user."});
				return('break');
			} else if(message == 'break2'){ // Break after clode look-up
				res.status(300).send({success:false,message:"Unable to validate visitor code."});
				return('break');
			} else { // Success
				return messageLogCollection.insert({
					guestName: data.guestName,
					guestCompany: data.guestCompany,
					guestCell: data.guestCell,
					guestEmail: data.guestEmail,
					visitorCode: data.visitorCode,
					userID: user.userID,
					userName: user.userName,
					body: message.body,
					created: message.dateCreated,
					sid: message.sid,
					status: message.status,
					to: message.to,
					price: message.price,
					priceUnit: message.priceUnit
				});				
			}
		})
		.then((message)=>{
			if(message == 'break'){
				return('break');
			}
			res.status(200).send({success:true});			
		})
		.catch((err)=>{
			console.log(err)
			res.status(300).send({success:false,message:"Unable to complete the request at this time."});
		})

	} else{
		res.status(498).send({});
	}
})


module.exports = router;