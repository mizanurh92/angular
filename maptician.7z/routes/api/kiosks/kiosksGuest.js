var router = require('express').Router();
var authenticate = require('../../.././middleware/authenticate').authenticate;
var utils = require('../../.././utils/utils');


// This save the visitor kiosk data.
router.post('/visitorKioskSave',authenticate,function(req,res){
	if(req.kiosk){
		console.log('Save Visitor Kiosk data')
		var data = req.body;
		var name = data.name;
		var companyName = data.company;
		var mobNo = data.mobile;
		var companyEmail= data.email
		data.date = new Date().getTime();
		data.kioskID = req.kiosk.kioskID;
		data.officeID = req.kiosk.officeID;
            var companyNo = req.companyNo;
            var collection = req.db.get(companyNo + '-guestKioskList');
            collection.insert(data)
			.then((result)=>{
				console.log(result);
				res.status(200).send({saveKioskData:true});
			})
			.catch((err)=>{
				console.log(err);
				res.render("Error")
			})
	} else{
			res.status(300).send({});
	}
	
})


module.exports = router;