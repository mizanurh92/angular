var router = require('express').Router();
var authenticate = require('../.././middleware/authenticate').authenticate;
var utils = require('../.././utils/utils');
var config = require('../.././config/config');
var profilePath = config.profilePath;

router.use('/authentication',require('./authentication/authentication'));
router.use('/reports',require('./reports/reports'));
router.use('/analytics',require('./analytics/analytics'));
router.use('/scenarios',require('./scenarios/scenarios'));
router.use('/offices',require('./offices/offices'));
router.use('/company',require('./company/company'));
router.use('/departments',require('./departments/departments'));
router.use('/employees',require('./employees/employees'));
router.use('/kiosks',require('./kiosks/kiosks'));
router.use('/maplinks',require('./maplinks/maplinks'));
router.use('/kiosksGuest',require('./kiosks/kiosksGuest')); // TODO refactor this to be referenced by kiosks.js
router.use('/seats',require('./seats/seats'));
router.use('/reservations',require('./reservations/reservations'));
router.use('/profileImages',require('./profileImages/profileImages'));
router.use('/sms',require('./twillo/sms'));
router.use('/tool',require('./tool/testDatatool'));
router.use('/maintenance',require('./maintenance/maintenance.js'));

module.exports = router;