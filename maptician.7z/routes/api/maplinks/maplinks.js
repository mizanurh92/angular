// This file handles the api's for maplink objects.  Maplinks are mapobjects that connect one map to another within
// the same office.  An example of this would be an elevator which could connect to multiple other elevators
// in an office that spans across several floors.  Maplinks are uni-directional in their links, such that Elevator A
// linking to Elevator B does not establish a link from Elevator B to Elevator A.  This is to reduce the uncertainty
// due to different version of maps and constantly checking for changes which would then have to be pushed to multiple
// maps.  To offset some of the risk of these uni-directional links, a map will validate the linking data each time
// a map is loaded, ensuring, at least, that the link target still exists and the descriptions are up-to-date.

var router = require('express').Router();
var authenticate = require('../../.././middleware/authenticate').authenticate;

// This provides a list of maplinks of a specified type for a given office.  It is used when setting the connection
// for a maplink object by giving a list of its potential counterparts.  Any current connections for these
// maplinks will be returned as well.
router.get('/maplinkList',authenticate,function(req,res){
	if(req.user){
		console.log("Getting Map Link List");
		var officeID = req.query.officeID; // This is the office context we are looking for maplinks for
		var mapID = req.query.mapID; // This is the map we are searching from - should not have matches from this map
		var type = req.query.type; // This is the type of maplink that we're getting a list for (stairs, door, elevator)
		var companyNo = req.companyNo;
		var mapCollection = req.db.get(companyNo + '-maps');
		var mapSavesCollection = req.db.get(companyNo + '-map-saves');

		var map, link;
		var mapObj = {};
		var orList = [];
		var linkList = [];
		mapCollection.find({officeID},{fields:{_id:0,live:0}})
		.then((results)=>{
			for(var i = 0; i < results.length; i++){
				map = results[i];
				if(map.id != mapID){
					mapObj[map.id] = map;
					orList.push({id:map.id,date:map.date})
				}
			}
			return mapSavesCollection.find({$or:orList},{fields:{id:1,'controllers.maplinks':1}});
		})
		.then((results)=>{
			for(var i = 0; i < results.length; i++){
				map = results[i];
				if(map.controllers && map.controllers.maplinks && map.controllers.maplinks.objects){
					mapObj[map.id].links = map.controllers.maplinks.objects;
				}
			}
			for(var i in mapObj){
				map = mapObj[i];
				for(var j = 0; j < map.links.length; j++){
					link = map.links[j];
					if(link.type == type){
						linkList.push({
							mapID:map.id,
							mapName: map.name,
							floor: map.floorNumber,
							suite: map.suiteNumber,
							location: link.points[0],
							type: link.type,
							linkID: link.id,
							linkName: link.name,
							connection: link.connection
						})						
					}
				}
			}
			res.status(200).send({data:linkList});
		})
		.catch((err)=>{
			console.log(err);
			res.status(300).send({});
		})

	} else{
		res.status(498).send({});
	}
})

// This function accepts an array of objects under the key 'data' which contains link entries for maplinke for
// a map during the load process.  The objective is to receive the list of links and their targets and check
// those targets to make sure they still exist.  If they do exist, then pull updated information on them, such
// as the maplink's name, the map's name, and the current coordinates for the object.  This information is
// passed back and used to update the maplinks for the map being loaded.  Note that maplinks are basically
// pointers, and their targets are not impacted by being linked to.
router.post('/validate',authenticate,function(req,res){
	if(req.kiosk || req.user){
		console.log("Validating Map Link List");
		var data = req.body.data;
		var companyNo = req.companyNo;
		var mapCollection = req.db.get(companyNo + '-maps');
		var mapSavesCollection = req.db.get(companyNo + '-map-saves');
		var map, mapID, link, links, connection, connectionID;
		var dataMapObj = {}; // Holds the input data, indexed by map
		var mapList = []; // Contains the set of maps found in the input data, used in initial db search
		var mapObj = {}; // Holds the search results for all maplinks in the set of maps
		var orList = []; // Used when searching for map-save data
		var resultList = []; // Holds the array of updated links

		for(var i = 0; i < data.length; i++){
			dataMapObj[data[i].mapID] = dataMapObj[data[i].mapID] ? dataMapObj[data[i].mapID].push(data[i]) : [data[i]];
		}		
		for(var i in dataMapObj){
			mapList.push({id:i});
		}

		mapCollection.find({$or:mapList},{fields:{_id:0,live:0}})
		.then((results)=>{
			for(var i = 0; i < results.length; i++){
				map = results[i];
				mapObj[map.id] = map;
				orList.push({id:map.id,date:map.date})
			}
			if(orList.length == 0){ // Catch if no maps are found that meet the search criteria
				return([]);
			}
			return mapSavesCollection.find({$or:orList},{fields:{id:1,'controllers.maplinks':1}});
		})
		.then((results)=>{
			for(var i = 0; i < results.length; i++){
				map = results[i];
				if(map.controllers && map.controllers.maplinks && map.controllers.maplinks.objects){
					mapObj[map.id].links = {};
					links = map.controllers.maplinks.objects;
					for(var j = 0; j < links.length; j++){
						link = links[j];
						mapObj[map.id].links[link.id] = link;
					}
				}
			}
			for(var i in dataMapObj){
				mapID = i;
				links = dataMapObj[mapID];
				for(var j = 0; j < links.length; j++){
					link = links[j];
					connectionID = link.connectionID;
					if(mapObj[mapID] && mapObj[mapID].links[connectionID]){
						map = mapObj[mapID];
						connection = map.links[connectionID];
						link.valid = true;
						link.mapName = map.name;
						link.floor = map.floorNumber;
						link.suite = map.suiteNumber;
						link.linkName = connection.name;
						link.location = connection.points[0];
						delete link.location.id;
					} else {
						link.valid = false;
					}
					resultList.push(link);
				}
			}
			res.status(200).send(resultList);
		})
		.catch((err)=>{
			console.log(err);
			res.status(300).send({});
		})
	} else{
		res.status(498).send({});
	}
})

module.exports = router;