var router = require('express').Router();
var authenticate = require('../../.././middleware/authenticate').authenticate;
var config = require('../../.././config/config');
var accountSid = config.twilioAccountSid;
var authToken = config.twilioAuthToken;
var twilio = require('twilio');
var client = new twilio(accountSid, authToken);
var format = require("string-template")
var countrycode = config.countrycode;
var fromTelNo = config.fromTelNo;

router.post('/sendsms', authenticate,function(req,res){
    if(req.kiosk){
        var companyNo = req.companyNo;
        var userCollection = req.db.get(companyNo + '-user-pin');
        // Format using an object hash with keys matching [0-9a-zA-Z]+
        var data = req.body;
        var userID = data.userID;
        var error =false;
        var found =false;
        var errorMsg = "Error in sending message";
        var greeting;
        userCollection.find({userID:userID},{fields:{pin:1}})
        .then((results)=>{
            if(!results[0]){
                errorMsg= "Not able to find pin";
                error = true;
            } else{
                for(var i in results){
                    if(results[i].pin == data.pin ){
                        found = true;
                        break;
                    }
                }
                if(found){
                    greeting = format("Hello {name}, someone is waiting for you in {kiosk}", {
                        name: data.first +' '+ data.last,
                        kiosk: req.kiosk.kioskName                        
                    })
                    
                    client.messages.create({
                        body: greeting,
                        to: countrycode+data.phoneNo, 
                        from: fromTelNo // From a valid Twilio number
                    })
                    .then((message) =>{
                        if(message.sid){
                            console.log(message.sid);
                        }
                        error = saveContactLog(req,message.sid,data);
                    })
                    .catch((err)=>{
                        console.log(err);
                        errorMsg = "Error in sending message";
                        error = true;
                    })
                }else{
                    error = true;
                    errorMsg= "Pin number didn't match";
                }
            }
            if(error){
                res.status(300).send(errorMsg);
            } else{
                res.status(200).send({});
            }
        })
        .catch((err)=>{
            console.log(err);
            errorMsg = "Error in sending message";
            res.status(300).send(errorMsg);
		})
    }  else{
		res.status(300).send({});
	}
});


var saveContactLog = function(req,sid,data) {
    var visitorContactLog = req.db.get(req.companyNo + '-visitor-contact-log');
    delete data.pin;
    var kiosk = req.kiosk;
    data.twilloID = sid;
    data.kioskID = kiosk.kioskID;
    data.officeID = kiosk.officeID;
    data.date = new Date().getTime(); 
    var error = false;
    visitorContactLog.insert(data)
    .then((result)=>{
        console.log(result);
    })
    .catch((err)=>{
        console.log(err);
        error =true;
    })
    return error;
};

module.exports = router;


