var router = require('express').Router();
var authenticate = require('.././middleware/authenticate').authenticate;
var companyData = require('.././middleware/companyData').companyData;
var mapSaveFunctions = require('.././utils/mapSaveFunctions');
var saveMapFile = mapSaveFunctions.saveMapFile;
var saveScenarioFile = mapSaveFunctions.saveScenarioFile;
var saveMapSeats = mapSaveFunctions.saveMapSeats;
var saveMapZones = mapSaveFunctions.saveMapZones;
var saveMapRooms = mapSaveFunctions.saveMapRooms;
var saveMapKiosks = mapSaveFunctions.saveMapKiosks;
var saveMapSeatAssignments = mapSaveFunctions.saveMapSeatAssignments;
var updateChangeLogs = mapSaveFunctions.updateChangeLogs;
var profilePath = require('.././config/config').profilePath;

const axios = require('axios');
const uuid = require('.././utils/utils.js').uuid;
router.get('/demoUsers',authenticate,function(req,res){
	var params = req.query;
	var companyNo = params.companyNo;
	var deptCollection = req.db.get(companyNo + '-departments');
	var officeCollection = req.db.get(companyNo + '-offices');
	var userCollection = req.db.get(companyNo + '-users');
	var offices, department, departments, users, len;
	var insertArray = [];
	var titles = {
		'Unassigned': [
			'Intern'
		],
		'Accounting': [
			'Sr. Accountant',
			'Java Developer',
			'Controller',
			'Internal Auditor',
			'Jr. Accountant',
			'Payables Specialist',
			'Compliance Auditor',
			'Receivables Specialist',
			'Bookkeeper',
			'Information Systems Analyst',
			'Revenue Recognition Specialist',
			'SOX Compliance Auditor'
		],
		'Finance': [
			'CFO',
			'Sr. Financial Analyst',
			'FP&A Analyst',
			'Data Scientist',
			'Director of Finance',
			'Financial Analyst',
			'Finacial Modeler',
		],
		'Development': [
			'Sr. Java Developer',
			'Java Developer',
			'Jr. Java Developer',
			'Software Architect',
			'Enterprise Architect',
			'Program Manager',
			'Project Manager',
			'Product Manager',
			'Sr. QA Analyst',
			'QA Analyst',
			'Jr. QA Analyst',
			'Automation Engineer',
			'Technical Writer',
			'Tech Lead',
			'DBA',
		],
		'Marketing': [
			'Sr. Marketing Associate',
			'Marketing Associate',
			'VP Marketing',
			'SEO Specialist',
			'Social Media Specialist',
			'Director of Marketing',
			'Digital Marketing Lead'
		],
		'Sales': [
			'VP Sales',
			'Director of Sales',
			'Sales Manager',
			'Sales Associate',
			'Outbound Sales Associate',
			'Sr. Sales Associate'
		],
		'Executive': [
			'CEO',
			'CIO',
			'COO'
		],
		'Human Resources':[
			'VP Human Resources',
			'HR Specialist',
			'Compliance Specialist',
			'Employee Trainer',
			'Director of Human Resources'
		]
	}

	var getTitle = function(departmentName){
		var titleList = titles[departmentName];
		console.log(departmentName)
		var len = titleList.length;
		var index = Math.floor(Math.random() * len);
		return titleList[index];
	}

	var toTitleCase = function(str){
    	return str.replace(/\w\S*/g, function(txt){return txt.charAt(0).toUpperCase() + 
    		txt.substr(1).toLowerCase();});
	}

	Promise.all([
			officeCollection.find({},{fields:{_id:0,officeID:1,name:1}}),
			deptCollection.find({},{fields:{_id:0,deptName:1,deptID:1}})
		])
	.then((results)=>{
		offices = results[0];
		departments = results[1];
		return axios.get('https://randomuser.me/api/',{
			params:{
				nat: params.nat || 'us',
				exc: params.exc || 'gender,location,login,dob,registered,picture',
				results: params.results || 1
			}
		})
	})
	.then((data) => {
		users = data.data.results;
		len = users.length;
		for(var i = 0; i < len; i++){
			user = users[i];
			department = departments[Math.floor(Math.random() * departments.length)];
			department = {
				deptID: department.deptID,
				name: department.deptName
			}
			user.employee = {
				employeeID: user.id.value.slice(-7),
				department,
				title: getTitle(department.name)
			}
			user.first = toTitleCase(user.name.first);
			user.last = toTitleCase(user.name.last);
			user.userStatus = "unassigned";
			user.profileImages = {
				largeProfile:"https://s3.amazonaws.com/nick-maptician/largeProfile.png",
				mediumProfile:"https://s3.amazonaws.com/nick-maptician/smallProfile.png",
				smallProfile:"https://s3.amazonaws.com/nick-maptician/thumbnailProfile.png"
			}
			user.office = offices[Math.floor(Math.random() * offices.length)];
			user.kioskSearchable = true;
			user.contactable = true;
			user.codeRequired = Math.floor(Math.random() * 2) ? true : false; // 50/50
			user.userID = uuid();
			user.userType = "user";
			user.tokenhash = uuid();
			delete user.name;
			delete user.id;
			delete user.nat;
		}
		
		for(var i in users){
			insertArray.push({insertOne: {document:users[i]}})
		}
		return userCollection.bulkWrite(insertArray);
	})
	.then((result)=>{
		res.status(200).send({result:"success"});		
	})
	.catch((error) => {
		console.log(error);
		res.status(300).send();
	});
})


router.post('/savemap', authenticate, function(req,res){
	if(req.user){
		var data = JSON.parse(req.body.data);
		var officeID = data.officeID;
		data.date = new Date().getTime();
		data.companyID = req.user.companyID;
		console.log(data)
		Promise.all([
				saveMapFile(data,req),
				saveMapSeats(data,req),
				saveMapZones(data,req),
				saveMapRooms(data,req),
				saveMapSeatAssignments(data,req),
				saveMapKiosks(data,req,officeID)
			])
			.then((result)=>{
				console.log('Save Successful');
				return updateChangeLogs(data,req);
			})
			.then((results)=>{
				console.log('Change logs updated');
				res.status(200).send({data:1});
			})
			.catch((err)=>{
				console.log('Error in save file',err)
				res.status(300).send({data:2});
			})
	} else {
		console.log('No token, sending error to log out user.')
		res.status(498).send();
	}
})

router.delete('/removeMapFile',authenticate,function(req,res){
	if(req.user){
		var companyNo = req.companyNo;
		var mapID = req.body.id;
		var mapCollection = req.db.get(companyNo + '-maps');
		var saveCollection = req.db.get(companyNo + '-map-saves');
		var seatCollection = req.db.get(companyNo + '-seats');
		var seatAssignmentCollection = req.db.get(companyNo + '-seat-assignments');
		var zoneAssignmentCollection = req.db.get(companyNo + '-zones');
		var roomAssignmentCollection = req.db.get(companyNo + '-rooms');
		var userAssignmentCollection = req.db.get(companyNo + '-users');
		Promise.all([
				mapCollection.remove({id:mapID}),
				saveCollection.remove({id:mapID}),
				seatCollection.remove({mapID}),
				seatAssignmentCollection.remove({mapID}),
				zoneAssignmentCollection.remove({mapID}),
				roomAssignmentCollection.remove({mapID}),
				userAssignmentCollection.remove({mapID}),
			])
			.then((docs)=>{
				console.log('Map Deleted Successfully');
				res.send({files:'success'});
			})
			.catch((err) => {
				console.log('Error in map deletion:',err);
				res.send({files:null});
			})
	} else {
		console.log('No token, sending error to log out user.')
		res.status(498).send();
	}
})

router.get('/loadFileList',authenticate,function(req,res){
	console.log('loading file list');
	if(req.user){
		var companyNo = req.companyNo;
		var mapCollection = req.db.get(companyNo + '-maps');
		var officeCollection = req.db.get(companyNo + '-offices');
		var officeObj = {};
		var mapArray = [];
		var office,officeID,map,offices;

		Promise.all([
			mapCollection.find(),
			officeCollection.find()
		])
		.then((results)=>{
			maps = results[0];
			offices = results[1];
			for(var i in offices){
				office = offices[i];
				officeID = office.officeID;
				officeObj[officeID] = office;
			}			
			for(var i in maps){
				map = maps[i];
				officeID = map.officeID;
				office = officeObj[officeID];
				mapArray.push({
					id: map.id,
					name: map.name,
					officeName: office.name,
					date: map.date,
					floor: map.floorNumber,
					suite: map.suiteNumber,
					city: office.city,
					state: office.state,
					zip: office.zip,
					country: office.country,
					address1: map.address1,
					address2: map.address2,
					live: map.live
				})
			}
			res.send({data:mapArray});			
		})
		.catch((err) => {
			console.log(err)
			res.send({data:null});
		})
	} else {
		console.log('No token, sending error to log out user.')
		res.status(498).send();
	}
})

router.get('/loadViewerFileList',authenticate,function(req,res){
	console.log('loading viewer file list');
	if(req.user){
		var companyNo = req.companyNo;
		var mapCollection = req.db.get(companyNo + '-maps');
		var officeCollection = req.db.get(companyNo + '-offices');
		var officeObj = {};
		var mapArray = [];
		var office,officeID,map,offices;

		Promise.all([
			mapCollection.find({live:true}),
			officeCollection.find()
		])
		.then((results)=>{
			maps = results[0];
			offices = results[1];
			for(var i in offices){
				office = offices[i];
				officeID = office.officeID;
				officeObj[officeID] = office;
			}			
			for(var i in maps){
				map = maps[i];
				officeID = map.officeID;
				office = officeObj[officeID];
				mapArray.push({
					id: map.id,
					name: map.name,
					officeName: office.name,
					date: map.date,
					floor: map.floorNumber,
					suite: map.suiteNumber,
					city: office.city,
					state: office.state,
					zip: office.zip,
					country: office.country,
					address1: map.address1,
					address2: map.address2,
				})
			}
			console.log(mapArray)
			res.send({data:mapArray});			
		})
		.catch((err) => {
			console.log(err)
			res.send({data:null});
		})
	} else {
		console.log('No token, sending error to log out user.')
		res.status(498).send();
	}
})

router.get('/loadFileVersionList',authenticate,function(req,res){
	console.log('loading file version list');
	if(req.user){
		var companyNo = req.companyNo;
		var mapCollection = req.db.get(companyNo + '-maps');
		var savesCollection = req.db.get(companyNo + '-map-saves');
		var mapID = req.query.id;
		var mapArray = [];
		var map,saves,name,date;

		Promise.all([
			mapCollection.find({id:mapID}),
			savesCollection.find({id:mapID},{fields:{_id:0,date:1}})
		])
		.then((results)=>{
			map = results[0][0];
			saves = results[1];
			name = map.name;
			for(var i in saves){
				mapArray.push({
					id:mapID,
					name,
					date:saves[i].date
				})
			}
			res.send({data:mapArray});			
		})
		.catch((err) => {
			console.log(err)
			res.send({data:null});
		})
	} else {
		console.log('No token, sending error to log out user.')
		res.status(498).send();
	}
})

router.get('/loadMapFile',authenticate,function(req,res){
	if(req.user){
		var companyNo = req.companyNo;
		var map,save,combined,date;
		var mapCollection = req.db.get(companyNo + '-maps');
		var saveCollection = req.db.get(companyNo + '-map-saves');
		var id = req.query.id;
		if(req.query.date){ // Path for if a specific date was passed to the route (and so potential loading a previously saved version)
			date = 1*req.query.date;
			Promise.all([
				mapCollection.find({id}),
				saveCollection.find({id,date})
			])
			.then((result)=>{
				map = result[0][0];
				save = result[1][0];
				save.name = map.name;
				save.officeID = map.officeID;
				save.live = map.live;
				res.send(save);
			})
			.catch((err) => {
				console.log(err);
			})
		} else { // Path where a date isn't specified.  Loads the most recent map version
			mapCollection.find({id})
			.then((result)=>{
				map = result[0];
				date = 1*map.date;
				return saveCollection.find({id,date});
			})
			.then((result)=>{
				save = result[0];
				save.name = map.name;
				save.officeID = map.officeID;
				save.live = map.live;
				res.send(save);
			})
			.catch((err) => {
				console.log(err);
			})			
		}
	} else {
		console.log('No token, sending error to log out user.')
		res.status(498).send();
	}
})

router.get('/loadOfficeFile',authenticate,function(req,res){
	if(req.kiosk){
		console.log("Loading office file")
		var companyNo = req.companyNo;
		var officeID = req.kiosk.officeID;
		var mapCollection = req.db.get(companyNo + '-maps');
		var saveCollection = req.db.get(companyNo + '-map-saves');
		var mapList, map;
		var orList = [];
		var mapObj = {};
		mapCollection.find({officeID,live:true})
		.then((maps)=>{
			mapList = maps;
			for(var i = 0; i < mapList.length; i++){
				map = mapList[i];
				orList.push({id:map.id,date:map.date})
				mapObj[map.id] = map;
			}
			return saveCollection.find({$or:orList});
		})
		.then((saves)=>{
			for(var i = 0; i < saves.length; i++){
				map = saves[i];
				mapID = map.id;
				map.name = mapObj[mapID].name;
				map.floor = mapObj[mapID].floorNumber;
				map.suite = mapObj[mapID].suiteNumber;
			}
			res.send(saves);
		})
		.catch((err)=>{
			console.log(err);
			res.send([]);			
		})
	} else {
		console.log('No token, sending error to log out user.')
		res.status(498).send();
	}
})


router.get('/appData',authenticate,function(req,res){
	if(req.user){
		console.log("Getting data for app load")
		var companyNo = req.companyNo;
		var departmentCollection = req.db.get(companyNo + '-departments');
		var departments;

		Promise.all([
				departmentCollection.find({},{fields:{_id:0,deptName:1,deptID:1}})
			])
		.then((results)=>{
			departments = results[0];
			var deptObj = {};
			for(var i = 0; i < departments.length; i++){
				deptObj[departments[i].deptID] = departments[i].deptName;
			}
			res.status(200).send({
				departments:deptObj,
			});
		})
		.catch((err)=>{
			console.log(err);
			res.status(300).send({});		
		})
	} else {
		console.log('No token, sending error to log out user.')
		res.status(498).send();
	}
})


router.get('/',authenticate,companyData,function(req,res,next){
	if(req.user){
		var companyNo = req.companyNo;
		var companyCollection = req.db.get('companies');
		var departmentCollection = req.db.get(companyNo + '-departments');
		Promise.all([
			companyCollection.find({companyNo},{fields:{_id:0,tables:1}}),
			departmentCollection.find({},{fields:{_id:0,deptName:1,deptID:1}})
		])
		.then((results)=>{
			var companyData = results[0][0];
			var departments = results[1];
			console.log('Rendering Admin User Home');
			
			var userData = {
				userID:req.user.userID,
				companyID:req.user.companyID,
				first:req.user.first,
				last:req.user.last,
				full:req.user.first + ' ' + req.user.last
			}

			var styleSheets = [
				'jquery-ui',
				'mapArea',
				'leftSidebar',
				'rightSidebar',
				'formModals',
				'buttonBar',
				'checkboxSlider',
				'spectrum',
				'icheckBlue',
				'icons',
				'progressBar',
				'datatables',
				'editor/editor.dataTables',
				'editor/svg',
				'analytics/analytics',
				'viewer/rightNav',
				'offices/offices',
				'company/company',
				'viewer/scheduler',
				'profile/profile',
				'./../jquery-modal/jquery.modal.min',
				'./../cropper/dist/cropper.min',
				'./../chosen/chosen.min',
				'./../sweetalert2/dist/sweetalert2.min',
				'./../spectrum/spectrum',
				'./../fullcalendar/dist/fullcalendar.min',
				'icheck/polaris/polaris',
				'scenarios/scenarios',
				'departments/departments',
				'home/home',
				'home/reportMenu',
				'progress-bars/cssprogress',
				'mobiscroll/mobiscroll.custom-3.2.5.min',
				'frontDesk/flowUpLabels',
				'maintenance/maintenance'
				]

			var plugins = [
				'./../core.js/client/shim.min',		
				'./../jquery/dist/jquery.min',
				'./../jquery-ui/jquery-ui.min',
				'./../jquery-modal/jquery.modal.min',
				'./../jquery-slimscroll/jquery.slimscroll.min',
				'./../jquery-validation/dist/jquery.validate.min',
				'./../jquery-touch-events/src/jquery.mobile-events.min',
				'./../spectrum/spectrum',
				'./../velocity/velocity.min',
				'./../iCheck/icheck.min',
				'./../cropper/dist/cropper',
				'./../sweetalert2/dist/sweetalert2.min',
				'./../d3/d3.min',
				'./../moment/min/moment.min',
				'./../fullcalendar/dist/fullcalendar.min',
				'./../js-quantities/build/quantities',
				'./../chosen/chosen.jquery.min',
				'./../crossfilter/crossfilter.min',
				'./../dcjs/dc.min',
				'plugins/flowUpLabels',
				'plugins/datatables.min',
				'plugins/dataTables.editor.min',
				'plugins/moment-precise-range',
				'plugins/mobiscroll.custom-3.2.5.min',
			  'plugins/FileSaver',
			  'plugins/yjspdf.min',
			  'plugins/save-svg-to-png',
			  'plugins/svg2pdf'
			]
      
			var scripts = [
				'app/app',
				'app/inits',
				'app/leftNav',
				'app/buttonPanel',
				'app/fileButtonControls',
				'app/mathClass',
				'app/modals',
				'app/home/home',
				'app/mapEngine/dataConnector',
				'app/mapEngine/mapContainerManager',
				'app/mapEngine/mapManager',
				'app/mapEngine/minimapManager',
				'app/mapEngine/settingsManager',
				'app/mapEngine/stateManager',
				'app/mapEngine/controllers/objectController',
				'app/mapEngine/controllers/architectureController',
				'app/mapEngine/controllers/areaController',
				'app/mapEngine/controllers/furnitureController',
				'app/mapEngine/controllers/kioskController',
				'app/mapEngine/controllers/maplinkController',
				'app/mapEngine/controllers/seatController',
				'app/mapEngine/editor/editorController',
				'app/mapEngine/editor/editorHandleRouter',
				'app/mapEngine/editor/editorInstance',
				'app/mapEngine/editor/editorKeyboardRouter',
				'app/mapEngine/editor/editorMouseRouter',
				'app/mapEngine/editor/editorObjectSelector',
				'app/mapEngine/editor/editorReports',				
				'app/mapEngine/editor/editorResizeMap',
				'app/mapEngine/editor/editorSVGRouter',
				'app/mapEngine/viewer/viewerButtonBindings',
				'app/mapEngine/viewer/viewerController',
				'app/mapEngine/viewer/viewerInstance',
				'app/mapEngine/viewer/viewerKeyboardRouter',
				'app/mapEngine/viewer/viewerMouseRouter',
				'app/mapEngine/viewer/viewerObjectSelector',
				'app/mapEngine/viewer/viewerSVGRouter',
				'app/mapEngine/viewer/viewerTables',
				'app/mapEngine/mapobjects/mapObject',
				'app/mapEngine/mapobjects/crosshair',
				'app/mapEngine/mapobjects/dragBoxSelector',
				'app/mapEngine/mapobjects/labels',
				'app/mapEngine/mapobjects/point',
				'app/mapEngine/mapobjects/architecture/column',
				'app/mapEngine/mapobjects/architecture/door',
				'app/mapEngine/mapobjects/architecture/elevator',
				'app/mapEngine/mapobjects/architecture/sink',
				'app/mapEngine/mapobjects/architecture/stairs',
				'app/mapEngine/mapobjects/architecture/toilet',
				'app/mapEngine/mapobjects/architecture/wall',
				'app/mapEngine/mapobjects/architecture/window',
				'app/mapEngine/mapobjects/area/area',
				'app/mapEngine/mapobjects/area/room',
				'app/mapEngine/mapobjects/area/zone',
				'app/mapEngine/mapobjects/furniture/cubicle',
				'app/mapEngine/mapobjects/furniture/cubicleEntrance',
				'app/mapEngine/mapobjects/furniture/desk',
				'app/mapEngine/mapobjects/furniture/Ldesk',
				'app/mapEngine/mapobjects/furniture/table',
				'app/mapEngine/mapobjects/kiosk/kiosk',
				'app/mapEngine/mapobjects/maplink/maplink',				
				'app/mapEngine/mapobjects/maplink/doorLink',
				'app/mapEngine/mapobjects/maplink/elevatorLink',
				'app/mapEngine/mapobjects/maplink/stairslink',
				'app/mapEngine/mapobjects/seat/seat',
				'app/analytics/analytics',
				'app/calendar/calendar',
				'app/company/company',
				'app/company/analytics',
				'app/company/summary',
				'app/departments/departments',
				'app/offices/offices',
				'app/offices/analytics',
				'app/offices/occupants',
				'app/offices/summary',
				'app/profile/profileMenu',
				'app/profile/userProfileMenu',
				'app/reports/modalTables',
				'app/reports/standardReports',
				'app/reports/standardReports',
				'app/maintenance/maintenance'
			]

			var async = [
			  	'./../js-xlsx/jszip',
			  	'./../js-xlsx/dist/xlsx.core.min',
			  	'plugins/simple-excel.min',
			  	'plugins/xlsx',
			]

			console.log(companyData.tables)

			res.render('home', {
				title: 'Maptician',
				styleSheets:styleSheets,
				plugins:plugins,
				scripts:scripts,
				async:async,
				user:userData,
				company:req.company,
				profilePath,
				roomTypes:companyData.tables.roomTypes,
				equipment: companyData.tables.equipment,
				ameneties: companyData.tables.ameneties,
				accessibility: companyData.tables.accessibility,
				departments: departments,
				category:companyData.tables.category
			});
		})
		.catch((err)=>{
			console.log(err);
			console.log('Rendering Landing Screen');
			res.render('landing', { title: 'Maptician' })
		})
	} else if(req.kiosk){

		console.log('Rendering Kiosk Home');

		var kioskData = {
			kioskID:req.kiosk.userID,
			kioskName: req.kiosk.kioskName,
			mapName: req.kiosk.mapName,
			mapID: req.kiosk.mapID,
			userType: req.kiosk.userType,
			location: req.kiosk.location
		}
		
		var styleSheets = [
			'mapArea',
			'rightSidebar',
			'formModals',
			'buttonBar',
			'icons',
			'datatables',
			'editor/editor.dataTables',
			'./../jquery-modal/jquery.modal.min',
			'./../chosen/chosen.min',
			'./../sweetalert2/dist/sweetalert2.min',
			'./../slick-carousel/slick/slick',
			'./../slick-carousel/slick/slick-theme',
			'frontDesk/frontDesk',
			'frontDesk/officeDirectory',
			'frontDesk/modals',
			'frontDesk/flowUpLabels',
			'frontDesk/slider',
			'frontDesk/map'
			]

		var plugins = [
			'./../core.js/client/shim.min',		
			'./../jquery/dist/jquery.min',
			'./../jquery-validation/dist/jquery.validate.min',
			'./../jquery-validation/dist/additional-methods.min',
			'./../velocity/velocity.min',
			'./../iCheck/icheck.min',
			'./../sweetalert2/dist/sweetalert2.min',
			'./../moment/min/moment.min',
			'./../chosen/chosen.jquery.min',
			'./../slick-carousel/slick/slick.min',
			'plugins/flowUpLabels',
			'plugins/jquery.maskedinput',
			'plugins/datatables.min',
			'plugins/dataTables.editor.min',
			'./../jquery-touch-events/src/jquery.mobile-events.min',
			]

		var scripts = [
			'app/frontDesk/frontDesk',
			'app/controllers/objectController',
			'app/controllers/architectureController',
			'app/controllers/areaController',
			'app/controllers/connectionController',
			'app/controllers/seatController',
			'app/controllers/kioskController',
			'app/controllers/maplinkController',
			'app/controllers/furnitureController',			
			'app/controllers/stateController',
			'app/mapobjects/mapObject',
			'app/mapobjects/architecture/column',
			'app/mapobjects/architecture/door',
			'app/mapobjects/architecture/elevator',
			'app/mapobjects/architecture/sink',
			'app/mapobjects/architecture/toilet',
			'app/mapobjects/architecture/stairs',
			'app/mapobjects/architecture/wall',
			'app/mapobjects/architecture/window',
			'app/mapobjects/furniture/desk',
			'app/mapobjects/furniture/Ldesk',
			'app/mapobjects/furniture/table',
			'app/mapobjects/furniture/cubicle',
			'app/mapobjects/furniture/cubicleEntrance',
			'app/mapobjects/area/area',
			'app/mapobjects/area/room',
			'app/mapobjects/area/zone',
			'app/mapobjects/seat/seat',
			'app/mapobjects/kiosk/kiosk',
			'app/mapobjects/maplink/maplink',
			'app/mapobjects/maplink/stairslink',
			'app/mapobjects/maplink/doorLink',
			'app/mapobjects/maplink/elevatorLink',
			'app/mapobjects/crosshair',
			'app/mapobjects/point',
			'app/mapobjects/labels',
			'app/mapobjects/dragBoxSelector',
			'app/mapContainerClass',
			'app/settingsClass',
			'app/mapClass',
			'app/minimapClass',
			'app/kiosk/kioskInstance',
			'app/kiosk/kioskController',
			'app/kiosk/kioskMouseRouter',
			'app/kiosk/kioskSVGRouter',
			'app/kiosk/kioskObjectSelector',
			'app/kiosk/kioskKeyboardRouter',
			'app/kiosk/kioskTables',
			'app/mathClass',
			'app/buttonPanel',
			'app/frontDesk/officeDirectory',
			'app/frontDesk/guestLogModal',
			'app/frontDesk/visitorCodeModal',
			'app/frontDesk/contactUserModal',
			'./../sw'
			]

		var async = [
			'./../jquery-modal/jquery.modal.min',
			'./../jquery-slimscroll/jquery.slimscroll.min',
			'./../jquery-touch-events/src/jquery.mobile-events.min',
		]

		res.render('frontDesk/frontDeskHome', {
			title: 'Maptician',
			styleSheets:styleSheets,
			plugins:plugins,
			scripts:scripts,
			async:async,
			user:{},
			company:req.company,
			companyImage:profilePath + req.kiosk.companyID + '/' + req.company.profileImage,
			message: req.company.message,
			visitPurpose: req.kiosk.visitPurpose || ['Meeting','Interview','Vendor Service','Inter-company Visit','Other'],
			profilePath
		});
	} else {
		console.log('Rendering Landing Screen');
		res.render('landing', { title: 'Maptician' })		
	}
})

module.exports = router;
