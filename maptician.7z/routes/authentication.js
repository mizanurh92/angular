var router = require('express').Router();
var credential = require('credential');
var pw = credential();
var jwt = require('jsonwebtoken');
var uuid = require('.././utils/utils.js').uuid;
var profilePath = require('.././config/config').profilePath;

// Renders the loging screen based on page navigation to /login
router.get('/login',function(req,res){
	console.log("Rendering Log-In Screen");
	res.render('login');
})

// Renders the loging screen based on page navigation to /login
router.get('/kioskLogin',function(req,res){
	console.log("Rendering Kiosk Log-In Screen");
	res.render('kiosklogin');
})

// User posts login credentials and if the credentials are valid, this creates a JWT in a cookie for app authentication
// User is routed on front-end to the main page on successful login.
router.post('/login',function(req,res){
	console.log("Route: post/login");
	var companyCollection = req.db.get('companies');
	var data = req.body;
	var company = data.company.toLowerCase();
	var password = data.password;
	var email = data.email
	if(!company){
		res.status(200).send({login:false,err:"Company Name not entered"});
		return;
	}
	if(!password){
		res.status(200).send({login:false,err:"Password not entered"});
		return;
	}
	if(!email){
		res.status(200).send({login:false,err:"Email not entered"});
		return;
	}
	var collectionPrefix;
	companyCollection.find({lcase:company})
	.then((doc)=>{
		if(!doc.length){
			console.log("Could not locate company");
			res.status(200).send({login:false,err:"Invalid Login Credentials"});
			return("Err");			
		}
		collectionPrefix = doc[0].companyNo;
		var userCollection = req.db.get(collectionPrefix + '-users');
		return userCollection.findOne({email:data.email})
	})
	.then((doc) => {
		if(doc == "Err"){return;}
		if(!doc){
			console.log("Could not locate user file");
			res.status(200).send({login:false,err:"Incorrect Email or Password"});
			return;			
		}
		if(doc.userStatus != "active"){
			console.log("User account is not active.");
			res.status(200).send({login:false,err:"User account is not active"});
			return;				
		}
		var storedHash = JSON.stringify(doc.password);
		pw.verify(storedHash,password,function(err,isValid){
			if (err) { 
				res.status(200).send({login:false,err:"Error Processing Credentials"});
				return;
			} else {
				var tokensecret = doc.tokenhash;
				var id = doc.userID;
				var token = jwt.sign({userID:id,company:collectionPrefix},tokensecret,{ expiresIn: '30d' });
			}
			if(isValid){
				console.log("Verified.  Storing token:",token)
				res.cookie('x-auth',token,{
					Secure:true,
					httpOnly:true,
					expires: new Date(new Date().getTime()+200000000)
				});
				res.status(200).send({login:true});
			} else {
				console.log("Password doesn't match records.");
				res.status(200).send({login:false,err:"Passwords don't match"});
			}
		})
	})
	.catch((err)=>{
		console.log(err);
		res.status(300).send({});
	})
})

// User posts login credentials and if the credentials are valid, this creates a JWT in a cookie for app authentication
// User is routed on front-end to the main page on successful login.
router.post('/kioskLogin',function(req,res){
	console.log("Route: post/login");
	var companyCollection = req.db.get('companies');
	var data = req.body;
	var company = data.company.toLowerCase();
	var password = data.password;
	var username = data.username
	if(!company){
		res.status(200).send({login:false,err:"Company Name not entered"});
		return;
	}
	if(!password){
		res.status(200).send({login:false,err:"Password not entered"});
		return;
	}
	if(!username){
		res.status(200).send({login:false,err:"User Name not entered"});
		return;
	}
	var collectionPrefix;
	companyCollection.find({lcase:company})
	.then((doc)=>{
		collectionPrefix = doc[0].companyNo;
		var userCollection = req.db.get(collectionPrefix + '-users');
		return userCollection.findOne({userName:username})
	})
	.then((doc) => {
		if(!doc){
			console.log("Could not locate user file");
			res.status(200).send({login:false,err:"Incorrect User Name or Password"});
			return;			
		}
		if(doc.status != "active"){
			console.log("User account is not active.");
			res.status(200).send({login:false,err:"User account is not active"});
			return;				
		}
		var storedHash = JSON.stringify(doc.password);
		pw.verify(storedHash,password,function(err,isValid){
			if (err) { 
				res.status(200).send({login:false,err:"Error Processing Credentials"});
				return;
			} else {
				var tokensecret = doc.tokenhash;
				var id = doc.kioskID;
				var token = jwt.sign({kioskID:id,company:collectionPrefix},tokensecret,{ expiresIn: '3d' });
			}
			if(isValid){
				console.log("Verified.  Storing token:",token)
				res.cookie('x-auth',token,{
					Secure:true,
					httpOnly:true,
					expires: new Date(new Date().getTime()+259200000)
				});
				res.status(200).send({login:true});
			} else {
				console.log("Password doesn't match records.");
				res.status(200).send({login:false,err:"Incorrect User Name or Password"});
			}
		})
	})
	.catch((err)=>{
		console.log(err);
		res.status(300).send({});
	})
})

// Renders the registration screen based on navigation to /register
router.get('/register',function(req,res){
	console.log("Rendering Registration Screen");
	res.render('register');
})

// Checks to see if a company name is already in the company collection.  Used as part of the registration process.
router.post('/checkCompany',function(req,res){
	var company = req.body.company.toLowerCase();
	var companyCollection = req.db.get('companies');
	companyCollection.find({lcase:company})
	.then((result)=>{
		if(result.length){
			res.status(200).send(false);
		} else {
			res.status(200).send(true);
		}
	})
	.catch((err)=>{
		console.log(err);
		res.status(300).send();
	})
})


// Registers a new company in the application.  Also creates and admin account for login.
router.post('/register',function(req,res){
	console.log('Starting Company Registration Process')
	var db = req.db;
	var companyCollection = db.get('companies');
	var isError = false;
	var data = req.body;
	var company = data.company;
	var counter;
	var lcase = company.toLowerCase();
	if(!company){
		res.status(300).send({error:"Company information not submitted."});
		return;
	}
	var password = data.password;
	var cpassword = data.cpassword;
	if(!password || !cpassword || password != cpassword){
		res.status(300).send({error:"Password information not submitted or doesn't match."});
		return;
	}
	var email = data.email;
	if(!email){
		// TODO need email validation
		res.status(300).send({error:"Email information not submitted."});
		return;	
	}
	var first = data.first;
	var last = data.last;
	var phone = data.phone;
	if(!first || !last){
		res.status(300).send({error:"Administrative user information missing."});
		return;			
	}
	var website = data.website;
	var address1 = data.address1;
	var address2 = data.address2;
	var city = data.city;
	var state = data.state;
	var zip = data.zip;
	var country = data.country;
	if(!address1 || !city || !state || !country){
		res.status(300).send({error:"Missing company location inforamtion."});
		return;			
	}
	var date = new Date().getTime();
	var companyID;
	var user, userID, userCollection, departmentCollection, tokenhash;
	companyCollection.find({lcase})
	.then((data)=>{
		if(data.length){
			res.status(300).send({error:"Company already exists."});
			return("Break");
		} else {
			return companyCollection.update({counter:true},{$inc:{companyCount:1}});
		}
	})
	.then((data)=>{
		return companyCollection.find({counter:true});
	})
	.then((data)=>{
		counter = data[0].companyCount;
		var roomTypes = [
			"Conference Room",
			"Meeting Room",
			"Private Office",
			"Workstations",
			"Training Room"
		]
		var equipment = [
			"Conference Table",
			"Whiteboard",
			"Video Conferencing",
			"Projector",
			"Computer",
			"Phone",
			"Fax",
			"Sound System",
			"Television",
			"Copier",
			"Printer"
		]
		var ameneties = [
			"Window",
			"Corner",
			"Access Control",
			"Sound Insulation",
			"Wi-Fi"
		]
		var accessibility = [
			"Wheelchair",
			"Visual Impairment",
			"Hearing Impairment",
			"Maternity"
		]
		return companyCollection.insert({
			companyName: company,
			lcase,
			mailingAddress: {
				address1,
				address2,
				city,
				state,
				zip,
				country
			},
			website,
			companyStatus: "active",
			creationDate: date,
			companyNo: counter,
			tables: {
				roomTypes,
				equipment,
				ameneties,
				accessibility
			}
		});
	})
	.then((data)=>{
		if(data == "Break"){
			return("Break");
		}
		companyID = data._id;
		return pw.hash(password)
	})
	.then((hash)=>{
		var passData = JSON.parse(hash);
		tokenhash = uuid();
		userID = uuid();
		user = {
			email,
			first,
			last,
			cell: phone,
			tokenhash: tokenhash,
			companyID,
			userStatus: 'active',
			contact: [],
			userType: 'Account Admin',
			profileImages: {
				largeProfile: profilePath + 'largeProfile.png',
				mediumProfile: profilePath + 'smallProfile.png',
				smallProfile: profilePath + 'blankProfile.png'
			},
			userID: userID,
			password: passData,
			kioskSearchable: true,
			contactable: true,
			codeRequired: true,
			employee: {
				employeeID: null,
				title: null,
				department: {
					deptID: "00000",
					deptName: "Unassigned"
				}
			}
		}
		departmentCollection = db.create(counter + '-departments');
		var mapSaveCollection = db.create(counter + '-map-saves');
		var officeCollection = db.create(counter + '-offices');
		var roomResCollection = db.create(counter + '-room-reservations');
		var roomCollection = db.create(counter + '-rooms');
		var scenarioCollection = db.create(counter + '-scenarios');
		var seatAssignmentCollection = db.create(counter + '-seat-assignments');
		var seatReservationsCollection = db.create(counter + '-seat-reservations');
		var seatCollection = db.create(counter + '-seats');
		var zoneCollection = db.create(counter + '-zones');
		userCollection = db.create(counter + '-users');
		var mapsCollection = db.create(counter + '-maps');
		return Promise.all([
			roomCollection.ensureIndex('mapID'),
			roomCollection.ensureIndex('roomID'),
			roomCollection.ensureIndex('status'),
			seatAssignmentCollection.ensureIndex('mapID'),
			seatAssignmentCollection.ensureIndex('seatID'),
			seatAssignmentCollection.ensureIndex('userID'),	
			seatCollection.ensureIndex('mapID'),
			seatCollection.ensureIndex('seatID'),
			seatCollection.ensureIndex('status'),
			zoneCollection.ensureIndex('mapID'),
			zoneCollection.ensureIndex('zoneID'),
			zoneCollection.ensureIndex('status'),
			userCollection.ensureIndex('userID'),
			mapsCollection.ensureIndex('id'),
			mapsCollection.ensureIndex('officeID'),	
			])
	})
	.then((data)=>{
		return Promise.all([
			userCollection.insert(user),
			departmentCollection.insert({deptName:"Unassigned",deptID:"00000"})
		]);
	})
	.then((data)=>{
		if(data == "Break"){return("Break");} // Catches the break command from the path where the company already existed
		if(isError){
			console.log('Error Place 1')
			res.status(300).send({error:'Error occured in account creation.  Please try again later.'});
		} else{
			var token = jwt.sign({userID:userID,company:counter},tokenhash,{ expiresIn: '30d' });
			res.cookie('x-auth',token,{
				Secure:true,
				httpOnly:true,
				expires: new Date(new Date().getTime()+200000000)
			});
			res.status(200).send({login:true});
		}
	})
	.catch((err)=>{
		console.log('Promises Error');
		console.log(err);
		res.status(300).send({error:'Error occured in account creation.  Please try again later.'});
	})
})

// Sets the cookie expiration to the current time and sends the user to the login screen
router.get('/logout',function(req,res,next){
	var token = req.cookies['x-auth'];
	if(token){
		res.cookie('x-auth',token,{
		  	Secure:true,
		  	httpOnly:true,
		  	expires: new Date()
		});
	}
	res.render('login');
})

module.exports = router;