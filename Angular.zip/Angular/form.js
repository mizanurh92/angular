var app=angular.module("form",[]);
app.controller("Validate",function($scope){
	$scope.details=false;
	$scope.submit=function(){
		$scope.fullName= $scope.firstName+" "+$scope.lastName;
		if($scope.firstName== "" || $scope.lastName== ""){
			$scope.details=false;
		}else{
			$scope.details=true;
		}

	}
	$scope.signIn=function(){
		$scope.signInDiv=true;

	}
	
})