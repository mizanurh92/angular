var app=angular.module("calc", []);

app.controller("Mainctrl",function($scope){
	//$scope.message="hello,Welcome"
	$scope.one=function(){
		$scope.message="1";
		return $scope.message;

	}
	$scope.two=function(){
		$scope.message="2";
		return $scope.message;
	}
	$scope.three=function(){
		$scope.message="3";
		return $scope.message;
	}
	$scope.four=function(){
		$scope.message="4";
		return $scope.message;
	}
	$scope.five=function(){
		$scope.message="5";
		return $scope.message;
	}
	$scope.six=function(){
		$scope.message="6";
		return $scope.message;
	}
	$scope.seven=function(){
		$scope.message="7";
		return $scope.message;
	}
	$scope.eight=function(){
		$scope.message="8";
		return $scope.message;
	}
	$scope.nine=function(){
		$scope.message="9";
		return $scope.message;
	}
	$scope.add=function(){
		var x=parseInt($scope.message);
		var y= parseInt($scope.message);
		var z=x+y;
		$scope.message=z;
	}
})
