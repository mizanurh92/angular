var app = angular.module('myCtrl',[])

	var MainController = function($scope){
		$scope.message="hello";
	};

app.controller("MainController",MainController)
