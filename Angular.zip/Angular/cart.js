var app=angular.module("cart",[]);
app.controller("Mainctrl",function($scope){
	$scope.products=["mobile","tv"];
	$scope.addfnc = function () {
		if($scope.products.indexOf($scope.product)==-1){ 
			$scope.products.push($scope.product);
        	delete $scope.product;
        }else{
        	$scope.errortext="this item is alreay exits"
        }
       
    };
    $scope.remove=function(index){
    	$scope.products.splice(index, 1);
    }
})