'use strict';
angular.module('myApp.widget', [])
     .directive('appHeader', function() {
          return {
               restrict: 'E',
               replace: true,
               templateUrl: 'templates/header.htm',
               controller: function($scope) {
               }
          }
     })
     .directive("anydate", function ($rootScope) {
                return {
                                restrict: "A",
                                require: "ngModel",
                                link: function (scope, elem, attrs, ngModelCtrl) {
                                                var updateModel = function (dateText) {
                                                                scope.$apply(function () {
                                                                                ngModelCtrl.$setViewValue(dateText);
                                                                                $rootScope.dateData = dateText
                                                                });
                                                };
                                                var options = {
                                                                dateFormat: "mm/dd/yy",
                                                                minDate: -0,
                                                                onSelect: function (dateText) {
                                                                                updateModel(dateText);
                                                                }
                                                };

                                                elem.datepicker(options);

                                }

                }

});

