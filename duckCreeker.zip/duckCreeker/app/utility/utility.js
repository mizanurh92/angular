'use strict';
angular.module('myApp.utility', [])

.factory('mockData',['$http',function($http){
  
    var getData = function(obj,successCallback, failureCallback) {
    console.log(obj)
    var request = $http({
               method: "POST",
               url: 'http://DIN51002262:8081/dct/services/getdata',
               headers: {
                    'Content-Type': 'application/json'
               },
               data: obj
          });
          request.then(successCallback, failureCallback);
      }

      return{
        getData:getData
      };
    
}]);