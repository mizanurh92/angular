'use strict';

angular.module('myApp.view1', ['ngRoute', 'ngTouch', 'ui.grid'])

.config(['$routeProvider', function ($routeProvider) {
	$routeProvider.when('/view1', {
		templateUrl: 'view1/view1.html',
		controller: 'View1Ctrl'
	});
}])

.controller('View1Ctrl', ['$scope', 'mockData', function ($scope, mockData) {
	$scope.quote = function(){
       location.href = '#!/view3';
    }
}]);