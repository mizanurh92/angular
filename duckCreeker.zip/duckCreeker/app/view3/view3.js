'use strict';

angular.module('myApp.view3', ['ngRoute','myApp.utility','ngAnimate', 'ngSanitize', 'ui.bootstrap'])

.config(['$routeProvider', function($routeProvider) {
  $routeProvider.when('/view3', {
    templateUrl: 'view3/view3.html',
    controller: 'View3Ctrl'
  });
}])

.controller('View3Ctrl', ['$scope','mockData', '$rootScope', function($scope,mockData,$rootScope) {
var ctrl = this;
  
  ctrl.active = 0;
  $scope.timeline = [
    {time:"3 Months", days:"3"},
    {time:"6 Months", days:"6"},
    {time:"1 Year", days:"12"}
];
                
$scope.TimelineChange = function(selectedTime) {
    var Month = selectedTime; //or whatever offset
    var CurrentDate = new Date($rootScope.dateData);
    var finalDate = new Date(CurrentDate.setMonth(CurrentDate.getMonth() + Month))
    var month = finalDate.getMonth() + 1;
    var day = finalDate.getDate() - 1;
    var year = finalDate.getFullYear();
    $rootScope.ExpDate = month + '/' + day + '/' + year;
    
}

  $scope.formsubmit=function(param){
  	console.log(param)
  	var obj={"address1":param.appadd1,"address2":param.appadd2,"city":param.appcity,"state":param.appstate,"zipcode":param.appZip,"primaryPhone":param.appphn,"email":param.appemail,"type":"TP","coverageLimitLineA":param.LineALimit,"coverageLimitLineB":param.LineBLimit,"coverageBaseRate":"0","coverageInsurableAmount":"0","coverageRiskA":param.RiskALimit,"coverageRiskB":param.RiskBLimit}
  	$scope.allData=[];
  	mockData.getData(param,function(resp){
  		console.log("added successfully.")
  		console.log(resp)
  		$scope.allData.push({
  			"QuoteNumber": resp.data.data.policy.QuoteNumber,
			"PolicyNumber": resp.data.data.policy.PolicyNumber,
			"premium": resp.data.data.policy.premium,
			"premiumchange": resp.data.data.policy.premiumchange,
			"premium-written": resp.data.data.policy.premium_written,
			"tax":resp.data.data.policy.line.taxes_surcharges,
			"LineAPremium":resp.data.data.policy.line.coverage.lineA.premium,
			"LineBPremium":resp.data.data.policy.line.coverage.lineB.premium,
			"RiskDescription":resp.data.data.policy.line.element.description,
			"Riskinsurable-amount":resp.data.data.policy.line.element.insurable_amount,
			"RiskAPremium":resp.data.data.policy.line.element.riskA,
			"RiskBPremium":resp.data.data.policy.line.element.riskB,
			"RisktotalPremium":resp.data.data.policy.line.element.premium
  		})
  		console.log($scope.allData)
  	})

  }
    

}]);