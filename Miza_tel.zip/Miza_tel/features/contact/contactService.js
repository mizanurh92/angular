(function() {
    'use strict';

	// ContactService for storing data in ContactView.  Not currently used.

	angular.module('app.contact')
	.factory('ContactService', function () {
		
		return{	
			"":"",
		};
	});

})();