(function() {
    'use strict';

	angular.module('app.contact', [])
	.controller("ContactController",function($scope, $location, ContactService, $window){
    	
    	$scope.ContactService = ContactService;      	
      	
    });

})();