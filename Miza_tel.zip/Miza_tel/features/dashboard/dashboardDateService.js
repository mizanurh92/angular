(function() {
    'use strict';

	// HomeService for storing data in HomeView

	angular.module('app.dashboarddateservice', [])
	.factory('DashboardDateService', function ($q, $http) {
		
		return{	
			
			fetchDate: function (type, fleet_id) {
					
				var deferred = $q.defer();
			
				// AJAX request
				$http({
					method: 'GET',
					url: '/api/getDashboardDates',
					params: {
						type: type,
						fleet_id:fleet_id
					}

				}).then(function (response) {
					// success
					// get Results object from GET response
					deferred.resolve(response);

				}, function (reason) {
						// failure
						deferred.reject(reason);
				});

				return deferred.promise;
			},
			
		};
		
	});

})();