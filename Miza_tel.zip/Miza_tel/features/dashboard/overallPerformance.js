(function () {
"use strict";

window.prepOverAllChart = function(fleet_id, dtFrom, dtTo,divId,usSpinnerService,type,country,ageRange){
    if(dtFrom === "") dtFrom = '2016-11-01';
    if(dtTo === "") dtTo = '2017-12-31';
    window.getOverAllPerformance(fleet_id, dtFrom, dtTo,type,country,ageRange, function(data) {
    	expose_overall_period(fleet_id, data,divId,new Date(dtFrom),new Date(dtTo));
    });
};

// Needs to iterate each date between start and end dates
var expose_overall_period = function(fleet_id, data,divId,dtFrom,dtTo) {

    data = data.json_agg;

    if(data === null) {
        console.log('prepChart4 -- no data for this driver and period');
        document.getElementById("nooverallperformancedata").style = "display:block !important;";
        document.getElementById("overallperformance_history_div").style = "visibility:hidden !important" ;
        return false;
    }
    document.getElementById("nooverallperformancedata").style = "display:none !important";
    document.getElementById("overallperformance_history_div").style = "visibility:visible !important";
    var lastDate ='';
    var dateRange = [];
    var dataLookup = [];
    // coalesce into unique dates
    data.map( function(curItem) { 
  		if(lastDate!=curItem.date)
		dateRange.push(curItem.date);
		lastDate=curItem.date;
		});
    // Get a data Lookup for each date series value
    dateRange.map( function(dateString){
		// Intialize first level
		dataLookup[dateString]=[];
		// Initialize each rating mileage
		for(var rating = 1; rating<=5; rating++)
			dataLookup[dateString][rating]=0.0;});
    // Set all the actual values here all at once in one pass
    data.map(function (curItem){
		dataLookup[curItem.date][curItem.rating]=curItem.total_distance;
		});

    //window.chart_days = data.map( (item) => {return item.date} );
    // We need a value for each date even if it is zero
    dataLookup.series = function (rating){
		return dateRange.map( function(curDate) {
		return dataLookup[curDate][rating];});
	};

    var render=function(dataSeries){renderOverAllChart(fleet_id,divId,dateRange,dataSeries);};
    window.getAxes(1,false,dataLookup,render);


};


var renderOverAllChart = function(fleet_id,divId,chart_days,series) {

    Highcharts.chart(divId, {
        chart: {
            type: 'column'
        },
        title: {
            text: 'Daily Mileage by Avg. Score'
        },
        xAxis: {
            categories: chart_days
        },
        yAxis: {
            title: {
                text: null
            },
            stackLabels: {
                enabled: false,
                style: {
                    fontWeight: 'bold',
                    color: (Highcharts.theme && Highcharts.theme.textColor) || 'gray'
                }
            }
        },
        legend: {
            backgroundColor: (Highcharts.theme && Highcharts.theme.background2) || 'white',
            borderColor: '#CCC',
            //borderWidth: 1,
            shadow: false
        },
        tooltip: {
            headerFormat: '<b>{point.x}</b><br/>',
            pointFormat: '{series.name}<br/>Miles {point.stackTotal}<br/>Total {point.stackTotal}'
        },
        plotOptions: {
            column: {
                stacking: 'normal',
                dataLabels: {
                    enabled: false,
                    color: (Highcharts.theme && Highcharts.theme.dataLabelsColor) || 'white'
                }
            },
            series: {
                pointPadding: 0,
                groupPadding: 0.0
            }
        },
        series: series
    });
};
}());
