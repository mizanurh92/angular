(function() {
    'use strict';

	angular.module('app.dashboard', [])
    .controller("DashboardController", function($scope, $location, $window, localStorageService, $state, $stateParams, DashboardService, $filter, usSpinnerService,DashboardDateService,DashboardDriverService,CountriesService){

    var picker1 = $('#startdate');
    var picker2 = $('#enddate');
    	if(localStorage.token !== null & localStorage.token !== undefined){
    			var t;
                $scope.idletime = function(){
                    $scope.resetTimer();
                };
                
                $scope.resetTimer=function(){
                    clearTimeout(t);
                    t = setTimeout($scope.logout, 5*60000);
                };
                
                $scope.logout=function(){
                    localStorage.token = null;
                    location.href = '#/login';
                };
    		
    var d = new Date();
    var curDay = d.getDate();
    var currMonth = d.getMonth();
    var currYear = d.getFullYear();
    var startDate = new Date(currYear,currMonth,curDay - 15);
    var endDate = new Date(currYear,currMonth, curDay);

    $scope.closebuttonText="Close Driver History";
    $scope.avgSpeedColorClass='red';
    $scope.avgSmoothColorClass='red';
    $scope.avgTimeColorClass='red';
    $scope.fleet_heading = "Showing Fleet Drivers";
    $scope.fleet_id = $stateParams.fleet_id;
    $scope.tableRowExpanded = false;
    $scope.tableRowIndexCurrExpanded = "";
    $scope.tableRowIndexPrevExpanded = "";
    $scope.storeIdExpanded = "";
    $scope.dayDataCollapse = [];
    $scope.isActiveHire = false;
    $scope.totAvgScore = 0;
    $scope.radialSeg =0;
    $scope.topTotal = 0;
    $scope.avgTotal = 0;
    $scope.riskyTotal = 0;
    $scope.totAvgSpeed = 0;
    $scope.avgSpeedAvg = 0; 
    $scope.riskySpeedAvg = 0;
    $scope.updateDials = updateDials;
    $scope.radialTotal = 0;
    $scope.radialAvgSpd = 0;
    $scope.drivers=null;
    $scope.driver=null;
    $scope.selectedType = 'Top Drivers';
    $scope.selectedDiv = 'fleet';
    $scope.overallPerformanceType='top';
    $scope.overallPerformanceCountry='All';
    $scope.overallPerformanceAgeRange='All';

//    $scope.countryList=['All','IRELAND','AUSTRALIA','FRANCE','ARGENTINA','GERMANY','INDIA','HUNGARY','POLAND','CHINA','UNITED STATES','UNITED KINGDOM','JAPAN','ITALY','UNITED ARAB EMIRATES','OMAN','GREECE'];
    $scope.countryList = [];
    
    picker1.datepicker('setDate',startDate);
    picker2.datepicker('setDate',endDate);
    $scope.sdate = picker1.datepicker('getFormattedDate');
    $scope.edate = picker2.datepicker('getFormattedDate');
    
    $scope.fleetEndDate=null;
    $scope.fleetStartDate=null;
    $scope.driverEndDate=null;
    $scope.driverStartDate=null;
    $scope.showoverallHistory = true;
    
    $('#startdate .input-group.date', '#enddate .input-group.date').datepicker({
        todayHighlight: true,
        format: "yyyy-mm-dd",
        autoclose: true
    });

    init($scope.fleet_id );
    } else {
    	localStorage.setPreviousPage = '/#'+$location.url();
    	location.href = '#/login';
    }	      	
    
    function init (fleet_id ) {
        fetchDashboardData(fleet_id);
    }
    
    function mergeTwoObj (arrObj1, arrObj2) {
        var mergeObj = [];
        if(arrObj1.length > 0 && arrObj2.length > 0) {
		var i;
        	for(i=0;i<arrObj2.length;i++){
        		mergeObj.push(arrObj2[i]);
        	}
        	for(i=0;i<arrObj1.length;i++){
        		mergeObj.push(arrObj1[i]);
        	}
// $.each(arrObj1, function (k1, v1) {
// var obj = {};
// obj = angular.extend(obj,v1);
// mergeObj.push(obj);
// });
// $.each(arrObj2, function (k2, v2) {
// var obj = {};
// obj = angular.extend(obj,v2);
// mergeObj.push(obj);
// });

        }
//        if(mergeObj.length > 0) {
//            mergeObj = $filter('ASC')(mergeObj, 'rank_driver', true);
//        }
        return mergeObj;
    }
    function setDot(kind,color){
    	document.getElementById(kind).setAttribute('class','circle-banner '+color);
    }

    function setAllDots(speed,smooth,time){
		setDot("avgSpeedColorDot",speed);
		setDot("avgSmoothColorDot",smooth);
		setDot("avgTimeColorDot",time);
    }
    function silverDots() {
		setDot("avgSpeedColorDot",'silver');
		setDot("avgSmoothColorDot",'silver');
		setDot("avgTimeColorDot",'silver');
    }
    function getTopDriver (fleet_id,offset,updateTable) {
        var type = 'top';
        $scope.selectedType = 'Top Drivers';
        $scope.sdate = picker1.datepicker('getFormattedDate');
        $scope.edate = picker2.datepicker('getFormattedDate');
        $scope.topoffset = offset ? offset : 0;
        $scope.fleet_id = fleet_id ? fleet_id :1;
        $scope.suggestion ="Avoid Harse Breaking.";
        startSpin();
        
        DashboardService.fetchTopDrivers(type, $scope.sdate, $scope.edate, $scope.topoffset, $scope.isActiveHire,$scope.fleet_id).then(function (response) {
		$scope.topTotal = 0;
        	if(response.data.drivers === null || response.data.drivers === undefined) {
                stopSpin();
		$scope.showNoData=true;
                //alert("No data found. Please change date range.")
                return false;
            }
	    else
		$scope.showNoData=false;

            if(typeof $scope.topdrivers !== 'undefined' && typeof $scope.topdrivers.drivers !== 'undefined') {
                var newObj = mergeTwoObj(response.data.drivers, $scope.topdrivers.drivers, 'score');
                $scope.topdrivers.drivers = {};
                $scope.topdrivers.drivers = newObj;
            } else {
                $scope.topdrivers = response.data;
                
            }

            var scores = 0;
            var speed_ave = 0;
            for (var i = 0; i < $scope.topdrivers.drivers.length; i++) {
                $scope.dayDataCollapse[$scope.topdrivers.drivers[i].driver_id] = 'true';
                scores += parseInt($scope.topdrivers.drivers[i].score, 10);
                speed_ave += parseInt($scope.topdrivers.drivers[i].speed_ave, 10);
            }
            $scope.topTotal = $scope.topdrivers.drivers[0].fleet_score;
            $scope.topSpeedAvg = $scope.topdrivers.drivers[0].fleet_speed;
            $scope.radialSegTotal = $scope.topdrivers.drivers[0].full_count;
            $scope.drivers = $scope.topdrivers;
            $scope.updateDials('top');
            setAllDots($scope.topdrivers.drivers[0].speed_color,$scope.topdrivers.drivers[0].score_color,$scope.topdrivers.drivers[0].task_color);
            stopSpin();
        });
    }
    
    function getAvgDriver (fleet_id,offset) {
        var type = 'avg';
        $scope.selectedType = 'Avg Drivers';
        $scope.sdate = picker1.datepicker('getFormattedDate');
        $scope.edate = picker2.datepicker('getFormattedDate');
        $scope.avgoffset = offset ? offset : 0;
        $scope.fleet_id = fleet_id ? fleet_id :1;
        startSpin();
        DashboardService.fetchTopDrivers(type, $scope.sdate, $scope.edate, $scope.avgoffset, $scope.isActiveHire,$scope.fleet_id).then(function (response) {
            $scope.avgTotal = 0;
            if(response.data.drivers === null || response.data.drivers === undefined) {
                stopSpin();
                return false;
            }
            
            if(typeof $scope.avgdrivers !== 'undefined' && typeof $scope.avgdrivers.drivers !== 'undefined') {
                var newObj = mergeTwoObj(response.data.drivers, $scope.avgdrivers.drivers, 'score');
                $scope.avgdrivers.drivers = {};
                $scope.avgdrivers.drivers = angular.copy(newObj);
            } else {
                $scope.avgdrivers = response.data;
            }

            var scores = 0;
            var speed_ave = 0;
            for (var i = 0; i < $scope.avgdrivers.drivers.length; i++) {
                $scope.dayDataCollapse[$scope.avgdrivers.drivers[i].driver_id] = 'true';
                scores += parseInt($scope.avgdrivers.drivers[i].score, 10);
                speed_ave += parseInt($scope.avgdrivers.drivers[i].speed_ave, 10);
            }
            $scope.avgTotal = $scope.avgdrivers.drivers[0].fleet_score;
            $scope.avgSpeedAvg = $scope.avgdrivers.drivers[0].fleet_speed;
            $scope.radialSegTotal = $scope.avgdrivers.drivers[0].full_count;
            $scope.opt = 'top';
            stopSpin();
        });
    }
    
    function startSpin (){
        usSpinnerService.spin('spinner-1');
    }
    
    function stopSpin (){
        usSpinnerService.stop('spinner-1');
    }
    
    $scope.getSpeedColor = function (speed) {
        if(speed >= 0 && speed <= 75 ) return 'success';
        else if(speed >= 76 && speed <= 85 ) return 'warning';
        else return 'danger';
    };
    
    $scope.getTimeonTaskColor = function (speed) {
        if(speed >= 76 ) return 'green';
        else if(speed >= 36 && speed <= 75 ) return 'yellow';
        else if(speed >= 0 && speed <= 35 ) return 'red';
    };
    
    $scope.getSpeedCtrlColor = function (speed) {
        if(speed >= 0 && speed <= 75 ) return 'green';
        else if(speed >= 76 && speed <= 85 ) return 'yellow';
        else return 'red';
    };

    $scope.showOverallPerformance = function(fleet_id){
    	$scope.closebuttonText="Close Overall Performance";
		$scope.fleet_heading = "Showing Overall Performance";
		//$scope.showSearch = true;
		$("#driverSearchFrm").attr("style","visibility:hidden");
		$scope.showfleetDiv = false;
		$scope.showoverallDiv = true;
		$scope.showDriverDiv = false;
		$scope.showFleetTrend = true;
		$scope.selectedDiv = 'overallperformance';
		$scope.overallPerformanceType = $scope.opt;
		$scope.parentmodel.opt = $scope.opt;
		$scope.getOverAllperformance($scope.fleet_id);
    
    };

    $scope.showDriversChart = function(driver_id,st_Date,end_Date){
    	$scope.closebuttonText="Close Driver History";
		//$scope.showSearch = true;
		$("#driverSearchFrm").attr("style","visibility:visible");
		$scope.showfleetDiv = false;
		$scope.showoverallDiv = false;
		$scope.showDriverDiv = true;
		$scope.showFleetTrend = true;
    	if(driver_id===undefined || driver_id===""){
    		//alert("Driverid can not be blank");
			$scope.showTableView();
    	}else{
		//var st_Date=$scope.sdate;
		//var end_Date=$scope.edate;
    		DashboardDriverService.fetchDriverDetails(driver_id,$scope.fleet_id,st_Date,end_Date).then(function (response) {
    		$scope.fleet_heading = "Showing Driver History";
                if(response.data.driver === null || response.data.driver === undefined) {
                    stopSpin();
                    $scope.showNoDriver = true;
                    $scope.showDriverHistory = true;
                    $scope.showFleetTrend = true;
                    $scope.selectedDiv = 'driver';
                    $scope.showoverallHistory = true;
                    return false;
                }
                $scope.driver = response.data.driver;
                $scope.showNoDriver = false;
                $scope.showDriverHistory = true;
                $scope.showFleetTrend = true;
                $scope.showoverallHistory = true;
                $scope.selectedDiv = 'driver';
                updateDates();
                getDriversChart();
                $scope.fromDriverSearch = false;
                stopSpin();
            });
    		
    	}
    };
    
    function getDriversChart(){
    	$('#driver_chart3container').html("");
    	$('#driver_chart4container').html("");
    	window.prepChart3($scope.driver_id,picker1.datepicker('getFormattedDate'),picker2.datepicker('getFormattedDate'),driver_chart3container);
        window.prepChart4($scope.driver_id,picker1.datepicker('getFormattedDate'),picker2.datepicker('getFormattedDate'),driver_chart4container);
    }
    
    function updateDates(){
    	$scope.fromDriverSearch = true;
    	if($scope.driver.startdate!==null && $scope.driver.startdate!==undefined){
    		var earliestDate = new Date($scope.driver.startdate.replace(/-/g, '\/'));
    		$scope.driverStartDate = earliestDate;
    		picker1.datepicker('setDate',$scope.driverStartDate);
    	}
        if($scope.driver.enddate!==null && $scope.driver.enddate!==undefined){
        	var latestDate = new Date($scope.driver.enddate.replace(/-/g, '\/'));
        	$scope.driverEndDate = latestDate;
        	picker2.datepicker('setDate',$scope.driverEndDate);
    	}
    }
    
    $scope.showTableView = function(){
    	$scope.driver_id ="";
    	$scope.selectedDiv = "";
        $scope.overallPerformanceType='top';
        $scope.overallPerformanceCountry='All';
        $scope.overallPerformanceAgeRange='All';
        $scope.parentmodel.country='All';
        $scope.parentmodel.opt='top';
        $scope.parentmodel.ageRange='All';
    	$("#driverSearchFrm").attr("style","visibility:visible");
    	$("#driver_chart3container").innerHTML = "";
    	$("#driver_chart4container").innerHTML = "";
    	$scope.fleet_heading = "Showing Fleet Drivers";
		$scope.showSearch = true;
		$scope.showfleetDiv = true;
		$scope.showoverallDiv = false;
		$scope.showDriverDiv = false;
		$scope.showFleetTrend = false;
        if($scope.fleetEndDate!==null && $scope.fleetEndDate!==undefined)
        	picker2.datepicker('setDate',$scope.fleetEndDate);
        else
        	picker2.datepicker('setDate',endDate);
        if($scope.fleetStartDate!==null && $scope.fleetStartDate!==undefined)
        	picker1.datepicker('setDate',$scope.fleetStartDate);
        else
        	picker1.datepicker('setDate',startDate);
        $scope.selectedDiv = 'fleet';
        $scope.driverEndDate = null;
        $scope.driverStartDate = null;
        resetDashboard();
    };
    
    function getSuggestion (driver){
    	var suggestion = "";
    	if(driver.avg_score<83){
    		suggestion = "Avoid Harse Breaking. ";
    	}if(driver.avg_speed > 75){
    		suggestion += "Avoid Speedy Drives. ";
    	}if(driver.avg_task > 75){
    		suggestion += "Avoid Long Drives.";
    	}
    	return suggestion;
    }
    
    function getRiskyDriver (fleet_id,offset) {
        var type = 'risky';
        $scope.selectedType = 'Risky Drivers';
        $scope.sdate = picker1.datepicker('getFormattedDate');
        $scope.edate = picker2.datepicker('getFormattedDate');
        $scope.riskyoffset = offset ? offset : 0;
        $scope.fleet_id = fleet_id ? fleet_id :1;
        startSpin();
        // $scope.suggestion ="Avoid Speedy drive";
        DashboardService.fetchTopDrivers(type, $scope.sdate, $scope.edate, $scope.riskyoffset, $scope.isActiveHire,$scope.fleet_id).then(function (response) {
            $scope.riskyTotal = 0;
            if(response.data.drivers === null) {
                stopSpin();
                return false;
            }
            if(typeof $scope.riskydrivers !== 'undefined' && typeof $scope.riskydrivers.drivers !== 'undefined') {
                var newObj = mergeTwoObj(response.data.drivers, $scope.riskydrivers.drivers, 'score');
                $scope.riskydrivers.drivers = {};
                $scope.riskydrivers.drivers = angular.copy(newObj);
            } else {
                $scope.riskydrivers = response.data;
                
            }
            var scores = 0;
            var speed_ave = 0;
            for (var i = 0; i < $scope.riskydrivers.drivers.length; i++) {
                $scope.dayDataCollapse[$scope.riskydrivers.drivers[i].driver_id] = 'true';
                scores += parseInt($scope.riskydrivers.drivers[i].score, 10);
                speed_ave += parseInt($scope.riskydrivers.drivers[i].speed_ave, 10);
            }
            $scope.riskyTotal = $scope.riskydrivers.drivers[0].fleet_score;
            $scope.riskySpeedAvg = $scope.riskydrivers.drivers[0].fleet_speed;
            $scope.radialSegTotal = $scope.riskydrivers.drivers[0].full_count;
            stopSpin();
        });
    }

    picker1.datepicker().on('changeDate', function () {
            picker1.datepicker('hide');
            getDataForDateChange();
    });
    picker2.datepicker().on('changeDate', function () {
            picker2.datepicker('hide');
            getDataForDateChange();

    });

    function getDataForDateChange(){
        if($scope.selectedDiv=='fleet'){
            resetDashboard();
        }else if($scope.selectedDiv=='driver'){
        	fetchDashboardData($scope.fleet_id);
        	if($scope.fromDriverSearch===false){
                getDriversChart();
                $scope.fromDriverSearch = false;
        	}
        }else if($scope.selectedDiv === 'overallperformance'){
        	$scope.getOverAllperformance($scope.fleet_id);
        }
    }
    
    $scope.getOverAllperformance = function(fleet_id){
    	$("#spinner").show();
    	$('#overallperformance_chart4container').html("");
    	$('#overallperformance_chart3container').html("");
    	startSpin();
    	if($scope.countryList.length===0){
    		CountriesService.fetchCountries().then(function (response) {
    			if(response.data.countires === null) {
                    stopSpin();
                    return false;
                }
    			$scope.countryList = response.data.countires;
    			$scope.countryList.push({name:"All"});
    			window.prepOverAllChartPerDay(1,picker1.datepicker('getFormattedDate'),picker2.datepicker('getFormattedDate'),overallperformance_chart3container,usSpinnerService,$scope.overallPerformanceType,$scope.overallPerformanceCountry,$scope.overallPerformanceAgeRange);
    	        window.prepOverAllChart(1,picker1.datepicker('getFormattedDate'),picker2.datepicker('getFormattedDate'),overallperformance_chart4container,usSpinnerService,$scope.overallPerformanceType,$scope.overallPerformanceCountry,$scope.overallPerformanceAgeRange);
    			stopSpin();
    		});
    		
    	}else{
    		window.prepOverAllChartPerDay(1,picker1.datepicker('getFormattedDate'),picker2.datepicker('getFormattedDate'),overallperformance_chart3container,usSpinnerService,$scope.overallPerformanceType,$scope.overallPerformanceCountry,$scope.overallPerformanceAgeRange);
	        window.prepOverAllChart(1,picker1.datepicker('getFormattedDate'),picker2.datepicker('getFormattedDate'),overallperformance_chart4container,usSpinnerService,$scope.overallPerformanceType,$scope.overallPerformanceCountry,$scope.overallPerformanceAgeRange);
stopSpin();
    	}
    	
    };

    $scope.fetchFewMore = function () {
	var temp=null;
        if($scope.opt =='top') {
            $scope.topoffset =parseInt($scope.topoffset) +10;
            getTopDriver($scope.fleet_id,$scope.topoffset);
            $scope.drivers = $scope.topdrivers ;
            temp = $scope.topdrivers;
            setTimeout(function() {
            	setAllDots(temp.drivers[0].speed_color,temp.drivers[0].score_color,temp.drivers[0].task_color);
            }, 1000);
        } else if ($scope.opt == 'avg') {
            $scope.avgoffset = parseInt($scope.avgoffset) +10;
            getAvgDriver($scope.fleet_id,$scope.avgoffset);
            $scope.drivers = $scope.avgdrivers ;
            temp = $scope.avgdrivers;
            setTimeout(function() {
            	setAllDots(temp.drivers[0].speed_color,temp.drivers[0].score_color,temp.drivers[0].task_color);
            }, 1000);
        } else if ($scope.opt == 'risky'){
            $scope.riskyoffset =parseInt($scope.riskyoffset) + 10;
            getRiskyDriver($scope.fleet_id,$scope.riskyoffset);
            $scope.drivers = $scope.riskydrivers ;
            temp = $scope.riskydrivers;
            setTimeout(function() {
            	setAllDots(temp.drivers[0].speed_color,temp.drivers[0].score_color,temp.drivers[0].task_color);
            }, 1000);
        }
        temp = null;
    };
    function resetDashboard () {
        $scope.topdrivers = {};
        $scope.avgdrivers = {};
        $scope.riskydrivers = {};
        $scope.drivers = {};
        $scope.radialTotal =0;
        $scope.radialAvgSpd = 0;
        $scope.radialSeg =0;
        fetchDashboardData($scope.fleet_id);
    }
    
    $scope.updateDrivers= function (type){
    	if(type=='top'){
    		$scope.selectedType = 'Top Drivers';
    		$scope.suggestion ="Avoid Harse Breaking.";
    		$scope.drivers = $scope.topdrivers;
    		$scope.radialSeg = $scope.topdrivers.drivers[0].fleet_segment;
    	}else if(type=='avg'){
    		$scope.selectedType = 'Avg Drivers';
    		$scope.suggestion ="Avoid Long rides, Avoid Speedy drives.";
    		$scope.drivers = $scope.avgdrivers;
    		$scope.radialSeg = $scope.avgdrivers.drivers[0].fleet_segment;
    	}else if(type=='risky'){
    		$scope.selectedType = 'Risky Drivers';
    		$scope.suggestion ="Avoid Speedy drives.";
    		$scope.drivers = $scope.riskydrivers;
    		$scope.radialSeg = $scope.riskydrivers.drivers[0].fleet_segment;
    	}
    	setAllDots($scope.drivers.drivers[0].speed_color,$scope.drivers.drivers[0].score_color,$scope.drivers.drivers[0].task_color);
   		updateDials(type);

    };
    
    $scope.updateOverAllPerformance= function (overallPerformanceObj){
    	if(overallPerformanceObj.opt=='top'){
    		$scope.selectedType = 'Top Drivers';
    		$scope.suggestion ="Avoid Harse Breaking.";
    		$scope.drivers = $scope.topdrivers;
    		$scope.radialSeg = $scope.topdrivers.drivers[0].fleet_segment;
    	}else if(overallPerformanceObj.opt=='avg'){
    		$scope.selectedType = 'Avg Drivers';
    		$scope.suggestion ="Avoid Long rides, Avoid Speedy drives.";
    		$scope.drivers = $scope.avgdrivers;
    		$scope.radialSeg = $scope.avgdrivers.drivers[0].fleet_segment;
    	}else if(overallPerformanceObj.opt=='risky'){
    		$scope.selectedType = 'Risky Drivers';
    		$scope.suggestion ="Avoid Speedy drives.";
    		$scope.drivers = $scope.riskydrivers;
    		$scope.radialSeg = $scope.riskydrivers.drivers[0].fleet_segment;
    	}
    	setAllDots($scope.drivers.drivers[0].speed_color,$scope.drivers.drivers[0].score_color,$scope.drivers.drivers[0].task_color);
   		updateDials(overallPerformanceObj.opt);
   		$scope.overallPerformanceType=overallPerformanceObj.opt;
   	    $scope.overallPerformanceCountry=overallPerformanceObj.country;
   	    $scope.getAgeRange(overallPerformanceObj.ageRange);
    	$scope.getOverAllperformance($scope.fleet_id);
    };
    
    $scope.getAgeRange= function (ageRange){
    	if(ageRange==="Age 20 to 30"){
    		$scope.overallPerformanceAgeRange=" between 20 and 30";
    	}else if(ageRange==="Age 30 to 40"){
    		$scope.overallPerformanceAgeRange=" between 30 and 40";
    	}else if(ageRange==="Age 40 to 50"){
    		$scope.overallPerformanceAgeRange=" between 40 and 50";
    	}else if(ageRange==="Age 50+"){
    		$scope.overallPerformanceAgeRange=" > 50";
    	}else{
    		$scope.overallPerformanceAgeRange="All";
    	}
    };
    
    $scope.showSuggestion = function(driver){
    	$scope.suggestion = getSuggestion(driver);
    };
    $scope.chkActive = function () {
        resetDashboard();        
    };
    $scope.redirectLogin = function (argument) {
        localStorageService.set('name','manivannan');
        $state.go('dashboard');
    };
    $scope.funLogout = function (argument) {
        localStorage.clear();
        $state.go('login');
    };
    $scope.showColormap = function(fleet_id){
    	window.location = "#/colormap/"+fleet_id;
    };
    
    function updateDials (text) {
        if(text === 'top') {
                $scope.radialTotal  = $scope.topTotal?$scope.topdrivers.drivers[0].fleet_score:0;
                $scope.radialAvgSpd = $scope.topTotal?$scope.topdrivers.drivers[0].fleet_speed:0;
                $scope.radialSeg    = $scope.topTotal?$scope.topdrivers.drivers[0].fleet_segment:0;
        } else if (text === 'avg') {
                $scope.radialTotal  = $scope.radialTotal?$scope.avgdrivers.drivers[0].fleet_score:0;
                $scope.radialAvgSpd = $scope.radialTotal?$scope.avgdrivers.drivers[0].fleet_speed:0;
                $scope.radialSeg    = $scope.radialTotal?$scope.avgdrivers.drivers[0].fleet_segment:0;
        } else if (text === 'risky'){
                $scope.radialTotal  = $scope.riskyTotal?$scope.riskydrivers.drivers[0].fleet_score:0;
                $scope.radialAvgSpd = $scope.riskyTotal?$scope.riskydrivers.drivers[0].fleet_speed:0;
                $scope.radialSeg    = $scope.riskyTotal?$scope.riskydrivers.drivers[0].fleet_segment:0;
        } 
    }

    function getAvgScore () {
        if($scope.topTotal && $scope.avgTotal && $scope.riskyTotal) {
            $scope.updateDials('top');
        }
    }
    $scope.$watch(function () {
        return $scope.topTotal;
    }, function (newValue) {
        if(newValue) {
            getAvgScore();
        }
    });
    $scope.$watch(function () {
        return $scope.avgTotal;
    }, function (newValue) {
        if(newValue) {
            getAvgScore();
        }
    });
    $scope.$watch(function () {
        return $scope.riskyTotal;
    }, function (newValue) {
        if(newValue) {
            getAvgScore();
        }
    });
    
    $scope.setEarliestDate = function(){
    	var type = "earliest";
    		DashboardDateService.fetchDate(type,$scope.fleet_id).then(function (response) {
            if(response.data.drivers === null) {
                stopSpin();
                return false;
            }
            var earliestDate = new Date(response.data.date.replace(/-/g, '\/'));
            $scope.fleetStartDate = earliestDate;
            picker1.datepicker('setDate',earliestDate);
    	});
    };
    
    $scope.showSearchDiv = function(){
    	$scope.selectedDiv = 'driver';
    };
    
    $scope.showFleetDiv = function(){
    	$scope.selectedDiv = 'fleet';
    };
    
    $scope.setLastestDate = function(){
    	var type = "latest";
    		DashboardDateService.fetchDate(type,$scope.fleet_id).then(function (response) {
            if(response.data.drivers === null) {
//                stopSpin();
                return false;
            }
            var latestDate = new Date(response.data.date.replace(/-/g, '\/'));
            $scope.fleetEndDate = latestDate;
            picker2.datepicker('setDate',latestDate);
            
    	});
    };
    
    function fetchDashboardData (fleet_id) {
        $scope.topTotal = 0 ;
        $scope.avgTotal = 0 ;
        $scope.riskyTotal = 0;
        silverDots();
        getAvgDriver(fleet_id,0);
        getRiskyDriver(fleet_id,0);
        setTimeout(function() {
        	getTopDriver(fleet_id,0);
    	}, 1000);
        
    }
    
    $scope.selectTableRow = function (index, storeId,driver) {
        if ($scope.dayDataCollapse === 'undefined') {
            $scope.dayDataCollapse = $scope.dayDataCollapseFn();
        } else {

            if ($scope.tableRowExpanded === false && $scope.tableRowIndexCurrExpanded === "" && $scope.storeIdExpanded === "") {
                $scope.tableRowIndexPrevExpanded = "";
                $scope.tableRowExpanded = true;
                $scope.tableRowIndexCurrExpanded = storeId;
                $scope.storeIdExpanded = storeId;
                $scope.dayDataCollapse[storeId] = false;
                window.prepChart3(driver.driver_id,picker1.datepicker('getFormattedDate'),picker2.datepicker('getFormattedDate'),driver.driver_id+'-chart3container');
                window.prepChart4(driver.driver_id,picker1.datepicker('getFormattedDate'),picker2.datepicker('getFormattedDate'),driver.driver_id+'-chart4container');
            } else if ($scope.tableRowExpanded === true) {
                if ($scope.tableRowIndexCurrExpanded === storeId && $scope.storeIdExpanded === storeId) {
                    $scope.tableRowExpanded = false;
                    $scope.tableRowIndexCurrExpanded = "";
                    $scope.storeIdExpanded = "";
                    $scope.dayDataCollapse[storeId] = true;
                } else {
                    $scope.tableRowIndexPrevExpanded = $scope.tableRowIndexCurrExpanded;
                    $scope.tableRowIndexCurrExpanded = storeId;
                    $scope.storeIdExpanded = storeId;
                    $scope.dayDataCollapse[$scope.tableRowIndexPrevExpanded] = true;
                    $scope.dayDataCollapse[$scope.tableRowIndexCurrExpanded] = false;
                    window.prepChart3(driver.driver_id,picker1.datepicker('getFormattedDate'),picker2.datepicker('getFormattedDate'),driver.driver_id+'-chart3container');
                    window.prepChart4(driver.driver_id,picker1.datepicker('getFormattedDate'),picker2.datepicker('getFormattedDate'),driver.driver_id+'-chart4container');
                }
            }
        }
        $scope.suggestion = getSuggestion(driver);
    };	  	
    });

})();


