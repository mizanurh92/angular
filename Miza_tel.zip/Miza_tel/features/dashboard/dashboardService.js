(function() {
    'use strict';

	// HomeService for storing data in HomeView

	angular.module('app.dashboardservice', [])
	.factory('DashboardService', function ($q, $http) {
		
		return{	
			
			fetchTopDrivers: function (type, sdate, edate, offset, isActive,fleet_id) {
					
				var deferred = $q.defer();
			
				// AJAX request
				$http({
					method: 'GET',
					url: '/api/dashboardlist',
					params: {
						driver_type: type,
						sdate: sdate,
						edate: edate,
						offset: offset,
						isActive: isActive,
						fleet_id:fleet_id
					}

				}).then(function (response) {
					// success
					// get Results object from GET response
					deferred.resolve(response);

				}, function (reason) {
						// failure
						deferred.reject(reason);
				});

				return deferred.promise;
			},
			
		};
		
	});

})();