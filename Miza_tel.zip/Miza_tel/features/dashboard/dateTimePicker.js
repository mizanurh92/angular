angular.module('app.dateTimePicker', [])
    .directive("dateTimePicker", function () {
        return {
            restrict: "A",
            link: function ($scope, element, attrs) {

                angular.element( element ).datepicker({
                    todayHighlight: true
                });

                //angular.element(element).datepicker('setDatesDisabled', datepickerDatesDisabled);

                angular.element( element).datepicker().children('input').keydown(function(e){
                    e.preventDefault();
                });

            }
        };
    });