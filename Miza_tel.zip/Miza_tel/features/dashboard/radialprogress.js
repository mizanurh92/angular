///**
// * Directive, which creates D3.js based donut chart, with the value in the middle of it
// *
// * Parameters:
// * value      - The value, which needs to be represented | required
// * maxvalue   - The maximum value of the interval | optional, default value 100 -> value acts like percentage
// * color      - Color of the first value | optional, default color is red. (#FF0000)
// * background - Color of the second value | optional, default color is black. (#000000)
// * textcolor  - Color of the value title in middle | optional, by default it has the color of the first value
// *
// * Example:
// * <radialprogress data-value="60" data-maxvalue="100" data-color="#FF0000" data-background="#00FF00" data-textcolor="#FF0000"></radialprogress>
// */

angular.module('app.radialprogress', [])
    .directive('radialprogress', function($parse, $window){
        return {
            restrict: 'EA',
            scope: {
                value: '=',
                maxvalue: '=',
		id: '='
            },
            link: function(scope, element, attrs) {
		
                var dataset = [parseInt(scope.value)];
                console.log(dataset);
				scope.$watch(function(){
					return scope.value;
					},
				function(newvalue,oldvalue){
				        var changeset = [parseInt(scope.value)];
				        animate(changeset);
		            	},true);

				function getColorCode (data, color) {
				            
				        if(attrs.type === 'flt_seg') {
				            ringcolor = '#8FC731';
				        } else if(attrs.type === 'avg_speed') {
				             if(data >= 0 && data <= 75) ringcolor = '#8FC731';
				            else if(data >= 76 && data <= 85 ) ringcolor = '#ffdf00';
				            else ringcolor = '#cc3300';
				        } else {
				             if(data >= 76) ringcolor = '#8FC731';
				            else if(data <= 75 && data >= 36 ) ringcolor = '#ffdf00';
				            else ringcolor = '#cc3300';
				        }
				        return ringcolor;
				}
                function animate(values) {
                	
        	    d3.selectAll('#'+element[0].id+' svg').remove();
        	    var endPercent =0;
                    if (!values) {
                        endPercent = 0;
                    }
                    if (values === 0) {
                        endPercent = 0.00;
                    } else {
                        endPercent = (values / 100);

                    }
                    
                    var color = getColorCode(values,attrs.color);
                    

                    var radius = 72;
                    var border = 6;
                    var padding = 10;
                    var startPercent = 0;


                    var twoPi = Math.PI * 2;
                    var formatPercent = d3.format('.0%');
                    var boxSize = (radius + padding) * 2;
                    var count = Math.round((endPercent - startPercent) / 0.02);
                    if(count>50){
                    	count =50;
                    }
                    var step = endPercent < startPercent ? -0.02 : 0.02;
                    var arc = d3.svg.arc().startAngle(0).innerRadius(radius).outerRadius(radius - border);

                    var parent = d3.select(element[0]);

                    var svg = parent.append('svg')
                        .attr('width', boxSize)
                        .attr('height', boxSize);
                    var defs = svg.append('defs');
                    var filter = defs.append('filter')
                        .attr('id', 'blur');
                    filter.append('feGaussianBlur')
                        .attr('in', 'SourceGraphic')
                        .attr('stdDeviation', '7');


                    var g = svg.append('g')
                        .attr('transform', 'translate(' + boxSize / 2 + ',' + boxSize / 2 + ')');

                    var meter = g.append('g')
                        .attr('class', 'progress-meter');

                    meter.append('path')
                        .attr('class', 'background')
                        .attr('fill', '#3b3b3b')
                        .attr('fill-opacity', 0.5)
                        .attr('d', arc.endAngle(twoPi));

                    var foreground = meter.append('path')
                        .attr('class', 'foreground')
                        .attr('fill', color)
                        .attr('fill-opacity', 1)
                        .attr('stroke', color)
                        .attr('stroke-width', 6)
                        .attr('stroke-opacity', 1);

                    var front = meter.append('path')
                        .attr('class', 'foreground')
                        .attr('fill', color)
                        .attr('fill-opacity', 1);

                    var numberText = meter.append('text')
                        .attr('fill', '#fff')
                        .attr('text-anchor', 'middle')
                        .attr('dy', '.35em');
                    var progress = startPercent;

                    function updateProgress(progress) {
                        foreground.attr('d', arc.endAngle(twoPi * progress));
                        front.attr('d', arc.endAngle(twoPi * progress));
                        if(count===0){
                        	progress = 1;
                        }
                        var val=values[0]*progress;
                        numberText.text(Math.floor(val));
                    }

                    (function loops() {

                        updateProgress(progress);

                        count--;
                        progress += step;
                        if (count >= 0) {
                            setTimeout(loops, 5);
                        }

                    })();
                }




            }
        };
    });
