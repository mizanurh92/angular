(function() {
    'use strict';

	// HomeService for storing data in HomeView

	angular.module('app.dashboarddriverservice', [])
	.factory('DashboardDriverService', function ($q, $http) {
		
		return{	
			
			fetchDriverDetails: function (driver_id,fleet_id,startDate,endDate) {
					
				var deferred = $q.defer();
			
				// AJAX request
				$http({
					method: 'GET',
					url: '/api/getDriverDetails',
					params: {
						driver_id: driver_id,
						fleet_id:fleet_id,
						sdate:startDate,
						edate:endDate
					}

				}).then(function (response) {
					// success
					// get Results object from GET response
					deferred.resolve(response);

				}, function (reason) {
						// failure
						deferred.reject(reason);
				});

				return deferred.promise;
			},
			
		};
		
	});

})();