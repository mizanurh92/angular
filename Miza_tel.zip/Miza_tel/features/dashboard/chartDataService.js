(function(){
"use strict";

window.getDataForDriver = function(driverId, dtFrom, dtTo, cb) {
    $.getJSON( "/api/userChartData?driverid=" + driverId + '&dtFrom=' + dtFrom + '&dtTo=' + dtTo,
        function( data ) {
            console.log(data);
            if(cb){
                cb(data);
            }
        }
    );
};
window.getWeightedScorePerDay = function(driverId, dtFrom, dtTo, cb) {
    $.getJSON( "/api/weightedScorePerDay?driverid=" + driverId + '&dtFrom=' + dtFrom + '&dtTo=' + dtTo,
        function( data ) {
            console.log(data);
            if(cb){
                cb(data);
            }
        }
    );
};

window.getOverAllPerformancePerDay = function(fleetId, dtFrom, dtTo, type,country,ageRange,cb) {
    $.getJSON( "/api/performance?fleet_id=" + fleetId + '&dtFrom=' + dtFrom + '&dtTo=' + dtTo+'&type='+type+'&country='+country+'&ageRange='+ageRange,
        function( data ) {
            console.log(data);
            if(cb){
                cb(data);
            }
        }
    );
};

window.getPerformanceCategories = function(fleetId, individual,cb) {
    $.getJSON( "/api/performanceCategories?fleet_id=" + fleetId + '&individual='+ (individual?'true':'false'),
        function( data ) {
            console.log(data);
            if(cb){
                cb(data);
            }
        }
    );
};


window.getOverAllPerformance = function(fleetId, dtFrom, dtTo,type,country,ageRange, cb) {
    $.getJSON( "/api/performancePerDay?fleet_id=" + fleetId + '&dtFrom=' + dtFrom + '&dtTo=' + dtTo+"&type="+type+'&country='+country+'&ageRange='+ageRange,
        function( data ) {
            console.log(data);
            if(cb){
                cb(data);
            }
        }
    );
};
}());
