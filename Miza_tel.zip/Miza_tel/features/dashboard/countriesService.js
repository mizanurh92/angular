(function() {
    'use strict';

	// HomeService for storing data in HomeView

	angular.module('app.countriesservice', [])
	.factory('CountriesService', function ($q, $http) {
		
		return{	
			
			fetchCountries: function (type, fleet_id) {
					
				var deferred = $q.defer();
			
				// AJAX request
				$http({
					method: 'GET',
					url: '/api/getCountriesList',
					params: {
					}

				}).then(function (response) {
					// success
					// get Results object from GET response
					deferred.resolve(response);

				}, function (reason) {
						// failure
						deferred.reject(reason);
				});

				return deferred.promise;
			},
			
		};
		
	});

})();