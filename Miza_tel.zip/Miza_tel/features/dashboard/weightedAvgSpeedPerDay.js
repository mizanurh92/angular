(function () {
"use strict";

window.prepChart3 = function(driver_id, dtFrom, dtTo,divId){
    if(dtFrom === "") dtFrom = '2016-11-01';
    if(dtTo === "") dtTo = '2017-12-31';
    window.getDataForDriver(driver_id, dtFrom, dtTo, function(data){
        expose_period(driver_id, data,divId);
    });
};

var expose_period = function(driver_id, data,divId) {

    data = data.json_agg;

    if(data === null) {
        console.log('prepChart3 -- no data for this driver and period');
        return false;
    }

    var dateRange = data.map( function(item) {return item.date ;} );
    var dataSeries = [];

    dataSeries.push({
        showInLegend: true,
        name: 'Tot. Distance',
        color: "red",
        data: data.map( function(item){return item.total_distance ;} )} );

    dataSeries.push({
        showInLegend: true,
        name: 'Avg. Speed',
        color: "blue",
        data: data.map( function(item){return item.average_speed ;} )} );

    renderChart(driver_id,divId,dateRange,dataSeries);
};

var renderChart = function(driverId,divId,chart_days,series) {

    Highcharts.chart(divId, {
         title: {
            text: 'Daily Mileage and Avg. Speed'
        },
        xAxis: {
            categories: chart_days
        },
        yAxis: {
            title: {
                text: null
            },
            plotLines: [{
                value: 0,
                width: 1,
                color: '#808080'
            }]
        },
        legend: {
            backgroundColor: (Highcharts.theme && Highcharts.theme.background2) || 'white',
            borderColor: '#CCC',
            //borderWidth: 1,
            shadow: false
        },
        tooltip: {
            headerFormat: '<b>{point.x}</b><br/>',
            pointFormat: '{series.name}: {point.y}'
        },
        plotOptions: {
            column: {
                stacking: 'normal',
                dataLabels: {
                    enabled: true,
                    color: (Highcharts.theme && Highcharts.theme.dataLabelsColor) || 'white'
                }
            },
            series: {
                pointPadding: 0,
                groupPadding: 0.0
            }
        },
        series: series
    });
};
}());
