(function () {
// TODO: fleet_id
"use strict";
window.getAxes=function(fleet_id,individual,dataLookup,render){
    window.getPerformanceCategories(fleet_id,individual,function(data)
	{
		populateAxes(data,dataLookup,render);
	});
};

var populateAxes=function(data,dataLookup,render)
{
    var dataSeries = [];
    data.json_agg.map(function(curBlock)
	{
		dataSeries.push({
        		name: curBlock.range,
        		color: curBlock.color,
        		data: dataLookup.series(curBlock.rating)
		});
	});
	render(dataSeries);
};

window.prepChart4 = function(driverId, dtFrom, dtTo,divId){
    if(dtFrom === "") dtFrom = '2016-11-01';
    if(dtTo === "") dtTo = '2017-12-31';
    window.getWeightedScorePerDay(driverId, dtFrom, dtTo, function(data) {
        expose_period4(driverId, data,divId,new Date(dtFrom),new Date(dtTo));
    });
};

// Needs to iterate each date between start and end dates
var expose_period4 = function(driver_id, data,divId,dtFrom,dtTo) {

    data = data.json_agg;

    if(data === null) {
        console.log('prepChart4 -- no data for this driver and period');
        return false;
    }

    var lastDate ='';
    var dateRange = [];
    var dataLookup = [];
    // coalesce into unique dates
    data.map( function(curItem) { 
  		if(lastDate!=curItem.date)
		dateRange.push(curItem.date);
		lastDate=curItem.date;
		});
    // Get a data Lookup for each date series value
    dateRange.map( function(dateString){
		// Intialize first level
		dataLookup[dateString]=[];
		// Initialize each rating mileage
		for(var rating = 1; rating<=5; rating++)
			dataLookup[dateString][rating]=0.0;});
    // Set all the actual values here all at once in one pass
    data.map(function (curItem){
		dataLookup[curItem.date][curItem.rating]=curItem.total_distance;
		});

    //window.chart_days = data.map( (item) => {return item.date} );
    // We need a value for each date even if it is zero
    dataLookup.series = function (rating){
		return dateRange.map( function(curDate) {
		return dataLookup[curDate][rating];});
	};

    var render=function(dataSeries){renderChart4(driver_id,divId,dateRange,dataSeries);};
    window.getAxes(1,true,dataLookup,render);

};


var renderChart4 = function(driverId,divId,chart_days,series) {

    Highcharts.chart(divId, {
        chart: {
            type: 'column'
        },
        title: {
            text: 'Daily Mileage by Avg. Score'
        },
        xAxis: {
            categories: chart_days
        },
        yAxis: {
            title: {
                text: null
            },
            stackLabels: {
                enabled: false,
                style: {
                    fontWeight: 'bold',
                    color: (Highcharts.theme && Highcharts.theme.textColor) || 'gray'
                }
            }
        },
        legend: {
            backgroundColor: (Highcharts.theme && Highcharts.theme.background2) || 'white',
            borderColor: '#CCC',
            //borderWidth: 1,
            shadow: false
        },
        tooltip: {
            headerFormat: '<b>{point.x}</b><br/>',
            pointFormat: '{series.name}<br/>Miles {point.y}<br/>Total {point.stackTotal}'
        },
        plotOptions: {
            column: {
                stacking: 'normal',
                dataLabels: {
                    enabled: false,
                    color: (Highcharts.theme && Highcharts.theme.dataLabelsColor) || 'white'
                }
            },
            series: {
                pointPadding: 0,
                groupPadding: 0.0
            }
        },
        series: series
    });
};
}());
