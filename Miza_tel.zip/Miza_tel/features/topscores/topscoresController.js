(function() {
    'use strict';

	angular.module('app.topscores', [])
	.controller("TopscoresController",function($scope, $location, TopscoresService, $window, HomeService){
    	
    	$scope.TopscoresService = TopscoresService;      	
      	
      	// load my daily scores rank via AJAX
      	TopscoresService.retrieveMyDaily(HomeService.userEmail).then(function (response) {
      		TopscoresService.myScores.daily = response.data;	
      	});
      	
      	// load my alltime scores rank via AJAX
      	TopscoresService.retrieveMyAlltime(HomeService.userEmail).then(function (response) {
      		TopscoresService.myScores.alltime = response.data;	
      	});
      	
      	/*
      	// load my weekly scores rank via AJAX
      	TopscoresService.retrieveMyWeekly(HomeService.userEmail).then(function (response) {
      		TopscoresService.myScores.weekly = response.data;	
      	});
      	*/
      	
      	// load my biweekly scores rank via AJAX
      	TopscoresService.retrieveMyBiWeekly(HomeService.userEmail).then(function (response) {
      		TopscoresService.myScores.biweekly = response.data;	
      	});
      	
      	// load alltime scores via AJAX
      	TopscoresService.retrieveAlltimeScores().then(function (response) {
      		TopscoresService.alltimeScores = response.data;	
      	});	      	
      	
      	// load daily scores via AJAX
      	TopscoresService.retrieveDailyScores().then(function (response) {
      		TopscoresService.dailyScores = response.data;	
      	});
      	
      	/*
      	// load weekly scores via AJAX
      	TopscoresService.retrieveWeeklyScores().then(function (response) {
      		TopscoresService.weeklyScores = response.data;	
      	});
      	*/
      	
      	// load biweekly scores via AJAX
      	TopscoresService.retrieveBiWeeklyScores().then(function (response) {
      		TopscoresService.biweeklyScores = response.data;	
      	});
      	
        // set the appropriate MY daily,weekly,biweekly, and alltime scores
		$scope.getMyScores = function (type) {
			var scores;
			if(type === 'daily'){
				scores = TopscoresService.myScores.daily;
			}
			else if(type === 'alltime'){
				scores = TopscoresService.myScores.alltime;
			}
			else if(type === 'weekly'){
				scores = TopscoresService.myScores.weekly;
			}
			else if(type === 'biweekly'){
				scores = TopscoresService.myScores.biweekly;
			}
			return scores;	
		};
		
		// set the appropriate top ten daily,weekly,alltime scores
		$scope.getScores = function (type) {
			var scores;
			if(type==='daily'){
				scores = TopscoresService.dailyScores.daily;
			}
			else if(type === 'alltime'){
				scores = TopscoresService.alltimeScores.alltime;
			}
			else if(type === 'weekly'){
				scores = TopscoresService.weeklyScores.weekly;
			}
			else if(type === 'biweekly'){
				scores = TopscoresService.biweeklyScores.biweekly;
			}
			return scores;	
		};	      	
      		      	
    });

})();