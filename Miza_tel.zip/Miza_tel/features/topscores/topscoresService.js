(function() {
    'use strict';

	// HomeService for storing data in HomeView

	angular.module('app.topscores')
	.factory('TopscoresService', function ($q, $http) {
		
		return{	
			
			"myScores": {
				"daily": {},
				"alltime": {},
				"weekly": {},
				"biweekly": {}
			},
			"dailyScores":"{}",
			"alltimeScores":"{}",
			"weeklyScores":"{}",
			"biweeklyScores":"{}",
						
			retrieveMyDaily: function (email) {
					
				var deferred = $q.defer();
			
				// AJAX request
				$http({
					method: 'GET',
					url: '/api/renter_rank',
					params: {
						duration_type: "daily",
						email: email
					}

				}).then(function (response) {
					// success
					// get Results object from GET response
					deferred.resolve(response);

				}, function (reason) {
						// failure
						deferred.reject(reason);
				});

				return deferred.promise;
			},
			
			retrieveMyWeekly: function (email) {
					
				var deferred = $q.defer();
			
				// AJAX request
				$http({
					method: 'GET',
					url: '/api/renter_rank',
					params: {
						duration_type: "weekly",
						email: email
					}

				}).then(function (response) {
					// success
					// get Results object from GET response
					deferred.resolve(response);

				}, function (reason) {
						// failure
						deferred.reject(reason);
				});

				return deferred.promise;
			},
			
			retrieveMyBiWeekly: function (email) {
					
				var deferred = $q.defer();
			
				// AJAX request
				$http({
					method: 'GET',
					url: '/api/renter_rank',
					params: {
						duration_type: "biweekly",
						email: email
					}

				}).then(function (response) {
					// success
					// get Results object from GET response
					deferred.resolve(response);

				}, function (reason) {
						// failure
						deferred.reject(reason);
				});

				return deferred.promise;
			},
			
			retrieveMyAlltime: function (email) {
					
				var deferred = $q.defer();
			
				// AJAX request
				$http({
					method: 'GET',
					url: '/api/renter_rank',
					params: {
						duration_type: "alltime",
						email: email
					}

				}).then(function (response) {
					// success
					// get Results object from GET response
					deferred.resolve(response);

				}, function (reason) {
						// failure
						deferred.reject(reason);
				});

				return deferred.promise;
			},


			retrieveAlltimeScores: function () {
					
				var deferred = $q.defer();
			
				// AJAX request
				$http({
					method: 'GET',
					//url: 'assets/data/alltime.json',
					url: '/api/topten',
					params: {
						duration_type: "alltime"
					}

				}).then(function (response) {
					// success
					// get Results object from GET response
					
					deferred.resolve(response);

				}, function (reason) {
						// failure
						deferred.reject(reason);
				});

				return deferred.promise;
			},
			retrieveDailyScores: function () {
					
				var deferred = $q.defer();
			
				// AJAX request
				$http({
					method: 'GET',
					//url: 'assets/data/alltime.json',
					url: '/api/topten',
					params: {
						duration_type: "daily"
					}

				}).then(function (response) {
					// success
					// get Results object from GET response
					
					deferred.resolve(response);

				}, function (reason) {
						// failure
						deferred.reject(reason);
				});

				return deferred.promise;
			},
			retrieveWeeklyScores: function () {
					
				var deferred = $q.defer();
			
				// AJAX request
				$http({
					method: 'GET',
					//url: 'assets/data/alltime.json',
					url: '/api/topten',
					params: {
						duration_type: "weekly"
					}

				}).then(function (response) {
					// success
					// get Results object from GET response
					
					deferred.resolve(response);

				}, function (reason) {
						// failure
						deferred.reject(reason);
				});

				return deferred.promise;
			},
			retrieveBiWeeklyScores: function () {
					
				var deferred = $q.defer();
			
				// AJAX request
				$http({
					method: 'GET',
					//url: 'assets/data/alltime.json',
					url: '/api/topten',
					params: {
						duration_type: "biweekly"
					}

				}).then(function (response) {
					// success
					// get Results object from GET response
					
					deferred.resolve(response);

				}, function (reason) {
						// failure
						deferred.reject(reason);
				});

				return deferred.promise;
			}
			
		};
		
	});

})();