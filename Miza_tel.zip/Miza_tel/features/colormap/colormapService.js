(function() {
    'use strict';

	// HomeService for storing data in HomeView

	angular.module('app.colormapservice', [])
	.factory('ColorMapService', function ($q, $http) {
		
		return{	
			
			fetchFleetData: function (fleet_id,type,sDate,eDate) {
					
				var deferred = $q.defer();
			
				// AJAX request
				$http({
					method: 'GET',
					url: '/api/colormap',
					params: {
						fleet_id:fleet_id,
						type: type,
						sDate:sDate,
						eDate:eDate
					}

				}).then(function (response) {
					// success
					// get Results object from GET response
					deferred.resolve(response);

				}, function (reason) {
						// failure
						deferred.reject(reason);
				});

				return deferred.promise;
			},
			
		};
		
	});

})();