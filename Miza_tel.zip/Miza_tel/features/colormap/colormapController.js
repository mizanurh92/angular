function showDetails(driver_id) {
	console.log("driver id"+driver_id);
	setTimeout(function() {
		$('#chartcontainer').hide();
		window.prepChart3(driver_id,$('#startdate').datepicker('getFormattedDate'),$('#enddate').datepicker('getFormattedDate'),chart3container);
        window.prepChart4(driver_id,$('#startdate').datepicker('getFormattedDate'),$('#enddate').datepicker('getFormattedDate'),chart4container);
		$('#chartcontainer').show();
	}, 500);
}

(function() {

	'use strict';

	angular
			.module('app.colormap', [])
			.controller(
					"ColorMapController",
					function($scope, $location, $window, localStorageService,
							$state, $stateParams, ColorMapService, $filter,
							usSpinnerService) {
					    var picker1 = $('#startdate');
					    var picker2 = $('#enddate');
						if(localStorage.token !== null && localStorage.token !== undefined ){
						
							var t;
				            $scope.idletime = function(){
				                $scope.resetTimer();
				            };
				            
				            $scope.resetTimer=function (){
				                clearTimeout(t);
				                t = setTimeout($scope.logout, 5*60000);
				            };
				            
				            $scope.logout=function (){
				                localStorage.token = null;
				                location.href = '#/login';
				            };
				    		
							
							var d = new Date();
					    var curDay = d.getDate();
					    var currMonth = d.getMonth();
					    var currYear = d.getFullYear();
						var startDate = new Date(currYear,currMonth,curDay - 90);
					    var endDate = new Date(currYear,currMonth, curDay);
					    
						$scope.fleet_id = $stateParams.fleet_id;
						$scope.updateDials = updateDials;
						$scope.driverdata = [];
						$scope.sorted = true;
						$scope.minDate = "";
						$scope.maxDate = "";
						$scope.offset = 0;
						$scope.sdate = "";
						$scope.edate = "";
						$scope.radialTotal = 0;
						$scope.radialAvgSpd = 0;
						$scope.radialSeg = 0;
						$scope.radialSegTotal = 100;
						$scope.radialMaxTotal = 100;
						$scope.radialMaxSpd = 100;
						
					    //var picker1 = $('#startdate');
					    //var picker2 = $('#enddate');

					    picker1.datepicker('setDate',startDate);
					    picker2.datepicker('setDate',endDate);
					    
						init($scope.fleet_id);

						} else {
							localStorage.setPreviousPage = '/#'+$location.url();
					    	location.href = '#/login';
						}

						function init(fleet_id) {
							console.log('Init');
							getFleetData(fleet_id, false);
						}

						function updateDials(text) {
							$scope.radialTotal = $scope.fleetSummary.fleet_summary.fleets[0].avg_score;
							$scope.radialAvgSpd = $scope.fleetSummary.fleet_summary.fleets[0].avg_speed;
							$scope.radialSeg = $scope.fleetSummary.fleet_summary.fleets[0].full_count;
							
							silverDots();
							$scope.radialSegTotal = $scope.fleetSummary.fleet_summary.fleets[0].full_count;
							$scope.radialMaxTotal = 100;
							$scope.radialMaxSpd = 100;
							
							for(var i=0;i<$scope.fleetSummary.fleet_summary.fleets.length;i++){
								if($scope.fleetSummary.fleet_summary.fleets[i].category == "risky"){
									$scope.riskyTotal = $scope.fleetSummary.fleet_summary.fleets[i].score;
								}else if($scope.fleetSummary.fleet_summary.fleets[i].category == "avg"){
									$scope.avgTotal = $scope.fleetSummary.fleet_summary.fleets[i].score;
								}else if($scope.fleetSummary.fleet_summary.fleets[i].category == "top"){
									$scope.topTotal = $scope.fleetSummary.fleet_summary.fleets[i].score;
								}
							}

							$scope.maxDate = $scope.fleetSummary.fleet_summary.fleets[0].maxdate;
							$scope.minDate = $scope.fleetSummary.fleet_summary.fleets[0].mindate;
							
//							picker1.datepicker('setDate',new Date($scope.minDatei.replace(/-/g, '\/')));
//						    picker2.datepicker('setDate',new Date($scope.maxDate..replace(/-/g, '\/')));
						}
						
						function getFleetData(fleet_id, sorted) {
							if (typeof fleet_id === undefined || fleet_id === 0) {
								fleet_id = 1;
							}
							// startSpin();
							ColorMapService.fetchFleetData(fleet_id,
									"fleet_summary").then(function(response) {

								if (response.data.drivers === null) {
									// // stopSpin();
									return false;
								}

								$scope.fleetSummary = response.data;
								
								updateDials();
								generateColormap(fleet_id);
								//// // stopSpin();

							});
							

						}

					    function silverDots() {
							setDot("avgSpeedColorDot",'silver');
							setDot("avgSmoothColorDot",'silver');
							setDot("avgTimeColorDot",'silver');
					    }
					    
					    function setDot(kind,color){
					    	document.getElementById(kind).setAttribute('class','circle-banner '+color);
					    }
					    
					    function setAllDots(speed,smooth,time){
							setDot("avgSpeedColorDot",speed);
							setDot("avgSmoothColorDot",smooth);
							setDot("avgTimeColorDot",time);
					    }
					    
						function generateColormap(fleet_id){
							// startSpin();
							
							$scope.sdate = picker1.datepicker('getFormattedDate');
					        $scope.edate = picker2.datepicker('getFormattedDate');
							ColorMapService
									.fetchFleetData(fleet_id, "chart",$scope.sdate,$scope.edate)
									.then(
											function(response) {

												if (response.data.drivers === null) {
													// // stopSpin();
													return false;
												}
												document.getElementById("colormapDiv").innerHTML = response.data;
												// stopSpin();
											});
						}
						
						Array.prototype.contains = function(v) {
							for (var i = 0; i < this.length; i++) {
								if (this[i].driver_id === v.driver_id)
									return true;
							}
							return false;
						};

						Array.prototype.unique = function() {
							var arr = [];
							for (var i = 0; i < this.length; i++) {
								if (!arr.contains(this[i])) {
									arr.push(this[i]);
								}
							}
							return arr;
						};

						// $scope.showDetails = function (driver_id) {
						// console.log('Showing Chart');
						// window.prepChart1(driver_id);
						// window.prepChart2(driver_id);
						// $('#chart2container').show();
						// };

						$scope.loadMore = function() {
							var totalLength = $scope.fleetData.length;
							var offset = $scope.driverdata.length;
							var limit = offset + 100;
							if (totalLength <= limit) {
								limit = totalLength;
							}
							for (var i = offset; i < limit - 1; i++) {
								$scope.driverdata.push($scope.fleetData[i]);
							}
						};
						
						$scope.setLevelText = function(value){
							$(".td_score").css({'width':value+'px','font-size':value+'px'});
							$(".td_score").css({'height':value+'px','font-size':value+'px'});
						};
						
						$scope.doZoomin = function(){
							 $("#levelrange").val(parseInt($("#levelrange").val())+1);  
				               $("#levelrange").trigger('change');
						};
						
						$scope.doZoomout = function(){
							 $("#levelrange").val(parseInt($("#levelrange").val())-1);  
				               $("#levelrange").trigger('change');
						};

						// $scope.showScore = function() {
						// console.log('showScore');
						// $tooltiptext.visibility = 'visible';
						// };

						$scope.showChart = function() {
							console.log('showChart');
							alert('Showing Chart 123');
						};

						function startSpin() {
							usSpinnerService.spin('spinner-1');
						}
						function stopSpin() {
							usSpinnerService.stop('spinner-1');
						}
						
					    picker1.datepicker().on('changeDate', function () {
					        if(picker1.datepicker('getDate') > picker2.datepicker('getDate') ) {
					            alert('Start date should be greater then end date'); 
					        } else {
					            picker1.datepicker('hide');
					            resetColormap();   
					            
					        }
					    });
					    picker2.datepicker().on('changeDate', function () {
					        if(picker2.datepicker('getDate')  > picker1.datepicker('getDate') ) {
					            picker2.datepicker('hide');
					            resetColormap();    
					        } else {
					            alert('End date should be greater then start date');
					        }
					        
					    });
					    
						$scope.showDashboard = function(fleet_id) {
							$('#chartcontainer').hide();
							window.location = "#/dashboard/" + fleet_id;
						};
						
						function resetColormap(){
							document
							.getElementById("colormapDiv").innerHTML = "";
							document
							.getElementById("chart3container").innerHTML = "";
							document
							.getElementById("chart4container").innerHTML = "";
							$('#chartcontainer').hide();
							generateColormap($scope.fleet_id);
						}

					});

})();
