(function() {
    'use strict';

	angular.module('app.welcomeresendfail', [])
	.controller("WelcomeResendFailController",function($scope, $location){
      	
    });

})();