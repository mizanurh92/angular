(function() {
    'use strict';

	// Behavior services for storing data in BehaviorView

	angular.module('app.behavior')
	.factory('BehaviorService', function ($q, $http) {
		
		return{	
			
			"top": "{}",
			"bottom": "{}",
			
			retrieveTopBehavior: function () {
					
				var deferred = $q.defer();
			
				// AJAX request
				$http({
					method: 'GET',
					url: '/api/aggregate',
					params: {
						order_type: "top"
					}

				}).then(function (response) {
					// success
					// get Results object from GET response
					deferred.resolve(response);

				}, function (reason) {
						// failure
						deferred.reject(reason);
				});

				return deferred.promise;
			},
			retrieveBottomBehavior: function () {
					
				var deferred = $q.defer();
			
				// AJAX request
				$http({
					method: 'GET',
					url: '/api/aggregate',
					params: {
						order_type: "bottom"
					}

				}).then(function (response) {
					// success
					// get Results object from GET response
					deferred.resolve(response);

				}, function (reason) {
						// failure
						deferred.reject(reason);
				});

				return deferred.promise;
			}
		
		};
		
	});

})();