(function() {
    'use strict';

	angular.module('app.behavior', [])
	.controller("BehaviorController",function($scope, $location, BehaviorService, $window, HomeService){
    	
    	// Behavior Component Score Tooltip Descriptions
    	$scope.showSpinner = true;
    	
    	$scope.smoothDescription = "This is a measure of the risk of the driving style based on the amount of acceleration and braking. In general, journeys with more harsh acceleration and more harsh braking events will score worse than a gentler drive.";
    	$scope.speedDescription = "This is a measure of the risk posed by the speed the vehicle is travelling at, on the basis that a faster vehicle can do more damage.  In general, increased speeds will score worse.";
    	$scope.fatigueDescription = "This is a measure of the risk that the driver is exposing themselves to by driving for extended periods of time or on monotonous roads. In general, it is recommended to keep journeys shorter than two hours, as long drives without breaks will score worse.";
    	
    	$scope.BehaviorService = BehaviorService;      	
      	$scope.date = new Date();
      	
      	// AJAX request for Top Behavior bars
      	BehaviorService.retrieveTopBehavior().then(function (response) {
      		BehaviorService.top = response.data;	
      	});
      	
      	// AJAX request for Bottom Behavior bars
      	BehaviorService.retrieveBottomBehavior().then(function (response) {
      		BehaviorService.bottom = response.data;
      		$scope.showSpinner = false;
      	});
      	
    });

})();
