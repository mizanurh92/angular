(function() {
    'use strict';

	// HomeService for storing data in HomeView

	angular.module('app.home')
	.factory('HomeService', function ($state, $q, $http) {
		
		return{	
			userDetected: false,
   			searchEmail: "",
   			userEmail: "",
   			state: $state,
   			searchCount: 0,
		
			retrieveEmail: function (id) {
					
				var deferred = $q.defer();
			
				// AJAX request
				$http({
					method: 'GET',
					//url: 'assets/data/mydrive.json',
					url: '/api/renter_email',
					params: {
						id: id
					}

				}).then(function (response) {
					// success
					// get Results object from GET response
					deferred.resolve(response);

				}, function (reason) {
						// failure
						deferred.reject(reason);
				});

				return deferred.promise;
			},
			welcomeResend: function (email) {
					
				var deferred = $q.defer();
			
				// AJAX request
				$http({
					method: 'POST',
					//url: 'assets/data/mydrive.json',
					url: '/api/welcome_resend',
					params: {
						email: email
					}

				}).then(function (response) {
					// success
					// get Results object from GET response
					deferred.resolve(response);

				}, function (reason) {
						// failure
						deferred.reject(reason);
				});

				return deferred.promise;
			}
		
		};
		
	});

})();