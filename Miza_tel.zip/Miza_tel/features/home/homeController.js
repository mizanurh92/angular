(function() {
    'use strict';

	angular.module('app.home', [])
	.controller("HomeController",function($scope, $location, HomeService, $window, $state, localStorageService, $stateParams){
    	
    	$scope.HomeService = HomeService;
    	
    	// if we have a url_id for a person visiting MyDrive from their email
		if($stateParams && $stateParams.id){
			//AJAX request to get the associated email address
			HomeService.retrieveEmail($stateParams.id).then(function (response) {
      			// store the email in localStorage (will persist until browser history is cleared), and without a cookie
      			localStorageService.set("userEmail", response.data.email);
      			// set userDetected to true, and set the HomeService userEmail to the email retrieved.
      			HomeService.userDetected = true;
      			HomeService.userEmail = response.data.email;
      			
      			// Go to the MyDrive page, but reload it, since we want to have the above userDetected and userEmail reset, as
      			// Home->MyDrive (nested within Home), and we need to reload to have the changed variables take effect.
      			$state.transitionTo('home.mydrive', {id:""}, { 
				  reload: true, inherit: true, notify: true 
				});
      		});	
		}
    	
    	// retrieve the userEmail from localStorage      	
   		HomeService.userEmail = localStorageService.get("userEmail");
   		// if an email exists, set userDetected to true, else false
   		if(HomeService.userEmail){
   			HomeService.userDetected = true;
   		}
   		else{
   			HomeService.userDetected = false;
   		}
   		
   		// Get the overall scoreModel if already set, and if not, set to "daily".
   		$scope.Model = $scope.Model || { 
   			scoreChoiceModel: "daily",
   			state: $state
   		};
   		
   		// On "Find My Car" submit, augment the searchCount and check for errors.
   		$scope.submit = function(form) {
			// if form not valid
			
			HomeService.searchCount++;
			
			if(!form.$valid){
				// show all errors on form
				$scope.$broadcast('show-errors-check-validity');
				/*
				// scroll to first item with error
				var $target = $('.has-error').first();
				if($target.length > 0){
					$("body,html").animate({scrollTop: $target.offset().top}, "fast");
				}
				*/
			}
			else{
				// show the loading spinner while searching
      			$scope.showSpinner = true;
      			// Ajax request to resend the welcome email for the email in the search box
      			HomeService.welcomeResend(HomeService.searchEmail).then(
					function (response) {
						// shut off spinner
						$scope.showSpinner = false;
						// redirect to welcomeresend success page
      					$state.go('home.welcomeresend');
      				},function(reason){
      					// shut off spinner
      					$scope.showSpinner = false;
      					// redirect to welcomeresend failure page
      				 	$state.go('home.welcomeresendfail');
      				}
      			);
      			
			}
		};      	
      	
      	// Tab nav definitions for mobile phone (Boostrap XS)
      	$scope.tabDataXS   = [
			
		  	{
				heading: '<i class="fa fa-trophy fa-2x"></i><br class="visible-xs-block"><span>Top <br class="visible-xs-block">Scores</span>',
				route:   'home.topscores',
		  	},
		  	{
				heading: '<i class="fa fa-car fa-2x"></i><br class="visible-xs-block"><span>My <br class="visible-xs-block">Drive</span>',
				route:   'home.mydrive',
		  	},
		  	{
				heading: '<i class="fa fa-road fa-2x"></i><br class="visible-xs-block"><span>Trip<br class="visible-xs-block"> Behavior</span>',
				route:   'home.behavior',
		  	},
		  	{
				heading: '<i class="fa fa-question fa-2x"></i><br class="visible-xs-block"><span>Prizes<br class="visible-xs-block"> & FAQ</span>',
				route:   'home.faq',
		  	}
		];
		
		// Tab nav definitions for tablets and Desktop (Boostrap SM and above)
		$scope.tabDataSM   = [
			
		  	{
				heading: '<i class="fa fa-car fa-2x"></i><br class="visible-xs-block"><span>My <br class="visible-xs-block">Drive</span>',
				route:   'home.mydrive',
		  	},
		  	{
				heading: '<i class="behavior-tab-sm fa fa-road fa-2x"></i><br class="visible-xs-block"><span>Trip<br class="visible-xs-block"> Behavior</span>',
				route:   'home.behavior',
		  	},
		  	{
				heading: '<i class="fa fa-question fa-2x"></i><br class="visible-xs-block"><span>Prizes<br class="visible-xs-block"> & FAQ</span>',
				route:   'home.faq',
		  	}
		];
      	
    });

})();