(function() {
    'use strict';

	// renterService for storing data in renterView

	angular.module('app.mydrive')
	.factory('RenterService', function ($q, $http) {
		
		return{	
		
			"profile": "{}",
			
			retrieveRenter: function (email) {
					
				var deferred = $q.defer();
			
				// AJAX request
				$http({
					method: 'GET',
					//url: 'assets/data/mydrive.json',
					url: '/api/renter_id',
					params: {
						email: email
					}

				}).then(function (response) {
					// success
					// get Results object from GET response
					deferred.resolve(response);

				}, function (reason) {
						// failure
						deferred.reject(reason);
				});

				return deferred.promise;
			}
		
		};
		
	});

})();