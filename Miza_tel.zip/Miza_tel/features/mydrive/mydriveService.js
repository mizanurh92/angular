(function() {
    'use strict';

	// HomeService for storing data in HomeView

	angular.module('app.mydrive')
	.factory('MydriveService', function ($q, $http) {
		
		return{	
			
			"myDrive": "{}",
			
			// Retrieve data for MyDrive
			retrieveMyDrive: function (email) {
					
				var deferred = $q.defer();
			
				// AJAX request
				$http({
					method: 'GET',
					url: '/api/renter_details',
					params: {
						email: email
					}

				}).then(function (response) {
					// success
					// get Results object from GET response
					deferred.resolve(response);

				}, function (reason) {
						// failure
						deferred.reject(reason);
				});

				return deferred.promise;
			}
		};
		
	});

})();