(function() {
    'use strict';

	angular.module('app.mydrive', [])
	.controller("MydriveController",function($scope, $location, MydriveService, $window, $filter, HomeService, RenterService){
    	
    	// keeps track of whether MyDrive info is found (trip scores)
    	$scope.notFound = $scope.notFound || false;
    	$scope.MydriveService = MydriveService;
    	$scope.RenterService = RenterService;           	
      	// dailyMax initial value
      	$scope.dailyMax = 0;
      	
      	// start loading spinner
      	$scope.showSpinner = true;
      	MydriveService.retrieveMyDrive(HomeService.userEmail).then(function (response) {
      		// stop loading spinner
      		$scope.showSpinner = false;
      	
      		// if daily_scores/trip scores are presence, load them into the view
      		if(response.data.daily_scores){     		
				MydriveService.myDrive = response.data;	
			
				// if they are present and of non-zero length
				if(MydriveService.myDrive && MydriveService.myDrive.daily_scores && MydriveService.myDrive.daily_scores.length){ 
					
					// find the max	
					for(var i=0; i<MydriveService.myDrive.daily_scores.length; i++){
						var max = MydriveService.myDrive.daily_scores[i].average;
						if(max > $scope.dailyMax){
							$scope.dailyMax = max;
						}
					}
					// set the trend to positive (today vs. yesterday)
					$scope.trendPositive = true;
			
					// order scores from with most recent at the top
					$scope.MydriveService.myDrive.daily_scores = $filter('orderBy')($scope.MydriveService.myDrive.daily_scores, '-date');
			
					// if there are at least two scores, set the trendPositive to true if today's score is greater than or equal to yesterday's
					if($scope.MydriveService.myDrive.daily_scores.length >= 2){
						$scope.trendPositive = (Math.round($scope.MydriveService.myDrive.daily_scores[0].average)-Math.round($scope.MydriveService.myDrive.daily_scores[1].average)) >=0;
					}
				}
			}
			else{
				// user is not present
				HomeService.userDetected=false; 
			}

      	});
      	
      	// Retrieve the userEmail for the profile Dashboard
      	RenterService.retrieveRenter(HomeService.userEmail).then(function (response) {
      		RenterService.profile = response.data;	
      	});
      	
    });

})();