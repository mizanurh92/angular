(function() {
    'use strict';

	angular.module('app.faq', [])
	.controller("FaqController",function($scope, $location, FaqService, $window){
    	
    	$scope.FaqService = FaqService;    	
    	// allow only one question to be opened at once
    	$scope.oneAtATime = true;
		// FAQ default state by question #, see faqView.html
		$scope.status = {
			open1: false,
			open2: false,
			open3: false,
			open4: false,
			open4a: false,
			open5: false,
			open6: false,
			open7: false,
			open9: false,
			open10: false,
			open14: false,
			open16: false,
			open17: false,
			open18: false,
			open19: false,
			open20: false,
			open21: false
		};
      	
    });

})();