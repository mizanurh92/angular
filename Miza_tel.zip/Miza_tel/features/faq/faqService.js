(function() {
    'use strict';

	// faqService for storing data in FAQView
	// not currently used

	angular.module('app.faq')
	.factory('FaqService', function () {
		
		return{	
			"":""
		};
	});

})();