(function() {
    'use strict';

	angular.module('app.welcomeresend', [])
	.controller("WelcomeResendController",function($scope, $location){
      	
    });

})();