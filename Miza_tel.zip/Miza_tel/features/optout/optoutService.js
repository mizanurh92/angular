(function() {
    'use strict';

	// optOutService for OptOutview
	// not used at present

	angular.module('app.optout')
	.factory('OptoutService', function ($state, $q, $http) {
		
		return{	
		};
	});

})();