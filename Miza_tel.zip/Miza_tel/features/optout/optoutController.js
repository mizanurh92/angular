(function() {
    'use strict';

	

	angular.module('app.optout', [])
	.controller("OptoutController",function($scope, $location, OptoutService, $stateParams){
    	
    	$scope.OptoutService = OptoutService;
      	
    });

})();