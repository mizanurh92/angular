(function() {
    'use strict';
    angular.module('app.loginservice',[])
    
    .factory('loginutility',['$http',function($http){
    	  var loginVal = function(uname,pwd, successCallback, failureCallback) {
    		  
              var request = $http({
                  method: "GET",
                  url: '/api/login',
                  params: {
						userId: uname,
						password: pwd,
						
					}
              });
              request.then(successCallback, failureCallback);
    	  };
    	  return {
    		  loginVal:loginVal
    	  };
    }]);
    
    })();
