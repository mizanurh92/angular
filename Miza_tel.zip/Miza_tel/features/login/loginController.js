(function() {
    'use strict';
    angular.module('app.login', ['app.loginservice'])
    .controller('logincontroller',['$scope','loginutility','$rootScope',function($scope,loginutility,$rootScope){
   
    	$scope.fn_login = function(login){
    			var uname = login.username;
    			var pwd = login.password;
    			
    		loginutility.loginVal(uname,pwd,function(response){
    			console.log(response);
    			localStorage.token = response.data.token;
    			var previousURL = localStorage.setPreviousPage;
    			if(previousURL){
                    location.href = previousURL;
                }else{
                    location.href = '#/dashboard/1';
                }
    		},function(response){
    			console.log(response);
    			alert(response.data.msg);
    		});
    	};

    }]);
    
})();
