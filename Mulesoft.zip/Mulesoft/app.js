'use strict';

/**
 * @ngdoc overview
 * @name mulesoftAcceleratorApp
 * @description
 * # mulesoftAcceleratorApp
 *
 * Main module of the application.
 */

 var angularApp = angular.module('muleSoft', ['ngRoute','muleSoft.widgets']);

 angularApp.config(function($routeProvider,$httpProvider) {
    $routeProvider
      .when('/basic',{
       templateUrl: 'src/views/home.html'
      })
      .when('/category',{
       templateUrl: 'src/views/category.html',
       controller: 'categoryCtrl'
      })
      .when('/logs', {
        templateUrl: 'src/views/dashboard.html',
        controller: 'pieChartController'

      })
       .when('/admincategories', {
        templateUrl: 'src/views/admincategories.html',
        controller: 'adminCtrl'

      })
       .when('/adminexception', {
        templateUrl: 'src/views/adminexception.html',
        controller: 'adminExceptionCtrl'

      })
      
       .when('/configuration', {
        templateUrl: 'src/views/adminconfiguration.html',
        controller: 'configurationCtrl'
      })
      
      .when('/ErrorDetails', {
        templateUrl: 'src/views/logger.html',
        controller: 'ErrorDetailsCtrl'

      })
      .when('/ErrorReferences', {
        templateUrl: 'src/views/adminrecovery.html',
        controller: 'ErrorReferencesCtrl'

      })
      .when('/exceptiontype', {
        templateUrl: 'src/views/exceptiontype.html',
        controller: 'exceptionTypeCtrl'

      })
      .when('/recovery', {
        templateUrl: 'src/views/recoverable.html',
        controller: 'recoveryCtrl'

      })
      .when('/admin', {
        templateUrl: 'src/views/adminnew.html',
        controller: 'adminnewCtrl'

      })
      
       .when('/trackActivity', {
        templateUrl: 'src/views/trackActivitynew.html',
        controller: 'trackActivityCtrl'
      })
      
      .when('/activityLog', {
        templateUrl: 'src/views/activityLognew.html',
        controller: 'activityLogCtrl'

      })
      .when('/dashboard', {
        templateUrl: 'src/views/dashboardnew.html',
        controller: 'dashboardCtrlNew'

      })

      .otherwise({
			    redirectTo: '/basic'
		});    
  });
