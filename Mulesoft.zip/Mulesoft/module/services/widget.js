'use strict';
angular.module('muleSoft.widgets', [])

.directive('loading', ['$http', function($http) {
     return {
          restrict: 'A',
          link: function(scope, element, attrs) {
               scope.isLoading = function() {
                    var reqCount = $http.pendingRequests;
                    return reqCount.length > 0;
               };
               scope.$watch(scope.isLoading, function(value) {
                    if (value) {
                         element.removeClass('ng-hide');
                    } else {
                         element.addClass('ng-hide');
                    }
               });
          }
     };
}])
