angularApp.service('dataService',['$http', '$q',function($http,$q){
	this.getData = function(url) {
        var def = $q.defer();
        $http.get(url)
            .success(function(result) {
                var data = result;//here u will get the data
               
                def.resolve(data);
            })
            .error(function(error) {
            	console.log("error",error);
                def.reject("Failed to get data");
            });
        return def.promise;
    };
    	
    this.getBarData = function(url) {
        var def = $q.defer();
        
        $http.get(url)
            .success(function(data) {
                def.resolve(data);
            })
            .error(function(error) {
            	console.log("error",error);
                def.reject("Failed to get albums");
            });
        return def.promise;
    };
    
}]);