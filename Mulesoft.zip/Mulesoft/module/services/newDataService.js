angularApp.service('newDataService',['$http', '$q',function($http,$q){
this.getnewTabledata = function(url) {
    var def = $q.defer();
    $http.get(url)
        .success(function(result) {
            var data = result;//here u will get the data
            def.resolve(data);
        })
        .error(function(error) {
        	console.log("error",error);
            def.reject("Failed to get data");//if it fails  u will get here error msg
        });
    return def.promise;
};
this.putnewTabledata = function(url,data) {
    var def = $q.defer();
    var config = {headers: {
    	  "Authorization": "token",
    	  "Accept": "application/json",
    	  "Access-Control-Allow-Origin": "http://10.102.55.150:8081",
    	  "Access-Control-Allow-Origin": "*",
    	  "Access-Control-Allow-Credentials": true,
    	  "Access-Control-Allow-Methods": ("GET, POST, PUT, DELETE, OPTIONS"),
    	  "Access-Control-Allow-Headers":"x-requested-with, Content-Type, origin, authorization, accept, client-security-token"
    	  },
    	  crossDomain: true,
    	};
    $http.put(url,data,config)
        .success(function(result) {
            var data = result;//here u will get the data
            def.resolve(data);
        })
        .error(function(error) {
        	console.log("error",error);
            def.reject("Failed to get data");//if it fails  u will get here error msg
        });
    return def.promise;
};
}]);