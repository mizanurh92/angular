angularApp.controller('trackActivityCtrl',['$scope','filterFilter','newDataService', function ($scope,filterFilter,newDataService) {
newDataService.getnewTabledata(host1+'/events').then(function(responseData) { 
		    $scope.head = {
		
		    		creationDateTime: "Time",
					id: "UserId",
					IPAddress: "IPAddress",
					EventSource: "EventSource",
					activityType: "Operation Type",
					activityCompleted: "Operation Completed",
					Details: "Details"
				};
		    
		    $scope.gridData=responseData;
	      	         		    
		 
		    newDataService.getnewTabledata(host1+'/trackattributes').then(function(responseData) { 
    			$scope.attributeNames = responseData;
    			
    	    	
	    	},
	        	    function(result) {
	            console.log("Failed to get the name, result is " + result); 
    });
		    
		    //pagination
//			// create empty search model (object) to trigger $watch on update
//			$scope.searchTable = "";
//			$scope.resetFilters = function () {
//				// needs to be a function or it won't trigger a $watch
//				$scope.searchTable = "";
//			};
		
			// pagination controls
			$scope.currentPage = 1;
			$scope.totalItems = $scope.gridData.length;
			$scope.entryLimit = 8; // items per page
			$scope.noOfPages = Math.ceil($scope.totalItems / $scope.entryLimit);
		
//			// $watch search to update pagination
//			$scope.$watch('searchTable', function (newVal, oldVal) {
//				$scope.filtered = filterFilter($scope.gridData.contacts, newVal);
//				$scope.totalItems = $scope.filtered.length;
//				$scope.noOfPages = Math.ceil($scope.totalItems / $scope.entryLimit);
//				$scope.currentPage = 1;
//			}, true);
		    
		    $scope.sort = {
		        column: 'Service_Name',
		        descending: false
		    };
		    
		    $scope.changeSorting = function(column) {
		    	console.log("fsdf",column);
		        var sort = $scope.sort;
		        if (sort.column == column) {
		            sort.descending = !sort.descending;
		        } else {
		            sort.column = column;
		            sort.descending = false;
		        }
		    };
		 /* $scope.editingData = {};
		    
		    for (var i = 0, length = $scope.gridData.length; i < length; i++) {
		      $scope.editingData[$scope.gridData[i].id] = false;
		    }
		
		
		    $scope.modify = function(row){
		        $scope.editingData[row] = true;
		    };
		
		
		    $scope.update = function(row){
		        $scope.editingData[row.id] = false;
		    };
		    */
		    $scope.addRow = function(){
		    	$scope.gridData.contacts.push({
		    		creationDateTime: "",
		    		id: "",
		    		IPAddress: "",
		    		EventSource: "",
		    		activityType: "",
		    		activityCompleted: "",
		    		Details: ""
			});
		    	return 'new';
		    };
	},
    function(result) {
console.log("Failed to get the name, result is " + result); 
});

  }]);
