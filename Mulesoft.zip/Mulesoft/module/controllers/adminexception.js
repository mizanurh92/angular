angularApp.controller('adminExceptionCtrl',['$scope','$filter','filterFilter','errorDataService','$http' , function ($scope,$filter,filterFilter,errorDataService,$http) {

    
    errorDataService.getTabledata(host+'/handleExceptions').then(function(responseData) { 
    	$scope.head = {

        		Exception_Code: "Exception Code",
        		Exception_Name: "Exception Name",    	    
        		Exception_Type: "Category",
        		Exception_Recovery:"Recovery",
        	    	  Edit:"Edit"
    		};
    	$scope.gridData= {
      	         contacts: responseData,
      	         selected: {}
      	    };
    	$scope.exceptionCategoryName=[];
    	$scope.exceptionRecoveryCode=[];

    	errorDataService.getTabledata(host+'/categories').then(function(responseData) { 
	    			$scope.exceptionSelectBox = responseData;
	    			for(var i=0;i<$scope.gridData.contacts.length;i++){
	    	    		for(var j=0;j<$scope.exceptionSelectBox.length;j++){
	    	    		if($scope.gridData.contacts[i].categoryId==$scope.exceptionSelectBox[j].categoryId){
	    	    				$scope.exceptionCategoryName.push($scope.exceptionSelectBox[j]);
	    	    			
	    	    			}	
	    	    		}
	    	    		
	    	    	}
	    	    	console.log($scope.exceptionCategoryName);
		    	},
		        	    function(result) {
		            console.log("Failed to get the name, result is " + result); 
	    });
    	errorDataService.getTabledata(host+'/getExceptionRecovery').then(function(responseData) { 
    		$scope.recoveryCodeList = responseData;
			for(var i=0;i<$scope.gridData.contacts.length;i++){
	    		for(var j=0;j<$scope.recoveryCodeList.length;j++){
	    		if($scope.gridData.contacts[i].recoveryId==$scope.recoveryCodeList[j].recoveryId){
	    			$scope.exceptionRecoveryCode.push($scope.recoveryCodeList[j]);
	    			
	    			}	
	    		}
	    		
	    	}
    	},
        	    function(result) {
            console.log("Failed to get the name, result is " + result); 
    	});
    	
    	    
    	    $scope.getTemplate = function (contact) {
    	    	if (contact.categoryId == "") {
    	        	return 'new';
    	        	$scope.isCriticalDisabled[$index]=true;
    	        }
    	        if (contact.exceptionCode === $scope.gridData.selected.exceptionCode) 
    	        	{   
    	        	return 'edit'; 
    	        	}
    	        else return 'display';
    	    };

    	    $scope.editContact = function (index) {
    	    	$scope.gridData.selected = {};
    	        $scope.gridData.selected = angular.copy($scope.gridData.contacts[index]);
    	    };

    	    $scope.saveContact = function (idx) {
    	        console.log("Saving contact");
    	        $scope.gridData.contacts[idx] = angular.copy($scope.gridData.selected);
    	        /*var url = "http://10.102.55.149:8082/modifyCategoryInHandleExceptions";
    	        var config = {headers: {
    	      	  //'Authorization': token,
    	      	  "Accept": "application/json",
    	      	  "Access-Control-Allow-Origin": "http://10.102.55.149:8082",
    	      	  "Access-Control-Allow-Credentials": true
    	      	  },
    	      	  crossDomain: true,
    	      	};
    	        $http.put(url, $scope.gridData.selected, config)
                .success(function (data, status, headers, config) {
                	console.log("Success fully saved");
                })
                .error(function (data, status, header, config) {
                });*/
    	        
    	        
    	        
    	      errorDataService.putTabledata("http://10.102.55.149:9082/modifyCategoryInHandleExceptions",$scope.gridData.selected).then(function(responseData) {
		    	    	  errorDataService.getTabledata(host+'/handleExceptions').then(function(responseData) {
		    	    		  $scope.gridData= {
		    	    	      	         contacts: responseData,
		    	    	      	         selected: {}
		    	    	      	  };
		    	    	  },
		    		        	    function(result) {
		   		            console.log("Failed to get the name, result is " + result); 
		      	        });
    	        },
	        	    function(result) {
 		            console.log("Failed to get the name, result is " + result); 
    	        });
    	        	 
    	        $scope.reset();
    	    };

    	    $scope.reset = function () {
    	        $scope.gridData.selected = {};
    	    };
    	    
    	    //pagination
    		// create empty search model (object) to trigger $watch on update
    		$scope.searchTable = "";
    		$scope.resetFilters = function () {
    			// needs to be a function or it won't trigger a $watch
    			$scope.searchTable = "";
    		};

    		// pagination controls
    		$scope.currentPage = 1;
    		$scope.totalItems = $scope.gridData.contacts.length;
    		$scope.entryLimit = 8; // items per page
    		$scope.noOfPages = Math.ceil($scope.totalItems / $scope.entryLimit);

    		// $watch search to update pagination
    		$scope.$watch('searchTable', function (newVal, oldVal) {
    			$scope.filtered = filterFilter($scope.gridData.contacts, newVal);
    			$scope.totalItems = $scope.filtered.length;
    			$scope.noOfPages = Math.ceil($scope.totalItems / $scope.entryLimit);
    			$scope.currentPage = 1;
    		}, true);
    	    
    	    $scope.sort = {
    	        column: 'Service_Name',
    	        descending: false
    	    };
    	    
    	    $scope.changeSorting = function(column) {
    	    	console.log("fsdf",column);
    	        var sort = $scope.sort;
    	        if (sort.column == column) {
    	            sort.descending = !sort.descending;
    	        } else {
    	            sort.column = column;
    	            sort.descending = false;
    	        }
    	    };
    	 
    	    $scope.addRow = function(){
    	    	$scope.gridData.contacts.push({
    	    		categoryId: "",
    	    		exceptionCode: "",
    	    		exceptionName: "",
    	    		recoveryId: "",
    	    		EEC_Category_ID:""
    		});
    	    };
    	    $scope.addCancel = function () {
    	    	$scope.gridData.contacts.pop();    
    	    };
    	
    	
    },
    	    function(result) {
        console.log("Failed to get the name, result is " + result); 
});
    
  }]);
