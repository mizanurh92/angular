angularApp.controller('recoveryCtrl',['$scope','filterFilter','errorDataService' , function ($scope,filterFilter,errorDataService) {
	 errorDataService.getTabledata(host+'/getExceptionRecovery').then(function(responseData) { 
    $scope.head = {
    	Recovery_Id:"Recovery ID",
       Recovery_Code: "Recovery Code",
       Recovery_Strategies: "Strategy Description",
       IsRecoverable: "IsRecoverable",
		};
    
    $scope.gridData = responseData;
    //pagination
	// create empty search model (object) to trigger $watch on update
	$scope.searchTable = "";
	$scope.resetFilters = function () {
		// needs to be a function or it won't trigger a $watch
		$scope.searchTable = "";
	};

	// pagination controls
	$scope.currentPage = 1;
	$scope.totalItems = $scope.gridData.length;
	$scope.entryLimit = 8; // items per page
	$scope.noOfPages = Math.ceil($scope.totalItems / $scope.entryLimit);

	// $watch search to update pagination
	$scope.$watch('searchTable', function (newVal, oldVal) {
		$scope.filtered = filterFilter($scope.gridData, newVal);
		$scope.totalItems = $scope.filtered.length;
		$scope.noOfPages = Math.ceil($scope.totalItems / $scope.entryLimit);
		$scope.currentPage = 1;
	}, true);
    
    $scope.sort = {
        column: 'Service_Name',
        descending: false
    };
    
    $scope.changeSorting = function(column) {
    	console.log("fsdf",column);
        var sort = $scope.sort;
        if (sort.column == column) {
            sort.descending = !sort.descending;
        } else {
            sort.column = column;
            sort.descending = false;
        }
    };
	 },
	   function(result) {
  		console.log("Failed to get the name, result is " + result); 
	});
    

  }]);
