angularApp.controller('adminnewCtrl',['$scope','$filter','filterFilter','newDataService' , function ($scope,$filter,filterFilter,newDataService) {
	
   
    newDataService.getnewTabledata(host1+'/trackattributes').then(function(responseData) { 
    	$scope.head = {

        		Attribute_Name: "Attribute Name",
        		Is_Active: "Is Active",    	    
        	
        	    	  Modify:"Edit"
    		};
    	$scope.gridData= {
      	         contacts: responseData,
      	         selected: {}
      	    };
    
    	    $scope.getTemplate = function (contact) {
    	        if (contact.attributeId === $scope.gridData.selected.attributeId) return 'edit';
    	        else return 'display';
    	    };

    	    $scope.editContact = function (index) {
    	        $scope.gridData.selected = angular.copy($scope.gridData.contacts[index]);
    	    };

    	    $scope.saveContact = function (idx) {
    	        console.log("Saving contact");
    	       
		        console.log($scope.gridData.selected);
    	        $scope.reset();
    	    };

    	    $scope.reset = function () {
    	        $scope.gridData.selected = {};
    	    };
    	    
    	    //pagination
    		// create empty search model (object) to trigger $watch on update
    		$scope.searchTable = "";
    		$scope.resetFilters = function () {
    			// needs to be a function or it won't trigger a $watch
    			$scope.searchTable = "";
    		};

    		// pagination controls
    		$scope.currentPage = 1;
    		$scope.totalItems = $scope.gridData.contacts.length;
    		$scope.entryLimit = 8; // items per page
    		$scope.noOfPages = Math.ceil($scope.totalItems / $scope.entryLimit);

    		// $watch search to update pagination
    		$scope.$watch('searchTable', function (newVal, oldVal) {
    			$scope.filtered = filterFilter($scope.gridData.contacts, newVal);
    			$scope.totalItems = $scope.filtered.length;
    			$scope.noOfPages = Math.ceil($scope.totalItems / $scope.entryLimit);
    			$scope.currentPage = 1;
    		}, true);
    	    
    	    $scope.sort = {
    	        column: 'Service_Name',
    	        descending: false
    	    };
    	    
    	    $scope.changeSorting = function(column) {
    	    	console.log("fsdf",column);
    	        var sort = $scope.sort;
    	        if (sort.column == column) {
    	            sort.descending = !sort.descending;
    	        } else {
    	            sort.column = column;
    	            sort.descending = false;
    	        }
    	    };
    	 
    	    $scope.addRow = function(){
    	    	$scope.gridData.contacts.push({
    	    		Attribute_Name: "",
    	    		Is_Active: ""
    	    	
    	    	
    		});
    	    	return 'new';
    	    };
    	
    	
   },
    	    function(result) {
        console.log("Failed to get the name, result is " + result); 
});
    
    
    

  }]);
