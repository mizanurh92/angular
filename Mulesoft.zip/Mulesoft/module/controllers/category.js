angularApp.controller('categoryCtrl',['$scope','filterFilter','errorDataService' , function ($scope,filterFilter,errorDataService) {
    errorDataService.getTabledata(host+'/categories').then(function(responseData) { 
	$scope.isCriticalDisabled=[];
    $scope.head = {

    		categoryId: "Category ID",
    		categoryType: "Category Type",
    		exceptionCategory: "Exception Category",    	    
    		   isCritical: "IS Critical"
		};
    
    $scope.gridData = {
       contacts: responseData,
       selected: {}
    };
    
   for(var i=0;i<$scope.gridData.contacts.length;i++){
	   $scope.isCriticalDisabled[i]=true;
   }
    
    
    $scope.getTemplate = function (contact) {
    	if (contact.categoryId == "") {
        	return 'new';
        	$scope.isCriticalDisabled[$index]=true;
        }
        if (contact.categoryId === $scope.gridData.selected.categoryId) {
        	return 'edit';
        }
        else return 'display';
        
    };

    $scope.editContact = function (index) {
        $scope.gridData.selected = angular.copy($scope.gridData.contacts[index]);
        for(var i=0;i<$scope.gridData.contacts.length;i++){
      	   $scope.isCriticalDisabled[i]=true;
         }
        $scope.isCriticalDisabled[index]= false;
    };

    $scope.saveContact = function (idx) {
        console.log("Saving contact");
    	$scope.isCriticalDisabled[idx]= true;
        $scope.gridData.contacts[idx] = angular.copy($scope.gridData.selected);
        $scope.reset();
    };

    $scope.reset = function () {
        $scope.gridData.selected = {};
        for(var i=0;i<$scope.gridData.contacts.length;i++){
     	   $scope.isCriticalDisabled[i]=true;
        }
         
    };
    $scope.addCancel = function () {
    	$scope.gridData.contacts.pop();    
    };
    
    //pagination
	// create empty search model (object) to trigger $watch on update
	$scope.searchTable = "";
	$scope.resetFilters = function () {
		// needs to be a function or it won't trigger a $watch
		$scope.searchTable = "";
	};

	// pagination controls
	$scope.currentPage = 1;
	$scope.totalItems = $scope.gridData.contacts.length;
	$scope.entryLimit = 8; // items per page
	$scope.noOfPages = Math.ceil($scope.totalItems / $scope.entryLimit);

	// $watch search to update pagination
	$scope.$watch('searchTable', function (newVal, oldVal) {
		$scope.filtered = filterFilter($scope.gridData.contacts, newVal);
		$scope.totalItems = $scope.filtered.length;
		$scope.noOfPages = Math.ceil($scope.totalItems / $scope.entryLimit);
		$scope.currentPage = 1;
	}, true);
    
    $scope.sort = {
        column: 'Service_Name',
        descending: false
    };
    
    $scope.changeSorting = function(column) {
    	console.log("fsdf",column);
        var sort = $scope.sort;
        if (sort.column == column) {
            sort.descending = !sort.descending;
        } else {
            sort.column = column;
            sort.descending = false;
        }
    };
 
    $scope.addRow = function(){
		    	$scope.gridData.contacts.push({
		    		categoryId: "",
		    		categoryType: "",
		    		exceptionCategory: "",
		    		isCritical: ""
			});
    };
  },
	   function(result) {
    		console.log("Failed to get the name, result is " + result); 
	});

  }]);
