angularApp.controller('ErrorDetailsCtrl',['$scope','filterFilter','errorDataService', function ($scope,filterFilter,errorDataService) {
	errorDataService.getTabledata(host+'/getExceptionLog').then(function(responseData) { 
		$scope.head = {
				Current_Date: "Current Date",
				Exception_Code: "Exception Code",
				Exception_Error_Type: "Category",
	    		Recoverable: "Recoverable",
	    		Is_Critical: "Is Critical",
	    		Is_Recoverable: "Is Recoverable",
	    		Exception_Error_Stack_Trace: "Stack Trace",
	    		Exception_Error_Source: "Source",
	    		Service_Name: "Service Name",
	    		Exception_Error_Additional_Details1: "Additional Details 1",
	    		Exception_Error_Additional_Details2: "Additional Details 2"	
		};

	    $scope.gridData = responseData;
	    
	  //pagination
		// create empty search model (object) to trigger $watch on update
		$scope.searchTable = "";
		$scope.resetFilters = function () {
			// needs to be a function or it won't trigger a $watch
			$scope.searchTable = "";
		};

		// pagination controls
		$scope.currentPage = 1;
		$scope.totalItems = $scope.gridData.length;
		$scope.entryLimit = 8; // items per page
		$scope.noOfPages = Math.ceil($scope.totalItems / $scope.entryLimit);

		// $watch search to update pagination
		$scope.$watch('searchTable', function (newVal, oldVal) {
			$scope.filtered = filterFilter($scope.gridData, newVal);
			$scope.totalItems = $scope.filtered.length;
			$scope.noOfPages = Math.ceil($scope.totalItems / $scope.entryLimit);
			$scope.currentPage = 1;
		}, true);
	    
	    $scope.sort = {
	        column: 'Service_Name',
	        descending: false
	    };
	    
	    $scope.changeSorting = function(column) {
	    	console.log("fsdf",column);
	        var sort = $scope.sort;
	        if (sort.column == column) {
	            sort.descending = !sort.descending;
	        } else {
	            sort.column = column;
	            sort.descending = false;
	        }
	    };
		
		},
	    function(result) {
	        console.log("Failed to get the name, result is " + result); 
	});

	

  }]);
