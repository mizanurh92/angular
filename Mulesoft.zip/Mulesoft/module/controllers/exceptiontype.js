angularApp.controller('exceptionTypeCtrl',['$scope','filterFilter','errorDataService' , function ($scope,filterFilter,errorDataService) {
    errorDataService.getTabledata('http://10.102.55.149:9082/exceptionType').then(function(responseData) { 
    $scope.head = {

    		   exceptionCode: "Exception Code",
    		   exceptionName: "Exception Name",
    		   categoryType: "Category",  
    	       recoveryCode :"Recovery"
//    	       isCritical: "IS Critical",
//    	       isRecoverable: "IS Recoverable"
		};
    
    $scope.gridData = {
       contacts: responseData,
    };
    $scope.exceptionCategoryName=[];
    $scope.exceptionRecoveryCode=[];
    errorDataService.getTabledata(host+'/categories').then(function(responseData) { 
		$scope.exceptionSelectBox = responseData;
		for(var i=0;i<$scope.gridData.contacts.length;i++){
    		for(var j=0;j<$scope.exceptionSelectBox.length;j++){
    		if($scope.gridData.contacts[i].categoryId==$scope.exceptionSelectBox[j].categoryId){
    				$scope.exceptionCategoryName.push($scope.exceptionSelectBox[j]);
    			
    			}	
    		}
    		
    	}
    	console.log($scope.exceptionCategoryName);
	},
    	    function(result) {
        console.log("Failed to get the name, result is " + result); 
});
    errorDataService.getTabledata(host+'/getExceptionRecovery').then(function(responseData) { 
		$scope.recoveryCodeList = responseData;
		for(var i=0;i<$scope.gridData.contacts.length;i++){
    		for(var j=0;j<$scope.recoveryCodeList.length;j++){
    		if($scope.gridData.contacts[i].recoveryId==$scope.recoveryCodeList[j].recoveryId){
    			$scope.exceptionRecoveryCode.push($scope.recoveryCodeList[j]);
    			
    			}	
    		}
    		
    	}
	},
    	    function(result) {
        console.log("Failed to get the name, result is " + result); 
	});
    //pagination
	// create empty search model (object) to trigger $watch on update
	$scope.searchTable = "";
	$scope.resetFilters = function () {
		// needs to be a function or it won't trigger a $watch
		$scope.searchTable = "";
	};

	// pagination controls
	$scope.currentPage = 1;
	$scope.totalItems = $scope.gridData.contacts.length;
	$scope.entryLimit = 8; // items per page
	$scope.noOfPages = Math.ceil($scope.totalItems / $scope.entryLimit);

	// $watch search to update pagination
	$scope.$watch('searchTable', function (newVal, oldVal) {
		$scope.filtered = filterFilter($scope.gridData.contacts, newVal);
		$scope.totalItems = $scope.filtered.length;
		$scope.noOfPages = Math.ceil($scope.totalItems / $scope.entryLimit);
		$scope.currentPage = 1;
	}, true);
    
    $scope.sort = {
        column: 'Service_Name',
        descending: false
    };
    
    $scope.changeSorting = function(column) {
    	console.log("fsdf",column);
        var sort = $scope.sort;
        if (sort.column == column) {
            sort.descending = !sort.descending;
        } else {
            sort.column = column;
            sort.descending = false;
        }
    };
 
    },
	   function(result) {
    		console.log("Failed to get the name, result is " + result); 
	});

  }]);
