angularApp.controller('activityLogCtrl',['$scope','filterFilter','newDataService', function ($scope,filterFilter,newDataService) {
	$scope.showPopModal = false;
	newDataService.getnewTabledata(host1+'/events').then(function(responseData) { 
	
	  $scope.gridData = {
		       contacts: responseData
		 
		    };
	  
	  
	 
	    
	  //pagination
		// create empty search model (object) to trigger $watch on update
		$scope.searchTable = "";
		$scope.resetFilters = function () {
			// needs to be a function or it won't trigger a $watch
			$scope.searchTable = "";
		};

		// pagination controls
		$scope.currentPage = 1;
		//$scope.totalItems = $scope.gridData.length;
		$scope.entryLimit = 8; // items per page
		$scope.noOfPages = Math.ceil($scope.totalItems / $scope.entryLimit);

		// $watch search to update pagination
//		$scope.$watch('searchTable', function (newVal, oldVal) {
//			$scope.filtered = filterFilter($scope.gridData, newVal);
//			$scope.totalItems = $scope.filtered.length;
//			$scope.noOfPages = Math.ceil($scope.totalItems / $scope.entryLimit);
//			$scope.currentPage = 1;
//		}, true);
//	    
	    $scope.sort = {
	        column: 'Time',
	        descending: false
	    };
	    
	    $scope.changeSorting = function(column) {
	    	console.log("fsdf",column);
	        var sort = $scope.sort;
	        if (sort.column == column) {
	            sort.descending = !sort.descending;
	        } else {
	            sort.column = column;
	            sort.descending = false;
	        }
	    };
		
		},
	    function(result) {
	        console.log("Failed to get the name, result is " + result); 
	});
	   /* var modal = document.getElementById('myModal');

		// Get the button that opens the modal
		var btn = document.getElementById("myBtn");

		// Get the <span> element that closes the modal
		var span = document.getElementsByClassName("close")[0];

		// When the user clicks the button, open the modal 
		btn.onclick = function() {
		    modal.style.display = "block";
		}

		// When the user clicks on <span> (x), close the modal
		span.onclick = function() {
		    modal.style.display = "none";
		}*/
	$scope.showPopWindow = function(){
		newDataService.getnewTabledata(host1+'/activities').then(function(responseData) { 
			$scope.showPopModal = true;
			$scope.data = responseData;
		},
	    function(result) {
	        console.log("Failed to get the name, result is " + result); 
	});
		
	}
	$scope.cancel = function() {
		  $scope.showModal = false;
		};
	

  }]);
