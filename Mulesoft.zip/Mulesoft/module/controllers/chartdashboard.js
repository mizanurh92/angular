angularApp.controller('pieChartController',['$scope','dataService' , function ($scope,dataService) {  

	$scope.bar = false;
	$scope.pieDiv = false;
	$scope.sortChartBy = "day";
	$scope.showExceptionDescription = false;
// Load Charts and the corechart and barchart packages.
  google.charts.load('current', {'packages':['corechart','bar']});

  // Draw the pie chart and bar chart when Charts is loaded.
  google.charts.setOnLoadCallback(drawPieChart); 
  google.charts.setOnLoadCallback(drawBarChartHour); 
  
  function drawPieChart() {
	  $scope.pieDiv = true;
	  dataService.getData(host+'/getCategoryExceptions').then(function(rowsData) { 
		  var data = new google.visualization.DataTable();
		    
		    data.addColumn('string', 'Error Type');
		    data.addColumn('number', 'Frequency');
		    
		    var result = [];
		    for(var i in rowsData)
		    	result.push([rowsData[i].Category,parseInt(rowsData[i].ExceptionCount)]);
		    
		    data.addRows(result);
		    
		    var piechart_options = {
		    		title: 'Exception Per Category',
		    		is3D: true,
		    		tooltip: {isHtml: true},
		    		chartArea:{left:0,top:10,width:"65%", right:80,bottom:20,height:"80%"},
		    		height:250
		    		};
		    
		    var piechart = new google.visualization.PieChart(document.getElementById('piechart_div'));
		    piechart.draw(data, piechart_options);
		    
		    google.visualization.events.addListener(piechart, 'select', selectHandler);
		    
		    function selectHandler(e) {
		    		chartObject = piechart.getSelection(piechart);
		    		
		    		$scope.showExceptionDescription = true;
		    		
		    		var categoryValue = data.getValue(chartObject[0].row, 0);
		    		/*var value1 = data.getValue(chartObject[0].row, 1);*/
		    		dataService.getData(host+'/getExceptionInfo?category='+categoryValue).then(function(data){
		    			$scope.rowsData = data;
			    		
		    		},
		    		function(result) {
		    	                console.log("Failed to get the name, result is " + result); 
		    	        });
		    		
		    	  
		    	}
	  },
		  
		    function(result) {
                console.log("Failed to get the name, result is " + result); 
        });
	
   
  };
 
	  function drawBarChartHour() {
		  $scope.sortChartBy = "week";
		  $scope.bar = true;
		  dataService.getBarData(host+'/getExceptionsCount?time='+$scope.sortChartBy).then(function(rowsData) { 
		  var data = new google.visualization.DataTable();
		  	
		    data.addColumn('string', 'Exception Code');
		    data.addColumn('number', 'Count');
		    
		    var result = [];
		    for(var i in rowsData)
		    	result.push([rowsData[i].ExceptionCode,rowsData[i].ExceptionCount]);
		    
		    data.addRows(result);
	
		    var barchart_options = {title:'Barchart',
		                   height:300,
		                   legend: 'none'};
		    var barchart = new google.charts.Bar(document.getElementById('barchart_div'));
		    barchart.draw(data, barchart_options);
		    
		  },
		  
		    function(result) {
	          console.log("Failed to get the name, result is " + result); 
	  });
		    
};
  
  $scope.showCharts = function(){
		  google.charts.setOnLoadCallback(drawBarChartHour); 
  };
  
}]);
