/**
 * Author : Michael Dpenha
 * 
 */

import { BrowserModule } from '@angular/platform-browser';
import { NgModule,CUSTOM_ELEMENTS_SCHEMA } from '@angular/core'
import { CommonModule } from '@angular/common';
import { RouterOutlet } from '@angular/router';
import { HttpModule } from '@angular/http';
import { FormsModule } from '@angular/forms'

import { AppComponent } from './app.component';
import { AppRoutingModule,routedComponents } from './app.routing';
import { CommonComponents,commonComponents  } from './common/index';

import { ReusableComponents,reusableComponents  } from './component/index';

import { SidebarService } from './common/sidebar/sidebar.service';
import { RouteService } from './services/route.service';
import { UsersComponent } from './component/users/users.component';
import {DataService} from './services/data.service';
import { DataTranferComponent } from './component/data-tranfer/data-tranfer.component';
import { ChildUsersComponent } from './component/child-users/child-users.component';
import { AuthGuard } from './auth.guard';
import { AllPipePipe } from './all-pipe.pipe';
@NgModule({
  declarations: [
    AppComponent,
    routedComponents,
    commonComponents,
    reusableComponents,
    UsersComponent,
    DataTranferComponent,
    ChildUsersComponent,
    AllPipePipe
  ],
  imports: [
    BrowserModule,
    CommonModule,
    AppRoutingModule,
    HttpModule,
    FormsModule
  ],
  providers: [SidebarService,RouteService,DataService,AuthGuard],
  bootstrap: [AppComponent],
  schemas: [ CUSTOM_ELEMENTS_SCHEMA ]
})
export class AppModule { }
