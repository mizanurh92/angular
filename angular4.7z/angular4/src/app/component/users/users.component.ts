import { Component, OnInit , ViewChild} from '@angular/core';
import { DataService } from '../../services/data.service';
import { Http, Response } from '@angular/http';
import {DataTranferComponent} from './../data-tranfer/data-tranfer.component'

@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.css']
})
export class UsersComponent implements OnInit {
  name: string;
  age: number;
  hobbies:string[];
  address:Address;
  fullname:any;
  isEditable:boolean;
  posts:Post[];
  comments=Comment;
  postComments=Comment;
  @ViewChild(DataTranferComponent) child;
  constructor(private dataservice : DataService, public http:Http) { }

  ngOnInit() {
    console.log("running inInit....");
    this.name="Mizanur";
    this.age=26;
    this.hobbies=['playing football','watching movies'];
    this.address={
      street:'talwade',
      city:'pune',
      state:'MA',
      zip:411062
    };
    this.fullname="Mizanur Hossain";
    this.isEditable=false;
    this.dataservice.getpostsonUserID().subscribe((allposts) => {
      this.posts=allposts;
      console.log(this.posts[0].userId);
    })
    this.dataservice.setName(this.fullname);
    this.dataservice.getComments().subscribe(allComments => {
      this.comments=allComments
    })
    this.dataservice.postComments().subscribe(allPostComments => {
      this.postComments=allPostComments;
    })
  }

  editUser(){
    this.isEditable= !this.isEditable;
  }
  receiveMessage($event) {
    this.fullname=$event;
  }

}
interface Address{
  street:string;
  city:string;
  state:string;
  zip:number
}
interface Post{
  userId:number,
  id:number,
  title:string,
  body:string
}
interface Comments{
  body:string;
}
