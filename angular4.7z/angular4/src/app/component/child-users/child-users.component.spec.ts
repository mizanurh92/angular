import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ChildUsersComponent } from './child-users.component';

describe('ChildUsersComponent', () => {
  let component: ChildUsersComponent;
  let fixture: ComponentFixture<ChildUsersComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ChildUsersComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ChildUsersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
