import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router'

@Component({
  selector: 'app-child-users',
  templateUrl: './child-users.component.html',
  styleUrls: ['./child-users.component.css']
})
export class ChildUsersComponent implements OnInit {
  allparasms:any;
  constructor(private route: ActivatedRoute) { }

  ngOnInit() {
    this.route.paramMap.subscribe(params => {
      this.allparasms=params.get("id");
    })
  }

}
