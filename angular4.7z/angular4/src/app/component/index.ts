import { ListComponent } from './list/list.component';

export class ReusableComponents { }
export const reusableComponents = [ListComponent ];