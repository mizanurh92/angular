import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-checkbox',
  templateUrl: './checkbox.component.html',
  styleUrls: ['./checkbox.component.css']
})
export class CheckboxComponent implements OnInit {

  constructor() { }
	private saveUsername: boolean = true;
    private autoLogin: boolean = true;
	  ngOnInit() {
			console.log("inside code")

  }

}


    