import { Component, OnInit  , Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'list-component',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.css']
})
export class ListComponent{
  autoRender : boolean = true;
  Items : any = [];
  
  @Input('data') data : any;
  
  @Output('select') selectEvent = new EventEmitter<any>();

  constructor() {
    
  }
  onSelect(event:any){
    this.selectEvent.emit(event);
  }
  ngOnInit() {
    if(this.autoRender){
      this.createInstance();
    }
  }

  private createInstance (){
    this.Items = this.data;
  }

}
  