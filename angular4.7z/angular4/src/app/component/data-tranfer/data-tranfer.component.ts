import { Component, OnInit , Input , Output, EventEmitter} from '@angular/core';

@Component({
  selector: 'app-data-tranfer',
  templateUrl: './data-tranfer.component.html',
  styleUrls: ['./data-tranfer.component.css']
})
export class DataTranferComponent implements OnInit {
  @Input() public childMassage: string;
  message: string = "Hola Mundo!";
  @Output() messageEvent= new EventEmitter<string>()
  constructor() { }

  ngOnInit() {
  }
  sendMessage(){
    this.messageEvent.emit(this.message)
  }
}
