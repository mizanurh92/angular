import { AllPipePipe } from './all-pipe.pipe';

describe('AllPipePipe', () => {
  it('create an instance', () => {
    const pipe = new AllPipePipe();
    expect(pipe).toBeTruthy();
  });
});
