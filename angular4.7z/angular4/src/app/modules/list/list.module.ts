import { Component, OnInit } from '@angular/core';
import {ListComponent} from '../../component/list/list.component';

@Component({
  selector: 'list-module',
  templateUrl: './list.module.html',
  styleUrls: ['./list.module.css']
})
export class ListModule implements OnInit {
  data : string[] =['Michael Dpenha','Sumeet Somnavane','Mayur Patil','Sachin Rajput','Rutuja Swami','Tejashree Deshmukh','Mantej']; 
  constructor() { }

  ngOnInit() {
  }
  onSelection (event : any){
    alert('test')
  }

}
