import { TestBed, inject } from '@angular/core/testing';
import {EventEmitter} from '@angular/core';
import { RouteService } from './route.service';
import { RouterTestingModule } from '@angular/router/testing';
class MockRouter {
    navigateByUrl(url: string) { return url; }
}
describe('RouteService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule],
      providers: [{ provide: RouteService, useClass: MockRouter }]
    });
  });

  it('should be created', inject([RouteService], (service: RouteService) => {
    expect(service).toBeTruthy();
  }));
});
