import { Injectable } from '@angular/core';
import { Http, Response } from '@angular/http';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/toPromise';

@Injectable()
export class DataService {
  newName: string;
  constructor(public http:Http) { }
  getposts(){
    return this.http.get('https://jsonplaceholder.typicode.com/posts').map(res => res.json());
  }
  getpostsonUserID(){
    return this.http.get('https://jsonplaceholder.typicode.com/posts?userId=1').map(res => res.json());
  }
  getComments(){
    return this.http.get('https://jsonplaceholder.typicode.com/posts/1/comments').map(res => res.json());
  }
  postComments(){
    return this.http.post('https://jsonplaceholder.typicode.com/posts', JSON.stringify({
      userId: 1
    })).map(res => res.json())
  }
  setName(name:string){
    this.newName=name;
  }
  getName(){
    return this.newName;
  }
}
