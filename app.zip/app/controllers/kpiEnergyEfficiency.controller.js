/* 
 *  ================================================================================
 *  Copyright (C) 2017
 */

(function() {
	'use strict';
	
	AppModule.controller('kpiEnergyEffController', ['$scope', 'AppService', "AppConst", "$route","$interval", kpiEnergyEffController]);
	
	function kpiEnergyEffController($scope, AppService,AppConst, $route,$interval) {
		
		var vm = this;
		
		vm.init = function() {
			var kpiAvailabilityURL = '/ops/opskpi/getEnergyEfficiency?siteId='+'sdslab'+'&kpiCategory='+'EnergyEfficiency';
			AppService.getData(1, kpiAvailabilityURL).then(function(response) {
	        	   if (response.status === 200 && response.data) {
	        		 vm.energyEfficiencyData = response.data;
					 var obj=[];
					 console.log(parseInt(vm.energyEfficiencyData[3].CustomerTarget));
	        		 for(var i=0;i<vm.energyEfficiencyData.length;i++) {
	        			  if(vm.energyEfficiencyData[i].KpiName=="PowerUsageEffectiveness"){
	        				  vm.powerUsageEffectiveness = vm.energyEfficiencyData[i];
	        			  }
	        			  else if(vm.energyEfficiencyData[i].KpiName=="TotalEnergyConsumed") {
	        				  vm.totalEnergyConsumed = vm.energyEfficiencyData[i];
	        			  }
	        			  else if(vm.energyEfficiencyData[i].KpiName=="TotalEnergyCost") {
	        				  vm.totalEnergyCost = vm.energyEfficiencyData[i];
	        			  }
	        			  else if(vm.energyEfficiencyData[i].KpiName=="CarbonUsageEffectiveness") {
	        				  vm.carbonUsageEffectiveness = vm.energyEfficiencyData[i];
	        			  }
	        			  
	        			   obj[i] = JSON.parse(vm.energyEfficiencyData[i].KpiValues);
						     var graphdata=[];
							   for(var m=0;m<obj[i].length;m++){
									if(obj[i][m].February !=undefined){
										var Febvalue=obj[i][m].February;
										graphdata.push(Febvalue);
									}
									else if(obj[i][m].March !=undefined){
										 var Marchvalue=obj[i][m].March;
										 graphdata.push(Marchvalue);
									 }
									 else if(obj[i][m].April !=undefined){
										 var Aprilvalue=obj[i][m].April;
										 graphdata.push(Aprilvalue);
									 }
									 else if(obj[i][m].May !=undefined){
										 var Mayvalue=obj[i][m].May;
										 graphdata.push(Mayvalue);
									 }
									else if(obj[i][m].June !=undefined){
										 var Junevalue=obj[i][m].June;
										 graphdata.push(Junevalue);
									 }
									 else if(obj[i][m].July !=undefined){
										 var Julyvalue=obj[i][m].July;
										 graphdata.push(Julyvalue);
									 }
									 else if(obj[i][m].August !=undefined){
										 var Augvalue=obj[i][m].August;
										 graphdata.push(Augvalue);
									 }
									 else if(obj[i][m].September !=undefined){
										 var Sepvalue=obj[i][m].September;
										 graphdata.push(Sepvalue)
									 }
									 else if(obj[i][m].October !=undefined){
										 var Octvalue=obj[i][m].October;
										 graphdata.push(Octvalue)
									 }
									 else if(obj[i][m].November !=undefined){
										 var Novvalue=obj[i][m].November;
										 graphdata.push(Novvalue)
									 }
									 else if(obj[i][m].December !=undefined){
										 var Decvalue=obj[i][m].December;
										 graphdata.push(Decvalue)
									 }
									 else if(obj[i][m].January !=undefined){
										 var janvalue=obj[i][m].January;
										 graphdata.push(janvalue)
									 }
									}
								var customarTarget=[];
									for(var a=0;a<obj[i].length;a++){
										customarTarget.push(parseFloat(vm.energyEfficiencyData[i].CustomerTarget));
									}
						
						var chart = Highcharts.chart(vm.energyEfficiencyData[i].KpiName, {
							colors: ['rgb(124, 181, 236)','red'],
							xAxis: {       
							   labels: {
								   enabled: false
							   },
							   minorTickLength: 0,
							   tickLength: 0
							},
							yAxis:{ 
							  gridLineWidth: 0,
							  minorGridLineWidth: 0
							},
							series: [
							{
								name: 'Data1',
								type: 'column',
								colorByPoint: false,
								//data: [json.KPIValues[0].Jun,json.KPIValues[1].April,json.KPIValues[2].Mar,json.KPIValues[3].Feb],
								data:graphdata,
								showInLegend: false
							},
							{
								name: 'avarage',
								type: 'spline',
								colorByPoint: false,
								data: customarTarget,
								showInLegend: false
							}]

					});
					chart.setSize("230", "130");
	        		  }
	        		  
	        		  
	                }
	           });		
		}
		 //Trigger initial l oading - every 10 secs interval start
        var refreshPage = function() {
              $route.reload();

        };
        var interval = $interval(refreshPage, AppConst.CONST_PAGEREFRESHTIME.ONE_MINUTE);
        $scope.$on('$destroy', function() {
              $interval.cancel(interval);
        });
        //end
		vm.init();
	}
	
}());