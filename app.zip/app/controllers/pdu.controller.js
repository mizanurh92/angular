/* 
 *  ================================================================================
 *  Copyright (C) 2017
 */ 

(function() {
	'use strict';
	
	AppModule.controller("pduController",["$scope","AppConst","AppService","$interval","$route", pduController]);

	function pduController($scope,AppConst,AppService,$interval,$route) {
		var vm=this;
		
		vm.init = function(){

			$scope.tooltipOptions = {} ;
			$scope.tooltipOptions.contentAsHTML = true;			
			var pduDiagramStatusUrl = "/ops/opsmodule/pdudiagramstatus";
			
			var _equipmentAndAttributeList =	{
					"site":"sdslab",
					"values":[{
					   "equipmentID":"mdbVoltage",
					   "attributeName":"phaseA"                               
					},
					{ "equipmentID":"mdbVoltage",
					  "attributeName":"phaseB"                               
					},
					{ "equipmentID":"mdbVoltage",
						  "attributeName":"phaseC"                               
					},
					{ "equipmentID":"mdbVoltage",
						  "attributeName":"incoming"                               
					},
					{ "equipmentID":"mdbVoltage",
					  "attributeName":"tripstatus"                               
					},
					{
						   "equipmentID":"cracDBVoltage",
						   "attributeName":"phaseA"                               
						},
						{ "equipmentID":"cracDBVoltage",
						  "attributeName":"phaseB"                               
						},
						{ "equipmentID":"cracDBVoltage",
							  "attributeName":"phaseC"                               
						},
						{ "equipmentID":"cracDBVoltage",
							  "attributeName":"incoming"                               
						},
						{ "equipmentID":"cracDBVoltage",
						  "attributeName":"tripstatus"                               
						}
					]
				};

			
			_equipmentAndAttributeList = JSON.parse(angular.toJson(_equipmentAndAttributeList));
			
			AppService.postData(_equipmentAndAttributeList,pduDiagramStatusUrl).then(function(response) {
                if (response.status === 200 && response.data) {
                	
                	var assetList=response.data;
                	 for (var i = 0; i < assetList.length; i++) {
                		 
                    	 var assetId = assetList[i].assetId;
                    	 var attributeVal = response.data[i].attributeVal;
                    	 var attributeName = response.data[i].attributeName;
                    	 var assetStatus = response.data[i].assetStatus;
                    	 vm[assetId+"_"+attributeName]=attributeVal;
                    	 if("CR"==response.data[i].assetStatus){
                    	   vm[assetId+"_status_Indicator"]="statusRed";
                    	 }
                    	 else{
                    	   vm[assetId+"_status_Indicator"]="statusGreen";
                    	 }

                    }
                	 
//                vm['mdbVoltage_phaseA']=500;	 
                vm['mdbVoltage_totalAvg']=parseFloat((parseInt(vm['mdbVoltage_phaseA'])+parseInt(vm['mdbVoltage_phaseB'])+parseInt(vm['mdbVoltage_phaseC']))/3).toFixed(2);
                drawPduMeter("mdbVoltagePdu",vm['mdbVoltage_totalAvg']);
                drawPduMeter("mdbCurrent");
    			drawPduMeter("cracDBVoltage");
    			drawPduMeter("cracDBCurrent");
    			

                 }
            });
			
			
//			drawPduMeter("mdbVoltage",vm['mdbVoltage_totalAvg']);
//			drawPduMeter("mdbCurrent");
//			drawPduMeter("cracDBVoltage");
//			drawPduMeter("cracDBCurrent");
			
			//Trigger initial loading - every 10 secs interval start
			var refreshPage = function() {
				$route.reload();

			};
			var interval = $interval(refreshPage, AppConst.CONST_PAGEREFRESHTIME.TEN_SECONDS);
			$scope.$on('$destroy', function() {
				$interval.cancel(interval);
			});
			//end
			
		
		}
		               vm.init();
		           	
		    function drawPduMeter(divid,value){
		    	
		    	Highcharts.chart(divid, {

		    	    chart: {
		    	        type: 'gauge',
		    	        plotBackgroundColor: null,
		    	        plotBackgroundImage: null,
		    	        plotBorderWidth: 0,
		    	        backgroundColor:'black',
		    	        plotShadow: false
		    	    },

		    	    title: {
		    	        text: null
		    	    },

		    	    pane: {
		    	        startAngle: -130,
		    	        endAngle: 130,
		    	        background: [ {
		    	            // default background
		    	        }, {
		    	            backgroundColor: '#DDD',
		    	            borderWidth: 0,
		    	            outerRadius: '105%',
		    	            innerRadius: '103%'
		    	        }]
		    	    },

		    	    // the value axis
		    	    yAxis: {
		    	        min: 0,
		    	        max: 200,

		    	        minorTickInterval: 'auto',
		    	        minorTickWidth: 1,
		    	        minorTickLength: 10,
		    	        minorTickPosition: 'inside',
		    	        minorTickColor: '#666',

		    	        tickPixelInterval: 30,
		    	        tickWidth: 2,
		    	        tickPosition: 'inside',
		    	        tickLength: 10,
		    	        tickColor: '#666',
		    	        labels: {
		    	            step: 2,
		    	            rotation: 'auto'
		    	        },
		    	        title: {
		    	            text: 'V',
		    	            y:15
		    	        },
		    	        plotBands: [{
		    	            from: 0,
		    	            to: 120,
		    	            color: '#55BF3B' // green
		    	        }, {
		    	            from: 120,
		    	            to: 160,
		    	            color: '#DDDF0D' // yellow
		    	        }, {
		    	            from: 160,
		    	            to: 200,
		    	            color: '#DF5353' // red
		    	        }]
		    	    },

		    	    series: [{
		    	        name: 'Voltage',
		    	        data: [parseInt(value)],//[value]parseFloat(scope.data),
		    	        tooltip: {
		    	            valueSuffix: 'V'
		    	        }
		    	    }],
		    	    exporting: {
		                enabled: false
		            }

		    	});
		    	
		    }           
		               
		} // closing activeEventsController
	
}())
