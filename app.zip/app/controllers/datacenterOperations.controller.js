/* 
 *  ================================================================================
 *  Copyright (C) 2017
 */ 
(function() {
	'use strict';
	AppModule.controller("datacenterOperationsController",["$scope","AppConst",datacenterOperationsController]);

	function datacenterOperationsController($scope,AppConst) {
		var vm=this;
		vm.datacenterOperations = "DATA CENTER OPERATIONS";
	}
	
}())
