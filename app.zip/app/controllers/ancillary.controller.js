/* 
 *  ================================================================================
 *  Copyright (C) 2017
 */ 

(function() {
	'use strict';
	
	AppModule.controller("ancillaryController",["$scope","AppConst","AppService","$interval","$route",ancillaryController]);

	function ancillaryController($scope,AppConst,AppService,$interval,$route) {
		var vm=this;
		
		vm.init = function(){
			
			var ancilliarystatusUrl = "/ops/opsmodule/ancilliarystatus";
			
			var _equipmentAndAttributeList =	{
					"site":"sdslab",
					"values":[{
					   "equipmentID":"BD-DC2-WDS",
					   "attributeName":"2ndAlaram"                               
					},
					{ "equipmentID":"BD-DC2-WDS",
					  "attributeName":"1stAlaram"                               
					 },
					{ "equipmentID":"BD-DC1-WDS",
					  "attributeName":"WaterDetected"                               
					 },
					 { "equipmentID":"BD-DC1-WDS",
					  "attributeName":"systemstatus"                               
					 }
					]
				};

			
			_equipmentAndAttributeList = JSON.parse(angular.toJson(_equipmentAndAttributeList));
			
			AppService.postData(_equipmentAndAttributeList,ancilliarystatusUrl).then(function(response) {
                if (response.status === 200 && response.data) {
                	
                	var assetList=response.data;
                	 for (var i = 0; i < assetList.length; i++) {
                		 
                		 var assetId = assetList[i].assetId;
                		 var attributeName = assetList[i].attributeName;
                		 
                		 if("BD-DC1-WDS"==assetId && "WaterDetected"==attributeName){
                			 vm.WaterDetected=response.data[i].attributeVal; 
                		 }
                		 
                		 else if("BD-DC1-WDS"==assetId && "systemstatus"==attributeName){
                			 vm.systemstatus=response.data[i].attributeVal; 
                		 }
                		 
                		 
                		 else if("BD-DC2-WDS"==assetId && "1stAlaram"==attributeName){
                			 vm.fstAlaram=response.data[i].attributeVal; 
                		 }
                		 
                		 else if("BD-DC2-WDS"==assetId && "2ndAlaram"==attributeName){
                			 vm.sndAlaram=response.data[i].attributeVal; 
                		 }
                		 
//                    	 var attributeVal = response.data[i].attributeVal; 
//                    	 vm[assetId+"_VAl"]=attributeVal;
//                    	 if("CR"==response.data[i].assetStatus){
//                    		 vm.BD-DC1-WDS_status="statusRed";
                    		 vm["BD-DC1-WDS_status"]="statusRed"; 
//                    	 }
                    	
                    }

                 }
            });
		               
		}
		
		//Trigger initial l oading - every 10 secs interval start
        var refreshPage = function() {
              $route.reload();

        };
        var interval = $interval(refreshPage, AppConst.CONST_PAGEREFRESHTIME.ONE_MINUTE);
        $scope.$on('$destroy', function() {
              $interval.cancel(interval);
        });
        //end
		               
		               vm.init();
	
			
		} // closing activeEventsController
		
		
		
	
	
}())
