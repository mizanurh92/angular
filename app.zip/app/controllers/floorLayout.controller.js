/* 
 *  ================================================================================
 *  Copyright (C) 2017
 */
(function() {
    'use strict';
    AppModule.controller("floorLayoutController", ["$scope", "AppConst", "AppService", "$interval", "$route", "PanZoomService", "$routeParams", "$sessionStorage", floorLayoutController]);

    function floorLayoutController($scope, AppConst, AppService, $interval, $route, PanZoomService, $routeParams, $sessionStorage) {
        var vm = this;
        vm.siteid = $routeParams.siteid;
        //		[RTH1-OPERATINGMODE, TSB61A1-UTILIZATIONCAPACITY]
        vm.datacenterOperations = "This is our Floor Layout1";
        //vm.Equipmentvalue=10;
        $scope.samplescope = "VMMMMMM";
        vm.equipmentId = "USTLAB-KBT-RACK9";
        $scope.RAC = [
            /*{model : "Rack Capacity",value:"CapacityDesignLimit"},*/
            {
                model: "Rear Temp/ RH",
                value: "RearTemperature"
            },
            {
                model: "Front Temp/ RH",
                value: "FRTTemperature"
            }
        ];
        vm.equipmentList = ["RTH1"];

        vm.init = function() {

            vm.CRFilter = true;
            vm.WRFilter = true;
            vm.MRFilter = true;
            $sessionStorage.CRFilter = vm.CRFilter;
            $sessionStorage.WRFilter = vm.WRFilter;
            $sessionStorage.MRFilter = vm.MRFilter;

            if ($scope.selectedRac == undefined && null == sessionStorage.getItem("attributeName")) {
                vm.equipmentId = "USTLAB-KBT-RACK9";
                $scope.selectedRac = "FRTTemperature";
                sessionStorage.setItem("equipmentId", vm.equipmentId);
                sessionStorage.setItem("attributeName", $scope.selectedRac);
            }

            if ($scope.selectedRac == "CapacityDesignLimit") {
                vm.equipmentId = "USTLAB-KBT-RACK9";
                sessionStorage.setItem("equipmentId", vm.equipmentId);
                sessionStorage.setItem("attributeName", $scope.selectedRac);
            } else if ($scope.selectedRac == "RearTemperature") {
                vm.equipmentId = "USTLAB-KBT-RACK9-RS";
                sessionStorage.setItem("equipmentId", vm.equipmentId);
                sessionStorage.setItem("attributeName", $scope.selectedRac);
            } else if ($scope.selectedRac == "FRTTemperature") {
                vm.equipmentId = "USTLAB-KBT-RACK9-FS";
                sessionStorage.setItem("equipmentId", vm.equipmentId);
                sessionStorage.setItem("attributeName", $scope.selectedRac);
            } else {
                /*vm.equipmentId = "USTLAB-KBT-RACK9";
                $scope.selectedRac = "CapacityDesignLimit";
                */
                vm.equipmentId = sessionStorage.getItem("equipmentId");;
                $scope.selectedRac = sessionStorage.getItem("attributeName");

            }
            $scope.tooltipOptions = {};
            $scope.tooltipOptions.contentAsHTML = true;
            var floorLayoutStatusUrl = "/ops/engie/flayout/floorlayoutstatus";
            var _equipmentAndAttributeList = {
                "site": "ustlab",
                "values": [{
                        "equipmentID": "RTH1",
                        "attributeName": "AmbientTemperature"
                    },
                    {
                        "equipmentID": vm.equipmentId,
                        "attributeName": $scope.selectedRac
                    }
                ]
            };


            _equipmentAndAttributeList = JSON.parse(angular.toJson(_equipmentAndAttributeList));

            AppService.postData(_equipmentAndAttributeList, floorLayoutStatusUrl).then(function(response) {
                if (response.status === 200 && response.data) {
                    vm.rackData = response.data;
                    var assetList = response.data;
                    for (var i = 0; i < assetList.length; i++) {

                        var assetId = assetList[i].assetId;
                        if (assetId.includes("RACK9")) {
                            assetId = "RACK9";
                        }
                        var attributeVal = response.data[i].attributeVal;
                        var assetIdVAL = assetId + "_VAl";
                        vm[assetIdVAL] = parseFloat(attributeVal).toFixed(2);
                        vm.assetIdName = assetId;

                        if ("CR" == response.data[i].assetStatus) {
                            vm[assetId + "_status"] = "statusBullet statusBulletBlinker statusRed";
                        } else if ("WR" == response.data[i].assetStatus) {
                            vm[assetId + "_status"] = "statusBullet statusBulletBlinker statusYellow";
                        } else {
                            vm[assetId + "_status"] = "statusBullet statusBulletBlinker statusGreen";
                        }

                        thresholdCheck(attributeVal, assetId);
                    }

                }
            });



            var dcFloor = {
                x: 55,
                y: -105,
                width: 310,
                height: 600
            };

            $scope.panzoomConfig = {
                zoomLevels: 3.1,
                neutralZoomLevel: 1.99,
                scalePerZoomLevel: 1.34,
                initialZoomToFit: dcFloor
            };

            // The panzoom model should initialle be empty; it is initialized by the <panzoom>
            // directive. It can be used to read the current state of pan and zoom. Also, it will
            // contain methods for manipulating this state.
            $scope.panzoomModel = {};


        };

        vm.selectedRacVal = function() {
            if ($scope.selectedRac == undefined && null == sessionStorage.getItem("attributeName")) {
                vm.equipmentId = "USTLAB-KBT-RACK9";
                $scope.selectedRac = "FRTTemperature";
                sessionStorage.setItem("equipmentId", vm.equipmentId);
                sessionStorage.setItem("attributeName", $scope.selectedRac);
            }
            if ($scope.selectedRac == undefined && null == sessionStorage.getItem("attributeName")) {
                vm.equipmentId = "USTLAB-KBT-RACK9";
                $scope.selectedRac = "FRTTemperature";
                sessionStorage.setItem("equipmentId", vm.equipmentId);
                sessionStorage.setItem("attributeName", $scope.selectedRac);
            }

            if ($scope.selectedRac == "CapacityDesignLimit") {
                vm.equipmentId = "USTLAB-KBT-RACK9";
                sessionStorage.setItem("equipmentId", vm.equipmentId);
                sessionStorage.setItem("attributeName", $scope.selectedRac);
            } else if ($scope.selectedRac == "RearTemperature") {
                vm.equipmentId = "USTLAB-KBT-RACK9-RS";
                sessionStorage.setItem("equipmentId", vm.equipmentId);
                sessionStorage.setItem("attributeName", $scope.selectedRac);
            } else if ($scope.selectedRac == "FRTTemperature") {
                vm.equipmentId = "USTLAB-KBT-RACK9-FS";
                sessionStorage.setItem("equipmentId", vm.equipmentId);
                sessionStorage.setItem("attributeName", $scope.selectedRac);
            } else {
                /*vm.equipmentId = "USTLAB-KBT-RACK9";
                $scope.selectedRac = "CapacityDesignLimit";
                */
                vm.equipmentId = sessionStorage.getItem("equipmentId");;
                $scope.selectedRac = sessionStorage.getItem("attributeName");

            }
            $scope.tooltipOptions = {};
            $scope.tooltipOptions.contentAsHTML = true;
            var floorLayoutStatusUrl = "/ops/engie/flayout/floorlayoutstatus";
            var _equipmentAndAttributeList = {
                "site": "ustlab",
                "values": [{
                        "equipmentID": "RTH1",
                        "attributeName": "AmbientTemperature"
                    },
                    {
                        "equipmentID": vm.equipmentId,
                        "attributeName": $scope.selectedRac
                    }
                ]
            };


            _equipmentAndAttributeList = JSON.parse(angular.toJson(_equipmentAndAttributeList));

            AppService.postData(_equipmentAndAttributeList, floorLayoutStatusUrl).then(function(response) {
                if (response.status === 200 && response.data) {
                    vm.rackData = response.data;
                    var assetList = response.data;
                    for (var i = 0; i < assetList.length; i++) {

                        var assetId = assetList[i].assetId;
                        if (assetId.includes("RACK9")) {
                            assetId = "RACK9";
                        }
                        var attributeVal = response.data[i].attributeVal;
                        var assetIdVAL = assetId + "_VAl";
                        vm[assetIdVAL] = parseFloat(attributeVal).toFixed(2);
                        vm.assetIdName = assetId;

                        if ("CR" == response.data[i].assetStatus) {
                            vm[assetId + "_status"] = "statusBullet statusBulletBlinker statusRed";
                        } else if ("WR" == response.data[i].assetStatus) {
                            vm[assetId + "_status"] = "statusBullet statusBulletBlinker statusYellow";
                        } else {
                            vm[assetId + "_status"] = "statusBullet statusBulletBlinker statusGreen";
                        }

                        thresholdCheck(attributeVal, assetId);
                    }

                }
            });
        };

        function thresholdCheck(attributeVal, assetId) {
            var threshold = 15.00
            if (attributeVal > threshold) {
                vm[assetId + "_color"] = "backgroundred";
            } else if (attributeVal == threshold) {
                vm[assetId + "_color"] = "backroundyellow";
            } else if (attributeVal < threshold) {
                vm[assetId + "_color"] = "backgroundgreen";
            }

        }

        vm.filterEquipmentsBySev = function(filterVal) {

            if (vm.CRFilter && !vm.WRFilter && !vm.MRFilter) {
                $("span").removeClass("statusGreen");
                $("span").removeClass("statusYellow");
                $("span.1-4, span.1-6").addClass("statusBullet statusBulletBlinker statusRed");
                $("span.2-2, span.2-5, span.2-8").addClass("statusBullet statusBulletBlinker statusRed");
                $("span.3-2, span.3-4, span.3-7").addClass("statusBullet statusBulletBlinker statusRed");
                $("span.4-1, span.4-3, span.4-5").addClass("statusBullet statusBulletBlinker statusRed");
            } else if (vm.WRFilter && !vm.CRFilter && !vm.MRFilter) {
                $("span").removeClass("statusGreen");
                $("span").removeClass("statusRed");
                $("span.1-5, span.1-7, span.1-8 ").addClass("statusBullet statusBulletBlinker statusYellow");
                $("span.2-3, span.2-6, span.2-9 ").addClass("statusBullet statusBulletBlinker statusYellow");
                $("span.3-3, span.1-6, span.1-8, span.1-9").addClass("statusBullet statusBulletBlinker statusYellow");
                $("span.4-2").addClass("statusBullet statusBulletBlinker statusYellow");
            } else if (vm.MRFilter && !vm.CRFilter && !vm.WRFilter) {
                $("span").removeClass("statusYellow");
                $("span").removeClass("statusRed");
                $("span.1-1, span.1-1, span.1-9").addClass("statusBullet statusBulletBlinker statusGreen");
                $("span.2-1, span.2-4, span.2-7").addClass("statusBullet statusBulletBlinker statusGreen");
                $("span.3-1, span.3-6").addClass("statusBullet statusBulletBlinker statusGreen");
                $("span.4-4").addClass("statusBullet statusBulletBlinker statusGreen");
            } else if ((vm.CRFilter && vm.WRFilter && vm.MRFilter) || (!vm.CRFilter && !vm.WRFilter && !vm.MRFilter)) {
                $("span").removeClass("statusGrey");
                $("span.1-1").addClass("statusBullet statusBulletBlinker statusGreen");
                $("span.1-2").addClass("statusBullet statusBulletBlinker statusGreen");
                $("span.1-3").addClass("statusBullet statusBulletBlinker statusYellow");
                $("span.1-4").addClass("statusBullet statusBulletBlinker statusRed");
                $("span.1-5").addClass("statusBullet statusBulletBlinker statusYellow");
                $("span.1-6").addClass("statusBullet statusBulletBlinker statusRed");
                $("span.1-7").addClass("statusBullet statusBulletBlinker statusYellow");
                $("span.1-8").addClass("statusBullet statusBulletBlinker statusYellow");
                $("span.1-9").addClass("statusBullet statusBulletBlinker statusGreen");

                $("span.2-1").addClass("statusBullet statusBulletBlinker statusGreen");
                $("span.2-2").addClass("statusBullet statusBulletBlinker statusRed");
                $("span.2-3").addClass("statusBullet statusBulletBlinker statusYellow");
                $("span.2-4").addClass("statusBullet statusBulletBlinker statusGreen");
                $("span.2-5").addClass("statusBullet statusBulletBlinker statusRed");
                $("span.2-6").addClass("statusBullet statusBulletBlinker statusYellow");
                $("span.2-7").addClass("statusBullet statusBulletBlinker statusGreen");
                $("span.2-8").addClass("statusBullet statusBulletBlinker statusRed");
                $("span.2-9").addClass("statusBullet statusBulletBlinker statusYellow");

                $("span.3-1").addClass("statusBullet statusBulletBlinker statusGreen");
                $("span.3-2").addClass("statusBullet statusBulletBlinker statusRed");
                $("span.3-3").addClass("statusBullet statusBulletBlinker statusYellow");
                $("span.3-4").addClass("statusBullet statusBulletBlinker statusRed");
                $("span.3-5").addClass("statusBullet statusBulletBlinker statusYellow");
                $("span.3-6").addClass("statusBullet statusBulletBlinker statusGreen");
                $("span.3-7").addClass("statusBullet statusBulletBlinker statusRed");
                $("span.3-8").addClass("statusBullet statusBulletBlinker statusYellow");
                $("span.3-9").addClass("statusBullet statusBulletBlinker statusYellow");

                $("span.4-1").addClass("statusBullet statusBulletBlinker statusRed");
                $("span.4-2").addClass("statusBullet statusBulletBlinker statusYellow");
                $("span.4-3").addClass("statusBullet statusBulletBlinker statusRed");
                $("span.4-4").addClass("statusBullet statusBulletBlinker statusGreen");
                $("span.4-5").addClass("statusBullet statusBulletBlinker statusRed");
            } else if (vm.CRFilter && vm.WRFilter && !vm.MRFilter) {
                $("span").removeClass("statusGreen");
                $("span.1-4, span.1-6").addClass("statusBullet statusBulletBlinker statusRed");
                $("span.2-2, span.2-5, span.2-8").addClass("statusBullet statusBulletBlinker statusRed");
                $("span.3-2, span.3-4, span.3-7").addClass("statusBullet statusBulletBlinker statusRed");
                $("span.4-1, span.4-3, span.4-5").addClass("statusBullet statusBulletBlinker statusRed");
                $("span.1-5, span.1-7, span.1-8 ").addClass("statusBullet statusBulletBlinker statusYellow");
                $("span.2-3, span.2-6, span.2-9 ").addClass("statusBullet statusBulletBlinker statusYellow");
                $("span.3-3, span.1-6, span.1-8, span.1-9").addClass("statusBullet statusBulletBlinker statusYellow");
                $("span.4-2").addClass("statusBullet statusBulletBlinker statusYellow");

            } else if (vm.CRFilter && !vm.WRFilter && vm.MRFilter) {
                $("span").removeClass("statusYellow");
                $("span.1-4, span.1-6").addClass("statusBullet statusBulletBlinker statusRed");
                $("span.2-2, span.2-5, span.2-8").addClass("statusBullet statusBulletBlinker statusRed");
                $("span.3-2, span.3-4, span.3-7").addClass("statusBullet statusBulletBlinker statusRed");
                $("span.4-1, span.4-3, span.4-5").addClass("statusBullet statusBulletBlinker statusRed");

                $("span.1-1, span.1-1, span.1-9").addClass("statusBullet statusBulletBlinker statusGreen");
                $("span.2-1, span.2-4, span.2-7").addClass("statusBullet statusBulletBlinker statusGreen");
                $("span.3-1, span.3-6").addClass("statusBullet statusBulletBlinker statusGreen");
                $("span.4-4").addClass("statusBullet statusBulletBlinker statusGreen");

            } else if (!vm.CRFilter && vm.WRFilter && vm.MRFilter) {
                $("span").removeClass("statusRed");
                $("span.1-5, span.1-7, span.1-8 ").addClass("statusBullet statusBulletBlinker statusYellow");
                $("span.2-3, span.2-6, span.2-9 ").addClass("statusBullet statusBulletBlinker statusYellow");
                $("span.3-3, span.1-6, span.1-8, span.1-9").addClass("statusBullet statusBulletBlinker statusYellow");
                $("span.4-2").addClass("statusBullet statusBulletBlinker statusYellow");

                $("span.1-1, span.1-1, span.1-9").addClass("statusBullet statusBulletBlinker statusGreen");
                $("span.2-1, span.2-4, span.2-7").addClass("statusBullet statusBulletBlinker statusGreen");
                $("span.3-1, span.3-6").addClass("statusBullet statusBulletBlinker statusGreen");
                $("span.4-4").addClass("statusBullet statusBulletBlinker statusGreen");

            }


        };


        //Trigger initial loading - every 10 secs interval start
        var refreshPage = function() {
            $route.reload();

        };
        var interval = $interval(refreshPage, AppConst.CONST_PAGEREFRESHTIME.ONE_MINUTE);
        $scope.$on('$destroy', function() {
            $interval.cancel(interval);
        });
        //end

        vm.init();

    }



}())