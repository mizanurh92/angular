/* 
 *  ================================================================================
 *  Copyright (C) 2017
 */
(function() {
    'use strict';
    AppModule.controller("operationOverviewController", ["$scope", "$rootScope", "AppConst", 'AppService', 'AppSettings', 
                                                         '$http','CommonService', "$location","$routeParams", "$sessionStorage", 
                                                         "$interval","$route",
                                                         operationOverviewController]);
	    function operationOverviewController($scope, $rootScope, AppConst, AppService, AppSettings, 
	    		$http, CommonService, $location, $routeParams,$sessionStorage,
	    		$interval,$route) {
			var vm=this;
			vm.operationOverview = "Operation Overview";
			vm.siteid = $routeParams.siteid;
			vm.serviceStartDate = $routeParams.serviceStartDate;
			vm.temperature = "Temperature";
	        vm.humidity = "Humidity";
	        vm.CurrentA  = "CurrentA";
	        vm.CurrentB = "CurrentB";
	        vm.CurrentC = "CurrentC";
	        vm.Load = "Load";
	        vm.Pressure = "Pressure";
	        vm.Flow = "Flow";
	        vm.isLoading = true;
			
			vm.init = function(){
				
			var operationOverviewUrl = '/ops/engie/service/operation/overview?siteId='+vm.siteid+'&userId='+$sessionStorage.userId;
	           AppService.getData(1, operationOverviewUrl).then(function(response) {
	        	   if (response.status === 200 && response.data) {
	        		   vm.isLoading = false;
	        		   vm.operationOverviewData = response.data;
	        		   vm.electricalList = vm.operationOverviewData['Electrical And MechanicalView'].TSB;
	        		   vm.upsList = vm.operationOverviewData['Electrical And MechanicalView'].UPS;
	        		   vm.crackList = vm.operationOverviewData['Electrical And MechanicalView'].CRA;
	        		   vm.temperatureValue = vm.operationOverviewData['Humidity And Temperature'].temperature;
	        		   vm.temperatureValueRounded = Math.round(vm.temperatureValue *100)/100;
	        		   vm.humidityValue = vm.operationOverviewData['Humidity And Temperature'].humidity;
	        		   vm.humidityValueRounded= Math.round(vm.humidityValue*100)/100;
	        		   vm.chillerList = vm.operationOverviewData['Electrical And MechanicalView'].CHI;
	        		   vm.genList = vm.operationOverviewData['Electrical And MechanicalView'].GEN;
	        		   vm.recentActiveAlarmList = vm.operationOverviewData['Recent Active New Alarm'];
	        		   vm.alarmCount = vm.operationOverviewData['Alarm Count'][0]['Alarm Count'];
	        		   vm.activeAlarmList = vm.operationOverviewData['Alarm Count'][0]['Active Alarm'];
	        		   vm.aveTimeEventRate =vm.operationOverviewData['Average'][0]['AvgRatePerDate'];	        		   
	        		   vm.aveTimeAck = vm.operationOverviewData['Average'][0]['AckDuration'];
	        		   vm.aveTimeNormalize = vm.operationOverviewData['Average'][0]['NRDuration'];
	        		   var aveAckTime = (parseInt(vm.aveTimeAck))/60;
	        		   var aveNormalizeTime = (parseInt(vm.aveTimeNormalize))/60;
	        		   CommonService.DataCenterEvents('aveEvent', vm.aveTimeEventRate);
	        		   CommonService.DataCenterEvents('aveAck', 70);
	        		   CommonService.DataCenterEvents('aveNormalize', 50);
	        		   for (var i = 1; i < vm.electricalList.length; i++) {
	        			   var divElectricGauge =  "elecdiv" + i;	        			  
	                       CommonService.electricalBoardGauge(divElectricGauge, vm.electricalList[i].UtilizationCapacity);
	                   }
	        		  /* console.log("aveTimeAck : "+aveAckTime);
	        		   console.log("aveTimeNormalize : "+aveNormalizeTime);*/
	        		   
	        		   /*var coolVar = '123 abc itchy knee';
	        		   var partsArray = coolVar.split(' ');*/
	        		   
	                }
	           });		
			};
			
			vm.redirectExecutiveOverview = function() {
				$location.path(AppConst.CONST_VAR.EXECUTIVEOVERVIEWCTR + "/" + vm.siteid);
	        };
	        
	       
	       
	      //Trigger initial l oading - every 10 secs interval start
	       /* var refreshPage = function() {
	              $route.reload();
	              vm.isLoading = false;

	        };
	        var interval = $interval(refreshPage, AppConst.CONST_PAGEREFRESHTIME.ONE_MINUTE);
	        $scope.$on('$destroy', function() {
	              $interval.cancel(interval);
	        });*/
	        //end

			vm.init();
	    }	
	
}())
