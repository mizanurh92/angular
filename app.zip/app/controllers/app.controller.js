/* 
 *  ================================================================================
 *  Copyright (C) 2015
 * 
 */
AppModule.controller("AppController", function($scope, $rootScope, $location,
    AppModel, AppConst, StateModel, AppService, $window) {
   
	$scope.StateModel = StateModel;
    $scope.model = AppModel;
    $scope.CONST = AppConst;
    $rootScope.preloading = true;
    	
    $scope.$watch('StateModel.state', function(newValue, oldValue) {
        if (newValue && newValue != oldValue) {
            $location.url(newValue);
        }
    });

   
    $scope.init = function() {
        
        
    };

    
    $scope.init()
});