(function() {
	'use strict';
function ngviewScrolling(){
		var totalHeight=window.innerHeight;
		var navHeight=$(".navbar").outerHeight();
		var NavFooterheight=5+navHeight;
		var hlogo=$(".logo").height();
		console.log(navHeight);
		if(window.innerWidth >= 768){
			var contentHeight=totalHeight-NavFooterheight;
			$(".content").css("height",contentHeight);
		}
		else{
			var contentHeight=totalHeight-(NavFooterheight+hlogo);
			$(".content").css("height",contentHeight);
		}
		
	}
	$( window ).resize(function() {
	  ngviewScrolling();
	});
}());