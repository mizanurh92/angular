/* 
 *  ================================================================================
 *  Copyright (C) 2017
 */ 

(function() {
	'use strict';
	
	AppModule.controller("inactiveEventsController",["$scope","AppConst","AppService","$route","$interval", inactiveEventsController]);

	function inactiveEventsController($scope,AppConst,AppService,$route,$interval) {
		var vm=this;
		
		vm.init = function(){
			
        var activeEventsUrl = "/ops/events/eventslist";
        var convertUTCToLocal=-1;	
			var _postData =	{
					"siteid":"sdslab",
					"serviceType":"inactiveEvents",
					"timezoneOffetInMin":new Date().getTimezoneOffset()*convertUTCToLocal
				};
		
		 var columnDefs = [
		                   {headerName: "S/N", field: "sno", width: 60,cellStyle: {'background-color': 'white'},cellClass:"text-center"}, 
		                   {headerName: "Type of Events", field: "alertType", cellStyle: {'background-color': 'white'},width: 110},
		                   {headerName: "Severity", field: "eventSeverity",width: 100,
		                	   cellStyle: function(params) {
		       			        if (params.data.eventSeverity=='Critical') {
		       			            return {color: 'red','background-color': 'white'};
		       			        }else if (params.data.eventSeverity=='Warning') {
		       			            return {color: '#FFBF00','background-color': 'white'};
		       			        }else if (params.data.eventSeverity=='Minor') {
		       			            return {color: 'grey','background-color': 'white'};
		       			        }  
		       			     }
		                   },
		                   {headerName: "Event Name", field: "eventMsg",width: 230,cellStyle: {'background-color': 'white'}},
		                   {headerName: "Asset", field: "assetId",width: 220,cellStyle: {'background-color': 'white'}},
		                   {headerName: "Asset Group", field: "assetGroup",width: 100,cellStyle: {'background-color': 'white'}},
		                   {headerName: "Time of Event", field: "timeOfEvent",width: 130,cellStyle: {'background-color': 'white'},filter:'date',
		       				filterParams : { comparator: dateComparatorFun }},
		                   {headerName: "Time of Normalize", field: "timeOfAck",width: 140,cellStyle: {'background-color': 'white'},filter:'date',
			       		    filterParams : { comparator: dateComparatorFun }},
		                   {headerName: "Duration", field: "price",width: 100,cellStyle: {'background-color': 'white'}},
		                   {headerName: "Quick Actions", field: "eventAction",width: 100,cellStyle: {'background-color': 'white'}}
		               ];

		               _postData = JSON.parse(angular.toJson(_postData));
		   			   AppService.postData(_postData,activeEventsUrl).then(function(response) {
		                   if (response.status === 200 && response.data) {
		                	   $scope.gridOptions.api.setRowData(response.data);

		                   }
		   			   })

		               $scope.gridOptions = {
		                   columnDefs: columnDefs,
		                   pagination: true,
		   				   enableFilter: true,
		   				   paginationPageSize:10,
		   			       paginationStartPage:0,
		   			       enableSorting : true,
		   			       enableColResize : true
		               };
		               
		}    
		               
		               vm.init();
		               
		             //Trigger initial l oading - every 10 secs interval start
		               var refreshPage = function() {
		                     $route.reload();

		               };
		               var interval = $interval(refreshPage, AppConst.CONST_PAGEREFRESHTIME.ONE_MINUTE);
		               $scope.$on('$destroy', function() {
		                     $interval.cancel(interval);
		               });
		               //end
		               vm.onFilterChanged = function(value) {
			       			$scope.gridOptions.api.setQuickFilter(vm.searchFilterVal);
			       	   }
		               
		               vm.exportToCsv = function () {
		       		       var params = {
		       		           skipHeader: false,
		       		           columnGroups: true,
		       		           skipFooters: true,
		       		           skipGroups: false,
		       		           skipFloatingTop: true,
		       		           skipFloatingBottom: true,
		       		           allColumns: true,
		       		           onlySelected: false,
		       		           suppressQuotes: false,
		       		           fileName: 'inactiveEvents.csv',
		       		           columnSeparator: ','
		       		       };
		       		       $scope.gridOptions.api.exportDataAsCsv(params);
		       		   }
		       		
		       		   
		       		   
		       		   
		       		function dateComparatorFun(filterLocalDateAtMidnight, cellValue){
		   			    var dateParts  = cellValue.split(" ")[0].split("/");
		   	            var year = Number(dateParts[2]);
		   	            var month = Number(dateParts[1]) - 1;
		   	            var day = Number(dateParts[0]);
		   	            var cellDate = new Date(year,month,day);

		   	            // Now that both parameters are Date objects, we can compare
		   	            if (cellDate < filterLocalDateAtMidnight) {
		   	                return -1;
		   	            } else if (cellDate > filterLocalDateAtMidnight) {
		   	                return 1;
		   	            } else {
		   	                return 0;
		   	            }
		   		     }
		}
}())
