/* 
 *  ================================================================================
 *  Copyright (C) 2017
 */ 
(function() {
	'use strict';
	AppModule.controller("eleDiagramController",["$scope","AppConst","AppService","$interval","$route",eleDiagramController]);

	function eleDiagramController($scope,AppConst,AppService,$interval,$route) {
		var vm=this;
	
		$scope.samplescope = "VMMMMMM";
		vm.equipmentList=["RTH1","TSB61A1"];
		vm.init = function(){
			$scope.tooltipOptions = {} ;
			$scope.tooltipOptions.contentAsHTML = true;			
			var eleDiagramStatusUrl = "/ops/opsmodule/elediagramstatus";
			
			var _equipmentAndAttributeList =	{
					"site":"sdslab",
					"values":[{
					   "equipmentID":"SDSLAB-KCT-ACSB61B1",
					   "attributeName":"UtilizationCapacity"                               
					}
					,
					{
						   "equipmentID":"SDSLAB-KCT-TSB61A7",
						   "attributeName":"UtilizationCapacity"                               
					  }
					]
				};

			
			_equipmentAndAttributeList = JSON.parse(angular.toJson(_equipmentAndAttributeList));
			
			AppService.postData(_equipmentAndAttributeList,eleDiagramStatusUrl).then(function(response) {
                if (response.status === 200 && response.data) {
                	
                	var assetList=response.data;
                	 for (var i = 0; i < assetList.length; i++) {
                		 
                    	 var assetId = assetList[i].assetId;
                    	 var attributeVal = response.data[i].attributeVal; 
                    	 vm[assetId+"_VAl"]=attributeVal;
                    	 vm[assetId+"_status"]=response.data[i].assetStatus;
                    	 
                    	 if("CR"==response.data[i].assetStatus) {
                      	     //vm[assetId+"_status_Indicator"]="redbulb";
                      		 vm[assetId+"_status_Indicator"]="statusRed";
                      	 } else if("WR"==response.data[i].assetStatus) {
                        	 //vm[assetId+"_status_Indicator"]="yellowbulb";
                      		 vm[assetId+"_status_Indicator"]="statusYellow";
                    	 } else if("MR"==response.data[i].assetStatus) {
                    	     //vm[assetId+"_status_Indicator"]="yellowbulb";
                  		     vm[assetId+"_status_Indicator"]="statusGrey";
                    	 } else if("NM"==response.data[i].assetStatus) {
                    	     //vm[assetId+"_status_Indicator"]="greenbulb";
                  		     vm[assetId+"_status_Indicator"]="statusGreen";
                    	 }
                    }

                 }
            });
			//Trigger initial loading - every 10 secs interval start
			var refreshPage = function() {
				$route.reload();

			};
			var interval = $interval(refreshPage, AppConst.CONST_PAGEREFRESHTIME.ONE_MINUTE);
			$scope.$on('$destroy', function() {
				$interval.cancel(interval);
			});
			//end
		}
		
		
		
		vm.init();
		
	}
	
	
	
}())
