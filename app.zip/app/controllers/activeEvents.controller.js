/* 
 *  ================================================================================
 *  Copyright (C) 2017
 */

(function() {
	'use strict';

	AppModule.controller("activeEventsController", [ "$scope", "AppConst","$sessionStorage",
		"AppService", "$route", "$interval","$filter","$rootScope",'$location',"sharedProperties", activeEventsController ]);

	function activeEventsController($scope, AppConst,$sessionStorage, AppService, $route, $interval,$filter,$rootScope,$location,sharedProperties) {
		var vm = this;
		
		$scope.ackCriClick = false;
		$scope.ackWarClick = false;
		$scope.ackMinClick = false;
		var convertUTCToLocal=-1;
		var refreshEnabled=true;
		var lastUrl=sharedProperties.getLastUrl();
		vm.init = function() {
			var activeEventsUrl = "/ops/events/eventslist";
			if(lastUrl=="/assetperformance/upsAssetEvents/sdslab"){
				var _postData = {
					"siteid" : "sdslab",
					"serviceType" : "activeEvents",
					"timezoneOffetInMin":new Date().getTimezoneOffset()*convertUTCToLocal,
					"assetId":sharedProperties.getAssetId()
				};
			}
			else{
				var _postData = {
					"siteid" : "sdslab",
					"serviceType" : "activeEvents",
					"timezoneOffetInMin":new Date().getTimezoneOffset()*convertUTCToLocal
				};
			}
			console.log(_postData);
			
			vm.spinnerFlag = false;

			var columnDefs = [{
				headerName : "S/N",
				field : "sno",
				width : 60,
				cellClass : "text-center",      
				filter: 'text',
				cellStyle: function(params) {
					if ("NACK" == params.data.eventAction) {
						return {color:'#00aaff'};
					}else {
						return {color:  '#808080'};
					}
				}
			}, {
				headerName : "Type of Events",
				field : "alertType",
				width : 111,
				cellStyle: function(params) {
					if ("NACK" == params.data.eventAction) {
						return {color:'#00aaff'};
					}else {
						return {color:  '#808080'};
					}
				}
			}, {
				headerName : "Severity",
				field : "eventSeverity",
				width : 80,
				filter:'text',
				cellStyle: function(params) {
			        if (params.data.eventSeverity=='Critical') {
			            return {color: 'red'};
			        /*}else if (params.data.eventSeverity=='Warning') {*/
			        }else if (params.data.eventSeverity=='Warning') {
			            return {color: '#FFBF00'};
			        }else if (params.data.eventSeverity=='Minor') {
			            return {color: '#808080'};
			        }  
			     }
			}, {
				headerName : "Event Name",
				field : "eventMsg",
				suppressFilter: true,
				width : 197,
				cellRenderer : renderEventNameCell,
				cellStyle : function(params) {
					
					if ("NACK" == params.data.eventAction) {
						return {color: '#00aaff', cursor : 'pointer',};
					}else {
						return {color: '#808080', cursor : 'pointer',};
					}
				}
				
			}, {
				headerName : "Asset",
				field : "assetId",
				width : 150,
				cellStyle: function(params) {
					if ("NACK" == params.data.eventAction) {
						return {color:'#00aaff'};
					}else {
						return {color:  '#808080'};
					}
				}
			}, {
				headerName : "Asset Group",
				field : "assetGroup",
				width : 100,
				cellStyle: function(params) {
					if ("NACK" == params.data.eventAction) {
						return {color:'#00aaff'};
					}else {
						return {color:  '#808080'};
					}
				}
			}, {
				headerName : "Time of Event",
				field : "timeOfEvent",
				suppressFilter: true,
				/*width : 130,*/
				width : 160,
				filterParams : { comparator: dateComparatorFun },
				cellStyle: function(params) {
					if ("NACK" == params.data.eventAction) {
						return {color:'#00aaff'};
					}else {
						return {color:  '#808080'};
					}
				}
			}, {
				headerName : "Time of Ack",
				field : "timeOfAck",
				/*width : 130,*/
				width : 135,
				filter:'date',
				filterParams : { comparator: dateComparatorFun},
				cellStyle: function(params) {
					if ("NACK" == params.data.eventAction) {
						return {color:'#00aaff'};
					}else {
						return {color:  '#808080'};
					}
				}
			}, {
				headerName : "Duration",
				field : "ackDuration",
				suppressFilter: true,
				/*width : 110*/
				width : 173,
				cellStyle: function(params) {
					if ("NACK" == params.data.eventAction) {
						return {color:'#00aaff'};
					}else {
						return {color:  '#808080'};
					}
				}

			}, {
				headerName : "Quick Actions",
				field : "eventAction",
				/*width : 144,*/
				width : 150,
				suppressFilter: true,
				cellRenderer : renderNackButton,
				cellStyle: function(params) {
					if ("NACK" == params.data.eventAction) {
						return {color:'#00aaff'};
					}else {
						return {color:  '#808080'};
					}
				}
			} ];

			$scope.gridOptions = {
				angularCompileRows : true,
				angularCompileHeaders : true,
				columnDefs : columnDefs,
				getRowStyle :applyRowStyle,
				enableSorting : true,
				enableColResize : true,
				pagination: true,
				enableFilter: true,
				paginationPageSize:10,
			    paginationStartPage:0,
				isExternalFilterPresent : isExternalFilterPresent,
				doesExternalFilterPass : fiterRecords,
				rowSelection: 'single',
                onSelectionChanged: onSelectionChanged
				
			};

			_postData = JSON.parse(angular.toJson(_postData));
			AppService.postData(_postData, activeEventsUrl).then(
				function(response) {
					if (response.status === 200 && response.data) {

						vm.eventListOrig = response.data.eventList;
						vm.eventListTemp = response.data.eventList;
						$scope.gridOptions.api.setRowData(vm.eventListTemp);
						vm.totalActiveAlarmCount = response.data.totalActiveAlarmCount;
						vm.totalNAckAlarmCount = response.data.totalNAckAlarmCount;
						vm.longStandingAlarmCount = response.data.longStandingAlarmCount;
						vm.siteid=response.data.siteid;
						// $scope.gridOptions.rowData=response.data;
						vm.eventCountDetails(vm.eventListTemp)

					}
				})
				
				

			vm.msg = "grid page paeggggggggggggggggggggggg"

		}
		
		vm.eventCountDetails=function(eventList){
			//console.log("len ="+eventList)
			var acftCnt=0;
			var awftCnt=0;
			var amftCnt=0;
			angular.forEach(eventList, function(node, key) {
				//console.log("node.eventSeverity ="+node.eventSeverity)
				if ('Critical' == node.eventSeverity) {
					acftCnt++;
				}else if('Warning' == node.eventSeverity){
					awftCnt++;
				}else if('Minor' == node.eventSeverity){
					amftCnt++;
				}
					
				});
			vm.ACFT=acftCnt;
			vm.AWFT=awftCnt;
			vm.AMFT=amftCnt;
		}

		vm.init();
		
		vm.refreshPage = function() {
			console.log(" refreshEnabled="+refreshEnabled)
			if(refreshEnabled)//Disble refresh if "Event Details" popup shown 
				$route.reload();

      };
      var interval = $interval(vm.refreshPage, AppConst.CONST_PAGEREFRESHTIME.ONE_MINUTE);
      $scope.$on('$destroy', function() {
            $interval.cancel(interval);
      });
		
		//Trigger initial l oading - every 10 secs interval start
        
        //end
		
		
 
		vm.onFilterChanged = function(value) {
			//			alert(value);
			//			alert(vm.searchFilterVal);
			$scope.gridOptions.api.setQuickFilter(vm.searchFilterVal);
		}
		
		vm.externalFilterChanged = function(val) {
			//console.log(" val="+val)
			var i = 0;
			var j = 0;
			if ('Critical' == val) {
				var model = $scope.gridOptions.api.getModel().rootNode.allLeafChildren;
				angular.forEach(model, function(node, key) {
					if ('Critical' == node.data.eventSeverity) {
						i++;
					}
					if ('Critical' == node.data.eventSeverity && 'NACK' == node.data.eventAction) {
						j++;
						
					}
				});
				vm.ACFT = i;
				vm.ACFNACK = j;
				$scope.ackCriClick = true;
			}
			if ('Warning' == val) {
				var model = $scope.gridOptions.api.getModel().rootNode.allLeafChildren;
				angular.forEach(model, function(node, key) {
					if ('Warning' == node.data.eventSeverity) {
						i++;
					}
					if ('Warning' == node.data.eventSeverity && 'NACK' == node.data.eventAction) {
						j++;
					}
				});
				vm.AWFT = i;
				vm.AWFNACK = j;
				$scope.ackWarClick = true;
			}
			if ('Minor' == val) {
				var model = $scope.gridOptions.api.getModel().rootNode.allLeafChildren;
				angular.forEach(model, function(node, key) {
					if ('Minor' == node.data.eventSeverity) {
						i++;
					}
					if ('Minor' == node.data.eventSeverity && 'NACK' == node.data.eventAction) {
						j++;
					}
				});
				vm.AMFT = i;
				vm.AMFNACK = j;
				$scope.ackMinClick = true;
			}
			vm.externalFilterVal = val;
			$scope.gridOptions.api.onFilterChanged();
			
		}
		
		function dateComparatorFun(filterLocalDateAtMidnight, cellValue){
			 var dateParts  = cellValue.split(" ")[0].split("/");
	            var year = Number(dateParts[2]);
	            var month = Number(dateParts[1]) - 1;
	            var day = Number(dateParts[0]);
	            var cellDate = new Date(year,month,day);

	            // Now that both parameters are Date objects, we can compare
	            if (cellDate < filterLocalDateAtMidnight) {
	                return -1;
	            } else if (cellDate > filterLocalDateAtMidnight) {
	                return 1;
	            } else {
	                return 0;
	            }
		}
		
		function applyRowStyle(params){
		    /*if ("ACK"== params.data.eventAction) {
		        return {'background-color': '#DEDEDE'}
		    	 return {'background-color': 'white'}
		        return {'background-color': 'white',color: '#3c8dbc'}
		    }*/
		    return {'background-color': 'white'};
		}	

		function isExternalFilterPresent() {
			// if ageType is not everyone, then we are filtering
			if (undefined != vm.externalFilterVal) {
				return true;
			}
			return false;
		}
		function fiterRecords(node) {
			return node.data.eventSeverity == vm.externalFilterVal;
		}

		function openEventDetails(siteDetails) {
			siteDetails = JSON.parse(decodeURI(siteDetails));
			vm.siteDetails = siteDetails;
			var assetInfoKeys=[];
			// Get DB values from DB.
			var activeEventsUrl = "/ops/events/eventslist";
			var _postData = {
				"siteid" : "sdslab",
				"serviceType" : "activeEvents.eventDetails",
				"assetId":siteDetails.assetId,
				"eventMsg":siteDetails.eventMsg
			};
			//_postData.push("assetId",assetId)
			
			_postData = JSON.parse(angular.toJson(_postData));
			AppService.postData(_postData, activeEventsUrl).then(
				function(response) {
					if (response.status === 200 && response.data) {
						//console.log(JSON.parse(response.data));
						var allEntDetails = JSON.parse(response.data);	
						var allEntJsObj=JSON.parse(allEntDetails)
						vm.jsonOb=allEntJsObj.assetInfo;
						vm.fauitOverTime=JSON.parse(allEntJsObj.faultOverTime);
						//console.log("vm.fauitOverTime="+vm.fauitOverTime)
						drawChart(vm.fauitOverTime);
					}
				})
			$('#eventDetail').modal('show');
			$('#eventDetail').on('shown.bs.modal', function(e) {
				refreshEnabled=false;
			})
			$('#eventDetail').on('hidden.bs.modal', function(e) {
				 refreshEnabled=true;
			})
		}

		function renderEventNameCell(params) {
			var siteDetails = getSiteConfigDetails(params.data)
			params.$scope.openEventDetails = openEventDetails;
			$scope.id = "params.data.id"
			return "<a  ng-click=openEventDetails('" + siteDetails + "')>" + params.data.eventMsg
				+ "</a>";
		}
		function renderSevColumn(params){
			var eventSeverity = params.data.eventSeverity
			if("CR"==eventSeverity){
				return "sty";
			}
			
			
		}

		function ackThisEvent(allAttributes) {
			//alert("i am getting ack" + allAttributes);
			/*console.log("value of JSON : "+allAttributes);*/
			allAttributes = JSON.parse(decodeURI(allAttributes));
			
			var allAttrArr = allAttributes.split('##');
			var id=allAttrArr[0];
			var assetId=allAttrArr[1];
			var attrName=allAttrArr[2];
			var country=allAttrArr[3]
			var timeOfEventReq=allAttrArr[4];
			var spinnerEvent = allAttrArr[5];
			//alert("Id" + id);
			var activeEventsUrl = "/ops/events/eventslist";
			var _postData = {
					"serviceType" : "EVENT_ACK",
					"id":id,
					"assetId":assetId,
					"attrName":attrName,
					"country":country,
					"timeOfEventReq":timeOfEventReq,
					"userId":$sessionStorage.userId
				};
				
				AppService.postData(_postData, activeEventsUrl).then(
					function(response) {
						if (response.status === 200 && response.data) {
							vm.spinnerFlag = spinnerEvent;
							
							$scope.gridOptions.api.setRowData(vm.eventListTemp);
							// $scope.gridOptions.rowData=response.data;
							

						}
					})
		}

		function renderNackButton(params) {
		
			params.data.spinner = vm.spinnerFlag;
			
		
			if ("NACK" == params.data.eventAction) {
				params.$scope.ackThisEvent = ackThisEvent;
				var allAttributes=params.data.id+'##'+params.data.assetId+'##'+params.data.attributeName+'##'+params.data.country+'##'+params.data.timeOfEventReq+'##'+params.data.spinner;
				
				var allAttributes = getAllAttributesDetails(allAttributes);
				
				
				return "<button type=button ng-click=ackThisEvent('" + allAttributes + "') class='btn btn-primary' style='padding:0px 0px;font-size:10px;'>ACKNOWLEDGE</button>";
			}else if (("ACK" == params.data.eventAction && !vm.spinnerFlag)) {
				return " Acknowledged by "+ params.data.ackByName;
			}else if (("ACK" == params.data.eventAction && vm.spinnerFlag)) {
				return "<i class='fa fa-circle-o-notch fa-spin spinnerColor'></i>";
			}

		};
		
		function onSelectionChanged() {			
		    var selectedRows = $scope.gridOptions.api.getSelectedRows();
		    var model = $scope.gridOptions.api.getModel();
		    selectedRows[0].eventAction = "ACK";		    
		    for (var i = 0; i < vm.eventListTemp.length; i++) {
		    	if(vm.eventListTemp[i].sno === selectedRows[0].sno){
		    		vm.eventListTemp[i].eventAction = selectedRows[0].eventAction;
		    	}
		    }
		};
		
		function drawChart(data) {
			var chartData=[ {
				"date" : "2012-07-27",
				"value" : 13
			}, {
				"date" : "2012-07-28",
				"value" : 11
			}, {
				"date" : "2012-07-29",
				"value" : 15
			}, {
				"date" : "2012-07-30",
				"value" : 16
			}, {
				"date" : "2012-07-31",
				"value" : 18
			}, {
				"date" : "2012-08-01",
				"value" : 13
			}, {
				"date" : "2012-08-02",
				"value" : 22
			}, {
				"date" : "2012-08-03",
				"value" : 23
			}, {
				"date" : "2012-08-04",
				"value" : 20
			}, {
				"date" : "2012-08-05",
				"value" : 17
			}, {
				"date" : "2012-08-06",
				"value" : 16
			}, {
				"date" : "2012-08-07",
				"value" : 18
			}, {
				"date" : "2012-08-08",
				"value" : 21
			} ];
			
			//DOTO to be removed.
			if(data && data.length>0){//if no record
				chartData=data;
			}
			var chart = AmCharts
				.makeChart(
					"historicalEventDetais",
					{
						"type" : "serial",
						"theme" : "light",
						"marginRight" : 40,
						"marginLeft" : 40,
						"autoMarginOffset" : 20,
						"mouseWheelZoomEnabled" : true,
						"dataDateFormat" : "DD-MM-YYYY",
						"valueAxes" : [ {
							"id" : "v1",
							"axisAlpha" : 0,
							"position" : "left",
							"ignoreAxisWidth" : true
						} ],
						"balloon" : {
							"borderThickness" : 1,
							"shadowAlpha" : 0
						},
						"graphs" : [ {
							"id" : "g1",
							"balloon" : {
								"drop" : true,
								"adjustBorderColor" : false,
								"color" : "#ffffff"
							},
							"bullet" : "round",
							"bulletBorderAlpha" : 1,
							"bulletColor" : "#FFFFFF",
							"bulletSize" : 5,
							"hideBulletsCount" : 50,
							"lineThickness" : 2,
							"title" : "red line",
							"useLineColorForBulletBorder" : true,
							"valueField" : "value",
							"balloonText" : "<span style='font-size:18px;'>[[value]]</span>"
						} ],
						"chartCursor" : {
							"pan" : true,
							"valueLineEnabled" : true,
							"valueLineBalloonEnabled" : true,
							"cursorAlpha" : 1,
							"cursorColor" : "#258cbb",
							"limitToGraph" : "g1",
							"valueLineAlpha" : 0.2,
							"valueZoomable" : true
						},

						"categoryField" : "date",
						"categoryAxis" : {
							"parseDates" : true,
							"dashLength" : 1,
							"minorGridEnabled" : true
						},
						"export" : {
							"enabled" : false
						},
						"dataProvider" : chartData	
					});
		}

		vm.exportToCsv = function() {
			var params = {
				skipHeader : false,
				columnGroups : true,
				skipFooters : true,
				skipGroups : false,
				skipFloatingTop : true,
				skipFloatingBottom : true,
				allColumns : true,
				onlySelected : false,
				suppressQuotes : false,
				fileName : 'activeEvents.csv',
				columnSeparator : ','
			};

			$scope.gridOptions.api.exportDataAsCsv(params);
		}

		

		//Pass site  details for "Event Details" popup window
		function getSiteConfigDetails(paramsData) {
			//console.log(" assetId" + paramsData.assetId);
			//console.log(paramsData.sno+" paramsData.notificationAuditsTrail=" + paramsData.notificationAuditsTrail);
			var location;
			var eventMsg ="";
			var timeOfEvent;
			var siteDetails = {};
			var locAry;
			if (paramsData.assetId) {//for handling data issue
				locAry = paramsData.assetId.split("-");
				if (locAry.length > 1) {
					location = locAry[1];
				} else {
					location = paramsData.assetId;
				}
			}
			if (paramsData.eventMsg) {
				eventMsg = paramsData.eventMsg;
			}
			var email={};
			email.L1="";
			if(paramsData.notificationAuditsTrail){
				email=JSON.parse(paramsData.notificationAuditsTrail);
		    }
			siteDetails.email=email.L1;
			siteDetails.assetId = paramsData.assetId;
			siteDetails.location = location;
			siteDetails.eventMsg = eventMsg;
			siteDetails.timeOfEvent = paramsData.timeOfEvent;
			siteDetails.assetGroup=paramsData.assetGroup;
			siteDetails.ackDuration=paramsData.ackDuration;
			siteDetails.eventAction=paramsData.eventAction
			siteDetails.ackByName=paramsData.ackByName
			//console.log("name :" +siteDetails.ackByName);
			siteDetails.timeOfAck=paramsData.timeOfAck
			/*console.log("timeofeve "+siteDetails.timeOfEvent);
			console.log("timeofack "+siteDetails.timeOfAck);*/
			
			var escpeSiteDetails = encodeURI(JSON.stringify(siteDetails));
			return escpeSiteDetails;
			
		}
		
		function getAllAttributesDetails(attributesDetails) {
			
			return encodeURI(JSON.stringify(attributesDetails));
		}
		
		


	} // closing activeEventsController

}())