/* 
 *  ================================================================================
 *  Copyright (C) 2015
 * 
 */
(function() {
    'use strict';
    AppModule.controller('AppModalController', function($scope, close) {
        $scope.close = function(result) {
            if (!result || result === 'cancel') {
                $scope.modal.action = false;
            } else {
                $scope.modal.action = true;
            }

            close(result, 10); // close, but give 10ms for bootstrap to animate
            setTimeout(function() {
                var _backdrop = document.querySelector(".modal-backdrop");
                document.querySelector("body").removeChild(_backdrop); //Temporary fix to remove the black backdrop added by bootstrap.
                $('body').removeClass('modal-open');
                $('body').removeAttr('style');
            }, 20)
        };
        $scope.init = function() {
            $scope.modal = {
                "title": "",
                "message": "",
                "buttonname": "",
                "action": false //action specifies whether modal dismiss or call action method
            };
        };

    });
})();