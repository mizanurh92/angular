/* 
 *  ================================================================================
 *  Copyright (C) 2017
 */ 

(function() {
	'use strict';
	
	AppModule.controller("singleLineDiagramController",["$scope","AppConst","AppService","$interval","$route",singleLineDiagramController]);

	function singleLineDiagramController($scope,AppConst,AppService,$interval,$route) {
		var vm=this;
		
		vm.init = function(){

			$scope.tooltipOptions = {} ;
			$scope.tooltipOptions.contentAsHTML = true;			
			var slDiagramStatusUrl = "/ops/opsmodule/sldiagramstatus";
			
			var _equipmentAndAttributeList =	{
					"site":"ustlab",
					"values":[{
					   "equipmentID":"UPSDB",
					   "attributeName":"PowerAvailable"                               
					}
					,
					{
						   "equipmentID":"DC2DB",
						   "attributeName":"BreakerStaus"                               
					  }
					
					
					]
				};

			
			_equipmentAndAttributeList = JSON.parse(angular.toJson(_equipmentAndAttributeList));
	   
			AppService.postData(_equipmentAndAttributeList, slDiagramStatusUrl).then(function(response) {
				console.log(JSON.stringify(response.data.eventSeverity))
				if (response.status === 200 && response.data) {
					var assetList = response.data.eventSeverity;
					console.log(response.data.eventSeverity);
					for (var i = 0; i < assetList.length; i++) {
						var equipmentId = assetList[i].equipmentId;
						console.log(equipmentId);
						var attributeBSVal = assetList[i].BreakerStaus;
						console.log(attributeBSVal);
						var attributePSVal = assetList[i].PowerAvailable;
						console.log(attributePSVal);
					
						if( i == 0 || i == 2) {
							if ("CR" == attributeBSVal) {
								vm[equipmentId+"_BreakerStaus"] = "statusBullet statusBulletBlinker statusRed";
						  } else if ("WR" == attributeBSVal) {
								vm[equipmentId+"_BreakerStaus"] = "statusBullet statusBulletBlinker statusYellow";
						  } else {
								vm[equipmentId+"_BreakerStaus"] = "statusBullet statusBulletBlinker statusGreen";
						  }
							
						 }	 if(i == 1 || i == 3) {
							 if ("CR" == attributePSVal) {
									vm[equipmentId+"_PowerAvailable"] = "statusBullet statusBulletBlinker statusRed";
							  } else if ("WR" == attributePSVal) {
									vm[equipmentId+"_PowerAvailable"] = "statusBullet statusBulletBlinker statusYellow";
							  } else {
									vm[equipmentId+"_PowerAvailable"] = "statusBullet statusBulletBlinker statusGreen";
							  }
						 }	
					}

				}
			});
			
			/*$(document).ready(function(){
				var colorchange = '<svg id="svg_lineone" width="678px" height="363px" viewBox="0 0 1200 400" xmlns="http://www.w3.org/2000/svg" version="1.1" class="svg4Position"><polyline name="pl_lineone"  points="425,-101,425,-42,580,-42,580,233,208,233,208,500" class="sldPolyLine sldStrokeRed"/> </svg>';
				$("#toogleAll").click(function(){
					 var all =   $("polyline").addClass("sldStrokeRed");
					  
				    });
					
					$("#toogleOne").click(function(){
				    	var one = $("#svg_last_line").html(colorchange)
				    	 alert(one);
				    });
				});
			*/
			vm.toggleOneLine = function(){
				  var colorchange = '<svg id="svg_lineone" width="678px" height="363px" viewBox="0 0 1200 400" xmlns="http://www.w3.org/2000/svg" version="1.1" class="svg4Position"><polyline name="pl_lineone"  points="425,-101,425,-42,580,-42,580,233,208,233,208,500" class="sldPolyLine sldStrokeRed"/> </svg>';
				  var one = $("#svg_last_line").html(colorchange);
			}
			
			vm.toggleAllLines = function(){
				var all =   $("polyline").addClass("sldStrokeRed");
				//$("polyline.sldStrokeGreen").toggleClass("sldStrokeRed");
			}
			
			//Trigger initial loading - every 10 secs interval start
			/*var refreshPage = function() {
				$route.reload();

			};
			var interval = $interval(refreshPage, AppConst.CONST_PAGEREFRESHTIME.TEN_SECONDS);
			$scope.$on('$destroy', function() {
				$interval.cancel(interval);
			});*/
			//end
			
			
		
		}
		               vm.init();
		           	
		} // closing activeEventsController
	
}())
