/* 
 *  ================================================================================
 *  Copyright (C) 2017
 */

(function(){
	'use strict';
	AppModule.controller("kpiController", ["$scope", "AppService", "AppConst", "$route","$interval", kpiController]);
	
	function kpiController($scope, AppService,AppConst, $route,$interval) {
		
		var vm = this;
		
		vm.init = function() {
			
			var kpiAvailabilityURL = '/ops/opskpi/getAvailability?siteId='+'sdslab'+'&kpiCategory='+'Availability';
			AppService.getData(1, kpiAvailabilityURL).then(function(response) {
	        	   if (response.status === 200 && response.data) {
	        		 vm.availabilityData = response.data;
					 
					 var obj=[];
	        		 for(var i=0;i<vm.availabilityData.length;i++) {
	        			  if(vm.availabilityData[i].KpiName=="DataCenterAvailability"){
	        				  vm.dataCenterAvailability = vm.availabilityData[i];
	        			  }
	        			  else if(vm.availabilityData[i].KpiName=="TotalNumberOfAgingEquipments") {
	        				  vm.totalNumberOfAgingEquipments = vm.availabilityData[i];
	        			  }
	        			  else if(vm.availabilityData[i].KpiName=="TotalAlarmsInAMonth") {
	        				  vm.totalAlarmsInAMonth = vm.availabilityData[i];
	        			  }
	        			  else if(vm.availabilityData[i].KpiName=="AvgRateOfEvtOccurPerWk") {
	        				  vm.avgRateOfEvtOccurPerWk = vm.availabilityData[i];
	        			  }
	        			  else if(vm.availabilityData[i].KpiName=="TotUnackAlarms") {
	        				  vm.totUnackAlarms = vm.availabilityData[i];
	        			  }
	        			  else if(vm.availabilityData[i].KpiName=="TotLongStandingAlarms") {
	        				  vm.totLongStandingAlarms = vm.availabilityData[i];
	        			  }
	        			  else if(vm.availabilityData[i].KpiName=="AvgTimeOfAck") {
	        				  vm.avgTimeOfAck = vm.availabilityData[i];
							  vm.avgTimeOfAckInMin=parseInt(vm.avgTimeOfAck.CurrentReading);
							  vm.avgTimeOfAckInSec=parseInt((vm.avgTimeOfAck.CurrentReading%1)*60);
	        			  }
	        			  else if(vm.availabilityData[i].KpiName=="AvgTimeOfNormalization") {
	        				vm.avgTimeOfNormalization = vm.availabilityData[i];
							vm.AvgTimeOfNormalizationInMin=parseInt(vm.avgTimeOfNormalization.CurrentReading);
							vm.AvgTimeOfNormalizationInSec=parseInt((vm.avgTimeOfNormalization.CurrentReading%1)*60);
	        			  }
						  
	        		  }
						  for(var j=0;j<vm.availabilityData.length-2;j++){
							  obj[j] = JSON.parse(vm.availabilityData[j].KpiValues);
							  var graphdata=[];
							  for(var m=0;m<obj[j].length;m++){
									if(obj[j][m].February !=undefined){
										var Febvalue=obj[j][m].February;
										graphdata.push(Febvalue)
									}
									else if(obj[j][m].March !=undefined){
										 var Marchvalue=obj[j][m].March;
										 graphdata.push(Marchvalue);
									 }
									 else if(obj[j][m].April !=undefined){
										 var Aprilvalue=obj[j][m].April;
										 graphdata.push(Aprilvalue);
									 }
									 else if(obj[j][m].May !=undefined){
										 var Mayvalue=obj[j][m].May;
										 graphdata.push(Mayvalue);
									 }
									else if(obj[j][m].June !=undefined){
										 var Junevalue=obj[j][m].June;
										 graphdata.push(Junevalue);
									 }
									 else if(obj[j][m].July !=undefined){
										 var Julyvalue=obj[j][m].July;
										 graphdata.push(Julyvalue);
									 }
									 else if(obj[j][m].August !=undefined){
										 var Augvalue=obj[j][m].August;
										 graphdata.push(Augvalue)
									 }
									 else if(obj[j][m].September !=undefined){
										 var Sepvalue=obj[j][m].September;
										 graphdata.push(Sepvalue)
									 }
									 else if(obj[j][m].October !=undefined){
										 var Octvalue=obj[j][m].October;
										 graphdata.push(Augvalue)
									 }
									 else if(obj[j][m].November !=undefined){
										 var Novvalue=obj[j][m].November;
										 graphdata.push(Novvalue)
									 }
									 else if(obj[j][m].December !=undefined){
										 var Decvalue=obj[j][m].December;
										 graphdata.push(Decvalue)
									 }
									 else if(obj[j][m].January !=undefined){
										 var janvalue=obj[j][m].January;
										 graphdata.push(janvalue)
									 }
									}
									var customarTarget=[];
									for(var a=0;a<obj[j].length;a++){
										customarTarget.push(parseFloat(vm.availabilityData[j].CustomerTarget));
									}
									//console.log(graphdata);
									var chart = Highcharts.chart(vm.availabilityData[j].KpiName, {
										colors: ['rgb(124, 181, 236)','red'],
										backgroundColor: null,
										xAxis: {      
										   labels: {
											   enabled: false
										   },
										   minorTickLength: 0,
										   tickLength: 0
										},
										yAxis:{ 
										  gridLineWidth: 0,
										  minorGridLineWidth: 0
										},
										series: [
										{
											name: 'Data',
											type: 'column',
											colorByPoint: false,
											//data: [json.KPIValues[0].Jun,json.KPIValues[1].April,json.KPIValues[2].Mar,json.KPIValues[3].Feb],
											data:graphdata,
											showInLegend: false
										},
										{
											name: 'avarage',
											type: 'spline',
											colorByPoint: false,
											data: customarTarget,
											showInLegend: false
										}],
										exporting: {
											enabled: false
										}
	
							});
							chart.setSize("230", "130");
							
						  }
						  for(var k=vm.availabilityData.length-2;k< vm.availabilityData.length; k++){
							  obj[k] = JSON.parse(vm.availabilityData[k].KpiValues);
							  var graphdata1=[];
							  //console.log(obj[k]);
							   for(var n=0;n<obj[k].length;n++){
									if(obj[k][n].February !=undefined){
										var FebvalueTime=parseFloat(obj[k][n].February);
										graphdata1.push(FebvalueTime);
									}
									else if(obj[k][n].March !=undefined){
										 var MarchvalueTime=parseFloat(obj[k][n].March);
										 graphdata1.push(MarchvalueTime);
									 }
									 else if(obj[k][n].April !=undefined){
										 var AprilvalueTime=parseFloat(obj[k][n].April);
										 graphdata1.push(AprilvalueTime);
									 }
									 else if(obj[k][n].May !=undefined){
										 var MayvalueTime=parseFloat(obj[k][n].May);
										 graphdata1.push(MayvalueTime);
									 }
									else if(obj[k][n].June !=undefined){
										 var JunevalueTime=parseFloat(obj[k][n].June);
										 graphdata1.push(JunevalueTime);
									 }
									 else if(obj[k][n].July !=undefined){
										 var JulyvalueTime=parseFloat(obj[k][n].July);
										 graphdata1.push(JulyvalueTime);
									 }
									 else if(obj[k][n].August !=undefined){
										 var AugvalueTime=parseFloat(obj[k][n].August);
										 graphdata1.push(AugvalueTime);
									 }
									 else if(obj[k][n].September !=undefined){
										 var Sepvalue=parseFloat(obj[k][n].September);
										 graphdata1.push(Sepvalue)
									 }
									 else if(obj[k][n].October !=undefined){
										 var Octvalue=parseFloat(obj[k][n].October);
										 graphdata1.push(Augvalue)
									 }
									 else if(obj[k][n].November !=undefined){
										 var Novvalue=parseFloat(obj[k][n].November);
										 graphdata1.push(Novvalue)
									 }
									 else if(obj[k][n].December !=undefined){
										 var Decvalue=parseFloat(obj[k][n].December);
										 graphdata1.push(Decvalue)
									 }
									 else if(obj[k][n].January !=undefined){
										 var janvalue=parseFloat(obj[k][k].January);
										 graphdata1.push(janvalue)
									 }
									}
									var customarTarget1=[];
									for(var a=0;a<obj[k].length;a++){
										customarTarget1.push(parseFloat(vm.availabilityData[k].CustomerTarget));
									}
									console.log(graphdata1)
									var chart = Highcharts.chart(vm.availabilityData[k].KpiName, {
										colors: ['rgb(124, 181, 236)','red'],
										backgroundColor: null,
										xAxis: {      
										   labels: {
											   enabled: false
										   },
										   minorTickLength: 0,
										   tickLength: 0
										},
										yAxis:{ 
										  gridLineWidth: 0,
										  minorGridLineWidth: 0
										},
										series: [
										{
											name: 'Data',
											type: 'column',
											colorByPoint: false,
											//data: [json.KPIValues[0].Jun,json.KPIValues[1].April,json.KPIValues[2].Mar,json.KPIValues[3].Feb],
											data:graphdata1,
											showInLegend: false
										},
										{
											name: 'avarage',
											type: 'spline',
											colorByPoint: false,
											data:customarTarget1 ,
											showInLegend: false
										}],
										tooltip: {
											formatter: function() {
												var readingInMin=parseInt(this.y);
												var readingInSec=parseInt((this.y%1)*60);
												return 'Data: ' + readingInMin +'m ' + readingInSec +'s';
											}
										}
	
							});
							chart.setSize("230", "130");
						  }
						  
	        		}
	           });		
			
	
		}
		 //Trigger initial l oading - every 10 secs interval start
        var refreshPage = function() {
              $route.reload();

        };
        var interval = $interval(refreshPage, AppConst.CONST_PAGEREFRESHTIME.ONE_MINUTE);
        $scope.$on('$destroy', function() {
              $interval.cancel(interval);
        });
        //end
		vm.init();
	}
	
}());