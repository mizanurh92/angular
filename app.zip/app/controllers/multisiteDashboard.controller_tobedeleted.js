/* 
 *  ================================================================================
 *  Copyright (C) 2017
 */
(function() {
    'use strict';
    AppModule.controller("dashboardController", ["$scope", "$rootScope", "AppConst", 'AppService', 'AppSettings', '$http',"$timeout", dashboardController]);

    function dashboardController($scope, $rootScope, AppConst, AppService, AppSettings, $http, $timeout) {
        var vm = this;
        vm.dashboard = "MULTI SITE DASHBOARD";
        var siteId = 1
        //var url = "assets/jsondata/siteMetrics.json";
        var url = "engie/msd/totactivealm";
        AppService.getData(1, url).then(function(response) {
            vm.sites = response.data.Sites;
            for (var i = 0; i < vm.sites.length; i++) {
            	 var divItload = "chartdiv1"+vm.sites[i].siteid;
            	 //console.log(vm.sites[i].totalDataCenterUtlization);
            	 generateCylinderChart(divItload,vm.sites[i].totalDataCenterUtlization)
            	
            }
     
        });
       
        function generateCylinderChart(divId, data){
        	
		        var chart1 = AmCharts.makeChart(divId, {	
		       	  "theme": "light",
		       	  "type": "serial",
		       	  "depth3D": 100,
		       	  "angle": 10,
		       	  "autoMargins": false,
		       	  "marginTop":0, 
		       	  "marginBottom": 0,
		       	  "marginLeft": 0,
		       	  "marginRight": 0,
		       	  "pullOutRadius":0,
		       	  "dataProvider": data,
		       	  "valueAxes": [ {
		       	    "stackType": "100%",
		       	    "gridAlpha": 0,
		       	    "labelsEnabled": false
		       	  } ],
		       	  "graphs": [ {
		       	    "type": "column",
		       	    "topRadius": 1,
		       	    "columnWidth": 1,
		       	    "showOnAxis": false,
		       	    "lineThickness": 2,
		       	    "lineAlpha": 0.5,
		       	    "lineColor": "#FFFFFF",
		       	    "fillColors": "#1aff1a",
		       	    "fillAlphas": 0.8,
		       	    "valueField": "value1"
		       	  }, {
		       	    "type": "column",
		       	    "topRadius": 1,
		       	    "columnWidth": 1,
		       	    "showOnAxis": false,
		       	    "lineThickness": 2,
		       	    "lineAlpha": 0.5,
		       	    "lineColor": "#cdcdcd",
		       	    "fillColors": "#cdcdcd",
		       	    "fillAlphas": 0.5,
		       	    "valueField": "value2"
		       	  } ],
		
		       	  "categoryField": "category",
		       	  "categoryAxis": {
		       	    "axisAlpha": 0,
		       	    "labelOffset": 0,
		       	    "gridAlpha": 0
		       	  },
		       	  "export": {
		       	    "enabled": false
		       	  }
		       	} );
		       
		       
		        
         }
        
        /*
         * Function which loads pulse of data centre events in a pie chart
         */
        vm.loadPulseOfDataCentreEvents = function(divId){
              var seriesData = [];
              var url='/engie/msd/pulsedcevents'
              $http.get(url)
                         .then(function(res){
                         
                     vm.pulseOfDataCntrEvnts = res.data;  
                     vm.noOfSitesWithAlarms = vm.pulseOfDataCntrEvnts.noOfSiteWithAlarms;
                     vm.totActiveAlarmCnt = vm.pulseOfDataCntrEvnts.totActiveAlarmCnt;
                     vm.data = vm.pulseOfDataCntrEvnts.pulseDataDtsList;
                     
                     angular.forEach(vm.data, function (key, value) {
                            key.y = parseInt(key.perDist);
                        });
                  });
              $timeout(function(){
                     var chart = new Highcharts.Chart({
     
                             chart: {
                                 renderTo: divId,
                                 plotBackgroundColor: null,
                              plotBorderWidth: null,
                              plotShadow: false,
                                 type: 'pie'
                             },
                             title: {
                              text: 'Sites Alarm Distribution'
                          },
                          tooltip: {
                              pointFormat: '{series.siteName}: <b>{point.percentage:.1f}%</b>'
                          },  
                          plotOptions: {
                              pie: {
                                  allowPointSelect: true,
                                  cursor: 'pointer',
                                  size : 180,
                                  dataLabels: {
                                      enabled: true,
                                      format: '{point.siteName}<br/> {point.percentage:.1f} %',
                                      distance: -30,
                                         style: {
                                             fontWeight: 'bold',
                                             color: 'white'
                                         }
                                  },
                                  showInLegend: false,
                              }
                          }, 
                             series: [{
                                colorByPoint: true,
                                 data: vm.data
                             }]
     
                         });
              }, 1000);
        };

        
        
    }
}())