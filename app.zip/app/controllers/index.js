'use strict';

var angular = require('angular');

AppModule.controller('dashboardController', require('./dashboardController'));