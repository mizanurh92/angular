/* 
 *  ================================================================================
 *  Copyright (C) 2017
 */ 

(function() {
	'use strict';
	
	AppModule.controller("eventsAnalytics2",["$scope","AppConst","AppService","ChartService","$route","$interval","$http",eventsAnalytics2]);

	function eventsAnalytics2($scope,AppConst,AppService,ChartService,$route,$interval,$http) {
		var vm=this;
		var fullScreenMap={"totalEventActivity":{
			"url":"/ops/eventAnalytics/getTotalEventActivityByDay",
			"serviceType":"getTotalEventActivityByDay"
			},
			"mostFrequentEquipment":{
				"url":"/ops/eventAnalytics/getMostFrequentEquipment",
				"serviceType":"getMostFrequentEquipment"
			},
			"top20MostFrequentEvents":{
				"url":"/ops/eventAnalytics/getTop20MostFrequentEvents",
				"serviceType":"getTop20MostFrequentEvents"
			},
			"EventsTrendByMonth":{
				"url":"/ops/eventAnalytics/getEventsTrendByMonth",
				"serviceType":"getEventsTrendByMonth"
			},
			"TrendsEventsbyCategory":{
				"url":"/ops/eventAnalytics/getEventsTrendByCategory",
				"serviceType":"getEventsTrendByCategory"
			}
		};
		
		vm.init = function(){
			
	        var eventsAnalyticsByDayUrl = "/ops/eventAnalytics/getTotalEventActivityByDay";
		    var getTop20MostFrequentEventsUrl="/ops/eventAnalytics/getTop20MostFrequentEvents";
		    var getMostFrequentEquipmentUrl="/ops/eventAnalytics/getMostFrequentEquipment";
		    var getEventsTrendByCategoryUrl="/ops/eventAnalytics/getEventsTrendByCategory";
		    var getEventsTrendByMonthUrl="/ops/eventAnalytics/getEventsTrendByMonth";
  			var _postData =	{
					"siteid":"sdslab",
					"serviceType":"activeEvents"
				};

		               
//		               ChartService.rateOfAck("ratePerHourAck",50);
		             
		               
			_postData =	{
   					"site":"sdslab",
   					"serviceType":"getTotalEventActivityByDay"
   				};
   	
   			    AppService.postData(_postData,eventsAnalyticsByDayUrl).then(function(response) {
                   if (response.status === 200 && response.data) {
                	   /*console.log("response is response.data);
*/                	   ChartService.stackedAreaChartbyAmChart("totalEventActivity",response.data);
                	   
                   }
   			    })
   			    
   			    
   			     _postData =	{
   					"site":"sdslab",
   					"serviceType":"getTop20MostFrequentEvents"
   				};
   	
   			    AppService.postData(_postData,getTop20MostFrequentEventsUrl).then(function(response) {
                   if (response.status === 200 && response.data) {
                	   ChartService.topMostFrequentEventsOrEquipments("top20MostFrequentEvents",response.data);//("totalEventActivity",response.data);
                   }
   			    })
   			    
   			    
   			     _postData =	{
   					"site":"sdslab",
   					"serviceType":"getMostFrequentEquipment"
   				};
   	
   			    AppService.postData(_postData,getMostFrequentEquipmentUrl).then(function(response) {
                   if (response.status === 200 && response.data) {
                	   ChartService.topMostFrequentEventsOrEquipments("mostFrequentEquipment",response.data);//("totalEventActivity",response.data);
                   }
   			    })
		               
		                  _postData =	{
			   					"site":"sdslab",
			   					"serviceType":"getEventsTrendByCategory"
			   				};
			   	
			   			    AppService.postData(_postData,getEventsTrendByCategoryUrl).then(function(response) {
			                   if (response.status === 200 && response.data) {
			                	   ChartService.eventsTrendByCategoryOrHistory("TrendsEventsbyCategory",response.data);//("totalEventActivity",response.data);
			                   }
			   			    })
			   			    
			   			    
			   			     _postData =	{
			   					"site":"sdslab",
			   					"serviceType":"getEventsTrendByMonth"
			   				};
			   	
			   			    AppService.postData(_postData,getEventsTrendByMonthUrl).then(function(response) {
			                   if (response.status === 200 && response.data) {
			                	   ChartService.eventsTrendByCategoryOrHistory("EventsTrendByMonth",response.data);//("totalEventActivity",response.data);
			                   }
			   			    })
		               
		}    
		
		
		var postdata =	{
					"site":"sdslab",
					"serviceType":"getTotalEventActivityByDay"
				};
		AppService.postData(postdata,"/ops/eventAnalytics/getTotalEventActivityByDay").then(function(response) {
            if (response.status === 200 && response.data) {
         	  
         	   vm.globalStartdate = response.data[0].day;
         	   vm.gobalEndDate = response.data[69].day;
            }
		    })
		
		
		
		
		
		
		vm.fullScreenChart = function(targetChart){
			
			
			 $('#fullScreenChart').modal('show');
			
			var _postData =	{
   					"site":"sdslab",
   					"serviceType":fullScreenMap[targetChart].serviceType
   				};
			
			    AppService.postData(_postData,fullScreenMap[targetChart].url).then(function(response) {
                   if (response.status === 200 && response.data) {
                	  
                	   if("totalEventActivity"==targetChart){
                		  
                		   if(vm.eventObj.serviceStartDate===undefined) {
                			   vm.eventObj.serviceStartDate = response.data[0].day;
                			   vm.eventObj.serviceEndDate =  response.data[69].day;
               				}
                		   	vm.modelLabel = "Total Event Activity";
                		    ChartService.stackedAreaChartbyAmChart("fullScreenChartContainer",response.data);
                	   }
                	   else if("mostFrequentEquipment"==targetChart || "top20MostFrequentEvents"==targetChart ){ 
                		   if("mostFrequentEquipment"==targetChart) {
                			   vm.eventObj.serviceStartDate = vm.globalStartdate;
                			   vm.eventObj.serviceEndDate =  vm.gobalEndDate;
                			   vm.modelLabel = "Top 20 Equipment Triggered Events";
                		   }else if("top20MostFrequentEvents"==targetChart) {
                			   vm.eventObj.serviceStartDate = vm.globalStartdate;
                			   vm.eventObj.serviceEndDate =  vm.gobalEndDate;
                			   vm.modelLabel = "Top 20 Most Frequent Events over";
                		   }
                		   
                		   //console.log("wquipment : "+vm.eventObj.serviceStartDate1);
                		  // console.log("20 most frequest : "+vm.eventObj.serviceStartDate2);
                   		   ChartService.topMostFrequentEventsOrEquipments("fullScreenChartContainer",response.data);
                	  }
                	   else if("EventsTrendByMonth"==targetChart || "TrendsEventsbyCategory"==targetChart ){ 
                		   if("EventsTrendByMonth"==targetChart) {
                			   
                			   vm.eventObj.serviceStartDate = response.data.categories[0];
                			   vm.eventObj.serviceEndDate =  response.data.categories[3];
                			   vm.modelLabel = "Historical Event Trend";
                		   }else if("TrendsEventsbyCategory"==targetChart) {
                			   vm.eventObj.serviceStartDate = vm.globalStartdate;
                			   vm.eventObj.serviceEndDate =  vm.gobalEndDate;
                			   vm.modelLabel = "Trends of Events by Category";
                		   }
                   		   ChartService.eventsTrendByCategoryOrHistory("fullScreenChartContainer",response.data);
                   	  }
         	   
                   }
   			    })
   			
   			 
   			 /*$(document).on("hidden.bs.modal", "#myModalID", function () {
				 alert("hai");
			 $(this).find("#info").html(""); // Just clear the contents.
			
			 });*/
   			    
		}
		
		$('#fullScreenChart').on("hidden.bs.modal",  function () {
			console.log("remove date");
			//$('.removeDate').remove();
			//$(this).find(".removeDate").html("");
		 });
		
			    
		
		
		
		
		
		
		vm.totalEventPrint=function(){
			$("#totalEventPrint .margin5px").css("display","none");
			var fileName="totalEvent.pdf";
			var EventActivity=document.getElementById("totalEventPrint");
			domtoimage.toPng(EventActivity).then(function(dataUrl) {
				var dwidth=$("#totalEventPrint").width();
					var dheight=$("#totalEventPrint").height();
					var _postPdfData =	{
                		"images":[
							{  
							    "data":dataUrl,
							    "width":dwidth,
							    "height": dheight      							 
							   }						   
                		 ]		
					};
					_postPdfData = JSON.parse(angular.toJson(_postPdfData));
						var pdfUrl = "ops/engie/printpdf ";
						$http.post(pdfUrl,_postPdfData,{responseType:'arraybuffer'}).then(function onSuccess(response) {
							if (response.data) {    						
								var file = new Blob([response.data], {type: 'application/pdf'});
								var fileURL = window.URL.createObjectURL(file);
								if(response && response.data){
									var a = document.createElement("a");
									document.body.appendChild(a);
									a.href = fileURL;
									console.log(fileURL);
									a.download = fileName;
									a.click();
								}
							}

						});
				  
				})
				.catch(function(error) {
				  console.error('oops, something went wrong!', error);
				});
				setTimeout(function(){$("#totalEventPrint .margin5px").css("display","block"); }, 10);
		}
		vm.mostFrequentEquipment=function(){
			$("#mostFrequentEquipmentDiv .margin5px").css("display","none");
			var fileName="mostFrequentEquipment.pdf";
			var mostFrequentEquipmentDiv=document.getElementById("mostFrequentEquipmentDiv");
			console.log(mostFrequentEquipmentDiv);
			domtoimage.toPng(mostFrequentEquipmentDiv).then(function(dataUrl1) {
				var dwidth=$("#mostFrequentEquipmentDiv").width();
					var dheight=$("#mostFrequentEquipmentDiv").height();
					var _postPdfData =	{
                		"images":[
							{  
							    "data":dataUrl1,
							    "width":dwidth,
							    "height": dheight      							 
							   }						   
                		 ]		
					};
					_postPdfData = JSON.parse(angular.toJson(_postPdfData));
						var pdfUrl = "ops/engie/printpdf ";
						$http.post(pdfUrl,_postPdfData,{responseType:'arraybuffer'}).then(function onSuccess(response) {
							if (response.data) {    						
								var file = new Blob([response.data], {type: 'application/pdf'});
								var fileURL = window.URL.createObjectURL(file);
								if(response && response.data){
									var a = document.createElement("a");
									document.body.appendChild(a);
									a.href = fileURL;
									console.log(fileURL);
									a.download = fileName;
									a.click();
								}
							}

						});
				  
				})
				.catch(function(error) {
				  console.error('oops, something went wrong!', error);
				});
				setTimeout(function(){$("#mostFrequentEquipmentDiv .margin5px").css("display","block"); }, 10);
		}
		vm.TrendsEventsbyCategory=function(){
			$("#TrendsEventsbyCategoryDiv .margin5px").css("display","none");
			var fileName="TrendsEventsbyCategory.pdf";
			var TrendsEventsbyCategory=document.getElementById("TrendsEventsbyCategoryDiv");
			domtoimage.toPng(TrendsEventsbyCategory).then(function(dataUrl2) {
				var dwidth=$("#TrendsEventsbyCategory").width();
					var dheight=$("#TrendsEventsbyCategory").height();
					var _postPdfData =	{
                		"images":[
							{  
							    "data":dataUrl2,
							    "width":dwidth,
							    "height": dheight      							 
							   }						   
                		 ]		
					};
					_postPdfData = JSON.parse(angular.toJson(_postPdfData));
						var pdfUrl = "ops/engie/printpdf ";
						$http.post(pdfUrl,_postPdfData,{responseType:'arraybuffer'}).then(function onSuccess(response) {
							if (response.data) {    						
								var file = new Blob([response.data], {type: 'application/pdf'});
								var fileURL = window.URL.createObjectURL(file);
								if(response && response.data){
									var a = document.createElement("a");
									document.body.appendChild(a);
									a.href = fileURL;
									console.log(fileURL);
									a.download = fileName;
									a.click();
								}
							}

						});
				  
				})
				.catch(function(error) {
				  console.error('oops, something went wrong!', error);
				});
				setTimeout(function(){$("#TrendsEventsbyCategory .margin5px").css("display","block"); }, 10);
		}
		vm.top20MostFrequentEvents=function(){
			$("#mostFrequentEventsDiv .margin5px").css("display","none");
			var fileName="top20MostFrequentEvents.pdf";
			var top20MostFrequentEvents=document.getElementById("mostFrequentEventsDiv");
			domtoimage.toPng(top20MostFrequentEvents).then(function(dataUrl3) {
				var dwidth=$("#top20MostFrequentEvents").width();
					var dheight=$("#top20MostFrequentEvents").height();
					var _postPdfData =	{
                		"images":[
							{  
							    "data":dataUrl3,
							    "width":dwidth,
							    "height": dheight      							 
							   }						   
                		 ]		
					};
					_postPdfData = JSON.parse(angular.toJson(_postPdfData));
						var pdfUrl = "ops/engie/printpdf ";
						$http.post(pdfUrl,_postPdfData,{responseType:'arraybuffer'}).then(function onSuccess(response) {
							if (response.data) {    						
								var file = new Blob([response.data], {type: 'application/pdf'});
								var fileURL = window.URL.createObjectURL(file);
								if(response && response.data){
									var a = document.createElement("a");
									document.body.appendChild(a);
									a.href = fileURL;
									console.log(fileURL);
									a.download = fileName;
									a.click();
								}
							}

						});
				  
				})
				.catch(function(error) {
				  console.error('oops, something went wrong!', error);
				});
				setTimeout(function(){$("#top20MostFrequentEvents .margin5px").css("display","block"); }, 10);
		}
		vm.EventsTrendByMonth=function(){
			$("#HistoricalEvents .margin5px").css("display","none");
			var fileName="EventsTrendByMonth.pdf";
				var EventsTrendByMonth=document.getElementById("HistoricalEvents");
			domtoimage.toPng(EventsTrendByMonth).then(function(dataUrl4) {
				var dwidth=$("#EventsTrendByMonth").width();
					var dheight=$("#EventsTrendByMonth").height();
					var _postPdfData =	{
                		"images":[
							{  
							    "data":dataUrl4,
							    "width":dwidth,
							    "height": dheight      							 
							   }						   
                		 ]		
					};
					_postPdfData = JSON.parse(angular.toJson(_postPdfData));
						var pdfUrl = "ops/engie/printpdf ";
						$http.post(pdfUrl,_postPdfData,{responseType:'arraybuffer'}).then(function onSuccess(response) {
							if (response.data) {    						
								var file = new Blob([response.data], {type: 'application/pdf'});
								var fileURL = window.URL.createObjectURL(file);
								if(response && response.data){
									var a = document.createElement("a");
									document.body.appendChild(a);
									a.href = fileURL;
									console.log(fileURL);
									a.download = fileName;
									a.click();
								}
							}

						});
				  
				})
				.catch(function(error) {
				  console.error('oops, something went wrong!', error);
				});
				setTimeout(function(){$("#HistoricalEvents .margin5px").css("display","block"); }, 10);
		}
		function rateOfAck(divid){
			

			setInterval(randomValue, 2000);

			// set random value
			function randomValue() {
			  var value = Math.round(Math.random() * 100);
			  chart.arrows[0].setValue(value);
			  chart.axes[0].setTopText(value);
			  // adjust darker band to new value
			  chart.axes[0].bands[1].setEndValue(value);
			}
		
	}
		var today = new Date();
		vm.eventObj = {};
		/*vm.siteObj.serviceStartDate = new Date();*/
        //vm.eventObj.serviceStartDate = new Date();
        //vm.eventObj.serviceEndDate = new Date();
        vm.dateFormat = 'yyyy-MM-dd';
        vm.availableDateOptions = {
            formatYear: 'yy',
            startingDay: 1,
            minDate: today,
            maxDate: new Date(2030, 5, 22)
        };
        
        vm.serviceStartDatePopup = {
            opened: false
        };
        vm.serviceEndDatePopup = {
                opened: false
        };
        //TotEvntActOvr60DaysPerd
        vm.OpenserviceStartDate = function() {
            vm.serviceStartDatePopup.opened = !vm.serviceStartDatePopup.opened;
        };
        vm.OpenserviceEndDate = function() {
            vm.serviceEndDatePopup.opened = !vm.serviceEndDatePopup.opened;
        };
        //MostFrequentEquipmentOver60daysPeriod
        vm.serviceStartDatePopup1 = {
                opened: false
        };
        vm.serviceEndDatePopup1 = {
                    opened: false
        };
        vm.OpenserviceStartDate1 = function() {
            vm.serviceStartDatePopup1.opened = !vm.serviceStartDatePopup1.opened;
        };
         
        vm.OpenserviceEndDate1 = function() {
            vm.serviceEndDatePopup1.opened = !vm.serviceEndDatePopup1.opened;
        };
        
      //Top20MostFrequentEventsOver60daysPeriod
        vm.serviceStartDatePopup2 = {
                opened: false
        };
        vm.serviceEndDatePopup2 = {
                    opened: false
        };
        vm.OpenserviceStartDate2 = function() {
            vm.serviceStartDatePopup2.opened = !vm.serviceStartDatePopup2.opened;
        };
         
        vm.OpenserviceEndDate2 = function() {
            vm.serviceEndDatePopup2.opened = !vm.serviceEndDatePopup2.opened;
        };
        
        vm.eventActivityDateRange = function(reportName){
        	vm.submitted=true;
        	console.log("reportName="+reportName+ " st date= "+vm.eventObj.serviceStartDate+ " endDt:"+vm.eventObj.serviceEndDate)
        		if("TotEvntActOvr60DaysPerd"===reportName){
        			if(vm.siteForm.$valid) {
        				if(vm.eventObj.serviceStartDate>vm.eventObj.serviceEndDate){
        					vm.invalidperiod=true;
        					vm.exceededperiod=false;
        				}else if(vm.eventObj.serviceEndDate>new Date()) {
        					vm.invalidperiod=false;
        					vm.exceededperiod=true;
        					vm.errorMsg = false;
    	             		
        				}
        				else {
        					vm.errorMsg = false;
        					vm.invalidperiod=false;
        					vm.exceededperiod=false;
        					var eventsAnalyticsByDayUrl = "/ops/eventAnalytics/getTotalEventActivityByDay";
        		        	var  _postData =	{
        				   					"site":"sdslab",
        				   					"serviceType":"getTotalEventActivityByDay",
        				   					"startDate":vm.eventObj.serviceStartDate,
        				   					"endDate":vm.eventObj.serviceEndDate,
        				   				};
        				   			    AppService.postData(_postData,eventsAnalyticsByDayUrl).then(function(response) {
        				                   if (response.status === 200 && response.data) {
        				                	   ChartService.stackedAreaChartbyAmChart("totalEventActivity",response.data);
        				                   }
        				   			    })
        				}
        				
	        	 }else {
	        		 vm.invalidperiod=false;
 					vm.exceededperiod=false;
	             		vm.errorMsg = true;
	             		vm.errorMsg1 = false;
	             		vm.errorMsg2 = false;
			     }
        		}else if("MostFrequentEquipmentOver60daysPeriod"===reportName){
        			if(vm.siteForm1.$valid) {
        				if(vm.eventObj.serviceStartDate1>vm.eventObj.serviceEndDate1){
        					vm.invalidperiod1=true;
        					vm.exceededperiod1=false;
        				}else if(vm.eventObj.serviceEndDate1>new Date()) {
        					vm.invalidperiod1=false;
        					vm.exceededperiod1=true;
        					vm.errorMsg1 = false;
        				}
        				else {
        					vm.errorMsg1 = false;
        					vm.invalidperiod1=false;
        					vm.exceededperiod1=false;
			        	var getMostFrequentEquipmentUrl="/ops/eventAnalytics/getMostFrequentEquipment";
	
			        	_postData =	{
			   					"site":"sdslab",
			   					"serviceType":"getMostFrequentEquipment",
			   					"startDate":vm.eventObj.serviceStartDate1,
			   					"endDate":vm.eventObj.serviceEndDate1,
			   				};
			   			    AppService.postData(_postData,getMostFrequentEquipmentUrl).then(function(response) {
			                   if (response.status === 200 && response.data) {
			                	   ChartService.topMostFrequentEventsOrEquipments("mostFrequentEquipment",response.data);
			                   }
			   			    })
        				}
        				}else {
        					vm.invalidperiod1=false;
        					vm.exceededperiod1=false;
        				vm.errorMsg = false;
	             		vm.errorMsg1 = true;
	             		vm.errorMsg2 = false;
	             		/*alert("service dates are required");*/
	             	
			     }   			    
				    }else{//Top20MostFrequentEventsOver60daysPeriod
				    	if(vm.siteForm2.$valid) {
				    		if(vm.eventObj.serviceStartDate2>vm.eventObj.serviceEndDate2){
	        					vm.invalidperiod2=true;
	        					vm.exceededperiod2=false;
	        				}else if(vm.eventObj.serviceEndDate2>new Date()) {
	        					vm.invalidperiod2=false;
	        					vm.exceededperiod2=true;
	        					vm.errorMsg2 = false;
	        				}
	        				else {
	        					vm.errorMsg2 = false;
	        					vm.invalidperiod2=false;
	        					vm.exceededperiod2=false;
				    	console.log(" in side Top20MostFrequentEventsOver60daysPeriod");
				    	console.log(" st date2:" +vm.eventObj.serviceStartDate2+ " end dt2:"+vm.eventObj.serviceEndDate2);
				    	var getTop20MostFrequentEventsUrl="/ops/eventAnalytics/getTop20MostFrequentEvents";
				    	 _postData =	{
				   					"site":"sdslab",
				   					"serviceType":"getTop20MostFrequentEvents",
				   					"startDate":vm.eventObj.serviceStartDate2,
				   					"endDate":vm.eventObj.serviceEndDate2,
				   				};
				   			    AppService.postData(_postData,getTop20MostFrequentEventsUrl).then(function(response) {
				                   if (response.status === 200 && response.data) {
				                	   ChartService.topMostFrequentEventsOrEquipments("top20MostFrequentEvents",response.data);
				                   }
				   			    })
	        				}
				    	} else {
				    		vm.invalidperiod2=false;
        					vm.exceededperiod2=false;
				    		vm.errorMsg = false;
		             		vm.errorMsg1 = false;
		             		vm.errorMsg2 = true;
				             		/*alert("service dates are required");*/
				             	
						     }  
				    
				    
				    }
        	
       
        	
        }
        
        //Date range end
        
      //Trigger initial l oading - every 10 secs interval start
       /* var refreshPage = function() {
              $route.reload();

        };
        var interval = $interval(refreshPage, AppConst.CONST_PAGEREFRESHTIME.ONE_MINUTE);
        $scope.$on('$destroy', function() {
              $interval.cancel(interval);
        });*/
        //end 
		
		 vm.init();

}}())