/* 
 *  ================================================================================
 *  Copyright (C) 2017
 */
(function() {
    'use strict';
    AppModule.controller("dashboardController", ["$scope", "$rootScope", "AppConst", 'AppService', 'AppSettings', '$http', "$timeout", 'CommonService', 'StateModel', '$routeParams', '$location', "$sessionStorage", "$localStorage", "$window", "$route", "$templateCache", "$cookies","$interval", "linkService",  dashboardController]);
 
    function dashboardController($scope, $rootScope, AppConst, AppService, AppSettings, $http, $timeout, CommonService, StateModel, $routeParams, $location, $sessionStorage, $localStorage, $window, $route, $templateCache, $cookies, $interval, linkService) {
        var vm = this;
        //console.log("$sessionStorage.userId", $sessionStorage.userId);/* Storing the userid to session */
        
        vm.dashboard = "MULTI SITE DASHBOARD";        
        vm.temperature = "Temperature";
        vm.humidity = "Humidity";
        vm.currentDate =  Date.now();
        vm.siteNavId = "sdslab";
        vm.pwdErrorMsg = false;
    	vm.isLoading = false;
    	vm.showMultisite = true;
    	vm.showOpr = false;
    	vm.showAsset=false;
    	vm.showServiceTracking=false;
        /*$sessionStorage.userId = "anilkumar@engie.com";*/
    	if($sessionStorage.userId === undefined){    		
			$route.reload();
			$location.path("/");
			$templateCache.removeAll();		               
    	}
    	
    	
    	
    	var filename = $location.path().substring($location.path().indexOf('/')+1);
    	var lab = $location.path().substring($location.path().lastIndexOf('/')+1);
    	
    	console.log("labNmae is : "+lab);
    	console.log("filename is : "+filename);
    	var activePage = linkService.activePage(filename);

    	//alert(JSON.stringify(activePage));
    	
    	if(activePage === undefined || activePage === null){ 
    		
    		vm.showMultisite = true;    	
	    	vm.showOpr = true;    
	    	vm.showAsset= true; 
	    	vm.showServiceTracking=true;
	    	vm.selectedDO = false;    
	     	vm.selectedMultiSite = false;   
	     	vm.selectedOPS = false;   
	       	vm.selectedFloor = false;  
	       	vm.selectedElectrical = false; 
	       	vm.selectedSingleLine = false;
	       	vm.selectedAncillary = false; 
	       	vm.selectedLog = false;  
	       	vm.selectedActive = false;   
	       	vm.selectedInactive = false;
	       	vm.selectedTrends = false; 
	       	vm.selectedTrends1 = false;    
	       	vm.selectedTrends2 = false;  
	    	vm.selectedKpi = false;    
	    	vm.selectedkpiEfficiency = false;   
	    	vm.selectedkpiPower = false;    
	    	vm.selectedkpiMechanical = false;    
	    	vm.selectedkpiAir = false;   
	    	vm.selectedkpiAvailability =false;    
	    	vm.selectedAssetP= false;   
	    	vm.selectedCRAC= false;
	    	vm.selecteSerTrack= false;
    		vm.selectedserviceAction= false;
			vm.dataCenterIcon = "settings.png";

    	}else{
    		console.log("upon refreshing : "+activePage.dcIconActive);
	    	vm.showMultisite = activePage.showMultisite;    	
	    	vm.showOpr = activePage.showOpr;
	    	vm.showAsset=activePage.showAsset;
	    	vm.showServiceTracking=activePage.showServiceTracking;
	    	vm.selectedDO = activePage.selectedDO;
	     	vm.selectedMultiSite = activePage.selectedMultiSite;
	     	vm.selectedOPS = activePage.selectedOPS;
	       	vm.selectedFloor =activePage.selectedFloor;
	       	vm.selectedElectrical = activePage.selectedElectrical;
	       	vm.selectedSingleLine = activePage.selectedSingleLine;
	       	vm.selectedAncillary = activePage.selectedAncillary;
	       	vm.selectedLog = activePage.selectedLog;
	       	vm.selectedActive = activePage.selectedActive;
	       	vm.selectedInactive = activePage.selectedInactive;
	       	vm.selectedTrends = activePage.selectedTrends;
	       	vm.selectedTrends1 = activePage.selectedTrends1;
	       	vm.selectedTrends2 = activePage.selectedTrends2;
	    	vm.selectedKpi = activePage.selectedKpi;
	    	vm.selectedkpiEfficiency = activePage.selectedkpiEfficiency;
	    	vm.selectedkpiPower = activePage.selectedkpiPower;
	    	vm.selectedkpiMechanical = activePage.selectedkpiMechanical;
	    	vm.selectedkpiAir = activePage.selectedkpiAir;
	    	vm.selectedkpiAvailability = activePage.selectedkpiAvailability;
	    	vm.selectedAssetP= activePage.selectedAssetP;
			vm.selectedCRAC= activePage.selectedCRAC;
			vm.dataCenterIcon = activePage.dcIconActive;
			vm.selecteSerTrack=activePage.selecteSerTrack;
    		vm.selectedserviceAction= activePage.selectedserviceAction;
			
    	}
		
    	
      var upslistassetInfo = 'assetperformance/engie/service/assetperformance/upslist?userId='+$sessionStorage.userId+'&siteId='+'sdslab'+'&assetId='+'&actionType='+'ASSETPERFORMANCE_UPS_LIST';
				AppService.getData(1, upslistassetInfo).then(function(response) {
	        	   if (response.status === 200 && response.data) {
					$scope.upslistassetInfoData = response.data;
					/*Setting the default selected index */
					
					
						$scope.updateAssets=function(param,activeIndexCarousel){
							console.log("param",param);
							var assetId=param.assetID;
							var pollingInterval=param.pollingInterval;
							$rootScope.assetID=assetId;
							$rootScope.pollingInterval=pollingInterval;
							$localStorage.assetID=assetId;
							$localStorage.pollingInterval=pollingInterval;
							$localStorage.siteId=vm.siteNavId;
							$localStorage.activeIndexCarousel=activeIndexCarousel;
							console.log($localStorage.assetID,"assetId");
							console.log($localStorage.activeIndexCarousel,"activeIndexCarousel");
							$rootScope.$broadcast('selectedID', {
                              pro1:assetId, 
                              pro2:pollingInterval, // send whatever you want
                              pro3:activeIndexCarousel
                         });
						}
	                }
	           });
	   
        
        if ($location.path() === "/" || $location.path() === "/"+ AppConst.CONST_VAR.AUTHENTICATE || $location.path() === "/"+ AppConst.CONST_VAR.FORCECHANGEPWD) {
            vm.showSidebar = false;
            $location.bgroundLogin = "backgroundlogin";
        } else {
            vm.showSidebar = true;
            $location.bgroundLogin = "";
        }
        
        $rootScope.$on('$routeChangeSuccess', function(e, curr, prev) {       	
        	$scope.routeName = $route.current.$$route.originalPath;
        	$localStorage.routeName = $scope.routeName;
        		
        	$scope.viewSiteDropdown = true;
            if ($scope.routeName === "/"+ AppConst.CONST_VAR.HOME 
            	|| $scope.routeName === "/" 
            	|| $scope.routeName === "/"+ AppConst.CONST_VAR.AUTHENTICATE
            	|| $scope.routeName === "/"+ AppConst.CONST_VAR.FORCECHANGEPWD
            	|| $scope.routeName === "/"+ AppConst.CONST_VAR.USERLIST
            	|| $scope.routeName === "/"+ AppConst.CONST_VAR.ROLELIST
            	|| $scope.routeName === "/"+ AppConst.CONST_VAR.SITELIST
            	|| $scope.routeName === "/"+ AppConst.CONST_VAR.GROUPLIST) {
            		$scope.viewSiteDropdown = true;
            }else if($scope.routeName === "/"+ AppConst.CONST_VAR.HOME 
                || $scope.routeName === "/" 
                || $scope.routeName === "/"+ AppConst.CONST_VAR.AUTHENTICATE
                || $scope.routeName === "/"+ AppConst.CONST_VAR.FORCECHANGEPWD){
            		vm.showSidebar = false;
            	
            }else{        	
            	if($routeParams.siteid !==undefined){
        		vm.siteNavId = $routeParams.siteid;            	
        		$localStorage.siteNavId = vm.siteNavId;            	
        		$scope.viewSiteDropdown = false;
        		vm.showSidebar = true;
                }else{
                	vm.siteNavId = "sdslab";
                }
            		
            }
        });

        vm.cognito = {};
        vm.pwdDtl = {};
        vm.cognito.cognitoUser = null;
        vm.isLoading = false;
        /*
         * PoolId and Client Id initialization for AWS cognito
         */
        vm.cognito.poolData = {
                UserPoolId : 'us-west-2_nbnh1KDRo', 
                ClientId : '2ej9a3uj13n0mrm95ar1skpo0v' 
        };
        vm.showModalCP = false;
        vm.userName = $sessionStorage.userId;
        console.log(vm.userName);
        
       if(vm.userName){
    	   		var namecorrect= vm.userName.substring(0,vm.userName.lastIndexOf("@"));
    	   		vm.name= namecorrect;
       } 	   

        vm.init = function() {
            vm.userPriviledges();
            var convertUTCToLocal=-1;
            var timezoneOffetInMin=new Date().getTimezoneOffset()*convertUTCToLocal;
            var multisiteUrl = 'ops/engie/service/multisitehome?userId='+$sessionStorage.userId+'&siteId='+'&timezoneOffetInMin='+timezoneOffetInMin;
            //var multisiteUrl = 'engie/service/multisitehome?userId='+$sessionStorage.userId+'&siteId=';
            AppService.getData(1, multisiteUrl).then(function(response) {
                vm.dashboardData = response.data;
                vm.siteDetails = vm.dashboardData.siteDetails;
                AppService.siteServiceStartDate("SET",vm.siteDetails);
            });
        };

        vm.redirectExecutiveOverview = function(siteid,startDate) {
            $location.path(AppConst.CONST_VAR.EXECUTIVEOVERVIEWCTR + "/" + siteid);
            vm.onClickTopMenu("operations");
           if(siteid=="sdslac") {
        	   vm.selectedSdslac = 'active';
        	   vm.selectedSdslab ='';
        	   vm.selectedUstlab ='';
           }else if(siteid == "sdslab") {
        	   vm.selectedSdslac = '';
        	   vm.selectedSdslab ='active';
        	   vm.selectedUstlab ='';
           }else if(siteid == "ustlab") {
        	   
        	   vm.selectedSdslac = '';
        	   vm.selectedSdslab ='';
        	   vm.selectedUstlab ='active';
           }
        };
        
        vm.onClickTopMenu = function(menuId) {
        	
             
           /* alert(menuId);*/
        	
        	if(menuId=="multisite") {
        		
	        	$location.path("ops/"+AppConst.CONST_VAR.HOME);
	        	vm.showAsset=false;
	        	vm.showOpr = false;
	        	vm.showMultisite = true;
	        	vm.showServiceTracking=false;
	        	vm.dataCenterIcon = "settings.png";
	        	$("#"+menuId).addClass("active");
	        	
        	}else if(menuId=="operations") {
         		
        		vm.showAsset=false;
	        	vm.showMultisite = false;
	        	vm.showOpr = true;
	        	vm.showServiceTracking=false;
	        	vm.dataCenterIcon = "settingsActive.png";
	        	$("#"+menuId).addClass("active");
	        	
	           	
         	}else if(menuId=="assetperformance"){
         		$("#"+menuId).addClass("active");
        		vm.showAsset=true;
	        	vm.showOpr = false;
	        	vm.showMultisite = false;
	        	vm.showServiceTracking=false;
	        	vm.dataCenterIcon = "settings.png";
            }else if(menuId=="userList" || menuId=="roleList" || menuId=="siteList" || menuId=="groupList") {
            	vm.showAsset=false;
        	    vm.showOpr = false;
        	    vm.showMultisite = true;
	        	vm.showServiceTracking=false;
        	    vm.dataCenterIcon = "settings.png";
        	    $("#"+menuId).addClass("active");
        	    
            }else if(menuId=="servicetracking"){
            	
            	$("#"+menuId).addClass("active");
        		vm.showAsset=false;
	        	vm.showOpr = false;
	        	vm.showMultisite = false;
	        	vm.showServiceTracking=true;
	        	vm.dataCenterIcon = "settings.png";
            }
        	
        	var selectedItem = linkService.clickedItem(menuId);
        	vm.selectedDO = selectedItem.selectedDO;
         	vm.selectedMultiSite = selectedItem.selectedMultiSite;
         	vm.selectedOPS = selectedItem.selectedOPS;
           	vm.selectedFloor =selectedItem.selectedFloor;
           	vm.selectedElectrical = selectedItem.selectedElectrical;
           	vm.selectedSingleLine = selectedItem.selectedSingleLine;
           	vm.selectedAncillary = selectedItem.selectedAncillary;
           	vm.selectedLog = selectedItem.selectedLog;
           	vm.selectedActive = selectedItem.selectedActive;
           	vm.selectedInactive = selectedItem.selectedInactive;
           	vm.selectedTrends = selectedItem.selectedTrends;
           	vm.selectedTrends1 = selectedItem.selectedTrends1;
           	vm.selectedTrends2 = selectedItem.selectedTrends2;
        	vm.selectedKpi = selectedItem.selectedKpi;
        	vm.selectedkpiEfficiency = selectedItem.selectedkpiEfficiency;
        	vm.selectedkpiPower = selectedItem.selectedkpiPower;
        	vm.selectedkpiMechanical = selectedItem.selectedkpiMechanical;
        	vm.selectedkpiAir = selectedItem.selectedkpiAir;
        	vm.selectedkpiAvailability = selectedItem.selectedkpiAvailability;
        	vm.selectedAssetP= selectedItem.selectedAssetP;
        	vm.selectedCRAC= selectedItem.selectedCRAC;
        	vm.selecteSerTrack=selectedItem.selecteSerTrack;
    		vm.selectedserviceAction= selectedItem.selectedserviceAction;
    		vm.eventToggle = selectedItem.eventToggle;
    		vm.trendToggle = selectedItem.trendToggle;
    		vm.kpiToggle = selectedItem.kpiToggle;
    		
        };

        

        /*  user profile              */

        vm.showModal = false;
        vm.userProfileModal = function() {
            $scope.showModal = !$scope.showModal;
            $(".userProfileModal").modal("show");                    
            var url = 'ops/engie/user/userprofile';
            var user = {
                "emailid": $sessionStorage.userId
            };
            vm.emailId = user.emailid;
            $http.post(url, user).
            then(function(response) {
               
                vm.userprofile = response.data;
                vm.userName = vm.userName;
                vm.company = vm.userprofile.company;
                vm.designation = vm.userprofile.designation;
                vm.userId = vm.userprofile.userId;
                var dateTime = vm.userprofile.lastLoginTime.split(" ");
            	var date = new Date(dateTime[0])
                vm.lastLoginDate = getFormattedDate(date);
                vm.lastLoginTime = dateTime[1];
                vm.duration = vm.userprofile.duration;
            });


        };

        /*  end of user profile  */
        
     /*   for date format starts here*/
        function getFormattedDate(date) {
			  var year = date.getFullYear();

			  var month = (1 + date.getMonth()).toString();
			  month = month.length > 1 ? month : '0' + month;

			  var day = date.getDate().toString();
			  day = day.length > 1 ? day : '0' + day;
			  
			  return day + '/' + month + '/' + year;
			}

        /*   for date format ends here*/

        /* site profile  */

        vm.showsiteModal = false;
        $scope.siteModal = function(siteId) {
            $scope.showsiteModal = !$scope.showsiteModal;
            var url = '/ops/engie/site/siteprofile';
            $http.post(url, {
                "siteid": siteId
            }).
            then(function(response) {
                vm.siteprofile = response.data;
                vm.type = vm.siteprofile.type;
                vm.serviceStartDate = vm.siteprofile.serviceStartDate;
                vm.siteAddress = vm.siteprofile.siteAddress;
                vm.siteID = vm.siteprofile.siteID;
                //console.log(" multiSite vm.serviceStartDate= "+vm.serviceStartDate);
            });


        };
        
        /*  end of site profile   */

        vm.listOfData=[
        	{
        		"location1":"sdstest",
        		"totalEventCount1": "15",
        		"timeOfLastEvent1": "01:38 PM 23/06/2017 ",
             },
             {
         		"location1":"usttest",
         		"totalEventCount1": "10",
         		"timeOfLastEvent1": "01:38 PM 23/06/2017 ",
              }
        ];
        /*  change password  */
        
        /*
         * Function Name: changePassword(passwordDtls)
         * Description : To change the password for user in AWS cognito. 
         * This is when the Change Password is selected from Menu.
         * 			  
         */
        vm.changePassword = function(passwordDtls) {
        	$scope.submitted = true;
        	if(vm.pwdForm.$valid) {
        	vm.isLoading = true; 
	       	$scope.submitted = false;
	       	vm.prevPwd = passwordDtls.prevpwd;
	       	vm.newPwd = passwordDtls.newpwd;
	       	vm.confirmPwd = passwordDtls.confirmpwd;
	       	
	       	AWSCognito.config.region = 'us-west-2';
	       	vm.userPool = new AmazonCognitoIdentity.CognitoUserPool(vm.cognito.poolData);
    		vm.userData = {
    			Username : $sessionStorage.userId,
    			Pool : vm.userPool
    	    };
    		
    		vm.cognito.cognitoUser = $sessionStorage.cognitoUser;
    		vm.attributes = $sessionStorage.attributes;
    		vm.accessToken = $sessionStorage.accessToken;
    		
    		vm.cognito.cognitoUser = {};
    		
    		try {
    			vm.cognito.cognitoUser = new AWSCognito.CognitoIdentityServiceProvider.CognitoUser(vm.userData);
    		} catch(err){
    			vm.isLoading = false;
    			vm.message = err;
    		}
    			
    		if((vm.newPwd) === (vm.confirmPwd)) {
    			/*$scope.submitted = false;*/
    			var params = {
				    "PreviousPassword":vm.prevPwd, /* required */
				    "ProposedPassword":vm.newPwd, /* required */
				    "AccessToken":vm.accessToken
				};
    			
    			new AWSCognito.CognitoIdentityServiceProvider().changePassword(params, function(err, result) {
    				
  	       	        if (err) {
  	       	        	vm.isLoading = false; 
  	       	        	vm.message= AppConst.ERRORMESSAGES.PWD_UNMATCH;
  	       	        	console.log(err);
  	       	            vm.passwordErrorMessage = AppConst.ERRORMESSAGES.PWD_UNMATCH;
  	       	            vm.pwdErrorMsg = true;
  	       	            $scope.$apply();
  	       	            /*console.log("prv password " +vm.prevPwd);*/
  	       	           
  	       	            return;
  	       	        } else {
  	       	        	
  	       	        	vm.isLoading = false; 
  	       	        	$scope.pwdSuccessMsg=true;
  	       	        	$scope.$apply();
  	       	        	vm.passwordSuccessMessage= AppConst.SUCCESSMESSAGES.PASSWORD_SUCCESS;
  	       	            
  	       	        }
  	       	    });
    			
	       	 } else {
	       		 vm.isLoading = false;
	       		 $timeout(function(){
		            vm.message = AppConst.ERRORMESSAGES.PWD_UNMATCH;
				    }, 1000);
	       	 }
	       	 vm.showModalCP = false;
	    }
        }
        /*var defaultForm={
 		 prevpwd : "";
 		newpwd : "";
	       	confirmpwd : "";
     }*/
        vm.showModalCP = false;
        vm.changePasswordModal = function() {
        	document.getElementById("pwdForm").reset();
        	vm.pwdDtl = {};
        	vm.isLoading = false;
            $scope.showModalCP = !$scope.showModalCP;
            $(".changePasswordModal").modal("show");
            $scope.submitted = false;
            vm.pwdErrorMsg = false;
            vm.pwdForm.$setPristine();
          // clear the form
            
            /*vm.pwdDtl.prevpwd ="";
            vm.pwdDtl.newpwd = "";
	       	vm.pwdDtl.confirmpwd = "";*/
            
        };

        /*  change password  */        
        
        
        /* Function to load cylinder chart*/

        function generateCylinderChart(divId, data) {

            var fillColor;
            if (data[0].value1 >= "50") {
                fillColor = AppConst.CONST_VAR_VAL.RED;
            } else if ((data[0].value1 < "50") && (data[0].value1 >= "30")) {
                fillColor = AppConst.CONST_VAR_VAL.GREEN;
            } else {
                fillColor = AppConst.CONST_VAR_VAL.YELLOW;
            }
            if (data[0].value1 === null) {
                data[0].value1 = "0";
            }
            /*Creating value for data[0].value2 for correcting the format*/
            data[0].value2 = (100 - data[0].value1).toString();



            $timeout(function() {
                var chart1 = AmCharts.makeChart(divId, {
                    "theme": "light",
                    "type": "serial",
                    "depth3D": 100,
                    "angle": 0,
                    "autoMargins": false,
                    "marginTop": 0,
                    "marginBottom": 0,
                    "marginLeft": 0,
                    "marginRight": 0,
                    "pullOutRadius": 0,
                    "dataProvider": data,
                    "valueAxes": [{
                        "stackType": "100%",
                        "gridAlpha": 0,
                        "labelsEnabled": false
                    }],
                    "graphs": [{
                        "type": "column",
                        "topRadius": 1,
                        "columnWidth": 1,
                        "showOnAxis": false,
                        "lineThickness": 2,
                        "lineAlpha": 0.5,
                        "lineColor": "#FFFFFF",
                        "fillColors": fillColor,
                        "fillAlphas": 0.8,
                        "valueField": "value1"
                    }, {
                        "type": "column",
                        "topRadius": 1,
                        "columnWidth": 1,
                        "showOnAxis": false,
                        "lineThickness": 2,
                        "lineAlpha": 0.5,
                        "lineColor": "#cdcdcd",
                        "fillColors": "#cdcdcd",
                        "fillAlphas": 0.5,
                        "valueField": "value2"
                    }],

                    "categoryField": "category",
                    "listeners": [{
                        "event": "rendered",
                        "method": handleRender
                    }],
                    "categoryAxis": {
                        "axisAlpha": 0,
                        "labelOffset": 0,
                        "gridAlpha": 0
                    },
                    "export": {
                        "enabled": false
                    }
                });
            }, 1000);


        };

        function handleRender(event) {
            $(".chartdiv1 a").remove();
            $(".chartdiv2 a").remove();
            $(".chartdiv3 a").remove();
        };

        /*
         * Function which loads pulse of data centre events in a pie chart
         */
        vm.loadPulseOfDataCentreEvents = function(divId) {
            var seriesData = [];
            var url = '/engie/msd/pulsedcevents'
            $http.get(url)
                .then(function(res) {

                    vm.pulseOfDataCntrEvnts = res.data;
                    vm.noOfSitesWithAlarms = vm.pulseOfDataCntrEvnts.noOfSiteWithAlarms;
                    vm.totActiveAlarmCnt = vm.pulseOfDataCntrEvnts.totActiveAlarmCnt;
                    vm.data = vm.pulseOfDataCntrEvnts.pulseDataDtsList;

                    angular.forEach(vm.data, function(key, value) {
                        key.y = parseInt(key.perDist);
                    });

                    Highcharts.setOptions({
                        colors: ['#87CEFA','#00BFFF','#6495ED','#483D8B','#8A2BE2','#1E90FF','#B0E0E6','#6A5ACD','#6495ED','#5F9EA0','#87CEEB']
                    });
                    var chart = new Highcharts.Chart({
                        chart: {
                            renderTo: divId,
                            plotBackgroundColor: null,
                            plotBorderWidth: null,
                            plotShadow: false,
                            margin: [0, 0, 0, 0],
                            spacingTop: 0,
                            spacingBottom: 0,
                            spacingLeft: 0,
                            spacingRight: 0,
                            height: 214,
                            type: 'pie'
                        },
                        title: {
                            text: ''
                        },
                        tooltip: {
                            pointFormat: '{point.siteName}: <b>{point.percentage:.1f}%</b>'
                        },
                        plotOptions: {
                            pie: {
                                allowPointSelect: true,
                                cursor: 'pointer',
                                size: 180,
                                dataLabels: {
                                    enabled: true,
                                    format: '{point.siteName}<br/> {point.percentage:.1f} %',
                                    distance: -30,
                                    style: {
                                        fontWeight: 'bold',
                                        color: 'white'
                                    }
                                },
                                showInLegend: false,
                            }
                        },
                        series: [{
                            colorByPoint: true,
                            data: vm.data
                        }],
                        exporting: {
                            enabled: false
                        }

                    });

                });

        };

        /*
         * Function to load data centre up time in a meter gauge
         */
        function loadDataCentreUpTime(divId, data) {
            $timeout(function() {
                var chart = AmCharts.makeChart(divId, {
                    "theme": "light",
                    "type": "gauge",
                    "axes": [{
                        "topTextFontSize": 13,
                        "topTextColor": '#057FFF',
                        "topTextYOffset": 50,
                        "topText": parseFloat(data.dataCenterUPTIME).toFixed(2)+'kW',
                        "axisColor": "#31d6ea",
                        "axisThickness": .05,
                        "endValue": 100,
                        "gridInside": true,
                        "inside": false,
                        "radius": "90%",
                        "valueInterval": 25,
                        "tickColor": "#67b7dc",
                        "startAngle": -90,
                        "endAngle": 90,
                        "bandOutlineAlpha": 0,
                        "fontSize":8,
                        "bands": [{
                            "color": "#E74C3C",
                            "endValue": 25,
                            "innerRadius": "125%",
                            "radius": "200%",
                            "gradientRatio": [0.5, 0, -0.5],
                            "startValue": 0
                        }, {
                            "color": "#F4D03F",
                            "endValue": 50,
                            "innerRadius": "125%",
                            "radius": "200%",
                            "gradientRatio": [0.5, 0, -0.5],
                            "startValue": 25
                        }, {
                            "color": "#7DCEA0",
                            "endValue": 75,
                            "innerRadius": "125%",
                            "radius": "200%",
                            "gradientRatio": [0.5, 0, -0.5],
                            "startValue": 50
                        }, {
                            "color": "#196F3D",
                            "endValue": 100,
                            "innerRadius": "125%",
                            "radius": "200%",
                            "gradientRatio": [0.5, 0, -0.5],
                            "startValue": 75
                        }]
                    }],
                    "arrows": [{
                        "alpha": 1,
                        "innerRadius": "35%",
                        "nailRadius": 1,
                        "nailBorderThickness":1,
                        "radius": "144%",
                        "value": data.dataCenterUPTIME
                    }],
                    "listeners": [{
                        "event": "rendered",
                        "method": handleUptimeRender
                    }],
                });
            }, 1000);

        };
        
        function handleUptimeRender(event) {
            $(".upTimeDiv a").remove();          
        };


        vm.userPriviledges = function() {
            //var urlPriviledgeUrl = 'assets/jsondata/roleList.json';
            var urlPriviledgeUrl = 'admin/engie/service/admin?userId=' + $sessionStorage.userId + '&siteId=&actionType=user_auth';
            AppService.getData(1, urlPriviledgeUrl).then(function(response) {
                if (response.status === 200 && response.data) {
                    $rootScope.privilegeList = response.data.roleList;
                }
            });
        };
        	
        
        vm.logoutUser = function(){
        	 var _postData =	{
						"userId":$sessionStorage.userId,
						"uniqId":$cookies.get('UserCookie'),
						"actionType":"user_logout"
						}; 
			 var logoutUserUrl = "/jurisdiction/engie/user/logout";
        	_postData = JSON.parse(angular.toJson(_postData));
			console.log("_postData",_postData);
			AppService.postData(_postData,logoutUserUrl).then(function(response) {
					if (response.status === 200 && response.data) {
						$cookies.remove('UserCookie');
						delete $sessionStorage.userId;
						delete $sessionStorage.idToken;
						delete $sessionStorage.accessToken;
						delete $sessionStorage.cognitoUser;
						delete $sessionStorage.attributes;
						$templateCache.removeAll();
						$location.path("/");
                		$window.location.reload();
                	 }
   			});
        	
        	
        	
        };
        
        vm.redirectMultisiteDashboard = function() {
            $location.path("ops/"+AppConst.CONST_VAR.HOME);
        };
        
        vm.refreshPage = function() {
			$route.reload();
		};
		
		vm.onSiteSelect = function(label){
        	vm.siteNavId = label;
        
        	$localStorage.siteNavId = vm.siteNavId;
        	if($localStorage.routeName === "/" + "ops/"+AppConst.CONST_VAR.EXECUTIVEOVERVIEW){
        		$location.path(AppConst.CONST_VAR.EXECUTIVEOVERVIEWCTR + "/" + $localStorage.siteNavId);            		
        	}else if($localStorage.routeName === "/" + "ops/"+AppConst.CONST_VAR.OPERATIONOVERVIEW){
        		$location.path(AppConst.CONST_VAR.OPERATIONOVERVIEWCTR + "/" + $localStorage.siteNavId);
        	}else if($localStorage.routeName === "/" + "ops/"+AppConst.CONST_VAR.FLAYOUT){
        		$location.path(AppConst.CONST_VAR.FLAYOUTCTR + "/" + $localStorage.siteNavId);
        	}else if($localStorage.routeName === "/" + "ops/"+AppConst.CONST_VAR.EDIAGRAM){
        		$location.path(AppConst.CONST_VAR.EDIAGRAMCTR + "/" + $localStorage.siteNavId);
        	}else if($localStorage.routeName === "/" + "ops/"+AppConst.CONST_VAR.SINGLELINEDIAGRAM){ 
        		$location.path(AppConst.CONST_VAR.SINGLELINEDIAGRAMCTR + "/" + $localStorage.siteNavId);
        	}else if($localStorage.routeName === "/" + "ops/"+AppConst.CONST_VAR.POWERDISTRIBUTIONUNIT){
        		$location.path(AppConst.CONST_VAR.POWERDISTRIBUTIONUNITCTR + "/" + $localStorage.siteNavId);            		
        	}else if($localStorage.routeName === "/" + "ops/"+AppConst.CONST_VAR.ANCILLARY){
        		$location.path(AppConst.CONST_VAR.ANCILLARYCTR + "/" + $localStorage.siteNavId);            		
        	}else if($localStorage.routeName === "/" + "ops/"+AppConst.CONST_VAR.ACTEVENTS){
        		$location.path(AppConst.CONST_VAR.ACTEVENTSCTR + "/" + $localStorage.siteNavId);            		
        	}else if($localStorage.routeName === "/" + "ops/"+AppConst.CONST_VAR.INACTEVENTS){
        		$location.path(AppConst.CONST_VAR.INACTEVENTSCTR + "/" + $localStorage.siteNavId);            		
        	}else if($localStorage.routeName === "/" + "ops/"+AppConst.CONST_VAR.EVENTANALYTICS1){
        		$location.path(AppConst.CONST_VAR.EVENTANALYTICS1CTR + "/" + $localStorage.siteNavId);            		
        	}else if($localStorage.routeName === "/" + "ops/"+AppConst.CONST_VAR.EVENTANALYTICS2){
        		$location.path(AppConst.CONST_VAR.EVENTANALYTICS2CTR + "/" + $localStorage.siteNavId);            		
        	}else if($localStorage.routeName === "/" + "ops/"+AppConst.CONST_VAR.KPIAVAILABILITY){
        		$location.path(AppConst.CONST_VAR.KPIAVAILABILITYCTR + "/" + $localStorage.siteNavId);            		
        	}else if($localStorage.routeName === "/" + "ops/"+AppConst.CONST_VAR.KPIENERGYEFFICIENCY){
        		$location.path(AppConst.CONST_VAR.KPIENERGYEFFICIENCYCTR + "/" + $localStorage.siteNavId);            		
        	}else if($localStorage.routeName === "/" + "ops/"+AppConst.CONST_VAR.KPIPOWER){
        		$location.path(AppConst.CONST_VAR.KPIPOWERCTR + "/" + $localStorage.siteNavId);            		
        	}else if($localStorage.routeName === "/" + "ops/"+AppConst.CONST_VAR.KPIMECHANICAL){
        		$location.path(AppConst.CONST_VAR.KPIMECHANICALCTR + "/" + $localStorage.siteNavId);            		
        	}else if($localStorage.routeName === "/" + "ops/"+AppConst.CONST_VAR.KPIAIRFLOW){
        		$location.path(AppConst.CONST_VAR.KPIAIRFLOWCTR + "/" + $localStorage.siteNavId);            		
        	}else if($localStorage.routeName === "/" + "assetperformance/"+AppConst.CONST_VAR.UPSASSETPERFLANDING){
        		$location.path(AppConst.CONST_VAR.UPSASSETPERFLANDINGCTR + "/" + $localStorage.siteNavId);            		
        	}else if($localStorage.routeName === "/" + "assetperformance/"+AppConst.CONST_VAR.UPSASSETINFO){
        		$location.path(AppConst.CONST_VAR.UPSASSETINFOCTR + "/" + $localStorage.siteNavId);            		
        	}
         };
         
         
         /*-------------------------for active links starts here-----------------------------------------------------*/
         
         
         
         
         if($location.path()=="/"+AppConst.CONST_VAR.EXECUTIVEOVERVIEWCTR + "/" + $localStorage.siteNavId 
       		  || $location.path()=="/"+AppConst.CONST_VAR.OPERATIONOVERVIEWCTR + "/" + $localStorage.siteNavId
       		  || $location.path()=="/ops/"+AppConst.CONST_VAR.FLAYOUTCTR + "/" + $localStorage.siteNavId
       		  || $location.path()=="/ops/"+AppConst.CONST_VAR.EDIAGRAMCTR + "/" + $localStorage.siteNavId
       		  || $location.path()=="/ops/"+AppConst.CONST_VAR.SINGLELINEDIAGRAMCTR + "/" + $localStorage.siteNavId
       		  || $location.path()=="/ops/"+AppConst.CONST_VAR.POWERDISTRIBUTIONUNITCTR + "/" + $localStorage.siteNavId
       		  || $location.path()=="/ops/"+AppConst.CONST_VAR.ANCILLARYCTR + "/" + $localStorage.siteNavId
       		  || $location.path()=="/ops/"+AppConst.CONST_VAR.ACTEVENTSCTR + "/" + $localStorage.siteNavId
       		  || $location.path()=="/ops/"+AppConst.CONST_VAR.INACTEVENTSCTR + "/" + $localStorage.siteNavId
       		  || $location.path()=="/ops/"+AppConst.CONST_VAR.EVENTANALYTICS1CTR + "/" + $localStorage.siteNavId
       		  || $location.path()=="/ops/"+AppConst.CONST_VAR.EVENTANALYTICS2CTR + "/" + $localStorage.siteNavId
       		  || $location.path()=="/ops/"+AppConst.CONST_VAR.KPIAVAILABILITYCTR + "/" + $localStorage.siteNavId
       		  || $location.path()=="/ops/"+AppConst.CONST_VAR.KPIENERGYEFFICIENCYCTR + "/" + $localStorage.siteNavId
       		  || $location.path()=="/ops/"+AppConst.CONST_VAR.KPIPOWERCTR + "/" + $localStorage.siteNavId
       		  || $location.path()=="/ops/"+AppConst.CONST_VAR.KPIMECHANICALCTR + "/" + $localStorage.siteNavId
       		  || $location.path()=="/ops/"+AppConst.CONST_VAR.KPIAIRFLOWCTR + "/" + $localStorage.siteNavId) {
       	  
	       	  	vm.showMultisite = false;
	       	  	vm.showOpr = true;
	       	  	vm.showAsset=false;
	       	    vm.showServiceTracking=false;
	       	  	
	       	
         	
         }else if($location.path()==="/ops/home"){
       	  
	       	  	vm.showMultisite = true;
	       	  	vm.showOpr = false;
	       	  	vm.showAsset=false;
	       	    vm.showServiceTracking=false;
	       	  	
	       	  	
	       	  
         } 
        
         
         
         /*-------------------------for active links ends here-----------------------------------------------------*/
         
         
         
         
         
         vm.selectDefaultSiteId = function(siteNavId){
        	if(siteNavId === null || siteNavId === undefined){
         		vm.siteNavId = "sdslab";
         	}
        	 
         };

	    
         /*vm.dropDownSites = ['sdslab', 'sdslac', 'ustlab'];
       
         vm.dropboxitemselected = function (site) {
      
        	 vm.siteNavId = site;
    
          	$localStorage.siteNavId = vm.siteNavId;
          	if($localStorage.routeName === "/" + AppConst.CONST_VAR.EXECUTIVEOVERVIEW){
          		$location.path(AppConst.CONST_VAR.EXECUTIVEOVERVIEWCTR + "/" + $localStorage.siteNavId);            		
          	}else if($localStorage.routeName === "/" + AppConst.CONST_VAR.OPERATIONOVERVIEW){
          		$location.path(AppConst.CONST_VAR.OPERATIONOVERVIEWCTR + "/" + $localStorage.siteNavId);
          	}else if($localStorage.routeName === "/" + AppConst.CONST_VAR.FLAYOUT){
          		$location.path(AppConst.CONST_VAR.FLAYOUTCTR + "/" + $localStorage.siteNavId);
          	}else if($localStorage.routeName === "/" + AppConst.CONST_VAR.EDIAGRAM){
          		$location.path(AppConst.CONST_VAR.EDIAGRAMCTR + "/" + $localStorage.siteNavId);
          	}else if($localStorage.routeName === "/" + AppConst.CONST_VAR.SINGLELINEDIAGRAM){ 
          		$location.path(AppConst.CONST_VAR.SINGLELINEDIAGRAMCTR + "/" + $localStorage.siteNavId);
          	}else if($localStorage.routeName === "/" + AppConst.CONST_VAR.POWERDISTRIBUTIONUNIT){
          		$location.path(AppConst.CONST_VAR.POWERDISTRIBUTIONUNITCTR + "/" + $localStorage.siteNavId);            		
          	}else if($localStorage.routeName === "/" + AppConst.CONST_VAR.ANCILLARY){
          		$location.path(AppConst.CONST_VAR.ANCILLARYCTR + "/" + $localStorage.siteNavId);            		
          	}else if($localStorage.routeName === "/" + AppConst.CONST_VAR.ACTEVENTS){
          		$location.path(AppConst.CONST_VAR.ACTEVENTSCTR + "/" + $localStorage.siteNavId);            		
          	}else if($localStorage.routeName === "/" + AppConst.CONST_VAR.INACTEVENTS){
          		$location.path(AppConst.CONST_VAR.INACTEVENTSCTR + "/" + $localStorage.siteNavId);            		
          	}else if($localStorage.routeName === "/" + AppConst.CONST_VAR.EVENTANALYTICS1){
          		$location.path(AppConst.CONST_VAR.EVENTANALYTICS1CTR + "/" + $localStorage.siteNavId);            		
          	}else if($localStorage.routeName === "/" + AppConst.CONST_VAR.EVENTANALYTICS2){
          		$location.path(AppConst.CONST_VAR.EVENTANALYTICS2CTR + "/" + $localStorage.siteNavId);            		
          	}else if($localStorage.routeName === "/" + AppConst.CONST_VAR.KPIAVAILABILITY){
          		$location.path(AppConst.CONST_VAR.KPIAVAILABILITYCTR + "/" + $localStorage.siteNavId);            		
          	}else if($localStorage.routeName === "/" + AppConst.CONST_VAR.KPIENERGYEFFICIENCY){
          		$location.path(AppConst.CONST_VAR.KPIENERGYEFFICIENCYCTR + "/" + $localStorage.siteNavId);            		
          	}else if($localStorage.routeName === "/" + AppConst.CONST_VAR.KPIPOWER){
          		$location.path(AppConst.CONST_VAR.KPIPOWERCTR + "/" + $localStorage.siteNavId);            		
          	}else if($localStorage.routeName === "/" + AppConst.CONST_VAR.KPIMECHANICAL){
          		$location.path(AppConst.CONST_VAR.KPIMECHANICALCTR + "/" + $localStorage.siteNavId);            		
          	}else if($localStorage.routeName === "/" + AppConst.CONST_VAR.KPIAIRFLOW){
          		$location.path(AppConst.CONST_VAR.KPIAIRFLOWCTR + "/" + $localStorage.siteNavId);            		
          	}
         }*/
         
         
         /*----------------------------file upload function starts here----------------------------------------------*/
         $scope.creds = {
         		  bucket: 'avrilimageupload',
         		  access_key: 'AKIAI5DH7LGOLEYUV5ZQ',
         		  secret_key: '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'
         		}
         
         vm.uploadFile = function(){
         	
         	$scope.invalidImage = false;
         	$scope.noImageselected=false;
             var file = vm.userImage;
             console.log('file is : ' );
             console.dir(file);
            
             AWS.config.update({ accessKeyId: $scope.creds.access_key, secretAccessKey: $scope.creds.secret_key });
             AWS.config.region = 'ap-southeast-1';
             var bucket = new AWS.S3({ params: { Bucket: $scope.creds.bucket } });
             
             if(vm.userImage) {
             	if(vm.userImage.type == "image/jpeg" || vm.userImage.type == "image/png"){
             		
             		$scope.invalidImage = false;
             		// Prepend Unique String To Prevent Overwrites
                     var uniqueFileName = $scope.uniqueString() + '-' + vm.userImage.name;
                     
                     var params = { Key: uniqueFileName, ContentType: vm.userImage.type, Body: vm.userImage, ServerSideEncryption: 'AES256' };
                     
                     bucket.putObject(params, function(err, data) {
                         if(err) {
                           //alert(err.message,err.code); 
                           console.log(err.message);
                           return false;
                         }
                         else {
                         	 $scope.noImageselected=false;
                         	vm.s3_path = 'https://s3-ap-southeast-1.amazonaws.com/'+$scope.creds.bucket + '/' + uniqueFileName; // path of file in S3
                         	console.log(uniqueFileName);
                         	console.log("file path in s3 is : "+vm.s3_path);
                           // Upload Successfully Finished
                           alert("File Uploaded Successfully");
                           vm.editImage = true;

                           // Reset The Progress Bar
                           setTimeout(function() {
                             $scope.uploadProgress = 0;
                             $scope.$digest();
                           }, 4000);
                         }
                       })
                       .on('httpUploadProgress',function(progress) {
                           $scope.uploadProgress = Math.round(progress.loaded / progress.total * 100);
                           $scope.$digest();
                         });
             	}
             	
             	else {
             		$scope.invalidImage = true;
             		alert("invalid file type");
             	}
             	 
             }
             
             else {
                
                 alert('Please select a file to upload');
                 $scope.noImageselected=true;
               }
             
             
         };
         
         
         $scope.uniqueString = function() {
             var text     = "";
             var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";

             for( var i=0; i < 8; i++ ) {
               text += possible.charAt(Math.floor(Math.random() * possible.length));
             }
             return text;
           }
         
         angular.element("input[type='file']").val(null);
         
         
         
    /*------------------------------file upload function ends here------------------------------------------------ */
         
         
        vm.onClose = function (className) {
        	//$scope.showModal = false;
        	$('body').on('hidden.bs.modal', '.modal', function() { /*clear modal cache, so that new content can be loaded*/
                $(".userProfileModal").removeData('modal');
         });
         	$("."+className).modal("hide");
        };
         
            
         

        vm.init();


    }
}())