/* 
 *  ================================================================================
 *  Copyright (C) 2017
 */
(function() {
    'use strict';
    AppModule.controller("executiveOverviewController", ["$scope","$sessionStorage", "$localStorage", "$rootScope", "AppConst", 'AppService', 'AppSettings', '$http','CommonService', "$location","$routeParams", "$interval","$route",executiveOverviewController]);

	    function executiveOverviewController($scope, $sessionStorage, $localStorage, $rootScope, AppConst, AppService, AppSettings, $http, CommonService, $location, $routeParams, $interval, $route) {
			var vm=this;
			vm.executiveOverview = "Executive Overview";
			vm.siteid = $routeParams.siteid;
			//vm.serviceStartDate = $routeParams.serviceStartDate;
			
			vm.temperature = "Temperature";
	        vm.humidity = "Humidity";
	               
	        $rootScope.$on('$routeChangeSuccess', function(e, curr, prev) {
	        	vm.siteNavId = $routeParams.siteid;
		        $localStorage.siteNavId = vm.siteNavId;
		       
	        });
			vm.init = function(){
				
				//var summaryAsseturl = "assets/jsondata/summaryAssetHealth.json";
				var cylinderUrl = "assets/jsondata/totalDataCenterUtlization.json";
				
				
				var siteidUrl = "/ops/engie/service/msd/msddynamictable?userId=anilkumar@engie.com&siteId="+vm.siteid;
				var activeEventsUrl = "/ops/engie/pastweek/pastweekevents";
				var activeEventsTrackerUrl = '/ops/engie/service/operation/overview?siteId='+vm.siteid+'&userId='+$sessionStorage.userId;
				
		           AppService.getData(1, activeEventsTrackerUrl).then(function(response) {
		        	   if (response.status === 200 && response.data) {
		        		   vm.isLoading = false;
		        		   vm.activeEventsTrackerData = response.data;
		        		  
		        		   vm.aveTimeEventRate =vm.activeEventsTrackerData['Average'][0]['AvgRatePerDate'];	        		   
		        		   vm.aveTimeAck = vm.activeEventsTrackerData['Average'][0]['AckDuration'];
		        		   vm.aveTimeNormalize = vm.activeEventsTrackerData['Average'][0]['NRDuration'];
		        		   var aveAckTime = (parseInt(vm.aveTimeAck))/60;
		        		   var aveNormalizeTime = (parseInt(vm.aveTimeNormalize))/60;
		        		   /*vm.aveTimeEventRate*/
		        		   CommonService.DataCenterEvents('aveEvent',50 );
		        		   CommonService.DataCenterEvents('aveAck', 70);
		        		   CommonService.DataCenterEvents('aveNormalize', 50);	
		        		  /* console.log("aveTimeAck : "+aveAckTime);
		        		   console.log("aveTimeNormalize : "+aveNormalizeTime);*/
		        		   
		        		   /*var coolVar = '123 abc itchy knee';
		        		   var partsArray = coolVar.split(' ');*/
		        		   
		                }
		           });		
				
				
				
				
				
				
				AppService.getData(1, siteidUrl).then(function(response) {
					vm.siteData = response.data;
					vm.dataDatacenterUptime = response.data[0].dcUptimeDto;
					var divUpTime = "upTime";
					CommonService.generateDataCentreUpTime(divUpTime, vm.dataDatacenterUptime);
					
					
					CommonService.DataCenterAvailability('DataCenterAvailability', 50);
					
					vm.dataSiteAlarmDistribution = response.data[0].totalActiveAlarms;
					vm.dataAverageTempHumidity = response.data[0].avgRoomTemperatureHumidity;					
					vm.dataAverageTempHumidity.humidity = parseFloat(vm.dataAverageTempHumidity.humidity).toFixed(2); 
					vm.dataAverageTempHumidity.temperature = parseFloat(vm.dataAverageTempHumidity.temperature).toFixed(2); 
					vm.totalDataCenterUtlization = response.data[0].totalDataCenterUtlization;
	               	vm.divItload = "chartdiv"+ vm.totalDataCenterUtlization.itLoad.category;
	               	vm.divPower = "chartdiv"+ vm.totalDataCenterUtlization.power.category;
	               	vm.divCooling = "chartdiv"+ vm.totalDataCenterUtlization.cooling.category;
	               	
	               	CommonService.DataCenterUtilization(vm.divItload, vm.totalDataCenterUtlization.itLoad.value1);
	               	CommonService.DataCenterUtilization(vm.divPower, vm.totalDataCenterUtlization.power.value1);
	               	CommonService.DataCenterUtilization(vm.divCooling, vm.totalDataCenterUtlization.cooling.value1);
	               	
	               	
	               	
	               
	               	
	               	/*------------------------------for total active alarm count----------------------------------*/
	               	vm.totalActiveEventsCount = 0;
	               	
	               	for(var i=0;i< vm.dataSiteAlarmDistribution.length;i++) {
	               		vm.totalActiveEventsCount +=  vm.dataSiteAlarmDistribution[i].y;
	               	}

				 	vm.powerUsageEffectiveness = response.data[0].powerUsageEffectiveness;
					vm.powerUsageValue = parseFloat(vm.powerUsageEffectiveness.powerUsageEffectiveness).toFixed(2);
					var divPowerUsage = "powerUsage";
					CommonService.generatePowerUsage(divPowerUsage, vm.powerUsageEffectiveness.powerUsageEffectiveness);
					
					
					
					if(response.data[0].carbonemission===null){
						response.data[0].carbonemission = 0;
					}
					if(response.data[0].averageEngeryCost===null){
						response.data[0].averageEngeryCost = 0;
					}
					vm.carbonValue = parseFloat(response.data[0].carbonemission).toFixed(2);
					vm.avgCostValue = parseFloat(response.data[0].averageEngeryCost).toFixed(2);
					
					vm.dataSummaryHealth = response.data[0].summaryAssetHealth;
					
					

		        });
				
				var _siteidObj =	{"siteid":vm.siteid};
				_siteidObj = JSON.parse(angular.toJson(_siteidObj));
	
	
				AppService.postData(_siteidObj,activeEventsUrl).then(function(response) {
			        if (response.status === 200 && response.data) {
			        	vm.activeEvents = response.data[0];
			        	vm.timeseries = response.data[0].timeseries;			        	
			        	for(var i=0;i< vm.timeseries.length;i++) {			        		
			        		var timeSeriesDate = new Date(vm.timeseries[i]);
			        		vm.timeseries[i] = getFormattedDate(timeSeriesDate);							
		               	}			        	
			        	vm.eventSeverity = response.data[0].eventSeverity;
			        	vm.eventSeverity[0].color = "#E74C3C";
			        	vm.eventSeverity[0].name = "Active Critical Faults";
			        	vm.eventSeverity[1].color = "orange";
			        	vm.eventSeverity[1].name = "Warning Critical Faults";
			        	vm.eventSeverity[2].color = "grey";
			        	vm.eventSeverity[2].name = "Minor Critical Faults";
			         }
			    });

				//Top5 equipments with CRs
				var exOvDynatbUrl = "/ops/engie/service/exov/exovdynamictable?userId=anilkumar@engie.com&siteId="+vm.siteid+"&serviceType=TOP5EQUIPWITHCR";
				
				AppService.getData(1, exOvDynatbUrl).then(function(response) {
					
					//angular.forEach(response.data, function(value, key) {
					//});
					vm.top5EquipmentsWithCr=response.data;
					
					
				});
				
				//TOTAL SITE ENERGY CONSUMPTION
				var exOvDynatbTotSitEngConsUrl = "/ops/engie/service/exov/exovdynamictable?userId=anilkumar@engie.com&siteId="+vm.siteid+"&serviceType=TOTALSITE_ENERGYCONSUMPTION";
				
				AppService.getData(1, exOvDynatbTotSitEngConsUrl).then(function(response) {
					
					vm.totalSiteEnergyConsumption=response.data;
					var facilityLoad = parseFloat(vm.totalSiteEnergyConsumption.TotalFacilityLoad);
		        	var itLoad = parseFloat(vm.totalSiteEnergyConsumption.TotalITLoad);
					vm.totalLoad = facilityLoad + itLoad;
					if(!vm.totalLoad) {
						vm.totalLoad = 0;
						facilityLoad = 0;
						itLoad = 0;
					}
					
					var tillDate=vm.totalSiteEnergyConsumption.tillDate;//Milli
					var serviceStartDate=AppService.siteServiceStartDate("GET",vm.siteid);
					console.log(" serviceStartDate="+serviceStartDate);
					var date = new Date(tillDate);//TODO utc to local time 
					vm.serviceEndDate = getFormattedDate(date);
					vm.serviceStartDate=serviceStartDate;
					CommonService.siteEnergyConsumption('siteEnergyConsumption',facilityLoad,itLoad);
				});
				
				
				
			};
			
			function getFormattedDate(date) {
				  var year = date.getFullYear();

				  var month = (1 + date.getMonth()).toString();
				  month = month.length > 1 ? month : '0' + month;

				  var day = date.getDate().toString();
				  day = day.length > 1 ? day : '0' + day;
				  
				  return day + '/' + month + '/' + year;
				}
			
	        vm.redirectOperationOverview = function() {

	            $location.path(AppConst.CONST_VAR.OPERATIONOVERVIEWCTR + "/" + vm.siteid);
	        };
	        
	        
	        
	       //Trigger initial l oading - every 10 secs interval start
	       /* var refreshPage = function() {
	              $route.reload();

	        };
	        var interval = $interval(refreshPage, AppConst.CONST_PAGEREFRESHTIME.ONE_MINUTE);
	        $scope.$on('$destroy', function() {
	              $interval.cancel(interval);
	        });*/
	        //end
	        
	        vm.takeScreenShot = function () {
				var fileName = "ExecutiveOverView.pdf";
				var finalArray=[];
				var Active=document.getElementById("DivActiveEvents");
				var dwidth1=$("#DivActiveEvents").outerWidth();
				var dheight1=$("#DivActiveEvents").outerHeight(); 
				var CenterAvalibility=document.getElementById("DivCenterAvalibility");
				var dwidth2=$("#DivCenterAvalibility").width();
				var dheight2=$("#DivCenterAvalibility").height();
				var totalEnergy=document.getElementById("totalEnergy");
				var dwidth3=$("#totalEnergy").width();
				var dheight3=$("#totalEnergy").height();
				var powerUs=document.getElementById("powerUs");
				var dwidth4=$("#powerUs").width();
				var dheight4=$("#powerUs").height();
				var top5Equipment=document.getElementById("top5Equipment");
				var dwidth5=$("#top5Equipment").width();
				var dheight5=$("#top5Equipment").height();
				var totalData=document.getElementById("totalData");
				var dwidth6=$("#totalData").width();
				var dheight6=$("#totalData").height();
				var trendActive=document.getElementById("trendActive");
				var dwidth7=$("#trendActive").width();
				var dheight7=$("#trendActive").height();
				var estimateCostEnergy=document.getElementById("estimateCostEnergy");
				var dwidth8=$("#estimateCostEnergy").width();
				var dheight8=$("#estimateCostEnergy").height();
				var totalCarbon=document.getElementById("totalCarbon");
				var dwidth9=$("#totalCarbon").width();
				var dheight9=$("#totalCarbon").height();
				 var options = {
					quality: 1.0 
				};
				domtoimage.toJpeg(Active,{height:dheight1,width:dwidth1}).then(function(dataUrl1) {
					console.log(dataUrl1);
					finalArray.push(dataUrl1);
					domtoimage.toJpeg(CenterAvalibility).then(function(dataUrl2) {
					  finalArray.push(dataUrl2);
						  domtoimage.toPng(totalEnergy).then(function(dataUrl3) {
						  finalArray.push(dataUrl3);
							  domtoimage.toPng(powerUs).then(function(dataUrl4) {
							  finalArray.push(dataUrl4);
							  domtoimage.toPng(top5Equipment).then(function(dataUrl5) {
								  finalArray.push(dataUrl5);
								  domtoimage.toPng(totalData).then(function(dataUrl6) {
									  finalArray.push(dataUrl6);
									  domtoimage.toPng(trendActive).then(function(dataUrl7) {
										  finalArray.push(dataUrl7);
										  domtoimage.toPng(estimateCostEnergy).then(function(dataUrl8) {
											  finalArray.push(dataUrl8);
												domtoimage.toPng(totalCarbon).then(function(dataUrl9) {
												  finalArray.push(dataUrl9);
												  var _postPdfData =	{
														"images":[
															{  
																"data":finalArray[0],
																"width":dwidth1,
																"height": dheight1      							 
															   },  
																{  
																"data":finalArray[1],
																"width":dwidth2,
																"height":dheight2      							 
															   },
																{  
																"data":finalArray[2],
																"width":dwidth3,
																"height": dheight3      							 
															   },  
																{  
																"data":finalArray[3],
																"width":dwidth4,
																"height":dheight4    							 
															   },  
																{  
																"data":finalArray[4],
																"width":dwidth5,
																"height":dheight5    							 
															   },  
																{  
																"data":finalArray[5],
																"width":dwidth6,
																"height":dheight6    							 
															   },  
																{  
																"data":finalArray[6],
																"width":dwidth7,
																"height":dheight7    							 
															   },  
																{  
																"data":finalArray[7],
																"width":dwidth8,
																"height":dheight8   							 
															   },  
																{  
																"data":finalArray[8],
																"width":dwidth9,
																"height":dheight9  							 
															   }						   
														 ]		
													};
													_postPdfData = JSON.parse(angular.toJson(_postPdfData));
													console.log(_postPdfData);
													var pdfUrl = "/ops/engie/printpdf ";
													$http.post(pdfUrl,_postPdfData,{responseType:'arraybuffer'}).then(function onSuccess(response) {
														if (response.data) {    						
															var file = new Blob([response.data], {type: 'application/pdf'});
															var fileURL = window.URL.createObjectURL(file);
															if(response && response.data){
																var a = document.createElement("a");
																document.body.appendChild(a);
																a.href = fileURL;
																console.log(fileURL);
																a.download = fileName;
																a.click();
															}
														}

													});
												})
											})
										})
										
									})
								})
							})
						})
					})

					
						
					})
					
		
					
					
				}

			vm.init();
	    }	
	
}())
