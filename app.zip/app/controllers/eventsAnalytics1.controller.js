/* 
 * 
 *  ================================================================================
 *  Copyright (C) 2017
 */ 

(function() {
	'use strict';
	
	AppModule.controller("eventsAnalytics1",["$scope","AppConst","AppService","ChartService","$route","$interval","$http",eventsAnalytics1]);

	function eventsAnalytics1($scope,AppConst,AppService,ChartService,$route,$interval,$http) {
		var vm=this;
				
		vm.init = function(){
			
        var eventsAnalyticsUrl = "/ops/eventAnalytics/getDCAssetAvailabilty";
        var getEventsTrendByCategoryUrl="/ops/eventAnalytics/getEventsTrendByCategory";
	    var getEventsTrendByMonthUrl="/ops/eventAnalytics/getEventsTrendByMonth";
	    var getRateOfEventsOccur="/ops/eventAnalytics/getRateOfEventsOccur";
	    var getRateOfEventsAck="/ops/eventAnalytics/getRateOfEventsAck";
	    
	    
	    var _postData =	{
				"siteid":"sdslab",
				"serviceType":"activeEvents"
			};

	               
//	               ChartService.rateOfAck("ratePerHourAck",50);
	               
	               _postData =	{
		   					"site":"sdslab",
		   					"serviceType":"getRateOfEventsOccur"
		   				};
		   	
		   			    AppService.postData(_postData,getRateOfEventsOccur).then(function(response) {
		                   if (response.status === 200 && response.data) {
		                	   ChartService.eventRate("ratePer60Day",response.data.jsonObjectListPer60Days,response.data.jsonObjectListPer60DaysSum);
		                	   ChartService.eventRate("ratePerWeek",response.data.jsonObjectListPerWeek,response.data.jsonObjectListPerWeekSum);
		                	   ChartService.eventRate("ratePerDay",response.data.jsonObjectListPerDay,response.data.jsonObjectListPerDaySum);
		                	   ChartService.eventRate("ratePerHour",response.data.jsonObjectListPerHour,response.data.jsonObjectListPerHourSum);
		                   }
		   			    })
		   			    
		   			    
		   			      _postData =	{
		   					"site":"sdslab",
		   					"serviceType":"getRateOfEventsAck"
		   				};
		   	
		   			    AppService.postData(_postData,getRateOfEventsAck).then(function(response) {
		                   if (response.status === 200 && response.data) {
		                	   ChartService.rateOfAck("ratePer60DayAck",response.data.jsonObjectListPer60DaysSum);
		                	   ChartService.rateOfAck("ratePerWeekAck",response.data.jsonObjectListPerWeekSum);
		                	   ChartService.rateOfAck("ratePerDayAck",response.data.jsonObjectListPerDaySum);
		                	   ChartService.rateOfAck("ratePerHourAck",response.data.jsonObjectListPerHourSum);
		                   }
		   			    })
	    
			var _postData =	{
					"site":"sdslab",
					"serviceType":"getDCAssetAvailabilty"
				};
			
		
		 var columnDefs = [
		                   {headerName: "", field: "assetID", width: 130,cellClass:"text-center"}, 
		                   {headerName: "Critical", field: "CR", width: 70,
		                	   cellRenderer: function (params) {     
		                           return renderProgessbarCR(params);
		                   }},
		                   {headerName: "Warning", field: "WR",width: 70, cellRenderer: function (params) {     
		                           return renderProgessbarWR(params);
		                   }},
		                   {headerName: "Minor", field: "MR",width: 70, cellRenderer: function (params) {     
		                           return renderProgessbarMR(params);
		                   }},
		                   {headerName: "Total", field: "Total",width: 70, cellRenderer: function (params) {     
		                           return renderProgessbarTotal(params);
		                   }}

		                  
		               ];
		 				
						 $scope.gridOptions1 = { columnDefs: columnDefs	};
						 $scope.gridOptions2 = { columnDefs: columnDefs	};

		               _postData = JSON.parse(angular.toJson(_postData));
		   			   AppService.postData(_postData,eventsAnalyticsUrl).then(function(response) {
		                   if (response.status === 200 && response.data) {
//		                			   onGridReady: function() {
		                				   $scope.gridOptions1.api.setRowData(response.data);
		                				   $scope.gridOptions2.api.setRowData(response.data);
		                   }
		   			   })

		              
		}
		
		
		
		
		
		
		//Trigger initial l oading - every 10 secs interval start
       /* var refreshPage = function() {
              $route.reload();

        };
        var interval = $interval(refreshPage, AppConst.CONST_PAGEREFRESHTIME.ONE_MINUTE);
        $scope.$on('$destroy', function() {
              $interval.cancel(interval);
        });*/
        //end   

		function renderProgessbarCR(params){
			var CRWidth=0;
			if(undefined==params.data.CR){
				params.data.CR=0;
			}
			else if(params.data.CR < 100){
				 CRWidth=params.data.CR;
			}
			else if(params.data.CR > 100){
				 CRWidth=params.data.CR/10 +20;
			}
			return "<div class='progress'>"+
			  "<div role='progressbar ' aria-valuenow='"+params.data.CR+"' aria-valuemin='0' aria-valuemax='100' style='min-width:.7em; width:"+CRWidth+"%'>"+params.data.CR+"</div></div>";
		
			//closing function renderProgessbar(params){
		}
		function renderProgessbarWR(params){
			var WRWidth=0;
			if(undefined==params.data.WR){
				params.data.WR=0;
			}
			else if(params.data.WR < 100){
				 WRWidth=params.data.WR;
			}
			else if(params.data.WR > 100){
				 WRWidth=params.data.WR/10;
			}
			return "<div class='progress'>"+
			  "<div role='progressbar' aria-valuenow='"+params.data.WR+"' aria-valuemin='0' aria-valuemax='100' style='min-width:.7em; width:"+WRWidth+"%'>"+params.data.WR+"</div></div>";
		}
		function renderProgessbarMR(params){
			var MRWidth=0;
			if(undefined==params.data.MR){
				params.data.MR=0;
			}
			else if(params.data.MR < 100){
				 MRWidth=params.data.MR;
			}
			else if(params.data.MR > 100){
				 MRWidth=params.data.MR/10+20;
			}
			return "<div class='progress'>"+
			  "<div role='progressbar' aria-valuenow='"+params.data.MR+"' aria-valuemin='0' aria-valuemax='100' style='min-width:.7em; width:"+MRWidth+"%'>"+params.data.MR+"</div></div>";
		}
		function renderProgessbarTotal(params){
			var TotalWidth=0;
			if(undefined==params.data.Total){
				params.data.MR=0;
			}
			else if(params.data.Total < 100){
				 TotalWidth=params.data.Total;
			}
			else if(params.data.Total > 100){
				 TotalWidth=params.data.Total/10 +20;
			}
			return "<div class='progress'>"+
			  "<div role='progressbar' aria-valuenow='"+params.data.Total+"' aria-valuemin='0' aria-valuemax='100' style='min-width:.7em; width:"+TotalWidth+"%'>"+params.data.Total+"</div></div>";
		}
		
		vm.totalEventPrint=function(){
			$("#eventTable .margin5px").css("display","none");
			var fileName="EventTable.pdf";
			var EventTable=document.getElementById("eventTable");
			domtoimage.toPng(EventTable).then(function(dataUrl) {
				console.log(dataUrl);
				var dwidth=$("#eventTable").width();
					var dheight=$("#eventTable").height();
					var _postPdfData =	{
                		"images":[
							{  
							    "data":dataUrl,
							    "width":dwidth,
							    "height": dheight      							 
							   }						   
                		 ]		
					};
					_postPdfData = JSON.parse(angular.toJson(_postPdfData));
						var pdfUrl = "ops/engie/printpdf ";
						$http.post(pdfUrl,_postPdfData,{responseType:'arraybuffer'}).then(function onSuccess(response) {
							if (response.data) {    						
								var file = new Blob([response.data], {type: 'application/pdf'});
								var fileURL = window.URL.createObjectURL(file);
								if(response && response.data){
									var a = document.createElement("a");
									document.body.appendChild(a);
									a.href = fileURL;
									console.log(fileURL);
									a.download = fileName;
									a.click();
								}
							}

						});
				  
				})
				.catch(function(error) {
				  console.error('oops, something went wrong!', error);
				});
				setTimeout(function(){$("#eventTable .margin5px").css("display","block"); }, 10);
		}
		
		vm.fullScreenChart = function(targetChart){
		
			$('#fullScreenChart').modal('show');
			
		}
		
		
		 vm.init();

}}())
