/* 
 *  ================================================================================
 *  Copyright (C) 2017
 */
(function(){
	'use strict';	

/**
 * filter to show response type
 * */
	AppModule.filter('checkAval', function() {
		return function(input,option) {
			if(input){
				for(var i in input){
					if(input[i].answerCncptCode.trim()===option){
						return true;
					}
				}
			}
			return false;
		}
	});
	/**
	 * filter to get the answer Text
	 * */
		AppModule.filter('getText', function() {
			return function(input,option) {
				if(input){
					for(var i in input){
						if(input[i].answerCncptCode.trim()===option){
							return input[i].answerText;
						}
					}
				}
				return '';
			}
		});
		
		AppModule.filter('getByDate', function() {
			  return function(input, id) {
			    var i=0, len=input.length;
			    var dataArr= [];
			    for (; i<len; i++) {
			      if (+input[i].lastEntryTimestamp == +id) {
			      dataArr.push(input[i]);
			      }
			    }
			    return dataArr;
			  }
		});
	
	
}());