angular.element(document).ready(function() {
	console.log("coming here");
    angular.bootstrap(document, ['myApp']);
});