agGrid.initialiseAgGridWithAngular1(angular);
var AppModule = angular.module('opsModule',["ngRoute","agGrid","ngStorage","ui.bootstrap","ngCookies","ngAnimate","flow"]);

AppModule.config(['$routeProvider', 'AppConst', '$httpProvider',
      function($routeProvider, AppConst, $httpProvider) {
	    	$routeProvider   	
           .when("/ops/"+ AppConst.CONST_VAR.HOME,{
                templateUrl: AppConst.TPL_URLS.HOME
           })
	        .when('/ops/' + AppConst.CONST_VAR.EXECUTIVEOVERVIEW,{
	        	templateUrl: AppConst.TPL_URLS.EXECUTIVEOVERVIEW,
	        	controller : "executiveOverviewController",
	        	controllerAs: "executiveOverviewCtrl"	
	        })
	        .when('/ops/' + AppConst.CONST_VAR.DATACENTEROPERATIONS,{
	        	templateUrl: AppConst.TPL_URLS.DATACENTEROPERATIONS,
	        	controller : "datacenterOperationsController",
	        	controllerAs: "datacenterOperationsCtrl"	
	        })
	        .when('/ops/' + AppConst.CONST_VAR.FLAYOUT,{
	        	templateUrl: AppConst.TPL_URLS.FLAYOUT,
	        	controller : "floorLayoutController",
	        	controllerAs: "floorLayoutCtrl"	
	        })
	         .when('/ops/' + AppConst.CONST_VAR.ACTEVENTS,{
	        	templateUrl: AppConst.TPL_URLS.ACTEVENTS,
	        	controller : "activeEventsController",
	        	controllerAs: "activeEventsCtrl"	
	        })
	         .when('/ops/' + AppConst.CONST_VAR.INACTEVENTS,{
	        	templateUrl: AppConst.TPL_URLS.INACTEVENTS,
	        	controller : "inactiveEventsController",
	        	controllerAs: "inactiveEventsCtrl"	
	        })  
	        .when('/ops/' + AppConst.CONST_VAR.EVENTANALYTICS1,{
	        	templateUrl: AppConst.TPL_URLS.EVENTANALYTICS1,
	        	controller : "eventsAnalytics1",
	        	controllerAs: "eventsAnalytics1Ctrl"	
	        })
	         .when('/ops/' + AppConst.CONST_VAR.EVENTANALYTICS2,{
	        	templateUrl: AppConst.TPL_URLS.EVENTANALYTICS2,
	        	controller : "eventsAnalytics2",
	        	controllerAs: "eventsAnalytics1Ctrl"	
	        })
	        .when('/ops/' + AppConst.CONST_VAR.SINGLELINEDIAGRAM,{
	        	templateUrl: AppConst.TPL_URLS.SINGLELINEDIAGRAM,
	        	controller : "singleLineDiagramController",
	        	controllerAs: "singleLineDiagramCtrl"	
	        })
	          .when('/ops/' + AppConst.CONST_VAR.POWERDISTRIBUTIONUNIT,{
	        	templateUrl: AppConst.TPL_URLS.POWERDISTRIBUTIONUNIT,
	        	controller : "pduController",
	        	controllerAs: "pduCtrl"	
	        })
	         .when('/ops/' + AppConst.CONST_VAR.EDIAGRAM,{
	        	templateUrl: AppConst.TPL_URLS.EDIAGRAM,
	        	controller : "eleDiagramController",
	        	controllerAs: "eleDiagramCtrl"	
	        })
	        .when('/ops/' + AppConst.CONST_VAR.EDIAGRAM,{
	        	templateUrl: AppConst.TPL_URLS.EDIAGRAM,
	        	controller : "eleDiagramController",
	        	controllerAs: "eleDiagramCtrl"	
	        })
	         .when('/ops/' + AppConst.CONST_VAR.ANCILLARY,{
	        	templateUrl: AppConst.TPL_URLS.ANCILLARY,
	        	controller : "ancillaryController",
	        	controllerAs: "ancillaryCtrl"	
	        })
	        .when('/ops/' + AppConst.CONST_VAR.OPERATIONOVERVIEW,{
	        	templateUrl: AppConst.TPL_URLS.OPERATIONOVERVIEW,
	        	controller : "operationOverviewController",
	        	controllerAs: "operationOverviewCtrl"	
	        })
	        .when('/ops/' + AppConst.CONST_VAR.KPIAVAILABILITY,{
	        	templateUrl: AppConst.TPL_URLS.KPIAVAILABILITY,
	        	controller : "kpiController",
	        	controllerAs: "kpiCtrl"	
	        })
	        .when('/ops/' + AppConst.CONST_VAR.KPIENERGYEFFICIENCY,{
	        	templateUrl: AppConst.TPL_URLS.KPIENERGYEFFICIENCY,
	        	controller : "kpiEnergyEffController",
	        	controllerAs: "kpiEnergyEffCtrl"	
	        })
	        .when('/ops/' + AppConst.CONST_VAR.KPIPOWER,{
	        	templateUrl: AppConst.TPL_URLS.KPIPOWER,
	        	controller : "kpiPowerController",
	        	controllerAs: "kpiPowerCtrl"	
	        })
	         .when('/ops/' + AppConst.CONST_VAR.KPIMECHANICAL,{
	        	templateUrl: AppConst.TPL_URLS.KPIMECHANICAL,
	        	controller : "kpiMechanicalController",
	        	controllerAs: "kpiMechanicalCtrl"	
	        })
	        .when('/ops/' + AppConst.CONST_VAR.KPIAIRFLOW,{
	        	templateUrl: AppConst.TPL_URLS.KPIAIRFLOW,
	        	controller : "kpiAirflowController",
	        	controllerAs: "kpiAirflowCtrl"	
	        })
	        .otherwise({
	            redirectTo : "/"
	        });
}]);

AppModule.config(['flowFactoryProvider', function (flowFactoryProvider) {
	  flowFactoryProvider.defaults = {
	    target: '',
	    permanentErrors: [404, 500, 501],
	    maxChunkRetries: 1,
	    singleFile:1,
	    chunkRetryInterval: 5000,
	    simultaneousUploads: 4
	  };
	  flowFactoryProvider.on('catchAll', function (event) {
	    console.log('catchAll', arguments);
	  });
	  // Can be used with different implementations of Flow.js
	  // flowFactoryProvider.factory = fustyFlowFactory;
}]);

//AppModule.run(["$rootScope", "$log", "$location", function ($rootScope, $log, $location){
//    //  $localStorage.$reset();//reset all previous data
//      $log.debug('app started.');
//      $rootScope.location = $location;    
//      if($location.path() === '/' || $location.path() === '/authenticate' || $location.path() === '/forceChangePwd'){
//    	  $location.bgroundLogin = "backgroundlogin";
//      }else{
//    	  $location.bgroundLogin = "";
//      }
//      console.log("$location",$location.path());
//     
//}]);


//angular.element(document).ready(function() { 
//	console.log("coming here");
//    angular.bootstrap(document, ['myApp']);
//    
//});

/*require('./controllers/multisiteDashboard.controller');
require('./controllers/datacenterOperations.controller');
require('./directives/common-directives');
require('./filters/filters');
require('./model/app.const');
require('./model/app.model');
require('./model/app.settings');
require('./services/app.service');*/
