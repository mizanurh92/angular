/* 
 * ================================================================================
 * Copyright (C) 2017
 */
AppModule.directive('tooltipOnVal', ['AppService', 'AppSettings', '$http', '$rootScope', function(AppService, AppSettings, $http, $rootScope) {
    return {
        restrict: 'A',
        link: function(scope, element, attrs) {
            var position = attrs.tooltipPosition ? attrs.tooltipPosition : 'top';
            var maxWidth = attrs.tooltipMaxWidth ? attrs.tooltipMaxWidth : null;
            var tooltipUrl = attrs.tooltipUrl ? attrs.tooltipUrl : null;
            var trigger = attrs.trigger ? attrs.trigger : "hover";
            var tooltipContent = null;
            if (attrs.tooltipContent === undefined) {
                attrs.tooltipContent = '';
                tooltipContent = angular.element('<div>' + attrs.tooltipContent + '</div>');
            } else {
                tooltipContent = attrs.tooltipContent;
            }
            $(element).tooltipster({
                position: position,
                contentAsHTML: true,
                content: tooltipContent,
                maxWidth: maxWidth,
                onlyOne: true,
                interactive: true,
                trigger: trigger,
                functionBefore: function(instance, helper) {
                    var postData = "";
                    var equipmentID = instance._$origin[0].id;
                    var serviceType = instance._$origin.attr('serviceType');
                    postData = {
                        "site": "sdslab",
                        "serviceType": serviceType,
                        "equipmentID": scope.selectedRac
                    };
                    AppService.postData(postData, tooltipUrl).then(function(response) {
                        var tooltipList = response.data.tooltipOnVal;
                        var eventInfo = "Rack 9<hr class='divider'>";
                        for (var i = 0; i < tooltipList.length; i++) {
                            var Info = tooltipList[i].attributeName + ":" + tooltipList[i].attributeVal;
                            eventInfo = eventInfo + Info + "</br>";
                        }
                        instance.content("<div style='height : 115px;'>" + eventInfo + "</div>");
                    });
                    var url = tooltipUrl;
                }
            });
        }
    }
}]);
AppModule.directive('tooltipFl', ['AppService', 'AppSettings', '$http', '$rootScope', function(AppService, AppSettings, $http, $rootScope) {
    return {
        restrict: 'A',
        link: function(scope, element, attrs) {
            var position = attrs.tooltipPosition ? attrs.tooltipPosition : 'top';
            var maxWidth = attrs.tooltipMaxWidth ? attrs.tooltipMaxWidth : null;
            var tooltipUrl = attrs.tooltipUrl ? attrs.tooltipUrl : null;
            var trigger = attrs.trigger ? attrs.trigger : "hover";
            var tooltipContent = null;
            if (attrs.tooltipContent === undefined) {
                attrs.tooltipContent = '';
                tooltipContent = angular.element('<div>' + attrs.tooltipContent + '</div>');
            } else {
                tooltipContent = attrs.tooltipContent;
            }
            $(element).tooltipster({
                position: position,
                contentAsHTML: true,
                content: tooltipContent,
                maxWidth: maxWidth,
                trigger: trigger,
                functionBefore: function(instance, helper) {
                    var equipmentID = instance._$origin[0].id;
                    var postData = {
                        "site": "sdslab",
                        "serviceType": "tooltip",
                        "equipmentID": equipmentID
                    };
                    var url = tooltipUrl;
                    AppService.postData(postData, url).then(function(response) {
                        var eventInfo = response.data.eventSeverity + "," + response.data.eventMsg;
                        // for (i = 0; i < cities.length; i++) {
                        instance.content("<div>" + eventInfo + "</div>");
                        // }
                    });
                }
            });
        }
    }
}]);　
/*Static tooltip added for showing Rack Capacity.*/
AppModule.directive('tooltipRackCapacity', ['AppService', 'AppSettings', '$http', '$rootScope', function(AppService, AppSettings, $http, $rootScope) {
    return {
        restrict: 'A',
        link: function(scope, element, attrs) {
            var position = attrs.tooltipPosition ? attrs.tooltipPosition : 'top';
            var maxWidth = attrs.tooltipMaxWidth ? attrs.tooltipMaxWidth : null;
            var tooltipUrl = attrs.tooltipUrl ? attrs.tooltipUrl : null;
            var trigger = attrs.trigger ? attrs.trigger : "hover";
            var tooltipContent = null;
            if (attrs.tooltipContent === undefined) {
                attrs.tooltipContent = '';
                tooltipContent = angular.element('<div>' + attrs.tooltipContent + '</div>');
            } else {
                tooltipContent = attrs.tooltipContent;
            }
            $(element).tooltipster({
                position: position,
                contentAsHTML: true,
                content: tooltipContent,
                maxWidth: maxWidth,
                trigger: trigger,
                functionBefore: function(instance, helper) {
                    //alert(scope.selectedRac);
                    var postData = "";
                    var equipmentID = "CapacityDesignLimit";
                    var serviceType = instance._$origin.attr('serviceType');
                    postData = {
                        "site": "sdslab",
                        "serviceType": serviceType,
                        "equipmentID": equipmentID
                    };
                    AppService.postData(postData, tooltipUrl).then(function(response) {
                        var tooltipList = response.data.tooltipOnVal;
                        var eventInfo = "Rack 9<hr class='divider'>";
                        for (var i = 0; i < tooltipList.length; i++) {
                        	if(tooltipList[i].attributeName=='CapacityDesignLimit'){
                        		continue;
                        	}
                            var Info = tooltipList[i].attributeName + ":" + tooltipList[i].attributeVal;
                            eventInfo = eventInfo + Info + "</br>";
                        }
                        instance.content("<div>" + eventInfo + "</div>");
                    });
                    var url = tooltipUrl;
                }
            });
        }
    }
}]);
/*Static data if there is any event*/
AppModule.directive('tooltipRackCapacityNoValue', ['AppService', 'AppSettings', '$http', '$rootScope', function(AppService, AppSettings, $http, $rootScope) {
    return {
        restrict: 'A',
        link: function(scope, element, attrs) {
            var position = attrs.tooltipPosition ? attrs.tooltipPosition : 'top';
            var maxWidth = attrs.tooltipMaxWidth ? attrs.tooltipMaxWidth : null;
            var tooltipUrl = attrs.tooltipUrl ? attrs.tooltipUrl : null;
            var trigger = attrs.trigger ? attrs.trigger : "hover";
            var tooltipContent = null;
            if (attrs.tooltipContent === undefined) {
                attrs.tooltipContent = '';
                tooltipContent = angular.element('<div>' + attrs.tooltipContent + '</div>');
            } else {
                tooltipContent = attrs.tooltipContent;
            }
            $(element).tooltipster({
                position: position,
                contentAsHTML: true,
                content: tooltipContent,
                maxWidth: maxWidth,
                trigger: trigger,
                functionBefore: function(instance, helper) {
                    var postData = "";
                    var equipmentID = "CapacityDesignLimit";
                    var serviceType = instance._$origin.attr('serviceType');
                    postData = {
                        "site": "sdslab",
                        "serviceType": serviceType,
                        "equipmentID": equipmentID
                    };
                    AppService.getData(1, tooltipUrl).then(function(response) {
                        var tooltipList = response.data.tooltipOnVal;                       
                        var eventInfo = "Rack 9<hr class='divider'>";
                        for (var i = 0; i < tooltipList.length; i++) {
                        	if(tooltipList[i].attributeName=='CapacityDesignLimit'){
                        		continue;
                        	}
                            var Info = tooltipList[i].attributeName + ":" + tooltipList[i].attributeVal;
                            eventInfo = eventInfo + Info + "</br>";
                        }
                        instance.content("<div>" + eventInfo + "</div>");
                    });
                }
            });
        }
    }
}]);