AppModule.directive('tooltipEle', ['AppService', 'AppSettings', '$http','$rootScope',function(AppService, AppSettings, $http,$rootScope) {
    return {
        restrict: 'A',
        link: function(scope, element, attrs) {
            var position = attrs.tooltipPosition ? attrs.tooltipPosition : 'top';
            var maxWidth = attrs.tooltipMaxWidth ? attrs.tooltipMaxWidth : null;
            var tooltipUrl = attrs.tooltipUrl ? attrs.tooltipUrl : null;
            var trigger = attrs.trigger ? attrs.trigger : "hover";
            var tooltipContent = null;
            if(attrs.tooltipContent === undefined) {
            	attrs.tooltipContent = '';
            	tooltipContent = angular.element('<div>' + attrs.tooltipContent + '</div>');
            } else {
            	tooltipContent = attrs.tooltipContent;
            }
            $(element).tooltipster({
                position: position,
                contentAsHTML:true,
                content: tooltipContent,
                maxWidth: maxWidth,
                trigger: trigger,
                functionBefore: function(instance, helper){
                	
                	 var equipmentID = instance._$origin[0].id;
                	 var postData={"site":"sdslab","serviceType":"tooltipEle","equipmentID":equipmentID};
                     var url = tooltipUrl;
                     AppService.postData(postData, url).then(function(response) {
                    	 
                         //var eventInfo = response.data.eventSeverity+","+response.data.eventMsg;
                    	 //CurrentLoad" , "CapacityUsed" , "CapacityDesignLimit", "CapacityRemaining
                    	 var eventInfo = "CurrentLoad: " + response.data.CurrentLoad + "<br>" +
                    	 	"CapacityUsed: " + response.data.CapacityUsed + "<br>" +
                    	 	/*"CapacityDesignLimit: " + response.data.CapacityDesignLimit + "<br>" +*/
                    	 	"CapacityRemaining: " + response.data.CapacityRemaining;
//                         for (i = 0; i < cities.length; i++) {
                        	 instance.content("<div>"+eventInfo+"</div>");
//                         }
                     });
           
                }
            });
                                
        }
    }
}]);