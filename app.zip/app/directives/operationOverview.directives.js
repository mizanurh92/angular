/* 
 *  ================================================================================
 *  Copyright (C) 2017
 */
AppModule.directive('electricalBoardGauge', ['AppService', 'AppSettings', '$http', '$rootScope', function(AppService, AppSettings, $http, $rootScope) {
    return {
        restrict: 'E',
        template: "<div></div>",
        scope: {
            title: '@',
            data: '='
        },
        link: function(scope, element, attrs) {
        	
            var chartElectricalGauge = new Highcharts.chart({
            	
            	chart: {
                    renderTo: element[0],
                    type: 'gauge',
                    plotBorderWidth: 1,
                    plotBackgroundColor: {
                        linearGradient: {
                            x1: 0,
                            y1: 0
                        },
                        stops: [
                            [0, '#196F3D'],
                            [0.3, '#F4D03F'],
                            [1, '#E74C3C']
                        ]
                    },
                    plotBackgroundImage: null,
                    height: 55,
                    width: 98
                },

                title: {
                    text: ''

                },

                pane: [{
                    startAngle: -40,
                    endAngle: 40,
                    background: null,
                    center: ['45%', '145%'],
                    size: 57
                }],

                tooltip: {
                    enabled: false
                },

                yAxis: [{
                    min: 0,
                    max: 100,
                    minorTickPosition: 'outside',
                    tickPosition: 'outside',
                    labels: {
                        rotation: 'auto',
                        distance: 20,
                        style: {

                            fontSize: '6px'
                        }
                    },
                    plotBands: [{
                        from: 0,
                        to: 6,
                        color: '#C02316',
                        innerRadius: '100%',
                        outerRadius: '105%'
                    }],
                    pane: 0,
                    title: {
                        y: -40
                    }
                }],

                plotOptions: {
                    gauge: {
                        dataLabels: {
                            enabled: false
                        },
                        dial: {
                            radius: '100%'
                        }
                    }
                },
                series: [{
                    name: 'Channel A',
                    data: [parseFloat(scope.data)],
                    yAxis: 0
                }],
                exporting: {
                    enabled: false
                }

            });
        }
    };
}]);

AppModule.directive('averageTemperatureChart', ['AppService', 'AppSettings', '$http','$rootScope', function(AppService, AppSettings, $http,$rootScope){
    return {
    	restrict: 'E',
    	template: "<div></div>",
    	scope: {
            id: '=',
            data: '=',
            height: '=',
            width: '=',
            typeval: '=',
        },
        link: function(scope, element, attrs) {
        	
        	scope.data = parseFloat(scope.data);
        	
        	if(scope.data > 400){
        		scope.data = 400;
        	}
        	
        	var chartSpeedometer = new Highcharts.chart(element[0],{
        		
        		chart: {
                    type: 'gauge',
                    plotBackgroundColor: null,
                    plotBackgroundImage: null,
                    plotBorderWidth: 0,
                    plotShadow: false,
                    backgroundColor:'transparent',
                    height: scope.height,
                    width: scope.width
                },
        		title: {
        	        text: ''
        	    },

        	    pane: {
        	        startAngle: -150,
        	        endAngle: 150,
        	        background: [{
        	            backgroundColor: {
        	                linearGradient: { x1: 0, y1: 0, x2: 0, y2: 1 },
        	                stops: [
        	                    [0, '#FFF'],
        	                    [1, '#333']
        	                ]
        	            },
        	            borderWidth: 0,
        	            outerRadius: '109%'
        	        }, {
        	            backgroundColor: {
        	                linearGradient: { x1: 0, y1: 0, x2: 0, y2: 1 },
        	                stops: [
        	                    [0, '#333'],
        	                    [1, '#FFF']
        	                ]
        	            },
        	            borderWidth: 1,
        	            outerRadius: '107%'
        	        }, {
        	            // default background
        	        }, {
        	            backgroundColor: '#DDD',
        	            borderWidth: 0,
        	            outerRadius: '105%',
        	            innerRadius: '103%'
        	        }]
        	    },

        	    // the value axis
        	    yAxis: {
        	        min: 0,
        	        max: 150,

        	        minorTickInterval: 'auto',
        	        minorTickWidth: 1,
        	        minorTickLength: 10,
        	        minorTickPosition: 'inside',
        	        minorTickColor: '#666',
        	        tickInterval: 25,
        	        tickPixelInterval: 25,
        	        tickWidth: 2,
        	        tickPosition: 'inside',
        	        tickLength: 10,
        	        tickColor: '#666',
        	        labels: {
        	            step: 1,
        	            rotation: 'auto'
        	        },
        	        title: {
        	            text: ''
        	        },
        	        plotBands: [{
        	            from: 0,
        	            to: 75,
        	            color: '#55BF3B' // green
        	        }, {
        	            from: 75,
        	            to: 100,
        	            color: '#DDDF0D' // yellow
        	        }, {
        	            from: 100,
        	            to: 150,
        	            color: '#DF5353' // red
        	        }]
        	    },
        	    plotOptions: {
        	        series: {
        	          dataLabels: {
        	            borderWidth: 0
        	          }
        	        }
        	      },
        	      
        	    tooltip: {
     	           
     	            pointFormat: '{series.name}<br/><span text-align=center>   <b>{point.y}</b></span>',
     	            enabled: false,
     	           useHTML:true,
                     formatter:function(){
                       if(this.series.name == 'Temperature') {
                    	   return this.series.name+ '<br/><span text-align=center>   <b>' +this.y+ ' <sup>0</sup>C</b></span>';
                       }else {
                    	   return this.series.name+ '<br/><span text-align=center>   <b>' +this.y+ '</b></span>';
                       }
                     }
     	            
     	        },
        	    series: [{
        	        name: scope.typeval,
        	        data: [scope.data],
        	        dataLabels: {
        	    	    formatter: function () {
        	    	        return null;
        	    	    }
        	    	},
        	    }],
        	    responsive: {
  		          rules: [{
		              condition: {
		                  maxWidth: 100
		              },
		              chartOptions: {
		                  legend: {
		                      align: 'center',
		                      verticalAlign: 'bottom',
		                      layout: 'horizontal'
		                  },
		                  yAxis: {
		                      labels: {
		                          align: 'left',
		                          x: 0,
		                          y: -5
		                      },
		                      title: {
		                          text: null
		                      }
		                  },
		                  subtitle: {
		                      text: null
		                  },
		                  credits: {
		                      enabled: false
		                  }
		              }
		          }]
		      },
        	    
            exporting: {
                enabled: false
            }
        	});
        }
    };
}]);

AppModule.directive('averageHumidityChart', ['AppService', 'AppSettings', '$http','$rootScope', function(AppService, AppSettings, $http,$rootScope){
    return {
    	restrict: 'E',
    	template: "<div></div>",
    	scope: {
            id: '=',
            data: '=',
            height: '=',
            width: '=',
            typeval: '=',
        },
        link: function(scope, element, attrs) {
        	
        	scope.data = parseFloat(scope.data);
        	
        	if(scope.data > 400){
        		scope.data = 400;
        	}
        	
        	var chartSpeedometer = new Highcharts.chart(element[0],{
        		
        		chart: {
                    type: 'gauge',
                    plotBackgroundColor: null,
                    plotBackgroundImage: null,
                    plotBorderWidth: 0,
                    plotShadow: false,
                    backgroundColor:'transparent',
                    height: scope.height,
                    width: scope.width
                },
        		title: {
        	        text: ''
        	    },

        	    pane: {
        	        startAngle: -150,
        	        endAngle: 150,
        	        background: [{
        	            backgroundColor: {
        	                linearGradient: { x1: 0, y1: 0, x2: 0, y2: 1 },
        	                stops: [
        	                    [0, '#FFF'],
        	                    [1, '#333']
        	                ]
        	            },
        	            borderWidth: 0,
        	            outerRadius: '109%'
        	        }, {
        	            backgroundColor: {
        	                linearGradient: { x1: 0, y1: 0, x2: 0, y2: 1 },
        	                stops: [
        	                    [0, '#333'],
        	                    [1, '#FFF']
        	                ]
        	            },
        	            borderWidth: 1,
        	            outerRadius: '107%'
        	        }, {
        	            // default background
        	        }, {
        	            backgroundColor: '#DDD',
        	            borderWidth: 0,
        	            outerRadius: '105%',
        	            innerRadius: '103%'
        	        }]
        	    },

        	    // the value axis
        	    yAxis: {
        	        min: 0,
        	        max: 100,

        	        minorTickInterval: 'auto',
        	        minorTickWidth: 1,
        	        minorTickLength: 10,
        	        minorTickPosition: 'inside',
        	        minorTickColor: '#666',
        	        tickInterval: 25,
        	        tickPixelInterval: 25,
        	        tickWidth: 2,
        	        tickPosition: 'inside',
        	        tickLength: 10,
        	        tickColor: '#666',
        	        labels: {
        	            step: 1,
        	            rotation: 'auto'
        	        },
        	        title: {
        	            text: ''
        	        },
        	        plotBands: [{
        	            from: 0,
        	            to: 40,
        	            color: '#55BF3B' // green
        	        }, {
        	            from: 40,
        	            to: 70,
        	            color: '#DDDF0D' // yellow
        	        }, {
        	            from: 70,
        	            to: 100,
        	            color: '#DF5353' // red
        	        }]
        	    },
        	    plotOptions: {
        	        series: {
        	          dataLabels: {
        	            borderWidth: 0
        	          }
        	        }
        	      },
        	    tooltip: {
     	           
     	            pointFormat: '{series.name}<br/><span text-align=center>   <b>{point.y}</b></span>',
     	            enabled: false,
     	           useHTML:true,
                     formatter:function(){
                       if(this.series.name == 'Humidity') {
                    	   return this.series.name+ '<br/><span text-align=center>   <b>' +this.y+ ' <sup>0</sup>C</b></span>';
                       }else {
                    	   return this.series.name+ '<br/><span text-align=center>   <b>' +this.y+ '</b></span>';
                       }
                     }
     	            
     	        },
        	    series: [{
        	        name: scope.typeval,
        	        data: [scope.data],
        	        dataLabels: {
        	    	    formatter: function () {
        	    	        return null;
        	    	    }
        	    	},
        	    }],
        	    responsive: {
  		          rules: [{
		              condition: {
		                  maxWidth: 100
		              },
		              chartOptions: {
		                  legend: {
		                      align: 'center',
		                      verticalAlign: 'bottom',
		                      layout: 'horizontal'
		                  },
		                  yAxis: {
		                      labels: {
		                          align: 'left',
		                          x: 0,
		                          y: -5
		                      },
		                      title: {
		                          text: null
		                      }
		                  },
		                  subtitle: {
		                      text: null
		                  },
		                  credits: {
		                      enabled: false
		                  }
		              }
		          }]
		      },
        	    
            exporting: {
                enabled: false
            }
        	});
        }
    };
}]);