/* 
 *  ================================================================================
 *  Copyright (C) 2017
 */
AppModule.directive('tooltipSl', ['AppService', 'AppSettings', '$http','$rootScope',function(AppService, AppSettings, $http,$rootScope) {
    return {
        restrict: 'A',
        link: function(scope, element, attrs) {
            var position = attrs.tooltipPosition ? attrs.tooltipPosition : 'top';
            var maxWidth = attrs.tooltipMaxWidth ? attrs.tooltipMaxWidth : null;
            var tooltipUrl = attrs.tooltipUrl ? attrs.tooltipUrl : null;
            var trigger = attrs.trigger ? attrs.trigger : "hover";
           $(element).tooltipster({
                position: position,
                contentAsHTML:true,
               /* content: angular.element('<div>' + attrs.tooltipContent + '</div>'),*/
                content: angular.element('<div>&nbsp;</div>'),
                maxWidth: maxWidth,
                trigger: trigger,
                functionBefore: function(instance, helper){
                	
                	 var equipmentID = instance._$origin[0].id;
                	 var postData={"site":"sdslab","serviceType":"tooltip","equipmentID":equipmentID};
                     var url = tooltipUrl;
                     AppService.postData(postData, url).then(function(response) {
                         var eventInfo = response.data.eventSeverity+","+response.data.eventMsg;
//                         for (i = 0; i < cities.length; i++) {
                        	 instance.content("<div>"+eventInfo+"</div>");
//                         }
                     });
           
                }
            });
                                
        }
    }
}]);
AppModule.directive('tooltipSo', ['AppService', 'AppSettings', '$http','$rootScope',function(AppService, AppSettings, $http,$rootScope) {
    return {
        restrict: 'A',
        link: function(scope, element, attrs) {
            var position = attrs.tooltipPosition ? attrs.tooltipPosition : 'top';
            var maxWidth = attrs.tooltipMaxWidth ? attrs.tooltipMaxWidth : null;
            var tooltipUrl = attrs.tooltipUrl ? attrs.tooltipUrl : null;
            var trigger = attrs.trigger ? attrs.trigger : "hover";
           $(element).tooltipster({
                position: position,
                contentAsHTML:true,
               /* content: angular.element('<div>' + attrs.tooltipContent + '</div>'),*/
                content: angular.element('<div>&nbsp;</div>'),
                maxWidth: maxWidth,
                trigger: trigger,
                functionBefore: function(instance, helper){
                	var assetId1="SDSLAB-KCT-UPS 6-2A";
					var assetId2="SDSLAB-KCT-UPS 6-2B";
					var systemOverviewUrl='assetperformance/engie/service/assetperformance/upsview';
                	var temp = instance._$origin[0].id;
					
					var equipmentIDwithStatus=temp.split("_");
					var equipmentID=equipmentIDwithStatus[1];
					var assetStatus=equipmentIDwithStatus[2];
					 instance.content("<div>"+equipmentID+"</div><div>"+assetStatus+"</div>");
					
                	 //var postData={"site":"sdslab","serviceType":"tooltip","equipmentID":equipmentID};
                     //var url = tooltipUrl;
                     
           
                }
            });
                                
        }
    }
}]);
