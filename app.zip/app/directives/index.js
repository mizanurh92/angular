'use strict';

var angular = require('angular');

angular.module('dashboard').directive('yepNope', require('./yep-nope.directive'));