/* 
 *  ================================================================================
 *  Copyright (C) 2017
 */
/**Directive to allow specific patterns only */
AppModule.directive('allowPattern', function() {
    return {
        restrict: "A",
        compile: function(tElement, tAttrs) {
            return function(scope, element, attrs) {
                element.bind("keypress", function(event) {
                    var keyCode = event.which || event.keyCode;
                    var keyCodeChar = String.fromCharCode(keyCode);
                    if (!keyCodeChar.match(new RegExp(attrs.allowPattern, "i"))) {
                        event.preventDefault();
                        return false;
                    }
                });
            };
        }
    };
});

AppModule.directive('myMaps', ['AppService', 'AppSettings', '$http','$rootScope', function(AppService, AppSettings, $http,$rootScope) {
    return {
        restrict: "E",
        scope: {
            data: '='
        },
        template: "<div style='height:360px;margin:5px;'></div>",
        replace: true,
        link: function(scope, element, attrs) {
        		var myLatlng = new google.maps.LatLng(1.352083, 103.81983600000001);
        	
            var mapOptions = {
                zoom: 14,
                center: myLatlng,
                streetViewControl: false,
                mapTypeId: 'terrain'
            };
            var map = new google.maps.Map(document.getElementById(attrs.id),
                mapOptions);
            scope.markers = [];
            var infoWindow = new google.maps.InfoWindow({maxWidth: 420});
            var createMarker = function(info) {
            	var iconBase = 'assets/images/';
            	var icons = {
            	          critical: {
            	            icon: iconBase + 'iconCritical.png'
            	          },
            	          warning: {
            	        	  icon: iconBase + 'iconWarning.png'
            	          },
            	          minor: {
            	        	  icon: iconBase + 'iconMinor.png'
            	          }
            	        };
            	
                var marker = new google.maps.Marker({
                    map: map,
                    position: new google.maps.LatLng(info.latitude, info.longitude),
                    icon: icons[info.type].icon,
                    title: info.siteId,
                  
                });
                marker.content = '<div class="map-info-window"><div class="infoWindowContent">'+
                	'<div class="panel panel-default"><div class="panel-heading">'+info.siteId+'</div>'+
                	'<div class="panel-body"><ul><li class="text-center"><p class="totalAlarmCount">'+info.totalEventCount+'</p>'+
                	'<p><b>TOTAL ACTIVE<br /> ALARM COUNT</b></p></li>'+
                    '<li ><p ><span text-center"></span>'+
                	'<span class="criticalCount">'+info.totalActiveAlarms[0].y+' CRITICAL EVENT</span></p><p><span class="text-center">'+
                    ' </span><span class="warningCount">'+info.totalActiveAlarms[1].y+' WARNING EVENT</span></p>'+
                	'<p><span class=" text-center"></span>'+
                    '<span class="minorCount">'+info.totalActiveAlarms[2].y+' MINOR EVENT</span></p></li></ul></div></div></div></div>';
                //marker.content = '<div class="siteDetails"><ul><li><h5>' + info.totalEventCount + '-' +info.totalActiveAlarms[1].y +':Critical<br>' +info.totalActiveAlarms[2].y +':Warning<br>' +info.totalActiveAlarms[0].y +':Minor</li><li></h5><h5>TOTAL ACTIVE ALARM COUNT</h5></li></ul></div>';

                google.maps.event.addListener(marker, 'click', function() {
                	infoWindow.setContent(marker.content);
                    infoWindow.open(map, marker);
                   /* map.setCenter(new google.maps.LatLng(1.352083, 103.81983600000001)); */
                });
                
                google.maps.event.addListener(infoWindow,'closeclick',function(){
                	map.setCenter(new google.maps.LatLng(1.352083, 103.81983600000001));
                	});
                
                scope.markers.push(marker);
            }
            var cityId = 1;
            var url = "engie/msd/map?userId=anilkumar@engie.com";
            var cities = scope.data;
            for (i = 0; i < cities.length; i++) {
            	if(cities[i].totalActiveAlarms[0].y > 0){
            		cities[i].type = "critical";
            	}else if((cities[i].totalActiveAlarms[0].y === 0.0) && (cities[i].totalActiveAlarms[1].y > 0)){
            		cities[i].type = "warning";
            	}else if((cities[i].totalActiveAlarms[0].y === 0.0) && (cities[i].totalActiveAlarms[1].y === 0.0)){
            		cities[i].type = "minor";
            	}            			
                createMarker(cities[i]);
            }
           
        }
    };
}]);


AppModule.directive('activeAlarmChart', ['AppService', 'AppSettings', '$http','$rootScope', function(AppService, AppSettings, $http,$rootScope){
    return {
        restrict: 'E',
        template: "<div style='height: 120px;min-width: 200px; max-width: 220px;'></div>",
        scope: {
            title: '@',
            data: '='
        },
        link: function(scope, element, attrs) {

        	scope.data[0].color = "#E74C3C";
        	scope.data[1].color = "#F4D03F";
        	
        	console.log("from active alarm chart : ",scope.data);
        	
        	for (var i = 0; i < scope.data.length; i++) {
        		if(scope.data[i].y === 0){
        			scope.data[i].y = 0.2;
        		}
        	};
            Highcharts.chart(element[0], {
            	chart: {
                    type: 'bar',
                    height: 120,
                    width: 220,
                    backgroundColor:'transparent'
                },
                legend: {
                    enabled: true,
        	    	layout: 'vertical',
            		align: 'right',
        				verticalAlign: 'middle',
                    labelFormatter: function() {
        				return this.name + " - <span class='total'>"+this.y+"</span>"
                    }
                },
                title: {
                    text: null
                },
                tooltip:{
                	enabled : false
                },
	
                xAxis: {
                    categories: ['Critical', 'Warning', 'Minor'],
                    labels: {
                        formatter: function () {
                            if ('Critical' === this.value) {
                                return '<span style="fill: #E74C3C;">' + this.value + '</span>';
                            } else if ('Warning' === this.value){
                            	return '<span style="fill: #F4D03F;">' + this.value + '</span>';
                            } else if('Minor' === this.value){
                            	return '<span style="fill: grey;">' + this.value + '</span>';
                            } else{
                            	
                            }
                        }
                    },
                    allowDecimals: false,
                    gridLineColor: 'transparent',
                    gridLineWidth: 0,
                    minorGridLineWidth: 0,
                    title: { text: '' },
                    lineWidth: 0,	
           					lineColor: 'transparent',
                    minorTickLength: 0,
           					tickLength: 0
                },
                yAxis: {
                    allowDecimals: false,
                    gridLineColor: 'transparent',
                    labels:{enabled: false},
                    gridLineWidth: 0,
                    minorGridLineWidth: 0,
                 		title: { text: '' }
                },
                plotOptions: {
                	 series: {
                        events: {
                            legendItemClick: function (x) {
                                var i = this.index  - 1;
                                var series = this.chart.series[0];
                                var point = series.points[i];   

                                if(point.oldY == undefined)
                                   point.oldY = point.y;

                                point.update({y: point.y != null ? null : point.oldY});
                            }
                        },
						dataLabels: {
							enabled: true,
							borderRadius: 0,
							inside: true,
							color: '#000',
							style: {
								textOutline: false,
								fontWeight: 'none'
			                }
						}
                    }
                },
                series: [
                    {
                        pointWidth:25,
                        color: ['#E74C3C', '#F4D03F', 'grey'],
                        showInLegend:false,
                        data: scope.data,
                        tooltip:{
                        	formatter:function(){
                                 if(this.point.y === 0.2)
                                	 return 'ON'
                                else
                                	return 'OFF'
                                   
                            },
                            pointFormat: '{name}<br/><span text-align=center><b>{point.y}</b></span>',
                        },
                        tooltip: {
            	            valueSuffix: '',
            	            useHTML:true,
            	            pointFormat: '{name}<br/><span text-align=center><b>{point.y}</b></span>',
            	        }
                    }
                    
                ],
                
                
                  
                lang: {
                    noData: "No Data Found"
                },
                noData: {
                    style: {
                        fontWeight: 'bold',
                        fontSize: '15px',
                        color: '#303030'
                    }
                },
                exporting: {
                    enabled: false
                }
                
            });
            
            
        }
    };
}]);


AppModule.directive('cylinderChart', ['AppService', 'AppSettings', '$http','$rootScope','AppConst', '$timeout', function(AppService, AppSettings, $http, $rootScope, AppConst,$timeout){
    return {
        restrict: 'E',
        template: "<div style='height: 120px;min-width: 200px; max-width: 220px;'></div>",
        scope: {
            id: '=',
            data: '='
        },
        link: function(scope, element, attrs) {
        	var fillColor;
        	
    		if(scope.data[0].value1 >= "50"){
    			fillColor = AppConst.CONST_VAR_VAL.RED;
    		}else if((scope.data[0].value1 < "50") && (scope.data[0].value1 >= "30")){
    			fillColor = AppConst.CONST_VAR_VAL.GREEN;
    		}else{
    			fillColor = AppConst.CONST_VAR_VAL.YELLOW;
    		}
    		
    		/*Creating value for data[0].value2 for correcting the format*/
    		scope.data[0].value2 = (100 - scope.data[0].value1).toString();
    		$timeout(function() {
	    	var chartCylinder = AmCharts.makeChart(scope.id, {	
		       	  "theme": "light",
		       	  "type": "serial",
		       	  "depth3D": 100,
		       	  "angle": 10,
		       	  "autoMargins": false,
		       	  "marginTop":0, 
		       	  "marginBottom": 0,
		       	  "marginLeft": 0,
		       	  "marginRight": 0,
		       	  "pullOutRadius":0,
		       	  "dataProvider": scope.data,
		       	  "valueAxes": [ {
		       	    "stackType": "100%",
		       	    "gridAlpha": 0,
		       	    "labelsEnabled": false
		       	  } ],
		       	  "graphs": [ {
		       	    "type": "column",
		       	    "topRadius": 1,
		       	    "columnWidth": 1,
		       	    "showOnAxis": false,
		       	    "lineThickness": 2,
		       	    "lineAlpha": 0.5,
		       	    "lineColor": "#FFFFFF",
		       	    "fillColors": fillColor,
		       	    "fillAlphas": 0.8,
		       	    "valueField": "value1"
		       	  }, {
		       	    "type": "column",
		       	    "topRadius": 1,
		       	    "columnWidth": 1,
		       	    "showOnAxis": false,
		       	    "lineThickness": 2,
		       	    "lineAlpha": 0.5,
		       	    "lineColor": "#cdcdcd",
		       	    "fillColors": "#cdcdcd",
		       	    "fillAlphas": 0.5,
		       	    "valueField": "value2"
		       	  } ],
		
		       	  "categoryField": "category",
		       	  "listeners": [{
		            "event": "rendered",
		            "method": handleRender
		            }],
		       	  "categoryAxis": {
		       	    "axisAlpha": 0,
		       	    "labelOffset": 0,
		       	    "gridAlpha": 0
		       	  },
		       	  "export": {
		       	    "enabled": false
		       	  }
		       	});
    		}, 1000);
	
			 function handleRender(event) {
			   $(".chartdiv1 a").remove();
			   $(".chartdiv2 a").remove();
			   $(".chartdiv3 a").remove();
			 };
        }
    };
}]);


AppModule.directive('summaryAssetHealth', ['AppService', 'AppSettings', '$http','$rootScope', function(AppService, AppSettings, $http,$rootScope){
    return {
        restrict: 'E',
        template: "<div style='position:absolute; left:0px; top:0px;'></div>",
        scope: {
            title: '@',
            data: '='
        },
        link: function(scope, element, attrs) {
        	var chart = new Highcharts.chart({
                chart: {
                    renderTo: attrs.id,
                    type: 'pie',
                    margin: [0, 0, 0, 0],
                    spacingTop: 0,
                    spacingBottom: 0,
                    spacingLeft: 0,
                    spacingRight: 0,
                    width: 168,
                    height: 132
                },
                title: {
                    text: ''
                },
                plotOptions: {
                    pie: {
                        innerSize: '80%',
                        size:'100%',
                        dataLabels: {
                            enabled: false,
                            
                        },
                    }
                },
                series: [
                         {
                        	 pointWidth:20,
                             data: scope.data
                         }
                         
                     ],
                exporting: {
                    enabled: false
                }        
            },
            
            function(chart) { // on complete
            	var total = scope.data[0].y + scope.data[1].y
                var textX = chart.plotLeft + (chart.plotWidth  * 0.5);
                var textY = chart.plotTop  + (chart.plotHeight * 0.5);

                var span = '<span id="pieChartInfoText" style="position:absolute; text-align:center;">';
                span += '<span style="font-size: 23px">'+total+'</span><br>';
                span += '<span style="font-size: 15px">Total</span>';
                span += '</span>';

                $("#addText").append(span);
                span = $('#pieChartInfoText');
                span.css('left', textX + (span.width() * -0.5));
                span.css('top', textY + (span.height() * -0.5));
            });
            
            
        }
    };
}]);

  	
        	
AppModule.directive('activeEventsPastWeek', ['AppService', 'AppSettings', '$http','$rootScope', function(AppService, AppSettings, $http,$rootScope){
    return {
    	restrict: 'E',
    	template: "<div></div>",
    	scope: {
            title: '@',
            data: '=',
            timeseries: '='
        },
        link: function(scope, element, attrs) {
        	var chartEvents = new Highcharts.chart({
        		chart: {
                    renderTo: attrs.id,
                    width: 590,
                    height: 250
                },
        		title: {
        	        text: ''
        	    },
        	    xAxis:{
        	    	 categories: scope.timeseries
        	    },
        	    yAxis: {
        	        title: {
        	            text: 'Active Events'
        	        }
        	    },
        	    legend: {
        	        layout: 'vertical',
        	        align: 'right',
        	        verticalAlign: 'middle'
        	    },

        	    plotOptions: {
        	        
        	    },

        	    series: scope.data,
                exporting: {
                    enabled: false
                }
        	});
        }
    };
}]);


AppModule.directive('alarmDistribution', ['AppService', 'AppSettings', '$http','$rootScope', function(AppService, AppSettings, $http,$rootScope){
    return {
    	restrict: 'E',
    	template: "<div></div>",
    	scope: {
            title: '@',
            data: '='
        },
        link: function(scope, element, attrs) {
        	scope.data[0].color = "#E74C3C";
        	scope.data[1].color = "#F4D03F";
        	var chartAlarmDistribution = new Highcharts.chart({
        	
             chart: {
                 renderTo: attrs.id,
                 margin: [0, 0, 0, 0],
                 spacingTop: 0,
                 spacingBottom: 0,
                 spacingLeft: 0,
                 spacingRight: 0,
                 type: 'pie',
                 width: 168,
                 height: 132
             },
             title: {
                 text: ''
             },
             plotOptions: {
                 pie: {
                     allowPointSelect: true,
                     cursor: 'pointer',
                     size : 120,
                     dataLabels: {
                         enabled: true,
                         format: '{point.percentage:.1f} %',
                         distance: -30,
                            style: {
                                fontWeight: 'bold',
                                color: 'white'
                            }
                     },
                     showInLegend: false,
                 }
             },
             series: [{
                    colorByPoint: true,
                    data: scope.data
                }],
             exporting: {
                    enabled: false
             }   

            });
        }
    };
}]);


AppModule.directive('uptimeChart', ['AppService', 'AppSettings', '$http','$rootScope','AppConst', function(AppService, AppSettings, $http, $rootScope, AppConst){
    return {
        restrict: 'E',
        template: "<div style='width: 80%;height: 200px;margin: 0 auto'></div>",
        scope: {
        	id: '=',
            data: '='
        },
        link: function(scope, element, attrs) {
            var chart = AmCharts.makeChart("upTime", {
                "theme": "light",
                "type": "gauge",
                "axes": [{
                  "topTextFontSize": 20,
                  "topTextYOffset": 50,
                  "topText" : parseFloat(scope.data.dataCenterUPTIME).toFixed(2),
                  "axisColor": "#31d6ea",
                  "axisThickness": .05,
                  "endValue": 100,
                  "gridInside": true,
                  "inside": false,
                  "radius": "90%",
                  "valueInterval": 25,
                  "tickColor": "#67b7dc",
                  "startAngle": -90,
                  "endAngle": 90,
                  "bandOutlineAlpha": 0,
                  "bands": [{
                    "color": "#196F3D",
                    "endValue": 25,
                    "innerRadius": "125%",
                    "radius": "200%",
                    "gradientRatio": [0.5, 0, -0.5],
                    "startValue": 0
                  }, {
                    "color": "#7DCEA0",
                    "endValue": 50,
                    "innerRadius": "125%",
                    "radius": "200%",
                    "gradientRatio": [0.5, 0, -0.5],
                    "startValue": 25
                  }, {
                    "color": "#F4D03F",
                    "endValue": 75,
                    "innerRadius": "125%",
                    "radius": "200%",
                    "gradientRatio": [0.5, 0, -0.5],
                    "startValue": 50
                  }, {
                    "color": "#E74C3C",
                    "endValue": 100,
                    "innerRadius": "125%",
                    "radius": "200%",
                    "gradientRatio": [0.5, 0, -0.5],
                    "startValue": 75
                  }]
                }],
                "arrows": [{
                  "alpha": 1,
                  "innerRadius": "35%",
                  "nailRadius": 1,
                  "radius": "170%",
                  "value" : scope.data.dataCenterUPTIME
                }]
              });

        }
    };
}]);

AppModule.directive('averageSpeedometerChart', ['AppService', 'AppSettings', '$http','$rootScope', function(AppService, AppSettings, $http,$rootScope){
    return {
    	restrict: 'E',
    	template: "<div></div>",
    	scope: {
            id: '=',
            data: '=',
            height: '=',
            width: '=',
            typeval: '=',
        },
        link: function(scope, element, attrs) {
        	
        	scope.data = parseFloat(scope.data);
        	
        	if(scope.data > 400){
        		scope.data = 400;
        	}
        	
        	var chartSpeedometer = new Highcharts.chart(element[0],{
        		
        		chart: {
                    type: 'gauge',
                    plotBackgroundColor: null,
                    plotBackgroundImage: null,
                    plotBorderWidth: 0,
                    plotShadow: false,
                    backgroundColor:'transparent',
                    height: scope.height,
                    width: scope.width
                },
        		title: {
        	        text: ''
        	    },

        	    pane: {
        	        startAngle: -150,
        	        endAngle: 150,
        	        background: [{
        	            backgroundColor: {
        	                linearGradient: { x1: 0, y1: 0, x2: 0, y2: 1 },
        	                stops: [
        	                    [0, '#FFF'],
        	                    [1, '#333']
        	                ]
        	            },
        	            borderWidth: 0,
        	            outerRadius: '109%'
        	        }, {
        	            backgroundColor: {
        	                linearGradient: { x1: 0, y1: 0, x2: 0, y2: 1 },
        	                stops: [
        	                    [0, '#333'],
        	                    [1, '#FFF']
        	                ]
        	            },
        	            borderWidth: 1,
        	            outerRadius: '107%'
        	        }, {
        	            // default background
        	        }, {
        	            backgroundColor: '#DDD',
        	            borderWidth: 0,
        	            outerRadius: '105%',
        	            innerRadius: '103%'
        	        }]
        	    },

        	    // the value axis
        	    yAxis: {
        	        min: 0,
        	        max: 400,

        	        minorTickInterval: 'auto',
        	        minorTickWidth: 1,
        	        minorTickLength: 10,
        	        minorTickPosition: 'inside',
        	        minorTickColor: '#666',

        	        tickPixelInterval: 30,
        	        tickWidth: 2,
        	        tickPosition: 'inside',
        	        tickLength: 10,
        	        tickColor: '#666',
        	        labels: {
        	            step: 2,
        	            rotation: 'auto'
        	        },
        	        title: {
        	            text: ''
        	        },
        	        plotBands: [{
        	            from: 0,
        	            to: 200,
        	            color: '#55BF3B' // green
        	        }, {
        	            from: 200,
        	            to: 300,
        	            color: '#DDDF0D' // yellow
        	        }, {
        	            from: 300,
        	            to: 400,
        	            color: '#DF5353' // red
        	        }]
        	    },
        	    tooltip: {
     	           
     	           /* pointFormat: '{series.name}<br/><span text-align=center>   <b>{point.y}</b></span>',*/
     	            enabled: true,
     	           useHTML:true,
                     formatter:function(){
                       if(this.series.name == 'Temperature') {
                    	   return this.series.name+ '<br/><span text-align=center>   <b>' +this.y+ ' <sup>0</sup>F</b></span>';
                       }
                       else if((this.series.name == 'Humidity')) {
                    	   return this.series.name+ '<br/><span text-align=center>   <b>' +this.y+' %</b></span>';
                       }
                       else if((this.series.name == 'Load')) {
                    	   return this.series.name+ '<br/><span text-align=center>   <b>' +this.y+' tons</b></span>';
                       }
                       else if((this.series.name == 'Pressure')) {
                    	   return this.series.name+ '<br/><span text-align=center>   <b>' +this.y+' psi</b></span>';
                       }
                       else if((this.series.name == 'Flow')) {
                    	   return this.series.name+ '<br/><span text-align=center>   <b>' +this.y+' gpm</b></span>';
                       }
                       else {
                    	   return this.series.name+ '<br/><span text-align=center>   <b>' +this.y+ '</b></span>';
                       }
                     }
     	            
     	        },
        	    series: [{
        	        name: scope.typeval,
        	        data: [scope.data],
        	        
        	    }],
        	    responsive: {
  		          rules: [{
		              condition: {
		                  maxWidth: 100
		              },
		              chartOptions: {
		                  legend: {
		                      align: 'center',
		                      verticalAlign: 'bottom',
		                      layout: 'horizontal'
		                  },
		                  yAxis: {
		                      labels: {
		                          align: 'left',
		                          x: 0,
		                          y: -5
		                      },
		                      title: {
		                          text: null
		                      }
		                  },
		                  subtitle: {
		                      text: null
		                  },
		                  credits: {
		                      enabled: false
		                  }
		              }
		          }]
		      },
        	    
            exporting: {
                enabled: false
            }
        	});
        }
    };
}]);

AppModule.directive('tooltip', ['AppService', 'AppSettings', '$http','$rootScope',function(AppService, AppSettings, $http,$rootScope) {
    return {
        restrict: 'A',
        link: function(scope, element, attrs) {
            var position = attrs.tooltipPosition ? attrs.tooltipPosition : 'top';
            var maxWidth = attrs.tooltipMaxWidth ? attrs.tooltipMaxWidth : null;
            var tooltipUrl = attrs.tooltipUrl ? attrs.tooltipUrl : null;
            var trigger = attrs.trigger ? attrs.trigger : "hover";
            var tooltipContent = null;
            if(attrs.tooltipContent === undefined) {
            	attrs.tooltipContent = '';
                tooltipContent = angular.element('<div>' + attrs.tooltipContent + '</div>');
            } else {
            	tooltipContent = attrs.tooltipContent;
            }
            $(element).tooltipster({
                position: position,
                contentAsHTML:true,
                content: tooltipContent,
                maxWidth: maxWidth,
                trigger: trigger,
                functionBefore: function(instance, helper){
                	
                	 var equipmentID = instance._$origin[0].id;
                	 var postData={"site":"sdslab","serviceType":"tooltip","equipmentID":equipmentID};
                     var url = tooltipUrl;
                     AppService.postData(postData, url).then(function(response) {
                         var eventInfo = response.data.eventSeverity+","+response.data.eventMsg;
//                         for (i = 0; i < cities.length; i++) {
                        	 instance.content("<div>"+eventInfo+"</div>");
//                         }
                     });
           
                }
            });
                                
        }
    }
}]);

/*Zoom Module - DC Floorlayout Start*/
/*!
AngularJS pan/zoom v{VERSION}
@license: MIT
Github: https://github.com/mvindahl/angular-pan-zoom
*/
/* globals console */
AppModule.directive('panzoom', ['$document', 'PanZoomService',
function ($document, PanZoomService) {
           var api = {};
           var viewportHeight;
           var viewportWidth;            

           return {
               restrict: 'E',
               transclude: true,
               scope: {
                   config: '=',
                   model: '='
               },
               controller: ['$scope', '$element',
                   function ($scope, $element) {
                       var frameElement = $element;
                       var panElement = $element.find('.pan-element');
                       var zoomElement = $element.find('.zoom-element');
                       var panElementDOM = panElement.get(0);
                       var zoomElementDOM = zoomElement.get(0);
                       var animationFrame = window.requestAnimationFrame || window.mozRequestAnimationFrame;

                       var $overlay;
                       var existing = $document.find('#PanZoomOverlay');
                       
                       if (existing.length === 0) {
                           $overlay = $('<div id="PanZoomOverlay" style="position: absolute;'+
           				' top: 0; left: 0; right: 0; bottom: 0; opacity: 0; display: none;"></div>');
                           $document.find('body').append($overlay);
                       } else {
                       	$overlay = existing;
                       }
                       
                       var getCssScale = function (zoomLevel) {
                           return Math.pow($scope.config.scalePerZoomLevel, zoomLevel - $scope.config.neutralZoomLevel);
                       };

                       var getZoomLevel = function (cssScale) {
                           return Math.log(cssScale) / Math.log($scope.config.scalePerZoomLevel) + $scope.config.neutralZoomLevel;
                       };

                       // initialize models. Use passed properties when available, otherwise revert to defaults
                       // NOTE: all times specified in seconds, all distances specified in pixels                        
                       $scope.config.disableZoomAnimation = $scope.config.disableZoomAnimation !== undefined ? $scope.config.disableZoomAnimation : false;
                       $scope.config.zoomLevels = $scope.config.zoomLevels !== undefined ? $scope.config.zoomLevels : 5;
                       $scope.config.neutralZoomLevel = $scope.config.neutralZoomLevel !== undefined ? $scope.config.neutralZoomLevel : 2;
                       $scope.config.friction = $scope.config.friction !== undefined ? $scope.config.friction : 10.0;
                       $scope.config.haltSpeed = $scope.config.haltSpeed !== undefined ? $scope.config.haltSpeed : 100.0;
                       $scope.config.scalePerZoomLevel = $scope.config.scalePerZoomLevel !== undefined ? $scope.config.scalePerZoomLevel : 2;
                       $scope.config.zoomStepDuration = $scope.config.zoomStepDuration !== undefined ? $scope.config.zoomStepDuration : 0.2;
                       $scope.config.zoomToFitZoomLevelFactor =
                           $scope.config.zoomToFitZoomLevelFactor !== undefined ? $scope.config.zoomToFitZoomLevelFactor : 0.95;
                       $scope.config.zoomButtonIncrement = $scope.config.zoomButtonIncrement !== undefined ? $scope.config.zoomButtonIncrement : 1.0;
                       $scope.config.useHardwareAcceleration =
                           $scope.config.useHardwareAcceleration !== undefined ? $scope.config.useHardwareAcceleration : false;
                       
                       $scope.config.initialZoomLevel =
                           $scope.config.initialZoomLevel !== undefined ? $scope.config.initialZoomLevel : $scope.config.neutralZoomLevel;
                       $scope.config.initialPanX = $scope.config.initialPanX !== undefined ? $scope.config.initialPanX  : 0;
                       $scope.config.initialPanY = $scope.config.initialPanY || 0;
                       $scope.config.keepInBounds = $scope.config.keepInBounds ? $scope.config.keepInBounds : false;
                       if ($scope.config.keepInBounds && $scope.config.neutralZoomLevel !== 0) {
                           console.warn('You have set keepInBounds to true and neutralZoomLevel to ' + $scope.config.neutralZoomLevel +
                                        '. Be aware that the zoom level cannot below ' + $scope.config.neutralZoomLevel);
                       }
                       $scope.config.keepInBoundsRestoreForce =
                           $scope.config.keepInBoundsRestoreForce !== undefined ? $scope.config.keepInBoundsRestoreForce : 0.5;
                       $scope.config.keepInBoundsDragPullback =
                           $scope.config.keepInBoundsDragPullback !== undefined ? $scope.config.keepInBoundsDragPullback : 0.7;

                       $scope.config.zoomOnDoubleClick = $scope.config.zoomOnDoubleClick !== undefined ? $scope.config.zoomOnDoubleClick : true;
                       $scope.config.zoomOnMouseWheel = $scope.config.zoomOnMouseWheel !== undefined ? $scope.config.zoomOnMouseWheel : true;
                       $scope.config.panOnClickDrag = $scope.config.panOnClickDrag !== undefined ? $scope.config.panOnClickDrag : true;

                       $scope.config.invertMouseWheel = $scope.config.invertMouseWheel !== undefined ? $scope.config.invertMouseWheel : false;

                       $scope.config.chromeUseTransform = $scope.config.chromeUseTransform ? $scope.config.chromeUseTransform : false;


                       var calcZoomToFit = function (rect) {
                           // let (W, H) denote the size of the viewport
                           // let (w, h) denote the size of the rectangle to zoom to
                           // then we must CSS scale by the min of W/w and H/h in order to just fit the rectangle

                           var W = $element.width();
                           var H = $element.height();
                           var w = rect.width;
                           var h = rect.height;

                           var cssScaleExact = Math.min(W / w, H / h);
                           var zoomLevelExact = getZoomLevel(cssScaleExact);
                           var zoomLevel = zoomLevelExact * $scope.config.zoomToFitZoomLevelFactor;
                           var cssScale = getCssScale(zoomLevel);

                           return {
                               zoomLevel: zoomLevel,
                               pan: {
                                   x: -rect.x * cssScale + (W - w * cssScale) / 2,
                                   y: -rect.y * cssScale + (H - h * cssScale) / 2
                               }
                           };
                       };

                       if ($scope.config.initialZoomToFit) {
                           $scope.base = calcZoomToFit($scope.config.initialZoomToFit);
                       } else {
                           $scope.base = {
                               zoomLevel: $scope.config.initialZoomLevel,
                               pan: {
                                   x: $scope.config.initialPanX,
                                   y: $scope.config.initialPanY
                               }
                           };
                       }

                       $scope.model.zoomLevel = $scope.base.zoomLevel;
                       //Only true if panning has actually taken place, not just after mousedown
                       $scope.model.isPanning = false; 
                       $scope.model.pan = {
                           x: $scope.base.pan.x,
                           y: $scope.base.pan.y
                       };


                       // FIXME why declare these on $scope? They could be private vars
                       $scope.previousPosition = undefined;
                       $scope.dragging = false;
                       $scope.panVelocity = undefined;
                       $scope.zoomAnimation = undefined;

                       // private
                       
                       var syncModelToDOM = function () {
                           if ($scope.zoomAnimation) {
                               $scope.model.zoomLevel = $scope.base.zoomLevel + $scope.zoomAnimation.deltaZoomLevel * $scope.zoomAnimation.progress;
                               var deltaT = $scope.zoomAnimation.translationFromZoom($scope.model.zoomLevel);
                               $scope.model.pan.x = $scope.base.pan.x + deltaT.x;
                               $scope.model.pan.y = $scope.base.pan.y + deltaT.y;
                               
                               if ($scope.config.keepInBounds) {
                                   var topLeftCornerView = getViewPosition({ x: 0, y: 0 });
                                   var bottomRightCornerView = getViewPosition({ x: viewportWidth, y: viewportHeight });
       
                                   if (topLeftCornerView.x > 0) {
                                       $scope.model.pan.x = 0;
                                   }

                                   if (topLeftCornerView.y > 0) {
                                       $scope.model.pan.y = 0;
                                   }

                                   if (bottomRightCornerView.x < viewportWidth) {
                                       $scope.model.pan.x -= (bottomRightCornerView.x - viewportWidth);
                                   }

                                   if (bottomRightCornerView.y < viewportHeight) {
                                       $scope.model.pan.y -= (bottomRightCornerView.y - viewportHeight);
                                   }
                               }
                               
                           } else {
                               $scope.model.zoomLevel = $scope.base.zoomLevel;
                               $scope.model.pan.x = $scope.base.pan.x;
                               $scope.model.pan.y = $scope.base.pan.y;
                           }

                           var scale = getCssScale($scope.model.zoomLevel);
                           
                           var scaleString = 'scale(' + scale + ')';
                           
                           if (navigator.userAgent.indexOf('Chrome') !== -1) {
                               // For Chrome, use the zoom style by default, as it doesn't handle nested SVG very well
                               // when using transform
                               if( $scope.config.chromeUseTransform ) {
                                   // IE > 9.0
                                   zoomElementDOM.style.transformOrigin = '0 0';
                                   zoomElementDOM.style.transform = scaleString;
                               } else {
                                   // http://caniuse.com/#search=zoom
                                   zoomElementDOM.style.zoom = scale;
                               }

                           } else {
                               // Special handling of IE, as it doesn't support the zoom style
                               // http://caniuse.com/#search=transform

                               // IE 9.0
                               zoomElementDOM.style.msTransformOrigin = '0 0';
                               zoomElementDOM.style.msTransform = scaleString;

                               // IE > 9.0
                               zoomElementDOM.style.transformOrigin = '0 0';
                               zoomElementDOM.style.transform = scaleString;

                               // Safari etc..
                               zoomElementDOM.style.webkitTransformOrigin = '0 0';
                               zoomElementDOM.style.webkitTransform = scaleString;
                           }

                           if ($scope.config.useHardwareAcceleration) {
                               var translate = 'translate3d(' + $scope.model.pan.x + 'px, ' + $scope.model.pan.y + 'px, 0)';
                               
                               panElementDOM.style.transform = translate;
                               panElementDOM.style.msTransform = translate;
                               panElementDOM.style.webkitTransform = translate;  
                               panElementDOM.style.mozTransform = translate;
                           } else {
                               panElementDOM.style.left = $scope.model.pan.x + 'px';
                               panElementDOM.style.top = $scope.model.pan.y + 'px';    
                           }
                       };

                       var getCenterPoint = function () {
                           var center = {
                               x: frameElement.width() / 2,
                               y: frameElement.height() / 2
                           };
                           return center;
                       };

                       var changeZoomLevel = function (newZoomLevel, clickPoint, duration) {
                           // cancel any existing zoom animation
                           if ($scope.zoomAnimation) {
                               $scope.base.zoomLevel = $scope.model.zoomLevel;
                               $scope.base.pan.x = $scope.model.pan.x;
                               $scope.base.pan.y = $scope.model.pan.y;

                               $scope.zoomAnimation = undefined;
                           }

                           // keep zoom level in bounds
                           var minimumAllowedZoomLevel = $scope.config.keepInBounds ? $scope.config.neutralZoomLevel : 0;
                           newZoomLevel = Math.max(minimumAllowedZoomLevel, newZoomLevel);
                           newZoomLevel = Math.min($scope.config.zoomLevels - 1, newZoomLevel);

                           var deltaZoomLevel = newZoomLevel - $scope.base.zoomLevel;
                           if (!deltaZoomLevel) {
                               return;
                           }

                           duration = duration || $scope.config.zoomStepDuration;

                           //
                           // Let p be the vector to the clicked point in view coords and let p' be the same point in model coords. Let s be a scale factor
                           // and let t be a translation vector. Let the transformation be defined as:
                           //
                           //  p' = p * s + t
                           //
                           // And conversely:
                           //
                           //  p = (1/s)(p' - t)
                           //
                           // Now use subscription 0 to denote the value before transform and zoom and let 1 denote the value after transform. Scale
                           // changes from s0 to s1. Translation changes from t0 to t1. But keep p and p' fixed so that the view coordinate p' still
                           // corresponds to the model coordinate p. This can be expressed as an equation relying upon solely upon p', s0, s1, t0, and t1:
                           //
                           //  (1/s0)(p - t0) = (1/s1)(p - t1)
                           //
                           // Every variable but t1 is known, thus it is easily isolated to:
                           //
                           //  t1 = p' - (s1/s0)*(p' - t0)
                           //

                           var pmark = clickPoint || getCenterPoint();

                           var s0 = getCssScale($scope.base.zoomLevel);
                           var t0 = {
                               x: $scope.base.pan.x,
                               y: $scope.base.pan.y
                           };

                           var translationFromZoom = function (zoomLevel) {
                               var s1 = getCssScale(zoomLevel);
                               var t1 = {
                                   x: pmark.x - (s1 / s0) * (pmark.x - t0.x),
                                   y: pmark.y - (s1 / s0) * (pmark.y - t0.y)
                               };

                               return {
                                   x: t1.x - t0.x,
                                   y: t1.y - t0.y
                               };
                           };

                           // now rewind to the start of the anim and let it run its course
                           $scope.zoomAnimation = {
                               deltaZoomLevel: deltaZoomLevel,
                               translationFromZoom: translationFromZoom,
                               duration: duration,
                               //If zoom animation disabled set progress to finish and run normal animation loop
                               progress: $scope.config.disableZoomAnimation ? 1.0 : 0.0 
                           };
                       };

                       var zoomIn = function (clickPoint) {
                           changeZoomLevel(
                               $scope.base.zoomLevel + $scope.config.zoomButtonIncrement,
                               clickPoint);
                       };

                       var zoomOut = function (clickPoint) {
                           changeZoomLevel(
                               $scope.base.zoomLevel - $scope.config.zoomButtonIncrement,
                               clickPoint);
                       };

                       var getViewPosition = function (modelPosition) {
                           //  p' = p * s + t
                           var p = modelPosition;
                           var s = getCssScale($scope.base.zoomLevel);
                           var t = $scope.base.pan;

                           if ($scope.zoomAnimation) {
                               s = getCssScale($scope.base.zoomLevel + $scope.zoomAnimation.deltaZoomLevel * $scope.zoomAnimation.progress);
                               var deltaT = $scope.zoomAnimation.translationFromZoom($scope.model.zoomLevel);
                               t = { x: $scope.base.pan.x + deltaT.x, y: $scope.base.pan.y + deltaT.y };
                           }

                           return {
                               x: p.x * s + t.x,
                               y: p.y * s + t.y
                           };
                       };

                       var getModelPosition = function (viewPosition) {
                           //  p = (1/s)(p' - t)
                           var pmark = viewPosition;
                           var s = getCssScale($scope.base.zoomLevel);
                           var t = $scope.base.pan;

                           return {
                               x: (1 / s) * (pmark.x - t.x),
                               y: (1 / s) * (pmark.y - t.y)
                           };
                       };

                       var zoomToFit = function (rectangle) {
                           // example rectangle: { "x": 0, "y": 100, "width": 100, "height": 100 }
                           $scope.base = calcZoomToFit(rectangle);
                           syncModelToDOM();
                       };

                       var length = function (vector2d) {
                           return Math.sqrt(vector2d.x * vector2d.x + vector2d.y * vector2d.y);
                       };

                       var scopeIsDestroyed = false;
                       var AnimationTick = function () {
                           var lastTick = null;

                           return function () {
                               var now = jQuery.now();
                               var deltaTime = lastTick ? (now - lastTick) / 1000 : 0;
                               lastTick = now;
                               
                               if ($scope.zoomAnimation) {
                                   $scope.zoomAnimation.progress += deltaTime / $scope.zoomAnimation.duration;
                                   
                                   if ($scope.zoomAnimation.progress >= 1.0) {
                                       $scope.zoomAnimation.progress = 1.0;

                                       syncModelToDOM();

                                       $scope.base.zoomLevel = $scope.model.zoomLevel;
                                       $scope.base.pan.x = $scope.model.pan.x;
                                       $scope.base.pan.y = $scope.model.pan.y;

                                       $scope.zoomAnimation = undefined;

                                       if ($scope.config.modelChangedCallback) {                                        
                                           $scope.config.modelChangedCallback($scope.model);
                                       }
                                   }
                               }

                               if ($scope.panVelocity && !$scope.dragging) {
                                   // prevent overshooting if delta time is large for some reason. We apply the simple solution of
                                   // slicing delta time into smaller pieces and applying each one
                                   while (deltaTime > 0) {
                                       var dTime = Math.min(0.02, deltaTime);
                                       deltaTime -= dTime;

                                       $scope.base.pan.x += $scope.panVelocity.x * dTime;
                                       $scope.panVelocity.x *= (1 - $scope.config.friction * dTime);

                                       $scope.base.pan.y += $scope.panVelocity.y * dTime;
                                       $scope.panVelocity.y *= (1 - $scope.config.friction * dTime);

                                       var speed = length($scope.panVelocity);
                                       if (speed < $scope.config.haltSpeed) {
                                           $scope.panVelocity = undefined;

                                           if ($scope.config.modelChangedCallback) {                                        
                                               $scope.config.modelChangedCallback($scope.model);
                                           }

                                           break;
                                       }
                                   }
                               }
                               
                               if ($scope.config.keepInBounds && !$scope.dragging) {
                                   var topLeftCornerView = getViewPosition({ x: 0, y: 0 });
                                   var bottomRightCornerView = getViewPosition({ x: viewportWidth, y: viewportHeight });
       
                                   if (topLeftCornerView.x > 0) {
                                       $scope.base.pan.x -= $scope.config.keepInBoundsRestoreForce * topLeftCornerView.x;
                                   }

                                   if (topLeftCornerView.y > 0) {
                                       $scope.base.pan.y -= $scope.config.keepInBoundsRestoreForce * topLeftCornerView.y;
                                   }

                                   if (bottomRightCornerView.x < viewportWidth) {
                                       $scope.base.pan.x -= $scope.config.keepInBoundsRestoreForce * (bottomRightCornerView.x - viewportWidth);
                                   }

                                   if (bottomRightCornerView.y < viewportHeight) {
                                       $scope.base.pan.y -= $scope.config.keepInBoundsRestoreForce * (bottomRightCornerView.y - viewportHeight);
                                   }
                               }

                               syncModelToDOM();

                               if (animationFrame && !scopeIsDestroyed) {
                                   animationFrame(tick); //If we're using requestAnimationFrame reschedule 
                               } 

                               return !scopeIsDestroyed; // kill the tick for good if the directive goes off the page
                           };
                       };

                       syncModelToDOM();

                       var tick = new AnimationTick();
                       if (animationFrame) {
                           animationFrame(tick);
                       } else {
                           jQuery.fx.timer(tick);    
                       }

                       $scope.$on('$destroy', function () {
                           PanZoomService.unregisterAPI($scope.elementId);
                           scopeIsDestroyed = true;
                       });
                       // event handlers

                       $scope.onDblClick = function ($event) {
                           if ($scope.config.zoomOnDoubleClick) {
                               var clickPoint = {
                                   x: $event.pageX - frameElement.offset().left,
                                   y: $event.pageY - frameElement.offset().top
                               };
                               zoomIn(clickPoint);
                           }
                       };

                       var lastMouseEventTime;
                       var previousPosition;

                       $scope.onTouchStart = function($event) {
                           $event.preventDefault();

                           if ($event.originalEvent.touches.length === 1) {
                               // single touch, get ready for panning

                               // Touch events does not have pageX and pageY, make touchstart
                               // emulate a regular click event to re-use mousedown handler
                               $event.pageX = $event.originalEvent.touches[0].pageX;
                               $event.pageY = $event.originalEvent.touches[0].pageY;
                               $scope.onMousedown($event);
                           } else {
                               // multiple touches, get ready for zooming

                               // Calculate x and y distance between touch events
                               var x = $event.originalEvent.touches[0].pageX - $event.originalEvent.touches[1].pageX;
                               var y = $event.originalEvent.touches[0].pageY - $event.originalEvent.touches[1].pageY;

                               // Calculate length between touch points with pythagoras
                               // There is no reason to use Math.pow and Math.sqrt as we
                               // only want a relative length and not the exact one.
                               previousPosition = {
                                   length: x * x + y * y
                               };
                           }
                       };
                       
                       
                       $scope.onTouchMove = function($event) {
                       	$event.preventDefault();

                           if ($event.originalEvent.touches.length === 1) {
                               // single touch, emulate mouse move
                               $event.pageX = $event.originalEvent.touches[0].pageX;
                               $event.pageY = $event.originalEvent.touches[0].pageY;
                               $scope.onMousemove($event);
                           } else {
                               // multiple touches, zoom in/out

                               // Calculate x and y distance between touch events
                               var x = $event.originalEvent.touches[0].pageX - $event.originalEvent.touches[1].pageX;
                               var y = $event.originalEvent.touches[0].pageY - $event.originalEvent.touches[1].pageY;
                               // Calculate length between touch points with pythagoras
                               // There is no reason to use Math.pow and Math.sqrt as we
                               // only want a relative length and not the exact one.
                               var length = x * x + y * y;

                               // Calculate delta between current position and last position
                               var delta = length - previousPosition.length;

                               // Naive hysteresis
                               if (Math.abs(delta) < 100) {
                                   return;
                               }

                               // Calculate center between touch points
                               var centerX = $event.originalEvent.touches[1].pageX + x / 2;
                               var centerY = $event.originalEvent.touches[1].pageY + y / 2;

                               // Calculate zoom center
                               var clickPoint = {
                                   x: centerX - frameElement.offset().left,
                                   y: centerY - frameElement.offset().top
                               };

                               changeZoomLevel($scope.base.zoomLevel + delta * 0.0001, clickPoint);

                               // Update length for next move event
                               previousPosition = {
                                   length: length
                               };
                           }
                       };

                       $scope.onTouchEnd = function($event) {
                           $scope.onMouseup($event);
                       };

                       $scope.onMousedown = function ($event) {
                           if ($scope.config.panOnClickDrag) {
                               previousPosition = {
                                   x: $event.pageX,
                                   y: $event.pageY
                               };
                               lastMouseEventTime = jQuery.now();
                               $scope.dragging = true;
                               $scope.model.isPanning = false;
                               $document.on('mousemove', $scope.onMousemove);
                               $document.on('mouseup', $scope.onMouseup);	
                               $document.on('touchend', $scope.onTouchEnd);
                               $document.on('touchmove', $scope.onTouchMove);
                           }
                           
                           return false;
                       };
                       var pan = function (delta) {
                           delta.x = delta.x || 0;
                           delta.y = delta.y || 0;
                           $scope.base.pan.x += delta.x;
                           $scope.base.pan.y += delta.y;

                           syncModelToDOM();
                       };

                       $scope.onMousemove = function ($event) {
                   		$event.preventDefault();
                   		$event.stopPropagation();
                       	
                           var now = jQuery.now();
                           var timeSinceLastMouseEvent = (now - lastMouseEventTime) / 1000;
                           $scope.hasPanned = true;
                           lastMouseEventTime = now;
                           var dragDelta = {
                               x: $event.pageX - previousPosition.x,
                               y: $event.pageY - previousPosition.y
                           };
                           
                           if ($scope.config.keepInBounds) {
                               var topLeftCornerView = getViewPosition({ x: 0, y: 0 });
                               var bottomRightCornerView = getViewPosition({ x: viewportWidth, y: viewportHeight });
   
                               if (topLeftCornerView.x > 0 && dragDelta.x > 0) {
                                   dragDelta.x *= Math.min(Math.pow(topLeftCornerView.x, -$scope.config.keepInBoundsDragPullback), 1);
                               }

                               if (topLeftCornerView.y > 0 && dragDelta.y > 0) {
                                   dragDelta.y *= Math.min(Math.pow(topLeftCornerView.y, -$scope.config.keepInBoundsDragPullback), 1);
                               }

                               if (bottomRightCornerView.x < viewportWidth && dragDelta.x < 0) {
                                    dragDelta.x *= Math.min(Math.pow(viewportWidth - bottomRightCornerView.x, -$scope.config.keepInBoundsDragPullback), 1);
                               }

                               if (bottomRightCornerView.y < viewportHeight && dragDelta.y < 0) {
                                    dragDelta.y *= Math.min(Math.pow(viewportHeight - bottomRightCornerView.y, -$scope.config.keepInBoundsDragPullback), 1);
                               }
                           }
                           
                           pan(dragDelta);
                           
                           if (!$scope.model.isPanning) {
                           	/*This will improve the performance, 
                           	 *because the browser stops evaluating hits against the elements displayed inside the pan zoom view.
                           	 *Besides this, mouse events will not be sent to any other elements, 
                           	 *this prevents issues like selecting elements while dragging. */
                               $overlay.css('display', 'block');
                           }
                           
                           $scope.model.isPanning = true;
                           

                           // set these for the animation slow down once drag stops
                           $scope.panVelocity = {
                               x: dragDelta.x / timeSinceLastMouseEvent,
                               y: dragDelta.y / timeSinceLastMouseEvent
                           };

                           previousPosition = {
                               x: $event.pageX,
                               y: $event.pageY
                           };
                       };

                       $scope.onMouseup = function () {
                           var now = jQuery.now();
                           var timeSinceLastMouseEvent = (now - lastMouseEventTime) / 1000;

                           if ($scope.panVelocity) {
                               // apply strong initial dampening if the mouse up occured much later than
                               // the last mouse move, indicating that the mouse hasn't moved recently
                               // TBD experiment with this formula
                               var initialMultiplier = Math.max(0, Math.pow(timeSinceLastMouseEvent + 1, -4) - 0.2);

                               $scope.panVelocity.x *= initialMultiplier;
                               $scope.panVelocity.y *= initialMultiplier;
                           }

                           $scope.dragging = false;
                           $scope.model.isPanning = false;

                           $document.off('mousemove', $scope.onMousemove);
                           $document.off('mouseup', $scope.onMouseup);	
                           $document.off('touchend', $scope.onTouchEnd);
                           $document.off('touchmove', $scope.onTouchMove);
                           
                           //Set the overlay to noneblocking again:
                           $overlay.css('display', 'none');
                       };

                       $scope.onMouseleave = function () {
                           $scope.onMouseup(); // same behaviour
                       };

                       $scope.onMouseWheel = function ($event, $delta, $deltaX, $deltaY) {
                           if ($scope.config.zoomOnMouseWheel) {
                               $event.preventDefault();

                               if ($scope.zoomAnimation) {
                                   return; // already zooming
                               }

                               var sign = $deltaY / Math.abs($deltaY);

                               if ($scope.config.invertMouseWheel) {
                                   sign = -sign;
                               }

                               var clickPoint = {
                                   x: $event.originalEvent.pageX - frameElement.offset().left,
                                   y: $event.originalEvent.pageY - frameElement.offset().top
                               };

                               if (sign < 0) {
                                   zoomIn(clickPoint);
                               } else if (sign > 0) {
                                   zoomOut(clickPoint);
                               }
                           }
                       };
                    	
                       // create public API
                       api = {
                           model: $scope.model,
                           config: $scope.config,
                           changeZoomLevel: changeZoomLevel,
                           zoomIn: zoomIn,
                           zoomOut: zoomOut,
                           zoomToFit: zoomToFit,
                           getViewPosition: getViewPosition,
                           getModelPosition: getModelPosition
                       };

       }],
               link: function (scope, element, attrs) {
                   scope.elementId = attrs.id;

                   viewportHeight = element.find('.zoom-element').children().height();
                   viewportWidth = element.find('.zoom-element').children().width();

                   if (scope.elementId) {
                       PanZoomService.registerAPI(scope.elementId, api);
                   }
                   
                   element.on('touchstart', function(e) {
                   	scope.onTouchStart(e);
                   });
               },
               template: '<div class="pan-zoom-frame" ng-dblclick="onDblClick($event)" ng-mousedown="onMousedown($event)"' +
                   ' msd-wheel="onMouseWheel($event, $delta, $deltaX, $deltaY)"' +
                   ' style="position:relative;overflow:hidden;cursor:pointer">' +
                   '<div class="pan-element">' +                                    /* add code her to move the image */
                   '<div class="zoom-element" ng-transclude>' +
                   '</div>' +
                   '</div>' +
                   '</div>',
               replace: true
           };
   }]);


AppModule.directive('panzoomwidget', ['$document', 'PanZoomService',
function ($document, PanZoomService) {
  var panzoomId;

  return {
    restrict: 'E',
    transclude: true,
    compile: function compile(/*tElement, tAttrs, transclude*/) {
      return {
        pre: function preLink(/*scope, iElement, iAttrs, controller*/) { },
        post: function postLink(scope, iElement, iAttrs /*, controller*/) {
          // we pick the value ourselves at this point, before the controller is instantiated,
          // instead of passing it as a scope variable. This is to not force people to type quotes
          // around the string.
          // Note: we need to use iAttrs and not directly get the attribute on the element to
          // be sure to get the interpolated value ({{foo}})
          panzoomId = iAttrs.panzoomId;

          if (!panzoomId) {
            throw 'Error in setup. You must define attribute panzoom-id on the <panzoomwidget> element in order to link it to the ' +
            'id of the <panzoom> element. Ref: ';
          }
          PanZoomService.getAPI(panzoomId).then(function (api) {
            scope.model = api.model;
            scope.config = api.config;

            var zoomSliderWidget = iElement.find('.zoom-slider-widget');
            var isDragging = false;

            var sliderWidgetTopFromZoomLevel = function (zoomLevel) {
              return ((scope.config.zoomLevels - zoomLevel - 1) * scope.widgetConfig.zoomLevelHeight);
            };

            var zoomLevelFromSliderWidgetTop = function (sliderWidgetTop) {
              return scope.config.zoomLevels - 1 - sliderWidgetTop / scope.widgetConfig.zoomLevelHeight;
            };

            var getZoomLevelForMousePoint = function ($event) {
              var sliderWidgetTop = $event.pageY - iElement.find('.zoom-slider').offset().top - scope.widgetConfig.zoomLevelHeight / 2;
              return zoomLevelFromSliderWidgetTop(sliderWidgetTop);
            };

            scope.getZoomLevels = function () {
              var zoomLevels = [];
              for (var i = scope.config.zoomLevels - 1; i >= 0; i--) {
                zoomLevels.push(i);
              }
              return zoomLevels;
            };

            scope.widgetConfig = {
              zoomLevelHeight: 10
            };

            scope.zoomIn = function () {
              api.zoomIn();
            };

            scope.zoomOut = function () {
              api.zoomOut();
            };

            scope.onClick = function ($event) {
              var zoomLevel = getZoomLevelForMousePoint($event);
              api.changeZoomLevel(zoomLevel);
            };

            scope.onMousedown = function () {
              isDragging = true;

              $document.on('mousemove', scope.onMousemove);
              $document.on('mouseup', scope.onMouseup);
            };

            scope.onMousemove = function ($event) {
              $event.preventDefault();
              var zoomLevel = getZoomLevelForMousePoint($event);
              api.changeZoomLevel(zoomLevel);
            };

            scope.onMouseup = function () {
              isDragging = false;

              $document.off('mousemove', scope.onMousemove);
              $document.off('mouseup', scope.onMouseup);
            };

            scope.onMouseleave = function () {
              isDragging = false;
            };

            // $watch is not fast enough so we set up our own polling
            setInterval(function () {
              zoomSliderWidget.css('top', sliderWidgetTopFromZoomLevel(scope.model.zoomLevel) + 'px');
            }, 25);
          });
        }
      };
    },
    template: '<div class="panzoomwidget" style="margin-left: -23px;">' +
    '<div ng-click="zoomIn()" ng-mouseenter="zoomToLevelIfDragging(config.zoomLevels - 1)" class="glyphicon glyphicon-plus" aria-hidden="true" style="color:#3c8dbc;cursor: pointer;"></div>' +
    '<div class="zoom-slider" ng-mousedown="onMousedown()" ' +
    'ng-click="onClick($event)">' +
    '<div class="zoom-slider-widget" ng-style="{\'height\': widgetConfig.zoomLevelHeight - 2 +\'px\'}"></div>' +
    '<div ng-repeat="zoomLevel in getZoomLevels()" ' +
    ' class="zoom-level zoom-level-{{zoomLevel}}" ng-style="{\'height\': widgetConfig.zoomLevelHeight +\'px\'}"></div>' +
    '</div>' +
    '<div ng-click="zoomOut()" ng-mouseenter="zoomToLevelIfDragging(0)" class="glyphicon glyphicon-minus" aria-hidden="true" style="color:#3c8dbc;cursor:pointer"></div>' +
    '<div ng-transclude></div>' +
    '</div>' ,
    replace: true
  };
}]);


/*Zoom Module - DC Floorlayout Ends*/

/*   directive of user Profile   ------------------------------   */

AppModule.directive('userProfileModal', function () {
    return {
    	templateUrl :'assets/app/views/userProfile.html' ,
      restrict: 'E',
      transclude: true,
      replace:true,
      scope:true,
      
      link: function postLink(scope, element, attrs) {
        scope.header = attrs.header;
        


        scope.$watch(attrs.visible, function(value){
          if(value == true)
            $(element).modal('show');
          else
            $(element).modal('hide');
        });

        $(element).on('shown.bs.modal', function(){
          scope.$apply(function(){
            scope.$parent[attrs.visible] = true;
          });
        });

        $(element).on('hidden.bs.modal', function(){
          scope.$apply(function(){
            scope.$parent[attrs.visible] = false;
          });
        });
      }
    };
  });


/*   end of directive of user Profile   ------------------------------   */

/*   directive of site Profile   ------------------------------   */

AppModule.directive('siteProfile', function () {
    return {
      templateUrl : 'assets/app/views/siteProfile.html',
      restrict: 'E',
      transclude: true,
      replace:true,
      scope:true,
      link: function postLink(scope, element, attrs) {
        scope.header = attrs.header;

        scope.$watch(attrs.visible, function(value){
          if(value == true)
            $(element).modal('show');
          else
            $(element).modal('hide');
        });

        $(element).on('shown.bs.modal', function(){
          scope.$apply(function(){
            scope.$parent[attrs.visible] = true;
          });
        });

        $(element).on('hidden.bs.modal', function(){
          scope.$apply(function(){
            scope.$parent[attrs.visible] = false;
          });
        });
      }
    };
  });


/*  end of  directive of site Profile   ------------------------------   */


/*--------------------------directive for image upload starts here----------------------------------------------*/

AppModule.directive('fileModel', ['$parse', function ($parse) {
    return {
        restrict: 'A',
        
        link: function(scope, element, attrs) {
            var model = $parse(attrs.fileModel);
            var modelSetter = model.assign;
                   
            element.bind('change', function(){
                scope.$apply(function(){
                    modelSetter(scope, element[0].files[0]);
                });
            });
            document.getElementById("uploadBtn").onchange = function () {
            document.getElementById("uploadFile").value = this.value.replace(/^.*[\\\/]/, '')
            }
        }
    };
    
}]);

/*------------------------------directive for image upload ends here----------------------------------------------*/



/*-------------------------------------------directive for drag and drop upload starts here----------------------------------*/



/*AppModule.directive('fileDropzone', function() {
    return {
      restrict: 'A',
      scope: {
        file: '=',
        fileName: '='
      },
      link: function(scope, element, attrs) {
        var checkSize,
            isTypeValid,
            processDragOverOrEnter,
            validMimeTypes;
        
        processDragOverOrEnter = function (event) {
          if (event != null) {
            event.preventDefault();
          }
          event.dataTransfer.effectAllowed = 'copy';
          return false;
        };
        
        validMimeTypes = attrs.fileDropzone;
        
        checkSize = function(size) {
          var _ref;
          if (((_ref = attrs.maxFileSize) === (void 0) || _ref === '') || (size / 1024) / 1024 < attrs.maxFileSize) {
            return true;
          } else {
            alert("File must be smaller than " + attrs.maxFileSize + " MB");
            return false;
          }
        };

        isTypeValid = function(type) {
          if ((validMimeTypes === (void 0) || validMimeTypes === '') || validMimeTypes.indexOf(type) > -1) {
            return true;
          } else {
            alert("Invalid file type.  File must be one of following types " + validMimeTypes);
            return false;
          }
        };
        
        element.bind('dragover', processDragOverOrEnter);
        element.bind('dragenter', processDragOverOrEnter);

        return element.bind('drop', function(event) {
          var file, name, reader, size, type;
          if (event != null) {
            event.preventDefault();
          }
          reader = new FileReader();
          reader.onload = function(evt) {
            if (checkSize(size) && isTypeValid(type)) {
              return scope.$apply(function() {
                scope.file = evt.target.result;
                if (angular.isString(scope.fileName)) {
                  return scope.fileName = name;
                }
              });
            }
          };
          file = event.dataTransfer.files[0];
          name = file.name;
          type = file.type;
          size = file.size;
          reader.readAsDataURL(file);
          return false;
        });
      }
    };
  });*/



AppModule.directive("fileread", [function () {
    return {
        scope: {
            fileread: "="
        },
        link: function (scope, element, attributes) {
            element.bind("change", function (changeEvent) {
                var reader = new FileReader();
                reader.onload = function (loadEvent) {
                    scope.$apply(function () {
                        scope.fileread = loadEvent.target.result;
                    });
                }
                reader.readAsDataURL(changeEvent.target.files[0]);
            });
        }
    }
}]);








/*-------------------------------------------directive for drag and drop upload ends here----------------------------------*/





/*   directive of change password   ------------------------------   */

AppModule.directive('changePasswordModal', function () {
    return {
    	templateUrl :'assets/app/views/ChangePassword.html' ,
      restrict: 'E',
      transclude: true,
      replace:true,
      scope:true,
      
      link: function postLink(scope, element, attrs) {
        scope.header = attrs.header;
        


        scope.$watch(attrs.visible, function(value){
          if(value == true)
            $(element).modal('show');
          else
            $(element).modal('hide');
        });

        $(element).on('shown.bs.modal', function(){
          scope.$apply(function(){
            scope.$parent[attrs.visible] = true;
          });
        });

        $(element).on('hidden.bs.modal', function(){
          scope.$apply(function(){
            scope.$parent[attrs.visible] = false;
          });
        });
      }
    };
  });

AppModule.directive("matchPassword", function () {
 	return {
	require: "ngModel",
	scope: {
	otherModelValue: "=matchPassword"
 },
 	link: function(scope, element, attributes, ngModel) {
 	ngModel.$validators.matchPassword = function(modelValue) {
 	return modelValue == scope.otherModelValue;
};
scope.$watch("otherModelValue", function() {
 	ngModel.$validate();
});
}
};
});


/*   end of directive of change password   ------------------------------   */

/*   directive of forgot password   -------------------------------------   */

AppModule.directive('forgotPasswordModal', function () {
    return {
    	templateUrl :'assets/app/views/ForgotPassword.html' ,
      restrict: 'E',
      transclude: true,
      replace:true,
      scope:true,
      
      link: function postLink(scope, element, attrs) {
        scope.title = attrs.title;
        


        scope.$watch(attrs.visible, function(value){
          if(value == true)
            $(element).modal('show');
          else
            $(element).modal('hide');
        });

        $(element).on('shown.bs.modal', function(){
          scope.$apply(function(){
            scope.$parent[attrs.visible] = true;
          });
        });

        $(element).on('hidden.bs.modal', function(){
          scope.$apply(function(){
            scope.$parent[attrs.visible] = false;
          });
        });
      }
    };
  });


/*   end of directive of forgot password   ------------------------------   */

/*   directive of user loggedin   ---------------------------------------   */

AppModule.directive('userLoggedinModal', function () {
    return {
    	templateUrl :'assets/app/views/UserLoggedin.html' ,
      restrict: 'E',
      transclude: true,
      replace:true,
      scope:true,
      
      link: function postLink(scope, element, attrs) {
        scope.title = attrs.title;
        


        scope.$watch(attrs.visible, function(value){
          if(value == true)
            $(element).modal('show');
          else
            $(element).modal('hide');
        });

        $(element).on('shown.bs.modal', function(){
          scope.$apply(function(){
            scope.$parent[attrs.visible] = true;
          });
        });

        $(element).on('hidden.bs.modal', function(){
          scope.$apply(function(){
            scope.$parent[attrs.visible] = false;
          });
        });
      }
    };
  });


/*   end of directive of user loggedin   --------------------------------   */

/* mute notification start ------*/
 AppModule.directive("muteNotification",["AppService","$localStorage", function (AppService,$localStorage) {
        return {
            restrict: 'E',
            replace: true,
			link: function (scope, element, attributes) {
				
			},
			/*New Html Starts*/
			template: '<div class="modal fade" id="muteNotification" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">' +
		    '<div class="modal-dialog">' +
		        '<div class="modal-content">' +
		            '<!-- Modal Header -->' +
		            '<div class="modal-header customModal1">' +
		                '<button type="button" class="close" data-dismiss="modal">' +
		                       '<span aria-hidden="true">&times;</span>' +
		                       '<span class="sr-only">Close</span>' +
		                '</button>' +
		                '<h4 class="modal-title popupTitle" id="myModalLabel">' +
		                    'Mute Notification' +
		                '</h4>' +
		            '</div>' +
		            '<!-- Modal Body -->' +
		            '<div class="modal-body">' +
		                '<form class="form-horizontal" role="form">' +
		                  '<div class="form-group">' +
		                    '<label  class="col-sm-6 control-label popupLabel" for="minpicker">Specify the duration until when you do not need Alarm Notification</label>' +
		                    '<div class="col-sm-6">' +
		                        '<span><input type="number" name="NoticationHours" min="0" max="71" step="1" ng-init="0" ng-model="NoticationHours"/><span class="hourText">Hrs</span>' +
								  '</span><span><input type="number" name="NoticationMins" min="0" max="60" step="5" ng-init="0" ng-model="NoticationMins"/><span class="minsText">Mins</span>' +
		                    '</div>' +
		                  '</div>' +
						  '<div class="form-group">' +
		                    '<label  class="col-sm-6 control-label popupLabel" for="typeradio">Mute Alert Notification for</label>' +
		                    '<div class="col-sm-6">' +
		                        '<label class="radio-inline"><input type="radio" name="notificationFor" ng-model="notificationFor" value="SMS">SMS Only</label>' +
								'<label class="radio-inline"><input type="radio" name="notificationFor" ng-model="notificationFor" value="EMail">Email Only</label>' +
								'<label class="radio-inline"><input type="radio" name="notificationFor" ng-model="notificationFor" value="All">All</label>' +
		                    '</div>' +
		                  '</div>' +
						  '<div class="form-group">' +
		                    '<label  class="col-sm-6 control-label popupLabel" for="others">Specify the reason for why the Alert Notifications are muted</label>' +
		                    '<div class="col-sm-6">' +
								'<textarea class="form-control" rows="5" id="others" style="width: 88%;" ng-model="reasonToMute"></textarea>' +
		                    '</div>' +
		                  '</div>' +
		            	  '<div class="form-group">' +
		                    '<div class="col-sm-offset-4 col-sm-8">' +
		                      '<button ng-click="muteNotify(NoticationHours,NoticationMins,notificationFor,reasonToMute)" data-dismiss="modal" class="btn btn-default btnCustom1">Mute</button>' +
		                    '</div>' +
		                  '</div>' +
		                '</form>' +
		            '</div>' +
				'</div>' +
			   '</div>' +
		    '</div>',
			/*New Html Ends*/			
			/*template: '<div class="modal fade form-box" id="muteNotification" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">' +
            '<div class="modal-dialog" role="document">'+
            '   <div class="modal-content">' +
            '  <div class="modal-header">' +
            '      <span class="heading"> <h5 class="modal-title main-heading" id="myModalLabel">MUTE NOTIFICATION</h5><span>' +
            '      <span class="closeLink"> <a data-dismiss="modal"><span aria-hidden="true">&times;</span><span>close<span></a></span>' +
            '       </div>' +
            '<div class="modal-body MuteNotify">' +   
			'<div class="col-sm-12"><div class="col-sm-5 notifyText">Specify the duration until when you do not need Alarm Notification</div>'+
			'<div class="col-sm-7"><span><input type="number" name="NoticationHours" min="0" max="71" step="1" ng-init="0" ng-model="NoticationHours"/><span class="hourText">Hrs</span>'+
			'</span><span><input type="number" name="NoticationMins" min="0" max="60" step="5" ng-init="0" ng-model="NoticationMins"/><span class="minsText">Mins</span></div></div>'+
			'<div class="col-sm-12"><div class="notifyText col-sm-5">Mute Alert Notification for</div><div class="col-sm-7"><label><input type="radio" name="notificationFor" ng-model="notificationFor" value="SMS">SMS Only</label><label><input type="radio" name="notificationFor" ng-model="notificationFor" value="EMail">Email Only</label><label><input type="radio" name="notificationFor" ng-model="notificationFor" value="All">All</label></div></div>'+
			'<div class="col-sm-12"><div class="col-sm-5 notifyText">Specify the reason why the Alert Notification are muted</div><div class="col-sm-7"><input type="textarea" ng-model="reasonToMute"/></div></div>'+
			'<div class="col-sm-12 buttons"><button class="notifyButton" ng-click="muteNotify(NoticationHours,NoticationMins,notificationFor,reasonToMute)" data-dismiss="modal">Mute</div>'+
            '       </div>' +
            '       </div>',*/            
            controller: function ($scope) {
                $scope.muteNotificationPopup = function (attrs) {
                    $('#muteNotification').modal({backdrop: 'static', keyboard: false});
					$scope.NoticationHours=0;
					$scope.NoticationMins=0;
					$scope.notificationFor='';
					$scope.reasonToMute='';
					$scope.assetId=$localStorage.assetID;
					$scope.siteId=$localStorage.siteId;
					var setMute='assetperformance/engie/service/assetperformance/setmute';
					
					$scope.muteNotify=function(NoticationHours,NoticationMins,notificationFor,reasonToMute){
						$scope.Ismute=false;
						$scope.Isunmute=true;
						//console.log($scope.assetId,NoticationHours,NoticationMins,notificationFor,reasonToMute);
						var _postData =	{
							"actionType": "SET_MUTE",
		   					"siteId":$scope.siteId,
		   					"assetId":$scope.assetId,
							"assetType": "MUTE",
							"muteType":notificationFor,
							"userEmailId":"santosh.hariharan@ust-global.com",
							"muteReason":reasonToMute,
							"Name":"Santhosh",
							"status":"MUTE",
							"hours":NoticationHours,
							"minutes":NoticationMins
		   				};
						AppService.postData(_postData,setMute).then(function(response) {
		                   if (response.status === 200 && response.data) {
							   if(response.data.responseCode=="S202"){
								   alert(response.data.responseMessage)
									$scope.Ismute=false;
									$scope.Isunmute=true;
							   }
							   else{
									$scope.Ismute=true;
									$scope.Isunmute=false;
							   }
		                	  console.log(response.data);
		                   }
		   			    })
					}
                }
            }
        }
    }]);
	AppModule.directive("unMuteNotification",["AppService","$localStorage", function (AppService,$localStorage) {
        return {
            restrict: 'E',
            replace: true,
			link: function (scope, element, attributes) {
			},
			template: '<div class="modal fade form-box" id="unMuteNotification" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">' +
            '<div class="modal-dialog" role="document">'+
            '   <div class="modal-content">' +
            '  <div class="modal-header">' +
            '      <span class="heading"> <h5 class="modal-title main-heading" id="myModalLabel">NOTIFICATION ON MUTE</h5><span>' +
            '      <span class="closeLink"> <a data-dismiss="modal"><span aria-hidden="true">&times;</span><span>close<span></a></span>' +
            '       </div>' +
            '<div class="modal-body MuteNotify">' +   
			'<div class="col-sm-12 alermText"><div class="col-sm-2"><img src="assets/assetperformance/images/iconAlarm.png" alt="mute Icon"/></div><div class="col-sm-10">Alarm Notification has been temporarily disabled for duration {{NoticationHours}}Hrs {{NoticationMins}} Mins until {{EndTime | date}}</div></div>'+
			'<div class="col-sm-12"></div>'+
			'<div class="col-sm-12"></div>'+
			'<div class="col-sm-12 buttons"><a href="javascript:void(0);" ng-click="extendMuteNotificationPopup()"> Extend mute period</a><button class="notifyButton" ng-click="unMuteNotify()" data-dismiss="modal">Unmute</div>'+
            '       </div>' +
            '       </div>',
            controller: function ($scope) {
                $scope.unMuteNotificationPopup = function (attrs) {
                    $('#unMuteNotification').modal({backdrop: 'static', keyboard: false});
					var setMute='assetperformance/engie/service/assetperformance/setmute';
					var getMuteStatus='assetperformance/engie/service/assetperformance/getmutestatus';
					$scope.assetId=$localStorage.assetID;
					$scope.siteId=$localStorage.siteId;
					var _postData =	{
							"actionType": "GET_MUTE_STATUS",
		   					"siteId":$scope.siteId,
		   					"assetId":$scope.assetId
		   				};
						//console.log(vm.assetID);
						AppService.postData(_postData,getMuteStatus).then(function(response) {
		                   if (response.status === 200 && response.data) {
							   $scope.EndTime=response.data.MuteEndTimeStamp;
							   $scope.duration=response.data.duration;
							   $scope.NoticationHours=parseInt($scope.duration/60);
							   $scope.NoticationMins=parseInt($scope.duration%60);
		                   }
		   			    })
					$scope.unMuteNotify=function(){
						var _postData =	{
								"actionType": "SET_UNMUTE",
								"siteId":$scope.siteId,
								"assetId":$scope.assetId,
								"assetType": "MUTE",
								"status":"UNMUTE"
							};
						AppService.postData(_postData,setMute).then(function(response) {
							
		                   if (response.status === 200 && response.data) {
							   if(response.data.responseCode=="S201"){
								   alert(response.data.responseMessage)
									$scope.Ismute=true;
									$scope.Isunmute=false;
							   }
							   else{
									$scope.Ismute=false;
									$scope.Isunmute=true;
							   }
		                	 
		                   }
		   			    })
					}
                }
            }
        }
    }]);
	AppModule.directive("extendMuteNotification",["AppService","$localStorage", function (AppService,$localStorage) {
        return {
            restrict: 'E',
            replace: true,
			link: function (scope, element, attributes) {
			},
			template: '<div class="modal fade form-box" id="extendMuteNotification" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">' +
            '<div class="modal-dialog" role="document">'+
            '   <div class="modal-content">' +
            '  <div class="modal-header">' +
            '      <span class="heading"> <h5 class="modal-title main-heading" id="myModalLabel">EXTEND MUTE NOTIFICATION</h5><span>' +
            '      <span class="closeLink"> <a data-dismiss="modal"><span aria-hidden="true">&times;</span><span>close<span></a></span>' +
            '       </div>' +
            '<div class="modal-body MuteNotify">' +   
			'<div class="col-sm-12"><div class="col-sm-5 notifyText">Specify the duration until when you do not need Alarm Notification</div>'+
			'<div class="col-sm-7"><span><input type="number" name="NoticationHours" min="0" max="71" step="1" placeholder="0" ng-model="ExtendNoticationHours"/><span class="hourText">Hrs</span>'+
			'</span><span><input type="number" name="NoticationMins" min="0" max="60" step="5" placeholder="0" ng-model="ExtendNoticationMins"/><span class="minsText">Mins</span></div></div>'+
			'<div class="col-sm-12"><div class="col-sm-5 notifyText">Specify the reason why the Alert Notification are muted</div><div class="col-sm-7"><input type="textarea" ng-model="reasonToMute"/></div></div>'+
			'<div class="col-sm-12 buttons"><button class="notifyButton" ng-click="extendmuteNotify(ExtendNoticationHours,ExtendNoticationMins)" data-dismiss="modal">Extend</div>'+
            '       </div>' +
            '       </div>',
            controller: function ($scope) {
                $scope.extendMuteNotificationPopup = function (attrs) {
                    $('#extendMuteNotification').modal({backdrop: 'static', keyboard: false});
					$scope.assetId=$localStorage.assetID;
					$scope.siteId=$localStorage.siteId;
					$scope.ExtendNoticationHours=0;
					$scope.ExtendNoticationMins=0;
					var extendMute='assetperformance/engie/service/assetperformance/setextendmute';
					var getMuteStatus='assetperformance/engie/service/assetperformance/getmutestatus';
					$scope.extendmuteNotify=function(ExtendNoticationHours,ExtendNoticationMins){
						//console.log(NoticationHours,NoticationMins);
						var _postData =	{
							"actionType": "SET_EXTEND_MUTE",
		   					"siteId":$scope.siteId,
		   					"assetId":$scope.assetId,
							"assetType": "MUTE",
							"userEmailId":"santosh.hariharan@ust-global.com",
							"muteReason":"Asset on maintenance",
							"Name":"Santhosh",
							"status":"MUTE",
							"hours":ExtendNoticationHours,
							"minutes":ExtendNoticationMins
		   				};
						var _postData1 =	{
							"actionType": "GET_MUTE_STATUS",
		   					"siteId":$scope.siteId,
		   					"assetId":$scope.assetId
		   				};
						//console.log(NoticationHours,NoticationMins);
						AppService.postData(_postData,extendMute).then(function(response) {
		                   if (response.status === 200 && response.data) {
							   if(response.data.responseCode=="S203"){
									$scope.Ismute=false;
									$scope.Isunmute=true;
									$scope.EndTime=response.data.MuteEndTimeStamp;
									$scope.duration=response.data.duration;
								   $scope.NoticationHours=parseInt($scope.duration/60);
								   $scope.NoticationMins=parseInt($scope.duration%60);
							   }
							   else{
									$scope.Ismute=true;
									$scope.Isunmute=false;
									alert(failed)
							   }
		                	  //console.log(response.data);
		                   }
		   			    })
					}
                }
            }
        }
    }]);
/* mute Notificaton ends here */
	
	AppModule.directive("assetDetailsPopup",["$localStorage","AppService", function ($localStorage,AppService) {
        return {
            restrict: 'E',
            replace: true,
			link: function (scope, element, attributes) {
				
			},
			template: '<div class="modal fade form-box" id="assetDetails" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">' +
            '<div class="modal-dialog" role="document">'+
            '   <div class="modal-content">' +
            '  <div class="modal-header">' +
            '      <span class="heading"> <h5 class="modal-title main-heading" id="myModalLabel">Asset Information</h5><span>' +
            '      <span class="closeLink"> <a data-dismiss="modal"><span aria-hidden="true">&times;</span><span>close<span></a></span>' +
            '       </div>' +
            '<div class="modal-body">' +   
			'<div class="col-sm-12"><div class="col-sm-6"><span class="boldText">Asset type</span> <span>: Uninterruptible Power Supply</span></div><div class="col-sm-6"><span class="boldText">Topology</span><span>: Double Conversion Online</span></div></div>'+
			'<div class="col-sm-12"><div class="col-sm-6"><span class="boldText">Equipment ID</span> <span>: {{assetId}}</span></div><div class="col-sm-6"><span class="boldText">Manufacturer</span><span>: {{assetDetails1.Manufacturer}}</span></div></div>'+
			'<div class="col-sm-12"><div class="col-sm-6"><span class="boldText">Location </span> <span>: SG-CCK-RM1</span></div><div class="col-sm-6"><span class="boldText">Model No</span><span></span>: {{assetDetails2.Model}} </div></div>'+
			'<div class="col-sm-12"><div class="col-sm-6"><span class="boldText">Design Capacity</span> <span>: 160KVA</span></div><div class="col-sm-6"><span class="boldText">Serial Number</span><span>: AS123456789 </span></div></div>'+
			'<div class="col-sm-12"><div class="col-sm-6"><span class="boldText">Configuration</span> <span>: N+1</span></div><div class="col-sm-6"><span class="boldText">Dimensions</span><span>: H 1991mm * W 1200mm *D 1070mm</span></div></div>'+
			'<div class="col-sm-12"><div class="col-sm-6"><span class="boldText">Designed Battery Runtime</span> </span>: 30 mins<span></div><div class="col-sm-6"><span class="boldText">Weight</span><span>: 1490.0 kg</span></div></div>'+
			'<div class="col-sm-12"><div class="col-sm-6"><span class="boldText">Commission Date</span> <span>: 27/06/2017</span></div><div class="col-sm-6"><span class="boldText">Category</span><span>: Electrical</span></div></div>'+
            '       </div>' +
            '       </div>',
            controller: function ($scope) {
                $scope.assetDetails = function (attrs) {
                    $('#assetDetails').modal({backdrop: 'static', keyboard: false});
					$scope.assetId=attrs;
					$scope.siteId=$localStorage.siteId;
					var assetInfo = 'assetperformance/engie/service/assetperformance/upsassetdetails?userId='+'anilkumar@engie.com'+'&siteId='+$scope.siteId+'&assetId='+'UPS%206-1-A1'+'&actionType='+'ASSETPERFORMANCE_ASSET_DETAILS';
					AppService.getData(1, assetInfo).then(function(response) {
						   if (response.status === 200 && response.data) {
							 $scope.assetInfoData = response.data;
							 console.log($scope.assetInfoData)
									$scope.assetDetails1=$scope.assetInfoData.assetInfo[0];	
									$scope.assetDetails2=$scope.assetInfoData.assetInfo[1];
							
							}
					   });	
                }
            }
        }
    }]);
	
	/*Top 5 Most frequent UPS Events*/
	
	AppModule.directive('frequentUpsEvents', ['AppService', 'AppSettings', '$http','$rootScope', function(AppService, AppSettings, $http,$rootScope){
	    return {
	        restrict: 'E',
	        template: "<div style='height: 200px;min-width: 200px; max-width: 320px;'></div>",
	        scope: {
	            title: '@',
	            data: '=',
	            categories: '='
	        },
	        link: function(scope, element, attrs) {

	        	scope.data[0].color = "#00acf9";
	        	scope.data[1].color = "#00acf9";
	        	scope.data[2].color = "#00acf9";
	        	scope.data[3].color = "#00acf9";
	        	scope.data[4].color = "#00acf9";
	        	
	        	console.log("UPS Active eVENTS: ",scope.data);
	        	
	        	for (var i = 0; i < scope.data.length; i++) {
	        		if(scope.data[i].y === 0){
	        			scope.data[i].y = 0.2;
	        		}
	        	};
	            Highcharts.chart(element[0], {
	            	chart: {
	                    type: 'bar',
	                    height: 200,
	                    width: 320,
	                    backgroundColor:'transparent'
	                },
	                legend: {
	                    enabled: true,
	        	    	layout: 'vertical',
	            		align: 'right',
	        				verticalAlign: 'middle',
	                    labelFormatter: function() {
	        				return this.name + " - <span class='total'>"+this.y+"</span>"
	                    }
	                },
	                title: {
	                    text: null
	                },
	                tooltip:{
	                	enabled : false
	                },
		
	                xAxis: {
	                    categories: scope.categories,
	                    labels: {
	                        formatter: function () {
	                        	return '<span style="fill: #666666;">' + this.value + '</span>';
	                            /*if ('Critical' === this.value) {
	                                return '<span style="fill: #E74C3C;">' + this.value + '</span>';
	                            } else if ('Warning' === this.value){
	                            	return '<span style="fill: #F4D03F;">' + this.value + '</span>';
	                            } else if('Minor' === this.value){
	                            	return '<span style="fill: grey;">' + this.value + '</span>';
	                            } else{
	                            	
	                            }*/
	                        }
	                    },
	                    allowDecimals: false,
	                    gridLineColor: 'transparent',
	                    gridLineWidth: 0,
	                    minorGridLineWidth: 0,
	                    title: { text: '' },
	                    lineWidth: 0,	
	           					lineColor: 'transparent',
	                    minorTickLength: 0,
	           					tickLength: 0
	                },
	                yAxis: {
	                    allowDecimals: false,
	                    gridLineColor: 'transparent',
	                    labels:{enabled: false},
	                    gridLineWidth: 0,
	                    minorGridLineWidth: 0,
	                 		title: { text: '' }
	                },
	                plotOptions: {
	                	 series: {
	                        events: {
	                            legendItemClick: function (x) {
	                                var i = this.index  - 1;
	                                var series = this.chart.series[0];
	                                var point = series.points[i];   

	                                if(point.oldY == undefined)
	                                   point.oldY = point.y;

	                                point.update({y: point.y != null ? null : point.oldY});
	                            }
	                        },
							dataLabels: {
								enabled: true,
								borderRadius: 0,
								inside: true,
								color: '#000',
								style: {
									textOutline: false,
									fontWeight: 'none'
				                }
							}
	                    }
	                },
	                series: [
	                    {
	                        pointWidth:25,
	                        color: ['#E74C3C', '#F4D03F', 'grey'],
	                        showInLegend:false,
	                        data: scope.data,
	                        tooltip:{
	                        	formatter:function(){
	                                 if(this.point.y === 0.2)
	                                	 return 'ON'
	                                else
	                                	return 'OFF'
	                                   
	                            },
	                            pointFormat: '{name}<br/><span text-align=center><b>{point.y}</b></span>',
	                        },
	                        tooltip: {
	            	            valueSuffix: '',
	            	            useHTML:true,
	            	            pointFormat: '{name}<br/><span text-align=center><b>{point.y}</b></span>',
	            	        }
	                    }
	                    
	                ],
	                
	                
	                  
	                lang: {
	                    noData: "No Data Found"
	                },
	                noData: {
	                    style: {
	                        fontWeight: 'bold',
	                        fontSize: '15px',
	                        color: '#303030'
	                    }
	                },
	                exporting: {
	                    enabled: false
	                }
	                
	            });
	            
	            
	        }
	    };
	}]);


