/* 
 *  ================================================================================
 *  Copyright (C) 2017
 */
AppModule.factory('ChartService', function($http, AppSettings, AppConst, $q) {

    'use strict';
    var service = {};
    
    service.stackedAreaChartbyAmChart = function(divid,data) {
    	
//    	var data=[{"day":"2017-04-25","MR":1,"CR":50,"WR":0},{"day":"2017-04-25","CR":50,"MR":10,"WR":0},{"day":"2017-04-25","CR":50,"MR":10,"WR":0},{"day":"2017-04-25","CR":50,"MR":10,"WR":0},{"day":"2017-04-25","CR":1,"MR":10,"WR":0},{"day":"2017-04-25","CR":50,"MR":10,"WR":0},{"day":"2017-04-25","CR":1,"MR":10,"WR":0},{"day":"2017-04-25","MR":1,"CR":50,"WR":0},{"day":"2017-04-25","CR":50,"MR":10,"WR":0},{"day":"2017-04-25","CR":50,"MR":10,"WR":0}];
    	var chart = AmCharts.makeChart(divid, {
    		
    	    "type": "serial",
    		"theme": "light",
//    	    "titles": [{
//    	        "text": "Total",
//    	        "size": 15
//    	    }],
//    	    "legend": {
//    	        "align": "center",
//    	        "equalWidths": false,
//    	        "periodValueText": "[[value.sum]]",
//    	        "valueAlign": "left",
//    	        "valueText": "[[value]] ([[percents]]%)",
//    	        "valueWidth": 200
//    	    },
    		/*"legend": {
    		    "horizontalGap": 0,
    		    "maxColumns": 1,
    		    "position": "bottom",
    		  
    		    "markerSize": 7,
    			"autoMargins" : true,
    		    "marginTop": 10,
    		   "position" : "absolute",
    		   "top" : 170,
    		   "left" : 150,
    		    "data": [{
    		        "title": "CRITICAL",
    		        "color": "#FF0000"
    		      }, {
    		        "title": "WARNING",
    		        "color": "#FFFF00"
    		      },  {
    		        "title": "MINOR",
    		        "color": "#D3D3D3"
    		      }]
    		     
    		  },*/
    	    "dataProvider":data,// [{
//    	        "day": "2017-04-25",
//    	        "CR": 1587,
//    	        "motorcycles": 650,
//    	        "bicycles": 121
//    	    }, {
//    	        "day": "2017-04-25",
//    	        "CR": 1567,
//    	        "motorcycles": 683,
//    	        "bicycles": 146
//    	    }, {
//    	        "day": "2017-04-25",
//    	        "CR": 1617,
//    	        "motorcycles": 691,
//    	        "bicycles": 138
//    	    }],
//    	    "valueAxes": [{
//    	        "stackType": "100%",
//    	        "gridAlpha": 0.07,
//    	        "position": "left",
//    	        "title": "percent"
//    	    }],
    	    "graphs": [{
//    	        "balloonText": "<img src='http://www.amcharts.com/lib/3/images/car.png' style='vertical-align:bottom; margin-right: 10px; width:28px; height:21px;'><span style='font-size:14px; color:#000000;'><b>[[value]]</b></span>",
    	    	"balloonText": "<style='vertical-align:bottom; margin-right: 10px; width:28px; height:21px;'><span style='font-size:10px; color:#000000;'>CRITICAL:<b>[[value]]</b></span>",
    	    	"fillAlphas": 0.5,
    	        "lineAlpha": 0.5,
    	        "title": "CR",
    	        "valueField": "CR",
    	        "fillColors":"#FF0000"
    	    }, {
//    	        "balloonText": "<img src='http://www.amcharts.com/lib/3/images/motorcycle.png' style='vertical-align:bottom; margin-right: 10px; width:28px; height:21px;'><span style='font-size:14px; color:#000000;'><b>[[value]]</b></span>",
    	    	"balloonText": "<style='vertical-align:bottom; margin-right: 10px; width:28px; height:21px;'><span style='font-size:10px; color:#000000;'>WARNING:<b>[[value]]</b></span>",
    	    	"fillAlphas": 0.5,
    	        "lineAlpha": 0.5,
    	        "title": "MR",
    	        "valueField": "MR",
    	       "fillColors":"#D3D3D3"
    	    }, {
//    	        "balloonText": "<img src='http://www.amcharts.com/lib/3/images/bicycle.png' style='vertical-align:bottom; margin-right: 10px; width:28px; height:21px;'><span style='font-size:14px; color:#000000;'><b>[[value]]</b></span>",
    	    	"balloonText": "<style='vertical-align:bottom; margin-right: 10px; width:28px; height:21px;'><span style='font-size:10px; color:#000000;'>MINOR:<b>[[value]]</b></span>",
    	    	"fillAlphas": 0.5,
    	        "lineAlpha": 0.5,
    	        "title": "WR",
    	        "valueField": "WR",
    	        "fillColors":"#FFFF00"
    	    }],
    	    "plotAreaBorderAlpha": 0,
    	    "marginLeft": 0,
    	    "marginBottom": 0,
    	    "chartCursor": {
    	        "cursorAlpha": 0,
    	        "zoomable": false
    	    },
    	    "categoryField": "day",
    	     "categoryAxis": {
    	        "startOnAxis": true,
    	        "axisColor": "#DADADA",
    	        "gridAlpha": 0.07,
    	        "labelRotation": 90
    	    },
    	    "export": {
    	    	"enabled": false
    	     }
    	});
    	
    }
    
    
    service.topMostFrequentEventsOrEquipments =  function topMostFrequentEventsOrEquipments(divid,resdata){
		Highcharts.chart(divid, {
		    chart: {
		        type: 'column'
		    },
		    title: {
		        text: null
		    },
//		    subtitle: {
//		        text: 'Source: <a href="http://en.wikipedia.org/wiki/List_of_cities_proper_by_population">Wikipedia</a>'
//		    },
		    xAxis: {
		        type: 'category',
		        labels: {
		            rotation: -45,
		            style: {
		                fontSize: '13px',
		                fontFamily: 'Verdana, sans-serif'
		            }
		        }
		    },
		    yAxis: {
		        min: 0,
		        title: {
		            text: 'Alarm Count'
		        }
		    },
		    legend: {
		        enabled: false
		    },
		    tooltip: {
		        pointFormat: 'count: <b>{point.y:.1f} </b>'
		    },
		    series: [{
		        name: 'Population',
		        data: resdata,
//		        [
//		            ['Shanghai', 23.7],
//		            ['Lagos', 16.1],
//		            ['Lima', 8.9]
//		        ],
		        dataLabels: {
		            enabled: true,
		            rotation: -90,
		            color: '#FFFFFF',
		            align: 'right',
		            format: '{point.y:.1f}', // one decimal
		            y: 10, // 10 pixels down from the top
		            style: {
		                fontSize: '13px',
		                fontFamily: 'Verdana, sans-serif'
		            }
		        }
		    }],
		    exporting: {
                enabled: false
            }
		});
    }
    
    
    service.eventsTrendByCategoryOrHistory =  function eventsTrendByCategoryOrHistory(divid,resdata){ 
		Highcharts.chart(divid, {
		    chart: {
		        type: 'column'
		    },
		    title: {
		        text: null
		    },
		    xAxis: {
		        categories: resdata.categories//['Apples', 'Oranges', 'Pears', 'Grapes', 'Bananas']
		    },
		    yAxis: {
		        min: 0,
		        title: {
		            text: 'Total Event Count'
		        },
		        labels: {
		            formatter: function() {
		               return this.value+"%";
		            }
		          }
		    },
		    tooltip: {
		        pointFormat: '<span style="color:{series.color}">{series.name}</span>: <b>{point.y}</b> ({point.percentage:.0f}%)<br/>',
		        shared: true
		    },
		    plotOptions: {
		        column: {
		            stacking: 'percent'
		        }
		    },
		    series: [{
		        name: 'CRITICAL',
		        data: resdata.CR,
		        color: '#FF0000'   //[5, 3, 4, 7, 2]
		    }, {
		        name: 'WARNING',
		        data: resdata.WR,
		        color: '#FFFF00'  //[2, 2, 3, 2, 1]
		    }, {
		        name: 'MINOR',
		        data: resdata.MR,//[3, 4, 4, 2, 5]
		        color: '#D3D3D3'
		    }],
		    exporting: {
                enabled: false
            }
		});
    }
    
    service.eventRate =function eventRate(divid,data,centersum){
		var chart = AmCharts.makeChart(divid, {
			"type": "pie",
			  "theme": "light",
			  
			  "allLabels": [{
				    "text": centersum,
				    "align": "center",
				    "bold": true,
				    "y": 73,
				    "size" : "25"
				    
				  }, {
				    "text": "",
				    "align": "center",
				    "bold": false,
				    "y": 110
				  }],
			  "dataProvider":data,// [ {
			  "titleField": "title",
			  "valueField": "value",
			  "labelRadius": -130,
			  "colorField": "color",
			  "labelColorField": "color",
			  /*"radius": "42%",*/
			  "radius": "39%",
			  "innerRadius": "60%",
//			  "depth3D": 10,
			  "labelText": "",
			  "export": {
			    "enabled": false
			  }
		
		});
	}
    
    service.rateOfAck =function rateOfAck(divid,value){
    	var chart = AmCharts.makeChart(divid, {
			  "theme": "light",
			  "type": "gauge",
			  "axes": [{
			    "topTextFontSize": 10,
			    "topTextYOffset": 39,
			    "topText": value+"mins",
			    "axisColor": "#31d6ea",
			    "axisThickness": 1,
			    "endValue": 100,
			    "gridInside": true,
			    "inside": false,
			    "radius": "50%",
			    "valueInterval": 10,
			    "tickColor": "#67b7dc",
			    "startAngle": -90,
			    "endAngle": 90,
			    "unit": "",
			    "bandOutlineAlpha": 0,
			    "bands": [{
			      "color": "#0080ff",
			      "endValue": 100,
			      "innerRadius": "105%",
			      "radius": "170%",
			      "gradientRatio": [0.5, 0, -0.5],
			      "startValue": 0
			    }, {
			      "color": "#3cd3a3",
			      "endValue": value,
			      "innerRadius": "105%",
			      "radius": "170%",
			      "gradientRatio": [0.5, 0, -0.5],
			      "startValue": 0
			    }]
			  }],
			  "arrows": [{
			    "alpha": 1,
			    "innerRadius": "15%",
			    "nailRadius": 0,
			    "value":value,
			    "radius": "154%"
			  }]
			});
	

			}
    
    return service;
  
});


