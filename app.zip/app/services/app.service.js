/* 
 *  ================================================================================
 *  Copyright (C) 2017
 */
AppModule.factory('AppService', function($http, AppSettings, AppConst, $q) {

    'use strict';
    var service = {};
    var serviceStartDateAry=[];
    
    service.saveUser = function(data) {

        var deferred, _url;
        _url = AppSettings.context + 'public/users/save'
        deferred = $http.post(_url, data).then(function(response) {

            return response;

        }, function(error) {
            var _msg;
            if (!error.data || !error.data.applicationErrors) {
                if (error.status == 404) {
                    _msg = AppConst.ERRORMESSAGES.SERDOWN;
                } else {
                    _msg = error.statusText;
                }
            } else {
                _msg = error.data.applicationErrors[0].errorMessage
            }
            //showInfo("Error", _msg, "OK");
            return error;
        });

        return deferred;
    };

    service.updateData = function(data, userId) {
      
        var deferred, _url;

        _url = AppSettings.context + 'public/users/' + userId + '/save';
        deferred = $http.put(_url, data).then(function(response) {

            return response;

        }, function(error) {
            var _msg;
            if (!error.data || !error.data.applicationErrors) {
                if (error.status == 404) {
                    _msg = AppConst.ERRORMESSAGES.SERDOWN;
                } else {
                    _msg = error.statusText;
                }
            } else {
                _msg = error.data.applicationErrors[0].errorMessage
            }
            //showInfo("Error", _msg, "OK");
            return error;
        });

        return deferred;
    };

    /**Service to do AJAX request*/
    service.getData = function(requestId,_url) {
        var deferred;
        //_url = AppSettings.context + 'survey/' + dataRequestId;
        
       
       deferred = $http.get(_url).then(function(response) {

            return response;

        }, function(error) {
            var _msg;
            if (!error.data || !error.data.applicationErrors) {
                if (error.status == 404) {
                    _msg = AppConst.ERRORMESSAGES.SERDOWN;
                } else {
                    _msg = error.statusText;
                }
            } else {
                _msg = error.data.applicationErrors[0].errorMessage
            }
            //showInfo("Error", _msg, "OK");
            return error;
        });

        return deferred;
    };
    
    service.getSitesData = function(requestId,_url) {
        var deferred;
        //_url = AppSettings.context + 'survey/' + dataRequestId;
        
       
       deferred = $http.get(_url).then(function(response) {

            return response;

        }, function(error) {
            var _msg;
            if (!error.data || !error.data.applicationErrors) {
                if (error.status == 404) {
                    _msg = AppConst.ERRORMESSAGES.SERDOWN;
                } else {
                    _msg = error.statusText;
                }
            } else {
                _msg = error.data.applicationErrors[0].errorMessage
            }
            //showInfo("Error", _msg, "OK");
            return error;
        });

        return deferred;
    };
    
    
    service.postData = function(data,_url) {

        var deferred;
        
        deferred = $http.post(_url, data).then(function(response) {

            return response;

        }, function(error) {
            var _msg;
            if (!error.data || !error.data.applicationErrors) {
                if (error.status == 404) {
                    _msg = AppConst.ERRORMESSAGES.SERDOWN;
                } else {
                    _msg = error.statusText;
                }
            } else {
                _msg = error.data.applicationErrors[0].errorMessage
            }
            //showInfo("Error", _msg, "OK");
            return error;
        });

        return deferred;
    };
    
    service.postFileData = function(data,_url, config) {

        var deferred;
        
        deferred = $http.post(_url, data, config).then(function(response) {

            return response;

        }, function(error) {
            var _msg;
            if (!error.data || !error.data.applicationErrors) {
                if (error.status == 404) {
                    _msg = AppConst.ERRORMESSAGES.SERDOWN;
                } else {
                    _msg = error.statusText;
                }
            } else {
                _msg = error.data.applicationErrors[0].errorMessage
            }
            //showInfo("Error", _msg, "OK");
            console.log("POST DATA ERROR",error);
            return error;
        });

        return deferred;
    };
    
    service.putData = function(data,_url) {
        
        var deferred, _url;

        
        deferred = $http.put(_url, data).then(function(response) {

            return response;

        }, function(error) {
            var _msg;
            if (!error.data || !error.data.applicationErrors) {
                if (error.status == 404) {
                    _msg = AppConst.ERRORMESSAGES.SERDOWN;
                } else {
                    _msg = error.statusText;
                }
            } else {
                _msg = error.data.applicationErrors[0].errorMessage
            }
            //showInfo("Error", _msg, "OK");
            return error;
        });

        return deferred;
    };
    //Site service start date
    service.siteServiceStartDate = function(actionType,param){
    	if(actionType==="SET"){//param = siteDetails
    		angular.forEach(param, function(value, key) {
    			//console.log("key="+key + " val="+value.serviceStartDate+ " siteId="+value.siteId);
    			var date = new Date(value.serviceStartDate);
    			serviceStartDateAry[value.siteId]= getFormattedDate(date);
    			
    			//console.log("date is : "+serviceStartDateAry[value.siteId]);
			});
    	}else if(actionType==="GET"){//param=siteId
    		//console.log("siteId="+param+ " date ="+serviceStartDateAry[param]);
    		return serviceStartDateAry[param];
    	}
    	
    	return "";
    }
    
    return service;
    
    function getFormattedDate(date) {
		  var year = date.getFullYear();

		  var month = (1 + date.getMonth()).toString();
		  month = month.length > 1 ? month : '0' + month;

		  var day = date.getDate().toString();
		  day = day.length > 1 ? day : '0' + day;
		  
		  return day + '/' + month + '/' + year;
		}

});