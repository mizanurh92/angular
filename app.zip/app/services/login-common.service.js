AppModule.factory('LoginService',function(AppConst){
	
	var cognitoUser = {};
	var userAttributes = {};
	var token = {};
	var session = {};
	return {
	    setCognitoUser: function (data) {
	    	cognitoUser = data;
	    },
	    getCognitoUser: function () {
	        return cognitoUser;
	    },
	    setuserAttributes: function (data) {
	    	userAttributes = data;
	    },
	    getuserAttributes: function () {
	        return userAttributes;
	    },
	    setToken: function (data) {
	    	token = data;
	    },
	    getToken: function () {
	        return token;
	    },
	    setSession: function (data) {
	    	session = data;
	    },
	    getSession: function () {
	        return session;
	    }
	    
	}
});