/* 
 *  ================================================================================
 *  Copyright (C) 2017
 */

(function() {
    'use strict';

    AppModule.factory('CommonService', commonService);
    commonService.$inject = ['$http', 'AppSettings', 'AppConst', '$q',  'AppService', '$window', '$filter','$timeout'];

    function commonService($http, AppSettings, AppConst, $q, AppService, $window, $filter, $timeout) {
        var commonService = {};
       
        
        commonService.generateCylinderChart = function(divId, data) {
        	
        	var fillColor;
    		if(data[0].value1 >= "50"){
    			fillColor = AppConst.CONST_VAR_VAL.RED;
    		}else if((data[0].value1 < "50") && (data[0].value1 >= "30")){
    			fillColor = AppConst.CONST_VAR_VAL.GREEN;
    		}else{
    			fillColor = AppConst.CONST_VAR_VAL.YELLOW;
    		}
    		$timeout(function() {
    		var chart1 = AmCharts.makeChart(divId, {	
		       	  "theme": "light",
		       	  "type": "serial",
		       	  "depth3D": 100,
		       	  "angle": 10,
		       	  "autoMargins": false,
		       	  "marginTop":0, 
		       	  "marginBottom": 0,
		       	  "marginLeft": 0,
		       	  "marginRight": 0,
		       	  "pullOutRadius":0,
		       	  "dataProvider": data,
		       	  "valueAxes": [ {
		       	    "stackType": "100%",
		       	    "gridAlpha": 0,
		       	    "labelsEnabled": false
		       	  } ],
		       	  "graphs": [ {
		       	    "type": "column",
		       	    "topRadius": 1,
		       	    "columnWidth": 1,
		       	    "showOnAxis": false,
		       	    "lineThickness": 2,
		       	    "lineAlpha": 0.5,
		       	    "lineColor": "#FFFFFF",
		       	    "fillColors": fillColor,
		       	    "fillAlphas": 0.8,
		       	    "valueField": "value1"
		       	  }, {
		       	    "type": "column",
		       	    "topRadius": 1,
		       	    "columnWidth": 1,
		       	    "showOnAxis": false,
		       	    "lineThickness": 2,
		       	    "lineAlpha": 0.5,
		       	    "lineColor": "#cdcdcd",
		       	    "fillColors": "#cdcdcd",
		       	    "fillAlphas": 0.5,
		       	    "valueField": "value2"
		       	  } ],
		
		       	  "categoryField": "category",
		       	  "listeners": [{
		            "event": "rendered",
		            "method": handleRender
		            }],
		       	  "categoryAxis": {
		       	    "axisAlpha": 0,
		       	    "labelOffset": 0,
		       	    "gridAlpha": 0
		       	  },
		       	  "export": {
		       	    "enabled": false
		       	  }
		       	});
    		}, 1000);
        };
        
        commonService.generateDataCentreUpTime = function(divId, data) {
        	
        	var chart = AmCharts.makeChart(divId, {
                "theme": "light",
                "type": "gauge",
                "axes": [{
                  "topTextFontSize": 20,
                  "topTextColor": '#057FFF',
                  "topTextYOffset": 50,
                  "topText" : parseFloat(data.dataCenterUPTIME).toFixed(2),
                  "axisColor": "#31d6ea",
                  "axisThickness": .05,
                  "endValue": 100,
                  "gridInside": true,
                  "inside": false,
                  "radius": "80%",
                  "valueInterval": 25,
                  "tickColor": "#67b7dc",
                  "startAngle": -90,
                  "endAngle": 90,
                  "bandOutlineAlpha": 0,
                  "bands": [{
                    "color": "#196F3D",
                    "endValue": 25,
                    "innerRadius": "125%",
                    "radius": "200%",
                    "gradientRatio": [0.5, 0, -0.5],
                    "startValue": 0
                  }, {
                    "color": "#7DCEA0",
                    "endValue": 50,
                    "innerRadius": "125%",
                    "radius": "200%",
                    "gradientRatio": [0.5, 0, -0.5],
                    "startValue": 25
                  }, {
                    "color": "#F4D03F",
                    "endValue": 75,
                    "innerRadius": "125%",
                    "radius": "200%",
                    "gradientRatio": [0.5, 0, -0.5],
                    "startValue": 50
                  }, {
                    "color": "#E74C3C",
                    "endValue": 100,
                    "innerRadius": "125%",
                    "radius": "200%",
                    "gradientRatio": [0.5, 0, -0.5],
                    "startValue": 75
                  }]
                }],
                "arrows": [{
                  "alpha": 1,
                  "innerRadius": "35%",
                  "nailRadius": 1,
                  "radius": "170%",
                  "value" : data.dataCenterUPTIME
                }],
                "listeners": [{
		            "event": "rendered",
		            "method": handleUptimeRender
		         }],
              });
        	
        	
        };
        
        commonService.generatePowerUsage = function(divId, data) {
        	
        	$timeout(function() {
	        	var chart = AmCharts.makeChart(divId, {
	                "theme": "light",
	                "type": "gauge",
	                "axes": [{
	                  "topTextFontSize": 13,
	                  "topTextFontFamily":"Arial",
	                  "topTextFontWeight":"normal",
	                  "topTextColor": '#00acf9',
	                  "topTextYOffset": 50,
	                /*  "topText" : parseFloat(data.powerUsageEffectiveness).toFixed(2)+'kW',*/
	                  "axisColor": "#31d6ea",
	                  "axisThickness": .05,
	                  "endValue": 100,
	                  "gridInside": true,
	                  "inside": false,
	                  "radius": "80%",
	                  "valueInterval": 20,
	                  "tickColor": "0",
	                  "startAngle": -90,
	                  "endAngle": 90,
	                  "bandOutlineAlpha": 0,
	                  "fontSize":0,
	                  "bands": [{
	                        "color": "#196F3D",
	                        "endValue": 20,
	                        "innerRadius": "125%",
	                        "radius": "200%",
	                        "gradientRatio": [0.5, 0, -0.5],
	                        "startValue": 0,
	                        "balloonText": "Within Threshold Set"
	                    }, {
	                        "color": "#ffff00",
	                        "endValue": 40,
	                        "innerRadius": "125%",
	                        "radius": "200%",
	                        "gradientRatio": [0.5, 0, -0.5],
	                        "startValue": 20,
	                        "balloonText": "Close to Threshold Set"
	                    },{
	                        "color": "#FFA500",
	                        "endValue": 60,
	                        "innerRadius": "125%",
	                        "radius": "200%",
	                        "gradientRatio": [0.5, 0, -0.5],
	                        "startValue": 40,
	                        "balloonText": "Exceeds Threshold Set"
	                    }, {
	                        "color": "#ff0000",
	                        "endValue": 80,
	                        "innerRadius": "125%",
	                        "radius": "200%",
	                        "gradientRatio": [0.5, 0, -0.5],
	                        "startValue": 60,
	                        "balloonText": "Exceeds Threshold Set"
	                    }, {
	                        "color": "#E74C3C",
	                        "endValue": 100,
	                        "innerRadius": "125%",
	                        "radius": "200%",
	                        "gradientRatio": [0.5, 0, -0.5],
	                        "startValue": 80,
	                        "balloonText": "Exceeds Threshold Set"
	                    }]
	                }],
	                
	                "arrows": [{
	                  "alpha": 1,
	                  "innerRadius": "1%",
	                  "nailRadius": 1,
	                  "radius": "140%",
	                  "startWidth":8,
	                  "value" : data
	                }],
	                "balloon": {
	                    "adjustBorderColor": true,
	                    "color": "#000000",
	                    "cornerRadius": 5,
	                    "fillColor": "#FFFFFF"
	                  },
	                "listeners": [{
			            "event": "rendered",
			           "method": handlePowerRender
		
			         }],
	              });
	        	/*setInterval(randomValue, 2000);*/

	        	/*// set random value
	        	function randomValue() {
	        	  var value = Math.round(Math.random() * 100);
	        	  chart.arrows[0].setValue(value);
	        	  chart.axes[0].setTopText(value + " %");
	        	  // adjust darker band to new value
	        	  chart.axes[0].bands[1].setEndValue(value);
	        	}*/
        	}, 1000);	
        	
        };
        
         
        commonService.DataCenterEvents = function(divId, data) {
        	
        	$timeout(function() {
        		
        		var chart = Highcharts.chart(divId, {
        		    chart: {
        		        plotBackgroundColor: null,
        		        plotBorderWidth: 0,
        		        plotShadow: false
        		        
        		    },
        		    
        		    title: {
        		        text: '',
        		        align: '',
        		        verticalAlign: '',
        		      },
        		      tooltip: {
        		    	  pointFormat: ''
        		      },
        		      pane: {
        		        center: ['50%', '75%'],
        		        size: '100%',
        		        startAngle:-70,
        		        endAngle: 90,
        		        background: {
        		          borderWidth: 0,
        		          backgroundColor: 'none',
        		          innerRadius: '60%',
        		          outerRadius: '100%',
        		          shape: 'arc'
        		        }
        		      },
        		      yAxis: [{
        		        lineWidth: 0,
        		        min: 0,
        		        max: 90,
        		        minorTickLength: 0,
        		        tickLength: 0,
        		        tickWidth: 0,
        		        labels: {
        		          enabled: false
        		        },
        		        
        		         pane: 0,

        		      }],
        		      plotOptions: {
        		        pie: {
        		        	size : '220%',
        		          dataLabels: {
        		            enabled: false,
        		            distance: -50,
        		            style: {
        		              fontWeight: 'bold',
        		              color: 'white',
        		              textShadow: '0px 1px 2px black'
        		            }
        		          },
        		          startAngle: -90,
        		          endAngle: 90,
        		          center: ['50%', '75%']
        		        },
        		        gauge: {
        		          dataLabels: {
        		            enabled: false
        		          },
        		          pivot: {
        		            radius: 0
        		          },
        		          dial: {
        		            radius: '100%',
        		            borderWidth: 10,
        		            baseWidth: 10,
        		            baseLength: '0%', // of radius
        		          }
        		        }
        		      },

        		      series: [{
        		        type: 'pie',
        		        innerSize: '50%',
        		        data: [
        		        	{
        		                name: 'Within Threshold Set',
        		                y: 60,
        		                color: '#196F3D' 
        		            },
        		            {
        		                name: 'Close to Threshold Set',
        		                y: 60,
        		                color: '#F4D03F' 
        		            },
        		            {
        		                name: 'Excedes Threshold Set',
        		                y: 60,
        		                color: '#E74C3C' 
        		            } 
        		        ]
        		      }, {
        		        type: 'gauge',
        		        data: [data],
        		        dial: {
        		          rearLength: 0
        		        }
        		      }],
        		      responsive: {
        		          rules: [{
        		              condition: {
        		                  maxWidth: 500
        		              },
        		              chartOptions: {
        		                  legend: {
        		                      align: 'center',
        		                      verticalAlign: 'bottom',
        		                      layout: 'horizontal'
        		                  },
        		                  yAxis: {
        		                      labels: {
        		                          align: 'left',
        		                          x: 0,
        		                          y: -5
        		                      },
        		                      title: {
        		                          text: null
        		                      }
        		                  },
        		                  subtitle: {
        		                      text: null
        		                  },
        		                  credits: {
        		                      enabled: false
        		                  }
        		              }
        		          }]
        		      },
        		   
        		    exporting: {
                        enabled: false
                    } 
        		});

        	}, 1000);
        };
        
        
        commonService.siteEnergyConsumption = function(divId, facilityLoad, itLoad) {
        	
        	var total = facilityLoad + itLoad ;
        	var facilityLoadPer = (facilityLoad / total) * 100;
        	var itLoadPer = (itLoad / total) * 100;
        	console.log("itLoadPer",itLoadPer);
        	console.log("facilityLoadPer",facilityLoadPer);
        	$timeout(function() {
        		
        		var chart = Highcharts.chart(divId, {
        		     chart: {
        	            plotBackgroundColor: null,
         		        plotBorderWidth: 0,
         		        backgroundColor: null,
         		        type: 'pie',
         		        	 margin: [0, 0, 0, 0],
                             spacingTop: 0,
                             spacingBottom: 0,
                             spacingLeft: 0,
                             spacingRight: 0,
                             width: 206,
                             height: 170
        	               
        	            },
        	            title: {
        	                text: ''
        	            },
        	            yAxis: {
        	                title: {
        	                    text: ''
        	                }
        	            },
        	            plotOptions: {
        	                pie: {
        	                	
        	                    shadow: false
        	                }
        	            },
        	            
        	            tooltip: {
        	                formatter: function() {
        	                    return ''+ this.y +'kW<br>';
        	                    /*+parseFloat(this.percentage).toFixed(0) +'%'*/
        	                }
        	            },
        	            series: [{
        	                name: 'Browsers',
        	                /*data: [["Total Facility Load",facilityLoad],["Total IT Load",itLoad]],*/
        	                data: [
        	                    {y: facilityLoad, color: '#00a9e3'},
        	                    {y: itLoad, color: '#bbcfd6' },
        	                    
        	                ],
        	                size: '85%',
        	                innerSize: '50%',
        	                showInLegend:false,
        	                dataLabels: {
        	                    formatter: function() {
        	                       /* return this.y ;*/
        	                        return parseFloat(this.percentage).toFixed(0) +'%';
        	                    },                 
        	                    color: 'black',
        	                    distance: -12,
        	                    fontSize: "5px"
        	                }
        	            }] ,
        	            exporting: {
                            enabled: false
                        }
        		});

        	}, 1000);
        };
        
        
 commonService.DataCenterAvailability = function(divId, data) {
        	
        	$timeout(function() {
        		
        		var chart = Highcharts.chart(divId, {
        		    chart: {
        		        plotBackgroundColor: null,
        		        plotBorderWidth: 0,
        		        plotShadow: false,
        		        backgroundColor: null,
         		        	 /*margin: [0, 0, 0, 0],
                             spacingTop: 0,
                             spacingBottom: 0,
                             spacingLeft: 0,
                             spacingRight: 0,
                             width: 250,
                             height: 220*/
	        		        spacingTop: 0,
	                        spacingBottom: 0,
	                        spacingLeft: 0,
	                        spacingRight: 0,
	                        width: 230,
	                        height: 140
	        		        
        		    },
        		    
        		    title: {
        		        text: '',
        		        align: '',
        		        verticalAlign: '',
        		      },
        		      tooltip: {
        		    	  pointFormat: ''
        		      },
        		      pane: {
        		        center: ['50%', '75%'],
        		        size: '80%',
        		        startAngle: -70,
        		        endAngle: 110,
        		        background: {
        		          borderWidth: 0,
        		          backgroundColor: 'none',
        		          innerRadius: '60%',
        		          outerRadius: '100%',
        		          shape: 'arc'
        		        }
        		      },
        		      yAxis: [{
        		        lineWidth: 0,
        		        min: 0,
        		        max: 90,
        		        minorTickLength: 0,
        		        tickLength: 0,
        		        tickWidth: 0,
        		        labels: {
        		          enabled: false
        		        },
        		         pane: 0,

        		      }],
        		      plotOptions: {
        		        pie: {
        		        	size : '140%',
        		          dataLabels: {
        		            enabled: false,
        		            distance: -50,
        		            style: {
        		              fontWeight: 'bold',
        		              color: 'white',
        		              textShadow: '0px 1px 2px black'
        		            }
        		          },
        		          startAngle: -90,
        		          endAngle: 90,
        		          center: ['50%', '75%']
        		        },
        		        gauge: {
        		          dataLabels: {
        		            enabled: false
        		          },
        		          pivot: {
        		            radius: 0
        		          },
        		          dial: {
        		            radius: '120%',
        		            borderWidth: 10,
        		            baseWidth: 10,
        		            baseLength: '0%', // of radius
        		          }
        		        }
        		      },

        		      series: [{
        		        type: 'pie',
        		        innerSize: '60%',
        		        data: [
        		        	{
        		                name: 'Within Threshold Set',
        		                y: 60,
        		                color: '#b54545' 
        		            },
        		            {
        		                name: 'Close to Threshold Set',
        		                y: 60,
        		                color: '#ff0000' 
        		            },
        		            {
        		                name: 'Excedes Threshold Set',
        		                y: 60,
        		                color: '#FFA500' 
        		            },
        		            {
        		                name: 'Excedes Threshold Set',
        		                y: 60,
        		                color: '#ffff00' 
        		            },
        		            {
        		                name: 'Excedes Threshold Set',
        		                y: 60,
        		                color: 'green' 
        		            }
        		        ]
        		      }, {
        		        type: 'gauge',
        		        data: [data],
        		        dial: {
        		          rearLength: 0
        		        }
        		      }],
        		   
        		    exporting: {
                        enabled: false
                    } 
        		});

        	}, 1000);
        };
        
        
        
commonService.DataCenterUtilization = function(divId, data) {
        	
			
			var data = parseFloat(data);
			var remaining = 100-data;
	
        	$timeout(function() {
        		
        		var chart = Highcharts.chart(divId, {
        			 /*chart: {
			        plotBackgroundColor: null,
			        plotBorderWidth: 0,
			        plotShadow: false,
			        backgroundColor: null,
			        marginRight : 110,
                    spacingTop: 0,
                    spacingBottom: 0,
                    spacingLeft: 0,
                    spacingRight: 0,
                    width: 200,
                    height: 75
			        
			    },
			    yAxis: {
			        min: 0,
			        max: 100,
			        tickPositions: [0, 100]
			        
			      },
			    title: {
			        text: '',
			        align: '',
			        verticalAlign: '',
			       
			    },
			    tooltip: {
			    	enabled: false
			    },
			    plotOptions: {
			        pie: {
			        	size : '200%',
			            dataLabels: {
			                enabled: false,
			                distance: -50,
			                style: {
			                    fontWeight: 'bold',
			                    color: 'white'
			                }
			            },
			            startAngle: -90,
			            endAngle: 90,
			            center: ['50%', '75%']
			        }
			    },
			    series: [{
			        type: 'pie',
			        name: 'Utilization',
			        innerSize: '50%',
			        data: [
			            ['consumed',   data],
			            ['remaining', remaining],
			            
			            
			        ]
			    }],*/
			 chart: {
			      plotBackgroundColor: null,
			      plotBorderWidth: 0,
			      plotShadow: false,
			    /*  marginRight : 60,*/
                  spacingTop: 0,
                  spacingBottom: 0,
                  spacingLeft: 0,
                  spacingRight: 0,
                  width: 180,
                  height: 90
			    },
			    title: {
			        text: 'Total Data Center Utilization',
			        align: 'center',
			        verticalAlign: 'middle',
			        style: {
			          fontSize: '0px'
			        },
			        
			        y: 10
			      },
			    tooltip: {
			      enabled: false
			    },
			    plotOptions: {
			      pie: {
			    	  size : '230%',
			        dataLabels: {
			          enabled: false,
			          distance: 0
			        },
			        startAngle: -90,
			        endAngle: 90,
			        center: ['50%', '95%']
			      }
			    },
			    series: [{
			      type: 'pie',
			    /*  name: '3000',*/
			      innerSize: '60%',
			      data: [{
			        y:0,
			        name: '0',
			        dataLabels: {
			        		formatter:function(){
			        		if(isNaN(data)) {
		                    	 return null;
		                    }
		                    else {
		                    	return 0;
		                    }
		                       
		                },
		                style: {
		                	textOutline: false ,
		                	fontSize: 8
		                	/*y:50,
		                	x:10*/
		                },
			          enabled: true,
			          distance : -10,
			          
			          /*color: '#ebf2f7',*/
			          color: '#000',
			          x:5,
			          y:22
			        }
			      }, {
			        y: data,
			        color: '#96bad6',
			      }, {
			        y: remaining,
			        color: '#ebf2f7',
			        
			      }, {
			        y: 0,
			        name: '100',
			        dataLabels: {
			        	formatter:function(){
			        		if(isNaN(data)) {
		                    	 return null;
		                    }
		                    else {
		                    	return 100;
		                    }
		                       
		                },
		                style: {
		                	textOutline: false,
		                	fontSize: 8 
		                },
			        	enabled: true,
		               distance :  -10,
		               color: '#ebf2f7',
		               /*color: '#000',*/
			        
			        }
			      }]
			    }],
        		    exporting: {
                        enabled: false
                    } 
        		});

        	}, 1000);
        };
		commonService.UPSUtilization = function(divId, data) {
        	
			
			var data = parseFloat(data);
			var remaining = 100-data;
	
        	$timeout(function() {
        		
        		var chart = Highcharts.chart(divId, {

			 chart: {
			      plotBackgroundColor: null,
			      plotBorderWidth: 0,
			      plotShadow: false,
			    /*  marginRight : 60,*/
                  spacingTop: 0,
                  spacingBottom: 0,
                  spacingLeft: 0,
                  spacingRight: 0,
                  width: 180,
                  height: 120
			    },
			    title: {
			        text: 'UPS Utilization',
			        align: 'center',
			        verticalAlign: 'middle',
			        style: {
			          fontSize: '0px'
			        },
			        
			        y: 10
			      },
			    tooltip: {
			      enabled: false
			    },
			    plotOptions: {
			      pie: {
			    	  size : '190%',
			        dataLabels: {
			          enabled: false,
			          distance: 0
			        },
			        startAngle: -90,
			        endAngle: 90,
			        center: ['50%', '95%']
			      }
			    },
			    series: [{
			      type: 'pie',
			    /*  name: '3000',*/
			      innerSize: '60%',
			      data: [{
			        y:0,
			        name: '0',
			        dataLabels: {
			        		formatter:function(){
			        		if(isNaN(data)) {
		                    	 return null;
		                    }
		                    else {
		                    	return 0;
		                    }
		                       
		                },
		                style: {
		                	textOutline: false ,
		                	fontSize: 10
		                	/*y:50,
		                	x:10*/
		                },
			          enabled: true,
			          distance : -10,
			          
			          /*color: '#ebf2f7',*/
			          color: '#96bad6',
			          x:5,
			          y:22
			        }
			      }, {
			        y: data,
			        color: '#96bad6',
			      }, {
			        y: remaining,
			        color: '#ebf2f7',
			        
			      }, {
			        y: 0,
			        name: '100',
			        dataLabels: {
			        	formatter:function(){
			        		if(isNaN(data)) {
		                    	 return null;
		                    }
		                    else {
		                    	return 100;
		                    }
		                       
		                },
		                style: {
		                	textOutline: false,
		                	fontSize: 10
		                },
			        	enabled: true,
		               distance :  -10,
		               color: '#96bad6',
		               /*color: '#000',*/
			        
			        }
			      }]
			    }],
        		    exporting: {
                        enabled: false
                    } 
        		});

        	}, 100);
        };
        
        commonService.electricalBoardGauge = function(divId, data) {        
        	
    		$timeout(function() {
    			var chartElectricalGauge = AmCharts.makeChart(divId, {
    	  			  "theme": "light",
    	  			  "type": "gauge",
    	  	       	  "marginTop":0, 
    	  	       	  "marginBottom": 0,
    	  	       	  "marginLeft": 0,
    	  	       	  "marginRight": 0,
    	  	       	  "pullOutRadius":0,
    	  	       	"autoMargins": false,
    	  			  "axes": [{
    	  			    /*"topTextFontSize": 10,
    	  			    "topTextYOffset": 39,*/
    	  			    "fontSize":10,
    	  			    "topText": "",
    	  			    "axisColor": "#31d6ea",
    	  			    "axisThickness": 1,
    	  			    "endValue": 100,
    	  			    "gridInside": true,
    	  			    "inside": false,
    	  			    "radius": "71%",
    	  			    /*"labelsEnabled": false,*/
    	  			    "valueInterval": 10,
    	  			    "tickColor": "#67b7dc",
    	  			    "startAngle": -90,
    	  			    "endAngle": 90,
    	  			    "unit": "",
    	  			    "bandOutlineAlpha": 0,
    	  			    "bands": [{
    	  			      "color": "#FFFFFF",
    	  			      "endValue": 100,
    	  			      "innerRadius": "100%",
    	  			      "radius": "190%",
    	  			      /*"gradientRatio": [0.5, 0, -0.5],*/
    	  			      "startValue": 0,
    	  			      "balloonText": "Utilization Capacity: "+data+"%"
    	  			    }, {
    	  			      "color": "#3cd3a3",
    	  			      "endValue": data,
    	  			      "innerRadius": "100%",
    	  			      "radius": "190%",
    	  			      "gradientRatio": [0.5, 0, -0.5],
    	  			      "startValue": 0,
    	  			      "balloonText": "Utilization Capacity: "+data+"%"
    	  			    }]
    	  			  }],
    	  			  "listeners": [{
    	  		            "event": "rendered",
    	  		            "method": handleElectricalGaugeRender
    	  		            }],
    	  		            "arrows": [{
    	  						  "alpha": 1,
    	  		                  "innerRadius": "1%",
    	  		                  "nailRadius": 1,
    	  		                  "radius": "140%",
    	  		                  "startWidth":8,
    	  		                  "value" : data   	  					   
    	  					  }]
    	  			});
    		}, 1000);
        };
        
        
        commonService.cumulativeUpsEvents = function(divId, data, categories) {
        	
			
			var data = data;
			var categories = categories;
			
			console.log("categories",categories);
			console.log("data",data);
	
        	$timeout(function() {
        		
        		var chart = Highcharts.chart(divId, {

        		    chart: {
        		        type: 'column'
        		    },

        		    title: {
        		        text: ''
        		    },

        		    xAxis: {
        		        categories: categories
        		    },

        		    yAxis: {
        		        allowDecimals: false,
        		        min: 0,
        		       
        		        title: {
        		            text: ''
        		        }
        		    },

        		    tooltip: {
        		        formatter: function () {
        		            return '<b>' + this.x + '</b><br/>' +
        		                this.series.name + ': ' + this.y + '<br/>' +
        		                'Total: ' + this.point.stackTotal;
        		        }
        		    },

        		    plotOptions: {
        		        column: {
        		            stacking: 'normal'
        		        }
        		    },

        		    series: data,
        		    
        		    exporting: {
                        enabled: false
                    } 
        		});

        	}, 100);
        };
        
        
        commonService.energyCost = function(divId, data, categories) {
        	
			
			var data2 = data[0].Last;
			var data1 = data[1].Current;
			var categories = categories;
			
			console.log("categories",categories);
			console.log("data",data);
	
        	$timeout(function() {
        		
        		var chart = Highcharts.chart(divId, {

        			chart: {
						type: 'column',
						margin: 75,
						options3d: {
							enabled: true,
							alpha: 10,
							beta: 0,
							depth: 30
						},
						backgroundColor:"#bfbfbf",
						margin:[40,10,40,70]
					},
					colors: ['#5b9cd1','#bdd7f0'],
					title: {
        		        text: ''
        		    },
					xAxis: {
						categories: categories,
						crosshair: true
					},
					plotOptions: {
						column: {
							depth: 40,
							grouping: false,
							groupZPadding: 20
						}
					},
					series: [{
						name: 'Last 12 months',
						data: data1,
						showInLegend: false
					}, {
						name: 'Previous 12 months',
						data: data2,
						showInLegend: false
					}],
					exporting: {
                        enabled: false
                    } 
        		});

        	}, 100);
        };
        
        commonService.energyUsage = function(divId, categories, lineData, actualData) {        	

	
        	$timeout(function() {
        		
        		var chart = Highcharts.chart(divId, {
					chart: {							
						zoomType: 'xy',
						backgroundColor:'#cbcbcb',
						marginTop:20
					},
					colors: ['#6eabdd','#f3913f'],					
					title: {
        		        text: ''
        		    },
					xAxis: [{
						categories:categories,
						crosshair: true
					}],
					yAxis: [{ // Primary yAxis
						
					}, { // Secondary yAxis
						title: {
							text: 'SGD',
							style: {
								color: Highcharts.getOptions().colors[0]
							}
						},
						labels: {
							format: '',
							style: {
								color: Highcharts.getOptions().colors[0]
							}
						},
						opposite: true
					}],
					plotOptions: {
						column: {
							borderWidth: 0
						}
					},
					series: [{
						name: 'UPS Load',
						type: 'column',
						yAxis: 1,
						data:lineData,
						showInLegend: false

					}, {
						name: 'Energy Cost',
						type: 'line',
						data:actualData,
						showInLegend: false
					}],
					exporting: {
						enabled: false
					}
				});
        		
        		/*chart.setSize("280", "180");*/

        	}, 100);
        };
		commonService.LoadVsDesign = function(divId, categories, lineData, actualData) {
	
        	$timeout(function() {
        		
        		Highcharts.chart(divId, {
						chart: {
							backgroundColor: '#FCFFC5',
							height: 295,
							type: 'column'
						},
						colors: ['#0080bb','#ef7a3f'],
						xAxis: {
							categories:categories,
							crosshair: true
						},
						yAxis: {
							min: 0,
							title: {
								text: 'Load in KVA'
							}
						},
						plotOptions: {
							column: {
								pointPadding: 0.1,
								borderWidth: 0
							}
						},
						series: [{
							name: 'UPS Load',
							data:lineData

						}, {
							name: 'UPS Energy',
							data: actualData

						}],
						exporting: {
							enabled: false
						} 
					});

        	}, 1);
        };
		commonService.upsloadTrend = function(divId, categories, lineData, actualData) {
	
        	$timeout(function() {
        		
        		Highcharts.chart(divId, {
					chart: {
							height: 295,
							type: 'column',
							margin: 20,
							options3d: {
								enabled: true,
								alpha: 10,
								beta: 0,
								depth: 30
							}
						},
						colors: ['#0080bb','rgb(124, 181, 236)'],
						plotOptions: {
							column: {
								depth: 30,
								grouping: false,
								groupZPadding: 20
							}
						},
						xAxis: {
							categories:categories,
							crosshair: true
						},
						series: [{
							data: lineData
						}, {
							data:actualData
						}],
						exporting: {
							enabled: false
						}
					});

        	}, 1);
        };
		commonService.LoadVsTemp = function(divId, categories, lineData, actualData,thirdData) {
	
        	$timeout(function() {
        		
        		Highcharts.chart(divId, {
					chart: {
							height: 295,
							zoomType: 'xy'
						},
						colors: ['#0080bb','#ef7a3f','#000'],
					yAxis: [{ // Primary yAxis
							
						}, { // Secondary yAxis
							title: {
								text: '',
								style: {
									color: Highcharts.getOptions().colors[0]
								}
							},
							labels: {
								format: '',
								style: {
									color: Highcharts.getOptions().colors[0]
								}
							},
							opposite: true
						}],

					xAxis: {
							categories:categories,
							crosshair: true
						},

					series: [{
						name: 'UPS Internal temperature',
						yAxis: 1,
						data: lineData
					}, {
						name: 'Ambient Temperature',
						data: actualData
					}, {
						name: 'UPS Load',
						data: thirdData
					}],
					exporting: {
							enabled: false
						} 
					});

        	}, 1);
        };
		commonService.effiencyCurve = function(divId, categories, lineData, actualData) {
	
        	$timeout(function() {
        		
        		Highcharts.chart(divId, {
					chart: {
							height: 295,
							zoomType: 'xy'
						},
						colors: ['#0080bb','#ef7a3f'],
						xAxis: [{
							categories:categories,
							crosshair: true
						}],
						yAxis: [{ // Primary yAxis
							
						}, { // Secondary yAxis
							title: {
								text: 'SGD',
								style: {
									color: Highcharts.getOptions().colors[0]
								}
							},
							labels: {
								format: '',
								style: {
									color: Highcharts.getOptions().colors[0]
								}
							},
							opposite: true
						}],
						plotOptions: {
							column: {
								borderWidth: 0
							}
						},
						series: [{
							name: 'UPS Load',
							type: 'column',
							yAxis: 1,
							data:lineData

						}, {
							name: 'Efficiency',
							type: 'line',
							data:actualData
						}],
						exporting: {
							enabled: false
						}
					});

        	}, 1);
        };
		commonService.LoadVsEnergy = function(divId, categories, lineData, actualData) {
	
        	$timeout(function() {
        		
        		Highcharts.chart(divId, {
					chart: {
							height: 295,
							type: 'column'
						},
						colors: ['#ef7a3f','#0080bb'],
						xAxis: [{
							categories:categories,
							crosshair: true
						}],
						yAxis: {
							allowDecimals: true,
							min: 0
						},

						tooltip: {
							formatter: function () {
								return '<b>' + this.x + '</b><br/>' +
									this.series.name + ': ' + this.y + '<br/>' +
									'Total: ' + this.point.stackTotal;
							}
						},

						plotOptions: {
							column: {
								stacking: 'normal',
								borderWidth: 0
							}
						},

						series: [
						 {
							name: 'UPS Energy Loss',
							data:actualData,
							stack: 'UPS LOAD'
						},{
							name: 'UPS LOAD',
							data: lineData,
							stack: 'UPS LOAD'
						}],
						exporting: {
								enabled: false
							} 
					});

        	}, 1);
        };
        
        

		function handleRender(event) {
		   $(".chartdiv1 a").remove();
		   $(".chartdiv2 a").remove();
		   $(".chartdiv3 a").remove();
		};
		    
		function handleUptimeRender(event) {
			   $("#upTime a").remove();
		};
		
		function handlePowerRender(event) {
			   $("#powerUsage a").remove();
			   $(".powerUsage a").remove();
			   $("#aveEvent a").remove();
			   $("#aveAck a").remove();
			   $("#aveNormalize a").remove();
			   
		};
		
		function handleElectricalGaugeRender(event) {
	 		   $(".electGaugeBox a").remove();	 		   
		 };

        return commonService;
    }
}());
