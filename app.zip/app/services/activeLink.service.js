/* 
 *  ================================================================================
 *  Copyright (C) 2017
 */

AppModule.factory('linkService',["$location", "AppConst", "$localStorage", function($location, AppConst, $localStorage) {
	
	'use strict';
	var activeLink = {};
	
	//var activeLink = this;
	activeLink.clickedItem = function(clickedItem) {
		
		if(clickedItem=="multisite" || clickedItem=="ops/home") {
    		
        	$location.path("ops/"+AppConst.CONST_VAR.HOME);
        	
        	activeLink.selectedMultiSite = 'active';
        	activeLink.selectedDO = '';
         	activeLink.selectedOPS = '';
           	activeLink.selectedFloor ='';
           	activeLink.selectedElectrical = '';
           	activeLink.selectedSingleLine = '';
           	activeLink.selectedAncillary = '';
           	activeLink.selectedLog = '';
           	activeLink.selectedActive = '';
           	activeLink.selectedInactive = '';
           	activeLink.selectedTrends = '';
           	activeLink.selectedTrends1 = '';
           	activeLink.selectedTrends2 = '';
           	activeLink.selectedKpi = '';
           	activeLink.selectedkpiEfficiency = '';
           	activeLink.selectedkpiPower = '';
           	activeLink.selectedkpiMechanical = '';
           	activeLink.selectedkpiAir = '';
           	activeLink.selectedkpiAvailability = '';
           	activeLink.selectedAssetP= '';
    		activeLink.selectedCRAC='';
    		activeLink.selectedserviceAction='';
    		activeLink.selecteSerTrack='';
           	return activeLink;
        	
    	}else if(clickedItem=="operations" || clickedItem=="ops/executiveOverview/"+$localStorage.siteNavId) {
     		
        	
        	activeLink.selectedDO = 'active';
         	activeLink.selectedMultiSite = '';
         	activeLink.selectedOPS = 'active';
           	activeLink.selectedFloor ='';
           	activeLink.selectedElectrical = '';
           	activeLink.selectedSingleLine = '';
           	activeLink.selectedAncillary = '';
           	activeLink.selectedLog = '';
           	activeLink.selectedActive = '';
           	activeLink.selectedInactive = '';
           	activeLink.selectedTrends = '';
           	activeLink.selectedTrends1 = '';
           	activeLink.selectedTrends2 = '';
           	activeLink.selectedKpi = '';
           	activeLink.selectedkpiEfficiency = '';
           	activeLink.selectedkpiPower = '';
           	activeLink.selectedkpiMechanical = '';
           	activeLink.selectedkpiAir = '';
           	activeLink.selectedkpiAvailability = '';
           	activeLink.selectedAssetP= '';
    		activeLink.selectedCRAC='';
    		activeLink.selectedserviceAction='';
    		activeLink.selecteSerTrack='';
           	return activeLink;
           	
     	}else if(clickedItem=="ops" || clickedItem=="ops/operationOverview/"+$localStorage.siteNavId) {
     		activeLink.selectedDO = 'active';
     		activeLink.selectedOPS = 'active';
     		activeLink.selectedFloor ='';
           	activeLink.selectedElectrical = '';
           	activeLink.selectedSingleLine = '';
           	activeLink.selectedAncillary = '';
           	activeLink.selectedLog = '';
           	activeLink.selectedActive = '';
           	activeLink.selectedInactive = '';
           	activeLink.selectedTrends = '';
           	activeLink.selectedTrends1 = '';
           	activeLink.selectedTrends2 = '';
           	activeLink.selectedKpi = '';
           	activeLink.selectedkpiEfficiency = '';
           	activeLink.selectedkpiPower = '';
           	activeLink.selectedkpiMechanical = '';
           	activeLink.selectedkpiAir = '';
           	activeLink.selectedkpiAvailability = '';
           	activeLink.selectedAssetP= '';
    		activeLink.selectedCRAC='';
    		activeLink.selectedserviceAction='';
    		activeLink.selecteSerTrack='';
           	return activeLink;
           	
     	}else if(clickedItem=="floor" || clickedItem=="ops/floorLayout/"+$localStorage.siteNavId) {
     		activeLink.selectedDO = 'active';
     		activeLink.selectedOPS = '';
     		activeLink.selectedFloor ='active';
           	activeLink.selectedElectrical = '';
           	activeLink.selectedSingleLine = '';
           	activeLink.selectedAncillary = '';
           	activeLink.selectedLog = '';
           	activeLink.selectedActive = '';
           	activeLink.selectedInactive = '';
           	activeLink.selectedTrends = '';
           	activeLink.selectedTrends1 = '';
           	activeLink.selectedTrends2 = '';
           	activeLink.selectedKpi = '';
           	activeLink.selectedkpiEfficiency = '';
           	activeLink.selectedkpiPower = '';
           	activeLink.selectedkpiMechanical = '';
           	activeLink.selectedkpiAir = '';
           	activeLink.selectedkpiAvailability = '';
           	activeLink.selectedAssetP= '';
    		activeLink.selectedCRAC='';
    		activeLink.selectedserviceAction='';
    		activeLink.selecteSerTrack='';
           	return activeLink;
        	
     	}else if(clickedItem=="electrical" || clickedItem=="ops/eleDiagram/"+$localStorage.siteNavId) {
     		activeLink.selectedDO = 'active';
     		activeLink.selectedOPS = '';
     		activeLink.selectedFloor ='';
           	activeLink.selectedElectrical = 'active';
           	activeLink.selectedSingleLine = '';
           	activeLink.selectedAncillary = '';
           	activeLink.selectedLog = '';
           	activeLink.selectedActive = '';
           	activeLink.selectedInactive = '';
           	activeLink.selectedTrends = '';
           	activeLink.selectedTrends1 = '';
           	activeLink.selectedTrends2 = '';
           	activeLink.selectedKpi = '';
           	activeLink.selectedkpiEfficiency = '';
           	activeLink.selectedkpiPower = '';
           	activeLink.selectedkpiMechanical = '';
           	activeLink.selectedkpiAir = '';
           	activeLink.selectedkpiAvailability = '';
           	activeLink.selectedAssetP= '';
    		activeLink.selectedCRAC='';
    		activeLink.selectedserviceAction='';
    		activeLink.selecteSerTrack='';
           	return activeLink;
        	
    	}else if(clickedItem=="single" || clickedItem=="ops/singleLineDiagram/"+$localStorage.siteNavId) {
    		activeLink.selectedDO = 'active';
    		activeLink.selectedOPS = '';
     		activeLink.selectedFloor ='';
           	activeLink.selectedElectrical = '';
           	activeLink.selectedSingleLine = 'active';
           	activeLink.selectedAncillary = '';
           	activeLink.selectedLog = '';
           	activeLink.selectedActive = '';
           	activeLink.selectedInactive = '';
           	activeLink.selectedTrends = '';
           	activeLink.selectedTrends1 = '';
           	activeLink.selectedTrends2 = '';
           	activeLink.selectedKpi = '';
           	activeLink.selectedkpiEfficiency = '';
           	activeLink.selectedkpiPower = '';
           	activeLink.selectedkpiMechanical = '';
           	activeLink.selectedkpiAir = '';
           	activeLink.selectedkpiAvailability = '';
           	activeLink.selectedAssetP= '';
    		activeLink.selectedCRAC='';
    		activeLink.selectedserviceAction='';
    		activeLink.selecteSerTrack='';
           	return activeLink;
           	
    	}else if(clickedItem=="log" || clickedItem=="ops/activeEvents/"+$localStorage.siteNavId || clickedItem=="ops/inactiveEvents/"+$localStorage.siteNavId) {
    		//alert($location.path());
    		if(clickedItem=="ops/activeEvents/"+$localStorage.siteNavId) {
    			//alert("inside actve")
    			activeLink.selectedDO = 'active';
        		activeLink.selectedOPS = '';
         		activeLink.selectedFloor ='';
               	activeLink.selectedElectrical = '';
               	activeLink.selectedSingleLine = '';
               	activeLink.selectedAncillary = '';
               	activeLink.selectedLog = 'active';
               	activeLink.selectedActive = 'active';
               	activeLink.selectedInactive = '';
               	activeLink.selectedTrends = '';
               	activeLink.selectedTrends1 = '';
               	activeLink.selectedTrends2 = '';
               	activeLink.selectedKpi = '';
               	activeLink.selectedkpiEfficiency = '';
               	activeLink.selectedkpiPower = '';
               	activeLink.selectedkpiMechanical = '';
               	activeLink.selectedkpiAir = '';
               	activeLink.selectedkpiAvailability = '';
               	activeLink.selectedAssetP= '';
        		activeLink.selectedCRAC='';
        		activeLink.selectedserviceAction='';
        		activeLink.selecteSerTrack='';
               	return activeLink;
    		}else if(clickedItem=="ops/inactiveEvents/"+$localStorage.siteNavId) {
    			activeLink.selectedDO = 'active';
        		activeLink.selectedOPS = '';
         		activeLink.selectedFloor ='';
               	activeLink.selectedElectrical = '';
               	activeLink.selectedSingleLine = '';
               	activeLink.selectedAncillary = '';
               	activeLink.selectedLog = 'active';
               	activeLink.selectedActive = '';
               	activeLink.selectedInactive = 'active';
               	activeLink.selectedTrends = '';
               	activeLink.selectedTrends1 = '';
               	activeLink.selectedTrends2 = '';
               	activeLink.selectedKpi = '';
               	activeLink.selectedkpiEfficiency = '';
               	activeLink.selectedkpiPower = '';
               	activeLink.selectedkpiMechanical = '';
               	activeLink.selectedkpiAir = '';
               	activeLink.selectedkpiAvailability = '';
               	activeLink.selectedAssetP= '';
        		activeLink.selectedCRAC='';
        		activeLink.selectedserviceAction='';
        		activeLink.selecteSerTrack='';
               	return activeLink;
    		}else if(clickedItem=="log" && $location.path()=="/ops/activeEvents/"+$localStorage.siteNavId) {
    			//alert("sfdgsdfgbdf")
    			activeLink.selectedDO = 'active';
        		activeLink.selectedOPS = '';
         		activeLink.selectedFloor ='';
               	activeLink.selectedElectrical = '';
               	activeLink.selectedSingleLine = '';
               	activeLink.selectedAncillary = '';
               	activeLink.selectedLog = 'active';
               	activeLink.selectedActive = 'active';
               	activeLink.selectedInactive = '';
               	activeLink.selectedTrends = '';
               	activeLink.selectedTrends1 = '';
               	activeLink.selectedTrends2 = '';
               	activeLink.selectedKpi = '';
               	activeLink.selectedkpiEfficiency = '';
               	activeLink.selectedkpiPower = '';
               	activeLink.selectedkpiMechanical = '';
               	activeLink.selectedkpiAir = '';
               	activeLink.selectedkpiAvailability = '';
               	activeLink.selectedAssetP= '';
        		activeLink.selectedCRAC='';
        		activeLink.selectedserviceAction='';
        		activeLink.selecteSerTrack='';
               	return activeLink;
    		}else if(clickedItem=="log" && $location.path()=="/ops/inactiveEvents/"+$localStorage.siteNavId) {
    			//alert("sfdgsdfgbdf")
    			activeLink.selectedDO = 'active';
        		activeLink.selectedOPS = '';
         		activeLink.selectedFloor ='';
               	activeLink.selectedElectrical = '';
               	activeLink.selectedSingleLine = '';
               	activeLink.selectedAncillary = '';
               	activeLink.selectedLog = 'active';
               	activeLink.selectedActive = '';
               	activeLink.selectedInactive = 'active';
               	activeLink.selectedTrends = '';
               	activeLink.selectedTrends1 = '';
               	activeLink.selectedTrends2 = '';
               	activeLink.selectedKpi = '';
               	activeLink.selectedkpiEfficiency = '';
               	activeLink.selectedkpiPower = '';
               	activeLink.selectedkpiMechanical = '';
               	activeLink.selectedkpiAir = '';
               	activeLink.selectedkpiAvailability = '';
               	activeLink.selectedAssetP= '';
        		activeLink.selectedCRAC='';
        		activeLink.selectedserviceAction='';
        		activeLink.selecteSerTrack='';
               	return activeLink;
    		}else if(clickedItem=="log") {
    			activeLink.selectedDO = 'active';
        		activeLink.selectedOPS = '';
         		activeLink.selectedFloor ='';
               	activeLink.selectedElectrical = '';
               	activeLink.selectedSingleLine = '';
               	activeLink.selectedAncillary = '';
               	activeLink.selectedLog = 'active';
               	activeLink.selectedActive = '';
               	activeLink.selectedInactive = '';
               	activeLink.selectedTrends = '';
               	activeLink.selectedTrends1 = '';
               	activeLink.selectedTrends2 = '';
               	activeLink.selectedKpi = '';
               	activeLink.selectedkpiEfficiency = '';
               	activeLink.selectedkpiPower = '';
               	activeLink.selectedkpiMechanical = '';
               	activeLink.selectedkpiAir = '';
               	activeLink.selectedkpiAvailability = '';
               	activeLink.selectedAssetP= '';
        		activeLink.selectedCRAC='';
        		activeLink.selectedserviceAction='';
        		activeLink.selecteSerTrack='';
               	return activeLink;
    		}
        	
    	}else if(clickedItem=="active" || clickedItem=="ops/activeEvents/"+$localStorage.siteNavId) {
    		activeLink.selectedDO = 'active';
    		activeLink.selectedOPS = '';
     		activeLink.selectedFloor ='';
           	activeLink.selectedElectrical = '';
           	activeLink.selectedSingleLine = '';
           	activeLink.selectedAncillary = '';
           	activeLink.selectedLog = '';
           	activeLink.selectedActive = 'active';
           	activeLink.selectedInactive = '';
           	activeLink.selectedTrends = '';
           	activeLink.selectedTrends1 = '';
           	activeLink.selectedTrends2 = '';
           	activeLink.selectedKpi = '';
           	activeLink.selectedkpiEfficiency = '';
           	activeLink.selectedkpiPower = '';
           	activeLink.selectedkpiMechanical = '';
           	activeLink.selectedkpiAir = '';
           	activeLink.selectedkpiAvailability = '';
           	activeLink.selectedAssetP= '';
    		activeLink.selectedCRAC='';
    		activeLink.selectedserviceAction='';
    		activeLink.selecteSerTrack='';
           	return activeLink;
        	
    	}else if(clickedItem=="inactive" || clickedItem=="ops/inactiveEvents/"+$localStorage.siteNavId) {
    		activeLink.selectedDO = 'active';
    		activeLink.selectedOPS = '';
     		activeLink.selectedFloor ='';
           	activeLink.selectedElectrical = '';
           	activeLink.selectedSingleLine = '';
           	activeLink.selectedAncillary = '';
           	activeLink.selectedLog = '';
           	activeLink.selectedActive = '';
           	activeLink.selectedInactive = 'active';
           	activeLink.selectedTrends = '';
           	activeLink.selectedTrends1 = '';
           	activeLink.selectedTrends2 = '';
           	activeLink.selectedKpi = '';
           	activeLink.selectedkpiEfficiency = '';
           	activeLink.selectedkpiPower = '';
           	activeLink.selectedkpiMechanical = '';
           	activeLink.selectedkpiAir = '';
           	activeLink.selectedkpiAvailability = '';
           	activeLink.selectedAssetP= '';
    		activeLink.selectedCRAC='';
    		activeLink.selectedserviceAction='';
    		activeLink.selecteSerTrack='';
           	return activeLink;
        	
    	}else if(clickedItem=="ancillary" || clickedItem=="ops/ancillary/"+$localStorage.siteNavId) {
    		activeLink.selectedDO = 'active';
    		activeLink.selectedOPS = '';
     		activeLink.selectedFloor ='';
           	activeLink.selectedElectrical = '';
           	activeLink.selectedSingleLine = '';
           	activeLink.selectedAncillary = 'active';
           	activeLink.selectedLog = '';
           	activeLink.selectedActive = '';
           	activeLink.selectedInactive = '';
           	activeLink.selectedTrends = '';
           	activeLink.selectedTrends1 = '';
           	activeLink.selectedTrends2 = '';
           	activeLink.selectedKpi = '';
           	activeLink.selectedkpiEfficiency = '';
           	activeLink.selectedkpiPower = '';
           	activeLink.selectedkpiMechanical = '';
           	activeLink.selectedkpiAir = '';
           	activeLink.selectedkpiAvailability = '';
           	activeLink.selectedAssetP= '';
    		activeLink.selectedCRAC='';
    		activeLink.selectedserviceAction='';
    		activeLink.selecteSerTrack='';
           	return activeLink;
        	
    	}else if(clickedItem=="trends" || clickedItem=="ops/eventsAnalytics1/"+$localStorage.siteNavId || clickedItem=="ops/eventsAnalytics2/"+$localStorage.siteNavId) {
    		if(clickedItem=="ops/eventsAnalytics1/"+$localStorage.siteNavId) {
    			activeLink.selectedDO = 'active';
        		activeLink.selectedOPS = '';
         		activeLink.selectedFloor ='';
               	activeLink.selectedElectrical = '';
               	activeLink.selectedSingleLine = '';
               	activeLink.selectedAncillary = '';
               	activeLink.selectedLog = '';
               	activeLink.selectedActive = '';
               	activeLink.selectedInactive = '';
               	activeLink.selectedTrends = 'active';
               	activeLink.selectedTrends1 = 'active';
               	activeLink.selectedTrends2 = '';
               	activeLink.selectedKpi = '';
               	activeLink.selectedkpiEfficiency = '';
               	activeLink.selectedkpiPower = '';
               	activeLink.selectedkpiMechanical = '';
               	activeLink.selectedkpiAir = '';
               	activeLink.selectedkpiAvailability = '';
               	activeLink.selectedAssetP= '';
        		activeLink.selectedCRAC='';
        		activeLink.selectedserviceAction='';
        		activeLink.selecteSerTrack='';
               	return activeLink;
    		}else if(clickedItem=="ops/eventsAnalytics2/"+$localStorage.siteNavId) {
    			activeLink.selectedDO = 'active';
        		activeLink.selectedOPS = '';
         		activeLink.selectedFloor ='';
               	activeLink.selectedElectrical = '';
               	activeLink.selectedSingleLine = '';
               	activeLink.selectedAncillary = '';
               	activeLink.selectedLog = '';
               	activeLink.selectedActive = '';
               	activeLink.selectedInactive = '';
               	activeLink.selectedTrends = 'active';
               	activeLink.selectedTrends1 = '';
               	activeLink.selectedTrends2 = 'active';
               	activeLink.selectedKpi = '';
               	activeLink.selectedkpiEfficiency = '';
               	activeLink.selectedkpiPower = '';
               	activeLink.selectedkpiMechanical = '';
               	activeLink.selectedkpiAir = '';
               	activeLink.selectedkpiAvailability = '';
               	activeLink.selectedAssetP= '';
        		activeLink.selectedCRAC='';
        		activeLink.selectedserviceAction='';
        		activeLink.selecteSerTrack='';
               	return activeLink;
    		}else if(clickedItem=="trends" && $location.path()=="/ops/eventsAnalytics1/"+$localStorage.siteNavId) {
    			activeLink.selectedDO = 'active';
        		activeLink.selectedOPS = '';
         		activeLink.selectedFloor ='';
               	activeLink.selectedElectrical = '';
               	activeLink.selectedSingleLine = '';
               	activeLink.selectedAncillary = '';
               	activeLink.selectedLog = '';
               	activeLink.selectedActive = '';
               	activeLink.selectedInactive = '';
               	activeLink.selectedTrends = 'active';
               	activeLink.selectedTrends1 = 'active';
               	activeLink.selectedTrends2 = '';
               	activeLink.selectedKpi = '';
               	activeLink.selectedkpiEfficiency = '';
               	activeLink.selectedkpiPower = '';
               	activeLink.selectedkpiMechanical = '';
               	activeLink.selectedkpiAir = '';
               	activeLink.selectedkpiAvailability = '';
               	activeLink.selectedAssetP= '';
        		activeLink.selectedCRAC='';
        		activeLink.selectedserviceAction='';
        		activeLink.selecteSerTrack='';
               	return activeLink;
    		}else if(clickedItem=="trends" && $location.path()=="/ops/eventsAnalytics2/"+$localStorage.siteNavId) {
    			activeLink.selectedDO = 'active';
        		activeLink.selectedOPS = '';
         		activeLink.selectedFloor ='';
               	activeLink.selectedElectrical = '';
               	activeLink.selectedSingleLine = '';
               	activeLink.selectedAncillary = '';
               	activeLink.selectedLog = '';
               	activeLink.selectedActive = '';
               	activeLink.selectedInactive = '';
               	activeLink.selectedTrends = 'active';
               	activeLink.selectedTrends1 = '';
               	activeLink.selectedTrends2 = 'active';
               	activeLink.selectedKpi = '';
               	activeLink.selectedkpiEfficiency = '';
               	activeLink.selectedkpiPower = '';
               	activeLink.selectedkpiMechanical = '';
               	activeLink.selectedkpiAir = '';
               	activeLink.selectedkpiAvailability = '';
               	activeLink.selectedAssetP= '';
        		activeLink.selectedCRAC='';
        		activeLink.selectedserviceAction='';
        		activeLink.selecteSerTrack='';
               	return activeLink;
    		}else if(clickedItem=="trends") {
    			
    			activeLink.selectedDO = 'active';
        		activeLink.selectedOPS = '';
         		activeLink.selectedFloor ='';
               	activeLink.selectedElectrical = '';
               	activeLink.selectedSingleLine = '';
               	activeLink.selectedAncillary = '';
               	activeLink.selectedLog = '';
               	activeLink.selectedActive = '';
               	activeLink.selectedInactive = '';
               	activeLink.selectedTrends = 'active';
               	activeLink.selectedTrends1 = '';
               	activeLink.selectedTrends2 = '';
               	activeLink.selectedKpi = '';
               	activeLink.selectedkpiEfficiency = '';
               	activeLink.selectedkpiPower = '';
               	activeLink.selectedkpiMechanical = '';
               	activeLink.selectedkpiAir = '';
               	activeLink.selectedkpiAvailability = '';
               	activeLink.selectedAssetP= '';
        		activeLink.selectedCRAC='';
        		activeLink.selectedserviceAction='';
        		activeLink.selecteSerTrack='';
               	return activeLink;
    		}
    		
        	
    	}else if(clickedItem=="trends1" || clickedItem=="ops/eventsAnalytics1/"+$localStorage.siteNavId) {
    		activeLink.selectedDO = 'active';
    		activeLink.selectedOPS = '';
     		activeLink.selectedFloor ='';
           	activeLink.selectedElectrical = '';
           	activeLink.selectedSingleLine = '';
           	activeLink.selectedAncillary = '';
           	activeLink.selectedLog = '';
           	activeLink.selectedActive = '';
           	activeLink.selectedInactive = '';
           	activeLink.selectedTrends = '';
           	activeLink.selectedTrends1 = 'active';
           	activeLink.selectedTrends2 = '';
           	activeLink.selectedKpi = '';
           	activeLink.selectedkpiEfficiency = '';
           	activeLink.selectedkpiPower = '';
           	activeLink.selectedkpiMechanical = '';
           	activeLink.selectedkpiAir = '';
           	activeLink.selectedkpiAvailability = '';
           	activeLink.selectedAssetP= '';
    		activeLink.selectedCRAC='';
    		activeLink.selectedserviceAction='';
    		activeLink.selecteSerTrack='';
           	return activeLink;
        	
    	}else if(clickedItem=="trends2" || clickedItem=="ops/eventsAnalytics2/"+$localStorage.siteNavId) {
    		activeLink.selectedDO = 'active';
    		activeLink.selectedOPS = '';
     		activeLink.selectedFloor ='';
           	activeLink.selectedElectrical = '';
           	activeLink.selectedSingleLine = '';
           	activeLink.selectedAncillary = '';
           	activeLink.selectedLog = '';
           	activeLink.selectedActive = '';
           	activeLink.selectedInactive = '';
           	activeLink.selectedTrends = '';
           	activeLink.selectedTrends1 = '';
           	activeLink.selectedTrends2 = 'active';
           	activeLink.selectedKpi = '';
           	activeLink.selectedkpiEfficiency = '';
           	activeLink.selectedkpiPower = '';
           	activeLink.selectedkpiMechanical = '';
           	activeLink.selectedkpiAir = '';
           	activeLink.selectedkpiAvailability = '';
           	activeLink.selectedAssetP= '';
    		activeLink.selectedCRAC='';
    		activeLink.selectedserviceAction='';
    		activeLink.selecteSerTrack='';
           	return activeLink;
        	
    	}else if(clickedItem=="kpi" || clickedItem=="ops/kpiAvailability/"+$localStorage.siteNavId || clickedItem=="ops/kpiEnergyEfficency/"+$localStorage.siteNavId ||clickedItem=="ops/kpiPower/"+$localStorage.siteNavId || clickedItem=="ops/kpiMechanical/"+$localStorage.siteNavId || clickedItem=="ops/kpiAirFlow/"+$localStorage.siteNavId) {
    		if(clickedItem=="ops/kpiAvailability/"+$localStorage.siteNavId) {
    			activeLink.selectedDO = 'active';
        		activeLink.selectedOPS = '';
         		activeLink.selectedFloor ='';
               	activeLink.selectedElectrical = '';
               	activeLink.selectedSingleLine = '';
               	activeLink.selectedAncillary = '';
               	activeLink.selectedLog = '';
               	activeLink.selectedActive = '';
               	activeLink.selectedInactive = '';
               	activeLink.selectedTrends = '';
               	activeLink.selectedTrends1 = '';
               	activeLink.selectedTrends2 = '';
               	activeLink.selectedKpi = 'active';
               	activeLink.selectedkpiEfficiency = '';
               	activeLink.selectedkpiPower = '';
               	activeLink.selectedkpiMechanical = '';
               	activeLink.selectedkpiAir = '';
               	activeLink.selectedkpiAvailability = 'active';
               	activeLink.selectedAssetP= '';
        		activeLink.selectedCRAC='';
        		activeLink.selectedserviceAction='';
        		activeLink.selecteSerTrack='';
               	return activeLink;
    		}else if(clickedItem=="ops/kpiEnergyEfficency/"+$localStorage.siteNavId) {
    			activeLink.selectedDO = 'active';
        		activeLink.selectedOPS = '';
         		activeLink.selectedFloor ='';
               	activeLink.selectedElectrical = '';
               	activeLink.selectedSingleLine = '';
               	activeLink.selectedAncillary = '';
               	activeLink.selectedLog = '';
               	activeLink.selectedActive = '';
               	activeLink.selectedInactive = '';
               	activeLink.selectedTrends = '';
               	activeLink.selectedTrends1 = '';
               	activeLink.selectedTrends2 = '';
               	activeLink.selectedKpi = 'active';
               	activeLink.selectedkpiEfficiency = 'active';
               	activeLink.selectedkpiPower = '';
               	activeLink.selectedkpiMechanical = '';
               	activeLink.selectedkpiAir = '';
               	activeLink.selectedkpiAvailability = '';
               	activeLink.selectedAssetP= '';
        		activeLink.selectedCRAC='';
        		activeLink.selectedserviceAction='';
        		activeLink.selecteSerTrack='';
               	return activeLink;
    		}else if(clickedItem=="ops/kpiPower/"+$localStorage.siteNavId) {
    			activeLink.selectedDO = 'active';
        		activeLink.selectedOPS = '';
         		activeLink.selectedFloor ='';
               	activeLink.selectedElectrical = '';
               	activeLink.selectedSingleLine = '';
               	activeLink.selectedAncillary = '';
               	activeLink.selectedLog = '';
               	activeLink.selectedActive = '';
               	activeLink.selectedInactive = '';
               	activeLink.selectedTrends = '';
               	activeLink.selectedTrends1 = '';
               	activeLink.selectedTrends2 = '';
               	activeLink.selectedKpi = 'active';
               	activeLink.selectedkpiEfficiency = '';
               	activeLink.selectedkpiPower = 'active';
               	activeLink.selectedkpiMechanical = '';
               	activeLink.selectedkpiAir = '';
               	activeLink.selectedkpiAvailability = '';
               	activeLink.selectedAssetP= '';
        		activeLink.selectedCRAC='';
        		activeLink.selectedserviceAction='';
        		activeLink.selecteSerTrack='';
               	return activeLink;
    		}else if(clickedItem=="ops/kpiMechanical/"+$localStorage.siteNavId) {
    			activeLink.selectedDO = 'active';
        		activeLink.selectedOPS = '';
         		activeLink.selectedFloor ='';
               	activeLink.selectedElectrical = '';
               	activeLink.selectedSingleLine = '';
               	activeLink.selectedAncillary = '';
               	activeLink.selectedLog = '';
               	activeLink.selectedActive = '';
               	activeLink.selectedInactive = '';
               	activeLink.selectedTrends = '';
               	activeLink.selectedTrends1 = '';
               	activeLink.selectedTrends2 = '';
               	activeLink.selectedKpi = 'active';
               	activeLink.selectedkpiEfficiency = '';
               	activeLink.selectedkpiPower = '';
               	activeLink.selectedkpiMechanical = 'active';
               	activeLink.selectedkpiAir = '';
               	activeLink.selectedkpiAvailability = '';
               	activeLink.selectedAssetP= '';
        		activeLink.selectedCRAC='';
        		activeLink.selectedserviceAction='';
        		activeLink.selecteSerTrack='';
               	return activeLink;
    		}else if(clickedItem=="ops/kpiAirFlow/"+$localStorage.siteNavId) {
    			activeLink.selectedDO = 'active';
        		activeLink.selectedOPS = '';
         		activeLink.selectedFloor ='';
               	activeLink.selectedElectrical = '';
               	activeLink.selectedSingleLine = '';
               	activeLink.selectedAncillary = '';
               	activeLink.selectedLog = '';
               	activeLink.selectedActive = '';
               	activeLink.selectedInactive = '';
               	activeLink.selectedTrends = '';
               	activeLink.selectedTrends1 = '';
               	activeLink.selectedTrends2 = '';
               	activeLink.selectedKpi = 'active';
               	activeLink.selectedkpiEfficiency = '';
               	activeLink.selectedkpiPower = '';
               	activeLink.selectedkpiMechanical = '';
               	activeLink.selectedkpiAir = 'active';
               	activeLink.selectedkpiAvailability = '';
               	activeLink.selectedAssetP= '';
        		activeLink.selectedCRAC='';
        		activeLink.selectedserviceAction='';
        		activeLink.selecteSerTrack='';
               	return activeLink;
    		}else if(clickedItem=="kpi" && $location.path() =="/ops/kpiAvailability/"+$localStorage.siteNavId) {
    			activeLink.selectedDO = 'active';
        		activeLink.selectedOPS = '';
         		activeLink.selectedFloor ='';
               	activeLink.selectedElectrical = '';
               	activeLink.selectedSingleLine = '';
               	activeLink.selectedAncillary = '';
               	activeLink.selectedLog = '';
               	activeLink.selectedActive = '';
               	activeLink.selectedInactive = '';
               	activeLink.selectedTrends = '';
               	activeLink.selectedTrends1 = '';
               	activeLink.selectedTrends2 = '';
               	activeLink.selectedKpi = 'active';
               	activeLink.selectedkpiEfficiency = '';
               	activeLink.selectedkpiPower = '';
               	activeLink.selectedkpiMechanical = '';
               	activeLink.selectedkpiAir = '';
               	activeLink.selectedkpiAvailability = 'active';
               	activeLink.selectedAssetP= '';
        		activeLink.selectedCRAC='';
        		activeLink.selectedserviceAction='';
        		activeLink.selecteSerTrack='';
               	return activeLink;
    		}else if(clickedItem=="kpi" && $location.path() =="/ops/kpiEnergyEfficency/"+$localStorage.siteNavId) {
    			activeLink.selectedDO = 'active';
        		activeLink.selectedOPS = '';
         		activeLink.selectedFloor ='';
               	activeLink.selectedElectrical = '';
               	activeLink.selectedSingleLine = '';
               	activeLink.selectedAncillary = '';
               	activeLink.selectedLog = '';
               	activeLink.selectedActive = '';
               	activeLink.selectedInactive = '';
               	activeLink.selectedTrends = '';
               	activeLink.selectedTrends1 = '';
               	activeLink.selectedTrends2 = '';
               	activeLink.selectedKpi = 'active';
               	activeLink.selectedkpiEfficiency = 'active';
               	activeLink.selectedkpiPower = '';
               	activeLink.selectedkpiMechanical = '';
               	activeLink.selectedkpiAir = '';
               	activeLink.selectedkpiAvailability = '';
               	activeLink.selectedAssetP= '';
        		activeLink.selectedCRAC='';
        		activeLink.selectedserviceAction='';
        		activeLink.selecteSerTrack='';
               	return activeLink;
    		}else if(clickedItem=="kpi" && $location.path() =="/ops/kpiPower/"+$localStorage.siteNavId) {
    			activeLink.selectedDO = 'active';
        		activeLink.selectedOPS = '';
         		activeLink.selectedFloor ='';
               	activeLink.selectedElectrical = '';
               	activeLink.selectedSingleLine = '';
               	activeLink.selectedAncillary = '';
               	activeLink.selectedLog = '';
               	activeLink.selectedActive = '';
               	activeLink.selectedInactive = '';
               	activeLink.selectedTrends = '';
               	activeLink.selectedTrends1 = '';
               	activeLink.selectedTrends2 = '';
               	activeLink.selectedKpi = 'active';
               	activeLink.selectedkpiEfficiency = '';
               	activeLink.selectedkpiPower = 'active';
               	activeLink.selectedkpiMechanical = '';
               	activeLink.selectedkpiAir = '';
               	activeLink.selectedkpiAvailability = '';
               	activeLink.selectedAssetP= '';
        		activeLink.selectedCRAC='';
        		activeLink.selectedserviceAction='';
        		activeLink.selecteSerTrack='';
               	return activeLink;
    		}else if(clickedItem=="kpi" && $location.path() =="/ops/kpiMechanical/"+$localStorage.siteNavId) {
    			activeLink.selectedDO = 'active';
        		activeLink.selectedOPS = '';
         		activeLink.selectedFloor ='';
               	activeLink.selectedElectrical = '';
               	activeLink.selectedSingleLine = '';
               	activeLink.selectedAncillary = '';
               	activeLink.selectedLog = '';
               	activeLink.selectedActive = '';
               	activeLink.selectedInactive = '';
               	activeLink.selectedTrends = '';
               	activeLink.selectedTrends1 = '';
               	activeLink.selectedTrends2 = '';
               	activeLink.selectedKpi = 'active';
               	activeLink.selectedkpiEfficiency = '';
               	activeLink.selectedkpiPower = '';
               	activeLink.selectedkpiMechanical = 'active';
               	activeLink.selectedkpiAir = '';
               	activeLink.selectedkpiAvailability = '';
               	activeLink.selectedAssetP= '';
        		activeLink.selectedCRAC='';
        		activeLink.selectedserviceAction='';
        		activeLink.selecteSerTrack='';
               	return activeLink;
    		}else if(clickedItem=="kpi" && $location.path() =="/ops/kpiAirFlow/"+$localStorage.siteNavId) {
    			activeLink.selectedDO = 'active';
        		activeLink.selectedOPS = '';
         		activeLink.selectedFloor ='';
               	activeLink.selectedElectrical = '';
               	activeLink.selectedSingleLine = '';
               	activeLink.selectedAncillary = '';
               	activeLink.selectedLog = '';
               	activeLink.selectedActive = '';
               	activeLink.selectedInactive = '';
               	activeLink.selectedTrends = '';
               	activeLink.selectedTrends1 = '';
               	activeLink.selectedTrends2 = '';
               	activeLink.selectedKpi = 'active';
               	activeLink.selectedkpiEfficiency = '';
               	activeLink.selectedkpiPower = '';
               	activeLink.selectedkpiMechanical = '';
               	activeLink.selectedkpiAir = 'active';
               	activeLink.selectedkpiAvailability = '';
               	activeLink.selectedAssetP= '';
        		activeLink.selectedCRAC='';
        		activeLink.selectedserviceAction='';
        		activeLink.selecteSerTrack='';
               	return activeLink;
    		}else if(clickedItem=="kpi") {
    			activeLink.selectedDO = 'active';
        		activeLink.selectedOPS = '';
         		activeLink.selectedFloor ='';
               	activeLink.selectedElectrical = '';
               	activeLink.selectedSingleLine = '';
               	activeLink.selectedAncillary = '';
               	activeLink.selectedLog = '';
               	activeLink.selectedActive = '';
               	activeLink.selectedInactive = '';
               	activeLink.selectedTrends = '';
               	activeLink.selectedTrends1 = '';
               	activeLink.selectedTrends2 = '';
               	activeLink.selectedKpi = 'active';
               	activeLink.selectedkpiEfficiency = '';
               	activeLink.selectedkpiPower = '';
               	activeLink.selectedkpiMechanical = '';
               	activeLink.selectedkpiAir = '';
               	activeLink.selectedkpiAvailability = '';
               	activeLink.selectedAssetP= '';
        		activeLink.selectedCRAC='';
        		activeLink.selectedserviceAction='';
        		activeLink.selecteSerTrack='';
               	return activeLink;
    		}
    		
    	}else if(clickedItem=="kpiAvailability" || clickedItem=="ops/kpiAvailability/"+$localStorage.siteNavId) {
    		activeLink.selectedDO = 'active';
    		activeLink.selectedOPS = '';
     		activeLink.selectedFloor ='';
           	activeLink.selectedElectrical = '';
           	activeLink.selectedSingleLine = '';
           	activeLink.selectedAncillary = '';
           	activeLink.selectedLog = '';
           	activeLink.selectedActive = '';
           	activeLink.selectedInactive = '';
           	activeLink.selectedTrends = '';
           	activeLink.selectedTrends1 = '';
           	activeLink.selectedTrends2 = '';
           	activeLink.selectedKpi = '';
           	activeLink.selectedkpiEfficiency = '';
           	activeLink.selectedkpiPower = '';
           	activeLink.selectedkpiMechanical = '';
           	activeLink.selectedkpiAir = '';
           	activeLink.selectedkpiAvailability = 'active';
           	activeLink.selectedAssetP= '';
    		activeLink.selectedCRAC='';
    		activeLink.selectedserviceAction='';
    		activeLink.selecteSerTrack='';
           	return activeLink;
    	}else if(clickedItem=="kpiEfficiency" || clickedItem=="ops/kpiEnergyEfficency/"+$localStorage.siteNavId) {
    		activeLink.selectedDO = 'active';
    		activeLink.selectedOPS = '';
     		activeLink.selectedFloor ='';
           	activeLink.selectedElectrical = '';
           	activeLink.selectedSingleLine = '';
           	activeLink.selectedAncillary = '';
           	activeLink.selectedLog = '';
           	activeLink.selectedActive = '';
           	activeLink.selectedInactive = '';
           	activeLink.selectedTrends = '';
           	activeLink.selectedTrends1 = '';
           	activeLink.selectedTrends2 = '';
           	activeLink.selectedKpi = '';
           	activeLink.selectedkpiEfficiency = 'active';
           	activeLink.selectedkpiPower = '';
           	activeLink.selectedkpiMechanical = '';
           	activeLink.selectedkpiAir = '';
           	activeLink.selectedkpiAvailability = '';
           	activeLink.selectedAssetP= '';
    		activeLink.selectedCRAC='';
    		activeLink.selectedserviceAction='';
    		activeLink.selecteSerTrack='';
           	return activeLink;
    	}else if(clickedItem=="kpiPower" || clickedItem=="ops/kpiPower/"+$localStorage.siteNavId) {
    		activeLink.selectedDO = 'active';
    		activeLink.selectedOPS = '';
     		activeLink.selectedFloor ='';
           	activeLink.selectedElectrical = '';
           	activeLink.selectedSingleLine = '';
           	activeLink.selectedAncillary = '';
           	activeLink.selectedLog = '';
           	activeLink.selectedActive = '';
           	activeLink.selectedInactive = '';
           	activeLink.selectedTrends = '';
           	activeLink.selectedTrends1 = '';
           	activeLink.selectedTrends2 = '';
           	activeLink.selectedKpi = '';
           	activeLink.selectedkpiEfficiency = '';
           	activeLink.selectedkpiPower = 'active';
           	activeLink.selectedkpiMechanical = '';
           	activeLink.selectedkpiAir = '';
           	activeLink.selectedkpiAvailability = '';
           	activeLink.selectedAssetP= '';
    		activeLink.selectedCRAC='';
    		activeLink.selectedserviceAction='';
    		activeLink.selecteSerTrack='';
           	return activeLink;
    	}else if(clickedItem=="kpiMechanical" || clickedItem=="ops/kpiMechanical/"+$localStorage.siteNavId) {
    		activeLink.selectedDO = 'active';
    		activeLink.selectedOPS = '';
     		activeLink.selectedFloor ='';
           	activeLink.selectedElectrical = '';
           	activeLink.selectedSingleLine = '';
           	activeLink.selectedAncillary = '';
           	activeLink.selectedLog = '';
           	activeLink.selectedActive = '';
           	activeLink.selectedInactive = '';
           	activeLink.selectedTrends = '';
           	activeLink.selectedTrends1 = '';
           	activeLink.selectedTrends2 = '';
           	activeLink.selectedKpi = '';
           	activeLink.selectedkpiEfficiency = '';
           	activeLink.selectedkpiPower = '';
           	activeLink.selectedkpiMechanical = 'active';
           	activeLink.selectedkpiAir = '';
           	activeLink.selectedkpiAvailability = '';
           	activeLink.selectedAssetP= '';
    		activeLink.selectedCRAC='';
    		activeLink.selectedserviceAction='';
    		activeLink.selecteSerTrack='';
           	return activeLink;
    	}else if(clickedItem=="kpiAir" || clickedItem=="ops/kpiAirFlow/"+$localStorage.siteNavId) {
    		activeLink.selectedDO = 'active';
    		activeLink.selectedOPS = '';
     		activeLink.selectedFloor ='';
           	activeLink.selectedElectrical = '';
           	activeLink.selectedSingleLine = '';
           	activeLink.selectedAncillary = '';
           	activeLink.selectedLog = '';
           	activeLink.selectedActive = '';
           	activeLink.selectedInactive = '';
           	activeLink.selectedTrends = '';
           	activeLink.selectedTrends1 = '';
           	activeLink.selectedTrends2 = '';
           	activeLink.selectedKpi = '';
           	activeLink.selectedkpiEfficiency = '';
           	activeLink.selectedkpiPower = '';
           	activeLink.selectedkpiMechanical = '';
           	activeLink.selectedkpiAir = 'active';
           	activeLink.selectedkpiAvailability = '';
           	activeLink.selectedAssetP= '';
    		activeLink.selectedCRAC='';
    		activeLink.selectedserviceAction='';
    		activeLink.selecteSerTrack='';
           	return activeLink;
    	}else if(clickedItem=="assetperformance" || clickedItem=="assetperformance/ops/upsSystemOverview/"+$localStorage.siteNavId) {
     		
    		activeLink.selectedDO = '';
        	activeLink.selectedDO = '';
         	activeLink.selectedMultiSite = '';
         	activeLink.selectedOPS = '';
           	activeLink.selectedFloor ='';
           	activeLink.selectedElectrical = '';
           	activeLink.selectedSingleLine = '';
           	activeLink.selectedAncillary = '';
           	activeLink.selectedLog = '';
           	activeLink.selectedActive = '';
           	activeLink.selectedInactive = '';
           	activeLink.selectedTrends = '';
           	activeLink.selectedTrends1 = '';
           	activeLink.selectedTrends2 = '';
           	activeLink.selectedKpi = '';
           	activeLink.selectedkpiEfficiency = '';
           	activeLink.selectedkpiPower = '';
           	activeLink.selectedkpiMechanical = '';
           	activeLink.selectedkpiAir = '';
           	activeLink.selectedkpiAvailability = '';
           	activeLink.selecteSerTrack='';
           	activeLink.selectedserviceAction='';
           	activeLink.selectedAssetP= 'active';
    		activeLink.selectedCRAC='active';
           	return activeLink;
           	
     	}else if(clickedItem=="servicetracking" || clickedItem=="servicetracking/draftRecommendations"){
     		activeLink.selectedDO = '';
        	activeLink.selectedDO = '';
         	activeLink.selectedMultiSite = '';
         	activeLink.selectedOPS = '';
           	activeLink.selectedFloor ='';
           	activeLink.selectedElectrical = '';
           	activeLink.selectedSingleLine = '';
           	activeLink.selectedAncillary = '';
           	activeLink.selectedLog = '';
           	activeLink.selectedActive = '';
           	activeLink.selectedInactive = '';
           	activeLink.selectedTrends = '';
           	activeLink.selectedTrends1 = '';
           	activeLink.selectedTrends2 = '';
           	activeLink.selectedKpi = '';
           	activeLink.selectedkpiEfficiency = '';
           	activeLink.selectedkpiPower = '';
           	activeLink.selectedkpiMechanical = '';
           	activeLink.selectedkpiAir = '';
           	activeLink.selectedkpiAvailability = '';
           	activeLink.selectedAssetP= '';
    		activeLink.selectedCRAC='';
    		activeLink.selecteSerTrack='active';
    		activeLink.selectedserviceAction='active';
           	return activeLink;
     	}
	};
	
	activeLink.activePage = function(clickedItem) {
		
		console.log("location : "+"/assetperformance/ops/upsSystemOverview/"+$localStorage.siteNavId );
		console.log("path : "+ $location.path());
		if($location.path()=="/"+AppConst.CONST_VAR.EXECUTIVEOVERVIEWCTR + "/" + $localStorage.siteNavId 
	       		  || $location.path()=="/"+AppConst.CONST_VAR.OPERATIONOVERVIEWCTR + "/" + $localStorage.siteNavId
	       		  || $location.path()=="/"+AppConst.CONST_VAR.FLAYOUTCTR + "/" + $localStorage.siteNavId
	       		  || $location.path()=="/"+AppConst.CONST_VAR.EDIAGRAMCTR + "/" + $localStorage.siteNavId
	       		  || $location.path()=="/"+AppConst.CONST_VAR.SINGLELINEDIAGRAMCTR + "/" + $localStorage.siteNavId
	       		  || $location.path()=="/"+AppConst.CONST_VAR.POWERDISTRIBUTIONUNITCTR + "/" + $localStorage.siteNavId
	       		  || $location.path()=="/"+AppConst.CONST_VAR.ANCILLARYCTR + "/" + $localStorage.siteNavId
	       		  || $location.path()=="/"+AppConst.CONST_VAR.ACTEVENTSCTR + "/" + $localStorage.siteNavId
	       		  || $location.path()=="/"+AppConst.CONST_VAR.INACTEVENTSCTR + "/" + $localStorage.siteNavId
	       		  || $location.path()=="/"+AppConst.CONST_VAR.EVENTANALYTICS1CTR + "/" + $localStorage.siteNavId
	       		  || $location.path()=="/"+AppConst.CONST_VAR.EVENTANALYTICS2CTR + "/" + $localStorage.siteNavId
	       		  || $location.path()=="/"+AppConst.CONST_VAR.KPIAVAILABILITYCTR + "/" + $localStorage.siteNavId
	       		  || $location.path()=="/"+AppConst.CONST_VAR.KPIENERGYEFFICIENCYCTR + "/" + $localStorage.siteNavId
	       		  || $location.path()=="/"+AppConst.CONST_VAR.KPIPOWERCTR + "/" + $localStorage.siteNavId
	       		  || $location.path()=="/"+AppConst.CONST_VAR.KPIMECHANICALCTR + "/" + $localStorage.siteNavId
	       		  || $location.path()=="/"+AppConst.CONST_VAR.KPIAIRFLOWCTR + "/" + $localStorage.siteNavId) {
	       	
			
			activeLink.showMultisite = false;
			activeLink.showOpr = true;
			activeLink.showAsset=false;
			activeLink.showServiceTracking=false;
			activeLink.dcIconActive = "settingsActive.png";
		    activeLink.clickedItem(clickedItem);
		       	return activeLink;
	         	
	         }else if($location.path()==="/ops/home"){
	       	  	
	        	 activeLink.showMultisite = true;
	        	 activeLink.showOpr = false;
	        	 activeLink.showAsset=false;
	        	 activeLink.showServiceTracking=false;
	        	 activeLink.dcIconActive = "settings.png";
		       	 activeLink.clickedItem(clickedItem);
			       	return activeLink;
		       	  	
			       	assetperformance/upsSystemOverview/sdslab
	         }else if($location.path()==="/assetperformance/ops/upsSystemOverview/"+$localStorage.siteNavId){
	        	 activeLink.showMultisite = false;
	        	 activeLink.showOpr = false;
	        	 activeLink.showAsset=true;
	        	 activeLink.showServiceTracking=false;
	        	 activeLink.dcIconActive = "settings.png";
		       	 activeLink.clickedItem(clickedItem);
			       	return activeLink;
		       	  	
			       	
	         }else if($location.path()==="/admin/userList" || $location.path()==="/admin/roleList" || $location.path()==="/admin/siteList" || $location.path()==="/admin/groupList") {
	        	 activeLink.showMultisite = true;
	        	 activeLink.showOpr = false;
	        	 activeLink.showAsset=false;
	        	 activeLink.showServiceTracking=false;
	        	 activeLink.dcIconActive = "settings.png";
		       	 activeLink.clickedItem(clickedItem);
			       	return activeLink;
	         }else if($location.path()==="/servicetracking/draftRecommendations"){
	        	 activeLink.showMultisite = false;
	        	 activeLink.showOpr = false;
	        	 activeLink.showAsset=false;
	        	 activeLink.showServiceTracking=true;
	        	 activeLink.dcIconActive = "settings.png";
		       	 activeLink.clickedItem(clickedItem);
			       	return activeLink;
		       	  	
			       	
	         }
	         
	         
	         
	         
	         
	         
	         else {
	        	 
	        	 return null;
	         }
	}
	return activeLink;
}]);