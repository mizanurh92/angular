/* 
 *  ================================================================================
 *  Copyright (C) 2017
 */
AppModule.constant('AppConst', {
    'TITLE': {
        'APP_NAME': 'AVRIL',
        'APP_VERSION': 'V 0.1'
    },
    'ERR_MSGS': {
        'ERROR': 'Error!',
        'ACTION_ER': 'Action not possible'
    },
    'CONST_VAR': {
    	 "CHANGE_PWD" : "reset",
         "AUTHENTICATE" : "authenticate",
         'FORCECHANGEPWD' : "forceChangePwd",
         'HOME': "home",
         'EXECUTIVEOVERVIEWCTR':"ops/executiveOverview",
         'EXECUTIVEOVERVIEW' : "executiveOverview/:siteid",
         'DATACENTEROPERATIONS' : "dataCenterOperations",
         'FLAYOUTCTR': "ops/floorLayout",
         'FLAYOUT': "floorLayout/:siteid",
         'EDIAGRAMCTR': "ops/eleDiagram",
         'EDIAGRAM': "eleDiagram/:siteid",
         'ACTEVENTSCTR': "ops/activeEvents",
         'ACTEVENTS': "activeEvents/:siteid",
         'INACTEVENTSCTR': "ops/inactiveEvents",
         'INACTEVENTS': "inactiveEvents/:siteid",
         'EVENTANALYTICS1CTR': "ops/eventsAnalytics1",
         'EVENTANALYTICS1': "eventsAnalytics1/:siteid",
         'EVENTANALYTICS2CTR': "ops/eventsAnalytics2",
         'EVENTANALYTICS2': "eventsAnalytics2/:siteid",
         'USERLISTCTR':"admin/userList",
         'USERLIST': "userList",
         'ROLELISTCTR':"admin/roleList",
         'ROLELIST': "roleList",
         'SITELISTCTR':"admin/siteList",
         'SITELIST': "siteList",
         'GROUPLISTCTR':"admin/groupList",
         'GROUPLIST': "groupList",
         'SINGLELINEDIAGRAMCTR' : "ops/singleLineDiagram",
         'SINGLELINEDIAGRAM' : "singleLineDiagram/:siteid",
         'POWERDISTRIBUTIONUNITCTR' : "ops/pdu",
         'POWERDISTRIBUTIONUNIT' : "pdu/:siteid",
         'ANCILLARYCTR' : "ops/ancillary",
         'ANCILLARY' : "ancillary/:siteid",
         'OPERATIONOVERVIEWCTR':"ops/operationOverview",
         'OPERATIONOVERVIEW' : "operationOverview/:siteid",
         'KPIAVAILABILITYCTR' : "ops/kpiAvailability",
         'KPIAVAILABILITY' : "kpiAvailability/:siteid",
         'KPIENERGYEFFICIENCYCTR' : "ops/kpiEnergyEfficency",
         'KPIENERGYEFFICIENCY' : "kpiEnergyEfficency/:siteid",
         'KPIPOWERCTR' : "ops/kpiPower",
         'KPIPOWER' : "kpiPower/:siteid",
         'KPIMECHANICALCTR' : "ops/kpiMechanical",
         'KPIMECHANICAL' : "kpiMechanical/:siteid",
         'KPIAIRFLOWCTR' : "ops/kpiAirFlow",
         'KPIAIRFLOW' : "kpiAirFlow/:siteid",
         'PULSEDATACENTEREVENT': "pulseDatacenterEvent/:siteid",
         'PULSEDATACENTEREVENTCTR' : "ops/pulseDatacenterEvent",
         'UPSSYSTEMOVERVIEWCTR' : "assetperformance/upsSystemOverview",
         'UPSSYSTEMOVERVIEW' : "upsSystemOverview/:siteid",
         'UPSASSETINFOCTR' : "assetperformance/upsAssetInfo",
         'UPSASSETINFO' : "upsAssetInfo/:siteid",
		 'UPSASSETPERFORMANCECTR' : "upsAssetPerformance",
         'UPSASSETPERFORMANCE' : "upsAssetPerformance/:siteid",
         'UPSASSETEVENTSCTR' : "upsAssetEvents",
         'UPSASSETEVENTS' : "upsAssetEvents/:siteid",
		 'UPSASSETTRENDSCTR' : "upsAssetTrends",
         'UPSASSETTRENDS' : "upsAssetTrends/:siteid",
		 'UPSASSETENERGYCTR' : "upsAssetEnergy",
         'UPSASSETENERGY' : "upsAssetEnergy/:siteid",
         'SERTRACKDRAFTRECM' : "draftRecommendations",
         'SERTRACKMEASUREVERI' : 'postMeasurementVerification',
         'UPSASSETPERFLANDINGCTR' : "assetperformance/upsAssetPerfLanding",
         'UPSASSETPERFLANDING' : "upsAssetPerfLanding/:siteid",
    },
    'TPL_URLS': {
    	'LOGIN' : "assets/jurisdiction/app/views/Login.html",
        'CHANGE_PWD' : "assets/app/views/ChangePassword.html",
        'AUTHENTICATE' : "assets/app/views/Authentication.html",
        'FORCECHANGEPWD' : "assets/app/views/forceChangePassword.html",
    	'HOME':"assets/app/views/multisiteDashboard.html",
    	'EXECUTIVEOVERVIEW' : "assets/app/views/executiveOverview.html",
    	'DATACENTEROPERATIONS': "assets/app/views/datacenterOperations.html",
        'FLAYOUT': "assets/app/views/floorLayout.html",
        'EDIAGRAM': "assets/app/views/eleDiagram.html",
        'ACTEVENTS': "assets/app/views/activeEvents.html",
        'INACTEVENTS': "assets/app/views/inactiveEvents.html",
        'EVENTANALYTICS1': "assets/app/views/eventsAnalytics1.html",
        'EVENTANALYTICS2': "assets/app/views/eventsAnalytics2.html",
        'USERLIST': "assets/admin/app/views/userList.html",
        'ROLELIST': "assets/admin/app/views/roleList.html",
        'SITELIST': "assets/admin/app/views/siteList.html",
        'SINGLELINEDIAGRAM' : "assets/app/views/singleLineDiagram.html",
        'POWERDISTRIBUTIONUNIT' : "assets/app/views/pdu.html",
        'ANCILLARY' : "assets/app/views/ancillary.html",
        'GROUPLIST' : "assets/app/views/groupList.html",
        'OPERATIONOVERVIEW' : "assets/app/views/operationOverview.html",
        'KPIAVAILABILITY' : "assets/app/views/kpiAvailabilty.html",
        'KPIENERGYEFFICIENCY' : "assets/app/views/kpiEnergyEfficiency.html",
        'KPIPOWER' : "assets/app/views/kpiPower.html",
        'KPIMECHANICAL' : "assets/app/views/kpiMechanical.html",
        'KPIAIRFLOW' : "assets/app/views/kpiairFlow.html",
        'PULSEDATACENTEREVENT': "assets/app/views/pulseDatacenterEvent.html",
        'UPSSYSTEMOVERVIEW' : "assets/assetperformance/app/views/upsSystemOverview.html",
        'UPSASSETINFO' : "assets/assetperformance/app/views/upsAssetInfo.html",
		'UPSASSETPERFORMANCE' : "assets/assetperformance/app/views/upsAssetPerformance.html",
		'UPSASSETEVENTS' : "assets/assetperformance/app/views/upsAssetEvents.html",
		'UPSASSETTRENDS' : "assets/assetperformance/app/views/upsAssetTrends.html",
        'UPSASSETENERGY' : "assets/assetperformance/app/views/upsAssetEnergy.html",
        'SERTRACKDRAFTRECM' : "assets/servicetracking/app/views/draftRecommendations.html",
        'SERTRACKMEASUREVERI' : "assets/servicetracking/app/views/measurementVeriLog.html",
        'UPSASSETPERFLANDING' : "assets/assetperformance/app/views/upsAssetPerfLanding.html"
     },
    'CONST_IDS': {
        'HOME': "100"
    },
    'TPL_FILES': {
        
     },
    'VIEWMODE': {
        'ADD': "add",
        'EDIT': "edit",
        "VIEW": "view",
        "NEW": "new"
    },

    'SUCCESSMESSAGES': {
        'LOGIN_SUCCESS' : "Login Successful",
        'AUTHENTICATE_SUCCESS' : "Verification Successful",
        'PASSWORD_SUCCESS' : "Password changed successfully",
        'WARNING_TITLE': 'Warning',
        'INFO_TITLE': 'Information',
        'SUCCESS_TITLE': "Success"
    },
    'ERRORMESSAGES': {
        'SERDOWN': "Server is down. Please try again later.",
        'UNK': "Some unknown error has occured.",
        'AUTHENTICATE_FAILURE' : "Verification Failed",
        'PWD_UNMATCH' : "The passwords do not match."
    },
    'CONFIRMMESSAGES': {
        'CONFIRM_01': "Are you sure you want to save?",
        'CONFIRM_02': "You have unsaved changes. Are you sure you want to continue?",
        'CONFIRM_03': "Are you sure you want to save?",
        'CONFIRM_04': "All your unsaved data will be cleared, Do you wish you to continue?",
        'DELETE_TITLE': "Delete",
        'DELETE_MESSAGE': "Are you sure you want to delete?"
    },
    'CONST_VAR_VAL': {
    	'RED':"#ff4c4c",
    	'GREEN':"#1aff1a",
    	'YELLOW':"#FFFF00",
    },
    'TOOLS': {
        'TEST': 'VALUE'
        
    },
    'SERVICE_QN_VAL': {
        'ADDSERVICE_QN_TITLE': "Add Service",
        'ADDSERVICE_QN_01': "Do you want to add this Service?",
        'CONFIRMSUCCESS_TITLE': "Success",
        'CONFIRMSUCCESS_DESC': "New Service saved successfully"
    },
    'CONST_PAGEREFRESHTIME':{
    	'TEN_SECONDS':10000,
    	'ONE_MINUTE':60000,
    	'TWO_MINUTE':120000,
     }
});