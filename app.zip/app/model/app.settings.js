/* 
 *  ================================================================================
 *  Copyright (C) 2017
*/
AppModule.factory('AppSettings', function($location) {

	var model = {};
	model.logedUser = {};

	model.hostname = "";
	model.protocole = "";
	model.port = "";
	
	/* model.web_server_url = model.protocole + model.hostname + model.port
			+ model.appfolder; */
	model.web_server_url = "/"		
	model.context = model.web_server_url + "avril/services/" //prod url
	model.webContext = model.web_server_url + "avril/"//to invoke services within web project
	
	return model;
});