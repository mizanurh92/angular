/* 
 *  ================================================================================
 *  Copyright (C) 2017
 */
AppModule.factory("AppModel", ["AppService", "$window", function(AppService, $window) {
    var model = {};
    
    model.contract = ['Phone', 'Email'];
    model.userMessage = {
        "title": "",
        "message": "",
        "action": ""
    };


    return model;
}]);