/* 
 *  ================================================================================
 *  Copyright (C) 2017
 */
AppModule.constant('AppConst', {
    'TITLE': {
        'APP_NAME': 'AVRIL',
        'APP_VERSION': 'V 0.1'
    },
    'ERR_MSGS': {
        'ERROR': 'Error!',
        'ACTION_ER': 'Action not possible'
    },
    'CONST_VAR': {
        'HOME': "home",
        'DATACENTEROPERATIONS' : "dataCenterOperations"
    },
    'TPL_URLS': {
    	'HOME':"app/views/multisiteDashboard.html",
    	'DATACENTEROPERATIONS': "app/views/datacenterOperations.html"
     },
    'CONST_IDS': {
        'HOME': "100"
    },
    'TPL_FILES': {
        
     },
    'VIEWMODE': {
        'ADD': "add",
        'EDIT': "edit",
        "VIEW": "view",
        "NEW": "new"
    },

    'SUCCESSMESSAGES': {
        'WARNING_TITLE': 'Warning',
        'INFO_TITLE': 'Information',
        'SUCCESS_TITLE': "Success"
  
    },
    'ERRORMESSAGES': {
        'SERDOWN': "Server is down. Please try again later.",
        'UNK': "Some unknown error has occured."
    },
    'CONFIRMMESSAGES': {
        'CONFIRM_01': "Are you sure you want to save?",
        'CONFIRM_02': "You have unsaved changes. Are you sure you want to continue?",
        'CONFIRM_03': "Are you sure you want to save?",
        'CONFIRM_04': "All your unsaved data will be cleared, Do you wish you to continue?",
        'DELETE_TITLE': "Delete",
        'DELETE_MESSAGE': "Are you sure you want to delete?"
    },
    'CONST_VAR_VAL': {
    	'RED':"#ff4c4c",
    	'GREEN':"#1aff1a",
    	'YELLOW':"#FFFF00",
    },
    'TOOLS': {
        'TEST': 'VALUE'
        
    },
    'SERVICE_QN_VAL': {
        'ADDSERVICE_QN_TITLE': "Add Service",
        'ADDSERVICE_QN_01': "Do you want to add this Service?",
        'CONFIRMSUCCESS_TITLE': "Success",
        'CONFIRMSUCCESS_DESC': "New Service saved successfully"
    }
});