/* 
 *  ================================================================================
 *  Copyright (C) 2015
 * 
 */
AppModule.factory("StateModel", function($rootScope,AppConst) {
	var model = {};
	 model.state = "login";
	return model; 
})