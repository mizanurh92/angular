AppModule.factory('UtilService', ['AppModalService', function(AppModalService) {
    'use strict';
    var utils = {},
        modalInstance, copymodalInstance, previewmodalInstance;

    utils.showModal = function(title, msg, button1, promptAction, button2, params, noButtonAction) {
        if (modalInstance) {
            modalInstance.then(function(obj) {
                obj.element.modal('hide');
                angular.element(obj.element).remove();
            });

        }
        modalInstance = initialiseModal();
        modalInstance.then(function(modalObj) {
            modalObj.scope.init();
            modalObj.scope.modal.title = title;
            modalObj.scope.modal.buttonname = button1;
            modalObj.scope.modal.buttonname2 = button2;
            modalObj.scope.modal.message = msg;

            modalObj.element.modal();
            modalObj.close.then(function(result) {
                if (promptAction && modalObj.scope.modal.action) { // check the flag in app.modal.controller to execute action.
                    promptAction(params,result);
                } else if (promptAction && noButtonAction) { //if noButtonAction== true means this will trigger the action on No button click as well.
                    promptAction(params, result);
                }

            });
        });

    };
    var initialiseModal = function() {
        return AppModalService.showModal({
            templateUrl: 'assets/app/views/alertbox.html',
            controller: "AppModalController",
            backdrop: false,
            keyboard: false

        });
    };

    return utils;
}]);